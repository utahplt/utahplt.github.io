#lang racket/base
(require (rename-in "method.rkt" 
                    [define-sprite define-sprite/orig])
         ....)

(provide (except-out (all-from-out "method.rkt")
                     define-sprite/orig)
         define-sprite)

....
