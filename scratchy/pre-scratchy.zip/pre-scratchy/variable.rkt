#lang racket/base
(require (for-syntax racket/base))

(provide define-variable
         (for-syntax variable?))

....
