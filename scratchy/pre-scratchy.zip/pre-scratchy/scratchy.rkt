#lang racket/base
(require "almost-scratchy.rkt"
         "variable.rkt"
         (for-syntax racket/base))

(provide (except-out (all-from-out "almost-scratchy.rkt")
                     set!)
         (rename-out [checked-set! set!]))

....
