#lang racket/base

(provide define-sprite run+
         
         move-y move-x turn-to change-size
         forward turn touches? say hush)

....
