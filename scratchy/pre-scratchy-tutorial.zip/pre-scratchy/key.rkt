#lang racket/base

(provide key-handler)

(define-syntax-rule (key-handler [key expr ...] ...)
  (lambda (down? given-key)
    (when down?
      (cond
       [(is-key? given-key 'key) expr ...]
       ...))))

;; is-key? : (or/c char? symbol?) symbol? -> boolean?
;;  Determines whether the given "key" from the Racket GUI layer
;;  matches out simplified symbol representation of keys
(define (is-key? given sym)
  (eq? (if (char? given)
           (string->symbol (substring (format "~s" given) 2))
           given)
       sym))
