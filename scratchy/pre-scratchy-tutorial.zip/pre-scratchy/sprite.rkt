#lang racket/base

(provide define-sprite)

....
