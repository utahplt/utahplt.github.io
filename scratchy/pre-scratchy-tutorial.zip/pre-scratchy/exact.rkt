#lang racket/base
(require "read-exact.rkt")
(provide (rename-out [read* read]
                     [read-syntax* read-syntax]))

(define (read* in)
  (syntax->datum (read-syntax* (object-name in) in)))

(define (read-syntax* src in) ....)
