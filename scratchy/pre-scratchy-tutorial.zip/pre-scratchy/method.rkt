#lang racket/base
(require "sprite.rkt")

(provide define-sprite
         
         move-y move-x turn-to change-size
         forward turn touches? say hush)
