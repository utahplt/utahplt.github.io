;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;
;; program.ss
;; Richard Cobbe and David Goldberg
;;
;; This module defines the program abstract type and several functions that
;; act upon it.  In particular, those relations that examine the entire
;; program are defined here.
;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(module program mzscheme

  (require (lib "etc.ss")
           "ast.ss")

  (provide program?
           src-program?
           tagged-program?
           src-program-main
           tagged-program-main
           make-src-program             ;; for testing
           make-tagged-program          ;; for testing
	   tagged-program-index         ;; for testing
           
           ;; make-initial-src-program :: Src-Expr -> Program[Src]
           make-initial-src-program
           
           ;; src-program-add-class! :: Program[Src] Class[Src] Class-Name
           ;;                        -> Void
           src-program-add-class!
           
           ;; make-temp-program :: Program[Src] -> Program[Tagged]
           make-temp-program
           
           ;; make-init-tagged-program :: Tagged-Expr -> Program[Tagged]
           make-init-tagged-program
           
           ;; tagged-program-add-class! :: Program[Tagged] Class[Tagged]
           ;;                           -> Void
           tagged-program-add-class!
           
           ;; program-lookup :: Program[X] Type[Class] -> Class[X]
           program-lookup
           
           ;; type-exists? :: Program Type -> Boolean
           type-exists?
           
           ;; type<=? :: Program[Tagged] Type Type -> Boolean
           type<=?
           
           ;; type=? :: Program Type Type -> Boolean
           type=?
           
           ;; type-lub :: Program[Tagged] Type Type -> (union Type #f)
           type-lub
           
	   ;; next-beta :: Program[Tagged] Type[Class] Type[Class]
	   ;; Method-Name -> (union Type[Class] #f)
	   next-beta

           ;; get-tagged-fields :: Program[Tagged] Type[Class]
           ;;                   -> (Listof Tagged-Field)
           get-tagged-fields
           
           ;; get-tagged-field :: Program[Tagged] Type[Class] Field-Name
           ;;                  -> Tagged-Field
           get-tagged-field
           
           ;; get-method :: Program[Tagged] Type[Class] Method-Name
	   ;;               ( -> 'a)
           ;;            -> (Union Method 'a)
           get-method
           
	   ;; find-method-j ::  Program[Tagged] Type[Class] Method-Name
           ;;              -> Method
	   find-method-j

	   ;; find-method ::  Program[Tagged] Type[Class] Method-Name
           ;;             -> Method
	   find-method

	   ;; find-method/betwen/handle :: Program[Tagged] Type[Class]
	   ;;                              Type[Class] Method-Name
	   ;;                              ( -> 'a)
	   ;;                              --> (Union Method 'a)
	   find-method/between/handle

           ;; get-superclass-type :: Program[Tagged] Type[Class]
           ;;                     -> (Union Type[Class] #f)
           get-superclass-type
           
           program->sexpr
           
           mv-map)
  
  (define old-inspector (current-inspector))
  (current-inspector (make-inspector))

  (define-struct program ())
  (define-struct (src-program program) (index main))
  (define-struct (tagged-program program) (index main))
  ;; Program ::= (make-src-program (Hash-Table Class-Name Class[Src])
  ;;                               Src-Expr)
  ;;           | (make-tagged-program (Hash-Table Class-Name Class[Tagged])
  ;;                                  Tagged-Expr)

  (current-inspector old-inspector)

  ;; table-lookup :: (Hash-Table Class-Name Class) Type[Class] -> Class
  ;; look up class in a hash table indexed by class name
  (define table-lookup
    (lambda (table type)
      (hash-table-get table (class-type-name type)
                      (lambda ()
                        (error 'lookup "class ~a not found"
                               (class-type-name type))))))

  ;; program-lookup :: Program[X] Type[Class] -> Class[X]
  ;; look up a class within a program
  (define program-lookup
    (lambda (prog type)
      (table-lookup ((if (src-program? prog)
                         src-program-index
                         tagged-program-index)
                     prog)
                    type)))

  ;; make-initial-src-program :: Src-Expr -> Program[Src]
  ;; define basic src-program with expr as main body
  (define make-initial-src-program
    (lambda (expr)
      (make-src-program (hash-table ('Object
                                     (make-src-class (make-class-type 'Object)
                                                     null null null)))
                        expr)))

  ;; src-program-add-class! :: Program[Src] Class[Src] Type[Class] -> Void
  ;; add a class definition to prog.  The class named by supertype must
  ;; already be part of prog.
  (define src-program-add-class!
    (lambda (prog class supertype)
      (let* ([table (src-program-index prog)]
             [superclass (table-lookup table supertype)])
        (hash-table-put! table (class-type-name (src-class-name class)) class)
        (set-src-class-subclasses! superclass
                                   (cons class
                                         (src-class-subclasses superclass))))))

  ;; make-temp-program :: Program[Src] -> Program[Tagged]
  ;; build a skeleton tagged-program out of the src-program.  The result does
  ;; not contain any useful code; it should be used only to inspect the class,
  ;; field, and method structure of the program.  Essentially: parsing gives us
  ;; a top-down tree, and we need a bottom-up tree during the elaboration
  ;; phase.  This constructs a skeleton bottom-up tree that provides enough
  ;; info for elaboration to succeed.
  (define make-temp-program
    (lambda (src-prog)
      (let ([table (make-hash-table)]
            [src-table (src-program-index src-prog)])
        (let loop ([root (table-lookup src-table (make-class-type 'Object))]
                   [supertype #f])
          (let ([class-type (src-class-name root)])
            (hash-table-put! table (class-type-name class-type)
                             (make-tagged-class
                              class-type
                              (if supertype
                                  (table-lookup table supertype)
                                  #f)
                              (src-class-fields root)
                              (map src-method->temp-method
                                   (src-class-methods root))))
            (for-each
             (lambda (subclass) (loop subclass class-type))
             (src-class-subclasses root))))
        (make-tagged-program table #f))))

  ;; src-method->temp-method :: Method[Src-Class] -> Method[#f]
  ;; Produces a method with just enough info to do type checking.
  (define src-method->temp-method
    (lambda (sm)
      (make-method (method-type sm)
		   (method-beta? sm)
                   (method-name sm)
                   (method-arg-names sm)
                   (method-arg-types sm)
                   #f)))

  ;; make-init-tagged-program :: Tagged-Expr -> Program[Tagged]
  ;; Creates the initial tagged program that will eventually be the result of
  ;; the elaboration phase.
  (define make-init-tagged-program
    (lambda (main)
      (make-tagged-program (make-hash-table) main)))

  ;; tagged-program-add-class! :: Program[Tagged] Class[Tagged] -> Void
  ;; adds a class to a tagged program.
  (define tagged-program-add-class!
    (lambda (prog class)
      (hash-table-put! (tagged-program-index prog)
                       (class-type-name (tagged-class-name class))
                       class)))

  ;; type-exists? :: Program Type -> Boolean
  ;; determines whether the named type exists within the supplied program.
  (define type-exists?
    (lambda (prog t)
      (cond
       [(ground-type? t) #t]
       [(any-type? t) #t]
       [else
        (and (hash-table-get (if (src-program? prog)
                                 (src-program-index prog)
                                 (tagged-program-index prog))
                             (class-type-name t)
                             (lambda () #f))
             #t)])))

  ;; type<=? :: Program[Tagged] Type Type -> Boolean
  ;; returns #t if first type is subtype of (or equal to) second within prog.
  (define type<=?
    (lambda (prog t1 t2)
      (cond
       [(ground-type? t1) (and (ground-type? t2)
                               (eq? (ground-type-name t1)
                                    (ground-type-name t2)))]
       [(ground-type? t2) #f]
       [(any-type? t1) (or (any-type? t2) (class-type? t2))]
       [(class-type? t1) (and (class-type? t2) (subclass?
                                                (program-lookup prog t1)
                                                (program-lookup prog t2)))])))

  ;; subclass? :: Class[Tagged] Class[Tagged] -> Boolean
  ;; returns #t if c1 is a subclass of or equal to c2.
  (define subclass?
    (lambda (c1 c2)
      (let loop ([c1 c1])
          (cond
           [(boolean? c1) #f]
           [(eq? c1 c2) #t]
           [else (loop (tagged-class-superclass c1))]))))

  ;; type=? :: Program Type Type -> Boolean
  ;; determines if types t1 and t2 are the same within prog.
  (define type=?
    (lambda (prog t1 t2)
      (cond
        [(ground-type? t1) (and (ground-type? t2)
                                (eq? (ground-type-name t1)
                                     (ground-type-name t2)))]
        [(class-type? t1) (and (class-type? t2)
                               (eq? (class-type-name t1)
                                    (class-type-name t2)))]
        [(any-type? t1) (any-type? t2)])))

  ;; type-lub :: Program[Tagged] Type Type -> (Union Type #f)
  ;; finds the smallest type t in prog s.t. t1 <: t and t2 <: t.  Smallest here
  ;; means that for all types t' s.t. t1 <: t' and t2 <: t', t <: t'.  If no
  ;; such type exists, returns #f.
  (define type-lub
    (lambda (prog t1 t2)
      (cond
        [(ground-type? t1) (if (and (ground-type? t2)
                                    (eq? (ground-type-name t1)
                                         (ground-type-name t2)))
                               t1
                               #f)]
        [(ground-type? t2) #f]
        [(any-type? t1) t2]
        [(any-type? t2) t1]
        [else (class-lub (program-lookup prog t1)
                         (program-lookup prog t2))])))


  ;; next-beta :: Program[Tagged] Type[Class] Type[Class] Method-Name ->
  ;;              (union Type[Class] #f)
  ;; finds the class c with the first method m declared beta s.t.
  ;; (and (type<? c c1) (type<=? c2 c))
  ;; if c does not exists, finds the smallest class c' with method m s.t.
  ;; (and (type<? c' c1) (type<=? c2 c')) where smallest means for all types
  ;; c'' where c'' < c1 and c2 <= c'', c' <= c''
  ;; if c' does not exist, returns #f
  (define (next-beta prog c1 c2 m)
    (find-method/between/handle prog c2 c1 m (lambda () #f)))

  ;; class-lub :: Class[Tagged] Class[Tagged] -> Type[Class]
  ;; similar to type-lub, but restricted to class types.
  (define class-lub
    (lambda (c1 c2)
      '(printf "class-lub: c1 ~a~nc2 ~a~n" (type->sexpr (tagged-class-name c1))
              (type->sexpr (tagged-class-name c2)))
      (let loop ([c1 c1])
        '(printf "class-lub loop: c1 = ~a~n"
                (type->sexpr (tagged-class-name c1)))
        (if (subclass? c2 c1)
            (tagged-class-name c1)
            (loop (tagged-class-superclass c1))))))

  ;; get-tagged-fields :: Program[Tagged] Type[Class] -> (Listof Tagged-Field)
  ;; Returns a list of *all* fields in class, inherited, shadowed, and
  ;; otherwise, in order of declaration.  Superclass first.
  (define get-tagged-fields
    (lambda (prog type)
      (let loop ([class (program-lookup prog type)])
        (if (not class)
            null
            (append (loop (tagged-class-superclass class))
                    (map (lambda (fd)
                           (make-tagged-field (tagged-class-name class)
                                              (field-type fd)
                                              (field-name fd)))
                         (tagged-class-fields class)))))))

  ;; get-tagged-field :: Program[Tagged] Type[Class] Field-Name
  ;;                  -> Tagged-Field
  ;; Returns information about named field within specified class; does the
  ;; right thing for shadowing.
  (define get-tagged-field
    (lambda (prog type field)
      (letrec ([find-class
                (lambda (class)
                  (if (not class)
                      (error 'get-tagged-field
                             "field ~a doesn't exist in class ~a"
                             field (type->sexpr type))
                      (find-field-in-class class)))]
               [find-field-in-class
                (lambda (class)
                  (let loop ([fields (tagged-class-fields class)])
                    (cond
                      [(null? fields)
                       (find-class (tagged-class-superclass class))]
                      [(eq? field (field-name (car fields)))
                       (make-tagged-field (tagged-class-name class)
                                          (field-type (car fields))
                                          (field-name (car fields)))]
                      [else (loop (cdr fields))])))])
        (find-class (program-lookup prog type)))))

  ;; find-method :: Program[Tagged] Type[Class] Method-Name
  ;;            -> Method
  ;; Returns info about the named method for the given class.
  ;; For java and beta style inheritance.
  (define (find-method prog type method)
    (find-method/between/handle prog type (make-class-type #f) method 
				(lambda ()
				  (error 'find-method
					 "method ~a doesn't exist in class ~a"
					 method (type->sexpr type)))))
  (define find-method/between/handle
    (lambda (prog type-begin type-end method handler)
      (letrec ([find-beta 
		(lambda (cur-class prev-found)
		  (if (and cur-class
			   (not (eq? (class-type-name (tagged-class-name cur-class)) (class-type-name type-end))))
		      (let ([found (get-method prog (tagged-class-name cur-class) method (lambda () #f))])
			(find-beta (tagged-class-superclass cur-class)
				   (if (and found
					    (method-beta? found))
				       found
				       prev-found)))
		      (if prev-found
			  prev-found
			  (find-method-j/between/handle prog type-begin type-end method handler))))])
	(find-beta (program-lookup prog type-begin) #f))))

  ;; find-method-j :: Program[Tagged] Type[Class] Method-Name
  ;;            -> Method
  ;; Returns info about the named method for the given class, searching in
  ;; java style
  (define (find-method-j prog type m)
    (find-method-j/between/handle prog type (make-class-type #f) m 
				  	(lambda ()
				  (error 'find-method
					 "method ~a doesn't exist in class ~a"
					 m (type->sexpr type)))))
  (define find-method-j/between/handle
    (lambda (prog type-begin type-end method handler)
      
      (letrec ([find-class
                (lambda (class)
                  (if (or (not class)
			  (eq? (class-type-name (tagged-class-name class)) (class-type-name type-end)))
		      (handler)
                      (let ([found (get-method prog (tagged-class-name class) method (lambda () #f))])
			(if found
;; *****Enforce superclass has to be java-style?
			    found
			    (find-class (tagged-class-superclass class))))))])

       
        (find-class (program-lookup prog type-begin)))))

  ;; get-method :: Program[Tagged] Type[Class] Method-Name ( -> 'a)
  ;;            -> (Union Method 'a)
  (define get-method
    (lambda (prog type method handler)
      (let ([class (program-lookup prog type)])
	(let loop ([methods (tagged-class-methods class)])
	  (cond
	   [(null? methods) (handler)]
	   [(eq? method (method-name (car methods)))
	    (car methods)]
	   [else (loop (cdr methods))])))))

  ;; get-superclass-type :: Program[Tagged] Type[Class]
  ;;                     -> (Union Type[Class] #f)
  (define get-superclass-type
    (lambda (prog type)
      (let* ([class (program-lookup prog type)]
             [superclass (tagged-class-superclass class)])
        (if superclass
            (tagged-class-name superclass)
            #f))))

  (define program->sexpr
    (lambda (prog)
      (cond
       [(src-program? prog)
        `(src-program
          ,@(hash-table-map (src-program-index prog)
                            (lambda (k v)
                              `(src-class
                                ,k
                                ,(map (lambda (s)
                                        (class-type-name
                                         (src-class-name s)))
                                      (src-class-subclasses v))
                                ,(src-class-fields v)
                                ,(src-class-methods v))))
          ,(src-program-main prog))]
       [(tagged-program? prog)
        `(tagged-program
          ,@(hash-table-map (tagged-program-index prog)
                            (lambda (k v)
                              `(tagged-class
                                ,k
                                ,(if (tagged-class-superclass v)
                                     (class-type-name
                                      (tagged-class-name
                                       (tagged-class-superclass v)))
                                     #f)
                                ,(tagged-class-fields v)
                                ,(tagged-class-methods v))))
          ,(tagged-program-main prog))])))
  
  ;; map, but for functions that return 2 values.
  (define mv-map
    (lambda (f l)
      (if (null? l)
          (values null null)
          (let-values ([(bs cs) (mv-map f (cdr l))]
                       [(b c) (f (car l))])
            (values (cons b bs) (cons c cs))))))
  )
