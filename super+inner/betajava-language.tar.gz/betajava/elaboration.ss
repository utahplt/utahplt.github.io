;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;
;; elaboration.ss
;;
;; Richard Cobbe and David Goldberg
;;
;; Code to type-check and elaborate the program.
;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(module elaboration mzscheme
  
  (require (lib "match.ss")
           (lib "list.ss")
           "environment.ss"
           "ast.ss"
           "program.ss")
  
  (provide elaborate-program)

  ;; elaborate-program :: Program[Src] -> Program[Tagged]
  (define elaborate-program
    (lambda (src-prog)
      (let ([root (program-lookup src-prog (make-class-type 'Object))]
            [tmp-prog (make-temp-program src-prog)])
        (let*-values ([(main type) ((elab-expr tmp-prog
                                               (make-empty-env))
                                    (src-program-main src-prog))]
                      [(tagged-prog) (make-init-tagged-program main)])
          (elab-class! root #f tmp-prog tagged-prog)
          tagged-prog))))
  
  ;; elab-class! :: Class[Src] (Union Type[Class] #f)
  ;;                Program[Tagged] Program[Tagged]
  ;;             -> Void
  (define elab-class!
    (lambda (class superclass tmp-prog tagged-prog)
      (unless (andmap (lambda (fd)
                        (type-exists? tmp-prog (field-type fd)))
                      (src-class-fields class))
        (error 'elab-class!
               "bad field type in class ~a" (class-type-name
                                             (src-class-name class))))
      (tagged-program-add-class!
       tagged-prog
       (make-tagged-class (src-class-name class)
                          (if superclass
                              (program-lookup tagged-prog superclass)
                              #f)
                          (src-class-fields class)
                          (map (elab-method tmp-prog (src-class-name class))
                               (src-class-methods class))))
      (for-each (lambda (subclass)
                  (elab-class! subclass (src-class-name class)
                               tmp-prog tagged-prog))
                (src-class-subclasses class))))
  
  ;; elab-method :: Program[Tagged] Type[Class] -> (Method Src-Expr)
  ;;             -> (Method Tagged-Expr)
  (define elab-method
    (lambda (prog class-type)
      (lambda (method)
        (unless (andmap (lambda (type) (type-exists? prog type))
                        (method-arg-types method))
          (error 'elab-method
                 "class ~a: bad arg type in method ~a"
                 (class-type-name class-type)
                 (method-name method)))
        (unless (type-exists? prog (method-type method))
          (error 'elab-method
                 "class ~a: nonexistent return type in method ~a"
                 (class-type-name class-type)
                 (method-name method)))
        (let*-values ([(env) (extend-env
                              (make-empty-env)
                              (cons 'method-name 
				    (cons 'this (method-arg-names method)))
                              (cons (method-name method)
				    (cons class-type
					  (method-arg-types method))))]
                      [(body type) 
                       ((elab-expr prog env) (method-body method))])
          (unless (type<=? prog type (method-type method))
            (error 'elab-method
                   "class ~a: return type mismatch in method ~a"
                   (class-type-name class-type)
                   (method-name method)))
          (make-method (method-type method)
		       (method-beta? method)
                       (method-name method)
                       (method-arg-names method)
                       (method-arg-types method)
                       body)))))
  
  ;; elab-expr :: Program[Tagged] (Env Type) -> Src-Expr -> Tagged-Expr Type
  (define elab-expr
    (lambda (prog tenv)
      (match-lambda
        [($ new type args) (elab-new prog tenv type args)]
        [($ var-ref var) (elab-var-ref prog tenv var)]
        [(? nil? expr) (values expr (make-any-type))]
        [($ field-ref obj field) (elab-field-ref prog tenv obj field)]
        [($ method-call obj method args) (elab-method-call prog tenv
                                                           obj method args)]
        [($ super-call method args) (elab-super-call prog tenv method args)]
	[($ inner-call elseexp args) (elab-inner-call prog tenv elseexp args)]
        [($ cast type obj) (elab-cast prog tenv type obj)]
        [(? num-lit? expr) (values expr (make-ground-type 'int))]
        [(? bool-lit? expr) (values expr (make-ground-type 'bool))]
        [($ unary-prim rator rand) (elab-unary-prim prog tenv rator rand)]
        [($ binary-prim rator r1 r2) (elab-binary-prim prog tenv rator r1 r2)]
        [($ if-expr test then else) (elab-if-expr prog tenv
                                                  test then else)])))
  
  ;; elab-new :: Program[Tagged] (Env Type) Type[Class] (Listof Src-Expr)
  ;;          -> Tagged-Expr[New] Type[Class]
  (define elab-new
    (lambda (prog tenv type args)
      (unless (type-exists? prog type)
        (error 'elab-new "class ~a doesn't exist" (class-type-name type)))
      (let-values ([(tagged-args arg-types)
                    (mv-map (elab-expr prog tenv) args)]
                   [(tagged-fields) (get-tagged-fields prog type)])
        (unless (= (length tagged-fields) (length arg-types))
          (error 'elab-new
                 "arity error (class ~a) expected ~a args, got ~a"
                 (class-type-name type) (length tagged-fields)
                 (length arg-types)))
        (for-each (lambda (expected actual)
                    (unless (type<=? prog actual (tagged-field-type expected))
                      (error 'elab-new
                             "arg type error: expected ~a, got ~a"
                             (tagged-field-type expected) actual)))
                  (get-tagged-fields prog type)
                  arg-types)
        (values (make-new type tagged-args) type))))
  
  ;; elab-var-ref :: Program[Tagged] (Env Type) ID
  ;;              -> Tagged-Expr[Var] Type[!Any]
  (define elab-var-ref
    (lambda (prog tenv id)
      (values (make-var-ref id)
              (lookup tenv id (lambda ()
                                (error 'elab-var-ref
                                       "unbound id ~a" id))))))
  
  ;; elab-field-ref :: Program[Tagged] (Env Type) Src-Expr Field-Name
  ;;                -> Tagged-Expr[Tagged-Field-Ref] Type[!Any]
  (define elab-field-ref
    (lambda (prog tenv obj field)
      (let-values ([(tagged-obj obj-type) ((elab-expr prog tenv) obj)])
        (unless (class-type? obj-type)
          (error 'elab-field-ref
                 "ivar: expected class type, got ~a" obj))
        (let ([tagged-field (get-tagged-field prog obj-type field)])
          (values (make-tagged-field-ref tagged-obj
                                         (tagged-field-class tagged-field)
                                         field)
                  (tagged-field-type tagged-field))))))
  
  ;; elab-method-call :: Program[Tagged] (Env Type) Src-Expr Method-Name
  ;;                     (Listof Src-Expr)
  ;;                  -> Tagged-Expr[Method-Call] Type[!Any]
  (define elab-method-call
    (lambda (prog tenv obj method-name args)
      (let*-values ([(tagged-obj obj-type)
                     ((elab-expr prog tenv) obj)]
                    [(method) (find-method prog obj-type method-name)]
                    [(tagged-args arg-types)
                     (mv-map (elab-expr prog tenv) args)])
        (unless (= (length (method-arg-types method))
                   (length arg-types))
          (error 'elab-method-call
                 "class ~a, method ~a: expected ~a args, got ~a"
                 (class-type-name obj-type) method-name
                 (length (method-arg-types method)) (length arg-types)))
        (for-each (lambda (expected actual)
                    (unless (type<=? prog actual expected)
                      (error 'elab-method-call
                             "arg type error: expected ~a, got ~a"
                             expected actual)))
                  (method-arg-types method) arg-types)
        (values (make-method-call tagged-obj method-name tagged-args)
                (method-type method)))))
  
  ;; elab-super-call :: Program[Tagged] (Env Type) Method-Name
  ;;                    (Listof Src-Expr)
  ;;                 -> Tagged-Expr[Tagged-Super-Call] Type[!Any]
  (define elab-super-call
    (lambda (prog tenv method args)
      (let* ([this-type (lookup tenv 'this
                                (lambda ()
                                  (error 'elab-super-call
                                         "internal error: this not bound")))]
             [superclass (get-superclass-type prog this-type)]
             [supermethod (find-method-j prog superclass method)])
	(unless (not (method-beta? supermethod))
		(error 'elab-super-call
		       "superclass ~a of class ~a, method ~a: declared beta"
		       (class-type-name superclass)
		       (class-type-name this-type)
		       method))
        (let-values ([(tagged-args arg-types)
                      (mv-map (elab-expr prog tenv) args)])
          (unless (= (length arg-types)
                     (length (method-arg-types supermethod)))
            (error 'elab-super-call
                   "class ~a, method ~a: expected ~a args, got ~a"
                   (class-type-name this-type)
                   method
                   (length (method-arg-types supermethod))
                   (length arg-types)))
          (for-each (lambda (expected actual)
                      (unless (type<=? prog actual expected)
                        (error 'elab-super-call
                               "class ~a, method ~a: expected ~a, got ~a"
                               (class-type-name this-type)
                               method
                               expected
                               actual)))
                    (method-arg-types supermethod)
                    arg-types)
          (values
           (make-tagged-super-call superclass method tagged-args)
           (method-type supermethod))))))
  
  ;; elab-inner-call :: Program[Tagged] (Env Type) Src-Expr (Listof Src-Expr)
  ;;                    -> Tagged-Expr[Tagged-Inner-Call] Type[!Any]
  (define (elab-inner-call prog tenv elseexp args)
    (let* ([this-type (lookup tenv 'this
			      (lambda ()
				(error 'elab-inner-call
				       "internal error: this not bound")))]
	   [method-name (lookup tenv 'method-name
				(lambda ()
				  (error 'elab-inner-call
					 "internal error: no method name bound")))]
	   [cur-method (get-method prog this-type method-name 
				   (lambda ()
				     (error 'elab-inner-call
					    "internal error: no method ~a in class ~a"
					    method-name
					    (class-type-name this-type))))]
	   )
      (unless (method-beta? cur-method)
	      (error 'elab-inner-call
		     "class ~a, method ~a: not declared beta"
		     (class-type-name this-type)
		     method-name))
      (let-values ([(tagged-else else-type) ((elab-expr prog tenv) elseexp)]
		   [(tagged-args arg-types)
		    (mv-map (elab-expr prog tenv) args)])
        (unless (= (length arg-types)
                   (length (method-arg-types cur-method)))
          (error 'elab-inner-call
                 "class ~a, method ~a: expected ~a args, got ~a"
                 (class-type-name this-type)
                 method-name
                 (length (method-arg-types cur-method))
                 (length arg-types)))
        (for-each (lambda (expected actual)
                    (unless (type<=? prog actual expected)
                      (error 'elab-inner-call
                             "class ~a, method ~a: expected ~a, got ~a"
                             (class-type-name this-type)
                             method-name
                             expected
                             actual)))
                  (method-arg-types cur-method)
                  arg-types)
        (let ([result-type (type-lub prog (method-type cur-method) else-type)])
          (if result-type
              (values
               (make-tagged-inner-call tagged-else this-type method-name tagged-args)
               result-type)
              (error 'elab-inner-call
                     "method type and else type must be same: got ~a and ~a"
                     (type->sexpr (method-type cur-method))
                     (type->sexpr else-type)))))))
  
  ;; elab-cast :: Program[Tagged] (Env Type) Type[Class] Src-Expr
  ;;           -> Tagged-Expr Type[Class]
  (define elab-cast
    (lambda (prog tenv type obj)
      (let-values ([(tagged-obj obj-type) ((elab-expr prog tenv) obj)])
        (cond
          [(type<=? prog obj-type type) (values tagged-obj type)]
          [(type<=? prog type obj-type) (values (make-cast type tagged-obj)
                                                type)]
          [else (error 'elab-cast
                       "cannot cast ~a to ~a"
                       (type->sexpr obj-type)
                       (type->sexpr type))]))))
  
  ;; elab-unary-prim :: Program[Tagged] (Env Type) Unary-Prim Src-Expr
  ;;                 -> Tagged-Expr[Unary-Prim] Type[!Any;!Class]
  (define elab-unary-prim
    (lambda (prog tenv prim arg)
      (let-values ([(tagged-arg arg-type) ((elab-expr prog tenv) arg)])
        (let ([check-type (lambda (prim? msg)
                            (unless (prim? arg-type)
                              (error 'elab-unary-prim msg
                                     (type->sexpr arg-type))))])
          (case prim
            [(zero?) (check-type (lambda (t)
                                   (type=? prog t (make-ground-type 'int)))
                                 "zero?: expected int, got ~a")]
            [(null?) (check-type (lambda (t)
                                   (type<=? prog t (make-class-type 'Object)))
                                 "null?: expected class type, got ~a")]
            [(not) (check-type (lambda (t)
                                 (type=? prog t (make-ground-type 'bool)))
                               "not: expected boolean, got ~a")])
          (values (make-unary-prim prim tagged-arg)
                  (make-ground-type 'bool))))))
  
  ;; elab-binary-prim :: Program[Tagged] (Env Type) Binary-Prim
  ;;                     Src-Expr Src-Expr
  ;;                  -> Tagged-Expr[Binary-Prim] Type[!Any;!Class]
  (define elab-binary-prim
    (lambda (prog tenv prim arg1 arg2)
      (let-values ([(tagged-arg1 arg1-type) ((elab-expr prog tenv) arg1)]
                   [(tagged-arg2 arg2-type) ((elab-expr prog tenv) arg2)])
        (let ([check-type (lambda (type-f expected actual prim)
                            (unless (type-f prog actual expected)
                              (error 'elab-binary-prim
                                     "~a: expected ~a, got ~a"
                                     prim
                                     (type->sexpr expected)
                                     (type->sexpr actual))))])
          (case prim
            [(+ - *)
             (check-type type=? (make-ground-type 'int) arg1-type prim)
             (check-type type=? (make-ground-type 'int) arg2-type prim)
             (values (make-binary-prim prim tagged-arg1 tagged-arg2)
                     (make-ground-type 'int))]
            [(and or)
             (check-type type=? (make-ground-type 'bool) arg1-type prim)
             (check-type type=? (make-ground-type 'bool) arg2-type prim)
             (values (make-binary-prim prim tagged-arg1 tagged-arg2)
                     (make-ground-type 'bool))]
            [(==)
             (check-type type=? (make-ground-type 'int) arg1-type prim)
             (check-type type=? (make-ground-type 'int) arg2-type prim)
             (values (make-binary-prim prim tagged-arg1 tagged-arg2)
                     (make-ground-type 'bool))])))))
  
  ;; elab-if-expr :: Program[Tagged] (Env Type)
  ;;                 Src-Expr Src-Expr Src-Expr
  ;;              -> Tagged-Expr[If-Expr] Type
  (define elab-if-expr
    (lambda (prog tenv test then else)
      (let ([elab (elab-expr prog tenv)])
        (let-values ([(tagged-test test-type) (elab test)]
                     [(tagged-then then-type) (elab then)]
                     [(tagged-else else-type) (elab else)])
          (unless (type=? prog test-type (make-ground-type 'bool))
            (error 'elab-if-expr
                   "expected boolean test; got ~a"
                   (type->sexpr test-type)))
          (let ([result-type (type-lub prog then-type else-type)])
            (if result-type
                (values (make-if-expr tagged-test tagged-then tagged-else)
                        result-type)
                (error 'elab-if-expr
                       "both branches must have same type; got ~a and ~a"
                       (type->sexpr then-type)
                       (type->sexpr else-type))))))))
    )
