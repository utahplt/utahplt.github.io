;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;
;; reduction.ss
;; Richard Cobbe and David Goldberg
;;
;; Contains the definition of Betajava for the PLT Reduction
;; Semantics tool.
;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(module reduction mzscheme

  (require (lib "reduction-semantics.ss" "reduction-semantics")
           (lib "subst.ss" "reduction-semantics")
           (lib "match.ss")
           (lib "list.ss")
           "ast.ss"
           "program.ss")
  
  (provide aj-syntax aj-reductions/program with-program)
  
  ;; Tagging those objects that are values (i.e., using new-v instead of new)
  ;; is necessary to ensure a deterministic parse.  Otherwise,
  ;;    (new x 3 4 5)
  ;; can be parsed as (new class-name value ...) and as (new class-name expr
  ;; ...) which produces some nondeterminism in the reductions.  So far as I
  ;; can tell, this non-determinism is harmless, in that all of the multiple
  ;; results are equal, but it's just simpler (especially for the proofs!) not
  ;; to bother with it.  Does make the reduction rules slightly more
  ;; complicated, though.

  (define aj-syntax
    (language [ID (variable-except class new-v new new null super this cast
                                   true false if int bool Object + - * == and
                                   or zero? null? not beta inner)]
              [class-name Object ID]
              [binop + - * == and or]
              [unop zero? null? not]

              [instance (new-v class-name value ...)]

              [value null
                     true
                     false
                     number
                     instance]

              [expr value
                    (new class-name expr ...)
                    ID
                    this
                    null
                    (ivar expr class-name ID)
                    (send expr ID expr ...)
                    (super expr class-name ID expr ...)
		    (inner expr class-name ID expr expr ...)
                    (cast class-name expr)
                    (binop expr expr)
                    (unop expr)
                    (if expr expr expr)]

              [context hole
                       (new class-name value ... context expr ...)
                       (ivar context class-name ID)
                       (send context ID expr ...)
                       (send value ID value ... context expr ...)
                       (super value class-name ID value ... context expr ...)
		       (inner value class-name ID expr value ... context expr ...)
                       (cast class-name context)
                       (binop context expr)
                       (binop value context)
                       (unop context)
                       (if context expr expr)]))

  (define aj-reductions/program
    (lambda (program)
      (list
       ;; P |- E[new v1 ... vN] -->
     (reduction/context aj-syntax
                        context
                        (new (name class class-name) (name fields value) ...)
                        `(new-v ,(term class) ,@(term (fields ...))))
     ;; P |- E[object : c'.fd] -->
     (reduction/context aj-syntax
                        context
                        (ivar (name obj instance) (name class class-name)
                              (name field ID))
                        (field-lookup program (term obj) (term class) (term field)))
     ;; P |- E[null : c'.fd] -->
     (reduction aj-syntax
                (in-hole context (ivar null class-name ID))
                '(error dereferenced null))
     ;; P |- E[obj.md(v1 ... vN)] -->
     (reduction/context aj-syntax
                        context
                        (send (name obj instance) (name method ID)
                              (name args value) ...)
                        (let ([method (method-lookup program (term obj) (term method))])
                          (subst-args (method-body method)
                                      (cons (term obj) (term (args ...)))
                                      (cons 'this (method-arg-names method)))))
     ;; P |- E[null.md(v1 ... vN)] -->
     (reduction aj-syntax
                (in-hole context (send null ID value ...))
                '(error dereferenced null))

     ;; P |- E[super == obj : c . md(v1 ... vN)] -->
     (reduction/context aj-syntax
                        context
                        (super (name obj instance)
                               (name class Class-Name)
                               (name dmethod ID)
                               (name args value) ...)
                        (let (
                               [amethod (get-method program
                                                  (make-class-type (term class))
                                                  (term dmethod)
						  (lambda ()
						    (error 'reduce-super
							   "internal error: no method ~a in class ~a"
							   (term dmethod)
							   (term class))))])
                          (subst-args (method-body amethod)
                                      (cons (term obj) (term (args ...)))
                                      (cons 'this (method-arg-names amethod)))))

     ;; P |- E[inner == obj, c, md : inner(e1, v1 ... vN)]
     (reduction/context aj-syntax
			context
			(inner (name obj instance)
			       (name class Class-Name)
			       (name method ID)
			       (name elseexpr expr)
			       (name args value) ...)
			(let ([nm (next-beta program
					     (make-class-type (term class))
					     (obj->type (term obj))
					     (term method))])
			  (if nm
			      (subst-args (method-body nm)
					  (cons (term obj) (term (args ...)))
					  (cons 'this (method-arg-names nm)))
			      
			      (term elseexpr))))
				    
     ;; P |- E[cast t obj] -->
     (reduction aj-syntax
                (in-hole (name c context)
                         (cast (name type class-name)
                               (name obj instance)))
                (if (type<=? program (obj->type (term obj)) (make-class-type (term type)))
                    (replace (term c) (term hole) (term obj))
                    '(error bad cast)))

     ;; P |- E[cast t null] ->
     (reduction/context aj-syntax
                        context
                        (cast class-name null)
                        'null)

     ;; P |- E[v1 + v2] -->
     (reduction/context aj-syntax
                        context
                        (+ (name v1 number) (name v2 number))
                        (+ (term v1) (term v2)))

     ;; P |- E[v1 - v2] -->
     (reduction/context aj-syntax
                        context
                        (- (name v1 number) (name v2 number))
                        (- (term v1) (term v2)))

     ;; P |- E[v1 * v2] -->
     (reduction/context aj-syntax
                        context
                        (* (name v1 number) (name v2 number))
                        (* (term v1) (term v2)))

     ;; P |- E[zero? v] -->
     (reduction/context aj-syntax
                        context
                        (zero? (name arg number))
                        (bool->r (zero? (term arg))))

     ;; P |- E[v1 == v2] -->
     (reduction/context aj-syntax
                        context
                        (== (name v1 number) (name v2 number))
                        (bool->r (= (term v1) (term v2))))

     ;; P |- E[v1 and v2] -->
     (reduction/context aj-syntax
                        context
                        (and (name v1 value) (name v2 value))
                        (bool->r (and (eq? (term v1) 'true) (eq? (term v2) 'true))))

     ;; P |- E[v1 or v2] -->
     (reduction/context aj-syntax
                        context
                        (or (name v1 value) (name v2 value))
                        (bool->r (or (eq? (term v1) 'true) (eq? (term v2) 'true))))

     ;; P |- E[not v] -->
     (reduction/context aj-syntax
                        context
                        (not (name v value))
                        (bool->r (eq? (term v) 'false)))

     ;; P |- E[null? null] -->
     (reduction/context aj-syntax
                        context
                        (null? null)
                        'true)

     ;; P |- E[null? obj] -->
     (reduction/context aj-syntax
                        context
                        (null? instance)
                        'false)

     ;; P |- E[if true e1 e2] -->
     (reduction/context aj-syntax
                        context
                        (if true (name thn expr) expr)
                        (term thn))

     ;; P |- E[if false e1 e2] -->
     (reduction/context aj-syntax
                        context
                        (if false expr (name els expr))
                        (term els))
     )))

  ;; bool->r :: Boolean -> (Union 'true 'false)
  (define bool->r
    (lambda (b)
      (if b 'true 'false)))

  ;; Value ::= Number | 'true | 'false | 'null | Object
  ;; Object ::= (cons 'new-v (cons Class-Name (Listof Value)))

  ;; Reduction-Expr ::= Value
  ;;                  | (cons 'new (cons Class-Name (Listof R-Expr)))
  ;;                  | ID
  ;;                  | 'this
  ;;                  | (list 'ivar R-Expr Class-Name ID)
  ;;                  | (cons 'send (cons R-Expr (cons ID (Listof R-Expr))))
  ;;                  | (list 'cast Class-Name R-Expr)
  ;;                  | (Binary-Prim R-Expr R-Expr)
  ;;                  | (Unary-Prim R-Expr)
  ;;                  | (list 'if R-Expr R-Expr R-Expr)

  ;; exp->r :: Tagged-Expr -> R-Expr
  (define exp->r
    (match-lambda
      [($ new type args) `(new ,(type->r type) ,@(map exp->r args))]
      [($ var-ref var) var]
      [($ nil) 'null]
      [($ tagged-field-ref obj type field)
       `(ivar ,(exp->r obj) ,(type->r type) ,field)]
      [($ method-call obj method args)
       `(send ,(exp->r obj) ,method ,@(map exp->r args))]
      [($ tagged-super-call type method args)
       `(super this ,(type->r type) ,method ,@(map exp->r args))]
      [($ tagged-inner-call elseexp type method args)
       `(inner this ,(type->r type) ,method ,(exp->r elseexp) ,@(map exp->r args))]
      [($ cast type obj)
       `(cast ,(type->r type) ,(exp->r obj))]
      [($ num-lit val) val]
      [($ bool-lit val) (bool->r val)]
      [($ unary-prim rator rand) `(,rator ,(exp->r rand))]
      [($ binary-prim rator rand1 rand2)
       `(,rator ,(exp->r rand1) ,(exp->r rand2))]
      [($ if-expr t thn els) `(if ,(exp->r t) ,(exp->r thn) ,(exp->r els))]))

  ;; type->r :: Type -> (Union 'int 'bool Class-Name)
  (define type->r
    (match-lambda
      [($ ground-type name) name]
      [($ class-type name) name]
      [($ any-type) (error 'type-r "can't convert _|_")]))

  ;; field-lookup :: Program[Tagged] Object Class-Name Field-Name -> Value
  ;; Returns the value of the named field within the given object, viewed
  ;; as an instance of the specified class.
  (define field-lookup
    (lambda (prog obj class field)
      (let* ([type (make-class-type class)]
             [fields (get-tagged-fields prog type)]
             [field (get-tagged-field prog type field)])
        (list-ref obj (+ 2 (index-of field fields))))))

  ;; index-of :: X (Listof X) -> (Union N #f)
  ;; returns zero-based index of elt within l; comparisons by equal? .
  ;; Returns #f if not found.
  (define index-of
    (lambda (elt l)
      (let loop ([l l] [acc 0])
        (cond
         [(null? l) #f]
         [(equal? elt (car l)) acc]
         [else (loop (cdr l) (+ 1 acc))]))))

  ;; method-lookup :: Program[Tagged] Object Method-Name -> Method
  (define method-lookup
    (lambda (prog obj method)
      (find-method prog (obj->type obj) method)))

  ;; obj->type :: Object -> Type[Class]
  ;; returns the (dynamic) type of the object
  (define obj->type
    (lambda (obj)
      (make-class-type (cadr obj))))

  ;; aj-subst :: Symbol R-Expr R-Expr -> R-Expr
  ;; replaces free occurrences of Sym in second RExpr with first RExpr.
  (define aj-subst
    (subst
     [(? number?) (constant)]
     ['true (constant)]
     ['false (constant)]
     ['null (constant)]
     [('new-v type args ...) (constant)]
     [('new type args ...)
      (all-vars null)
      (build (lambda (vars . args) `(new ,type ,@args)))
      (subterms null args)]
     [(? id?) (variable)]
     ['this (variable)]
     [('ivar obj type field)
      (all-vars null)
      (build (lambda (vars obj) `(ivar ,obj ,type ,field)))
      (subterm null obj)]
     [('send obj method args ...)
      (all-vars null)
      (build (lambda (vars obj . args) `(send ,obj ,method ,@args)))
      (subterm null obj)
      (subterms null args)]
     [('super obj class-name method args ...)
      (all-vars null)
      (build (lambda (vars obj . args) `(super ,obj ,class-name ,method ,@args)))
      (subterm null obj)
      (subterms null args)]
     [('inner obj class-name method elseexpr args ...)
      (all-vars null)
      (build (lambda (vars obj elseexpr . args) `(inner ,obj ,class-name ,method ,elseexpr ,@args)))
      (subterm null obj)
      (subterm null elseexpr)
      (subterms null args)]
     [('cast type obj)
      (all-vars null)
      (build (lambda (vars obj) `(cast ,type ,obj)))
      (subterm null obj)]
     [((? binary-prim-name? prim) rand1 rand2)
      (all-vars null)
      (build (lambda (vars rand1 rand2) `(,prim ,rand1 ,rand2)))
      (subterm null rand1)
      (subterm null rand2)]
     [((? unary-prim-name? prim) rand)
      (all-vars null)
      (build (lambda (vars rand) `(,prim ,rand)))
      (subterm null rand)]
     [('if tst thn els)
      (all-vars null)
      (build (lambda (vars tst thn els) `(if ,tst ,thn ,els)))
      (subterm null tst)
      (subterm null thn)
      (subterm null els)]))

  ;; subst-args :: Tagged-Expr (Listof Value) (Listof ID) -> R-Expr
  (define subst-args
    (lambda (expr vals ids)
      ;(printf "subst-args: expr ~a~nvals ~a~nids ~a~n" expr vals ids)
      (foldl aj-subst (exp->r expr) ids vals)))
  )
