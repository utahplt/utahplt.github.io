;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;
;; betajava.ss
;; David Goldberg
;;
;; Provides the language and reductions for the BetaJava language for
;; use with various reduction semantics functions. Since reductions
;; depend on an elaborated program, they are provided as a function
;; that takes a program.
;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(module betajava mzscheme
  
  (require "reduction.ss"
           "elaboration.ss"
           "parser.ss")
  
  (provide betajava-syntax
           betajava-reductions/program
           betajava-reductions-expr/program)
  
  ;; Betajava language
  (define betajava-syntax aj-syntax)
  
  ;; Sexpr -> (listof red?)
  ;; Produces BetaJava reductions for the given program
  (define (betajava-reductions/program prog)
    (aj-reductions/program (elaborate-program (parse-program prog))))
  
  ;; Sexpr -> (values (listof red?) Sexpr)
  ;; Produces BetaJava reductions and the program's expression part
  (define (betajava-reductions-expr/program prog)
    (let ([expr (cadr prog)])
      (values (aj-reductions/program (elaborate-program (parse-program prog))) expr)))
  
  )