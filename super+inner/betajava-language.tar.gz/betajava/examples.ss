(require "betajava.ss"
         (lib "gui.ss" "reduction-semantics"))

;; Calls the plt-reducer gui tracer on a betajava program
(define (trace-betajava prog)
  (let-values ([(reds expr) (betajava-reductions-expr/program prog)])
    (traces betajava-syntax reds expr)))

;; Allows easily making a program bassed on test-program-definitions
(define (make-prog class-name constructor-args method-name method-args)
  (list test-program-definitions `(send (new ,class-name ,@constructor-args) ,method-name ,@method-args)))

(define test-program-definitions
  '((class base object
         ((int a)
          (int b))
         ((int m () 42)
          (int m2 () 17)))
       (class derived base
         ((bool a)
          (int c))
         ((int m () 23)))
       (class derivedsuper base
         ()
         ((int m () (+ 1 (super m)))))
       (class derivedbeta base
         ()
         ((int beta m () 21)))
       (class top Object
         ()
         ((int beta printplus () 1)))
       (class javaunder top
         ()
         ((int printplus () 2)))
       (class betaunder top
         ()
         ((int beta printplus () 3)))
       (class innertop Object
         ()
         ((int beta printplus ((int a)) (+ a (inner 1 a)))))
       (class nextjava innertop
         ()
         ((int printplus ((int a)) (+ a 2))))
       (class nextbeta nextjava
         ()
         ((int beta printplus ((int a)) (+ a (inner 3 a)))))
       ))

(define inherited-test (make-prog 'derived '(1 2 false 3) 'm2 null))
(define overridden-test (make-prog 'base '(1 2) 'm null))
(define overriding-test (make-prog 'derived '(1 2 false 3) 'm null))
(define overriding-beta-test (make-prog 'derivedbeta '(1 2) 'm null))
(define beta-over-java-test (make-prog 'javaunder null 'printplus null))
(define beta-over-beta-test (make-prog 'betaunder null 'printplus null))
(define forty-three-test (make-prog 'derivedsuper '(3 3) 'm null))
(define innertop-test (make-prog 'innertop null 'printplus '(1)))
(define nextjava-test (make-prog 'nextjava null 'printplus '(1)))
(define nextbeta-test (make-prog 'nextbeta null 'printplus '(1)))


