;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;
;; parser.ss
;; Richard Cobbe and David Goldberg
;;
;; Implements the parser for the S-Expression based source syntax for
;; BetaJava.
;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(module parser mzscheme

  (require (lib "list.ss")
           (lib "match.ss")
           "ast.ss"
           "program.ss")
  
  (provide parse-program)

  ;;  SOURCE LANGUAGE:

  ;;  reserved ::= class | new-v | new | null | super | this | cast | true |
  ;;             | false | if | int | bool | Object | <binary-prim> |
  ;;             | <unary-prim> | beta | inner

  ;;  binary-prim ::= + | - | * | == | and | or

  ;;  unary-prim ::= zero? | null? | not

  ;;  id ::= any symbol except a <reserved>

  ;;  defn-name ::= <id>

  ;;  class-name ::= <defn-name> | Object

  ;;  type-name ::= <class-name> | int | bool

  ;;  field-name ::= <id>

  ;;  method-name ::= <id>

  ;;  arg-name ::= <id>

  ;;  program ::= ( ( <defn>* ) <expr> )

  ;;  defn ::= ( class <defn-name> <class-name> ( <field>* ) ( <method>* ) )

  ;;  field ::= ( <type-name> <field-name> )

  ;;  method ::= ( <type-name> [beta] <method-name> ( <arg>* ) <expr> )

  ;;  arg ::= ( <type-name> <arg-name> )

  ;;  expr ::= ( new <class-name> <expr>* )
  ;;         | <id>
  ;;         | this
  ;;         | null
  ;;         | ( ivar <expr> <field-name> )
  ;;         | ( send <expr> <method-name> <expr>* )
  ;;         | ( super <method-name> <expr>* )
  ;;         | ( inner <expr> <expr>* )
  ;;         | ( cast <class-name> <expr> )
  ;;         | <integer literal>
  ;;         | true
  ;;         | false
  ;;         | ( <binary-prim> <expr> <expr> )
  ;;         | ( <unary-prim> <expr> )
  ;;         | ( if <expr> <expr> <expr> )

  (define make-initial-index
    (lambda ()
      (let ([index (make-hash-table)])
        (hash-table-put! index
                         'Object
                         (make-src-class 'Object null null null))
        index)))

  ;; parse-program :: Sexpr -> Program[Src]
  (define parse-program
    (match-lambda
      [((defns ...) main)
       (let ([program (make-initial-src-program (parse-expr main))])
         (for-each
          (lambda (defn)
            (call-with-values
             (lambda () (parse-defn defn))
             (lambda (class supertype)
               (src-program-add-class! program class supertype))))
          defns)
         program)]
      [bogus (error 'parse-program "invalid program structure: ~a" bogus)]))

  ;; parse-defn :: SExpr -> Class[Src] Type[Class]
  (define parse-defn
    (match-lambda
      [('class (? defn-name? name)
         (? class-name? super)
         (fields ...)
         (methods ...))
       (values (make-src-class (parse-type name) null
                               (map parse-field fields)
                               (map parse-method methods))
               (make-class-type super))]
      [bogus (error 'parse-defn "bad class definition: ~a" bogus)]))

  ;; SExpr -> Field
  (define parse-field
    (match-lambda
      [((? type-name? type) (? field-name? name))
       (make-field (parse-type type) name)]
      [bogus (error 'parse-field "bad field defn: ~a" bogus)]))

  ;; SExpr -> (Method Src-Expr)
  (define parse-method
    (lambda (src)
      (match src
	[((? type-name? type)
          (? method-name? name)
          (args ...)
          body)
         (mmethod type #f name args body)]
        [((? type-name? type)
          (? (lambda (t) (eq? t 'beta)) beta)
          (? method-name? name)
          (args ...)
          body) 
         (mmethod type #t name args body)]
        [bogus (error 'parse-method "bad method defn: ~a" bogus)])))
  
  (define (mmethod type beta? name args body)
    (let-values ([(arg-types arg-names) (mv-map parse-arg args)])
		(make-method (parse-type type) beta?
			     name arg-names arg-types (parse-expr body))))
  (define parse-arg
    (match-lambda
      [((? type-name? type) (? arg-name? arg))
       (values (parse-type type) arg)]
      [bogus (error 'parse-arg
                    "bad argument declaration: ~a"
                    bogus)]))

  (define parse-expr
    (match-lambda
      [('new (? class-name? type) args ...)
       (make-new (parse-type type) (map parse-expr args))]
      ['this (make-var-ref 'this)]
      ['null (make-nil)]
      [(? id? var) (make-var-ref var)]
      [('ivar obj (? field-name? field))
       (make-field-ref (parse-expr obj) field)]
      [('send obj (? method-name? method) args ...)
       (make-method-call (parse-expr obj) method
                         (map parse-expr args))]
      [('super (? method-name? method) args ...)
       (make-super-call method (map parse-expr args))]
      [('inner elseexp args ...)
       (make-inner-call (parse-expr elseexp) (map parse-expr args))]
      [('cast (? class-name? type) obj)
       (make-cast (parse-type type) (parse-expr obj))]
      [(? integer? n) (make-num-lit n)]
      ['true (make-bool-lit #t)]
      ['false (make-bool-lit #f)]
      [((? binary-prim-name? prim) r1 r2)
       (make-binary-prim prim (parse-expr r1) (parse-expr r2))]
      [((? unary-prim-name? prim) rand)
       (make-unary-prim prim (parse-expr rand))]
      [('if test then else)
       (make-if-expr (parse-expr test) (parse-expr then) (parse-expr else))]
      [bogus (error 'parse-expr
                    "bad expression: ~a" bogus)]))

  (define parse-type
    (match-lambda
      ['int (make-ground-type 'int)]
      ['bool (make-ground-type 'bool)]
      [(? class-name? c) (make-class-type c)]
      [bogus (error 'parse-type "bogus type ~a" bogus)]))
  )