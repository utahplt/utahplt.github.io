;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;
;; ast.ss
;;
;; Defines the AST types used for the BetaJava system.
;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(module ast mzscheme

  #| ID ::= any symbol except 'class 'new 'new-v 'null 'super 'this 'cast '+ '-
                '* 'zero? '== 'null? 'true 'false 'and 'or 'not 'if 'int 'bool
                'Object 'beta 'inner

     Class-Name ::= ID | 'Object
     Defn-Name ::= ID
     Type-Name ::= Class-Name | 'int | 'bool
     Method-Name ::= ID
     Field-Name ::= ID
     Arg-Name ::= ID

     Unary-Prim ::= 'zero? | 'null? | 'not
     Binary-Prim ::= '+ '- '* 'and 'or '=
  |#

  (define old-inspector (current-inspector))
  (current-inspector (make-inspector))

  (define BINARY-PRIMS '(+ - * == and or))
  (define UNARY-PRIMS '(zero? null? not))
  (define RESERVED-WORDS '(class new-v new null super this cast
                            true false if beta inner int bool Object))

  (define reserved?
    (lambda (x)
      (or (memq x RESERVED-WORDS)
          (binary-prim-name? x)
          (unary-prim-name? x))))

  (define binary-prim-name? (lambda (x) (memq x BINARY-PRIMS)))
  (define unary-prim-name? (lambda (x) (memq x UNARY-PRIMS)))

  (define id? (lambda (x) (and (symbol? x) (not (reserved? x)))))

  (define type-name?
    (lambda (x)
      (or (eq? x 'int)
          (eq? x 'bool)
          (class-name? x))))

  (define field-name? id?)
  (define method-name? id?)

  (define defn-name? id?)
  (define class-name?
    (lambda (x)
      (or (eq? x 'Object) (defn-name? x))))

  (define arg-name? id?)

  (define-struct src-class (name subclasses fields methods))
  (define-struct tagged-class (name superclass fields methods))
  ;; Class ::= (make-src-class Type[Class] (Listof Class[Src]) (Listof Field)
  ;;                           (Listof (Method Src-Expr)))
  ;;         | (make-tagged-class Type[Class] (Union Class[Tagged] #f)
  ;;                              (Listof Field) (Listof (Method Tagged-Expr)))

  (define-struct field (type name))
  ;; Field ::= (make-field Type Field-Name)

  (define-struct method (type beta? name arg-names arg-types body))
  ;; (Method X) ::= (make-method Type Method-Name
  ;;                             (Listof Arg-Name) (Listof Type) X)

  (define-struct expr ())
  (define-struct (new expr) (type args))
  (define-struct (var-ref expr) (var))
  (define-struct (nil expr) ())
  (define-struct (field-ref expr) (object field))
  (define-struct (tagged-field-ref expr) (object type field))
  (define-struct (method-call expr) (object method args))
  (define-struct (super-call expr) (method args))
  (define-struct (tagged-super-call expr) (type method args))
  (define-struct (inner-call expr) (elseexp args))
  (define-struct (tagged-inner-call expr) (elseexp type method args))
  (define-struct (cast expr) (type object))
  (define-struct (num-lit expr) (val))
  (define-struct (bool-lit expr) (val))
  (define-struct (unary-prim expr) (rator rand))
  (define-struct (binary-prim expr) (rator rand1 rand2))
  (define-struct (if-expr expr) (test then else))
  ;; Src-Expr ::= (make-new Type[Class] (Listof Src-Expr))
  ;;            | (make-var-ref Arg-Name)
  ;;            | (make-nil)
  ;;            | (make-field-ref Src-Expr Field-Name)
  ;;            | (make-method-call Src-Expr Method-Name (Listof Src-Expr))
  ;;            | (make-super-call Method-Name (Listof Src-Expr))
  ;;            | (make-inner-call Src-Expr (Listof Src-Expr))
  ;;            | (make-cast Type[Class] Src-Expr)
  ;;            | (make-num-lit Integer)
  ;;            | (make-bool-lit Boolean)
  ;;            | (make-unary-prim Unary-Prim Src-Expr)
  ;;            | (make-binary-prim Binary-Prim Src-Expr Src-Expr)
  ;;            | (make-if-expr Src-Expr Src-Expr Src-Expr)

  ;; Tagged-Expr ::= (make-new Type[Class] (Listof Tagged-Expr))
  ;;               | (make-var-ref Arg-Name)
  ;;               | (make-nil)
  ;;               | (make-tagged-field-ref Tagged-Expr Typed[Class]
  ;;                                        Field-Name)
  ;;               | (make-method-call Tagged-Expr Method-Name
  ;;                                   (Listof Tagged-Expr))
  ;;               | (make-tagged-super-call Type[Class] Method-Name
  ;;                                         (Listof Tagged-Expr))
  ;;               | (make-tagged-inner-call Tagged-Expr  Type[Class] 
  ;;                                         Method-Name (Listof Tagged-Expr)
  ;;               | (make-cast Type[Class] Tagged-Expr)
  ;;               | (make-num-lit Integer)
  ;;               | (make-bool-lit Boolean)
  ;;               | (make-unary-prim Unary-Prim Tagged-Expr)
  ;;               | (make-binary-prim Binary-Prim Tagged-Expr Tagged-Expr)
  ;;               | (make-if-expr Tagged-Expr Tagged-Expr Tagged-Expr)

  (define-struct type ())
  (define-struct (ground-type type) (name))
  (define-struct (class-type type) (name))
  (define-struct (any-type type) ())
  ;; Type ::= (make-ground-type (Union 'int 'bool))
  ;;        | (make-class-type Class-Name)
  ;;        | (make-any-type)

  (define (type->sexpr type)
    (cond
     [(ground-type? type) (ground-type-name type)]
     [(class-type? type) (class-type-name type)]
     [(any-type? type) '_!_]))

  (define-struct tagged-field (class type name))
  ;; Tagged-Field ::= (make-tagged-field Type[Class] Type Field-Name)

  (current-inspector old-inspector)

  (provide reserved?
           binary-prim-name?
           unary-prim-name?
           id?
           type-name?
           field-name?
           method-name?
           defn-name?
           class-name?
           arg-name?

   (struct src-class (name subclasses fields methods))
           (struct tagged-class (name superclass fields methods))

           (struct field (type name))
           (struct method (type beta? name arg-names arg-types body))

           expr?
           (struct new (type args))
           (struct var-ref (var))
           (struct nil ())
           (struct field-ref (object field))
           (struct tagged-field-ref (object type field))
           (struct method-call (object method args))
           (struct super-call (method args))
	   (struct inner-call (elseexp args))
           (struct tagged-super-call (type method args))
	   (struct tagged-inner-call (elseexp type method args))
           (struct cast (type object))
           (struct num-lit (val))
           (struct bool-lit (val))
           (struct unary-prim (rator rand))
           (struct binary-prim (rator rand1 rand2))
           (struct if-expr (test then else))

           (struct tagged-field (class type name))

           type?
           (struct ground-type (name))
           (struct class-type (name))
           (struct any-type ())
           type->sexpr))
