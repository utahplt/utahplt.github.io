;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;
;; environment.ss
;; Richard Cobbe
;;
;; Functions that define a standard environment data type.
;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(module environment mzscheme

  ;; env?           :: Any -> Bool
  ;; make-empty-env :: () -> (Env X)
  ;; lookup         :: (Env X) Symbol (() -> Y) -> (union X Y)
  ;; extend-env     :: (Env X) (listof Symbol) (listof X) -> (Env X)
  ;; env->alist     :: (Env X) -> (Listof (List Symbol X))

  (require (lib "contract.ss"))

  (define old-inspector (current-inspector))
  (current-inspector (make-inspector))

  (define-struct env ())
  (define-struct (empty-env env) ())
  (define-struct (rib-env env) (env ids bindings))
  ;; (Env X) ::= (make-empty-env)
  ;;           | (make-rib-env (Env X) (listof Symbol) (listof X))

  (current-inspector old-inspector)

  (define extend-env
    (lambda (env syms bindings)
      (unless (= (length syms) (length bindings))
        (raise (make-exn:application:mismatch
                "extend-env: IDs and bindings must have same length"
                (current-continuation-marks)
                bindings)))
      (make-rib-env env syms bindings)))

  (define (lookup env id fk)
    (unless (env? env)
      (error 'lookup "bad first arg: ~a" env))
    (let outer-loop ([env env])
      (if (empty-env? env)
          (fk)
          (let inner-loop ([ids (rib-env-ids env)]
                           [bindings (rib-env-bindings env)])
            (cond
              [(null? ids) (outer-loop (rib-env-env env))]
              [(eq? (car ids) id) (car bindings)]
              [else (inner-loop (cdr ids) (cdr bindings))])))))

  (define env->alist
    (lambda (env)
      (cond
       [(empty-env? env) null]
       [else (append (map list (rib-env-ids env) (rib-env-bindings env))
                     (env->alist (rib-env-env env)))])))

  (provide env?)

  (provide/contract #;(env? (-> any? boolean?))
                    (make-empty-env (-> env?))
                    (lookup (-> any? symbol? (-> any) any))
                    (extend-env (-> env? (listof symbol?) list? env?))
                    (env->alist (-> env? (listof (cons/p symbol? any?))))))
