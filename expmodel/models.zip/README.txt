This directory contains implementations of the models in

 Macros that Work Together
 Flatt, Culpepper, and Findler

to run PLT Redex version 4.2.0.6 or later.

The models sources are

  mm-runtime.ss --- section 3.2
  mm-parse2.ss --- section 3.3
  mm-defmacro.ss --- section 3.4
  mm-stxcase.ss --- section 3.5
  mm-local.ss --- section 3.6
  mm-defs.ss --- section 3.7

Except for the first, each contains a number of examples bound with
`define-example'. Run the file in DrScheme, then for an example like
`simple-parse-example', run it in one of the following ways using the
DrScheme interactions window:

 * (simple-parse-example 'expand) --- produces the expansion result
 * (simple-parse-example 'parse) --- parses the expansion to an ast
 * (simple-parse-example 'step) --- steps through an expansion
 * (simple-parse-example traces) --- shows a trace of expansion


The full model (i.e., "mm-defs.ss") is available in typeset form at

  http://www.cs.utah.edu/plt/expmodel/
