#lang scheme
(require redex
         "rewrites.ss"
         "define-example.ss"
         slideshow/pict)

(define-language mini
  
  ;; Executable AST and values:
  [ast var (App ast ast ...) val]
  [val (Fun var ast) atom
       (List val ...) stx]

  ;; Evaluation context in AST:
  [E hole      (App val ... E ast ...)]
  
  ;; Syntax objects (a subset of values):
  [stx (Stx atom ctx)
       (Stx (List stx ...) ctx)]
  [id (Stx sym ctx)]
  [pre-ctx • (Rename ctx id var)]
  [ctx • (Rename ctx id var) (Mark ctx mrk)]
       
  ;; Literal values:
  [atom sym prim desc-other-atom] ; `desc-other-atom' typesets as "...."
  [desc-other-atom number]
  [sym (Sym var)]
  [prim SE MKS desc-other-prim] ; `desc-other-prim' typesets as "...."
  [desc-other-prim + - CONS CAR CDR LIST]

  ;; Expansion operates on a mixture, where
  ;; `Exp' and `Eval' separate to-be-expanded
  ;; syntax (inside) from already-expanded
  ;; syntax (outside):
  [mixture (Exp stx env)
           (Eval ast env mode)
           (Stx (List stx ... mixture ...) ctx)]
  
  ;; Expansion context:
  [F hole
     (Stx (List stx ... F (Exp stx env) ...) ctx)]
  
  ;; Expand-time environment:
  [env desc-env] ; `desc-env' typesets as prose
  [desc-env ((var transformer) ...)]
  [transformer TFun TLet-Syntax TQuote
               (TVar id) val]
  
  ;; When expansion goes to expand-time evaluation,
  ;; the mode says how to resume expansion with the
  ;; macro result:
  [mode (InExp mrk)
        (InBind id stx)]
  
  ;; Use variables for vars, addrs, and marks
  [(var mrk) desc-name] ; `desc-name' typesets as prose
  [desc-name variable-not-otherwise-mentioned])

;; ----------------------------------------
;; Non-capturing substitution for AST:

(define-metafunction mini
  subst : ast var ast -> ast
  [(subst var var ast_v) ast_v]
  [(subst var_2 var ast_v) var_2]
  [(subst (App ast ...) var ast_v)
   (App (subst ast var ast_v) ...)]
  [(subst (Fun var ast) var ast_v)
   (Fun var ast)]
  [(subst (Fun var_2 ast) var ast_v)
   (Fun var_3 (subst (subst ast var_2 var_3) var ast_v))
   (where var_3 ,(variable-not-in (term ast_v) (term var_2)))]
  [(subst atom var ast_v) atom]
  [(subst (List val ...) var ast_v) 
   (List (subst val var ast_v) ...)]
  [(subst stx var ast_v) stx])

;; ----------------------------------------
;; Generic metafunctions that typeset as set operations:

(define-metafunction mini
  [(is-in? any_1 ()) #f]
  [(is-in? any_1 (any_1 any_2 ...)) #t]
  [(is-in? any_1 (any_2 any_3 ...)) (is-in? any_1 (any_3 ...))])

(define-metafunction mini
  [(emptyset) ()])

(define-metafunction mini
  [(add-elem any_1 any_2) (any_1 . any_2)])

(define-metafunction mini
  [(same? any_1 any_2) ,(equal? (term any_1) (term any_2))])

;; ----------------------------------------
;; Implementation of primitives:

(define-metafunction mini
  [(plus number_1 number_2) ,(+ (term number_1) (term number_2))])
(define-metafunction mini
  [(minus number_1 number_2) ,(+ (term number_1) (term number_2))])

(define-metafunction mini
  δ/stx : prim (val ...) -> val
  [(δ/stx SE ((Stx val ctx))) val]
  [(δ/stx MKS (atom (Stx val ctx))) (Stx atom ctx)]
  [(δ/stx MKS ((List stx ...) (Stx val ctx))) (Stx (List stx ...) ctx)])

(define-metafunction/extension δ/stx mini
  δ : prim (val ...) -> val
  [(δ + (number_1 number_2)) (plus number_1 number_2)]
  [(δ - (number_1 number_2)) (minus number_1 number_2)]
  [(δ CONS (val_1 (List val_2 ...))) (List val_1 val_2 ...)]
  [(δ CAR ((List val_1 val_2 ...))) val_1]
  [(δ CDR ((List val_1 val_2 ...))) (List val_2 ...)]
  [(δ LIST (val ...)) (List val ...)])

;; ----------------------------------------
;; Evaluating AST:

(define ->
  (reduction-relation 
   mini #:domain ast
   (--> (in-hole E (App (Fun var ast) val))
        (in-hole E (subst ast var val)))
   (--> (in-hole E (App prim val ...))
        (in-hole E (δ prim (val ...))))))

;; ----------------------------------------
;; Syntax-object operations:

(define-metafunction mini
  ;; Adds or cancels a mark
  addremove : mrk (mrk ...) -> (mrk ...)
  [(addremove mrk_1 (mrk_1 mrk_2 ...)) (mrk_2 ...)]
  [(addremove mrk_1 (mrk_2 ...)) (mrk_1 mrk_2 ...)])

(define-metafunction mini
  ;; Extracts all marks in order, removing cancelling pairs
  marksof : id -> (mrk ...)
  [(marksof (Stx (Sym var) •)) ()]
  [(marksof (Stx (Sym var) (Mark ctx mrk)))
   (addremove mrk (mrk_2 ...))
   (where (mrk_2 ...) (marksof (Stx (Sym var) ctx)))]
  [(marksof (Stx (Sym var) (Rename ctx id var_2))) (marksof (Stx (Sym var) ctx))])

(define-metafunction mini
  ;; Resolves an identifier to a variable; this is the heart of
  ;;  the syntax-object support for lexical scope
  resolve : id -> var
  [(resolve (Stx (Sym var) •)) var]
  [(resolve (Stx (Sym var) (Mark ctx mrk)))
   (resolve (Stx (Sym var) ctx))]
  [(resolve (Stx (Sym var) (Rename ctx id var_new)))
   var_new
   (where var_1 (resolve id))
   (where var_2 (resolve (Stx (Sym var) ctx)))
   (side-condition (term (same? var_1 var_2)))
   (side-condition (term (same? (marksof id) (marksof (Stx (Sym var) ctx)))))]
  [(resolve (Stx (Sym var) (Rename ctx id var_2)))
   (resolve (Stx (Sym var) ctx))])

(define-metafunction mini
  rename : stx id var -> stx
  ;; Simply pushes `Rename's down through a syntax object
  [(rename (Stx atom ctx) id var) 
   (Stx atom (Rename ctx id var))]
  [(rename (Stx (List stx ...) ctx) id var) 
   (Stx (List (rename stx id var) ...) (Rename ctx id var))])

(define-metafunction mini
  mark : stx mrk -> stx
  ;; Simply pushes `Mark's down through a syntax object
  [(mark (Stx atom ctx) mrk) 
   (Stx atom (Mark ctx mrk))]
  [(mark (Stx (List stx ...) ctx) mrk) 
   (Stx (List (mark stx mrk) ...) (Mark ctx mrk))])

(define-metafunction mini
  strip : stx -> val
  ;; Recursively strips lexical context from a syntax object
  [(strip (Stx atom ctx))
   atom]
  [(strip (Stx (List stx ...) ctx)) 
   (List (strip stx) ...)])

;; ----------------------------------------
;; Simple parsing of already-expanded code
;;  (used for expand-time expressions, instead of
;;   modeling multiple phases):

(define-metafunction mini
  parse : stx -> ast
  [(parse (Stx (List id_lambda id_arg stx_body) ctx))
   (Fun (resolve id_arg) (parse stx_body))
   (where lambda (resolve id_lambda))]
  [(parse (Stx (List id_quote atom) ctx))
   atom
   (where quote (resolve id_quote))]
  [(parse (Stx (List id_quote stx) ctx))
   (strip stx)
   (where quote (resolve id_quote))]
  [(parse (Stx (List id_syntax stx) ctx))
   stx
   (where syntax (resolve id_syntax))]
  [(parse (Stx (List stx_rator stx_rand ...) ctx))
   (App (parse stx_rator) (parse stx_rand) ...)]
  [(parse id)
   (resolve id)])

;; ----------------------------------------
;; Expand-time environment operations:

(define-metafunction mini
  lookup : env var -> transformer
  [(lookup ((var transformer) any_2 ...) var) transformer]
  [(lookup (any_1 any_2 ...) var) (lookup (any_2 ...) var)])

(define-metafunction mini
  extend : env var transformer -> env
  [(extend env var transformer) ((var transformer) . env)])

(define-metafunction mini
  extend* : env ((var transformer) ...) -> env
  [(extend* env ((var transformer) ...)) ((var transformer) ... . env)])

;; ----------------------------------------
;; The expander reduction:

(define expand->
  (reduction-relation
   mini #:domain mixture

   ;; Parsing core forms:
   ;;  lambda
   (--> (in-hole F (Exp (Stx (List id_lam id_arg stx_body) ctx) env))
        (in-hole F (Stx (List id_lam id_new (Exp stx_newbody env_new)) ctx))
        (where TFun (lookup env (resolve id_lam)))                            
        (fresh var_new)
        (where id_new (rename id_arg id_arg var_new))
        (where stx_newbody (rename stx_body id_arg var_new))
        (where env_new (extend env var_new (TVar id_new)))
        "lambda")

   ;;  application
   (--> (in-hole F (Exp (Stx (List id_rator stx_arg ...) ctx) env))
        (in-hole F (Stx (List (Exp id_rator env) (Exp stx_arg env) ...) ctx))
        (where (TVar id_new) (lookup env (resolve id_rator)))
        "app-var")
   (--> (in-hole F (Exp (Stx (List (Stx (List stx_1 ...) ctx_1) stx_2 ...) ctx_2) env))
        (in-hole F (Stx (List (Exp (Stx (List stx_1 ...) ctx_1) env) (Exp stx_2 env) ...) ctx_2))
        "app-exp")
   
   ;;  reference
   (--> (in-hole F (Exp id env))
        (in-hole F id_new)
        (where (TVar id_new) (lookup env (resolve id)))
        "ref")
   
   ;;  quote & syntax
   (--> (in-hole F (Exp (Stx (List id_quote stx) ctx) env))
        (in-hole F (Stx (List id_quote stx) ctx))
        (where TQuote (lookup env (resolve id_quote)))
        "quote")
   
   ;; Macro creation and binding:
   (--> (in-hole F (Exp (Stx (List id_ls id_mac stx_rhs stx_body) ctx) env))
        (in-hole F (Eval (parse stx_rhs) env (InBind id_mac stx_body)))
        (where TLet-Syntax (lookup env (resolve id_ls)))
        "bind-start")
   (--> (in-hole F (Eval val env (InBind id_mac stx_body)))
        (in-hole F (Exp (rename stx_body id_mac var_new) (extend env var_new val)))
        (fresh var_new)
        "bind-done")

   ;; Macro invocation and result:
   (--> (in-hole F (Exp stx_macapp env))
        (in-hole F (Eval (App val stx_in) env (InExp mrk_new)))
        (where (Stx (List id_mac stx_arg ...) ctx) stx_macapp)
        (where val (lookup env (resolve id_mac)))
        (where stx_in (mark stx_macapp mrk_new))
        (fresh mrk_new)
        "app-macro")
   (--> (in-hole F (Eval stx_out env (InExp mrk_new)))
        (in-hole F (Exp (mark stx_out mrk_new) env))
        "macro-done")

   ;; Expand-time eval (same as `->' above, but nested in a mixture):
   (--> (in-hole F (Eval (in-hole E (App (Fun var ast) val)) env mode))
        (in-hole F (Eval (in-hole E (subst ast var val)) env mode))
        "eval-lam")
   (--> (in-hole F (Eval (in-hole E (App prim val_arg ...)) env mode))
        (in-hole F (Eval (in-hole E val_res) env mode))
        (where val_res (δ prim (val_arg ...)))
        "eval-prim")

   ))

;; ----------------------------------------
;; Helpers for writing examples:

(define-metafunction mini
  preamble-env : -> env
  [(preamble-env) ((lambda TFun)
                   (let-syntax TLet-Syntax)
                   (quote TQuote)
                   (syntax TQuote))])

;; ----------------------------------------
;; Examples:

(define-example-definer define-example
  mini 
  (lambda (t) (term (Exp ,t (preamble-env))))
  expand-> 
  parse)

(define-example simple-macro-example
  (let-syntax x (lambda z (syntax (quote 2))) (x 1)))

(define-example reftrans-macro-example
  (lambda z (let-syntax x (lambda s (syntax z)) (lambda z (x)))))

(define-example hyg-macro-example
  (lambda z (let-syntax x (lambda s 
                            ('MKS
                             ('LIST (syntax lambda)
                                    (syntax z)
                                    ('CAR ('CDR ('SE s))))
                             (syntax here)))
              (x z))))

(define-example thunk-example
  (let-syntax 
      thunk (lambda e
              ('MKS
               ('LIST (syntax lambda) 
                      (syntax a) 
                      ('CAR ('CDR ('SE e))))
               e))
    (((lambda a (thunk ('+ a '1))) '5) '0)))

;; ----------------------------------------
;; Typesetting:

(define (rules->pict)
  (with-rewrites
   (lambda ()
      (reduction-relation->pict expand-> #:style 'compact-vertical))))

(define (lang->pict)
  (with-rewrites
   (lambda ()
     (ht-append
      20
      (vl-append
       10
       (language->pict mini #:nts '(ast val atom sym prim))
       (language->pict mini #:nts '(stx id ctx))
       (language->pict mini #:nts '(env)))
      (vl-append
       10
       (language->pict mini #:nts '(E F))
       (language->pict mini #:nts '(mixture mode))
       (language->pict mini #:nts '(transformer))
       (language->pict mini #:nts '(var mrk)))))))

(define (metas->pict)
  (with-rewrites
   (lambda ()
     (vl-append
      10
      (vl-append (metafunction->pict δ/stx) (text "..." 'default (default-font-size)))
      (metafunction->pict parse)
      (metafunction->pict resolve)
      (metafunctions->pict mark rename)
      (metafunctions->pict marksof addremove)
      (metafunctions->pict strip)))))

(define (pre-ctx->pict)
  (with-rewrites
   (lambda ()
     (language->pict mini #:nts '(pre-ctx)))))

(define (ctx->pict)
  (with-rewrites
   (lambda ()
     (language->pict mini #:nts '(ctx)))))

(define (resolve->pict)
  (with-rewrites
   (lambda ()
     (metafunction->pict resolve))))

(define (marksof->pict)
  (with-rewrites
   (lambda ()
     (metafunctions->pict marksof addremove))))

(define (lambda-rules->pict)
  (with-rewrites
   (lambda ()
     (parameterize ([render-reduction-relation-rules '("lambda")])
       (reduction-relation->pict expand-> #:style 'compact-vertical)))))

(define (ls-rules->pict)
  (with-rewrites
   (lambda ()
     (parameterize ([render-reduction-relation-rules '("bind-done")])
       (reduction-relation->pict expand-> #:style 'compact-vertical)))))

(define (macro-rules->pict)
  (with-rewrites
   (lambda ()
     (parameterize ([render-reduction-relation-rules '("app-macro" "macro-done")])
       (reduction-relation->pict expand-> #:style 'compact-vertical)))))

(define (mark->pict)
  (with-rewrites
   (lambda ()
     (parameterize ([linebreaks '(#f #t)])
       (metafunction->pict mark)))))

(define (rename->pict)
  (with-rewrites
   (lambda ()
     (parameterize ([linebreaks '(#t #t)])
       (metafunction->pict rename)))))

(define (reftrans-example->pict)
  (with-rewrites
   (lambda ()
     (let-syntax ([step (syntax-rules ()
                          [(_ e) (lw->pict mini (to-lw e))])])
       (append-steps
        (step (Exp (lambda a (thunk ('+ a '1))) env_0))
        (step (lambda a2 (Exp (thunk ('+ a2 '1)) env_1 = (extend env_0 a2 TVar))))
        (step-... "calling the" (step thunk) "transformer")
        (step (lambda a2 (Exp (lambda a ('+ a2 '1)) env_1)))
        (step (lambda a2 (lambda a3 (Exp ('+ a2 '1) (extend env_1 a3 TVar)))))
        (step-... "expanding the body")
        (step (lambda a2 (lambda a3 ('+ a2 '1)))))))))

(define (reftrans-example2->pict)
  (with-rewrites
   (lambda ()
     (let-syntax ([step (syntax-rules ()
                          [(_ e) (lw->pict mini (to-lw e))])])
       (append-steps
        (step (Exp (lambda a (thunk ('+ (Stx a •) '1))) env_0))
        (step (lambda (Stx a (Rename • a a2))
                (Exp (thunk ('+ (Stx a (Rename • a a2)) '1)) 
                     env_1 = (extend env_0 a2 TVar))))
        (step-... "calling the" (step thunk) "transformer")
        (step (lambda (Stx a (Rename • a a2))
                (Exp (lambda (Stx a •) ('+ (Stx a (Rename • a a2)) '1)) 
                     env_1)))
        (step (lambda (Stx a (Rename • a a2))
                (lambda (Stx a (Rename • a a3))
                  (Exp ('+ (Stx a (Rename (Rename • a a2) a a3)) '1) 
                       env_2 = (extend env_1 a3 TVar)))))
        (step-... "expanding the body")
        (step (lambda (Stx a (Rename • a a2))
                (lambda (Stx a (Rename • a a3))
                  ('+ (Exp (Stx a (Rename (Rename • a a2) a a3)) env_2) '1))))
        (cons (blank) (explain "where the inner" (step Rename) "takes precedence in the reference to" (step a) ":"))
        (step (lambda (Stx a (Rename • a a2))
                (lambda (Stx a (Rename • a a3))
                  ('+ (Stx a (Rename • a a2)) '1))))
        (cons (blank) (explain "which parses as"))
        (cons (step =) (step (lambda a2 (lambda a3 ('+ a2 '1))))))))))

(define (hyg-example->pict)
  (with-rewrites
   (lambda ()
     (let-syntax ([step (syntax-rules ()
                          [(_ e) (lw->pict mini (to-lw e))])])
       (append-steps
        (step (Exp (lambda a (let-syntax 
                               thunk (lambda e .... (Stx a •) ....) 
                               (thunk ('+ (Stx a •) '1)))) 
                   env_0))
        (step (lambda (Stx a (Rename • a a2))
                (Exp (let-syntax 
                       thunk (lambda e .... (Stx a (Rename • a a2)) ....) 
                       (thunk ('+ (Stx a (Rename • a a2)) '1)))
                     env_1 = (extend env_0 a2 TVar))))
        (step-... "evaluating the" (step thunk) "binding")
        (step (lambda (Stx a (Rename • a a2))
                (Exp (thunk ('+ (Stx a (Rename • a a2)) '1))
                     env_2 = (extend env_1 thunk ....))))
        (step-... "calling the" (step thunk) "transformer")
        (cons (blank) (explain "the macro-introduced" (step a) "has the marked context" (step ctx)))
        (step (lambda (Stx a (Rename • a a2))
                (Exp (lambda (Stx a ctx = (Mark (Rename • a a2) mrk_1))
                       ('+ (Stx a (Rename • a a2)) '1))
                     env_2)))
        (cons (blank) (explain "and the rename to" (step a3) "applies to" (step a) "with marked context" (step ctx)))
        (step (lambda (Stx a (Rename • a a2))
                (lambda (Stx a (Rename ctx (Stx a ctx) a3))
                  (Exp ('+ id_body = (Stx a (Rename (Rename • a a2)
                                                    (Stx a ctx)
                                                    a3))
                           '1)
                       env_3 = (extend env_2 a3 TVar)))))
        (step-... "expanding the body")
        (step (lambda (Stx a (Rename • a a2))
                (lambda (Stx a (Rename ctx (Stx a ctx) a3))
                  ('+ (Exp id_body env_3) '1))))
        (cons (blank) (explain "where the" (step a3) "renaming does not apply, since" (step id_body) "is not marked"))
        (step (lambda (Stx a (Rename • a a2))
                (lambda (Stx a (Rename ctx (Stx a ctx) a3))
                  ('+ (Stx a (Rename • a a2)) '1)))))))))

(provide rules->pict
         lang->pict
         metas->pict
         
         pre-ctx->pict
         ctx->pict
         resolve->pict
         marksof->pict
         lambda-rules->pict
         ls-rules->pict
         macro-rules->pict
         mark->pict
         rename->pict
         reftrans-example->pict
         reftrans-example2->pict
         hyg-example->pict)

