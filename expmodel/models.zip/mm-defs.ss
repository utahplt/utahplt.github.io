#lang scheme
(require redex
         "rewrites.ss"
         "define-example.ss"
         slideshow/pict)

(define-language mini
  
  ;; Executable AST and values:
  [ast var (App ast ast ...) val]
  [val (Fun var ast) atom
       (List val ...) stx (Defs σ)]
  [pre-val desc-other-atom (Defs σ)]

  ;; Evaluation context in AST:
  [E hole      (App val ... E ast ...)]
  
  ;; Syntax objects (a subset of values):
  [stx (Stx atom ctx)
       (Stx (List stx ...) ctx)]
  [id (Stx sym ctx)]
  [pre-ctx desc-other-atom (Rename ctx id var σ) (Defs ctx σ)]
  [ctx •
       (Rename ctx id var σ)
       (Mark ctx mrk)
       (Defs ctx σ)]
       
  ;; Literal values:
  [atom sym prim tprim desc-other-atom] ; `desc-other-atom' typesets as "...."
  [desc-other-atom number]
  [sym (Sym var)]
  [prim SE MKS desc-other-prim] ; `desc-other-prim' typesets as "...."
  [desc-other-prim + - CONS CAR CDR LIST]
  [tprim desc-old-tprim NEW-DEFS DEF-BIND]
  [desc-old-tprim LOCAL-VALUE LOCAL-EXPAND]
  [all-tprim NEW-DEFS DEF-BIND LOCAL-VALUE LOCAL-EXPAND] ; for typesetting

  ;; Expansion operates on a mixture, where
  ;; `Exp' and `Eval' separate to-be-expanded
  ;; syntax (inside) from already-expanded
  ;; syntax (outside):
  [mixture (Exp stx env)
           (Eval local-ast env mode)
           (Stx (List stx ... mixture ...) ctx)]
  [local-ast ast (in-hole E (Local-Exp mixture σ))]
  
  ;; Expansion context:
  [F hole
     (Stx (List stx ... F (Exp stx env) ...) ctx)
     (Eval (in-hole E (Local-Exp F σ)) env mode)]
  
  ;; Expand-time environment:
  [env desc-env] ; `desc-env' typesets as prose
  [desc-env ((var transformer) ...)]
  [transformer TFun TLet-Syntax TQuote
               (TVar id) val TStop]
  
  ;; When expansion goes to expand-time evaluation,
  ;; the mode says how to resume expansion with the
  ;; macro result:
  [mode (InExp mrk)
        (InBind id stx)
        (InIntDef σ id E mrk)]
  
  ;; Definition-context and store:
  [σ addr NULL]
  [Σ desc-Σ] ; `desc-Σ' typesets as prose
  [desc-Σ ((σ (id var) ...) ...)]  
  [S desc-S] ; `desc-S' typesets as prose
  [desc-S (σ ...)]

  ;; Use variables for vars, addrs, and marks
  [(var addr mrk) desc-name] ; `desc-name' typesets as prose
  [desc-name variable-not-otherwise-mentioned])

;; ----------------------------------------
;; Non-capturing substitution for AST:

(define-metafunction mini
  subst : ast var ast -> ast
  [(subst var var ast_v) ast_v]
  [(subst var_2 var ast_v) var_2]
  [(subst (App ast ...) var ast_v)
   (App (subst ast var ast_v) ...)]
  [(subst (Fun var ast) var ast_v)
   (Fun var ast)]
  [(subst (Fun var_2 ast) var ast_v)
   (Fun var_3 (subst (subst ast var_2 var_3) var ast_v))
   (where var_3 ,(variable-not-in (term ast_v) (term var_2)))]
  [(subst atom var ast_v) atom]
  [(subst (List val ...) var ast_v) 
   (List (subst val var ast_v) ...)]
  [(subst stx var ast_v) stx]
  [(subst (Defs σ) var ast_v) (Defs σ)])

;; ----------------------------------------
;; Generic metafunctions that typeset as set operations:

(define-metafunction mini
  [(is-in? any_1 ()) #f]
  [(is-in? any_1 (any_1 any_2 ...)) #t]
  [(is-in? any_1 (any_2 any_3 ...)) (is-in? any_1 (any_3 ...))])

(define-metafunction mini
  [(emptyset) ()])

(define-metafunction mini
  [(add-elem any_1 any_2) (any_1 . any_2)])

(define-metafunction mini
  [(same? any_1 any_2) ,(equal? (term any_1) (term any_2))])

;; ----------------------------------------
;; Implementation of primitives:

(define-metafunction mini
  [(plus number_1 number_2) ,(+ (term number_1) (term number_2))])
(define-metafunction mini
  [(minus number_1 number_2) ,(+ (term number_1) (term number_2))])

(define-metafunction mini
  δ/stx : prim (val ...) -> val
  [(δ/stx SE ((Stx val ctx))) val]
  [(δ/stx MKS (atom (Stx val ctx))) (Stx atom ctx)]
  [(δ/stx MKS ((List stx ...) (Stx val ctx))) (Stx (List stx ...) ctx)])

(define-metafunction/extension δ/stx mini
  δ : prim (val ...) -> val
  [(δ + (number_1 number_2)) (plus number_1 number_2)]
  [(δ - (number_1 number_2)) (minus number_1 number_2)]
  [(δ CONS (val_1 (List val_2 ...))) (List val_1 val_2 ...)]
  [(δ CAR ((List val_1 val_2 ...))) val_1]
  [(δ CDR ((List val_1 val_2 ...))) (List val_2 ...)]
  [(δ LIST (val ...)) (List val ...)])

;; ----------------------------------------
;; Evaluating AST:

(define ->
  (reduction-relation 
   mini #:domain ast
   (--> (in-hole E (App (Fun var ast) val))
        (in-hole E (subst ast var val)))
   (--> (in-hole E (App prim val ...))
        (in-hole E (δ prim (val ...))))))

;; ----------------------------------------
;; Definition-context store operations:

(define-metafunction mini
  alloc : Σ σ -> Σ
  [(alloc Σ σ) ((σ) . Σ)])

(define-metafunction mini
  store : Σ σ id var -> Σ
  [(store ((σ any_1 ...) any_2 ...) σ id var) 
   ((σ (id var) any_1 ...) any_2 ...)]
  [(store (any_1 any_2 ...) σ id var)
   ,(cons (term any_1) (term (store (any_2 ...) σ id var)))])

(define-metafunction mini
  [(store-lookup (any_1 ... (σ (id var_new) ...) any_2 ...) σ)
   (store-val ((id var_new) ...))]
  [(store-lookup any_1 any_2) #f])

;; ----------------------------------------
;; Syntax-object operations:

(define-metafunction mini
  ;; Adds or cancels a mark
  addremove : mrk (mrk ...) -> (mrk ...)
  [(addremove mrk_1 (mrk_1 mrk_2 ...)) (mrk_2 ...)]
  [(addremove mrk_1 (mrk_2 ...)) (mrk_1 mrk_2 ...)])

(define-metafunction mini
  ;; Extracts all marks in order, removing cancelling pairs
  marksof : id -> (mrk ...)
  [(marksof (Stx val •)) ()]
  [(marksof (Stx val (Mark ctx mrk)))
   (addremove mrk (marksof (Stx val ctx)))]
  [(marksof (Stx val (Rename ctx id var σ))) (marksof (Stx val ctx))]
  [(marksof (Stx val (Defs ctx σ))) (marksof (Stx val ctx))])

(define-metafunction mini
  ;; Unrolls a set of definition-context renamings into `Reaname's
  renames : σ ((id var) ...) ctx -> ctx
  [(renames σ () ctx) ctx]
  [(renames σ ((id var) (id_2 var_2) ...) ctx)
   (renames σ ((id_2 var_2) ...) (Rename ctx id var σ))])

(define (bad-resolve-partial-pict)
  (define-metafunction mini
    ;; Resolves an identifier to a variable; this is the heart of
    ;;  the syntax-object support for lexical scope
    resolve : id Σ -> var
    [(resolve (Stx val (Defs ctx σ)) Σ)
     (resolve (Stx val ctx_new) Σ)
     (where (store-val ((id var_new) ...)) (store-lookup Σ σ))
     (where ctx_new (renames σ ((id var_new) ...) ctx))])
  (metafunction->pict resolve))

(define (resolve*-partial-pict)
  (define-metafunction mini
    ;; Resolves an identifier to a variable; this is the heart of
    ;;  the syntax-object support for lexical scope
    resolve* : id Σ S S -> var
    [(resolve* (Stx (Sym var) (Rename ctx id_orig var_new σ)) Σ S_spine S_branch)
     var_new
     (where var_1 (resolve* id_orig Σ S_branch S_branch))
     (where var_2 (resolve* (Stx (Sym var) ctx) Σ (add-elem σ S_spine) S_branch))
     (side-condition (term (same? var_1 var_2)))
     (side-condition (term (same? (marksof id_orig) (marksof (Stx (Sym var) ctx)))))]
    [(resolve* (Stx (Sym var) (Defs ctx σ)) Σ S_spine S_branch)
     (resolve* (Stx (Sym var) ctx) Σ S_spine S_branch)
     (side-condition (term (is-in? σ S_spine)))]
    [(resolve* (Stx (Sym var) (Defs ctx σ)) Σ S_spine S_branch)
     (resolve* (Stx (Sym var) ctx_new) Σ S_spine (add-elem σ S_branch))
     (where (store-val ((id var_new) ...)) (store-lookup Σ σ))
     (where ctx_new (renames σ ((id var_new) ...) ctx))])
  (metafunction->pict resolve*))

(define-metafunction mini
  ;; Resolves an identifier to a variable; this is the heart of
  ;;  the syntax-object support for lexical scope
  resolve* : id Σ S S -> var
  [(resolve* (Stx (Sym var) •) Σ S_spine S_branch) var]
  [(resolve* (Stx (Sym var) (Mark ctx mrk)) Σ S_spine S_branch)
   (resolve* (Stx (Sym var) ctx) Σ S_spine S_branch)]
  [(resolve* (Stx (Sym var) (Rename ctx id_orig var_new σ)) Σ S_spine S_branch)
   var_new
   (where var_1 (resolve* id_orig Σ S_branch S_branch))
   (where var_2 (resolve* (Stx (Sym var) ctx) Σ (add-elem σ S_spine) S_branch))
   (side-condition (term (same? var_1 var_2)))
   (side-condition (term (same? (marksof id_orig) (marksof (Stx (Sym var) ctx)))))]
  [(resolve* (Stx (Sym var) (Rename ctx id_orig var_2 σ)) Σ S_spine S_branch) 
   (resolve* (Stx (Sym var) ctx) Σ S_spine S_branch)]
  [(resolve* (Stx (Sym var) (Defs ctx σ)) Σ S_spine S_branch)
   (resolve* (Stx (Sym var) ctx) Σ S_spine S_branch)
   (side-condition (term (is-in? σ S_spine)))]
  [(resolve* (Stx (Sym var) (Defs ctx σ)) Σ S_spine S_branch)
   (resolve* (Stx (Sym var) ctx_new) Σ S_spine (add-elem σ S_branch))
   (where (store-val ((id var_new) ...)) (store-lookup Σ σ))
   (where ctx_new (renames σ ((id var_new) ...) ctx))])

(define-metafunction mini
  resolve : stx Σ -> var
  ;; Starts `resolve*' with empty skip sets
  [(resolve stx Σ) (resolve* stx Σ (emptyset) (emptyset))])
  
(define-metafunction mini
  rename : stx id var -> stx
  ;; Simply pushes `Rename's down through a syntax object
  [(rename (Stx atom ctx) id var) 
   (Stx atom (Rename ctx id var NULL))]
  [(rename (Stx (List stx ...) ctx) id var) 
   (Stx (List (rename stx id var) ...) (Rename ctx id var NULL))])

(define-metafunction mini
  mark : stx mrk -> stx
  ;; Simply pushes `Mark's down through a syntax object
  [(mark (Stx atom ctx) mrk) 
   (Stx atom (Mark ctx mrk))]
  [(mark (Stx (List stx ...) ctx) mrk) 
   (Stx (List (mark stx mrk) ...) (Mark ctx mrk))])

(define-metafunction mini
  defs : stx σ -> stx
  ;; Simply pushes `Def's down through a syntax object
  [(defs (Stx atom ctx) σ) 
   (Stx atom (Defs ctx σ))]
  [(defs (Stx (List stx ...) ctx) σ) 
   (Stx (List (defs stx σ) ...) (Defs ctx σ))])

(define-metafunction mini
  strip : stx -> val
  ;; Recursively strips lexical context from a syntax object
  [(strip (Stx atom ctx))
   atom]
  [(strip (Stx (List stx ...) ctx)) 
   (List (strip stx) ...)])

;; ----------------------------------------
;; Simple parsing of already-expanded code
;;  (used for expand-time expressions, instead of
;;   modeling multiple phases):

(define-metafunction mini
  parse : stx Σ -> ast
  [(parse (Stx (List id_lambda id_arg stx_body) ctx) Σ)
   (Fun (resolve id_arg Σ) (parse stx_body Σ))
   (where lambda (resolve id_lambda Σ))]
  [(parse (Stx (List id_quote stx) ctx) Σ)
   (strip stx)
   (where quote (resolve id_quote Σ))]
  [(parse (Stx (List id_syntax stx) ctx) Σ)
   stx
   (where syntax (resolve id_syntax Σ))]
  [(parse (Stx (List stx_rator stx_rand ...) ctx) Σ)
   (App (parse stx_rator Σ) (parse stx_rand Σ) ...)]
  [(parse id Σ)
   (resolve id Σ)])

;; ----------------------------------------
;; Expand-time environment operations:

(define-metafunction mini
  lookup : env var -> transformer
  [(lookup ((var transformer) any_2 ...) var) transformer]
  [(lookup (any_1 any_2 ...) var) (lookup (any_2 ...) var)])

(define-metafunction mini
  extend : env var transformer -> env
  [(extend env var transformer) ((var transformer) . env)])

(define-metafunction mini
  extend* : env ((var transformer) ...) -> env
  [(extend* env ((var transformer) ...)) ((var transformer) ... . env)])

(define-metafunction mini
  nostops : env -> env
  [(nostops env)
   ,(filter (lambda (p)
              (not (eq? (cadr p) (term TStop))))
            (term env))])

;; ----------------------------------------
;; The expander reduction:

(define expand->
  (reduction-relation
   mini #:domain [St mixture Σ]

   ;; Parsing core forms:
   ;;  lambda
   (--> [St (in-hole F (Exp (Stx (List id_lam id_arg stx_body) ctx) env)) Σ]
        [St (in-hole F (Stx (List id_lam id_new (Exp stx_newbody env_new)) ctx)) Σ]
        (where TFun (lookup env (resolve id_lam Σ)))
        (fresh var_new)
        (where id_new (rename id_arg id_arg var_new))
        (where stx_newbody (rename stx_body id_arg var_new))
        (where env_new (extend env var_new (TVar id_new)))
        "lambda")

   ;;  application
   (--> [St (in-hole F (Exp (Stx (List id_rator stx_arg ...) ctx) env)) Σ]
        [St (in-hole F (Stx (List (Exp id_rator env) (Exp stx_arg env) ...) ctx)) Σ]
        (where (TVar id_new) (lookup env (resolve id_rator Σ)))
        "app-var")
   (--> [St (in-hole F (Exp (Stx (List (Stx (List stx_1 ...) ctx_1) stx_2 ...) ctx_2) env)) Σ]
        [St (in-hole F (Stx (List (Exp (Stx (List stx_1 ...) ctx_1) env) (Exp stx_2 env) ...) ctx_2)) Σ]
        "app-exp")
   
   ;;  reference
   (--> [St (in-hole F (Exp id env)) Σ]
        [St (in-hole F id_new) Σ]
        (where (TVar id_new) (lookup env (resolve id Σ)))
        "ref")
   
   ;;  quote & syntax
   (--> [St (in-hole F (Exp (Stx (List id_quote stx) ctx) env)) Σ]
        [St (in-hole F (Stx (List id_quote stx) ctx)) Σ]
        (where TQuote (lookup env (resolve id_quote Σ)))
        "quote")
   
   ;; Macro creation and binding:
   (--> [St (in-hole F (Exp (Stx (List id_ls id_mac stx_rhs stx_body) ctx) env)) Σ]
        [St (in-hole F (Eval (parse stx_rhs Σ) env (InBind id_mac stx_body))) Σ]
        (where TLet-Syntax (lookup env (resolve id_ls Σ)))
        "bind-start")
   (--> [St (in-hole F (Eval val env (InBind id_mac stx_body))) Σ]
        [St (in-hole F (Exp (rename stx_body id_mac var_new) (extend env var_new val))) Σ]
        (fresh var_new)
        "bind-done")

   ;; Macro invocation and result:
   (--> [St (in-hole F (Exp stx_macapp env)) Σ]
        [St (in-hole F (Eval (App val (mark stx_macapp mrk_new)) env (InExp mrk_new))) Σ]
        (where (Stx (List id_mac stx_arg ...) ctx) stx_macapp)
        (where val (lookup env (resolve id_mac Σ)))
        (fresh mrk_new)
        "app-macro")
   (--> [St (in-hole F (Eval stx_expmac env (InExp mrk_new))) Σ]
        [St (in-hole F (Exp (mark stx_expmac mrk_new) env)) Σ]
        "macro-done")

   ;; Expand-time eval (same as `->' above, but nested in a mixture):
   (--> [St (in-hole F (Eval (in-hole E (App (Fun var ast) val)) env mode)) Σ]
        [St (in-hole F (Eval (in-hole E (subst ast var val)) env mode)) Σ]
        "eval-lam")
   (--> [St (in-hole F (Eval (in-hole E (App prim val_arg ...)) env mode)) Σ]
        [St (in-hole F (Eval (in-hole E val_res) env mode)) Σ]
        (where val_res (δ prim (val_arg ...)))
        "eval-prim")

   ;; Local-value:
   (--> [St (in-hole F (Eval (in-hole E (App LOCAL-VALUE id)) env (InExp mrk))) Σ]
        [St (in-hole F (Eval (in-hole E val) env (InExp mrk))) Σ]
        (where val (lookup env (resolve (mark id mrk) Σ)))
        "eval-local")

   ;; Local-expand:
   (--> [St (in-hole F (Eval (in-hole E ast_expand) env mode)) Σ]
        [St (in-hole F (Eval (in-hole E (Local-Exp (Exp stx_new env_stops) σ)) env mode)) Σ]
        (where (App LOCAL-EXPAND stx_expr (List id_stop ...) (Defs σ)) ast_expand)
        (where (InExp mrk) mode)
        (where env_stops (extend* (nostops env) (((resolve id_stop Σ) TStop) ...)))
        (where stx_new (defs (mark stx_expr mrk) σ))
        "local-start")
   (--> [St (in-hole F (Eval (in-hole E (Local-Exp stx σ)) env mode)) Σ]
        [St (in-hole F (Eval (in-hole E (defs (mark stx mrk) σ)) env mode)) Σ]
        (where (InExp mrk) mode)
        "local-done")
   (--> [St (in-hole F (Exp (Stx (List id_stop stx ...) ctx) env)) Σ]
        [St (in-hole F (Stx (List id_stop stx ...) ctx)) Σ]
        (where TStop (lookup env (resolve id_stop Σ)))
        "stop")
   
   ;; Create definition context:
   (--> [St (in-hole F (Eval (in-hole E (App NEW-DEFS)) env mode)) Σ]
        [St (in-hole F (Eval (in-hole E (Defs σ)) env mode)) (alloc Σ σ)]
        (fresh σ)
        "new-defs")
   
   ;; Bind a variable in a definition context:
   (--> [St (in-hole F (Eval (in-hole E (App DEF-BIND val_def id)) env (InExp mrk))) Σ]
        [St (in-hole F (Eval (in-hole E 0) (extend env var_new (TVar id_new)) (InExp mrk))) Σ_2]
        (where val_def (Defs σ))
        (fresh var_new)
        (where id_new (rename id id var_new))
        (where Σ_2 (store Σ σ (mark id mrk) var_new))
        "def-var")
   ;; Bind an expand-time value in a definition context:
   (--> [St (in-hole F (Eval (in-hole E (App DEF-BIND val_def id stx_expr)) env mode)) Σ]
        [St (in-hole F (Eval (parse stx_newexpr Σ) env (InIntDef σ id E mrk))) Σ]
        (where val_def (Defs σ))
        (where (InExp mrk) mode)
        (where stx_newexpr (mark stx_expr mrk))
        "def-start")
   (--> [St (in-hole F (Eval val env (InIntDef σ id E mrk))) Σ]
        [St (in-hole F (Eval (in-hole E 0) (extend env var_new val) (InExp mrk))) Σ_2]
        (fresh var_new)
        (where Σ_2 (store Σ σ (mark id mrk) var_new))
        "def-done")

   ))

;; ----------------------------------------
;; Helpers for writing examples:

(define-metafunction mini
  preamble-env : -> env
  [(preamble-env) ((lambda TFun)
                   (let-syntax TLet-Syntax)
                   (quote TQuote)
                   (syntax TQuote))])

;; ----------------------------------------
;; Examples:

(define-metafunction mini
  [(parse/st [St stx Σ]) (parse stx Σ)])

(define-example-definer define-example
  mini 
  (lambda (t) (term [St (Exp ,t (preamble-env)) ()]))
  expand-> 
  parse/st)

(define-example simple-macro-example
  (let-syntax x (lambda z (syntax (quote 2))) (x 1)))

(define-example reftrans-macro-example
  (lambda z (let-syntax x (lambda s (syntax z)) (lambda z (x)))))

(define-example hyg-macro-example
  (lambda z (let-syntax x (lambda s 
                            ('MKS
                             ('LIST (syntax lambda)
                                    (syntax z)
                                    ('CAR ('CDR ('SE s))))
                             (syntax here)))
              (x z))))

(define-example local-value-example
  (let-syntax a '8
    (let-syntax b '9
      (let-syntax x (lambda s 
                      ('MKS
                       ('LIST (syntax quote)
                              ('MKS ('LOCAL-VALUE ('CAR ('CDR ('SE s))))
                                    (syntax here)))
                       (syntax here)))
        (x a)))))

(define-example local-expand-example
  (let-syntax q (lambda s (syntax ('CAR '8)))
    (let-syntax x (lambda s 
                    ;; Used as (x (q)) => extracts '8 from ('CAR '8)
                    ('CAR ('CDR ('SE ('LOCAL-EXPAND ('CAR ('CDR ('SE s))) 
                                                    ('LIST) 
                                                    ('NEW-DEFS))))))
      (x (q)))))

(define-example local-expand-stop-example
  (let-syntax p (lambda s (quote 0))
    (let-syntax q (lambda s (syntax ('CAR '8)))
      (let-syntax x (lambda s 
                      ;; Used as (x (q)) => extracts '8 from ('CAR '8)
                      ('CAR ('CDR ('SE ('LOCAL-EXPAND ('CAR ('CDR ('SE s)))
                                                      ('LIST (syntax p))
                                                      ('NEW-DEFS))))))
        (x (q))))))

(define-example nested-local-expand-example
  (let-syntax z (lambda s (syntax '0))
    (let-syntax a (lambda s
                    ;; When `b' forces `a', then `a'
                    ;; drops `z' form the stop list, so it
                    ;; should expand to 0
                    ('LOCAL-EXPAND ('CAR ('CDR ('SE s)))
                                   ('LIST)
                                   ('NEW-DEFS)))
      (let-syntax b (lambda s
                      ('MKS
                       ('LIST
                        (syntax quote)
                        ('LOCAL-EXPAND ('CAR ('CDR ('SE s)))
                                       ('LIST (syntax z))
                                       ('NEW-DEFS)))
                       s))
        ('LIST (b (z)) (b (a (z))))))))

(define-example defs-shadow-example
  (let-syntax call (lambda s ('MKS ('LIST ('CAR ('CDR ('SE s))))
                                   (syntax here)))
    (let-syntax p (lambda s (syntax '0))
      (let-syntax q (lambda s
                      ((lambda ctx
                         ((lambda ignored
                            ('MKS
                             ('LIST
                              (syntax lambda)
                              ('CAR ('CDR
                                     ('SE
                                      ('LOCAL-EXPAND ('MKS
                                                      ('LIST (syntax syntax)
                                                             ('CAR ('CDR ('SE s))))
                                                      (syntax here))
                                                     ('LIST)
                                                     ctx))))
                              ('LOCAL-EXPAND ('CAR ('CDR ('CDR ('SE s))))
                                             ('LIST (syntax call))
                                             ctx))
                             (syntax here)))
                          ('DEF-BIND ctx ('CAR ('CDR ('SE s))))))
                       ('NEW-DEFS)))
        (q p (call p))))))

(define-example defs-local-macro-example
  (let-syntax call (lambda s ('MKS ('LIST ('CAR ('CDR ('SE s)))) 
                                   (syntax here)))
    (let-syntax p (lambda s (syntax '0))
      (let-syntax q (lambda s
                      ((lambda ctx
                         ((lambda ignored
                            ('MKS
                             ('LIST
                              (syntax lambda)
                              ('CAR ('CDR
                                     ('SE
                                      ('LOCAL-EXPAND ('MKS 
                                                      ('LIST (syntax syntax)
                                                             ('CAR ('CDR ('SE s))))
                                                      (syntax here))
                                                     ('LIST)
                                                     ctx))))
                              ('LOCAL-EXPAND ('CAR ('CDR ('CDR ('SE s))))
                                             ('LIST)
                                             ctx))
                             (syntax here)))
                          ('DEF-BIND ctx ('CAR ('CDR ('SE s)))
                                     ('MKS
                                      ('LIST (syntax lambda)
                                             (syntax s)
                                             ('CAR ('CDR ('CDR ('CDR ('SE s))))))
                                      (syntax here)))))
                       ('NEW-DEFS)))
        (q p (call p) (syntax '13))))))

;; ----------------------------------------
;; Typesetting:

(define (parse-rules->pict)
  (with-rewrites
   (lambda ()
     (parameterize ([render-reduction-relation-rules '("lambda" "app-var" "app-exp" "ref" "quote")])
       (reduction-relation->pict expand-> #:style 'compact-vertical)))))

(define (trans-rules->pict)
  (with-rewrites
   (lambda ()
     (parameterize ([render-reduction-relation-rules '("local-start"
                                                       "local-done"
                                                       "stop"
                                                       "bind-start"
                                                       "bind-done"
                                                       "app-macro"
                                                       "macro-done"
                                                       "eval-lam"
                                                       "eval-prim"
                                                       "eval-local"
                                                       "new-defs"
                                                       "def-var"
                                                       "def-start"
                                                       "def-done")])
       (reduction-relation->pict expand-> #:style 'compact-vertical)))))

(define (lang->pict)
  (with-rewrites
   (lambda ()
     (ht-append
      20
      (vl-append
       10
       (language->pict mini #:nts '(ast val atom sym prim all-tprim σ))
       (language->pict mini #:nts '(stx id ctx))
       (language->pict mini #:nts '(Σ env S)))
      (vl-append
       10
       (language->pict mini #:nts '(E F))
       (language->pict mini #:nts '(mixture local-ast mode))
       (language->pict mini #:nts '(transformer))
       (language->pict mini #:nts '(var addr mrk)))))))

(define (metas->pict)
  (with-rewrites
   (lambda ()
     (vl-append
      10
      (vl-append (metafunction->pict δ/stx) (text "..." 'default (default-font-size)))
      (metafunction->pict parse)
      (metafunction->pict resolve)
      (parameterize (#;[linebreaks '(#f #t #f #t #t #t)])
        (metafunction->pict resolve*))
      (metafunction->pict renames)
      (metafunctions->pict mark rename defs)
      (metafunctions->pict marksof addremove)
      (metafunctions->pict strip)
      (metafunctions->pict nostops)))))

(define (tprim->pict)
  (with-rewrites
   (lambda ()
     (language->pict mini #:nts '(tprim)))))

(define (ctx->pict)
  (with-rewrites
   (lambda ()
     (vl-append
      10
      (language->pict mini #:nts '(pre-ctx pre-val))
      (language->pict mini #:nts '(σ Σ S))))))

(define (bad-resolve->pict)
  (with-rewrites
   (lambda ()
     (parameterize ([linebreaks '(#t)])
       (bad-resolve-partial-pict)))))

(define (renames->pict)
  (with-rewrites
   (lambda ()
     (parameterize ([linebreaks '(#f #t)])
       (metafunction->pict renames)))))

(define (resolve*->pict)
  (with-rewrites
   (lambda ()
     (vl-append
      10
      (metafunction->pict resolve)
      (vl-append
       (text "...." 'roman (default-font-size))
       (parameterize ([linebreaks '(#t #t #t)])
         (resolve*-partial-pict)))))))

(define (new-defs-rules->pict)
  (with-rewrites
   (lambda ()
     (parameterize ([render-reduction-relation-rules '("new-defs")]
                    [label-space 10])
       (reduction-relation->pict expand-> #:style 'compact-vertical)))))

(define (def-var-rules->pict)
  (with-rewrites
   (lambda ()
     (parameterize ([render-reduction-relation-rules '("def-var")]
                    [label-space 5])
       (reduction-relation->pict expand-> #:style 'compact-vertical)))))

(define (def-exp-rules->pict)
  (with-rewrites
   (lambda ()
     (parameterize ([render-reduction-relation-rules '("def-start" "def-done")])
       (reduction-relation->pict expand-> #:style 'compact-vertical)))))

(define (local-rules->pict)
  (with-rewrites
   (lambda ()
     (parameterize ([render-reduction-relation-rules '("local-start" "local-done")])
       (reduction-relation->pict expand-> #:style 'compact-vertical)))))

(define (example-ids->pict)
  (with-rewrites
   (lambda ()
     (let-syntax ([ex (syntax-rules ()
                        [(_ e) (lw->pict mini (to-lw e))])])
       (vl-append
        10
        (vl-append
         (ex (Stx x (Defs (Defs • σ_1) σ_1)))
         (ex (Stx x (Defs (Defs (Defs (Defs • σ_1) σ_2) σ_2) σ_1))))
        (ex (Plain Σ = (Set (Bind σ_1 (Set (Bind (Stx x (Defs • σ_1)) (Comma x1))
                                           (Bind (Stx x (Defs (Defs (Defs (Defs • σ_1) σ_2) σ_2) σ_1)) x3)))
                            (Bind σ_2 (Set (Bind (Defs (Defs (Defs • σ_1) σ_2) σ_2)) x2))))))))))

(provide parse-rules->pict
         trans-rules->pict
         lang->pict
         metas->pict
         
         tprim->pict
         ctx->pict
         bad-resolve->pict
         renames->pict
         resolve*->pict
         new-defs-rules->pict
         def-var-rules->pict
         def-exp-rules->pict
         local-rules->pict
         example-ids->pict)
