#lang scheme
(require redex
         "rewrites.ss"
         "define-example.ss"
         slideshow/pict)

(define-language mini
  
  ;; Executable AST and values:
  [ast var (App ast ast ...) val]
  [val (Fun var ast) atom
       (List val ...) stx]

  ;; Evaluation context in AST:
  [E hole      (App val ... E ast ...)]
  
  ;; Syntax objects (a subset of values):
  [stx (Stx atom ctx)
       (Stx (List stx ...) ctx)]
  [id (Stx sym ctx)]
  [ctx •
       (Mark ctx mrk)
       (Rename ctx id var)]
       
  ;; Literal values:
  [atom sym prim tprim desc-other-atom] ; `desc-other-atom' typesets as "...."
  [desc-other-atom number]
  [sym (Sym var)]
  [prim SE MKS desc-other-prim] ; `desc-other-prim' typesets as "...."
  [desc-other-prim + - CONS CAR CDR LIST]
  [tprim LOCAL-VALUE LOCAL-EXPAND]

  ;; Expansion operates on a mixture, where
  ;; `Exp' and `Eval' separate to-be-expanded
  ;; syntax (inside) from already-expanded
  ;; syntax (outside):
  [mixture desc-old-mixture (Eval local-ast env mode)]
  [desc-old-mixture (Exp stx env)           
                    (Stx (List stx ... mixture ...) ctx)]
  [local-ast ast (in-hole E (Local-Exp mixture))]
  
  ;; Expansion context:
  [F desc-old-F (Eval (in-hole E (Local-Exp F)) env mode)]
  [desc-old-F hole
              (Stx (List stx ... F (Exp stx env) ...) ctx)]

  
  ;; Expand-time environment:
  [env desc-env] ; `desc-env' typesets as prose
  [desc-env ((var transformer) ...)]
  [transformer TFun TLet-Syntax TQuote
               (TVar id) val TStop]
  
  ;; When expansion goes to expand-time evaluation,
  ;; the mode says how to resume expansion with the
  ;; macro result:
  [mode (InExp mrk)
        (InBind id stx)]
  
  ;; Use variables for vars, addrs, and marks
  [(var mrk) desc-name] ; `desc-name' typesets as prose
  [desc-name variable-not-otherwise-mentioned])

;; ----------------------------------------
;; Non-capturing substitution for AST:

(define-metafunction mini
  subst : ast var ast -> ast
  [(subst var var ast_v) ast_v]
  [(subst var_2 var ast_v) var_2]
  [(subst (App ast ...) var ast_v)
   (App (subst ast var ast_v) ...)]
  [(subst (Fun var ast) var ast_v)
   (Fun var ast)]
  [(subst (Fun var_2 ast) var ast_v)
   (Fun var_3 (subst (subst ast var_2 var_3) var ast_v))
   (where var_3 ,(variable-not-in (term ast_v) (term var_2)))]
  [(subst atom var ast_v) atom]
  [(subst (List val ...) var ast_v) 
   (List (subst val var ast_v) ...)]
  [(subst stx var ast_v) stx])

;; ----------------------------------------
;; Generic metafunctions that typeset as set operations:

(define-metafunction mini
  [(is-in? any_1 ()) #f]
  [(is-in? any_1 (any_1 any_2 ...)) #t]
  [(is-in? any_1 (any_2 any_3 ...)) (is-in? any_1 (any_3 ...))])

(define-metafunction mini
  [(emptyset) ()])

(define-metafunction mini
  [(add-elem any_1 any_2) (any_1 . any_2)])

(define-metafunction mini
  [(same? any_1 any_2) ,(equal? (term any_1) (term any_2))])

;; ----------------------------------------
;; Implementation of primitives:

(define-metafunction mini
  [(plus number_1 number_2) ,(+ (term number_1) (term number_2))])
(define-metafunction mini
  [(minus number_1 number_2) ,(+ (term number_1) (term number_2))])

(define-metafunction mini
  δ/stx : prim (val ...) -> val
  [(δ/stx SE ((Stx val ctx))) val]
  [(δ/stx MKS (atom (Stx val ctx))) (Stx atom ctx)]
  [(δ/stx MKS ((List stx ...) (Stx val ctx))) (Stx (List stx ...) ctx)])

(define-metafunction/extension δ/stx mini
  δ : prim (val ...) -> val
  [(δ + (number_1 number_2)) (plus number_1 number_2)]
  [(δ - (number_1 number_2)) (minus number_1 number_2)]
  [(δ CONS (val_1 (List val_2 ...))) (List val_1 val_2 ...)]
  [(δ CAR ((List val_1 val_2 ...))) val_1]
  [(δ CDR ((List val_1 val_2 ...))) (List val_2 ...)]
  [(δ LIST (val ...)) (List val ...)])

;; ----------------------------------------
;; Evaluating AST:

(define ->
  (reduction-relation 
   mini #:domain ast
   (--> (in-hole E (App (Fun var ast) val))
        (in-hole E (subst ast var val)))
   (--> (in-hole E (App prim val ...))
        (in-hole E (δ prim (val ...))))))

;; ----------------------------------------
;; Syntax-object operations:

(define-metafunction mini
  ;; Adds or cancels a mark
  addremove : mrk (mrk ...) -> (mrk ...)
  [(addremove mrk_1 (mrk_1 mrk_2 ...)) (mrk_2 ...)]
  [(addremove mrk_1 (mrk_2 ...)) (mrk_1 mrk_2 ...)])

(define-metafunction mini
  ;; Extracts all marks in order, removing cancelling pairs
  marksof : id -> (mrk ...)
  [(marksof (Stx val •)) ()]
  [(marksof (Stx val (Mark ctx mrk)))
   (addremove mrk (marksof (Stx val ctx)))]
  [(marksof (Stx val (Rename ctx id var))) (marksof (Stx val ctx))])

(define-metafunction mini
  ;; Resolves an identifier to a variable; this is the heart of
  ;;  the syntax-object support for lexical scope
  resolve : id -> var
  [(resolve (Stx (Sym var) •)) var]
  [(resolve (Stx val (Mark ctx mrk)))
   (resolve (Stx val ctx))]
  [(resolve (Stx val (Rename ctx id_orig var_new)))
   var_new
   (where var_1 (resolve id_orig))
   (where var_2 (resolve (Stx val ctx)))
   (side-condition (term (same? var_1 var_2)))
   (side-condition (term (same? (marksof id_orig) (marksof (Stx val ctx)))))]
  [(resolve (Stx val (Rename ctx id_orig var)))
   (resolve (Stx val ctx))])

(define-metafunction mini
  rename : stx id var -> stx
  ;; Simply pushes `Rename's down through a syntax object
  [(rename (Stx atom ctx) id var) 
   (Stx atom (Rename ctx id var))]
  [(rename (Stx (List stx ...) ctx) id var) 
   (Stx (List (rename stx id var) ...) (Rename ctx id var))])

(define-metafunction mini
  mark : stx mrk -> stx
  ;; Simply pushes `Mark's down through a syntax object
  [(mark (Stx atom ctx) mrk) 
   (Stx atom (Mark ctx mrk))]
  [(mark (Stx (List stx ...) ctx) mrk) 
   (Stx (List (mark stx mrk) ...) (Mark ctx mrk))])

(define-metafunction mini
  strip : stx -> val
  ;; Recursively strips lexical context from a syntax object
  [(strip (Stx atom ctx))
   atom]
  [(strip (Stx (List stx ...) ctx)) 
   (List (strip stx) ...)])

;; ----------------------------------------
;; Simple parsing of already-expanded code
;;  (used for expand-time expressions, instead of
;;   modeling multiple phases):

(define-metafunction mini
  parse : stx -> ast
  [(parse (Stx (List id_lambda id_arg stx_body) ctx))
   (Fun (resolve id_arg) (parse stx_body))
   (where lambda (resolve id_lambda))]
  [(parse (Stx (List id_quote stx) ctx))
   (strip stx)
   (where quote (resolve id_quote))]
  [(parse (Stx (List id_syntax stx) ctx))
   stx
   (where syntax (resolve id_syntax))]
  [(parse (Stx (List stx_rator stx_rand ...) ctx))
   (App (parse stx_rator) (parse stx_rand) ...)]
  [(parse id)
   (resolve id)])

;; ----------------------------------------
;; Expand-time environment operations:

(define-metafunction mini
  lookup : env var -> transformer
  [(lookup ((var transformer) any_2 ...) var) transformer]
  [(lookup (any_1 any_2 ...) var) (lookup (any_2 ...) var)])

(define-metafunction mini
  extend : env var transformer -> env
  [(extend env var transformer) ((var transformer) . env)])

(define-metafunction mini
  extend* : env ((var transformer) ...) -> env
  [(extend* env ((var transformer) ...)) ((var transformer) ... . env)])

(define-metafunction mini
  nostops : env -> env
  [(nostops env)
   ,(filter (lambda (p)
              (not (eq? (cadr p) (term TStop))))
            (term env))])

;; ----------------------------------------
;; The expander reduction:

(define expand->
  (reduction-relation
   mini #:domain mixture

   ;; Parsing core forms:
   ;;  lambda
   (--> (in-hole F (Exp (Stx (List id_lam id_arg stx_body) ctx) env))
        (in-hole F (Stx (List id_lam id_new (Exp stx_newbody env_new)) ctx))
        (where TFun (lookup env (resolve id_lam)))                            
        (fresh var_new)
        (where id_new (rename id_arg id_arg var_new))
        (where stx_newbody (rename stx_body id_arg var_new))
        (where env_new (extend env var_new (TVar id_new)))
        "lambda")

   ;;  application
   (--> (in-hole F (Exp (Stx (List id_rator stx_arg ...) ctx) env))
        (in-hole F (Stx (List (Exp id_rator env) (Exp stx_arg env) ...) ctx))
        (where (TVar id_new) (lookup env (resolve id_rator)))
        "app-var")
   (--> (in-hole F (Exp (Stx (List (Stx (List stx_1 ...) ctx_1) stx_2 ...) ctx_2) env))
        (in-hole F (Stx (List (Exp (Stx (List stx_1 ...) ctx_1) env) (Exp stx_2 env) ...) ctx_2))
        "app-exp")
   
   ;;  reference
   (--> (in-hole F (Exp id env))
        (in-hole F id_new)
        (where (TVar id_new) (lookup env (resolve id)))
        "ref")
   
   ;;  quote & syntax
   (--> (in-hole F (Exp (Stx (List id_quote stx) ctx) env))
        (in-hole F (Stx (List id_quote stx) ctx))
        (where TQuote (lookup env (resolve id_quote)))
        "quote")

   ;; Macro creation and binding:
   (--> (in-hole F (Exp (Stx (List id_ls id_mac stx_rhs stx_body) ctx) env))
        (in-hole F (Eval (parse stx_rhs) env (InBind id_mac stx_body)))
        (where TLet-Syntax (lookup env (resolve id_ls)))
        "bind-start")
   (--> (in-hole F (Eval val env (InBind id_mac stx_body)))
        (in-hole F (Exp (rename stx_body id_mac var_new) (extend env var_new val)))
        (fresh var_new)
        "bind-done")

   ;; Macro invocation and result:
   (--> (in-hole F (Exp stx_macapp env))
        (in-hole F (Eval (App val (mark stx_macapp mrk_new)) env (InExp mrk_new)))
        (where (Stx (List id_mac stx_arg ...) ctx) stx_macapp)
        (where val (lookup env (resolve id_mac)))
        (fresh mrk_new)
        "app-macro")
   (--> (in-hole F (Eval stx_expmac env (InExp mrk_new)))
        (in-hole F (Exp (mark stx_expmac mrk_new) env))
        "macro-done")

   ;; Expand-time eval (same as `->' above, but nested in a mixture):
   (--> (in-hole F (Eval (in-hole E (App (Fun var ast) val)) env mode))
        (in-hole F (Eval (in-hole E (subst ast var val)) env mode))
        "eval-lam")
   (--> (in-hole F (Eval (in-hole E (App prim val_arg ...)) env mode))
        (in-hole F (Eval (in-hole E val_res) env mode))
        (where val_res (δ prim (val_arg ...)))
        "eval-prim")

   ;; Local-value:
   (--> (in-hole F (Eval (in-hole E (App LOCAL-VALUE id)) env (InExp mrk)))
        (in-hole F (Eval (in-hole E val) env (InExp mrk)))
        (where val (lookup env (resolve (mark id mrk))))
        "eval-local")

   ;; Local-expand:
   (--> (in-hole F (Eval (in-hole E ast_expand) env (InExp mrk)))
        (in-hole F (Eval (in-hole E (Local-Exp mixture_expand)) env (InExp mrk)))
        (where (App LOCAL-EXPAND stx_expr (List id_stop ...)) ast_expand)
        (where env_stops (extend* (nostops env) (((resolve id_stop) TStop) ...)))
        (where mixture_expand (Exp (mark stx_expr mrk) env_stops))
        "local-start")
   (--> (in-hole F (Eval (in-hole E (Local-Exp stx)) env (InExp mrk)))
        (in-hole F (Eval (in-hole E (mark stx mrk)) env (InExp mrk)))
        "local-done")
   (--> (in-hole F (Exp (Stx (List id_stop stx ...) ctx) env))
        (in-hole F (Stx (List id_stop stx ...) ctx))
        (where TStop (lookup env (resolve id_stop)))
        "stop")

   ))

;; ----------------------------------------
;; Helpers for writing examples:

(define-metafunction mini
  preamble-env : -> env
  [(preamble-env) ((lambda TFun)
                   (let-syntax TLet-Syntax)
                   (quote TQuote)
                   (syntax TQuote))])

;; ----------------------------------------
;; Examples:

(define-example-definer define-example
  mini 
  (lambda (t) (term (Exp ,t (preamble-env))))
  expand-> 
  parse)

(define-example simple-macro-example
  (let-syntax x (lambda z (syntax (quote 2))) (x 1)))

(define-example reftrans-macro-example
  (lambda z (let-syntax x (lambda s (syntax z)) (lambda z (x)))))

(define-example hyg-macro-example
  (lambda z (let-syntax x (lambda s 
                            ('MKS
                             ('LIST (syntax lambda)
                                    (syntax z)
                                    ('CAR ('CDR ('SE s))))
                             (syntax here)))
              (x z))))

(define-example local-value-example
  (let-syntax a '8
    (let-syntax b '9
      (let-syntax x (lambda s 
                      ('MKS
                       ('LIST (syntax quote)
                              ('MKS ('LOCAL-VALUE ('CAR ('CDR ('SE s))))
                                    (syntax here)))
                       (syntax here)))
        (x a)))))

(define-example local-expand-example
  (let-syntax q (lambda s (syntax ('CAR '8)))
    (let-syntax x (lambda s 
                    ;; Used as (x (q)) => extracts '8 from ('CAR '8)
                    ('CAR ('CDR ('SE ('LOCAL-EXPAND ('CAR ('CDR ('SE s))) 
                                                    ('LIST))))))
      (x (q)))))

(define-example local-expand-stop-example
  (let-syntax p (lambda s (quote 0))
    (let-syntax q (lambda s (syntax ('CAR '8)))
      (let-syntax x (lambda s 
                      ;; Used as (x (q)) => extracts '8 from ('CAR '8)
                      ('CAR ('CDR ('SE ('LOCAL-EXPAND ('CAR ('CDR ('SE s)))
                                                      ('LIST (syntax p)))))))
        (x (q))))))

(define-example nested-local-expand-example
  (let-syntax z (lambda s (syntax '0))
    (let-syntax a (lambda s
                    ;; When `b' forces `a', then `a'
                    ;; drops `z' form the stop list, so it
                    ;; should expand to 0
                    ('LOCAL-EXPAND ('CAR ('CDR ('SE s)))
                                   ('LIST)))
      (let-syntax b (lambda s
                      ('MKS
                       ('LIST
                        (syntax quote)
                        ('LOCAL-EXPAND ('CAR ('CDR ('SE s)))
                                       ('LIST (syntax z))))
                       s))
        ('LIST (b (z)) (b (a (z))))))))

;; ----------------------------------------
;; Typesetting:

(define (rules->pict)
  (with-rewrites
   (lambda ()
      (reduction-relation->pict expand-> #:style 'compact-vertical))))

(define (lang->pict)
  (with-rewrites
   (lambda ()
     (ht-append
      20
      (vl-append
       10
       (language->pict mini #:nts '(ast val atom sym prim tprim))
       (language->pict mini #:nts '(stx id ctx))
       (language->pict mini #:nts '(env)))
      (vl-append
       10
       (language->pict mini #:nts '(E F))
       (language->pict mini #:nts '(mixture local-ast mode))
       (language->pict mini #:nts '(transformer))
       (language->pict mini #:nts '(var mrk)))))))

(define (metas->pict)
  (with-rewrites
   (lambda ()
     (vl-append
      10
      (vl-append (metafunction->pict δ/stx) (text "..." 'default (default-font-size)))
      (metafunction->pict parse)
      (metafunction->pict resolve)
      (metafunctions->pict mark rename)
      (metafunctions->pict marksof addremove)
      (metafunctions->pict strip)))))

(define (tprim->pict)
  (with-rewrites
   (lambda ()
     (language->pict mini #:nts '(atom tprim)))))

(define (mixture->pict)
  (with-rewrites
   (lambda ()
     (language->pict mini #:nts '(mixture local-ast F)))))

(define (value-rules->pict)
  (with-rewrites
   (lambda ()
     (parameterize ([render-reduction-relation-rules '("eval-local")]
                    [label-space 10])
       (reduction-relation->pict expand-> #:style 'compact-vertical)))))

(define (expand-rules->pict)
  (with-rewrites
   (lambda ()
     (parameterize ([render-reduction-relation-rules '("local-start" "local-done" "stop")])
       (reduction-relation->pict expand-> #:style 'compact-vertical)))))

(define (nostops->pict)
  (with-rewrites
   (lambda ()
     (metafunction->pict nostops))))

(define (example->pict)
  (with-rewrites
   (lambda ()
     (let-syntax ([step (syntax-rules ()
                          [(_ e) (lw->pict mini (to-lw e))])])
       (append-steps
        (step (Exp (let-syntax SPC public ....
                     (let-syntax SPC class .... (class (public '8))))
                   env_0))
        (step-... "evaluate transformer expression for" (step public))
        (step (Exp (let-syntax SPC class .... (class (public '8)))
                   env_1 = (extend env_0 public ....)))
        (step-... "evaluate transformer expression for" (step class))
        (step (Exp (class (public '8)) env_2 = (extend env_1 class ....)))
        (step-... "apply the" (step class) "transformer")
        (step (Eval .... ('LOCAL-EXPAND (syntax (public '8))
                                        ('LIST (syntax public))) ....
                    env_2 (InExp mrk_1)))
        (cons (blank) (explain "expansion stops immediately at" (step public) ":"))
        (step (Eval .... (syntax (public '8)) .... env_2 (InExp mrk_1)))
        (step-... "transformer strips the" (step public) "form away")
        (step (Eval (syntax '8) env_2 (InExp mrk_1)))
        (step (Exp '8 env_2)))))))

(provide rules->pict
         lang->pict
         metas->pict
         
         tprim->pict
         value-rules->pict
         mixture->pict
         expand-rules->pict
         nostops->pict
         example->pict)
