#lang scheme
(require redex
         "rewrites.ss"
         "define-example.ss"
         slideshow/pict)

(define-language mini
  
  ;; Executable AST and values:
  [ast var (App ast ast ...) val]
  [val (Fun var ast) atom
       (List val ...) stx]

  ;; Evaluation context in AST:
  [E hole      (App val ... E ast ...)]
  
  ;; Syntax objects (a subset of values):
  [stx (Stx atom ctx)
       (Stx (List stx ...) ctx)]
  [id (Stx sym ctx)]
  [ctx •]
       
  ;; Literal values:
  [atom sym prim desc-other-atom] ; `desc-other-atom' typesets as "...."
  [desc-other-atom number]
  [sym (Sym var)]
  [prim SE MKS desc-other-prim] ; `desc-other-prim' typesets as "...."
  [desc-other-prim + - CONS CAR CDR LIST]

  ;; Expansion operates on a mixture, where
  ;; `Exp' and `Eval' separate to-be-expanded
  ;; syntax (inside) from already-expanded
  ;; syntax (outside):
  [mixture (Exp stx env)
           (Stx (List stx ... mixture ...) ctx)]
  
  ;; Expansion context:
  [F hole (Stx (List stx ... F (Exp stx env) ...) ctx)]
  
  ;; Expand-time environment:
  [env desc-env] ; `desc-env' typesets as prose
  [desc-env ((var transformer) ...)]
  [transformer TFun TQuote (TVar id)]
  
  ;; Use variables for vars, addrs, and marks
  [(var) desc-name] ; `desc-name' typesets as prose
  [desc-name variable-not-otherwise-mentioned])

;; ----------------------------------------
;; Non-capturing substitution for AST:

(define-metafunction mini
  subst : ast var ast -> ast
  [(subst var var ast_v) ast_v]
  [(subst var_2 var ast_v) var_2]
  [(subst (App ast ...) var ast_v)
   (App (subst ast var ast_v) ...)]
  [(subst (Fun var ast) var ast_v)
   (Fun var ast)]
  [(subst (Fun var_2 ast) var ast_v)
   (Fun var_3 (subst (subst ast var_2 var_3) var ast_v))
   (where var_3 ,(variable-not-in (term ast_v) (term var_2)))]
  [(subst atom var ast_v) atom]
  [(subst (List val ...) var ast_v) 
   (List (subst val var ast_v) ...)]
  [(subst stx var ast_v) stx])

;; ----------------------------------------
;; Generic metafunctions that typeset as set operations:

(define-metafunction mini
  [(is-in? any_1 ()) #f]
  [(is-in? any_1 (any_1 any_2 ...)) #t]
  [(is-in? any_1 (any_2 any_3 ...)) (is-in? any_1 (any_3 ...))])

(define-metafunction mini
  [(emptyset) ()])

(define-metafunction mini
  [(add-elem any_1 any_2) (any_1 . any_2)])

(define-metafunction mini
  [(same? any_1 any_2) ,(equal? (term any_1) (term any_2))])

;; ----------------------------------------
;; Implementation of primitives:

(define-metafunction mini
  [(plus number_1 number_2) ,(+ (term number_1) (term number_2))])
(define-metafunction mini
  [(minus number_1 number_2) ,(+ (term number_1) (term number_2))])

(define-metafunction mini
  δ/stx : prim (val ...) -> val
  [(δ/stx SE ((Stx val ctx))) val]
  [(δ/stx MKS (atom (Stx val ctx))) (Stx atom ctx)]
  [(δ/stx MKS ((List stx ...) (Stx val ctx))) (Stx (List stx ...) ctx)])

(define-metafunction/extension δ/stx mini
  δ : prim (val ...) -> val
  [(δ + (number_1 number_2)) (plus number_1 number_2)]
  [(δ - (number_1 number_2)) (minus number_1 number_2)]
  [(δ CONS (val_1 (List val_2 ...))) (List val_1 val_2 ...)]
  [(δ CAR ((List val_1 val_2 ...))) val_1]
  [(δ CDR ((List val_1 val_2 ...))) (List val_2 ...)]
  [(δ LIST (val ...)) (List val ...)])

;; ----------------------------------------
;; Evaluating AST:

(define ->
  (reduction-relation 
   mini #:domain ast
   (--> (in-hole E (App (Fun var ast) val))
        (in-hole E (subst ast var val)))
   (--> (in-hole E (App prim val ...))
        (in-hole E (δ prim (val ...))))))

;; ----------------------------------------
;; Syntax-object operations:

(define-metafunction mini
  ;; Resolves an identifier to a variable; this is the heart of
  ;;  the syntax-object support for lexical scope
  resolve : id -> var
  [(resolve (Stx (Sym var) •)) var])

(define-metafunction mini
  strip : stx -> val
  ;; Recursively strips lexical context from a syntax object
  [(strip (Stx atom ctx))
   atom]
  [(strip (Stx (List stx ...) ctx)) 
   (List (strip stx) ...)])

;; ----------------------------------------
;; Simple parsing of already-expanded code
;;  (used for expand-time expressions, instead of
;;   modeling multiple phases):

(define-metafunction mini
  parse : stx -> ast
  [(parse (Stx (List id_lambda id_arg stx_body) ctx))
   (Fun (resolve id_arg) (parse stx_body))
   (where lambda (resolve id_lambda))]
  [(parse (Stx (List id_quote stx) ctx))
   (strip stx)
   (where quote (resolve id_quote))]
  [(parse (Stx (List id_syntax stx) ctx))
   stx
   (where syntax (resolve id_syntax))]
  [(parse (Stx (List stx_rator stx_rand ...) ctx))
   (App (parse stx_rator) (parse stx_rand) ...)]
  [(parse id)
   (resolve id)])

;; ----------------------------------------
;; Expand-time environment operations:

(define-metafunction mini
  lookup : env var -> transformer
  [(lookup ((var transformer) any_2 ...) var) transformer]
  [(lookup (any_1 any_2 ...) var) (lookup (any_2 ...) var)])

(define-metafunction mini
  extend : env var transformer -> env
  [(extend env var transformer) ((var transformer) . env)])

(define-metafunction mini
  extend* : env ((var transformer) ...) -> env
  [(extend* env ((var transformer) ...)) ((var transformer) ... . env)])

;; ----------------------------------------
;; The expander reduction:

(define expand->
  (reduction-relation
   mini #:domain mixture

   ;; Parsing core forms:
   ;;  lambda
   (--> (in-hole F (Exp (Stx (List id_lam id_arg stx_body) ctx) env))
        (in-hole F (Stx (List id_lam id_new (Exp stx_body env_new)) ctx))
        (where TFun (lookup env (resolve id_lam)))                            
        (fresh var_new)
        (where id_new (Stx (Sym var_new) •))
        (where env_new (extend env (resolve id_arg) (TVar id_new)))
        "lambda")

   ;;  application
   (--> (in-hole F (Exp (Stx (List id_rator stx_arg ...) ctx) env))
        (in-hole F (Stx (List (Exp id_rator env) (Exp stx_arg env) ...) ctx))
        (where (TVar id_new) (lookup env (resolve id_rator)))
        "app-var")
   (--> (in-hole F (Exp (Stx (List stx_rator stx_arg ...) ctx) env))
        (in-hole F (Stx (List (Exp stx_rator env) (Exp stx_arg env) ...) ctx))
        (where (Stx (List stx_1 ...) ctx_1) stx_rator)
        "app-exp")
   
   ;;  reference
   (--> (in-hole F (Exp id env))
        (in-hole F id_new)
        (where (TVar id_new) (lookup env (resolve id)))
        "ref")
   
   ;;  quote & syntax
   (--> (in-hole F (Exp (Stx (List id_quote stx) ctx) env))
        (in-hole F (Stx (List id_quote stx) ctx))
        (where TQuote (lookup env (resolve id_quote)))
        "quote")

   ))

;; ----------------------------------------
;; Helpers for writing examples:

(define-metafunction mini
  preamble-env : -> env
  [(preamble-env) ((lambda TFun)
                   (quote TQuote)
                   (syntax TQuote))])

;; ----------------------------------------
;; Examples:

(define-example-definer define-example
  mini 
  (lambda (t) (term (Exp ,t (preamble-env))))
  expand-> 
  parse)

(define-example simple-parse-example
  (lambda x (lambda y (y ('+ x '5)))))

(define-example shadow-parse-example
  (lambda lambda (lambda lambda lambda)))

;; ----------------------------------------
;; Typesetting:

(define (rules->pict)
  (with-rewrites
   (lambda ()
      (reduction-relation->pict expand-> #:style 'compact-vertical))))

(define (lang->pict)
  (with-rewrites
   (lambda ()
     (ht-append
      20
      (vl-append
       10
       (language->pict mini #:nts '(ast val atom sym prim))
       (language->pict mini #:nts '(stx id ctx)))
      (vl-append
       10
       (language->pict mini #:nts '(E F))
       (language->pict mini #:nts '(mixture))
       (language->pict mini #:nts '(transformer))
       (vl-append
        (language->pict mini #:nts '(env))
        (language->pict mini #:nts '(var))))))))

(define (metas->pict)
  (with-rewrites
   (lambda ()
     (vl-append
      10
      (vl-append (metafunction->pict δ/stx) (text "..." 'default (default-font-size)))
      (metafunction->pict parse)
      (metafunction->pict resolve)
      (metafunctions->pict strip)))))

(define (new-rules->pict)
  (with-rewrites
   (lambda ()
     (grammar+reductions
      (language->pict mini #:nts '(F))
      (reduction-relation->pict expand-> #:style 'compact-vertical)))))

(define (mixture->pict)
  (with-rewrites
   (lambda ()
     (language->pict mini #:nts '(mixture)))))

(define (env->pict)
  (with-rewrites
   (lambda ()
     (vl-append
      (language->pict mini #:nts '(env))
      (language->pict mini #:nts '(transformer))))))

(define (example->pict)
  (with-rewrites
   (lambda ()
     (append-steps
      (lw->pict mini (to-lw (Exp (lambda lambda lambda) env_0)))
      (lw->pict mini (to-lw (lambda lambda2 (Exp lambda (extend env_0 lambda lambda2)))))
      (lw->pict mini (to-lw (lambda lambda2 lambda2)))))))

(provide rules->pict
         lang->pict
         metas->pict
         
         mixture->pict
         env->pict
         new-rules->pict
         example->pict)
