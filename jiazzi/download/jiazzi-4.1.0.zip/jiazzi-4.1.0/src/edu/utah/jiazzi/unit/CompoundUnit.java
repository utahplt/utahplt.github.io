/*
 * Copyright (c) 2004, 2005, 2006 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package edu.utah.jiazzi.unit;

import java.util.*;

import edu.utah.jiazzi.loc.LocClass;
import edu.utah.jiazzi.loc.LocPackage;
import edu.utah.jiazzi.loc.LocRoot;
import edu.utah.jiazzi.loc.LocType;
import edu.utah.jiazzi.loc.Local;
import edu.utah.jiazzi.loc.Self;
import edu.utah.jiggy.clazz.ClassModel;
import edu.utah.jiggy.clazz.PackageModel;
import edu.utah.jiggy.clazz.TypeModel;
import edu.utah.jiggy.instruction.ins.ReplaceIns;
import edu.utah.jiggy.meta.flag.BinaryFlag;
import edu.utah.jiggy.meta.flag.FlagConstants;
import edu.utah.jiggy.meta.name.ClassName;
import edu.utah.jiggy.meta.name.MemberName;
import edu.utah.jiggy.meta.name.PackageName;
import edu.utah.jiggy.meta.shape.ArgShape;
import edu.utah.jiggy.meta.shape.ClassShape;
import edu.utah.jiggy.meta.shape.InitShape;
import edu.utah.jiggy.meta.shape.ReplaceShape;
import edu.utah.jiggy.meta.shape.ShapeKey;
import edu.utah.jiggy.meta.type.ArrayType;
import edu.utah.jiggy.meta.type.ClassType;
import edu.utah.jiggy.meta.type.PrimitiveType;
import edu.utah.jiggy.meta.type.RefType;
import edu.utah.jiggy.meta.type.TypeType;
import edu.utah.jiggy.meta.type.VariableType;

public class CompoundUnit extends Unit {
    private static boolean dbg = false;
    final Self self = new Self((CompoundUnit) this);

    public String toString() {
        return "compound " + super.toString();
    }

    // final Map<String,Local> locals =
    // new HashMap<String,Local>();
    final Map locals = new HashMap();

    // public final List<Local> order = new ArrayList<Local>();
    public final List order = new ArrayList();

    // final Map<String,Local> READ_locals =
    // Collections.unmodifiableMap(this.locals);
    final Map READ_locals = Collections.unmodifiableMap(this.locals);

    public Self self() {
        return this.self;
    }

    public Map locals() {
        return this.READ_locals;
    }

    public Local newLocal(String name, Unit unit) {
        Local local = new Local(name, (CompoundUnit) this, unit);
        if (this.locals.put(name, local) != null)
            throw new Error();
        this.order.add(local);
        return local;
    }

    public Local newLocal(Unit unit) {
        String name = "000" + this.order.size();
        Local local = new Local(name, (CompoundUnit) this, unit);
        this.locals.put(name, local);
        this.order.add(local);
        return local;
    }

    public Iterator allLocals() {
        final Iterator i = this.READ_locals.values().iterator();
        return new Iterator() {
            boolean b = true;

            public boolean hasNext() {
                return i.hasNext() || this.b;
            }

            public void remove() {
                throw new Error();
            }

            public Object next() {
                if (i.hasNext())
                    return i.next();
                else if (!this.b)
                    throw new Error();
                else {
                    this.b = false;
                    return CompoundUnit.this.self();
                }
            }
        };
    }

    public long modifiedSource(UnitEnvironment env) {
        long m = super.modifiedSource(env);
        for (Iterator i = this.locals.values().iterator();
             i.hasNext();
             /* i = i */) {
            Local local = (Local) i.next();
            long m0 = local.unit().modifiedSource(env);
            if (m0 > m)
                m = m0;
        }
        return m;
    }

    public long modifiedRaw(UnitEnvironment env) {
        long m = super.modifiedRaw(env);
        for (Iterator i = this.locals.values().iterator();
             i.hasNext();
             /* i = i */) {
            Local local = (Local) i.next();
            long m0 = local.unit().modifiedRaw(env);
            if (m0 > m)
                m = m0;
        }
        return m;
    }

    public CompoundUnit(java.lang.String name) {
        super(name);
    }

    public void verify(UnitEnvironment env) {
        /*
         * verify connections
         */
        for (Iterator i = this.allLocals(); i.hasNext(); /* i = i */) {
            final LocRoot local = (LocRoot) i.next();
            // final Map<LocPackage,LocPackage> revConnections = new
            // HashMap<LocPackage,LocPackage>();
            final Map revConnections = new HashMap();
            for (Iterator j = local.pkgLinkage().keySet().iterator();
                 j.hasNext();
                 /* j = j */) {
                LocPackage tpkg = (LocPackage) j.next();
                revConnections.put(local.pkgLinkage().get(tpkg), tpkg);
            }
            Set visible = new HashSet() {
                // public boolean contains(ClassType ctype0)
                public boolean contains(Object obj) {
                    ClassType ctype0 = (ClassType) obj;
                    if (ctype0 instanceof TypeModel)
                        return true;
                    LocType ctype = (LocType) ctype0;
                    if (ctype.clazz().pkg().isSink())
                        throw new Error(ctype + " is not a source class");
                    if (false) {
                        System.err.println("check " + ctype + " "
                            + ctype.clazz().pkg().root() + " " + local + " "
                            + ctype.clazz().pkg() + " "
                            + local.pkgLinkage().values());
                    }
                    if (ctype.clazz().pkg().root() == local)
                        return true;
                    if (!revConnections.keySet().contains(ctype.clazz().pkg()))
                        return false;
                    LocPackage lpkg = (LocPackage) revConnections.get(ctype
                        .clazz().pkg());
                    if (!lpkg.isSink())
                        throw new Error();
                    if (!lpkg.classes().containsKey(
                        ctype.clazz().name().nopkg()))
                        return false;
                    return true;
                }
            };
            for (Iterator j = local.pkgLinkage().keySet().iterator();
                 j.hasNext();
                 /* j = j */) {
                final LocPackage tpkg = (LocPackage) j.next();
                if (!tpkg.isSink())
                    throw new Error();
                final LocPackage fpkg = (LocPackage) local.pkgLinkage().get(
                    tpkg);
                if (!fpkg.isSource())
                    throw new Error();

                for (Iterator k = tpkg.classes().values().iterator();
                     k.hasNext();
                     /* k = k */) {
                    LocClass tcls = (LocClass) k.next();

                    env.pushErrorPreface("verifying link to class \""
                        + tcls.name() + "\" in " + local + " of " + this);
                    LocClass fcls;
                    for (LocPackage epkg = fpkg; true; epkg = epkg.extended) {
                        if (epkg.classes().containsKey(tcls.name().nopkg())) {
                            fcls = (LocClass) epkg.classes().get(
                                tcls.name().nopkg());
                            break;
                        }
                        if (epkg.extended == null) {
                            if (true)
                                throw new Error();
                            env.err().println(
                                "cannot find class " + tcls.name().nopkg()
                                    + " in " + fpkg);
                            env.fail();
                            fcls = null;
                            break;
                        }
                    }
                    if (fcls == null)
                        continue;

                    env.popErrorPreface();
                    env.pushErrorPreface("verifying link from class \""
                        + fcls.name() + "\" in " + fpkg.root() + " to class \""
                        + tcls.name() + "\" in " + local + " of " + this);
                    if (!fcls.shape().verify(env.err())) {
                        env.err().println(
                            "shape for \"" + fcls + "\" failed verification");
                        env.fail();
                        continue;
                    }
                    ClassShape fshape = fcls.shape().collapse(visible);

                    // if (tpkg.root().parent() == fcls.pkg().root().parent()) {
                    if (tpkg.root() == fcls.pkg().root()) {
                        if (fcls.shape().isSet(FlagConstants.INTERFACE))
                            fshape.addInterface(fcls.newType());
                        else
                            fshape.setZuper(fcls.newType());
                        for (Iterator g = fcls.newType().shape().interfaces()
                                 .iterator();
                             g.hasNext();
                             /* g = g */)
                            fshape.addInterface((ClassType) g.next());
                    }
                    if (!fshape.matches(tcls.shape(), env.err())) {

                        System.err
                            .println("fcls= " + fcls + " " + fcls.shape());
                        System.err.println("fcls= " + fcls + " " + fshape
                            + " (collapsed)");
                        System.err
                            .println("tcls= " + tcls + " " + tcls.shape());
                        System.err
                            .println("fpkg " + fpkg.root() + " "
                                + fpkg.lexemeLinkage() + " "
                                + fpkg.argVarLinkage());
                        System.err
                            .println("tpkg " + tpkg.root() + " "
                                + tpkg.lexemeLinkage() + " "
                                + tpkg.argVarLinkage());

                        // System.err.println(tpkg.upkg().classes().get(tcls.name().nopkg()).shape());
                        System.err.println("" + tpkg.upkg().signature);
                        if (tpkg.upkg().signature != null)
                            System.err
                                .println(((UnitClass) tpkg.upkg().signature
                                    .self().classes().get(tcls.name().nopkg()))
                                    .shape());

                        env.err().println(
                            "shape for \"" + fcls
                                + "\" does not match shape required for \""
                                + tcls + "\"");
                        env.fail();
                    }
                    env.popErrorPreface();
                }
            }
            if (!local.isSelf()) {
                Local local0 = (Local) local;
                for (Iterator j = local0.unit().generics().values().iterator();
                     j.hasNext();
                     /* j = j */) {
                    VariableType tv = (VariableType) j.next();
                    RefType tref = (RefType) local0.genericLinkage().get(tv);
                    ClassType bound = (ClassType) local0.bounds.get(tv.name());
                    // System.err.println(local0 + " check: " + tref + " isa " +
                    // bound);
                    if (tref == null)
                        throw new Error();
                    if (tref instanceof VariableType) {
                        if (!this.generics().values().contains(
                            (VariableType) tref))
                            throw new Error(tref
                                + " is not a type variable of the compound!");
                        ClassType boundFrom = (ClassType) this.self().bounds
                            .get(((VariableType) tref).name());
                        if (!boundFrom.isa(bound)) {
                            env.fail();
                            env.err().println(
                                "type variable " + tv.name()
                                    + " cannot be bound to type variable "
                                    + ((VariableType) tref).name()
                                    + " with bound " + boundFrom
                                    + " because at least " + bound
                                    + " is expected");
                        }
                    } else {
                        if (!tref.isa(bound)) {
                            env.fail();
                            env.err().println(
                                "type variable " + tv.name()
                                    + " cannot be bound to " + tref
                                    + " because at least " + bound
                                    + " is expected");
                        }
                    }
                }
            }
        }
        for (Iterator i = this.allLocals(); i.hasNext(); /* i = i */) {
            LocRoot local = (LocRoot) i.next();
            for (Iterator j = local.packages().values().iterator();
                 j.hasNext();
                 /* j = j */) {
                LocPackage lpkg = (LocPackage) j.next();
                if (lpkg.isSink())
                    continue;
                /* check for class collisions */
                for (LocPackage epkg = lpkg.extended;
                     epkg != null;
                     epkg = epkg.extended) {
                    for (Iterator k = epkg.fresh.iterator();
                         k.hasNext();
                         /* k = k */) {
                        ClassName cname = (ClassName) k.next();
                        if (lpkg.fresh.contains(cname)) {
                            env.err().println(
                                lpkg + " already introduces class " + cname
                                    + " introduced by super package " + epkg);
                            env.fail();
                        }
                    }
                }
                /* check for method collisions */
                for (Iterator k = lpkg.classes().values().iterator();
                     k.hasNext();
                     /* k = k */) {
                    LocClass lcls = (LocClass) k.next();
                    LocClass ecls = lcls;
                    while (ecls.newType().shape().zuper() instanceof LocType) {
                        ecls = ((LocType) ecls.newType().shape().zuper())
                            .clazz();
                        for (Iterator h = ecls.fresh.iterator();
                             h.hasNext();
                             /* h = h */) {
                            ShapeKey key = (ShapeKey) h.next();
                            if (lcls.fresh.contains(key)) {
                                env.err().println(
                                    lcls
                                        + " already introduces method "
                                        + lcls.newType().shape().actualMethod(
                                            key).javaSource("")
                                        + " that is introduced by super class "
                                        + ecls);
                                env.fail();
                            }
                        }
                    }
                }
            }
        }
    }

    protected void buildInner(final UnitEnvironment env) {
        /* decide whether to verify or not */
        for (Iterator i = this.allLocals(); i.hasNext(); /* i = i */)
            ((LocRoot) i.next()).resolveInit(env);

        {
            // Map<PackageName,LocPackage> map = new
            // HashMap<PackageName,LocPackage>();
            Map map = new HashMap();
            for (Iterator i = this.opens().iterator();
                 i.hasNext();
                 /* i = i */) {
                UnitOpen open = (UnitOpen) i.next();
                LocPackage lpkg = (LocPackage) this.self().packages().get(
                    open.in().name());
                map.put(open.name(), lpkg);
            }
            for (Iterator i = this.order.iterator();
                 i.hasNext();
                 /* i = i */) {
                Local l = (Local) i.next();
                for (Iterator j = l.unit().opens().iterator();
                     j.hasNext();
                     /* j = j */) {
                    UnitOpen open = (UnitOpen) j.next();
                    LocPackage lpkg = (LocPackage) l.packages().get(
                        open.in().name());
                    if (!l.pkgLinkage().keySet().contains(lpkg)) {
                        if (map.containsKey(open.name())) {
                            l.link(lpkg, (LocPackage) map.get(open.name()));
                            map.remove(open.name());
                        }
                    }
                    map.put(open.name(), l.packages().get(open.out().name()));
                }
            }
            for (Iterator i = this.opens().iterator();
                 i.hasNext();
                 /* i = i */) {
                UnitOpen open = (UnitOpen) i.next();
                LocPackage lpkg = (LocPackage) this.self().packages().get(
                    open.out().name());
                if (!this.self().pkgLinkage().keySet().contains(lpkg)) {
                    if (map.containsKey(open.name())) {
                        this.self().link(lpkg,
                            (LocPackage) map.get(open.name()));
                        map.remove(open.name());
                    }
                }
                lpkg = (LocPackage) this.self().packages().get(
                    open.fixed().name());
                map.put(open.name(), lpkg);
            }
            for (Iterator i = this.allLocals(); i.hasNext(); /* i = i */) {
                LocRoot local = (LocRoot) i.next();
                for (Iterator j = local.packages().values().iterator();
                     j.hasNext();
                     /* j = j */) {
                    LocPackage tpkg = (LocPackage) j.next();
                    if (!tpkg.isSink())
                        continue;
                    if (local.pkgLinkage().containsKey(tpkg))
                        continue;
                    if (!map.containsKey(tpkg.name()))
                        continue;
                    local.link(tpkg, (LocPackage) map.get(tpkg.name()));
                }
            }
        }
        for (Iterator i = this.allLocals(); i.hasNext(); /* i = i */)
            ((LocRoot) i.next()).resolve1(env);

        for (Iterator i = this.allLocals(); i.hasNext(); /* i = i */)
            ((LocRoot) i.next()).setSigLink(env);

        for (Iterator i = this.allLocals(); i.hasNext(); /* i = i */)
            ((LocRoot) i.next()).doDefaultLink(env);

        for (Iterator i = this.allLocals(); i.hasNext(); /* i = i */)
            ((LocRoot) i.next()).setSigLink(env);

        /*
         * ensure each local package sink is provided by a source with all the
         * required classes
         */
        for (Iterator i = this.allLocals(); i.hasNext(); /* i = i */) {
            LocRoot local = (LocRoot) i.next();
            for (Iterator j = local.packages().values().iterator();
                 j.hasNext();
                 /* j = j */) {
                LocPackage tpkg = (LocPackage) j.next();
                if (!tpkg.isSink())
                    continue;
                if (tpkg.classes().isEmpty()
                    && !local.pkgLinkage().containsKey(tpkg))
                    continue;
                if (!local.pkgLinkage().containsKey(tpkg)) {
                    // if (true) throw new Error();
                    env.err().println("package not connected to " + tpkg);
                    env.fail();
                    continue;
                }
                LocPackage fpkg = (LocPackage) local.pkgLinkage().get(tpkg);
                if (!fpkg.isSource())
                    throw new Error();
                for (Iterator k = tpkg.classes().values().iterator();
                     k.hasNext();
                     /* k = k */) {
                    LocClass tcls = (LocClass) k.next();
                    LocPackage epkg = fpkg;
                    while (epkg != null
                        && !epkg.classes().keySet().contains(
                            tcls.name().nopkg()))
                        epkg = epkg.extended;
                    if (epkg == null) {
                        env.fail();
                        env.err().print(
                            "class " + tcls.name().nopkg() + " not found in "
                                + fpkg + " (with ");
                        epkg = fpkg;
                        while (epkg != null) {
                            env.err().print(
                                epkg.classes().keySet() + ":"
                                    + epkg.lexemeLinkage());
                            epkg = epkg.extended;
                        }
                        env.err().println(")");
                    } else if (((ClassModel) epkg.classes().get(
                        tcls.name().nopkg())).name().var() != tcls.name().var()) {
                        env.err().println(
                            "name of class " + tcls.name().nopkg()
                                + " does not match " + tcls.name());
                        env.fail();
                    }
                }
            }
        }
        if (env.hasFailed()) {
            env.err().println("cannot link since error in locals");
            return;
        }
        for (Iterator j = this.allLocals(); j.hasNext(); /* j = j */)
            for (Iterator i = ((LocRoot) j.next()).packages().values()
                     .iterator();
                 i.hasNext();
                 /* i = i */)
                ((LocPackage) i.next()).resolveInit(env);

        for (Iterator i = this.allLocals(); i.hasNext(); /* i = i */)
            ((LocRoot) i.next()).resolve2(env);

        if (this.modifiedBuilt(env) < this.modifiedSource(env))
            this.verify(env);
        else
            System.err.println("no reason to verify " + this);

        for (Iterator i = this.locals().values().iterator();
             i.hasNext();
             /* i = i */) {
            Local local = (Local) i.next();
            local.unit().build(env);
        }
        if (env.hasFailed()) {
            env.err().println("cannot link since error in locals");
            return;
        }
        for (Iterator i = this.exports().iterator();
             i.hasNext();
             /* i = i */) {
            /* create exported packages */
            UnitPackage upkg = (UnitPackage) i.next();
            // PackageModel bpkg =
            new PackageModel(this.built(), upkg.name());
        }
        // Map<Local,ReplaceShape> rmap = new HashMap<Local,ReplaceShape>();
        Map rmap = new HashMap();

        /* establish all the classes first */
        for (Iterator i = this.locals().values().iterator();
             i.hasNext();
             /* i = i */) {
            Local local = (Local) i.next();

            ReplaceShape r2b = new ReplaceIns(); // new ReplaceShape();
            rmap.put(local, r2b);
            ReplaceShape u2l = new ReplaceShape();
            local.u2lName(u2l, env);
            local.u2lArg(u2l, env);
            u2l.map(local.unit(), local);

            for (Iterator j = local.unit().built().packages().values()
                     .iterator();
                 j.hasNext();
                 /* j = j */) {
                PackageModel rpkg = (PackageModel) j.next();
                UnitPackage upkg;
                LocPackage lpkg;
                if (local.unit().packages().containsKey(rpkg.name())) {
                    upkg = (UnitPackage) local.unit().packages().get(
                        rpkg.name());
                    if (!upkg.isExport())
                        throw new Error();
                    lpkg = (LocPackage) local.packages().get(rpkg.name());
                } else {
                    upkg = null;
                    lpkg = null;
                }
                PackageModel bpkg;
                LocPackage kpkg = null;
                {
                    LocPackage epkg = lpkg;
                    while (true) {
                        if (epkg == null)
                            break;
                        if (!epkg.isSource())
                            throw new Error();
                        if (this.self().pkgLinkage().values().contains(epkg))
                            break;
                        if (dbg)
                            System.err.println("SCAN: "
                                + epkg.name().javaSource() + "\t"
                                + epkg.root().name() + "\t" + epkg.extending);
                        epkg = epkg.extending;
                    }
                    if (epkg != null) {
                        for (Iterator k = this.self().pkgLinkage().keySet()
                                 .iterator();
                             true;
                             /* k = k */) {
                            kpkg = (LocPackage) k.next();
                            if (this.self().pkgLinkage().get(kpkg) == epkg)
                                break;
                        }
                        bpkg = (PackageModel) this.built().packages().get(
                            kpkg.name());
                    } else
                        bpkg = null;
                }
                if (bpkg == null) {
                    PackageName pname = new PackageName();
                    pname = pname.setOuter(rpkg.name());
                    pname = pname.setBase("_" + local.name());
                    bpkg = new PackageModel(this.built(), pname);
                }
                r2b.map(rpkg, bpkg);
                for (Iterator k = rpkg.classes().values().iterator();
                     k.hasNext();
                     /* k = k */) {
                    ClassModel rcls = (ClassModel) k.next();
                    ClassName cname;
                    if (upkg != null
                        && upkg.classes().containsKey(rcls.name().nopkg())) {
                        UnitClass ucls = (UnitClass) upkg.classes().get(
                            rcls.name().nopkg());
                        cname = ucls.name().nopkg().replace(u2l);
                    } else
                        cname = rcls.name().nopkg();
                    boolean prependClass = false;
                    if (kpkg != null) {
                        if (kpkg.classes().containsKey(cname)) {
                            if (!lpkg.classes().containsKey(cname))
                                throw new Error();
                            LocPackage epkg = lpkg;
                            while (true) {
                                if (epkg == this.self().pkgLinkage().get(kpkg)) {
                                    prependClass = false;
                                    break;
                                }
                                epkg = epkg.extending;
                                if (epkg.classes().containsKey(cname)) {
                                    prependClass = true;
                                    break;
                                }
                            }
                        } else
                            prependClass = true;
                    } else
                        prependClass = false;
                    if (prependClass == true) {
                        cname = (ClassName) cname.setEnd(cname.end() + "_"
                            + local.name());
                    }
                    ClassModel bcls = new ClassModel(bpkg, cname);
                    if (!cname.equals(rcls.name().nopkg()))
                        r2b.map(rcls.newType(), bcls.newType());
                }
            }
        }
        /* be extra careful with arg parameters */

        /* now we can do all our renaming */
        for (Iterator i = this.locals().values().iterator();
             i.hasNext();
             /* i = i */) {
            Local local = (Local) i.next();
            ReplaceShape r2b = (ReplaceShape) rmap.get(local);
            ReplaceShape u2l = new ReplaceShape();
            local.u2lName(u2l, env);
            local.u2lArg(u2l, env);
            u2l.map(local.unit(), local);

            for (Iterator j = local.unit().imports().iterator();
                 j.hasNext();
                 /* j = j */) {
                UnitPackage upkg = (UnitPackage) j.next();
                PackageModel rpkg = (PackageModel) local.unit().stub()
                    .packages().get(upkg.name());
                LocPackage lpkg = (LocPackage) local.pkgLinkage().get(
                    local.packages().get(upkg.name()));
                if (lpkg == null) /* no need */
                    continue;
                if (lpkg.root().isSelf()) {
                    r2b.map(rpkg, (PackageModel) this.stub().packages().get(
                        lpkg.name()));
                } else {
                    PackageModel bpkg = (PackageModel) ((PackageModel) lpkg
                        .root().unit().built().packages().get(lpkg.name()))
                        .replace((ReplaceShape) rmap.get((Local) lpkg.root()));
                    if (bpkg.root() != this.built())
                        throw new Error(lpkg + " " + bpkg + " "
                            + rmap.get((Local) lpkg.root()));
                    r2b.map(rpkg, bpkg);
                }
                for (Iterator k = upkg.classes().values().iterator();
                     k.hasNext();
                     /* k = k */) {
                    UnitClass ucls = (UnitClass) k.next();
                    ClassModel rcls = (ClassModel) rpkg.classes().get(
                        ucls.name().nopkg());
                    ClassName cname = ucls.name().nopkg().replace(u2l);

                    LocPackage epkg = lpkg;
                    ClassModel bcls;
                    while (true) {
                        if (epkg.classes().containsKey(cname)) {
                            if (epkg.root().isSelf())
                                bcls = (ClassModel) ((PackageModel) this.stub()
                                    .packages().get(epkg.name())).classes()
                                    .get(cname);
                            else {
                                PackageModel bpkg = (PackageModel) epkg.rpkg()
                                    .replace(
                                        (ReplaceShape) rmap.get((Local) epkg
                                            .root()));
                                if (bpkg.root() != this.built())
                                    throw new Error();
                                ClassName cname0 = (ClassName) cname
                                    .setEnd(cname.end() + "_"
                                        + ((Local) epkg.root()).name());
                                if (bpkg.classes().containsKey(cname0))
                                    bcls = (ClassModel) bpkg.classes().get(
                                        cname0);
                                else
                                    bcls = (ClassModel) bpkg.classes().get(
                                        cname);
                            }
                            break;
                        }
                        epkg = epkg.extended;
                    }
                    if (!bcls.name().nopkg().equals(ucls.name().nopkg())
                        || !lpkg.classes().containsKey(cname))
                        r2b.map(rcls.newType(), bcls.newType());
                }
            }
            ReplaceShape u2r = new ReplaceShape();
            local.unit().u2r(local.unit().built(), local.unit().stub(), u2r);

            /* remap the type variables now... */
            for (Iterator j = local.unit().generics().values().iterator();
                 j.hasNext();
                 /* j = j */) {
                VariableType tv = (VariableType) j.next();
                TypeModel rref = (TypeModel) tv.replace(u2r);
                RefType lref = (RefType) local.genericLinkage().get(tv);
                RefType bref;
                if (lref instanceof VariableType) {
                    bref = ((ClassModel) ((PackageModel) this.stub().packages()
                        .get(TVAR)).classes().get(
                        new ClassName(((VariableType) lref).name()))).newType();
                } else {
                    bref = (RefType) this.l2b(lref, rmap);
                }
                r2b.map(rref, bref);
            }
            // if (!local.lexemeLinkage().isEmpty()) {
            if (true) {
                /*
                 * class references are updated, now update member references
                 */
                for (Iterator j = local.unit().packages().values().iterator();
                     j.hasNext();
                     /* j = j */) {
                    UnitPackage upkg = (UnitPackage) j.next();
                    for (Iterator k = upkg.classes().values().iterator();
                         k.hasNext();
                         /* k = k */) {
                        UnitClass ucls = (UnitClass) k.next();
                        UnitType utype = (UnitType) ucls.newType();
                        TypeModel rtype = (TypeModel) utype.replace(u2r);
                        ClassModel rcls = rtype.clazz();
                        Iterator gm = utype.shape().methods().iterator();
                        Iterator gf = utype.shape().fields().iterator();
                        while (gm.hasNext() || gf.hasNext()) {
                            ShapeKey ukey = (ShapeKey) (gm.hasNext() ? gm
                                .next() : gf.next());

                            ShapeKey lkey;
                            u2l.set(utype);
                            try {
                                lkey = ukey.replace(u2l);
                            } catch (Error e) {
                                System.err.println(local + "");
                                System.err.println(ukey + " " + u2l);
                                throw e;
                            }
                            u2l.set((ClassType) null);

                            if ((lkey.nameType().name().equals(ukey.nameType()
                                .name()))
                                && (lkey.procedure().args().size() == ukey
                                    .procedure().args().size()))
                                continue;

                            u2r.set(utype);
                            ShapeKey rkey = ukey.replace(u2r);
                            u2r.set((ClassType) null);

                            r2b.set(rtype);
                            ShapeKey tkey = rkey.replace(r2b);
                            r2b.set((ClassType) null);

                            tkey = tkey.set(tkey.nameType().setName(
                                lkey.nameType().name()));

                            if (tkey.procedure().args().size() != ukey
                                .procedure().args().size()) {
                                if (tkey.procedure().args().size() != lkey
                                    .procedure().args().size())
                                    throw new Error();
                            } else {
                                int lsize = lkey.procedure().args().size();
                                int usize = ukey.procedure().args().size();
                                for (int kk = 0; kk < lsize - usize; kk++) {
                                    ArgShape larg = (ArgShape) lkey.procedure()
                                        .args().get(usize + kk);
                                    ArgShape barg = larg.setType(this.l2b(larg
                                        .type(), rmap));
                                    tkey = tkey.set(tkey.procedure().addArg(
                                        barg));
                                    /** ** how to add it dammit */
                                }
                                tkey = tkey.set(tkey.procedure().set(
                                    lkey.procedure().argVar()));
                            }
                            if (tkey.procedure().args().size() != lkey
                                .procedure().args().size())
                                throw new Error("tkey=" + tkey + " lkey="
                                    + lkey + " ukey=" + ukey + " rkey=" + rkey);

                            r2b.map(rtype, rkey, tkey);
                        }
                        /* method references */
                        for (Iterator g = utype.shape().methods().iterator();
                             g.hasNext();
                             /* g = g */) {
                            ShapeKey umthd = (ShapeKey) g.next();

                            u2r.set(utype);
                            ShapeKey rmthd = umthd.replace(u2r);
                            u2r.set((ClassType) null);

                            TypeModel ftype;
                            if (utype.shape().actualMethod(umthd).isSet(
                                FlagConstants.STATIC))
                                ftype = (TypeModel) rcls.newType().shape()
                                    .lookupMethod(rmthd);
                            else
                                ftype = (TypeModel) rcls.newType().shape()
                                    .freshMethod(rmthd);

                            if (ftype == null
                                && !utype.shape().actualMethod(umthd).isSet(
                                    FlagConstants.STATIC)) {
                                System.err.print(utype.javaSource()
                                    + " "
                                    + utype.shape().actual(umthd).javaSource(
                                        null));
                                System.err
                                    .print(" " + rcls.newType().javaSource()
                                        + " " + rmthd);
                                for (ClassType ct = rcls.newType();
                                     ct != null;
                                     ct = ct.shape().zuper()) {
                                    System.err.print(ct.shape().methods()
                                        .contains(rmthd));
                                    System.err.print(" "
                                        + ct.shape().freshMethod(rmthd));
                                    System.err.print(" " + ct.isShapeSet());
                                    System.err.println();
                                    ct.rawShape().print(ct, "", System.err,
                                        null);
                                }
                                throw new Error();
                            }

                            r2b.set(rcls.newType());
                            ShapeKey tmthd0 = rmthd.replace(r2b);
                            r2b.set((ClassType) null);

                            r2b.set(ftype);
                            ShapeKey tmthd1 = rmthd.replace(r2b);
                            r2b.set((ClassType) null);

                            if (!tmthd0.equals(tmthd1))
                                r2b.map(ftype, rmthd, tmthd0);
                        }
                        /* field references */
                        for (Iterator g = utype.shape().fields().iterator();
                             g.hasNext();
                             /* g = g */) {
                            ShapeKey ufld = (ShapeKey) g.next();

                            u2r.set(utype);
                            ShapeKey rfld = ufld.replace(u2r);
                            u2r.set((ClassType) null);

                            TypeModel ftype = (TypeModel) rcls.newType()
                                .shape().lookupField(rfld);

                            r2b.set(rcls.newType());
                            ShapeKey tfld0 = rfld.replace(r2b);
                            r2b.set((ClassType) null);

                            r2b.set(ftype);
                            ShapeKey tfld1 = rfld.replace(r2b);
                            r2b.set((ClassType) null);

                            if (!tfld0.equals(tfld1))
                                r2b.map(ftype, rfld, tfld0);
                        }
                    }
                }
            }
            {
                /* rename hidden methods */
                // Map<ShapeKey,Set<TypeModel>> preserve = new
                // HashMap<ShapeKey,Set<TypeModel>>();
                Map preserve = new HashMap();
                for (Iterator j = local.unit().packages().values().iterator();
                     j.hasNext();
                     /* j = j */)
                    for (Iterator k = ((UnitPackage) j.next()).classes()
                             .values().iterator();
                         k.hasNext();
                         /* k = k */) {
                        UnitClass ucls = (UnitClass) k.next();
                        UnitType utype = (UnitType) ucls.newType();
                        ClassModel rcls = ((TypeModel) utype.replace(u2r))
                            .clazz();
                        for (Iterator g = utype.shape().methods().iterator();
                             g.hasNext();
                             /* g = g */) {
                            ShapeKey umthd = (ShapeKey) g.next();
                            if (utype.shape().actualMethod(umthd).isSet(
                                FlagConstants.STATIC))
                                continue;

                            u2r.set(utype);
                            ShapeKey rmthd = umthd.replace(u2r);
                            u2r.set((ClassType) null);

                            TypeModel ftype = (TypeModel) rcls.newType()
                                .shape().freshMethod(rmthd);
                            if (ftype.shape().actualMethod(rmthd).access()
                                    == FlagConstants.PACKAGE)
                                throw new Error(rmthd
                                    + " in "
                                    + ftype
                                    + " cannot be package access method: "
                                    + ftype.shape().actualMethod(rmthd)
                                        .javaSource(""));
                            if (!preserve.containsKey(rmthd))
                                preserve.put(rmthd, new HashSet());
                            ((Set) preserve.get(rmthd)).add(ftype);
                        }
                    }
                for (Iterator j = local.unit().built().packages().values()
                         .iterator();
                     j.hasNext();
                     /* j = j */) {
                    PackageModel rpkg = (PackageModel) j.next();
                    for (Iterator k = rpkg.classes().values().iterator();
                         k.hasNext();
                         /* k = k */) {
                        ClassModel rcls = (ClassModel) k.next();
                        TypeModel rtype = (TypeModel) rcls.newType();
                        for (Iterator g = rtype.shape().methods().iterator();
                             g.hasNext();
                             /* g = g */) {
                            ShapeKey rmthd = (ShapeKey) g.next();
                            if (rtype.shape().actualMethod(rmthd).isSet(
                                FlagConstants.STATIC))
                                continue;
                            if (rtype.shape().actualMethod(rmthd).access()
                                    == FlagConstants.PRIVATE)
                                continue;
                            TypeModel ftype = (TypeModel) rcls.newType()
                                .shape().freshMethod(rmthd);
                            if (ftype == null)
                                throw new Error(rcls.newType().javaSource()
                                    + " " + rmthd);
                            if (ftype.clazz().pkg().root() != local.unit()
                                .built()
                                && /* class loader loaded */
                                ftype.clazz().pkg().root() != local.unit()
                                    .stub())
                                continue;
                            if (preserve.containsKey(rmthd)
                                && ((Set) preserve.get(rmthd)).contains(ftype))
                                continue;
                            else {
                                /* rename it! */
                                MemberName nm = (MemberName) rmthd.nameType()
                                    .name().setEnd("_" + local.name());

                                r2b.set(rtype);
                                ShapeKey tmthd = rmthd.replace(r2b);
                                r2b.set((ClassType) null);

                                tmthd = tmthd.set(tmthd.nameType().setName(nm));
                                r2b.map(rtype, rmthd, tmthd);
                            }
                        }
                    }
                }
            }
        }
        ReplaceShape u2b = new ReplaceShape();
        for (Iterator i = this.exports().iterator();
             i.hasNext();
             /* i = i */) {
            UnitPackage upkg = (UnitPackage) i.next();
            PackageModel bpkg = (PackageModel) this.built().packages().get(
                upkg.name());
            u2b.map(upkg, bpkg);
        }
        for (Iterator i = this.imports().iterator();
             i.hasNext();
             /* i = i */) {
            UnitPackage upkg = (UnitPackage) i.next();
            PackageModel bpkg = (PackageModel) this.stub().packages().get(
                upkg.name());
            u2b.map(upkg, bpkg);
        }
        for (Iterator i = this.exports().iterator();
             i.hasNext();
             /* i = i */) {
            UnitPackage upkg = (UnitPackage) i.next();
            PackageModel bpkg = (PackageModel) this.built().packages().get(
                upkg.name());
            for (Iterator j = upkg.classes().values().iterator();
                 j.hasNext();
                 /* j = j */) {
                UnitClass ucls = (UnitClass) j.next();
                UnitType utype = (UnitType) ucls.newType();
                if (bpkg.classes().containsKey(ucls.name().nopkg()))
                    continue;
                ClassModel bcls = new ClassModel(bpkg, ucls.name().nopkg());
                UnitPackage epkg = upkg.extended();
                ClassModel ecls;
                while (true) {
                    if (epkg == null)
                        throw new Error("class expected but not provided");
                    PackageModel eepkg;
                    if (epkg.isImport())
                        eepkg = (PackageModel) this.stub().packages().get(
                            epkg.name());
                    else
                        eepkg = (PackageModel) this.built().packages().get(
                            epkg.name());
                    if (eepkg.classes().containsKey(ucls.name().nopkg())) {
                        ecls = (ClassModel) eepkg.classes().get(
                            ucls.name().nopkg());
                        break;
                    }
                }
                TypeModel etype = (TypeModel) ecls.newType();
                ClassShape shape = new ClassShape();
                shape.setZuper(etype);
                shape.set(ucls.shape().access());
                shape.set(ucls.shape().virtual());
                for (Iterator k = ucls.shape().binaries().iterator();
                     k.hasNext();
                     /* k = k */)
                    shape.set((BinaryFlag) k.next());
                for (Iterator k = utype.shape().inits().iterator();
                     k.hasNext();
                     /* k = k */) {
                    InitShape uinit = utype.shape().actualInit(
                        (ShapeKey) k.next());

                    u2b.set(utype);
                    InitShape binit = (InitShape) uinit.replace(u2b);
                    u2b.set((ClassType) null);

                    shape.add(binit);
                }
                bcls.setShape(shape);
            }
        }
        for (Iterator i = this.locals().values().iterator();
             i.hasNext();
             /* i = i */) {
            Local local = (Local) i.next();
            ReplaceShape r2b = (ReplaceShape) rmap.get(local);
            if (dbg)
                System.err.println("REPLACE: " + local + " " + r2b);
            env.copyInto(local.unit().built(), this.built(), r2b);
        }
    }

    public TypeType l2b(TypeType tp, Map rmap) {
        if (tp instanceof ArrayType)
            return this.l2b(((ArrayType) tp).down(), rmap).up();
        if (tp instanceof PrimitiveType)
            return tp;
        if (tp instanceof TypeModel)
            return tp;
        if (tp instanceof VariableType)
            return ((ClassModel) ((PackageModel) this.stub().packages().get(
                TVAR)).classes().get(new ClassName(((VariableType) tp).name())))
                .newType();
        LocType ltp = (LocType) tp;
        LocPackage lpkg = ltp.clazz().pkg();
        ClassName lname = ltp.clazz().name().nopkg();
        if (ltp.clazz().pkg().root().isSelf())
            return ((ClassModel) ((PackageModel) this.stub().packages().get(
                lpkg.name())).classes().get(lname)).newType();
        else
            return ((ClassModel) ((PackageModel) lpkg.root().unit().built()
                .packages().get(lpkg.name())).classes().get(lname)).newType()
                .replace((ReplaceShape) rmap.get((Local) lpkg.root()));
    }
}
