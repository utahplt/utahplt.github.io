/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-unitdriver0 outjiazzi.Main */

package edu.utah.jiazzi.driver;

import java.io.File;

import edu.utah.jiazzi.unit.AtomUnit;
import edu.utah.jiazzi.unit.Unit;
import edu.utah.jiazzi.unit.UnitEnvironment;
import edu.utah.jiggy.clazz.ClassModel;
import edu.utah.jiggy.clazz.PackageModel;
import edu.utah.jiggy.meta.name.ClassName;
import edu.utah.jiggy.meta.name.PackageName;

public class Main {
    private static void usage() {
        System.err.println(
            "Normal usage::\n"
            //
            + "First arg: name of the unit directory\n"
            //
            + "Second arg: what you want to do:\n\n"
            + ("  `-stub' 1) Generate import stubs for the specified unit.\n")
            + ("          Iterates through the signature files within a"
                    + " specific build and\n")
            + ("          creates Java stubs for imported classes not found in"
                    + " the CLASSPATH.\n")
            + ("          These stubs are needed for compiling a unit's"
                    + " implementation.\n")
            + ("          The stubs are output to `stubs.jar'.\n")
            + ("          2) Produce stubs for the classes that exported from"
                    + " an atomic unit.\n")
            + ("          This happens when Jiazzi cannot find source code for"
                    + " the class\n")
            + ("          implementation.  If source files exist, Jiazzi won't"
                    + " overwrite them.\n\n")
            //
            + ("  `-link' Link specified unit (third arg) together.\n")
            + ("          The unit may be atomic or compound.\n\n")
            //
            + ("  `-dis'  Link unit together (like `-link'), then"
                    + " disassemble the class named\n")
            + ("          by the fourth and fifth args.  The output is sent to"
                    + " stdout.\n\n")
            //
            + "Third arg: the base name of the unit file\n"
            //
            + ("Fourth arg: the package of the class to be disassembled"
                    + " (only for `-dis')\n")
            //
            + ("Fifth arg: the name of the class to be disassembled"
                    + " (only for `-dis')\n")
            //
            + "\nFor version information, use one argument only: `-v'.");
        System.exit(1);
    }

    public static void main(String args[]) {
        // Check before getting the unit directory name (or `-v').
        if (args.length < 1) {
            usage();
        }

        if (args[0].equals("-v")) {
            System.out.println("Jiazzi version " + Version.getVersion());
            System.exit(0);
        }

        final File dir = new File(args[0]);
        UnitEnvironment env = new MainUnitEnvironment(dir);

        // Check before getting the action.
        if (args.length < 2) {
            usage();
        }
        if (args[1].equals("-stub")) {
            if (args.length != 3) {
                usage();
            }
            Unit unit = env.findUnit(args[2]);
            if (unit == null) {
                System.err.println(args[2] + " failed");
                return;
            }
            unit.resolve(env);
            if (unit instanceof AtomUnit) {
                ((AtomUnit) unit).doStubs(env);
            } else {
                System.err.println(unit + " does not require stubs");
            }

        } else if (args[1].equals("-link")) {
            if (args.length != 3) {
                usage();
            }
            Unit unit = env.findUnit(args[2]);
            if (unit == null) {
                System.err.println(args[2] + " failed");
                return;
            }
            unit.build(env);
            // env.save(unit);

        } else if (args[1].equals("-dis")) {
            if (args.length != 5) {
                usage();
            }
            Unit unit = env.findUnit(args[2]);
            unit.build(env);
            PackageName pname = new PackageName(args[3]);
            ClassName cname = new ClassName(args[4]);
            ClassModel clazz = (ClassModel)
                ((PackageModel) unit.built().packages().get(pname)).classes()
                .get(cname);

            System.out.println(clazz.name().javaSource() + " extends "
                + clazz.newType().shape().zuper().name().javaSource());

            clazz.body().buildInstructions(clazz);
            clazz.body().dump(clazz, System.out);

            /*
             * for (Iterator<shape.Key> i =
             * clazz.body().fields().keySet().iterator(); i.hasNext(); i = i)
             * System.out.println(" " +
             * clazz.newType().shape().actualField(i.next()).javaSource("") +
             * ";"); for (Iterator<shape.Key> i =
             * clazz.body().methods().keySet().iterator(); i.hasNext(); i = i) {
             * shape.Key mthd = i.next(); bt.Method body =
             * clazz.body().methods().get(mthd); shape.Member shape; if
             * (mthd.nameType() == NameType.EMPTY) { shape =
             * clazz.newType().shape().actualInit(mthd); System.out.println(" " +
             * shape.javaSource("<init>")); } else { shape =
             * clazz.newType().shape().actualMethod(mthd); ClassType from =
             * (ClassType) clazz.newType().shape().freshMethod(mthd);
             * System.out.println(" " + shape.javaSource("<init>") + "
             * overrides from " + from); } if
             * (body.attributes().containsKey(BTAttr.CODE)) { bt.Code code =
             * (bt.Code) body.attributes().get(BTAttr.CODE);
             * code.instructions(clazz,mthd);
             * code.printInstructions(env.platform(), System.out); }
             * System.out.println(); }
             */

        } else
            throw new Error(args[1] + " unrecognized option");
    }
}
