/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package edu.utah.jiazzi.unit;

import java.io.*;

import edu.utah.jiazzi.parser.JLexer;
import edu.utah.jiazzi.parser.JParser;

// This class is effectively made concrete by the old `jiazzi.parser.sig'
// file.
public/* abstract */class Parser extends java.lang.Object {
    public void unitsignature_r(UnitEnvironment env, Unit unit) {
        try {
            env.lexer = this.lexer;
            env.parser = this.parser;
            this.parser.unitsignature_r(env, unit);
            env.lexer = null;
            env.parser = null;
        } catch (antlr.ANTLRException e) {
            env.fail();
            env.err().println(e.toString());
        }
    }

    public UnitSignature signature_r(UnitEnvironment env) {
        try {
            env.lexer = this.lexer;
            env.parser = this.parser;
            UnitSignature sig = this.parser.signature_r(env);
            env.lexer = null;
            env.parser = null;
            return sig;
        } catch (antlr.ANTLRException e) {
            env.fail();
            env.err().println(e.toString());
            return null;
        }
    }

    public void linkage_r(UnitEnvironment env, CompoundUnit unit) {
        try {
            env.lexer = this.lexer;
            env.parser = this.parser;
            this.parser.linkage_r(env, unit);
            env.lexer = null;
            env.parser = null;
        } catch (antlr.ANTLRException e) {
            env.fail();
            env.err().println(e.toString());
        }
    }

    public Unit unit_r(UnitEnvironment env) {
        try {
            env.lexer = this.lexer;
            env.parser = this.parser;
            Unit u = this.parser.unit_r(env);
            env.lexer = null;
            env.parser = null;
            return u;
        } catch (antlr.ANTLRException e) {
            env.fail();
            env.err().println(e.toString());
            return null;
        }
    }

    final JParser parser;
    final JLexer lexer;

    public Parser(UnitEnvironment env, InputStream input, String filename) {
        super();
        this.lexer = new JLexer(input);
        this.lexer.setFilename(filename);
        this.lexer.setEnvironment(env);
        this.parser = new JParser(this.lexer);
        this.parser.setEnvironment(env);
        // System.err.println("PARSER: " + this);
    }

    public String toString() {
        return this.lexer + " " + this.parser + " " + this.lexer.getFilename();
    }
}
