/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiazzi.core outunit.UnitSignature */

package edu.utah.jiazzi.unit;

import java.util.*;

import edu.utah.jiggy.meta.name.ClassName;
import edu.utah.jiggy.meta.name.ExpandedName;
import edu.utah.jiggy.meta.name.PackageName;
import edu.utah.jiggy.meta.name.ReplaceName;
import edu.utah.jiggy.meta.name.VariableName;
import edu.utah.jiggy.meta.shape.ProcedureShape;

public class UnitSignature extends UnitRoot {
    private final String name;
    private final UnitPackage self;
    // private final Set<UnitPackage> supers =
    // new HashSet<UnitPackage>();
    private final Set supers = new HashSet();
    // private final Set<UnitPackage> READ_supers =
    // Collections.unmodifiableSet(this.supers);
    private final Set READ_supers = Collections.unmodifiableSet(this.supers);

    // public Map<String,VariableName> lexemes = new
    // HashMap<String,VariableName>();
    // public Map<String,ArgVar> argVars = new HashMap<String,ArgVar>();
    public Map lexemes = new HashMap();
    public Map argVars = new HashMap();

    public VariableName findNameVar(String key) {
        if (this.lexemes.containsKey(key))
            return (VariableName) this.lexemes.get(key);
        for (Iterator i = this.supers().iterator(); i.hasNext(); /* i = i */) {
            UnitPackage upkg = (UnitPackage) i.next();
            if (upkg.sig() == null)
                continue;
            VariableName var = upkg.sig().findNameVar(key);
            if (var != null)
                return var;
        }
        return null;
    }

    public boolean bindNameVar(String vname, ExpandedName exp) {
        boolean pass = false;
        for (Iterator i = this.supers().iterator(); i.hasNext(); /* i = i */) {
            UnitPackage spkg = (UnitPackage) i.next();
            if (spkg.sig().lexemes().containsKey(vname)) {
                VariableName var;
                var = (VariableName) spkg.sig().lexemes().get(vname);
                spkg.bind(var, exp);
                pass = true;
            }
            pass = spkg.sig().bindNameVar(vname, exp) || pass;
        }
        return pass;
    }

    public ArgVar findArgVar(String key) {
        if (this.argVars.containsKey(key))
            return (ArgVar) this.argVars.get(key);
        for (Iterator i = this.supers().iterator(); i.hasNext(); /* i = i */) {
            UnitPackage upkg = (UnitPackage) i.next();
            if (upkg.sig() == null)
                continue;
            ArgVar var = upkg.sig().findArgVar(key);
            if (var != null)
                return var;
        }
        return null;
    }

    public boolean bindArgVar(String vname, ProcedureShape proc) {
        boolean pass = false;
        for (Iterator i = this.supers().iterator(); i.hasNext(); /* i = i */) {
            UnitPackage spkg = (UnitPackage) i.next();
            if (spkg.sig().argVars().containsKey(vname)) {
                ArgVar var;
                var = (ArgVar) spkg.sig().argVars().get(vname);
                spkg.bind(var, proc);
                pass = true;
            }
            pass = spkg.sig().bindArgVar(vname, proc) || pass;
        }
        return pass;
    }

    // public Map<String,VariableName> READ_lexemes =
    // Collections.unmodifiableMap(this.lexemes);
    // public Map<String,ArgVar> READ_argVars =
    // Collections.unmodifiableMap(this.argVars);
    public Map READ_lexemes = Collections.unmodifiableMap(this.lexemes);
    public Map READ_argVars = Collections.unmodifiableMap(this.argVars);

    public Map lexemes() {
        return this.READ_lexemes;
    }

    public Map argVars() {
        return this.READ_argVars;
    }

    public VariableName newLexeme(String name) {
        VariableName var = new VariableName(name);
        if (this.lexemes.put(name, var) != null)
            throw new Error();
        return var;
    }

    public ArgVar newArgVar(String name) {
        ArgVar var = new ArgVar(name);
        if (this.argVars.put(name, var) != null)
            throw new Error();
        return var;
    }

    public void missClass(ClassName clazz) {
        UnitPackage upkg = (UnitPackage) this.packages().get(clazz.pkg());
        if (!upkg.isParam()) {
            System.err.println(this + " " + clazz + " "
                + upkg.classes().keySet());
            if (upkg == this.self())
                for (Iterator i = this.supers.iterator();
                     i.hasNext();
                     /* i = i */) {
                    UnitPackage zpkg = (UnitPackage) i.next();
                    System.err.println(zpkg + " " + zpkg.classes().keySet());
                }
            super.missClass(clazz);
        }
        new UnitClass(upkg, clazz.nopkg());
    }

    public Set supers() {
        return this.READ_supers;
    }

    public String name() {
        return this.name;
    }

    public UnitSignature(String name) {
        super();
        this.name = name;
        this.self = new UnitPackage(this, new PackageName("$self"));
    }

    public UnitPackage self() {
        return self;
    }

    // private final Set<UnitPackage> params = new HashSet<UnitPackage>();
    // private final Set<UnitPackage> params_READ =
    // Collections.unmodifiableSet(this.params);
    private final Set params = new HashSet();
    private final Set params_READ = Collections.unmodifiableSet(this.params);

    public Set params() {
        return this.params_READ;
    }

    public void makeParam(UnitPackage upkg) {
        if (upkg.root() != this)
            throw new Error();
        if (upkg.isSuper() || upkg.isParam() || upkg.isSelf())
            throw new Error();
        this.params.add(upkg);
    }

    public void makeSuper(UnitPackage upkg) {
        if (upkg.sig() == null)
            throw new Error();
        if (upkg.root() != this)
            throw new Error();
        if (upkg.isSuper() || upkg.isParam() || upkg.isSelf())
            throw new Error();
        this.supers.add(upkg);
    }

    public void resolve(UnitEnvironment env) {
        // System.err.println("RESOLVE: " + this + " " +
        // this.self().classes().keySet() + " " + this.supers() +
        // (this.supers().size() > 0 ?
        // ""+this.supers().iterator().next().classes().keySet() : ""));
        for (Iterator i = this.supers().iterator(); i.hasNext(); /* i = i */) {
            UnitPackage zpkg = (UnitPackage) i.next();

            if (zpkg.signature == null)
                throw new Error(zpkg + " has null signature?");
            if (zpkg.signature != null)
                zpkg.bind(zpkg.signature.self(), this.self());

            zpkg.setDefaults(this);
            ReplaceName z2s = new ReplaceName();

            for (Iterator k = zpkg.lexemeBindings().keySet().iterator();
                 k.hasNext();
                 /* k = k */) {
                VariableName var = (VariableName) k.next();
                z2s.map(var, (ExpandedName) zpkg.lexemeBindings().get(var));
            }
            for (Iterator j = zpkg.sig().self().classes().values().iterator();
                 j.hasNext();
                 /* j = j */) {
                UnitClass ucls = (UnitClass) j.next();
                ClassName cname = ucls.name().nopkg().replace(z2s);
                if (this.self().classes().containsKey(cname))
                    continue;
                new UnitClass(this.self(), cname);
            }
        }
        for (Iterator i = this.supers().iterator(); i.hasNext(); /* i = i */) {
            UnitPackage zpkg = (UnitPackage) i.next();
            // System.err.println("XXX: " + this + " " +
            // this.self.classes().keySet() + " " +
            // zpkg.sig().self().classes().keySet());
            zpkg.resolve(env, UnitPackage.SHAPE_RESOLVED);
            if (zpkg.classes().size() != zpkg.sig().self().classes().size()) {
                throw new Error(zpkg.classes().keySet() + " vs. "
                    + zpkg.sig().self().classes().keySet());
            }
        }
        for (Iterator i = this.supers().iterator(); i.hasNext(); /* i = i */) {
            UnitPackage zpkg = (UnitPackage) i.next();
            for (Iterator j = zpkg.classes().values().iterator();
                 j.hasNext();
                 /* j = j */) {
                UnitClass zcls = (UnitClass) j.next();
                if (!this.self().classes().containsKey(zcls.name().nopkg()))
                    new UnitClass(this.self(), zcls.name().nopkg());
                UnitClass scls = (UnitClass) this.self().classes().get(
                    zcls.name().nopkg());
                if (!zcls.isShapeSet())
                    throw new Error("why hasn't " + zcls + " in "
                        + zpkg.signature + " been assigned?");
                if (!scls.isShapeSet())
                    scls.setShape(zcls.shape());
                else
                    scls.shape().add(zcls.shape());
            }
        }
        for (Iterator i = this.supers().iterator(); i.hasNext(); /* i = i */) {
            UnitPackage zpkg = (UnitPackage) i.next();
            for (Iterator j = zpkg.classes().values().iterator();
                 j.hasNext();
                 /* j = j */) {
                UnitClass zcls = (UnitClass) j.next();
                UnitClass scls = (UnitClass) this.self().classes().get(
                    zcls.name().nopkg());
                if ((scls.newType().shape().zuper() == null || ((scls.newType()
                    .shape().zuper().equals(env.platform().findClass(
                    new ClassName("java.lang.Object")))) && zcls.newType()
                    .shape().zuper() != null))
                    && zcls.newType().shape().zuper() != null) {
                    scls.shape().setZuper(zcls.newType().shape().zuper());
                } else if ((zcls.newType().shape().zuper() == null)
                    || (zcls.newType().shape().zuper().equals(env.platform()
                        .findClass(new ClassName("java.lang.Object"))))) {
                    ;
                } else if (!zcls.newType().shape().zuper().equals(
                    scls.newType().shape().zuper())) {
                    env.fail();
                    env.err().println(
                        scls + "'s super class "
                            + scls.newType().shape().zuper()
                            + " conflicts with super signature " + zpkg + " "
                            + zpkg.signature.name() + " "
                            + zcls.newType().shape().zuper());
                }
            }
        }
        for (Iterator i = this.self().classes().values().iterator();
             i.hasNext();
             /* i = i */) {
            UnitClass scls = (UnitClass) i.next();
            if (!scls.isShapeSet()) {
                for (Iterator j = this.supers().iterator();
                     j.hasNext();
                     /* j = j */) {
                    UnitPackage zpkg = (UnitPackage) j.next();
                    System.err.println(zpkg + " " + zpkg.sig().self().classes()
                        + " " + zpkg.classes().values());
                }
                throw new Error(scls + " has no shape set!");
            }
        }
    }

    public String toString() {
        return "signature \"" + this.name() + "\"";
    }

    public long modified(UnitEnvironment env) {
        long m = env.modified((UnitSignature) this);
        for (Iterator i = this.supers().iterator(); i.hasNext(); /* i = i */) {
            long m0 = ((UnitPackage) i.next()).signature.modified(env);
            if (m0 > m)
                m = m0;
        }
        return m;
    }
}
