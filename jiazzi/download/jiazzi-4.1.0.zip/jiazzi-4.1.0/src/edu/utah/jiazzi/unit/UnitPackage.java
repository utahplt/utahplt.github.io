/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package edu.utah.jiazzi.unit;

import java.util.*;

import edu.utah.jiggy.meta.flag.FlagConstants;
import edu.utah.jiggy.meta.name.ClassName;
import edu.utah.jiggy.meta.name.ExpandedName;
import edu.utah.jiggy.meta.name.PackageName;
import edu.utah.jiggy.meta.name.VariableName;
import edu.utah.jiggy.meta.shape.ClassShape;
import edu.utah.jiggy.meta.shape.ProcedureShape;
import edu.utah.jiggy.meta.shape.ReplaceShape;
import edu.utah.jiggy.meta.type.ClassType;
import edu.utah.jiggy.meta.type.PackageType;
import edu.utah.jiggy.meta.type.RefType;
import edu.utah.jiggy.meta.type.Root;
import edu.utah.jiggy.meta.type.TypeType;
import edu.utah.jiggy.meta.type.VariableType;

public class UnitPackage extends PackageType {
    protected final PackageName name;
    protected final UnitRoot root;

    void missClass(ClassName name) {
        this.root().missClass(name.setPackage(this.name()));
    }

    protected final Map classes = new HashMap() {
        // public UnitClass get(ClassName clazz)
        public Object get(Object obj) {
            ClassName clazz = (ClassName) obj;
            clazz = clazz.nopkg();
            if (this.containsKey(clazz))
                return (UnitClass) super.get(clazz);
            missClass(clazz);
            if (!this.containsKey(clazz))
                throw new Error(clazz + " was not really added to " + this);
            return (UnitClass) super.get(clazz);
        }
    };

    public ClassType findClass(ClassName name) {
        return ((UnitClass) this.classes.get(name.nopkg())).newType();
    }

    public boolean containsClassInternal(ClassName name) {
        return this.classes.containsKey(name.nopkg());
    }

    // protected final Map<ClassName,clazz.Class> READ_classes =
    // Collections.unmodifiableMap(this.classes);
    protected final Map READ_classes = Collections
        .unmodifiableMap(this.classes);

    // public String toString() { return this.root.toString() + ":" +
    // this.name().toString(); }

    public UnitPackage(UnitRoot root, PackageName name) {
        this.name = name;
        this.root = root;
        if (((UnitRoot) root).packages.put(name, (UnitPackage) this) != null)
            throw new Error("package " + name + " already exists in " + root);
        // Below here,
        // From `edu.utah.jiazzi.core/outunit/Package.java'.
        if (name.equals(PackageName.ANONYMOUS)) {
            throw new Error("\"" + name + "\" is empty?");
        }
    }

    public void detach() {
        if (this.root().packages.remove(this.name) != this)
            throw new Error();
    }

    public Map classes() {
        return this.READ_classes;
    }

    public PackageName name() {
        return this.name;
    }

    public UnitRoot root() {
        return this.root;
    }

    public Root root0() {
        return this.root();
    }

    // Below here,
    // From `edu.utah.jiazzi.core/outunit/Package.java'.

    protected UnitSignature signature;
    public UnitPackage extended;
    public UnitPackage extending;

    public boolean visible = true;

    // public Map<ArgVar,ProcedureShape> argVarBindings = new
    // HashMap<ArgVar,ProcedureShape>();
    // public Map<VariableName,ExpandedName> lexemeBindings = new
    // HashMap<VariableName,ExpandedName>();
    // public Map<VariableType,RefType> genericBindings = new
    // HashMap<VariableType,RefType>();
    // public Map<UnitPackage,PackageType> pkgBindings = new
    // HashMap<UnitPackage,PackageType>();
    public Map argVarBindings = new HashMap();
    public Map lexemeBindings = new HashMap();
    public Map genericBindings = new HashMap();
    public Map pkgBindings = new HashMap();

    // private Map<ArgVar,ProcedureShape> READ_argVarBindings =
    // Collections.unmodifiableMap(this.argVarBindings);
    // private Map<VariableName,ExpandedName> READ_lexemeBindings =
    // Collections.unmodifiableMap(this.lexemeBindings);
    // private Map<VariableType,RefType> READ_genericBindings =
    // Collections.unmodifiableMap(this.genericBindings);
    // private Map<UnitPackage,PackageType> READ_pkgBindings =
    // Collections.unmodifiableMap(this.pkgBindings);
    private Map READ_argVarBindings = Collections
        .unmodifiableMap(this.argVarBindings);
    private Map READ_lexemeBindings = Collections
        .unmodifiableMap(this.lexemeBindings);
    private Map READ_genericBindings = Collections
        .unmodifiableMap(this.genericBindings);
    private Map READ_pkgBindings = Collections
        .unmodifiableMap(this.pkgBindings);

    // public Map<ArgVar,ProcedureShape> argVarBindings() { return
    // this.READ_argVarBindings; }
    // public Map<VariableName,ExpandedName> lexemeBindings() { return
    // this.READ_lexemeBindings; }
    // public Map<VariableType,RefType> genericBindings() { return
    // this.READ_genericBindings; }
    // public Map<UnitPackage,PackageType> pkgBindings() { return
    // this.READ_pkgBindings; }
    public Map argVarBindings() {
        return this.READ_argVarBindings;
    }

    public Map lexemeBindings() {
        return this.READ_lexemeBindings;
    }

    public Map genericBindings() {
        return this.READ_genericBindings;
    }

    public Map pkgBindings() {
        return this.READ_pkgBindings;
    }

    public boolean isOpen() {
        return false;
    }

    public UnitOpen open() {
        return null;
    }

    public void bind(ArgVar var, ProcedureShape proc) {
        if (this.argVarBindings.containsKey(var))
            throw new Error();
        this.argVarBindings.put(var, proc);
    }

    public boolean isBound(ArgVar var) {
        return this.argVarBindings.containsKey(var);
    }

    public ProcedureShape bindingFor(ArgVar var) {
        return (ProcedureShape) this.argVarBindings.get(var);
    }

    public void bind(VariableName var, ExpandedName exp) {
        if (this.lexemeBindings.containsKey(var))
            throw new Error();
        this.lexemeBindings.put(var, exp);
    }

    public boolean isBound(VariableName var) {
        return this.lexemeBindings.containsKey(var);
    }

    public ExpandedName bindingFor(VariableName var) {
        return (ExpandedName) this.lexemeBindings.get(var);
    }

    public void bind(VariableType var, RefType ref) {
        if (this.genericBindings.containsKey(var))
            throw new Error();
        this.genericBindings.put(var, ref);
    }

    public boolean isBound(VariableType var) {
        return this.genericBindings.containsKey(var);
    }

    public TypeType bindingFor(VariableType var) {
        return (TypeType) this.genericBindings.get(var);
    }

    public void bind(UnitPackage upkg, PackageType tpkg) {
        if (this.pkgBindings.containsKey(upkg))
            throw new Error();
        this.pkgBindings.put(upkg, tpkg);
    }

    public boolean isBound(UnitPackage var) {
        return this.pkgBindings.containsKey(var);
    }

    public PackageType bindingFor(UnitPackage var) {
        return (PackageType) this.pkgBindings.get(var);
    }

    public String preface() {
        if (this.root() instanceof Unit)
            return (this.isOpen() ? "open " : "")
                + (this.isImport() ? "imported "
                        : this.isExport() ? "exported "
                        : "*unknown* ");
        else if (this.isParam())
            return "parameter ";
        else if (this.isSuper())
            return "super ";
        else
            return "";
    }

    public String toString() {
        return this.preface() + "package \"" + this.name() + "\"";
    }

    protected boolean isResolved = false;

    protected Unit unit() {
        return (Unit) this.root();
    }

    protected UnitSignature sig0() {
        return (UnitSignature) this.root();
    }

    public void setSignature(UnitSignature sig) {
        this.signature = sig;
    }

    public void setExtended(UnitPackage pkg) {
        if (this.extended != null)
            throw new Error();
        if (pkg.extending != null)
            throw new Error();
        this.extended = pkg;
        pkg.extending = (UnitPackage) this;
    }

    public UnitSignature sig() {
        return this.signature;
    }

    public boolean exists() {
        return this.isImport() || this.isExport();
    }

    public boolean isExport() {
        return this.unit().exports().contains((UnitPackage) this);
    }

    public boolean isImport() {
        return this.unit().imports().contains((UnitPackage) this);
    }

    public boolean isSelf() {
        return this.sig0().self() == this;
    }

    public boolean isParam() {
        if (this.root() instanceof UnitSignature)
            return this.sig0().params().contains((UnitPackage) this);
        else
            return true;
    }

    public boolean isSuper() {
        return this.sig0().supers().contains((UnitPackage) this);
    }

    /*
     * public boolean isNoport() { return
     * this.root().noports().contains((UnitPackage) this); }
     */
    public UnitPackage extended() {
        return this.extended;
    }

    public static final int UNRESOLVED = 0;
    public static final int CLASS_RESOLVED = 1;
    public static final int SHAPE_RESOLVED = 2;
    public static final int FULL_RESOLVED = 3;

    int state = UNRESOLVED;

    public boolean containsClass(ClassName cname) {
        if (this.root() instanceof UnitSignature && this.isParam())
            return true;
        else
            return containsClassInternal(cname);
    }

    public void setDefaults(UnitRoot root) {
        if (this.extending != null)
            this.extending.setDefaults(root);
        if (this.signature == null) {
            if (this.extending != null) {
                this.argVarBindings.putAll(this.extending.argVarBindings);
                this.lexemeBindings.putAll(this.extending.lexemeBindings);
                this.genericBindings.putAll(this.extending.genericBindings);
                this.pkgBindings.putAll(this.extending.pkgBindings);
            }
            return;
        }
        for (Iterator i = this.signature.supers().iterator();
             i.hasNext();
             /* i = i */) {
            UnitPackage spkg = (UnitPackage) i.next();
            this.lexemeBindings.putAll(spkg.lexemeBindings);
            this.argVarBindings.putAll(spkg.argVarBindings);
        }
        for (Iterator i = this.signature.lexemes().values().iterator();
             i.hasNext();
             /* i = i */) {
            VariableName var = (VariableName) i.next();
            if (this.isBound(var))
                continue;
            else if (this.extending != null && this.extending.isBound(var))
                this.bind(var, this.extending.bindingFor(var));
            else if (root instanceof UnitSignature) {
                UnitSignature sig = (UnitSignature) root;
                VariableName var0 = (VariableName) sig.lexemes.put(var.text(),
                    var);
                if (var0 != null && var0 != var)
                    throw new Error(root + " " + var + " " + var0);
            }
        }
        for (Iterator i = this.signature.argVars().values().iterator();
             i.hasNext();
             /* i = i */) {
            ArgVar var = (ArgVar) i.next();
            if (this.isBound(var))
                continue;
            else if (this.extending != null && this.extending.isBound(var))
                this.bind(var, this.extending.bindingFor(var));
            else if (root instanceof UnitSignature) {
                UnitSignature sig = (UnitSignature) root;
                ArgVar var0 = (ArgVar) sig.argVars.put(var.name(), var);
                if (var0 != null && var0 != var)
                    throw new Error(root + " " + var + " " + var0);
            }
        }
        for (Iterator i = this.signature.generics().values().iterator();
             i.hasNext();
             /* i = i */) {
            VariableType var = (VariableType) i.next();
            if (this.isBound(var))
                continue;
            else if (this.extending != null && this.extending.isBound(var))
                this.bind(var, (RefType) this.extending.bindingFor(var));
            else if (root.generics().containsKey(var.name()))
                this.bind(var, (VariableType) root.generics().get(var.name()));
        }
        for (Iterator i = this.signature.params().iterator();
             i.hasNext();
             /* i = i */) {
            UnitPackage var = (UnitPackage) i.next();
            if (this.isBound(var))
                continue;
            else if (this.extending != null && this.extending.isBound(var))
                this.bind(var, this.extending.bindingFor(var));
            else if (root.packages().containsKey(var.name()))
                this.bind(var, (UnitPackage) root.packages().get(var.name()));
        }
        return;
    }

    public void resolve(UnitEnvironment env, int tstate) {
        if (this.state >= tstate
            || (this.root() instanceof UnitSignature && this.isParam()))
            return;

        if (this.signature != null && this.state < CLASS_RESOLVED
            && tstate >= CLASS_RESOLVED) {
            /* populate with name bindings */
            for (Iterator i = this.signature.argVars().values().iterator();
                 i.hasNext();
                 /* i = i */) {
                ArgVar var = (ArgVar) i.next();
                if (false && !this.argVarBindings().containsKey(var)) {
                    env.fail();
                    env.err().println(
                        "argument parameter " + var + " of signature "
                            + this.signature.name() + " not bound for package "
                            + this);
                }
            }
            for (Iterator i = this.signature.lexemes().values().iterator();
                 i.hasNext();
                 /* i = i */) {
                VariableName var = (VariableName) i.next();
                if (false && !this.lexemeBindings().containsKey(var)) {
                    env.fail();
                    env.err().println(
                        "name parameter " + var + " of signature "
                            + this.signature.name() + " not bound for package "
                            + this);
                }
            }
        }
        ReplaceShape replace = new ReplaceShape();
        if (this.signature != null && this.state < SHAPE_RESOLVED) {
            for (Iterator i = this.signature.lexemes().values().iterator();
                 i.hasNext();
                 /* i = i */) {
                VariableName var = (VariableName) i.next();
                if (this.lexemeBindings().containsKey(var)) {
                    if (this.lexemeBindings().get(var) == null)
                        throw new Error();
                    replace.map(var, (ExpandedName) this.lexemeBindings().get(
                        var));
                }
            }
        }
        if (this.state < CLASS_RESOLVED && tstate >= CLASS_RESOLVED) {
            if (this.extended != null)
                this.extended.resolve(env, CLASS_RESOLVED);
            if (false && this.signature == null && this.extended == null) {
                env
                    .err()
                    .println(
                        "package "
                            + this
                            + " does not have package signature and does not inherit another package");
                env.fail();
            }
            if (this.extended != null)
                for (Iterator i = this.extended.classes().values().iterator();
                     i.hasNext();
                     /* i = i */)
                    new UnitClass((UnitPackage) this, ((UnitClass) i.next())
                        .name().nopkg());

            if (this.signature != null) {
                for (Iterator i = this.signature.self().classes().values()
                         .iterator();
                     i.hasNext();
                     /* i = i */) {
                    UnitClass scls = (UnitClass) i.next();
                    ClassName cname = (ClassName) scls.name().nopkg().replace(
                        replace);
                    if (this.extended == null
                        || !this.extended().classes()
                            .containsKey(cname.nopkg()))
                        new UnitClass((UnitPackage) this, cname.nopkg());
                }
            }
            this.state = CLASS_RESOLVED;
        }
        if (this.signature != null && this.state < SHAPE_RESOLVED
            && tstate >= SHAPE_RESOLVED) {
            /* populate with name bindings */

            for (Iterator i = this.signature.generics().values().iterator();
                 i.hasNext();
                 /* i = i */) {
                VariableType var = (VariableType) i.next();
                if (!this.genericBindings().containsKey(var)) {
                    env.fail();
                    env.err().println(
                        "generic " + var + " of signature "
                            + this.signature.name() + " not bound for package "
                            + this);
                } else {
                    if (this.genericBindings().get(var) == null)
                        throw new Error();
                    replace.map(var, (RefType) this.genericBindings().get(var));
                }
            }

            if (this.sig() != null
                && this.pkgBindings().containsKey(this.sig().self())) {
                replace.map(this.sig().self(), (PackageType) this.pkgBindings()
                    .get(this.sig().self()));
            }
            for (Iterator i = this.signature.params().iterator();
                 i.hasNext();
                 /* i = i */) {
                UnitPackage spkg = (UnitPackage) i.next();
                if (!this.pkgBindings().containsKey(spkg)) {
                    env.fail();
                    env.err().println(
                        spkg + " of " + this.signature + " not bound for "
                            + this);
                } else {
                    if (this.pkgBindings().get(spkg) == null)
                        throw new Error("bound to null: " + spkg + " of "
                            + this);
                    replace.map(spkg, (PackageType) this.pkgBindings()
                        .get(spkg));

                    PackageType ppkg = (PackageType) this.pkgBindings().get(
                        spkg);
                    if (ppkg instanceof UnitPackage) {
                        UnitPackage upkg = (UnitPackage) ppkg;
                        if (upkg.root() instanceof Unit) {
                            upkg.resolve(env, CLASS_RESOLVED);
                            for (Iterator j = spkg.classes().values()
                                     .iterator();
                                 j.hasNext();
                                 /* j = j */) {
                                UnitClass sclazz = (UnitClass) j.next();
                                ClassName cname = (ClassName) sclazz.name()
                                    .nopkg().replace(replace);
                                if (!upkg.containsClass(cname.nopkg())) {
                                    for (UnitPackage k = upkg;
                                         k != null;
                                         k = k.extended())
                                        System.err.println(k + " "
                                            + k.classes().keySet());

                                    env.fail();
                                    env.err().println(
                                        upkg + " does not contain class \""
                                            + cname.nopkg()
                                            + "\" required for " + spkg
                                            + " of " + this.signature);

                                } else {
                                    if (!sclazz.newType().replace(replace)
                                        .equals(upkg.findClass(cname.nopkg()))) {
                                        throw new Error(sclazz.newType()
                                            + " vs. "
                                            + upkg.findClass(cname.nopkg()));
                                    }
                                }
                            }
                        }
                    }
                }
            }
            for (Iterator i = this.signature.argVars().values().iterator();
                 i.hasNext();
                 /* i = i */) {
                ArgVar var = (ArgVar) i.next();
                if (this.argVarBindings().containsKey(var)) {
                    if (this.argVarBindings().get(var) == null)
                        throw new Error();
                    replace.map(var, (ProcedureShape) ((ProcedureShape) this
                        .argVarBindings().get(var)).replace(replace));
                }
            }
        }
        if (this.state < SHAPE_RESOLVED && tstate >= SHAPE_RESOLVED) {
            if (this.extended != null) {
                this.extended.resolve(env, SHAPE_RESOLVED);

                for (Iterator i = this.extended.classes().values().iterator();
                     i.hasNext();
                     /* i = i */) {
                    UnitClass eclazz = (UnitClass) i.next();
                    UnitClass uclazz = (UnitClass) this.classes().get(
                        eclazz.name().nopkg());
                    ClassShape shape = (ClassShape) eclazz.shape().copy();
                    uclazz.setShape(shape);
                }
            }
            if (this.signature != null) {
                for (Iterator i = this.signature.self().classes().values()
                         .iterator();
                     i.hasNext();
                     /* i = i */) {
                    UnitClass scls = (UnitClass) i.next();
                    if (!scls.isShapeSet())
                        throw new Error(scls + " shape not set yet?? "
                            + this.signature);

                    ClassName cname = ((ClassName) scls.name().nopkg().replace(
                        replace)).nopkg();
                    if (!this.classes().containsKey(cname))
                        new UnitClass((UnitPackage) this, cname);
                    UnitClass ucls = (UnitClass) this.classes().get(cname);
                    ClassShape shape;
                    try {
                        replace.set(scls.newType());
                        shape = scls.shape().replace(replace);
                        replace.set((ClassType) null);
                    } catch (Error e) {
                        System.err.println(this + " [" + ucls + "] [" + scls
                            + "] " + replace);
                        scls.shape()
                            .print(scls.newType(), "", System.err, null);
                        throw e;
                    }
                    if (!ucls.isShapeSet()) {
                        ucls.setShape(shape);
                    } else {
                        ucls.shape().add(shape);
                        /* must set super class if not set. */
                        if (ucls.newType().shape().zuper() == null)
                            ucls.shape().setZuper(
                                scls.newType().shape().zuper());
                    }
                }
                /*
                 * look at the previous bindings in the signature, propogate
                 * them to our bindings
                 */
                if (false) {
                    for (Iterator i = this.signature.self().lexemeBindings()
                             .keySet().iterator();
                         i.hasNext();
                         /* i = i */) {
                        VariableName var = (VariableName) i.next();
                        this.bind(var, ((ExpandedName) this.signature.self()
                            .lexemeBindings().get(var)).replace(replace));
                    }
                    for (Iterator i = this.signature.self().argVarBindings()
                             .keySet().iterator();
                         i.hasNext();
                         /* i = i */) {
                        ArgVar var = (ArgVar) i.next();
                        this.bind(var,
                            (ProcedureShape) ((ProcedureShape) this.signature
                                .self().argVarBindings().get(var))
                                .replace(replace));
                    }
                }
            }
            this.state = SHAPE_RESOLVED;
        }
        if (this.state < FULL_RESOLVED && tstate >= FULL_RESOLVED) {
            if (this.extended != null)
                this.extended.resolve(env, FULL_RESOLVED);
            for (Iterator i = this.classes().values().iterator();
                 i.hasNext();
                 /* i = i */) {
                UnitClass uclazz = (UnitClass) i.next();
                uclazz.resolve(env); /* resolve before making abstract... */
                if (this.extending != null) {
                    /*
                     * we are extended, so make all classes abstract
                     */
                    // uclazz.shape().set(flag.Constants.ABSTRACT);
                    /* never set shape to abstract... */
                }
                for (UnitPackage epkg = this.extended;
                     epkg != null;
                     epkg = epkg.extended) {
                    if (!epkg.classes().containsKey(uclazz.name().nopkg()))
                        break;
                    UnitClass eclazz = (UnitClass) epkg.classes().get(
                        uclazz.name().nopkg());
                    uclazz.shape().subtract(eclazz.shape());
                    if (epkg == this.extended) {
                        if (uclazz.shape().binaries().contains(
                            FlagConstants.INTERFACE))
                            uclazz.shape().addInterface(eclazz.newType());
                        else
                            uclazz.shape().setZuper(eclazz.newType());
                    }
                }
            }
            this.state = FULL_RESOLVED;
        }
    }
}
