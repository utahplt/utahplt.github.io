/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package edu.utah.jiazzi.loc;

import java.util.*;

import edu.utah.jiazzi.unit.ArgVar;
import edu.utah.jiazzi.unit.UnitClass;
import edu.utah.jiazzi.unit.UnitEnvironment;
import edu.utah.jiazzi.unit.UnitPackage;
import edu.utah.jiggy.clazz.PackageModel;
import edu.utah.jiggy.meta.name.ClassName;
import edu.utah.jiggy.meta.name.ExpandedName;
import edu.utah.jiggy.meta.name.PackageName;
import edu.utah.jiggy.meta.name.ReplaceName;
import edu.utah.jiggy.meta.name.VariableName;
import edu.utah.jiggy.meta.shape.ProcedureShape;
import edu.utah.jiggy.meta.shape.ReplaceShape;
import edu.utah.jiggy.meta.type.ClassType;
import edu.utah.jiggy.meta.type.PackageType;
import edu.utah.jiggy.meta.type.Root;

public class LocPackage extends PackageType {
    protected final PackageName name;
    protected final LocRoot root;

    void missClass(ClassName name) {
        this.root().missClass(name.setPackage(this.name()));
    }

    // protected final Map<ClassName,clazz.Class> classes =
    protected final Map classes = new HashMap() {
        // public LocClass get(ClassName clazz)
        public Object get(Object obj) {
            ClassName clazz = (ClassName) obj;
            clazz = clazz.nopkg();
            if (this.containsKey(clazz))
                return (LocClass) super.get(clazz);
            missClass(clazz);
            if (!this.containsKey(clazz))
                throw new Error(clazz + " was not really added to " + this);
            return (LocClass) super.get(clazz);
        }
    };

    public ClassType findClass(ClassName name) {
        return ((LocClass) this.classes.get(name.nopkg())).newType();
    }

    public boolean containsClass(ClassName name) {
        return this.classes.containsKey(name.nopkg());
    }

    // protected final Map<ClassName,clazz.Class> READ_classes =
    // Collections.unmodifiableMap(this.classes);
    protected final Map READ_classes = Collections
        .unmodifiableMap(this.classes);

    // public String toString() { return this.root.toString() + ":" +
    // this.name().toString(); }

    public LocPackage(LocRoot root, PackageName name) {
        this.name = name;
        this.root = root;
        if (((LocRoot) root).packages.put(name, (LocPackage) this) != null)
            throw new Error("package " + name + " already exists in " + root);
    }

    public void detach() {
        if (this.root().packages.remove(this.name) != this)
            throw new Error();
    }

    public Map classes() {
        return this.READ_classes;
    }

    public PackageName name() {
        return this.name;
    }

    public LocRoot root() {
        return this.root;
    }

    public Root root0() {
        return this.root();
    }

    // Below here,
    // From `edu.utah.jiazzi.core/outloc/Package.java'.

    public LocPackage extended;
    public LocPackage extending;

    // protected final Map<VariableName,ExpandedName> lexemeLinkage = new
    // HashMap<VariableName,ExpandedName>();
    // protected final Map<ArgVar,ProcedureShape> argVarLinkage = new
    // HashMap<ArgVar,ProcedureShape>();
    protected final Map lexemeLinkage = new HashMap();
    protected final Map argVarLinkage = new HashMap();

    // private final Map<VariableName,ExpandedName> READ_lexemeLinkage =
    // Collections.unmodifiableMap(this.lexemeLinkage);
    // private final Map<ArgVar,ProcedureShape> READ_argVarLinkage =
    // Collections.unmodifiableMap(this.argVarLinkage);
    private final Map READ_lexemeLinkage = Collections
        .unmodifiableMap(this.lexemeLinkage);
    private final Map READ_argVarLinkage = Collections
        .unmodifiableMap(this.argVarLinkage);

    public Map lexemeLinkage() {
        return this.READ_lexemeLinkage;
    }

    public Map argVarLinkage() {
        return this.READ_argVarLinkage;
    }

    public void link(VariableName var, ExpandedName exp) {
        if (this.lexemeLinkage.put(var, exp) != null)
            throw new Error(var + " " + exp + " alread linked");
    }

    public void link(ArgVar var, ProcedureShape p) {
        if (this.argVarLinkage.put(var, p) != null)
            throw new Error(var + " " + p + " alread linked");
    }

    public ExpandedName linkFor(VariableName var) {
        return (ExpandedName) this.lexemeLinkage.get(var);
    }

    public boolean isBound(UnitPackage upkg, VariableName var) {
        // if (upkg.isBound(var)) return true;
        if (upkg.sig() == null)
            return false;
        if (upkg.sig().self().isBound(var))
            return true;
        for (Iterator i = upkg.sig().supers().iterator();
             i.hasNext();
             /* i = i */) {
            if (((UnitPackage) i.next()).isBound(var))
                return true;
        }
        return false;
    }

    public boolean isBound(UnitPackage upkg, ArgVar var) {
        // if (upkg.isBound(var)) return true;
        if (upkg.sig() == null)
            return false;
        if (upkg.sig().self().isBound(var))
            return true;
        for (Iterator i = upkg.sig().supers().iterator();
             i.hasNext();
             /* i = i */) {
            if (((UnitPackage) i.next()).isBound(var))
                return true;
        }
        return false;
    }

    public boolean orig(VariableName var) {
        // System.err.print(var + " " + this + " " + this.upkg().isExport());
        if (!this.upkg().isExport())
            return false;
        // System.err.print(" " + this.isBound(this.upkg(), var));
        if (!this.isBound(this.upkg(), var))
            return false;
        // System.err.print(" " + this.upkg().extended());
        if (this.upkg().extended == null)
            return true;
        LocPackage epkg = (LocPackage) this.root().packages().get(
            this.upkg().extended.name());
        // System.err.print(" " + epkg + " " + this.isBound(epkg.upkg(), var));
        if (this.isBound(epkg.upkg(), var))
            return false;
        return true;
    }

    public boolean orig(ArgVar var) {
        // System.err.print(var + " " + this + " " + this.upkg().isExport());
        if (!this.upkg().isExport())
            return false;
        // System.err.print(" " + this.isBound(this.upkg(), var));
        if (!this.isBound(this.upkg(), var))
            return false;
        // System.err.print(" " + this.upkg().extended());
        if (this.upkg().extended == null)
            return true;
        LocPackage epkg = (LocPackage) this.root().packages().get(
            this.upkg().extended.name());
        // System.err.print(" " + epkg + " " + this.isBound(epkg.upkg(), var));
        if (this.isBound(epkg.upkg(), var))
            return false;
        return true;
    }

    public boolean fresh(VariableName var) {
        UnitPackage upkg = this.upkg();
        if (!upkg.isExport())
            return false;
        if (upkg.sig().lexemes().get(var.text()) != var)
            return false;
        if (upkg.extended == null)
            return true;
        if (upkg.extended.sig().lexemes().get(var.text()) == var)
            return false;
        return true;
    }

    public boolean fresh(ArgVar var) {
        UnitPackage upkg = this.upkg();
        if (!upkg.isExport())
            return false;
        if (upkg.sig().argVars().get(var.name()) != var)
            return false;
        if (upkg.extended == null)
            return true;
        if (upkg.extended.sig().argVars().get(var.name()) == var)
            return false;
        return true;
    }

    public ProcedureShape linkFor(ArgVar var) {
        return (ProcedureShape) this.argVarLinkage.get(var);
    }

    public boolean isLinked(VariableName var) {
        return this.lexemeLinkage.containsKey(var);
    }

    public boolean isLinked(ArgVar var) {
        return this.argVarLinkage.containsKey(var);
    }

    public void u2lName(ReplaceName u2l, UnitEnvironment env) {
        for (Iterator i = this.lexemeLinkage().keySet().iterator();
             i.hasNext();
             /* i = i */) {
            VariableName var = (VariableName) i.next();
            u2l.map(var, (ExpandedName) this.lexemeLinkage.get(var));
        }
    }

    public void u2lArg(ReplaceShape u2l, UnitEnvironment env) {
        for (Iterator i = this.argVarLinkage().keySet().iterator();
             i.hasNext();
             /* i = i */) {
            ArgVar var = (ArgVar) i.next();
            u2l.map(var, (ProcedureShape) this.argVarLinkage().get(var));
        }
    }

    boolean isResolved = false;

    // public final Set<name.Class> fresh = new HashSet<name.Class>();
    public final Set fresh = new HashSet();

    public UnitPackage upkg() {
        return (UnitPackage) this.root().unit().packages().get(this.name());
    }

    public PackageModel rpkg() {
        if (this.isSource())
            return (PackageModel) this.root().unit().built().packages().get(
                this.name());
        else
            return (PackageModel) this.root().unit().stub().packages().get(
                this.name());
    }

    public boolean isSource() {
        if (this.root().isSelf())
            return this.upkg().isImport();
        else
            return this.upkg().isExport();
    }

    public String toString() {
        return this.root().toString() + '@' + this.name();
    }

    public boolean isSink() {
        return !this.isSource();
    }

    public boolean isOpen() {
        return this.upkg().isOpen();
    }

    public LocPackage in() {
        return (LocPackage) this.root().packages().get(
            this.upkg().open().in().name());
    }

    public LocPackage out() {
        return (LocPackage) this.root().packages().get(
            this.upkg().open().out().name());
    }

    public LocPackage lextended() {
        if (this.extended == null)
            return null;
        return (LocPackage) this.root().packages().get(
            this.upkg().extended().name());
    }

    public LocPackage lextending() {
        if (this.extending == null)
            return null;
        return (LocPackage) this.root().packages().get(
            this.upkg().extending.name());
    }

    public void setExtended(LocPackage epkg) {
        if (!epkg.isSource())
            throw new Error();
        if (this.extended != null)
            throw new Error("extended of " + this + " arleady " + this.extended
                + " so cannot set to " + epkg);
        this.extended = epkg;
        if (this.isSource()) {
            if (epkg.extending != null)
                throw new Error("extending of " + epkg + " already "
                    + epkg.extending + " so cannot be set to " + this);
            epkg.extending = (LocPackage) this;
        }
    }

    public void doDefaultLink(UnitEnvironment env) {

    }

    public void resolveInit(UnitEnvironment env) {
        if (this.isResolved)
            return;
        this.isResolved = true;
        ReplaceName u2l = new ReplaceName();
        this.root().u2lName(u2l, env);

        this.upkg().resolve(env, UnitPackage.SHAPE_RESOLVED);

        for (Iterator j = this.upkg().classes().keySet().iterator();
             j.hasNext();
             /* j = j */) {
            ClassName cname = ((ClassName) j.next()).nopkg().replace(u2l);
            LocClass lcls = new LocClass((LocPackage) this, cname.nopkg());
            this.fresh.add(lcls.name().nopkg());
        }
        for (UnitPackage epkg = this.upkg().extended;
             epkg != null;
             epkg = epkg.extended) {
            epkg.resolve(env, UnitPackage.SHAPE_RESOLVED);
            for (Iterator j = epkg.classes().values().iterator();
                 j.hasNext();
                 /* j = j */) {
                UnitClass ucls = (UnitClass) j.next();
                ClassName cname = ucls.name().nopkg().replace(u2l);
                LocClass lcls = (LocClass) this.classes().get(cname);
                this.fresh.remove(lcls.name().nopkg());
            }
        }
    }
}
