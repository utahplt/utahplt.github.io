/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package edu.utah.jiazzi.unit;

import java.util.*;
import java.io.*;

import edu.utah.jiazzi.parser.JLexer;
import edu.utah.jiazzi.parser.JParser;
import edu.utah.jiggy.clazz.ClassModel;
import edu.utah.jiggy.clazz.ModelRoot;
import edu.utah.jiggy.meta.shape.ReplaceShape;
import edu.utah.jiggy.meta.type.Environment;

public abstract class UnitEnvironment extends Object {
    // final Map<String,unit.Unit> units = new HashMap<String,unit.Unit>();
    // final Map<String,unit.UnitSignature> sigs = new
    // HashMap<String,unit.UnitSignature>();
    // final Set<String> unitsReading = new HashSet<String>();
    // final Set<String> sigsReading = new HashSet<String>();
    final Map units = new HashMap();
    final Map sigs = new HashMap();
    final Set unitsReading = new HashSet();
    final Set sigsReading = new HashSet();

    public long modified(UnitSignature sig) {
        return 0l;
    }

    public long modified(Unit unit) {
        return 0l;
    }

    public long modified(ModelRoot root) {
        return 0l;
    }

    public ModelRoot newBuilt(Unit unit) {
        throw new Error();
    }

    public ModelRoot newStub(Unit unit) {
        throw new Error();
    }

    public ModelRoot loadRaw(AtomUnit unit, ModelRoot stub) {
        throw new Error();
    }

    public ModelRoot loadBuilt(Unit unit, ModelRoot stub) {
        throw new Error();
    }

    public void save(Unit unit) {
        throw new Error();
    }

    public void copyInto(ModelRoot from, ModelRoot to, ReplaceShape replace) {
        throw new Error();
    }

    public Environment platform() {
        throw new Error();
    }

    public Unit findUnit(String name) {
        if (this.units.containsKey(name))
            return (Unit) this.units.get(name);
        if (this.unitsReading.contains(name))
            throw new Error("already trying to read unit " + name);
        this.unitsReading.add(name);
        Unit unit = this.missUnit(name);
        if (this.hasFailed())
            return null;
        unit.resolve((UnitEnvironment) this);
        this.units.put(name, unit);
        this.unitsReading.remove(name);
        return unit;
    }

    public UnitSignature findSignature(String name) {
        if (this.sigs.containsKey(name))
            return (UnitSignature) this.sigs.get(name);
        if (this.sigsReading.contains(name))
            throw new Error("already trying to read signature " + name);
        this.sigsReading.add(name);
        UnitSignature sig = this.missSignature(name);
        sig.resolve((UnitEnvironment) this);
        this.sigs.put(name, sig);
        this.sigsReading.remove(name);
        return sig;
    }

    protected Unit missUnit(String name) {
        throw new Error("cannot find unit " + name);
    }

    protected UnitSignature missSignature(String name) {
        throw new Error("cannot find signature " + name);
    }

    public String getSource(ClassModel cls) {
        return "";
    }

    public void setSource(ClassModel cls, String name) {
    }

    public UnitEnvironment() {
        super();
    }

    public abstract PrintStream skeleton(UnitClass clazz);

    public abstract void stubs(AtomUnit atom);

    public PrintStream err() {
        throw new Error();
    }

    private boolean failed = false;
    // private final ArrayList<String> errorPrefaces = new ArrayList<String>();
    private final ArrayList errorPrefaces = new ArrayList();

    public void pushErrorPreface(String msg) {
        this.errorPrefaces.add(msg);
    }

    public void popErrorPreface() {
        this.errorPrefaces.remove(this.errorPrefaces.size() - 1);
    }

    public String errorPrefaceInternal() {
        if (this.errorPrefaces.isEmpty())
            return "null";
        return (String) this.errorPrefaces.get(this.errorPrefaces.size() - 1);
    }

    public boolean hasFailed() {
        return this.failed;
    }

    public void fail() {
        this.failed = true;
    }

    public void resetFailed() {
        this.failed = false;
    }

    // Below here,
    // From `edu.utah.jiazzi.parser/outunit/Environment.java'.

    public JParser parser = null;
    public JLexer lexer = null;

    public String errorPreface() {
        String s = errorPrefaceInternal();
        String t;
        if (this.lexer != null)
            t = this.lexer.getFilename() + " [" + this.lexer.getLine() + "] ";
        else
            t = null;
        if (s == null && t == null)
            return null;
        if (s == null)
            return t;
        if (t == null)
            return s;
        return t + " " + s;
    }

    // public List<plf.Package> defaults =
    // new ArrayList<plf.Package>();
    public List defaults = new ArrayList();
}
