/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package edu.utah.jiazzi.unit;

import java.util.*;

import edu.utah.jiggy.meta.name.ClassName;
import edu.utah.jiggy.meta.name.PackageName;
import edu.utah.jiggy.meta.type.ClassType;
import edu.utah.jiggy.meta.type.Environment;
import edu.utah.jiggy.meta.type.PackageType;
import edu.utah.jiggy.meta.type.Root;
import edu.utah.jiggy.meta.type.VariableType;

public abstract class UnitRoot extends Root {
    protected Environment env;

    public Environment env() {
        return this.env;
    }

    public void setEnvironment(Environment env) {
        this.env = env;
    }

    protected final Map packages = new HashMap() {
        // public UnitPackage get(PackageName pkg)
        public Object get(Object obj) {
            PackageName pkg = (PackageName) obj;
            if (this.containsKey(pkg))
                return (UnitPackage) super.get(pkg);
            missPackage(pkg);
            if (!this.containsKey(pkg))
                throw new Error(pkg + " was not really added to " + this);
            return (UnitPackage) super.get(pkg);
        }
    };

    // protected final Map<name.Package,clazz.Package> READ_packages =
    // Collections.unmodifiableMap(this.packages);
    protected final Map READ_packages = Collections
        .unmodifiableMap(this.packages);

    public UnitRoot() {
        super();
    }

    public Map packages() {
        return this.READ_packages;
    }

    public void missClass(ClassName clazz) {
        throw new Error("cannot find class "
            + clazz
            + " in "
            + this
            + (this.packages().containsKey(clazz.pkg()) ? " "
                + ((UnitPackage) this.packages().get(clazz.pkg())).classes()
                    .keySet() : ""));
    }

    public void missPackage(PackageName pkg) {
        throw new Error("cannot find package " + pkg + " in " + this);
    }

    public PackageType findPackage(PackageName pkg) {
        return (PackageType) this.packages().get(pkg);
    }

    public boolean containsPackage(PackageName pkg) {
        return this.packages().containsKey(pkg);
    }

    // Below here,
    // From `edu.utah.jiazzi.core/outunit/Root.java'.

    public static final PackageName TVAR = new PackageName("var");

    // public final Map<String,VariableType> generics = new
    // HashMap<String,VariableType>();
    // private final Map<String,VariableType> generics_READ =
    // Collections.unmodifiableMap(this.generics);
    // public Map<String,VariableType> generics() { return this.generics_READ; }
    public final Map generics = new HashMap();
    private final Map generics_READ = Collections
        .unmodifiableMap(this.generics);

    public Map generics() {
        return this.generics_READ;
    }

    public VariableType newGeneric(String name, ClassType bound) {
        if (this.generics.keySet().contains(name))
            throw new Error();
        VariableType generic = new VariableType(name, bound);
        this.generics.put(name, generic);
        return generic;
    }
    /* generics are still assigned on a per-unit basis */

    /*
     * public final Map<String,name.Variable> lexemes = new HashMap<String,name.Variable>();
     * public final Map<String,unit.ArgVar> argVars = new HashMap<String,unit.ArgVar>();
     * 
     * 
     * private final Map<String,name.Variable> lexemes_READ =
     * Collections.unmodifiableMap(this.lexemes); private final Map<String,unit.ArgVar>
     * argVars_READ = Collections.unmodifiableMap(this.argVars);
     * 
     * 
     * public Map<String,name.Variable> lexemes() { return this.lexemes_READ; }
     * public Map<String,unit.ArgVar> argVars() { return this.argVars_READ; }
     * 
     * public name.Variable newLexeme(String name) { if
     * (this.lexemes.keySet().contains(name)) throw new Error(); name.Variable
     * lexeme = new name.Variable(name); this.lexemes.put(name, lexeme); return
     * lexeme; } public unit.ArgVar newArgVar(String name) { if
     * (this.argVars.keySet().contains(name)) throw new Error(); unit.ArgVar
     * argVar = new unit.ArgVar(name); this.argVars.put(name, argVar); return
     * argVar; }
     */
}
