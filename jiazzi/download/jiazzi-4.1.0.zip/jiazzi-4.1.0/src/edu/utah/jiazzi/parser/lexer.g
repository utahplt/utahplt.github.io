header {
/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

  package edu.utah.jiazzi.parser;
  
  import edu.utah.jiazzi.unit.UnitEnvironment;
}
/*
 * Make sure to run antlr.Tool on the lexer.g file first!
 */
options {
  mangleLiteralPrefix = "JIAZZI_";
}

class JLexer extends Lexer;
options {
  k=4;
  exportVocab=JIAZZI;
  charVocabulary = '\3'..'\377';
} 

tokens {
  "unit"; "atom"; "compound"; "signature";
  "bind"; "link"; "to";
  "open"; "name"; "arg"; "lexeme"; "generic";
  "import"; "export"; "local"; "empty"; "external";
  /* Java reserved words */
  "package"; 
  "class"; "interface";
  "extends"; "throws";
  "public"; "protected"; "static"; "final"; "abstract"; "implements"; 
  "void"; "boolean"; "byte"; "short"; "char"; "int"; "long"; "double"; "float"; 
  "native"; "synchronized"; "transient"; "volatile"; "true"; "false";
}
{
  private UnitEnvironment env;
  public void setEnvironment(UnitEnvironment env) {
    this.env = env;
  }
  public void reportError(String str) {
    this.env.err().println("" + str);
    this.env.fail();
  }
  public void reportError(antlr.RecognitionException exc) {
    this.reportError(exc.toString());
  }
}


WS : (' '
   | '\t'
   | '\n' {newline();}
   | '\r')
     { _ttype = Token.SKIP; }
   ;


ML_COMMENT
	:	"/*"
		(	{ LA(2)!='/' }? '*'
		|	'\n' { newline(); }
		|	~('*'|'\n')
		)*
		"*/"
			{ $setType(Token.SKIP); }
	;

SL_COMMENT : 
	"//" 
	(~'\n')* '\n'
	{ _ttype = Token.SKIP; newline(); }
	;


PLUS:	'+';
LT:	'<';
GT:	'>';
LCURLY:	'{';
RCURLY:	'}';
PIPE: '|';
LPAREN:	'(';
RPAREN:	')';
EQUAL:	'=';
MINUS:	'-';
SEMI: ';';
WILD: '*';
COMMA: ',';
COLON: ':';
AT: '@';
DOLLAR: '$';
DOT: '.';


DQUOTE: '"';
// character literals
CHAR_LITERAL
	:	'\'' ( ESC | ~'\'' ) '\''
	;
// string literals
STRING_LITERAL
	:	DQUOTE (ESC|~('"'|'\\'))* DQUOTE
	;



protected LBRACK: '[';
protected RBRACK: ']';

protected LETTER: ('a'..'z'|'A'..'Z'|'_');
protected NUMBER: ('0'..'9');

protected VAR options {
  testLiterals = true;
  paraphrase = "an identifier";
} :     LBRACK (LETTER (LETTER | NUMBER)*) RBRACK;

ID: ((VAR (LETTER (LETTER | NUMBER)*)? ) |
     (LETTER (LETTER | NUMBER)* (VAR (LETTER (LETTER | NUMBER)*)?)?)) {
  int mark = mark();
} (!(BRACKETS) {
  rewind(mark);
})?;


BRACKETS options {
  testLiterals = true;
  paraphrase = "brackets";
} : LBRACK RBRACK;


protected
ESC
	:	'\\'
		(	'n'
		|	'r'
		|	't'
		|	'b'
		|	'f'
		|	'"'
		|	'\''
		|	'\\'
		|	('u')+ HEX_DIGIT HEX_DIGIT HEX_DIGIT HEX_DIGIT 
		|	('0'..'3')
			(
				options {
					warnWhenFollowAmbig = false;
				}
			:	('0'..'7')
				(	
					options {
						warnWhenFollowAmbig = false;
					}
				:	'0'..'7'
				)?
			)?
		|	('4'..'7')
			(
				options {
					warnWhenFollowAmbig = false;
				}
			:	('0'..'9')
			)?
		)
	;

// hexadecimal digit (again, note it's protected!)
protected
HEX_DIGIT: ('0'..'9'|'A'..'F'|'a'..'f');

INTEGER_TEN: '0' | (('1'..'9') ('0'..'9')*);

// INTEGER_OCT: '0' ('0'..'7')+;

INTEGER_HEX: '0' ('x' | 'X') (HEX_DIGIT)*;


/*

// a numeric literal
NUM_INT
	{boolean isDecimal=false;}
	:	'.' {_ttype = DOT;}
			(('0'..'9')+ (EXPONENT)? (FLOAT_SUFFIX)? { _ttype = NUM_FLOAT; })?
	|	(	'0' {isDecimal = true;} // special case for just '0'
			(	('x'|'X')
				(											
				 // hex
				 // the 'e'|'E' and float suffix stuff look
				 // like hex digits, hence the (...)+ doesn't
				 // know when to stop: ambig.  ANTLR resolves
				 // it correctly by matching immediately.  It
				 // is therefor ok to hush warning.
				 options {
				  warnWhenFollowAmbig=false;
				}
				 :	HEX_DIGIT
				 )+
				|	('0'..'7')+								
				// octal
				)?
			|	('1'..'9') ('0'..'9')*  {isDecimal=true;}		// non-zero decimal
			)
			(	('l'|'L')
				
				// only check to see if it's a float if looks like decimal so far
				|	{isDecimal}?
				(	'.' ('0'..'9')* (EXPONENT)? (FLOAT_SUFFIX)?
					|	EXPONENT (FLOAT_SUFFIX)?
					|	FLOAT_SUFFIX
					)
			{ _ttype = NUM_FLOAT; }
				)?
			  ;


// a couple protected methods to assist in matching floating point numbers
protected
EXPONENT
	:	('e'|'E') ('+'|'-')? ('0'..'9')+
	;


protected
FLOAT_SUFFIX
	:	'f'|'F'|'d'|'D'
	;



*/
