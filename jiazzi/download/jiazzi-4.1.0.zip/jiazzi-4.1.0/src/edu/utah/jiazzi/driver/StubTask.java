/*
 * Copyright (c) 2005, 2006 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package edu.utah.jiazzi.driver;

import java.io.File;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;

import edu.utah.jiazzi.unit.AtomUnit;
import edu.utah.jiazzi.unit.Unit;
import edu.utah.jiazzi.unit.UnitEnvironment;

public class StubTask extends Task {
    private String unitDir;
    private String unitName;
    private boolean failOnError;

    public StubTask() {
        failOnError = true;
    }

    public void setDir(String dir) {
        unitDir = dir;
    }

    public void setFailonerror(boolean fail) {
        failOnError  = fail;
    }

    public void setUnit(String unit) {
        unitName = unit;
    }

    public void execute() throws BuildException {
        if (unitDir == null) {
            throw new BuildException("no unit directory specified");
        }
        if (unitName == null) {
            throw new BuildException("no unit specified");
        }

        // The code below this point is quite similar to code in `Main.main'.
        // The two versions of this code should be merged.

        UnitEnvironment env = new MainUnitEnvironment(new File(unitDir));
        Unit unit = env.findUnit(unitName);
        if (unit == null) {
            if (failOnError) {
                throw new BuildException(unitName + " failed");
            }
            return;
        }

        try {
            unit.resolve(env);
        } catch (RuntimeException e) {
            env.fail();
            e.printStackTrace();
        }

        if (!env.hasFailed()) {
            if (unit instanceof AtomUnit) {
                try {
                    ((AtomUnit) unit).doStubs(env);
                } catch (RuntimeException e) {
                    env.fail();
                    e.printStackTrace();
                }
            } else {
                if (failOnError) {
                    throw new BuildException(unit + " does not require stubs");
                }
            }
        }
        if (env.hasFailed()) {
            throw new BuildException(unitName + " failed");
        }
    }
}
