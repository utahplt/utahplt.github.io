/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package edu.utah.jiazzi.unit;

import edu.utah.jiggy.meta.name.PackageName;

public class UnitOpen {
    public final UnitPackage in;
    public final UnitPackage out;
    public final UnitPackage fixed;

    final PackageName name;

    public PackageName name() {
        return this.name;
    }

    public UnitOpen(Unit u, String pname) {
        this.name = new PackageName(pname);
        this.in = new OPackage(u, new PackageName("__" + pname + "__in"));
        this.out = new OPackage(u, new PackageName("__" + pname + "__out"));
        this.fixed = new OPackage(u, new PackageName(pname));
        this.out.setExtended(this.in);
        this.fixed.setExtended(this.out);
        this.fixed.visible = false;
        u.opens.add((UnitOpen) this);
        u.makeImport(this.in);
        u.makeImport(this.fixed);
        u.makeExport(this.out);
    }

    public UnitPackage in() {
        return this.in;
    }

    public UnitPackage out() {
        return this.out;
    }

    public UnitPackage fixed() {
        return this.fixed;
    }

    static final UnitSignature EMPTY = new UnitSignature("$EMPTY");
    static {
        EMPTY.resolve(null);
    }

    public class OPackage extends UnitPackage {
        OPackage(Unit u, PackageName name) {
            super(u, name);
        }

        public UnitSignature sig() {
            if (super.sig() != null)
                return super.sig();
            return EMPTY;
        }

        public boolean isOpen() {
            return true;
        }

        public UnitOpen open() {
            return (UnitOpen) UnitOpen.this;
        }
    }
}
