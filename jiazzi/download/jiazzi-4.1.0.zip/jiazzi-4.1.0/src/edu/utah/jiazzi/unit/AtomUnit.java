/*
 * Copyright (c) 2004, 2005, 2006 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiazzi.core outunit.Atom */

package edu.utah.jiazzi.unit;

import java.io.*;
import java.util.*;

import edu.utah.jiggy.bytecode.bt.ReplaceBT;
import edu.utah.jiggy.clazz.ClassModel;
import edu.utah.jiggy.clazz.ModelRoot;
import edu.utah.jiggy.clazz.NullModelRoot;
import edu.utah.jiggy.clazz.PackageModel;
import edu.utah.jiggy.clazz.TypeModel;
import edu.utah.jiggy.meta.flag.FlagConstants;
import edu.utah.jiggy.meta.shape.ClassShape;
import edu.utah.jiggy.meta.shape.MethodShape;
import edu.utah.jiggy.meta.shape.ReplaceShape;
import edu.utah.jiggy.meta.shape.ShapeKey;
import edu.utah.jiggy.meta.type.ClassType;

public class AtomUnit extends Unit {
    public AtomUnit(java.lang.String name) {
        super(name);
    }

    public long modifiedRaw(UnitEnvironment env) {
        long m = super.modifiedRaw(env);
        final ModelRoot rawStub = this.newStub0(env);
        final ModelRoot raw = env.loadRaw((AtomUnit) this, rawStub);
        if (raw == null)
            return 0;
        long m0 = env.modified(raw);
        if (m0 > m)
            m = m0;
        return m;
    }

    public String toString() {
        return "atom " + super.toString();
    }

    public void doStubs(UnitEnvironment env) {
        {
            Iterator i = this.exports().iterator();
            while (i.hasNext()) {
                UnitPackage upkg = (UnitPackage) i.next();
                for (Iterator j = upkg.classes().values().iterator();
                     j.hasNext();
                     /* j = j */) {
                    UnitClass uclazz = (UnitClass) j.next();
                    if (uclazz.outer() != null)
                        continue;
                    PrintStream out = env.skeleton(uclazz);
                    if (out == null)
                        continue;
                    uclazz.shape().print(uclazz.newType(), "", out,
                        "skeleton, please implement");
                }
            }
        }
        env.stubs((AtomUnit) this);
    }

    protected void buildInner(final UnitEnvironment env) {
        final ModelRoot rawStub = this.newStub0(env);
        final ModelRoot raw = env.loadRaw((AtomUnit) this, rawStub);
        if (raw == null) {
            env.err().println(
                "The directory project-path/" + this.name()
                    + "/ does not exist for the raw classes of " + this);
            env.fail();
            return;
        }
        for (Iterator i = this.exports().iterator(); i.hasNext(); /* i = i */) {
            UnitPackage pkg = (UnitPackage) i.next();
            for (Iterator j = pkg.classes().values().iterator();
                 j.hasNext();
                 /* j = j */) {
                UnitClass cls = (UnitClass) j.next();
                if (!raw.packages().containsKey(pkg.name())
                    || !((PackageModel) raw.packages().get(pkg.name()))
                        .classes().containsKey(cls.name().nopkg())) {
                    env.err().println(raw + " does not contain " + cls);
                    env.fail();
                }
            }
        }
        if (env.hasFailed()) {
            return;
        }
        this.newStub1(env, rawStub, raw);

        // Set<ClassType> visible = new HashSet<ClassType>() {
        Set visible = new HashSet() {
            // public boolean contains(ClassType ctype0)
            public boolean contains(Object ctype0) {
                TypeModel ctype = (TypeModel) ctype0;
                if (super.contains(ctype))
                    return true;
                if (ctype.clazz().pkg().root() != raw)
                    return true;
                if (!AtomUnit.this.packages().containsKey(
                    ctype.clazz().pkg().name()))
                    return false;
                UnitPackage upkg = (UnitPackage) AtomUnit.this.packages().get(
                    ctype.clazz().pkg().name());
                if (upkg.isImport())
                    throw new Error();
                if (!upkg.classes().containsKey(ctype.clazz().name().nopkg()))
                    return false;
                return true;
            }
        };
        ReplaceShape u2r = new ReplaceShape();
        this.u2r(raw, rawStub, u2r);
        {
            for (Iterator i = this.exports().iterator();
                 i.hasNext();
                 /* i = i */) {
                UnitPackage upkg = (UnitPackage) i.next();
                PackageModel rpkg = (PackageModel) raw.packages().get(
                    upkg.name());
                for (Iterator j = upkg.classes().values().iterator();
                     j.hasNext();
                     /* j = j */) {
                    UnitClass ucls = (UnitClass) j.next();
                    UnitType utype = (UnitType) ucls.newType();
                    ClassModel rcls = (ClassModel) rpkg.classes().get(
                        ucls.name().nopkg());
                    TypeModel rtype = (TypeModel) rcls.newType();

                    u2r.set(utype);
                    ClassShape ushape = ucls.shape().replace(u2r);
                    u2r.set((ClassType) null);

                    ClassShape rshape = rcls.shape().collapse(visible);
                    if (!rshape.verify(env.err())) {
                        env.err()
                            .println(rcls + " failed initial verification");
                        env.fail();
                    }
                    if (!rshape.matches(ushape, env.err())) {
                        env.err().println(
                            "shape for " + rcls
                                + " does not match shape required for " + ucls);
                        env.fail();
                    }
                    for (Iterator k = utype.shape().methods().iterator();
                         k.hasNext();
                         /* k = k */) {
                        ShapeKey umthd = (ShapeKey) k.next();
                        MethodShape uamthd = utype.shape().actualMethod(umthd);
                        if (uamthd.isSet(FlagConstants.STATIC))
                            continue;
                        u2r.set(utype);
                        ShapeKey rmthd = umthd.replace(u2r);
                        u2r.set((ClassType) null);
                        TypeModel ftype = (TypeModel) rtype.shape()
                            .freshMethod(rmthd);
                        if (ftype == null) {
                            System.err.println(rtype.shape().methods() + " "
                                + rmthd);
                            if (true)
                                continue;
                            throw new Error("cannot find " + rmthd + " in "
                                + rtype);
                        }
                        MethodShape urmthd = ftype.shape().actualMethod(rmthd);
                        if (urmthd.access() != uamthd.access()) {
                            env.fail();
                            env
                                .err()
                                .println(
                                    "method overriding not allowed to change access flags for unit exported methods: "
                                        + utype.javaSource()
                                        + "."
                                        + uamthd.javaSource("")
                                        + " vs. "
                                        + ftype.javaSource()
                                        + "."
                                        + urmthd.javaSource(""));
                        }
                    }
                }
            }
        }
        /*
         * if (!this.argVars().isEmpty()) { // ReplaceShape r2u = new
         * ReplaceShape(); // this.r2u(raw, rawStub, r2u); bt.CallGraph cg =
         * raw.callGraph(); for (Iterator<UnitPackage> i =
         * this.packages().values().iterator(); i.hasNext(); i = i) {
         * UnitPackage upkg = i.next(); for (Iterator<UnitClass> j =
         * upkg.classes().values().iterator(); j.hasNext(); j = j) { UnitClass
         * ucls = j.next(); for (Iterator<ShapeKey> k =
         * ucls.newType().shape().methods().iterator(); k.hasNext(); k = k) {
         * MethodShape mthd = ucls.newType().shape().actualMethod(k.next()); if
         * (mthd.procedure().argVar() == null) continue; TypeModel rtype =
         * (TypeModel) ucls.newType().replace(u2r); ShapeKey rmthd =
         * mthd.key().replace(ucls.newType(), u2r); TypeModel ftype =
         * (TypeModel) rtype.shape().freshMethod(rmthd); boolean pass = false;
         * for (Iterator<bt.MethodRef> h = cg.calls(ftype, rmthd).iterator();
         * h.hasNext(); h = h) { bt.MethodRef mref= h.next(); for (TypeModel
         * ptype = (TypeModel) mref.clazz(); ptype != null; ptype = (TypeModel)
         * ptype.shape().zuper()) { if
         * (!this.packages().containsKey(ptype.clazz().pkg().name())) continue;
         * UnitPackage vpkg = this.packages().get(ptype.clazz().pkg().name());
         * if (!vpkg.classes().containsKey(ptype.clazz().name().nopkg()))
         * continue; UnitClass vcls =
         * vpkg.classes().get(ptype.clazz().name().nopkg()); while (true) { for
         * (Iterator<ShapeKey> g = vcls.newType().shape().methods().iterator();
         * g.hasNext(); g = g) { MethodShape vmthd =
         * vcls.newType().shape().actualMethod(g.next()); if
         * (!vmthd.key().replace(vcls.newType(), u2r).equals(mref.member()))
         * continue; vcls = null; if (vmthd.procedure().argVar() !=
         * mthd.procedure().argVar()) { env.err().println(vmthd.javaSource("") + "
         * in " + vcls.name().javaSource() + " calls " + mthd.javaSource("") + "
         * in " + ucls.name().javaSource() + " but is not ascribed with argument
         * parameter " + mthd.procedure().argVar()); pass =
         * (vmthd.procedure().argVar() == mthd.procedure().argVar()); vcls =
         * null; break; } } if (vcls == null) break; if
         * (vcls.newType().shape().zuper() instanceof UnitType) { vcls =
         * ((UnitType) vcls.newType().shape().zuper()).clazz(); } else break; }
         * break; } if (!pass) { env.fail();
         * env.err().println(mthd.javaSource("") + " in " +
         * ucls.name().javaSource() + " called " + " by method " + mref + " that
         * is not ascribed with argument parameter " +
         * mthd.procedure().argVar()); } } } } }
         */
        if (env.hasFailed()) {
            env.err().println("cannot link because of errors");
            return;
        }
        /* just write them to jar file? need to screw with the */
        {
            ReplaceBT r2b = new ReplaceBT();
            r2b.map(raw, this.built());
            r2b.map(rawStub, this.stub());
            for (Iterator i = raw.packages().values().iterator();
                 i.hasNext();
                 /* i = i */) {
                PackageModel rpkg = (PackageModel) i.next();
                PackageModel tpkg = new PackageModel(this.built(), rpkg.name());
                for (Iterator j = rpkg.classes().values().iterator();
                     j.hasNext();
                     /* j = j */) {
                    ClassModel rcls = (ClassModel) j.next();
                    // ClassModel tcls =
                    new ClassModel(tpkg, rcls.name().nopkg());
                }
            }
            if (raw == this.built())
                throw new Error("you wenti!");

            /*
             * for (Iterator<UnitOpen> i = this.opens().iterator();
             * i.hasNext(); i = i) { UnitOpen upkg = i.next(); PackageModel rpkg =
             * (PackageModel) upkg.replace(u2r); PackageModel tpkg =
             * (PackageModel) rpkg.replace(r2b); for (Iterator<UnitClass> j =
             * upkg.classes().values().iterator(); j.hasNext(); j = j) {
             * UnitClass ucls = j.next(); ClassModel tcls = ((TypeModel)
             * ucls.newType().replace(u2r).replace(r2b)).clazz();
             * tcls.setCastThis(); } }
             */

            /*
             * change this to read in and write out instruction stream in the
             * stream, make sure "this" in open classes is always casted
             */
            raw.replace1((NullModelRoot) this.built(), r2b);

            env.copyInto(raw, this.built(), r2b);
            for (Iterator i = raw.packages().values().iterator();
                 i.hasNext();
                 /* i = i */) {
                PackageModel rpkg = (PackageModel) i.next();
                PackageModel tpkg = (PackageModel) this.built().packages().get(
                    rpkg.name());
                for (Iterator j = rpkg.classes().values().iterator();
                     j.hasNext();
                     /* j = j */) {
                    ClassModel rcls = (ClassModel) j.next();
                    ClassModel tcls = (ClassModel) tpkg.classes().get(
                        rcls.name().nopkg());
                    env.setSource(tcls,
                        this.name() + ":" + env.getSource(rcls));
                }
            }
        }
    }
}
