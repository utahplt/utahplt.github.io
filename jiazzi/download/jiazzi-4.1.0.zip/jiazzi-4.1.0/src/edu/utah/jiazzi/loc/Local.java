/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiazzi.core outloc.Local */

package edu.utah.jiazzi.loc;

import java.util.*;

import edu.utah.jiazzi.unit.CompoundUnit;
import edu.utah.jiazzi.unit.Unit;
import edu.utah.jiazzi.unit.UnitEnvironment;
import edu.utah.jiggy.meta.name.ClassName;
import edu.utah.jiggy.meta.type.RefType;
import edu.utah.jiggy.meta.type.ReplaceType;
import edu.utah.jiggy.meta.type.TypeType;
import edu.utah.jiggy.meta.type.VariableType;

public class Local extends LocRoot {
    protected final Unit unit;

    // private final Map<type.Variable,type.Ref> genericLinkage = new
    // HashMap<type.Variable,type.Ref>();
    private final Map genericLinkage = new HashMap();

    // private final Map<type.Variable,type.Ref> READ_genericLinkage =
    // Collections.unmodifiableMap(this.genericLinkage);
    private final Map READ_genericLinkage = Collections
        .unmodifiableMap(this.genericLinkage);

    // public Map<type.Variable,type.Ref> genericLinkage() { return
    // this.READ_genericLinkage; }
    public Map genericLinkage() {
        return this.READ_genericLinkage;
    }

    public void link(VariableType var, RefType ref) {
        if (this.genericLinkage.put(var, ref) != null)
            throw new Error(var + " " + ref + " alread linked");
    }

    public Local(java.lang.String name, CompoundUnit parent, Unit unit) {
        this.name = name;
        this.parent = parent;
        this.unit = unit;
    }

    public Unit unit() {
        return this.unit;
    }

    public void u2lType(ReplaceType u2l, UnitEnvironment env) {
        for (Iterator i = this.unit().generics().values().iterator();
             i.hasNext();
             /* i = i */) {
            VariableType tv = (VariableType) i.next();
            if (!this.genericLinkage().containsKey(tv)) {
                env.err().println("cannot find link for type variable " + tv);
                env.fail();
                this.genericLinkage()
                    .put(
                        tv,
                        env.platform().findClass(
                            new ClassName("java.lang.Object")));
            }
            u2l.map(tv, (TypeType) this.genericLinkage.get(tv));
        }
    }
}
