/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.bytecode outattr.InnerClass */

package edu.utah.jiggy.bytecode.bt;

import java.util.*;
import java.io.*;

import edu.utah.jiggy.clazz.ClassModel;
import edu.utah.jiggy.clazz.TypeModel;
import edu.utah.jiggy.meta.flag.AccessFlag;
import edu.utah.jiggy.meta.flag.FlagConstants;
import edu.utah.jiggy.meta.flag.VirtualFlag;
import edu.utah.jiggy.meta.shape.Base;
import edu.utah.jiggy.meta.shape.ClassShape;

public class BTInnerClasses extends BTAttr {
    public boolean isDerived() {
        return true;
    }

    protected boolean isMember() {
        return false;
    }

    public String name() {
        return "InnerClasses";
    }

    protected Set inners(ClassModel clazz) {
        Set set = new HashSet();
        set.add(clazz);
        for (Iterator i = clazz.pkg().classes().values().iterator();
             i.hasNext();
             /* i = i */) {
            ClassModel inner = (ClassModel) i.next();
            if (inner.name().outer() == null)
                continue;
            if (inner.name().outer().nopkg().equals(clazz.name().nopkg()))
                set.add(inner);
        }
        return set;
    }

    protected int size(ClassModel clazz, Base base) {
        return 2 + (this.inners(clazz).size() * 8);
    }

    public BTAttr readClass(int size, DataInputStream in, ClassModel clazz,
                            ClassShape scls) throws IOException {
        BTAttr attr = super.readClass(size, in, clazz, scls);
        int count = in.readUnsignedShort();
        for (int i = 0; i < count; i++) {
            int cinner = in.readShort();
            int couter = in.readShort();
            int cname = in.readShort();
            int cflags = in.readShort();
            final ClassModel inner;
            final ClassModel outer;
            final String name;
            if (cinner != 0)
                inner = ((TypeModel) clazz.body().pool().get(cinner).clazz())
                    .clazz();
            else
                inner = null;
            if (couter != 0)
                outer = ((TypeModel) clazz.body().pool().get(couter).clazz())
                    .clazz();
            else
                outer = null;
            if (cname != 0)
                name = clazz.body().pool().get(cname).utf8();
            else
                name = null;
            if (inner == clazz) {
                // if (outer != null) inner.setOuter(outer);
                if ((cflags & FlagConstants.STATIC.jvmcode()) != 0)
                    scls.set(FlagConstants.STATIC);
                AccessFlag access = AccessFlag.parse(cflags);
                VirtualFlag virtual = VirtualFlag.parse(cflags);
                scls.set(access);
                scls.set(virtual);
            }
        }
        return attr;
    }

    static boolean INNER_HELL = true;

    protected boolean prepareWrite(ClassModel clazz, Base base) {
        if (!INNER_HELL) {
            return false;
        } else {
            Set inners = this.inners(clazz);
            if (inners.size() == 1)
                return false;
            for (Iterator i = inners.iterator(); i.hasNext(); /* i = i */) {
                ClassModel inner = (ClassModel) i.next();
                clazz.body().pool().allocClass(inner.newType());
                if (inner.outer() != null)
                    clazz.body().pool().allocClass(inner.outer().newType());
                if (!inner.isUnnamed())
                    clazz.body().pool().allocUtf8(
                        inner.name().base().javaSource().toString());
            }
            return super.prepareWrite(clazz, base);
        }
    }

    protected void write(DataOutputStream out, ClassModel clazz, Base base)
            throws IOException {
        super.write(out, clazz, base);
        if (!INNER_HELL) {
            throw new Error("no inner class attributes!");
        } else {
            Set inners = this.inners(clazz);
            out.writeShort(inners.size());
            for (Iterator i = inners.iterator(); i.hasNext(); /* i = i */) {
                ClassModel inner = (ClassModel) i.next();
                int cinner, couter, cname, cflags;
                cinner = clazz.body().pool().allocClass(inner.newType());
                if (inner.outer() != null)
                    couter = clazz.body().pool().allocClass(
                        inner.outer().newType());
                else
                    couter = 0;
                if (!inner.isUnnamed())
                    cname = clazz.body().pool().allocUtf8(
                        inner.name().base().javaSource().toString());
                else
                    cname = 0;

                cflags = inner.shape().access().jvmcode()
                    | inner.shape().virtual().jvmcode();
                if (inner.shape().isSet(FlagConstants.STATIC))
                    cflags = cflags | FlagConstants.STATIC.jvmcode();
                if (inner.shape().isSet(FlagConstants.INTERFACE))
                    cflags = cflags | FlagConstants.INTERFACE.jvmcode();

                out.writeShort(cinner);
                out.writeShort(couter);
                out.writeShort(cname);
                out.writeShort(cflags);
            }
        }
    }

    public BTInnerClasses() {
        super();
    }
}
