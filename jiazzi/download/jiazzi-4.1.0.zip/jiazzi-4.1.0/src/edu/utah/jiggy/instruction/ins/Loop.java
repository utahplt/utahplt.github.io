/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package edu.utah.jiggy.instruction.ins;

import java.util.*;
import java.io.*;

public class Loop extends Control {
    Block head;
    Block exit;

    public void print(PrintStream out) {
        super.print(out);
    }

    public Block exit() {
        return this.exit;
    }

    public void process() {
        for (Iterator i = this.head().branches().iterator();
             i.hasNext();
             /* i = i */) {
            Block target = (Block) i.next();
            this.processRecurse(target, this.head());
        }
        /*
         * now we know our exit block (if any)
         */
        try {
            super.process();
        } catch (Error e) {
            System.err.println("loop " + this + " " + this.exit());
            throw e;
        }
    }

    public String toString() {
        return "loop-" + this.head();
    }

    public Block mergesWith(Block b0, boolean revbranch, Block b1) {
        if (b1.reaches(b0, revbranch))
            return b0;
        if (revbranch)
            return null;
        Block ret = null;
        for (Iterator i = b0.branches().iterator(); i.hasNext(); /* i = i */) {
            Block b00 = (Block) i.next();
            Block ret0 = this.mergesWith(b00, b00.dominates(b0), b1);
            if (ret0 == null)
                continue;
            if (ret != null && ret != ret0)
                throw new Error();
            ret = ret0;
        }
        return ret;
    }

    private void processRecurse(Block b, Block p) {
        boolean revbranch = b.dominates(p);
        Block pexit = this.parent().exit();

        if (!b.reaches(this.head(), false)) {
            if (pexit != null) {
                if (b.reaches(pexit, false)) {
                    if (this.exit == null)
                        this.exit = b;
                    else {
                        Block ret = mergesWith(b, false, this.exit);
                        if (ret == null)
                            throw new Error(this + " " + b + " " + this.exit);
                        this.exit = ret;
                    }
                }
            } else {
                if (this.exit == null)
                    this.exit = b;
                else {
                    Block ret = this.mergesWith(b, false, this.exit);
                    if (ret != null)
                        this.exit = ret;
                    else if (this.exit.getPC() < b.getPC())
                        this.exit = b;
                }
            }
        } else {
            if (!revbranch) {
                for (Iterator i = b.branches().iterator();
                     i.hasNext();
                     /* i = i */) {
                    Block target = (Block) i.next();
                    this.processRecurse(target, b);
                }
            }
        }
        if (false) {
            System.err.println("PR: " + b + " " + this.head() + " " + p + " "
                + revbranch + " " + b.reaches(this.head(), revbranch) + " "
                + b.reaches(this.head(), !revbranch) + " " + this.exit);
        }
    }

    public Block head() {
        return this.head;
    }

    public Block entrance() {
        return this.head();
    }

    public Loop(Control parent, Block head) {
        super(parent);
        this.head = head;
    }
}
