/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package edu.utah.jiggy.meta.type;

import edu.utah.jiggy.instruction.ins.Machine;
import edu.utah.jiggy.instruction.ins.TypeInfo;
import edu.utah.jiggy.meta.name.ClassName;
import edu.utah.jiggy.meta.name.PackageName;

public abstract class RefType extends TypeType {
    public RefType() {
        super();
    }

    public String defaultValue() {
        return "((" + this.javaSource() + ")null)";
    }

    // Below here,
    // From `edu.utah.jiggy.instruction/outtype/Ref.java'.

    public TypeInfo localTypeInfo() {
        return TypeInfo.REFERENCE;
    }

    public TypeType merge(TypeType t, Machine m) {
        if (t instanceof RefType)
            return m.context.findPackage(
                new PackageName("java.lang")).findClass(
                    new ClassName("Object"));
        else
            return super.merge(t, m);
    }

    public static RefType ANY = new RefType() {
        public boolean isa(TypeType type) {
            return (type instanceof RefType);
        }

        public TypeType merge(TypeType t, Machine m) {
            if (t instanceof RefType)
                return t;
            else
                return TypeConstants.ERROR;
        }
    };
}
