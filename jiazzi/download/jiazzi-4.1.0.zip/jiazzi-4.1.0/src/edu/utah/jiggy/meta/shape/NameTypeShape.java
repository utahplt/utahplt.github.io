/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.core outshape.NameTypeShape */

package edu.utah.jiggy.meta.shape;

import edu.utah.jiggy.meta.name.MemberName;
import edu.utah.jiggy.meta.type.ReplaceType;
import edu.utah.jiggy.meta.type.TypeConstants;
import edu.utah.jiggy.meta.type.TypeType;

public class NameTypeShape extends ShapeElement {
    protected MemberName name;
    protected TypeType type;

    public static final NameTypeShape EMPTY = new NameTypeShape();

    public String javaSource() {
        return this.type.javaSource() + " " + this.name.javaSource();
    }

    public NameTypeShape setName(MemberName name) {
        NameTypeShape nt = (NameTypeShape) this.copy();
        nt.name = name;
        return nt;
    }

    public TypeType type() {
        if (this.type == null)
            return TypeConstants.VOID;
        return this.type;
    }

    public NameTypeShape setType(TypeType type) {
        if (this.type == type)
            return (NameTypeShape) this;
        NameTypeShape nt = (NameTypeShape) this.copy();
        nt.type = type;
        return nt;
    }

    public MemberName name() {
        if (this.name == null)
            return new MemberName("<init>");
        return this.name;
    }

    public String toString() {
        if (this == EMPTY)
            return "<empty>";
        else
            return (this.type() == null ? "null" : this.type().javaSource())
                + " "
                + (this.name() == null ? "null" : this.name().javaSource());
    }

    public ShapeElement replace(ReplaceType replace) {
        if (this == EMPTY)
            return EMPTY;
        NameTypeShape copy = (NameTypeShape) super.replace(replace);
        TypeType t = copy.type.replace(replace);
        if (t != copy.type)
            copy = copy.setType(t);
        return copy;
    }

    public boolean matches(ShapeElement m) {
        if (!super.matches(m))
            return false;
        if (m == EMPTY || this == EMPTY)
            return this == m;
        NameTypeShape nt = (NameTypeShape) m;
        if (!this.name.equals(nt.name))
            return false;
        if (!this.type.equals(nt.type))
            return false;
        return true;
    }

    public NameTypeShape() {
        super();
    }
}
