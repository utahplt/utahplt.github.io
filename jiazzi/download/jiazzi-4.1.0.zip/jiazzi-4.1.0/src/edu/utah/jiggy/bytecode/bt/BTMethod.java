/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.bytecode outbt.Method */

package edu.utah.jiggy.bytecode.bt;

import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;

import edu.utah.jiggy.clazz.ClassModel;
import edu.utah.jiggy.instruction.ins.Block;
import edu.utah.jiggy.instruction.ins.Constant;
import edu.utah.jiggy.instruction.ins.Local;
import edu.utah.jiggy.instruction.ins.Method;
import edu.utah.jiggy.instruction.ins.Return;
import edu.utah.jiggy.instruction.ins.Throw;
import edu.utah.jiggy.instruction.ins.TypeInfo;
import edu.utah.jiggy.meta.flag.FlagConstants;
import edu.utah.jiggy.meta.shape.ArgShape;
import edu.utah.jiggy.meta.shape.InitShape;
import edu.utah.jiggy.meta.shape.MemberShape;
import edu.utah.jiggy.meta.shape.MethodShape;
import edu.utah.jiggy.meta.shape.NameTypeShape;
import edu.utah.jiggy.meta.shape.ShapeKey;
import edu.utah.jiggy.meta.type.ClassType;

public class BTMethod extends BTMember {
    public MemberShape orig;

    public BTMethod() {
        super();
    }

    public BTMethod(ClassModel clazz, InitShape init) {
        this();
        this.orig = (InitShape) init.copy();
    }

    public BTMethod(ClassModel clazz, MethodShape mthd) {
        this();
        this.orig = (MethodShape) mthd.copy();
    }

    /*
     * public void gjReplace(TypeModel ctype, Base base, ReplaceShape replace) {
     * ReplaceShape mreplace = new ReplaceShape(replace); super.gjReplace(ctype,
     * base, mreplace);
     * 
     * ShapeKey key0 = ((MemberShape) base).key(); ShapeKey key1 =
     * key0.replace(ctype, mreplace); if (key0.procedure().args().size() !=
     * key1.procedure().args().size()) throw new Error(key0 + " " + key1);
     * 
     * if (!key1.equals(key0)) replace.map(ctype, key0, key1); }
     */
    public void read(DataInputStream in, ClassModel clazz, MemberShape bld)
            throws IOException {
        super.read(in, clazz, bld);
        this.orig = (MemberShape) bld.copy();
    }

    // ENE, May 17 2005: now defined below,
    // in the code from `edu.utah.jiggy.instruction/outbt/Method.java'.
    // public void prepareWrite(ClassModel clazz, ShapeKey key) {
    // super.prepareWrite(clazz, key);
    // }
    public void write(DataOutputStream out, ClassModel clazz, ShapeKey key)
            throws IOException {
        super.write(out, clazz, key);
        MemberShape mmbr = clazz.newType().shape().actual(key);
        if (mmbr.virtual() == FlagConstants.ABSTRACT) {
            if (this.attributes().containsKey(BTAttr.CODE)) {
                System.err.println("why " + mmbr.javaSource("<init>")
                    + " contains code when it is abstract?");
            }
        }
        // if (this.orig.procedure().args().size() !=
        // key.procedure().args().size())
        // throw new Error("size of method changed! " + this.orig + " " +
        // clazz.newType().shape().actual(key));
    }

    // Below here,
    // From `edu.utah.jiggy.instruction/outbt/Method.java'.

    public void prepareWrite(ClassModel clazz, ShapeKey mthd) {
        ClassType ctype = clazz.newType();
        boolean isMethod = (mthd.nameType() != NameTypeShape.EMPTY);
        MemberShape mmbr = ctype.shape().actual(mthd);
        if ((mmbr.virtual() != FlagConstants.ABSTRACT)
            && (!this.attributes().containsKey(BTAttr.CODE))) {
            BTCode code = new BTCode();
            this.attributes().put(BTAttr.CODE, code);
            if ((ctype.shape().zuper() != null)
                && (!isMethod && ctype.shape().zuper().shape().inits()
                    .contains(mthd))
                || (isMethod
                    && ctype.shape().zuper().shape().methods().contains(mthd)
                    && ctype.shape().actualMethod(mthd).virtual().isa(
                        FlagConstants.CONCRETE))) {
                Method.Special invk = new Method.Special();
                BTMethodRef mref = new BTMethodRef(ctype.shape().zuper(), mthd);
                invk = (Method.Special) invk.setMethod(mref);
                this.forward(code, invk, mthd);
            } else if (!isMethod
                || ctype.shape().actualMethod(mthd).virtual().isa(
                    FlagConstants.CONCRETE)) {
                this.makeError(clazz, code, "cannot figure out code for "
                    + mthd + " in class " + clazz.name());
            }
        }
        super.prepareWrite(clazz, mthd);
    }

    private void makeError(ClassModel clazz, BTCode code, String msg) {
        Block b = new Block(0);
        b.instructions().add(new Constant.Immediate(TypeInfo.REFERENCE, 0));
        b.setBranch(new Throw());
        code.blocks = new ArrayList();
        code.blocks.add(b);
        code.setMaxStack(1);
        code.setMaxLocal(1);
    }

    private void forward(BTCode code, Method mthd, ShapeKey mmbr) {
        code.blocks = new ArrayList();
        Block b = new Block(0);
        b.instructions().add(new Local.Load(TypeInfo.REFERENCE).setIndex(0));
        int index = 1;
        for (Iterator i = mmbr.procedure().args().iterator();
             i.hasNext();
             /* i = i */) {
            ArgShape arg = (ArgShape) i.next();
            b.instructions().add(
                new Local.Load(arg.type().localTypeInfo()).setIndex(index));
            index += arg.type().stackWidth();
        }
        b.instructions().add(mthd);
        b.instructions()
            .add(new Return(mmbr.nameType().type().localTypeInfo()));
        code.setMaxStack(index > mmbr.nameType().type().stackWidth() ? index
                : mmbr.nameType().type().stackWidth());
        code.setMaxLocal(index);
        code.blocks.add(b);
    }

    public BTCode code() {
        return (BTCode) this.attributes().get(BTAttr.CODE);
    }
}
