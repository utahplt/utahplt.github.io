/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package edu.utah.jiggy.instruction.ins;

import java.util.*;

import edu.utah.jiggy.meta.type.Environment;

public class Machine extends java.lang.Object implements Cloneable {
    // public LinkedList<ins.Value> stack = new LinkedList<ins.Value>();
    // public ArrayList<ins.Value> locals = new ArrayList<ins.Value>();
    public LinkedList stack = new LinkedList();
    public ArrayList locals = new ArrayList();
    public boolean isStore = false;

    public String toString() {
        return this.stack + " " + this.locals;
    }

    public boolean mergeInto(Block from, Block to) {
        if (to.stack == null) {
            to.stack = new LinkedList(this.stack);
            to.locals = new ArrayList(this.locals);
            if (!(to.phis.isEmpty() || to.mergedWith.isEmpty()))
                throw new Error();
            to.mergedWith.add(from);
            return true;
        } else {
            to.mergedWith.add(from);
            boolean dirty = false;
            dirty = this.mergeInto(this.stack, to.stack, from, to) || dirty;
            dirty = this.mergeInto(this.locals, to.locals, from, to) || dirty;
            return dirty;
        }
    }

    public Machine copy() {
        try {
            Machine m = (Machine) this.clone();
            m.stack = new LinkedList(this.stack);
            m.locals = new ArrayList(this.locals);
            return m;
        } catch (CloneNotSupportedException e) {
            throw new Error();
        }
    }

    public boolean mergeInto(List from, List to, Block fblk, Block tblk) {
        boolean dirty = false;
        this.doError(from.size() == to.size(), from + " vs. " + to);
        ListIterator fi = from.listIterator();
        ListIterator ti = to.listIterator();
        while (fi.hasNext()) {
            Value vf = (Value) fi.next();
            Value vt = (Value) ti.next();
            Value v = vf.mergeInto((Machine) this, vt, fblk, tblk);
            if (v != vt || v.isDirty()) {
                ti.set(v);
                dirty = true;
            }
        }
        return dirty;
    }

    public void init(Block b) {
        this.stack.clear();
        this.stack.addAll(b.stack);
        this.locals.clear();
        this.locals.addAll(b.locals);
    }

    public Value pop() {
        Value value = (Value) this.stack.removeLast();
        if (value == Value.SECOND) {
            value = (Value) this.stack.removeLast();
        }
        return value;
    }

    public Value load(int index) {
        Value value = (Value) this.locals.get(index);
        this.doError(value != Value.SECOND, value + "");
        return value;
    }

    public void store(int index, Value value) {
        this.doError(this.locals.get(index) != Value.SECOND,
            index + " " + this.locals.get(index));
        this.locals.set(index, value);
        if (value.type(this.context).stackWidth() == 2) {
            Value v = (Value) this.locals.get(index + 1);
            this.doError(
                (v == Value.SECOND || v == Value.ERROR
                 || v.type(this.context).stackWidth() == 1),
                "" + v);
            this.locals.set(index + 1, Value.SECOND);
        }
        this.isStore = true;
    }

    public void push(Value value) {
        this.stack.add(value);
        if (value.type(this.context).stackWidth() == 2) {
            this.stack.add(Value.SECOND);
        }
    }

    public void doError(boolean b, String msg) {
        if (!b)
            throw new Error(msg);
    }

    public void doError(boolean b) {
        if (!b)
            throw new Error();
    }

    public final Environment context;

    public Machine(Environment context) {
        super();
        this.context = context;
    }
}
