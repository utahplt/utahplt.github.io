/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package edu.utah.jiggy.bytecode.bt;

import java.util.*;
import java.io.*;

import edu.utah.jiggy.clazz.ClassModel;
import edu.utah.jiggy.clazz.TypeModel;
import edu.utah.jiggy.meta.flag.FlagConstants;
import edu.utah.jiggy.meta.name.MemberName;
import edu.utah.jiggy.meta.shape.NameTypeShape;
import edu.utah.jiggy.meta.shape.ProcedureShape;
import edu.utah.jiggy.meta.shape.ShapeKey;
import edu.utah.jiggy.meta.type.ArrayType;
import edu.utah.jiggy.meta.type.ClassType;
import edu.utah.jiggy.meta.type.GJVariableType;
import edu.utah.jiggy.meta.type.RefType;
import edu.utah.jiggy.meta.type.TypeConstants;
import edu.utah.jiggy.meta.type.TypeType;

public class BTPool {
    static boolean dbg = false;
    // protected final List<bt.Pool.Entry> entries = new
    // ArrayList<bt.Pool.Entry>();
    // final Map<bt.Pool.Entry,Integer> allocated = new
    // HashMap<bt.Pool.Entry,Integer>();
    // final Set<Integer> free = new HashSet<Integer>();
    protected final List entries = new ArrayList();
    final Map allocated = new HashMap();
    final Set free = new HashSet();

    public int size() {
        return this.entries.size();
    }

    public void dump(PrintStream out) {
        out.println(entries.size());
        for (int i = 0; i < this.entries.size(); i++) {
            out.println(i + "\t" + this.entries.get(i));
        }
    }

    public BTPool replace(ReplaceBT replace) {
        BTPool copy = new BTPool();
        for (int i = 0; i < this.entries.size(); i++) {
            copy.entries.add(((BTPool.Entry) this.entries.get(i))
                .replace(replace));
        }
        return copy;
    }

    public void read(DataInputStream input) throws IOException {
        int count = input.readShort();
        this.entries.add(ZERO);
        if (this.entries.size() != 1)
            throw new Error();
        while (this.entries.size() < count) {
            BTPool.Entry e;
            try {
                e = Entry.readEntry(input);
            } catch (Throwable t) {
                t.printStackTrace();
                System.err.println("index: " + this.entries.size());
                for (int i = 0; i < this.entries.size(); i++)
                    System.err.println(i + "\t" + this.entries.get(i));
                throw new Error();
            }
            this.entries.add(e);
            if (e.isWide())
                this.entries.add(new Entry.Empty());
        }
        if (this.entries.size() != count)
            throw new Error();
    }

    public void resolve(ClassModel clazz) {

        for (int i = 0; i < this.entries.size(); i++) {
            try {
                ((BTPool.Entry) this.entries.get(i)).resolve(clazz);
            } catch (Error e) {
                e.printStackTrace();
                System.err.println("error resolving " + this.entries.get(i)
                    + " at " + i + " previous " + this.entries.get(i - 1));
                throw new Error();
            }
        }
    }

    static final BTPool.Entry.Empty ZERO = new BTPool.Entry.Empty() {
        public String toString() {
            return "ENTRY-ZERO";
        }
    };

    public void prepareWrite() {
        if (this.entries.size() == 0)
            this.entries.add(ZERO);

        if (this.entries.get(0) != ZERO)
            throw new Error();

        this.free.clear();
        this.allocated.clear();
        for (int i = 1; i < this.entries.size(); i++) {
            if (this.entries.get(i) == ZERO)
                throw new Error();

            if (this.entries.get(i) instanceof Entry.Preserve) {
                continue;
            } else {
                this.entries.set(i, null);
                this.free.add(new Integer(i));
            }
        }
        for (int i = 0; i < this.entries.size(); i++) {
            if (this.entries.get(i) != null) {
                this.allocated.put(this.entries.get(i), new Integer(i));
                Entry e = (Entry) this.entries.get(i);
                if (false && e instanceof Entry.Class) {
                    System.err.println("PRESERVED: " + i + " " + e + "["
                        + e.hashCode() + "]");
                }
            } else {
                continue;
            }
        }
        for (int i = 0; i < this.entries.size(); i++) {
            if (this.entries.get(i) != null) {
                ((BTPool.Entry) this.entries.get(i))
                    .prepareWrite((BTPool) this);
            }
        }
    }

    public void write(DataOutputStream output) throws IOException {
        while (!this.free.isEmpty()) {
            Iterator i = this.free.iterator();
            int n = ((Integer) i.next()).intValue();
            i.remove();
            Entry.Utf8 e = new Entry.Utf8();
            e.utf8 = "";
            this.entries.set(n, e);
        }
        output.writeShort(this.entries.size());
        for (int i = 0; i < this.entries.size(); i++)
            try {
                ((BTPool.Entry) this.entries.get(i)).write(output);
            } catch (Error ee) {
                System.err.println("index: " + i);
                throw ee;
            }
    }

    public BTPool.Entry get(int i) {
        return (BTPool.Entry) this.entries.get(i);
    }

    private int nextIndex(BTPool.Entry e) {
        e.prepareWrite((BTPool) this);
        if (this.allocated.containsKey(e))
            return ((Integer) this.allocated.get(e)).intValue();
        int ret;
        if (this.free.isEmpty() || e.isWide()) {
            this.entries.add(e);
            ret = this.entries.size() - 1;
            if (e.isWide())
                this.entries.add(new Entry.Empty());
        } else {
            Integer i = (Integer) this.free.iterator().next();
            this.free.remove(i);
            ret = i.intValue();
            if (this.entries.get(ret) != null)
                throw new Error(this.entries.get(ret) + " at index " + ret
                    + " was on free list!");
            this.entries.set(ret, e);
        }
        if (this.allocated.containsKey(e))
            throw new Error();
        if (this.allocated.put(e, new Integer(ret)) != null)
            throw new Error();

        if (false && e instanceof Entry.Class) {
            System.out.println("ALLOCATED: " + ret + " " + e + "["
                + (e.hashCode() % 1000) + "]");
        }
        return ret;
    }

    public int allocConstant(Object obj) {
        BTPool.Entry e;
        if (false)
            throw new Error();
        else if (obj instanceof Integer) {
            e = new Entry.CInteger();
            ((Entry.CInteger) e).n = ((Integer) obj).intValue();
        } else if (obj instanceof Float) {
            e = new Entry.CFloat();
            ((Entry.CFloat) e).n = ((Integer) obj).floatValue();
        } else if (obj instanceof Long) {
            e = new Entry.CLong();
            ((Entry.CLong) e).n = ((Long) obj).longValue();
        } else if (obj instanceof Double) {
            e = new Entry.CDouble();
            ((Entry.CDouble) e).n = ((Double) obj).doubleValue();
        } else if (obj instanceof String) {
            e = new Entry.CString();
            ((Entry.CString) e).string = (String) obj;
        } else
            throw new Error("unknown constant: " + obj);
        return this.nextIndex(e);
    }

    public int allocUtf8(String utf8) {
        Entry.Utf8 e = new Entry.Utf8();
        e.utf8 = utf8;
        int n = this.nextIndex(e);
        if (!((BTPool.Entry) this.entries.get(n)).utf8().equals(utf8))
            throw new Error("expected " + e + " but allocated "
                + this.entries.get(n));
        return n;
    }

    public int findUtf8(String utf8) {
        return this.allocUtf8(utf8);
    }

    public int allocNameType(MemberName name, String type) {
        return this.allocNameType(name.javaSource(), type);
    }

    public int allocNameType(String name, String type) {
        Entry.NameType e = new Entry.NameType();
        e.name = name;
        e.type = type;
        return this.nextIndex(e);
    }

    public int allocMethod(BTMethodRef ref, boolean isInterface) {
        Entry.MethodRef e = (isInterface ? new Entry.InterfaceRef()
                : new Entry.MethodRef());
        e.setRef(ref);
        return this.nextIndex(e);
    }

    public int allocField(BTFieldRef ref) {
        Entry.FieldRef e = new Entry.FieldRef();
        e.setRef(ref);
        return this.nextIndex(e);
    }

    public int allocClass(RefType type) {
        Entry.Class e = new Entry.Class();
        e.type = type;
        int ret = this.nextIndex(e);
        if (!((BTPool.Entry) this.entries.get(ret)).clazz().equals(type)) {
            throw new Error("wtf "
                + ((BTPool.Entry) this.entries.get(ret)).clazz() + " vs. "
                + type);
        }
        return ret;
    }

    public static abstract class Entry implements Cloneable {
        public Tag tag() {
            throw new Error("abstract");
        }

        public String utf8() {
            throw new Error(this + " not utf8");
        }

        public String string() {
            throw new Error(this + " not string");
        }

        public RefType clazz() {
            throw new Error(this + " not class type");
        }

        public BTFieldRef fref() {
            throw new Error(this + " not field ref");
        }

        public BTMethodRef mref() {
            throw new Error(this + " not method ref");
        }

        public int intC() {
            throw new Error(this + " not integer");
        }

        public float floatC() {
            throw new Error(this + " not float");
        }

        public double doubleC() {
            throw new Error(this + " not double");
        }

        public long longC() {
            throw new Error(this + " not long");
        }

        public Object constant() {
            throw new Error(this + " not constant");
        }

        String name() {
            throw new Error(this + " not name type");
        }

        String type() {
            throw new Error(this + " not name type");
        }

        public static interface Preserve {
        }

        public boolean isWide() {
            return false;
        }

        public void read(DataInputStream input) throws IOException {
        }

        public void resolve(ClassModel clazz) {
        }

        public void prepareWrite(BTPool pool) {
        }

        public void write(DataOutputStream out) throws IOException {
            out.writeByte(this.tag().tag());
        }

        public BTPool.Entry replace(ReplaceBT replace) {
            return (BTPool.Entry) this;
        }

        public int hashCode() {
            return this.tag().hashCode();
        }

        public boolean equals(Object o) {
            if (!(o instanceof Entry))
                return false;
            else
                return ((BTPool.Entry) o).equals((BTPool.Entry) this);
        }

        public boolean equals(BTPool.Entry e) {
            return this.tag() == e.tag();
        }

        public String toString() {
            String str = this.getClass().getName();
            str = str.substring(str.lastIndexOf('$') + 1, str.length());
            return str;
        }

        static abstract class OneIndex extends BTPool.Entry {
            protected int index;

            public void read(DataInputStream input) throws IOException {
                this.index = input.readUnsignedShort();
                if (this.index == 0)
                    throw new Error("read zero index: " + this);
            }

            public void resolve(ClassModel clazz) {
                try {
                    clazz.body().pool().get(this.index).resolve(clazz);
                } catch (Error e) {
                    e.printStackTrace();
                    System.err.println("index: " + this.index + " in " + clazz);
                    throw new Error();
                }
            }

            public void write(DataOutputStream out) throws IOException {
                super.write(out);
                if (this.index == 0)
                    throw new Error(this + " has zero index!");
                out.writeShort(this.index);
            }

            public String toString() {
                return super.toString() + "\t" + this.index;
            }
        }

        static abstract class TwoIndex extends Entry.OneIndex {
            protected int index2;

            public void read(DataInputStream input) throws IOException {
                super.read(input);
                this.index2 = input.readUnsignedShort();
                if (this.index2 == 0)
                    throw new Error("read zero index2: " + this);
            }

            public void resolve(ClassModel clazz) {
                super.resolve(clazz);
                clazz.body().pool().get(this.index2).resolve(clazz);
            }

            public void write(DataOutputStream out) throws IOException {
                super.write(out);
                if (this.index2 == 0)
                    throw new Error(this + " has zero index2!");
                out.writeShort(this.index2);
            }

            public String toString() {
                return super.toString() + "\t" + this.index2;
            }
        }

        static class Class extends Entry.OneIndex implements Entry.Preserve {
            RefType type;

            public Tag tag() {
                return CT_Class;
            }

            public RefType clazz() {
                if (this.type == null)
                    throw new Error("not resolved yet!");
                else
                    return this.type;
            }

            public String toString() {
                String s = super.toString() + "\t";
                if (this.type instanceof ClassType)
                    s += ((ClassType) this.type).jvmClassString();
                else
                    s += this.type.jvmTypeString();
                return s;
            }

            public int hashCode() {
                return super.hashCode() + this.type.hashCode();
            }

            public boolean equals(BTPool.Entry e) {
                if (!(e instanceof Class))
                    return false;
                if (!((Class) e).type.equals(this.type) || !super.equals(e)) {
                    if (((Class) e).type == this.type)
                        throw new Error("" + this.type);
                    if (((Class) e).type.toString()
                        .equals(this.type.toString()))
                        throw new Error("wtf: " + this.type.toString());
                    return false;
                }
                return true;
            }

            public void resolve(ClassModel clazz) {
                super.resolve(clazz);
                String tstr = clazz.body().pool().get(this.index).utf8();
                try {
                    if (tstr.charAt(0) == '[')
                        this.type = (ArrayType) TypeType.parseJvmType(tstr,
                            clazz.pkg().root().env());
                    else {
                        if (clazz == null)
                            throw new Error();
                        if (clazz.pkg() == null)
                            throw new Error(clazz + "");
                        if (clazz.pkg().root() == null)
                            throw new Error(clazz.pkg() + "");
                        if (clazz.pkg().root().env() == null)
                            throw new Error(clazz.pkg().root() + "");
                        this.type = clazz.pkg().root().env().findVMClass(tstr);
                    }
                } catch (Error e) {
                    System.err.println("utf8 index: " + this.index + " = "
                        + tstr);
                    throw e;
                }
            }

            public void prepareWrite(BTPool pool) {
                super.prepareWrite(pool);
                String tstr;
                if (this.type instanceof ClassType) {
                    tstr = ((ClassType) this.type).jvmClassString();
                    if (tstr.indexOf('/') == -1)
                        throw new Error("not good: " + tstr);
                } else {
                    tstr = ((ArrayType) this.type).jvmTypeString();
                }
                this.index = pool.allocUtf8(tstr);
                if (!((BTPool.Entry) pool.entries.get(this.index)).utf8()
                    .equals(tstr))
                    throw new Error("allocated " + tstr + " but got "
                        + ((BTPool.Entry) pool.entries.get(this.index)).utf8());
            }

            public BTPool.Entry replace(ReplaceBT replace) {
                RefType type = (RefType) this.type.replace(replace);
                if (type == this.type)
                    return super.replace(replace);
                if (!(type instanceof ClassType)
                    && !(type instanceof ArrayType))
                    throw new Error(type + " is wrong");
                Class copy = (Class) this.copy();
                copy.type = type;
                return copy;
            }
        }

        static class CString extends Entry.OneIndex implements Entry.Preserve {
            String string;

            public Tag tag() {
                return CT_String;
            }

            public String toString() {
                return super.toString() + "\t" + this.string;
            }

            public String string() {
                if (this.string == null)
                    throw new Error("not resolved yet!");
                else
                    return this.string;
            }

            public int hashCode() {
                return super.hashCode() + this.string.hashCode();
            }

            public boolean equals(BTPool.Entry e) {
                return super.equals(e)
                    && ((CString) e).string.equals(this.string);
            }

            public void resolve(ClassModel clazz) {
                super.resolve(clazz);
                this.string = clazz.body().pool().get(this.index).utf8();
            }

            public void prepareWrite(BTPool pool) {
                super.prepareWrite(pool);
                this.index = pool.allocUtf8(this.string);
            }

            public Object constant() {
                return this.string;
            }
        }

        static abstract class Ref extends Entry.TwoIndex implements
                Entry.Preserve {
            protected abstract BTMemberRef ref();

            protected abstract void setRef(BTMemberRef ref);

            public BTFieldRef fref() {
                return (BTFieldRef) this.ref();
            }

            public BTMethodRef mref() {
                return (BTMethodRef) this.ref();
            }

            public int hashCode() {
                return super.hashCode() + this.ref().hashCode();
            }

            public boolean equals(BTPool.Entry e) {
                return super.equals(e) && ((Ref) e).ref().equals(this.ref());
            }

            public String toString() {
                return super.toString() + "\t" + this.ref();
            }

            public BTPool.Entry replace(ReplaceBT replace) {
                BTMemberRef ref = this.ref().replace0(replace);
                if (ref == this.ref())
                    return this;
                Ref copy = (Ref) this.copy();
                copy.setRef(ref);
                return copy;
            }

            public void resolve(ClassModel clazz) {
                super.resolve(clazz);
                ClassType ctype = (ClassType) clazz.body().pool().get(
                    this.index).clazz();
                this.setRef(this.ref().setClass0(ctype));
                NameType nt = (NameType) clazz.body().pool().get(this.index2);
                ShapeKey member = new ShapeKey();
                member = member.set(new ProcedureShape());
                /* procedure is not empty */
                if (!nt.name().equals("<init>")) {
                    member = member.set(member.nameType().setName(
                        new MemberName(nt.name())));
                    member = member.parseJvmType(nt.type(), clazz.pkg().root()
                        .env());
                } else {
                    member = member.parseJvmType(nt.type(), clazz.pkg().root()
                        .env());
                    member = member.set(NameTypeShape.EMPTY);
                }
                this.setRef(this.ref().setMember0(member));
            }

            public void prepareWrite(BTPool pool) {
                super.prepareWrite(pool);
                this.index = pool.allocClass(this.ref().clazz());
                if (this.index == 0)
                    throw new Error();
            }
        }

        static class MethodRef extends Entry.Ref {
            BTMethodRef mref = new BTMethodRef();

            protected BTMemberRef ref() {
                return this.mref;
            }

            protected void setRef(BTMemberRef ref) {
                this.mref = (BTMethodRef) ref;
            }

            public Tag tag() {
                return CT_MethodRef;
            }

            public void prepareWrite(BTPool pool) {
                if (this.mref.member().nameType() != NameTypeShape.EMPTY) {
                    if (this.mref == null)
                        throw new Error(this + " has null mref");
                    else if (this.mref.clazz() == null)
                        throw new Error(this + " has null clazz");
                    else if (this.mref.clazz().shape() == null)
                        throw new Error(this + " has null shape");
                    else if (this.mref.member() == null)
                        throw new Error(this + " has null member");

                    ClassType ftype = this.mref.clazz().shape().lookupMethod(
                        this.mref.member());

                    if (ftype == null) {
                        System.err.println("XXXXXXXXXXXXXXXX trying to find "
                            + this.mref + " in " + this.mref.clazz());
                        for (ClassType ct = this.mref.clazz();
                             ct != null;
                             ct = ct.shape().zuper()) {
                            System.err.println(this.mref.member()
                                + " "
                                + ct.shape().methods().contains(
                                    this.mref.member()) + " "
                                + ct.shape().methods());
                            ct.rawShape().print(ct, "", System.err, null);
                        }
                        TypeType type0 = this.mref.member().nameType().type();
                        for (Iterator i = this.mref.clazz().shape().methods()
                                 .iterator();
                             i.hasNext();
                             /* i = i */) {
                            ShapeKey key = (ShapeKey) i.next();
                            TypeType type1 = key.nameType().type();
                            System.err.println("X " + key + " " + type0 + " "
                                + type1 + " " + type0.equals(type1) + " "
                                + type1.equals(type0));
                            if (type1 instanceof GJVariableType
                                && type0 instanceof TypeModel) {
                                ClassType bound =
                                    ((GJVariableType) type1).bound();
                                System.err.println("Y " + bound.equals(type0)
                                    + " " + type0.equals(bound) + " "
                                    + bound.pkg0().root0() + " "
                                    + ((ClassType) type0).pkg0().root0());
                                if (bound instanceof TypeModel) {
                                    ClassModel clazz0 =
                                        (((TypeModel) type0).clazz());
                                    ClassModel clazz1 =
                                        (((TypeModel) bound).clazz());
                                    System.err.println("Z " + clazz0 + " "
                                        + clazz1 + " " + (clazz0 == clazz1));
                                    System.err.println("V "
                                        + clazz0.pkg().root().hashCode() + " "
                                        + clazz1.pkg().root().hashCode());
                                }
                            }
                        }
                        throw new Error("method ref " + this.mref.member()
                            + " not found from "
                            + this.mref.clazz().javaSource());
                    }

                    if (!ftype.equals(this.mref.clazz())) {
                        if (ftype.rawShape().isSet(FlagConstants.INTERFACE) ==
                            this.mref.clazz().rawShape().isSet(
                                FlagConstants.INTERFACE)) {
                            if (dbg)
                                System.err.println("adjust method ref "
                                    + this.mref + " to " + ftype);
                            this.mref = this.mref.setClass(ftype);
                        }
                    }
                }
                super.prepareWrite(pool);
                String name;
                String type = this.mref.member().procedure().jvmTypeString();
                if (this.mref.member().nameType() == NameTypeShape.EMPTY) {
                    name = "<init>";
                    type = type + TypeConstants.VOID.jvmTypeString();
                } else {
                    name = this.mref.member().nameType().name().javaSource();
                    type = type
                        + this.mref.member().nameType().type().jvmTypeString();
                }
                this.index2 = pool.allocNameType(name, type);
            }
        }

        static class InterfaceRef extends Entry.MethodRef {
            public Tag tag() {
                return CT_InterfaceRef;
            }
        }

        static class FieldRef extends Entry.Ref {
            BTFieldRef fref = new BTFieldRef();

            protected BTMemberRef ref() {
                return this.fref;
            }

            protected void setRef(BTMemberRef ref) {
                this.fref = (BTFieldRef) ref;
            }

            public Tag tag() {
                return CT_FieldRef;
            }

            public void prepareWrite(BTPool pool) {
                ClassType ftype = this.fref.clazz().shape().lookupField(
                    this.fref.member());
                if (ftype == null) {
                    for (ClassType z = this.fref.clazz();
                         z != null;
                         z = z.shape().zuper())
                        System.err.println(z + " " + z.shape().fields() + " "
                            + z.shape().interfaces());
                    for (Iterator i = this.fref.clazz().shape().interfaces()
                             .iterator();
                         i.hasNext();
                         /* i = i */) {
                        ClassType z = (ClassType) i.next();
                        System.err.println(z + " " + z.shape().fields());
                    }
                    throw new Error("field ref " + this.fref + " not found");
                }
                if (!ftype.equals(this.fref.clazz())) {
                    if (dbg)
                        System.err.println("adjust field ref " + this.fref
                            + " to " + ftype);
                    this.fref = this.fref.setClass(ftype);
                }
                super.prepareWrite(pool);
                String name;
                name = this.fref.member().nameType().name().javaSource();
                this.index2 = pool.allocNameType(name, this.fref.member()
                    .nameType().type().jvmTypeString());
            }
        }

        static class NameType extends Entry.TwoIndex {
            String name;
            String type;

            public Tag tag() {
                return CT_NameType;
            }

            public String toString() {
                return super.toString() + "\t" + this.name + "\t" + this.type;
            }

            public void resolve(ClassModel clazz) {
                super.resolve(clazz);
                this.name = clazz.body().pool().get(this.index).utf8();
                this.type = clazz.body().pool().get(this.index2).utf8();
            }

            public int hashCode() {
                return super.hashCode() + this.name.hashCode()
                    + this.type.hashCode();
            }

            public boolean equals(BTPool.Entry e) {
                return super.equals(e) && ((NameType) e).name.equals(this.name)
                    && ((NameType) e).type.equals(this.type);
            }

            public void prepareWrite(BTPool pool) {
                super.prepareWrite(pool);
                this.index = pool.allocUtf8(this.name);
                this.index2 = pool.allocUtf8(this.type);
            }

            String name() {
                if (this.name == null)
                    throw new Error("resolve first");
                else
                    return this.name;
            }

            String type() {
                if (this.type == null)
                    throw new Error("resolve first");
                else
                    return this.type;
            }
        }

        static class Utf8 extends BTPool.Entry {
            String utf8;

            public String toString() {
                return super.toString() + "\t" + this.utf8;
            }

            public Tag tag() {
                return CT_Utf8;
            }

            public String utf8() {
                return this.utf8;
            }

            public int hashCode() {
                return super.hashCode() + this.utf8.hashCode();
            }

            public boolean equals(BTPool.Entry e) {
                return super.equals(e) && ((Utf8) e).utf8.equals(this.utf8);
            }

            public void read(DataInputStream input) throws IOException {
                this.utf8 = input.readUTF();
            }

            public void write(DataOutputStream out) throws IOException {
                super.write(out);
                out.writeUTF(this.utf8);
            }
        }

        static abstract class Numeric extends BTPool.Entry implements
                Entry.Preserve {
            public int hashCode() {
                return super.hashCode() + this.constant().hashCode();
            }

            public boolean equals(BTPool.Entry e) {
                return super.equals(e)
                    && this.constant().equals(((Numeric) e).constant());
            }

            public String toString() {
                return super.toString() + "\t" + this.constant();
            }
        }

        static class CInteger extends Entry.Numeric {
            int n;

            public Tag tag() {
                return CT_Integer;
            }

            public int intC() {
                return this.n;
            }

            public Object constant() {
                return new Integer(this.n);
            }

            public void read(DataInputStream input) throws IOException {
                this.n = input.readInt();
            }

            public void write(DataOutputStream out) throws IOException {
                super.write(out);
                out.writeInt(this.n);
            }
        }

        static class CFloat extends Entry.Numeric {
            float n;

            public Tag tag() {
                return CT_Float;
            }

            public float floatC() {
                return this.n;
            }

            public Object constant() {
                return new Float(this.n);
            }

            public void read(DataInputStream input) throws IOException {
                this.n = input.readFloat();
            }

            public void write(DataOutputStream out) throws IOException {
                super.write(out);
                out.writeFloat(this.n);
            }
        }

        static class CDouble extends Entry.Numeric {
            double n;

            public Tag tag() {
                return CT_Double;
            }

            public boolean isWide() {
                return true;
            }

            public double doubleC() {
                return this.n;
            }

            public Object constant() {
                return new Double(this.n);
            }

            public void read(DataInputStream input) throws IOException {
                this.n = input.readDouble();
            }

            public void write(DataOutputStream out) throws IOException {
                super.write(out);
                out.writeDouble(this.n);
            }
        }

        static class CLong extends Entry.Numeric {
            long n;

            public Tag tag() {
                return CT_Long;
            }

            public boolean isWide() {
                return true;
            }

            public long longC() {
                return this.n;
            }

            public Object constant() {
                return new Long(this.n);
            }

            public void read(DataInputStream input) throws IOException {
                this.n = input.readLong();
            }

            public void write(DataOutputStream out) throws IOException {
                super.write(out);
                out.writeLong(this.n);
            }
        }

        public static class Empty extends BTPool.Entry implements
                Entry.Preserve {
            public Tag tag() {
                return null;
            }

            public void read(DataInputStream input) throws IOException {
                throw new Error("should not read");
            }

            public void write(DataOutputStream out) throws IOException {
                return;
            }

            public String toString() {
                return "EMPTY";
            }

            public int hashCode() {
                return 0;
            }

            public boolean equals(BTPool.Entry e) {
                return e.tag() == null;
            }
        }

        public BTPool.Entry copy() {
            try {
                return (BTPool.Entry) this.clone();
            } catch (Exception e) {
                throw new Error("" + e);
            }
        }

        // static Map<Integer,Tag> tags = new HashMap<Integer,Tag>();
        static Map tags = new HashMap();

        public static BTPool.Entry readEntry(DataInputStream input)
                throws IOException {
            int b = input.readUnsignedByte();
            if (!Entry.tags.containsKey(new Integer(b)))
                throw new Error("illegal ct type " + b);
            BTPool.Entry e = ((Tag) Entry.tags.get(new Integer(b))).newEntry();
            e.read(input);
            return e;
        }

        public static abstract class Tag {
            final int tag;

            Tag(int tag) {
                this.tag = tag;
                Entry.tags.put(new Integer(this.tag), this);
            }

            int tag() {
                return this.tag;
            }

            public abstract BTPool.Entry newEntry();
        }

        static final Tag CT_Class = new Tag(7) {
            public BTPool.Entry newEntry() {
                return new Entry.Class();
            }
        };
        static final Tag CT_FieldRef = new Tag(9) {
            public BTPool.Entry newEntry() {
                return new Entry.FieldRef();
            }
        };
        static final Tag CT_MethodRef = new Tag(10) {
            public BTPool.Entry newEntry() {
                return new Entry.MethodRef();
            }
        };
        static final Tag CT_InterfaceRef = new Tag(11) {
            public BTPool.Entry newEntry() {
                return new Entry.InterfaceRef();
            }
        };
        static final Tag CT_String = new Tag(8) {
            public BTPool.Entry newEntry() {
                return new Entry.CString();
            }
        };
        static final Tag CT_Integer = new Tag(3) {
            public BTPool.Entry newEntry() {
                return new Entry.CInteger();
            }
        };
        static final Tag CT_Float = new Tag(4) {
            public BTPool.Entry newEntry() {
                return new Entry.CFloat();
            }
        };
        static final Tag CT_Long = new Tag(5) {
            public BTPool.Entry newEntry() {
                return new Entry.CLong();
            }
        };
        static final Tag CT_Double = new Tag(6) {
            public BTPool.Entry newEntry() {
                return new Entry.CDouble();
            }
        };
        static final Tag CT_NameType = new Tag(12) {
            public BTPool.Entry newEntry() {
                return new Entry.NameType();
            }
        };
        static final Tag CT_Utf8 = new Tag(1) {
            public BTPool.Entry newEntry() {
                return new Entry.Utf8();
            }
        };
    }
}
