/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package edu.utah.jiggy.meta.flag;

public abstract class AccessFlag extends AdvancingFlag.Use implements AllFlag {
    // protected
    // public
    public AccessFlag(AccessFlag parent) {
        super(parent);
    }

    public boolean isa(AccessFlag ac) {
        return this.isa0(ac);
    }

    public AccessFlag parent() {
        return (AccessFlag) this.parent0();
    }

    // Below here,
    // From `edu.utah.jiggy.bytecode/outflag/Access.java'.

    public static AccessFlag parse(int code) {
        AccessFlag ACCESS[] = {
            FlagConstants.PRIVATE,
            FlagConstants.PUBLIC,
            FlagConstants.PROTECTED, };
        for (int i = 0; i < ACCESS.length; i++)
            if ((code & ACCESS[i].jvmcode()) != 0)
                return ACCESS[i];
        return FlagConstants.PACKAGE;
    }

    public int jvmcode() {
        return 0;
    }
}
