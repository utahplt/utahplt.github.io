/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.core outshape.IsMethod */

package edu.utah.jiggy.meta.shape;

import java.util.*;

import edu.utah.jiggy.meta.flag.BinaryFlag;
import edu.utah.jiggy.meta.flag.FlagConstants;
import edu.utah.jiggy.meta.flag.VirtualFlag;
import edu.utah.jiggy.meta.type.ClassType;

public class MethodShape extends MemberShape {
    protected VirtualFlag virtual = FlagConstants.CONCRETE;
    protected NameTypeShape nameType;
    protected ProcedureShape procedure;
    protected ThrowzShape throwz = new ThrowzShape(); /* not empty */

    public void set(NameTypeShape s) {
        this.nameType = s;
    }

    public void set(ProcedureShape s) {
        this.procedure = s;
    }

    public void set(ThrowzShape s) {
        this.throwz = s;
    }

    public void set(VirtualFlag v) {
        this.validate(v);
        this.virtual = v;
    }

    protected Set supported() {
        return FlagConstants.METHOD_FLAGS;
    }

    public ShapeKey replaceKey(ReplaceShape replace, ClassType ctype) {
        if (this.access().isa(FlagConstants.PACKAGE)
            && !this.isSet(FlagConstants.STATIC)) {
            ClassType ctype0;
            try {
                ctype0 = ctype.shape().freshMethod(this.key());
            } catch (Error e) {
                System.err.println("tried to find fresh method for "
                    + this.javaSource(null) + " from " + ctype.javaSource());
                throw e;
            }
            if (ctype0 != null && ctype0 != ctype) {
                ctype = ctype0;
            }
        }
        return super.replaceKey(replace, ctype);
    }

    public String javaSource(String cname) {
        return super.javaSource(cname) + this.nameType.javaSource()
            + this.procedure.javaSource() + this.throwz.javaSource();
    }

    public VirtualFlag virtual() {
        return this.virtual;
    }

    public NameTypeShape nameType() {
        return this.nameType;
    }

    public ProcedureShape procedure() {
        return this.procedure;
    }

    public ThrowzShape throwz() {
        return this.throwz;
    }

    public MethodShape() {
        super();
    }

    // Below here,
    // From `edu.utah.jiggy.bytecode/outshape/Method.java'.

    public String jvmTypeString() {
        return this.procedure().jvmTypeString() + super.jvmTypeString();
    }

    public InitShape makeInit() {
        InitShape init = new InitShape();
        init.set(this.access());
        for (Iterator i = this.binaries().iterator(); i.hasNext(); /* i = i */)
            init.set((BinaryFlag) i.next());
        init.set(this.procedure());
        init.set(this.throwz());
        return init;
    }
}
