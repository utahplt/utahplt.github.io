/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package edu.utah.jiggy.instruction.ins;

import java.util.*;
import java.io.*;

public abstract class Control extends java.lang.Object {
    Control parent;

    // protected final Map<ins.Block,ins.Control> children =
    // new HashMap<ins.Block,ins.Control>();
    // protected final List<ins.Block> order =
    // new ArrayList<ins.Block>();
    protected final Map children = new HashMap();
    protected final List order = new ArrayList();

    public Control(Control parent) {
        this.parent = parent;
    }

    public Control parent() {
        return this.parent;
    }

    public Control child(Block block) {
        return (Control) this.children.get(block);
    }

    /* both are exclusive */
    public abstract Block entrance();

    public abstract Block exit();

    public Set merges() {
        return this.parent().merges();
    }

    public void notify(Merge merge) {
        if (this.parent() != null)
            this.parent().notify(merge);
    }

    public boolean isExit(Block block) {
        if (block == this.exit())
            return true;
        else if (this.parent() != null)
            return this.parent().isExit(block);
        else
            return false;
    }

    public void print(PrintStream out) {
        out.println("parent=" + parent + " order=" + this.order + " children="
            + this.children + " exit=" + this.exit());
        for (Iterator i = this.order.iterator(); i.hasNext(); /* i = i */) {
            Block b = (Block) i.next();
            out.println("*** " + this.children.get(b));
            ((Control) this.children.get(b)).print(out);
        }
    }

    public Merge findMerge(Block block) {
        return this.parent().findMerge(block);
    }

    public boolean isMerge(Block block, Block target) {
        boolean dom = target.dominates(block);
        for (Iterator i = target.predecessors().iterator();
             i.hasNext();
             /* i = i */) {
            Block block0 = (Block) i.next();
            if (block == block0)
                continue;
            if (dom != target.dominates(block0))
                continue;
            return true;
        }
        return false;
    }

    public void process() {
        this.process(this.entrance());
    }

    public void process(Block b) {
        while (true) {
            // System.out.println("PROCESS " + this + " " + b + " " +
            // this.isExit(b) + " " + this.exit());
            if (b == null)
                break;
            if (this.isExit(b))
                break;
            if (this.children.containsKey(b))
                throw new Error("zenme le! " + this + " " + b + " "
                    + this.children.get(b));
            /* check for loop first */
            if (!(this instanceof Loop) || (((Loop) this).head() != b)) {
                Set predecessors = b.predecessors();
                boolean isContinue = false;
                for (Iterator i = predecessors.iterator();
                     i.hasNext();
                     /* i = i */) {
                    Block p = (Block) i.next();
                    if (b.dominates(p)) {
                        /* loop */
                        Loop loop = new Loop((Control) this, b);
                        try {
                            loop.process();
                        } catch (Error e) {
                            System.err.println(loop);
                            throw e;
                        }
                        this.children.put(b, loop);
                        this.order.add(b);
                        Block t = loop.exit();
                        if (t == null)
                            return;
                        if (t.dominates(b))
                            return;
                        b = t;
                        isContinue = true;
                        break;
                    }
                }
                if (isContinue)
                    continue;
            }
            /* now check if we need a merge */
            Set branches = b.branches();
            if (branches.size() == 0)
                break;
            if (branches.size() == 1) {
                Block target = (Block) branches.iterator().next();
                if (target.dominates(b))
                    return;
                if (this.isMerge(b, target)) {
                    this.notify(this.findMerge(target));
                    return;
                }
                b = target;
                continue;
            }
            if (branches.size() > 2)
                throw new Error("switches not yet supported");
            Split split = new Split((Control) this, b);
            try {
                split.process();
            } catch (Error e) {
                System.err.println(split);
                throw e;
            }
            this.children.put(b, split);
            this.order.add(b);
            Block t = split.exit();
            if (t == null)
                return;
            if (t.dominates(b))
                return;
            b = t;
            continue;
        }
        return;
    }
}
