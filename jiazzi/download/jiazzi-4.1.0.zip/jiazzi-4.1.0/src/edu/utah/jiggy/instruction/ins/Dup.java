/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.bytecode.ins outins.Dup */

package edu.utah.jiggy.instruction.ins;

public class Dup extends Instruction {
    static void activate() {
        for (int i = 1; i <= 2; i++)
            for (int j = 0; j <= 2; j++)
                (new Dup(i, j)).put00();
    }

    final int width;
    final int behind;

    public String mnemonic() {
        return "dup" + (this.width > 1 ? "" + this.width : "")
            + (this.behind > 0 ? "_x" + this.behind : "");
    }

    public int opcode() {
        return 89 + (3 * (this.width - 1)) + this.behind;
    }

    public int width() {
        return this.width;
    }

    public int behind() {
        return this.behind;
    }

    public void execute(Machine m) {
        Value[] v = new Value[this.behind];
        int n = 0;
        while (n < this.behind) {
            v[n] = m.pop();
            n += v[n].type(m.context).stackWidth();
        }
        m.doError(n == this.behind,
            "" + (v.length == 1 ?
                    v[0] + (v.length == 2 ? " " + v[1] : "")
                    : ""));
        Value dup = m.pop();
        m.doError(dup.type(m.context).stackWidth() == this.width, "" + dup);
        m.push(dup);
        for (n = v.length; n > 0; n--) {
            if (v[n - 1] != null)
                m.push(v[n - 1]);
        }
        m.push(dup);
    }

    public Dup(int width, int behind) {
        super();
        this.width = width;
        this.behind = behind;
        if (this.width < 1)
            throw new Error();
        if (this.width > 2)
            throw new Error();
        if (this.behind < 0)
            throw new Error();
        if (this.behind > 2)
            throw new Error();
    }

    protected int size() {
        return 1;
    }
}
