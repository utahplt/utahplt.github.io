/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package edu.utah.jiggy.meta.type;

import edu.utah.jiggy.instruction.ins.Machine;

public class ArrayType extends RefType {
    public TypeType elem;
    public int dim;

    public ArrayType(TypeType elem, int dim) {
        super();
        if (elem instanceof ArrayType)
            throw new Error();
        this.elem = elem;
        this.dim = dim;
    }

    public TypeType elem() {
        return this.elem;
    }

    public int dim() {
        return this.dim;
    }

    public TypeType down() {
        if (this.dim <= 0)
            throw new Error();
        else if (this.dim == 1)
            return this.elem;
        else {
            ArrayType a = (ArrayType) this.copy();
            a.elem = this.elem;
            a.dim = this.dim - 1;
            return a;
        }
    }

    public ArrayType up() {
        ArrayType a = (ArrayType) this.copy();
        a.elem = this.elem;
        a.dim = this.dim + 1;
        return a;
    }

    public TypeType replace(ReplaceType replace) {
        ArrayType array = (ArrayType) super.replace(replace);
        if (array != this)
            return array;
        TypeType elem = array.elem.replace(replace);
        if (array.elem == elem)
            return array;
        if (array == this)
            array = (ArrayType) array.copy();
        array.elem = elem;
        return array;
    }

    public String toString() {
        return this.elem().toString() + "[" + this.dim + "]";
    }

    public String javaSource() {
        String str = "";
        for (int i = 0; i < this.dim(); i++)
            str += "[]";
        return this.elem().javaSource() + str;
    }

    public TypeType copy() {
        ArrayType array = (ArrayType) super.copy();
        array.dim = this.dim;
        array.elem = this.elem.copy();
        return array;
    }

    public ArrayType setElement(TypeType elem) {
        if (elem instanceof ArrayType)
            throw new Error();
        if (elem == this.elem)
            return (ArrayType) this;
        ArrayType copy = (ArrayType) this.copy();
        copy.elem = elem;
        return copy;
    }

    public boolean isa(TypeType type) {
        if (super.isa(type))
            return true;
        else if (!(type instanceof ArrayType))
            return false;
        else if (((ArrayType) type).dim != this.dim)
            return false;
        else
            return this.elem.isa(((ArrayType) type).elem);
    }

    public boolean equals(TypeType t) {
        if (!(t instanceof ArrayType))
            return t.reverseEquals(this);
        ArrayType a = (ArrayType) t;
        if (!super.equals(a))
            return t.reverseEquals(this);
        else if (this.dim != a.dim)
            return t.reverseEquals(this);
        else if (!this.elem.equals(a.elem))
            return t.reverseEquals(this);
        else
            return true;
    }

    /*
     * public boolean matches(TypeType t) { if (!(t instanceof type.Array))
     * return false; type.Array a = (type.Array) t; if (!super.matches(a))
     * return false; else if (this.dim != a.dim) return false; else if
     * (!this.elem.matches(a.elem)) return false; else return true; }
     */

    public int hashCode() {
        return super.hashCode() + this.dim + this.elem.hashCode();
    }

    // Below here,
    // From `edu.utah.jiggy.bytecode/outtype/Array.java'.

    public String jvmTypeString() {
        String string = "";
        for (int i = 0; i < this.dim(); i++)
            string += "[";
        return string + this.elem().jvmTypeString();
    }

    // Below here,
    // From `edu.utah.jiggy.instruction/outtype/Array.java'.

    public TypeType merge(TypeType t, Machine m) {
        if (t instanceof ArrayType) {
            TypeType elem = this.down().merge(((ArrayType) t).down(), m);
            if (elem == TypeConstants.ERROR)
                return super.merge(t, m);
            else
                return elem.up();
        } else
            return super.merge(t, m);
    }
}
