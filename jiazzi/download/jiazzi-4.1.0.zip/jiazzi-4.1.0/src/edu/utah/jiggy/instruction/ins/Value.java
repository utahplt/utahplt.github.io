/*
 * Copyright (c) 2004, 2005, 2006 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package edu.utah.jiggy.instruction.ins;

import java.util.*;

import edu.utah.jiggy.bytecode.bt.BTCode;
import edu.utah.jiggy.clazz.ClassModel;
import edu.utah.jiggy.meta.shape.ArgShape;
import edu.utah.jiggy.meta.type.Environment;
import edu.utah.jiggy.meta.type.TypeConstants;
import edu.utah.jiggy.meta.type.TypeType;

public abstract class Value {
    public abstract TypeType type(Environment env);

    public abstract String valueString();

    public int hashCode() {
        return this.valueString().hashCode();
    }

    public abstract Block block();

    public boolean isDirty() {
        return false;
    }

    public static final Value SECOND = new Value() {
        public TypeType type(Environment env) {
            return TypeConstants.ERROR;
        }

        public String valueString() {
            return "<wd>";
        }

        public Block block() {
            return null;
        }
    };
    public static final Value ERROR = new Value() {
        public TypeType type(Environment env) {
            return TypeConstants.ERROR;
        }

        public String valueString() {
            return "<err>";
        }

        public Block block() {
            return null;
        }
    };

    public Value mergeInto(Machine m, Value to, Block fromblk, Block toblk) {
        if (this == to)
            return to;
        if (to == ERROR || this == ERROR)
            return ERROR;
        if (to == SECOND || this == SECOND)
            return ERROR;
        Value.Phi top;
        if (to instanceof Value.Phi) {
            top = (Value.Phi) to;
            if (toblk.phis.contains(top)) {
                top.add(m, fromblk, (Value) this);
                return top;
            }
        }
        if (toblk.mergedWith.size() == 1
                && toblk.mergedWith.contains(fromblk)) {
            return (Value) this;
        }
        top = new Value.Phi(toblk);
        top.add(m, fromblk, (Value) this);
        for (Iterator i = toblk.mergedWith.iterator();
             i.hasNext();
             /* i = i */) {
            Block t = (Block) i.next();
            if (t != fromblk)
                top.add(m, t, to);
        }
        if (top.values.size() < 2)
            throw new Error(toblk.mergedWith + " " + top.values);
        return top;
    }

    public static class Exception extends Value {
        public final BTCode.ExceptionEntry exc;

        public Exception(BTCode.ExceptionEntry exc) {
            this.exc = exc;
        }

        public TypeType type(Environment env) {
            return this.exc.catchType();
        }

        public String valueString() {
            return "e"
                + (this.exc.handler == null ? this.exc.handler + "" :
                    "" + this.exc.handler.getPC());
        }

        public Block block() {
            return this.exc.handler;
        }

        public BTCode.ExceptionEntry entry() {
            return this.exc;
        }
    }

    public static class Phi extends Value implements Cloneable {
        // public Map<ins.Block,ins.Value> values = new
        // HashMap<ins.Block,ins.Value>();
        public Map values = new HashMap();
        public TypeType type;
        int id;
        boolean dirty = false;

        public boolean isDirty() {
            boolean b = this.dirty;
            this.dirty = false;
            return b;
        }

        public int nphi() {
            return this.id;
        }

        public void add(Machine m, Block t, Value v) {
            if (this.values.put(t, v) == v)
                return;
            this.dirty = true;
            if (this.type == null)
                this.type = v.type(m.context);
            else if (this.type == v.type(m.context))
                return;
            else {
                this.type = this.type.merge(v.type(m.context), m);
                return;
            }
        }

        public TypeType type(Environment env) {
            return this.type;
        }

        Block block;

        public Block block() {
            return this.block;
        }

        public Phi(Block block) {
            this.id = block.phis.size();
            this.block = block;
            block.phis.add((Value.Phi) this);
        }

        public Iterator args() {
            return this.values.values().iterator();
        }

        public Set targets() {
            return this.values.keySet();
        }

        public Value getArg(Block t) {
            return (Value) this.values.get(t);
        }

        public String valueString() {
            return "p" + this.block.getPC() + "_" + this.id;
        }

        public String toString() {
            if (this.values.keySet().size() < 2)
                throw new Error();
            String s = this.valueString() + " := phi[";
            for (Iterator i = this.values.keySet().iterator();
                 i.hasNext();
                 /* i = i */) {
                Block tm = (Block) i.next();
                s = s + tm + ":" + ((Value) this.values.get(tm)).valueString();
                if (i.hasNext())
                    s = s + ", ";
            }
            return s + "]";
        }
    }

    public static class This extends Value {
        ClassModel clazz;

        public This(ClassModel clazz) {
            this.clazz = clazz;
        }

        public TypeType type(Environment env) {
            return this.clazz.newType();
        }

        public String valueString() {
            return "vT";
        }

        public Block block;

        public Block block() {
            return this.block;
        }
    }

    public static class Arg extends Value {
        int pos;
        ArgShape arg;

        public Arg(int pos, ArgShape arg) {
            this.pos = pos;
            this.arg = arg;
        }

        public TypeType type(Environment env) {
            return this.arg.type();
        }

        public String valueString() {
            return "a" + this.pos;
        }

        public Block block;

        public Block block() {
            return this.block;
        }
    }
}
