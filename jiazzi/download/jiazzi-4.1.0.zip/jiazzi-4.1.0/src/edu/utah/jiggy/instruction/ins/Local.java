/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.bytecode.ins outins.Local */

package edu.utah.jiggy.instruction.ins;

import java.io.*;

import edu.utah.jiggy.clazz.ClassModel;
import edu.utah.jiggy.meta.flag.FlagConstants;
import edu.utah.jiggy.meta.shape.ShapeKey;

public abstract class Local extends SimpleTyped {
    protected int index = 0;
    static final int IMMEDIATE_COUNT = 4;
    static final int TYPE_COUNT = TypeInfo.REFERENCE.opcodeOffset() + 1;

    public Instruction replace(ReplaceIns replace) {
        Instruction instr = super.replace(replace);
        if (instr != this)
            return instr;
        /* determine if arguments are added */
        int n = replace.mmbr().replace(replace).procedure().stackWidth()
            - replace.mmbr().procedure().stackWidth();
        if (n != 0) {
            if (this.index() >=
                (replace.mmbr().procedure().stackWidth()
                        + (replace.mmbr().isSet(FlagConstants.STATIC) ?
                                0 : 1))) {
                /* n is number of single wide arguments added to method */
                /* move local index up by n places */
                return this.setIndex(this.index() + n);
            }
        }
        return this;
    }

    static void activate() {
        TypeInfo types[] = {
            TypeInfo.INT,
            TypeInfo.LONG,
            TypeInfo.FLOAT,
            TypeInfo.DOUBLE,
            TypeInfo.REFERENCE };
        for (int i = 0; i < types.length; i++) {
            Local.Load load = new Local.Load(types[i]);
            Local.Store store = new Local.Store(types[i]);
            for (int j = 0; j <= IMMEDIATE_COUNT; j++) {
                load.setIndex(j).put00();
                store.setIndex(j).put00();
            }
        }
    }

    public int index() {
        return this.index;
    }

    public Local setIndex(int index) {
        Local copy = (Local) this.copy();
        copy.index = index;
        return copy;
    }

    public Local(TypeInfo type) {
        super(type);
    }

    protected boolean isLoad() {
        return true;
    }

    protected int size() {
        if (this.index() < IMMEDIATE_COUNT)
            return 1;
        else if (!this.isWide())
            return 2;
        else
            return 4;
    }

    public boolean isWide() {
        return this.index() >= 256;
    }

    public String mnemonic() {
        return this.typeInfo().mnemonic() + (this.isLoad() ? "load" : "store")
            + (this.index() < IMMEDIATE_COUNT ? "_" + this.index() : "");
    }

    public String toString() {
        return super.toString()
            + (this.index() >= IMMEDIATE_COUNT ? " " + this.index() : "");
    }

    public int opcode() {
        if (this.index() >= IMMEDIATE_COUNT)
            return this.typeInfo().opcodeOffset();
        else
            return TYPE_COUNT
                + (this.typeInfo().opcodeOffset() * IMMEDIATE_COUNT)
                + this.index();
    }

    public boolean baseEquals(Instruction ins) {
        return super.baseEquals(ins) && ((Local) ins).index() == this.index();
    }

    public int baseHashCode() {
        return super.baseHashCode() + this.index();
    }

    public Instruction read(int pc, DataInputStream input, ClassModel clazz,
                            ShapeKey mthd) throws IOException {
        Local copy = (Local) super.read(pc, input, clazz, mthd);
        if (this.index() < IMMEDIATE_COUNT)
            return copy;
        else
            return copy.setIndex(input.readUnsignedByte());
    }

    public Instruction readWide(int pc, DataInputStream input,
                                ClassModel clazz, ShapeKey mthd)
            throws IOException {
        Local copy = (Local) super.readWide(pc, input, clazz, mthd);
        return copy.setIndex(input.readUnsignedShort());
    }

    public void write(int pc, DataOutputStream out, ClassModel clazz,
                      ShapeKey mthd) throws IOException {
        super.write(pc, out, clazz, mthd);
        if (this.index() >= IMMEDIATE_COUNT)
            out.writeByte(this.index());
    }

    public void writeWide(int pc, DataOutputStream out, ClassModel clazz,
                          ShapeKey mthd) throws IOException {
        super.writeWide(pc, out, clazz, mthd);
        out.writeShort(this.index());
    }

    public static class Load extends Local {
        static final int BASE = 21;

        public Load(TypeInfo type) {
            super(type);
        }

        protected boolean isLoad() {
            return true;
        }

        public int opcode() {
            return super.opcode() + BASE;
        }

        public void execute(Machine m) {
            super.execute(m);
            Value value = m.load(this.index);
            m.doError(value.type(m.context).isa(this.typeInfo()), " " + value);
            m.push(value);
        }
    }

    /* atom-edu.utah.jiggy.bytecode.ins outins.Local.Store */
    public static class Store extends Local {
        static final int BASE = 54;

        public Store(TypeInfo type) {
            super(type);
        }

        protected boolean isLoad() {
            return false;
        }

        public int opcode() {
            return super.opcode() + BASE;
        }

        public void execute(Machine m) {
            super.execute(m);
            Value value = m.pop();
            m.doError(value.type(m.context).isa(this.typeInfo()), value + "");
            m.store(this.index, value);
        }
    }
}
