/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.bytecode.ins outins.Arithmetic */

package edu.utah.jiggy.instruction.ins;

import edu.utah.jiggy.meta.type.Environment;
import edu.utah.jiggy.meta.type.TypeConstants;
import edu.utah.jiggy.meta.type.TypeType;

public abstract class Arithmetic extends SimpleTyped {

    public int argCount() {
        return this.op0().operands();
    }

    public void execute(Machine m) {
        Value value0 = null, value1 = null;

        if (this.op0().operands() == 2) {
            value0 = m.pop();
            m.doError(value0.type(m.context).isa(
                this.op0().typeFor(1, this.typeInfo())));
        }
        value1 = m.pop();
        m.doError(value1.type(m.context).isa(
            this.op0().typeFor(0, this.typeInfo())));
        this.args().add(value1);
        if (value0 != null)
            this.args().add(value0);
        m.push(this);
    }

    public TypeType type(Environment env) {
        return ((TypeInfo.Primitive) this.typeInfo()).ptype;
    }

    static void activate() {
        {
            Arithmetic.Operation.General ops[] =
                { ADD, SUB, REM, DIV, NEG, MUL };
            TypeInfo types[] = {
                TypeInfo.INT, TypeInfo.LONG, TypeInfo.FLOAT, TypeInfo.DOUBLE };
            for (int i = 0; i < ops.length; i++)
                for (int j = 0; j < types.length; j++)
                    (new Arithmetic.General(ops[i], types[j])).put00();
        }
        {
            Arithmetic.Operation.Integral ops[] = {
                USHR, SHR, AND, SHL, OR, XOR };
            TypeInfo types[] = { TypeInfo.INT, TypeInfo.LONG };
            for (int i = 0; i < ops.length; i++)
                for (int j = 0; j < types.length; j++)
                    (new Arithmetic.Integral(ops[i], types[j])).put00();
        }
    }

    public final static Arithmetic.Add ADD = new Arithmetic.Add();
    public final static Arithmetic.Subtract SUB = new Arithmetic.Subtract();
    public final static Arithmetic.Shift.Right.Unsigned USHR =
        new Arithmetic.Shift.Right.Unsigned();
    public final static Arithmetic.Shift.Right.Signed SHR =
        new Arithmetic.Shift.Right.Signed();
    public final static Arithmetic.And AND = new Arithmetic.And();
    public final static Arithmetic.Remainder REM = new Arithmetic.Remainder();
    public final static Arithmetic.Divide DIV = new Arithmetic.Divide();
    public final static Arithmetic.Negate NEG = new Arithmetic.Negate();
    public final static Arithmetic.Shift.Left SHL =
        new Arithmetic.Shift.Left();
    public final static Arithmetic.Or OR = new Arithmetic.Or();
    public final static Arithmetic.Xor XOR = new Arithmetic.Xor();
    public final static Arithmetic.Multiply MUL = new Arithmetic.Multiply();

    public abstract Arithmetic.Operation op0();

    protected int size() {
        return 1;
    }

    public String mnemonic() {
        return this.typeInfo().mnemonic() + this.op0().mnemonic();
    }

    public int opcode() {
        return this.op0().opcodeOffset() + this.typeInfo().opcodeOffset();
    }

    public Arithmetic(TypeInfo type) {
        super(type);
    }

    /* atom-edu.utah.jiggy.bytecode.ins outins.Arithmetic.Remainder */
    public static class Remainder extends Arithmetic.Operation.General {
        public int opcodeOffset() {
            return 112;
        }

        public String mnemonic() {
            return "rem";
        }

        public Remainder() {
            super();
        }
    }

    /* atom-edu.utah.jiggy.bytecode.ins outins.Arithmetic.Divide */
    public static class Divide extends Arithmetic.Operation.General {
        public int opcodeOffset() {
            return 108;
        }

        public String mnemonic() {
            return "div";
        }

        public Divide() {
            super();
        }
    }

    /* atom-edu.utah.jiggy.bytecode.ins outins.Arithmetic.Subtract */
    public static class Subtract extends Arithmetic.Operation.General {
        public int opcodeOffset() {
            return 100;
        }

        public String mnemonic() {
            return "sub";
        }

        public Subtract() {
            super();
        }
    }

    /* atom-edu.utah.jiggy.bytecode.ins outins.Arithmetic.And */
    public static class And extends Arithmetic.Operation.Integral {
        public int opcodeOffset() {
            return 126;
        }

        public String mnemonic() {
            return "and";
        }

        public And() {
            super();
        }
    }

    /* atom-edu.utah.jiggy.bytecode.ins outins.Arithmetic.Operation */
    public abstract static class Operation extends java.lang.Object {
        public int operands() {
            return 2;
        }

        public TypeType typeFor(int n, TypeInfo type) {
            return ((TypeInfo.Primitive) type).ptype;
        }

        public abstract int opcodeOffset();

        public abstract String mnemonic();

        public Operation() {
            super();
        }

        /* atom-edu.utah.jiggy.bytecode.ins outins.Arithmetic.Operation.Integral */
        public abstract static class Integral extends Arithmetic.Operation {
            public Integral() {
                super();
            }
        }

        /* atom-edu.utah.jiggy.bytecode.ins outins.Arithmetic.Operation.General */
        public abstract static class General extends Arithmetic.Operation {
            public General() {
                super();
            }
        }
    }

    /* atom-edu.utah.jiggy.bytecode.ins outins.Arithmetic.Or */
    public static class Or extends Arithmetic.Operation.Integral {
        public int opcodeOffset() {
            return 128;
        }

        public String mnemonic() {
            return "or";
        }

        public Or() {
            super();
        }
    }

    /* atom-edu.utah.jiggy.bytecode.ins outins.Arithmetic.Xor */
    public static class Xor extends Arithmetic.Operation.Integral {
        public int opcodeOffset() {
            return 130;
        }

        public String mnemonic() {
            return "xor";
        }

        public Xor() {
            super();
        }
    }

    /* atom-edu.utah.jiggy.bytecode.ins outins.Arithmetic.Negate */
    public static class Negate extends Arithmetic.Operation.General {
        public int opcodeOffset() {
            return 116;
        }

        public String mnemonic() {
            return "neg";
        }

        public int operands() {
            return 1;
        }

        public Negate() {
            super();
        }
    }

    /* atom-edu.utah.jiggy.bytecode.ins outins.Arithmetic.Multiply */
    public static class Multiply extends Arithmetic.Operation.General {
        public int opcodeOffset() {
            return 104;
        }

        public String mnemonic() {
            return "mul";
        }

        public Multiply() {
            super();
        }
    }

    /* atom-edu.utah.jiggy.bytecode.ins outins.Arithmetic.General */
    public static class General extends Arithmetic {
        final Arithmetic.Operation.General op;

        public Arithmetic.Operation.General op() {
            return this.op;
        }

        public Arithmetic.Operation op0() {
            return this.op();
        }

        public General(Arithmetic.Operation.General op, TypeInfo type) {
            super(type);
            this.op = op;
        }
    }

    /* atom-edu.utah.jiggy.bytecode.ins outins.Arithmetic.Integral */
    public static class Integral extends Arithmetic {
        final Arithmetic.Operation.Integral op;

        public Arithmetic.Operation.Integral op() {
            return this.op;
        }

        public Arithmetic.Operation op0() {
            return this.op();
        }

        public Integral(Arithmetic.Operation.Integral op, TypeInfo type) {
            super(type);
            this.op = op;
        }
    }

    /* atom-edu.utah.jiggy.bytecode.ins outins.Arithmetic.Shift */
    public abstract static class Shift extends Arithmetic.Operation.Integral {
        public Shift() {
            super();
        }

        public TypeType typeFor(int n, TypeInfo type) {
            if (n == 1)
                return TypeConstants.INT;
            else
                return super.typeFor(n, type);
        }

        /* atom-edu.utah.jiggy.bytecode.ins outins.Arithmetic.Shift.Left */
        public static class Left extends Arithmetic.Shift {
            public int opcodeOffset() {
                return 120;
            }

            public String mnemonic() {
                return "shl";
            }

            public Left() {
                super();
            }
        }

        /* atom-edu.utah.jiggy.bytecode.ins outins.Arithmetic.Shift.Right */
        public abstract static class Right extends Arithmetic.Shift {
            public Right() {
                super();
            }

            /*
             * atom-edu.utah.jiggy.bytecode.ins
             * outins.Arithmetic.Shift.Right.Signed
             */
            public static class Signed extends Arithmetic.Shift.Right {
                public int opcodeOffset() {
                    return 122;
                }

                public String mnemonic() {
                    return "shr";
                }

                public Signed() {
                    super();
                }
            }

            /*
             * atom-edu.utah.jiggy.bytecode.ins
             * outins.Arithmetic.Shift.Right.Unsigned
             */
            public static class Unsigned extends Arithmetic.Shift.Right {
                public int opcodeOffset() {
                    return 124;
                }

                public String mnemonic() {
                    return "ushr";
                }

                public Unsigned() {
                    super();
                }
            }
        }
    }

    /* atom-edu.utah.jiggy.bytecode.ins outins.Arithmetic.Add */
    public static class Add extends Arithmetic.Operation.General {
        public int opcodeOffset() {
            return 96;
        }

        public String mnemonic() {
            return "add";
        }

        public Add() {
            super();
        }
    }
}
