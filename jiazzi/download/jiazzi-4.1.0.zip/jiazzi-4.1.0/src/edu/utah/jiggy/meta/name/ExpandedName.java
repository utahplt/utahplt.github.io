/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.meta outname.ExpandedName */

package edu.utah.jiggy.meta.name;

public class ExpandedName extends java.lang.Object implements Cloneable {
    protected String append;
    protected String prepend;

    protected VariableName var = VariableName.NULL;

    public VariableName var() {
        return this.var;
    }

    public String extract() {
        if (this.var() != VariableName.NULL)
            throw new Error();
        return this.append + this.prepend;
    }

    public String toString() {
        return this.prepend.toString() + this.var.toString()
            + this.append.toString();
    }

    public ExpandedName replace(ReplaceName replace) {
        ExpandedName copy = this.copy();
        ExpandedName exp = replace.get(this.var);
        copy.prepend = this.prepend + exp.prepend;
        copy.append = exp.append + this.append;
        copy.var = exp.var;
        return copy;
    }

    public ExpandedName(java.lang.String prepend, VariableName var,
                        String append) {
        super();
        this.prepend = prepend;
        this.var = var;
        this.append = append;
    }

    protected ExpandedName copy() {
        try {
            return (ExpandedName) this.clone();
        } catch (CloneNotSupportedException e) {
            throw new Error();
        }
    }

    public ExpandedName prepend(String s) {
        ExpandedName copy = this.copy();
        copy.prepend = s + copy.prepend;
        return copy;
    }

    public ExpandedName append(String s) {
        ExpandedName copy = this.copy();
        copy.append = copy.append + s;
        return copy;
    }
}
