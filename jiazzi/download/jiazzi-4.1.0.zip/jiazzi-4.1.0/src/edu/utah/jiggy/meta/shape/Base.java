/*
 * Copyright (c) 2004, 2005, 2006 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.core outshape.Base */

package edu.utah.jiggy.meta.shape;

import java.util.*;

import edu.utah.jiggy.meta.flag.AccessFlag;
import edu.utah.jiggy.meta.flag.BinaryFlag;
import edu.utah.jiggy.meta.flag.Flag;
import edu.utah.jiggy.meta.flag.FlagConstants;
import edu.utah.jiggy.meta.flag.VirtualFlag;

// XXX: rename this class to `BaseShape' or similar, to avoid conflicts and
// confusing code elsewhere.
//
public abstract class Base extends java.lang.Object implements
        java.lang.Cloneable {
    // protected Set<BinaryFlag> binaries = new HashSet<BinaryFlag>();
    protected Set binaries = new HashSet();
    protected AccessFlag access = FlagConstants.PUBLIC;

    public Base() {
        super();
    }

    protected Set supported() {
        throw new Error("abstract");
    }

    protected void validate(Flag flag) {
        if (!this.supported().contains(flag))
            throw new Error(flag + " not supported by " + this.getClass());
    }

    public void add(Builder bld) {
        for (Iterator i = bld.binaries.iterator(); i.hasNext(); /* i = i */)
            this.set((BinaryFlag) i.next());
        this.set(bld.access);
        this.set(bld.virtual);
    }

    public void set(AccessFlag access) {
        this.validate(access);
        this.access = access;
    }

    public void set(VirtualFlag virtual) {
        if (virtual == FlagConstants.CONCRETE)
            return;
        else
            throw new Error(virtual + " not supported by " + this.getClass());
    }

    public void set(BinaryFlag binary) {
        this.validate(binary);
        this.binaries.add(binary);
    }

    public void unset(BinaryFlag binary) {
        this.binaries.remove(binary);
    }

    public AccessFlag access() {
        return this.access;
    }

    public Set binaries() {
        return this.binaries;
    }

    public boolean isSet(BinaryFlag a0) {
        return this.binaries.contains(a0);
    }

    public boolean isSet(Flag flag) {
        if (flag instanceof BinaryFlag)
            return this.isSet((BinaryFlag) flag);
        else if (flag instanceof AccessFlag)
            return flag == this.access();
        else if (flag instanceof VirtualFlag)
            return flag == this.virtual();
        else
            throw new Error("unknown flag " + flag);
    }

    public String toString() {
        return this.javaSource0();
    }

    public Base copy() {
        if (this.binaries == null)
            throw new Error("no binaries set for " + this + " "
                + this.getClass());
        try {
            Base copy = (Base) this.clone();
            copy.binaries = new HashSet(this.binaries);
            return copy;
        } catch (CloneNotSupportedException e) {
            throw new Error("" + e);
        }
    }

    protected String javaSource0() {
        String str = this.access().javaSource() + this.virtual().javaSource();
        for (Iterator i = this.binaries.iterator(); i.hasNext(); /* i = i */)
            str = str + ((BinaryFlag) i.next()).javaSource();
        return str;
    }

    private boolean matchIfEqual(Base b, BinaryFlag flag) {
        return (this.binaries.contains(flag) == b.binaries.contains(flag));
    }

    private boolean matchIfSet(Base b, BinaryFlag flag) {
        boolean isRequired = b.binaries.contains(flag);
        if (isRequired) {
            return this.binaries.contains(flag);
        }
        return true;
    }

    public boolean matches(Base b) {
        // `b' is the specification that `this' must satisfy.
        //
        // Previously, this method checked that the binary flags were equal:
        //
        // if (!this.binaries.equals(b.binaries))
        //     return false;
        //
        // But that condition is too strict.  Most binary flags don't actually
        // matter for shape compatibility: for example, we don't care if the
        // definition of a class, field, or method is marked as deprecated.  So
        // now we really only check the flags that we actually care about.

        if (!matchIfEqual(b, FlagConstants.IMMUTABLE)
                || !matchIfEqual(b, FlagConstants.INTERFACE)
                || !matchIfEqual(b, FlagConstants.STATIC)) {
            return false;
        }
        // For paranoia's sake: if `b' requires that other flags be set, then
        // match only if they are set in `this'.  But I'm pretty sure that the
        // following flags should never be set in `b'.
        //
        // TODO: reconsider SYNCHRONIZED, TRANSIENT, and VOLATILE.
        // Are they really not part of a component interface?  I believe that
        // they are not, but I need to think more about this.
        if (!matchIfSet(b, FlagConstants.DEPRECATED)
                || !matchIfSet(b, FlagConstants.NATIVE)
                || !matchIfSet(b, FlagConstants.STRICT)
                || !matchIfSet(b, FlagConstants.SYNCHRONIZED)
                || !matchIfSet(b, FlagConstants.SYNTHETIC)
                || !matchIfSet(b, FlagConstants.TRANSIENT)
                || !matchIfSet(b, FlagConstants.VOLATILE)) {
            return false;
        }

        // Check the compatibility of the other fields, too.

        if (!this.access().isa(b.access()))
            return false;
        
        if (this.virtual() == FlagConstants.FINAL
            && b.virtual() != FlagConstants.FINAL)
            return false;

        return true;
    }

    public VirtualFlag virtual() {
        return FlagConstants.CONCRETE;
    }

    public int hashCode() {
        throw new Error("should not be hashed: " + this.getClass());
    }

    public boolean equals(Object e) {
        throw new Error("should not be equaled: " + this.getClass());
    }
}
