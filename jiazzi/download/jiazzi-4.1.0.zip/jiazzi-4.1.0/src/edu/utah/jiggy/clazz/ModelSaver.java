/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.bytecode outclazz.Saver */

package edu.utah.jiggy.clazz;

import java.io.*;
import java.util.*;

public abstract class ModelSaver extends java.lang.Object {
    public void save(PackageModel pkg) throws java.io.IOException {
        this.forPackage(pkg);
        for (Iterator i = pkg.classes().values().iterator();
             i.hasNext();
             /* i = i */) {
            ClassModel clazz = (ClassModel) i.next();
            clazz.body().prepareWrite(clazz);
            DataOutputStream out = new DataOutputStream(this.forClass(clazz));
            try {
                clazz.body().write(out, clazz);
            } catch (Error e) {
                System.err.println("error saving "
                    + clazz.newType().javaSource() + " in " + this);
                throw e;
            }
        }
    }

    public void save(ModelRoot root) throws java.io.IOException {
        // System.err.println("save " + root + " to " + this);
        for (Iterator i = root.packages().values().iterator();
             i.hasNext();
             /* i = i */)
            this.save((PackageModel) i.next());
    }

    public abstract void close() throws java.io.IOException;

    public ModelSaver() {
        super();
    }

    protected abstract java.io.OutputStream forClass(ClassModel clazz)
            throws java.io.IOException;

    protected abstract void forPackage(PackageModel pkg)
            throws java.io.IOException;
}
