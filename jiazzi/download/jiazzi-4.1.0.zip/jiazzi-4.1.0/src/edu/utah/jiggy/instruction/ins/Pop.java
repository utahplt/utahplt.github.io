/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.bytecode.ins outins.Pop */

package edu.utah.jiggy.instruction.ins;

public class Pop extends Instruction {
    static void activate() {
        (new Pop(1)).put00();
        (new Pop(2)).put00();
    }

    final int width;

    public java.lang.String mnemonic() {
        return "pop" + (this.width > 1 ? "" + this.width : "");
    }

    public int width() {
        return this.width;
    }

    public int opcode() {
        return 87 + this.width - 1;
    }

    public void execute(Machine m) {
        String s = "";
        int i;
        for (i = 0; i < this.width; /* i = i */) {
            Value v = m.pop();
            i = i + v.type(m.context).stackWidth();
            s = s + " " + v;
        }
        m.doError(i == this.width, s);
    }

    public Pop(int width) {
        super();
        if (width < 1)
            throw new Error();
        if (width > 2)
            throw new Error();
        this.width = width;
    }

    protected int size() {
        return 1;
    }
}
