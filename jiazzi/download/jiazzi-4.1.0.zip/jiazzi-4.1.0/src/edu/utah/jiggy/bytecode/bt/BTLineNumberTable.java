/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.bytecode outattr.LineNumberTable */

package edu.utah.jiggy.bytecode.bt;

import java.util.*;
import java.io.*;

import edu.utah.jiggy.clazz.ClassModel;
import edu.utah.jiggy.instruction.ins.Block;
import edu.utah.jiggy.meta.shape.Base;
import edu.utah.jiggy.meta.shape.MemberShape;
import edu.utah.jiggy.meta.shape.ShapeKey;

public class BTLineNumberTable extends BTAttr {
    // protected Set<bt.LineNumberTable.Entry> entries =
    // new HashSet<bt.LineNumberTable.Entry>();
    protected Set entries = new HashSet();

    public BTAttr copy() {
        BTLineNumberTable copy = (BTLineNumberTable) super.copy();
        copy.entries = new HashSet(copy.entries);
        return copy;
    }

    public Set entries() {
        return this.entries;
    }

    protected boolean isClass() {
        return false;
    }

    public String name() {
        return "LineNumberTable";
    }

    protected int size(ClassModel clazz, Base base) {
        return 2 + (this.entries.size() * 4);
    }

    public String toString() {
        return super.toString() + ":" + this.entries;
    }

    public BTAttr readMember(int size, DataInputStream in, ClassModel clazz,
                             BTMember mmbr, MemberShape bld) throws IOException {
        BTLineNumberTable attr = (BTLineNumberTable) super.readMember(size, in,
            clazz, mmbr, bld);
        int count = in.readUnsignedShort();
        for (int i = 0; i < count; i++) {
            attr.entries.add(new BTLineNumberTable.Entry(
                in.readUnsignedShort(), in.readUnsignedShort()));
        }
        return attr;
    }

    public void writeMember(DataOutputStream out, ClassModel clazz,
                            ShapeKey mmbr) throws IOException {
        super.writeMember(out, clazz, mmbr);
        out.writeShort(this.entries.size());
        for (Iterator i = this.entries.iterator(); i.hasNext(); /* i = i */) {
            BTLineNumberTable.Entry e = (BTLineNumberTable.Entry) i.next();
            out.writeShort(e.startPC());
            out.writeShort(e.lineNumber());
        }
    }

    public BTLineNumberTable() {
        super();
    }

    /* atom-edu.utah.jiggy.bytecode outbt.LineNumberTable.Entry */
    public static class Entry extends java.lang.Object implements Cloneable {
        int startPC;
        final int lineNumber;

        public BTLineNumberTable.Entry copy() {
            try {
                return (BTLineNumberTable.Entry) this.clone();
            } catch (Throwable t) {
                throw new Error();
            }
        }

        public void setStartPC(int pc) {
            this.startPC = pc;
        }

        public int startPC() {
            return this.startPC;
        }

        public int lineNumber() {
            return this.lineNumber;
        }

        public Entry(int startPC, int lineNumber) {
            this.startPC = startPC;
            this.lineNumber = lineNumber;
        }

        public String toStringInternal() {
            return this.startPC + ":" + this.lineNumber;
        }

        // Below here (in this class),
        // From `edu.utah.jiggy.instruction/outbt/LineNumberTable.java'.

        public Block block = null;

        public String toString() {
            return toStringInternal()
                + (this.block == null ? "" : ":" + this.block);
        }

    }

    // Below here,
    // From `edu.utah.jiggy.instruction/outbt/LineNumberTable.java'.

    public BTAttr updateBranch(Map map) {
        BTLineNumberTable copy = (BTLineNumberTable) super.updateBranch(map);
        for (Iterator i = this.entries().iterator();
             i.hasNext();
             /* i = i */) {
            BTLineNumberTable.Entry e = (BTLineNumberTable.Entry) i.next();
            Block b = (Block) map.get(e.block);
            if (b == null && e.block != null)
                throw new Error();
            if (b == null)
                continue;
            if (b == e.block)
                throw new Error();

            if (copy == this)
                copy = (BTLineNumberTable) this.copy();
            if (copy == this)
                throw new Error("wtf");
            if (!copy.entries().remove(e))
                throw new Error();
            e = e.copy();
            e.block = b;
            copy.entries().add(e);
        }
        return copy;
    }

    public void setBlocks(BTCode code) {
        for (Iterator i = this.entries().iterator();
             i.hasNext();
             /* i = i */) {
            BTLineNumberTable.Entry e = (BTLineNumberTable.Entry) i.next();
            e.block = code.findTarget(e.startPC());
            if (e.block.getPC() != e.startPC())
                throw new Error("WTF");
        }
        return;
    }

    protected void write(DataOutputStream out, ClassModel clazz, Base base)
            throws IOException {
        for (Iterator i = this.entries().iterator();
             i.hasNext();
             /* i = i */) {
            BTLineNumberTable.Entry e = (BTLineNumberTable.Entry) i.next();
            if (e.block != null && e.block.getPC() != e.startPC()) {
                e.setStartPC(e.block.getPC());
            }
        }
        super.write(out, clazz, base);
    }
}
