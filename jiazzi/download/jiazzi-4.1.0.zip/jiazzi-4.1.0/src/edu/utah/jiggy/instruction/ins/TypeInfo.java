/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.bytecode.ins outins.TypeInfo */

package edu.utah.jiggy.instruction.ins;

import java.util.*;

import edu.utah.jiggy.meta.type.PrimitiveType;
import edu.utah.jiggy.meta.type.RefType;
import edu.utah.jiggy.meta.type.TypeConstants;
import edu.utah.jiggy.meta.type.TypeType;

public abstract class TypeInfo {
    public abstract char mnemonic();

    public abstract int opcodeOffset();

    public TypeInfo() {
    }

    public boolean isa(TypeInfo type) {
        if (this == type)
            return true;
        else
            return false;
    }

    public int stackWidth() {
        return 1;
    }

    public static abstract class Primitive extends TypeInfo {
        public final PrimitiveType ptype;

        Primitive(PrimitiveType ptype) {
            this.ptype = ptype;
            pmap.put(ptype, this);
        }

        public int stackWidth() {
            return this.ptype.stackWidth();
        }
    }

    public static abstract class Integral extends TypeInfo.Primitive {
        Integral(PrimitiveType ptype) {
            super(ptype);
        }

        public boolean isa(TypeInfo type) {
            if (type instanceof TypeInfo.Integral)
                return true;
            else
                return super.isa(type);
        }
    }

    // public final static Map<type.Primitive,TypeInfo.Primitive> pmap = new
    // HashMap<type.Primitive,TypeInfo.Primitive>();
    public final static Map pmap = new HashMap();

    public static TypeInfo get(TypeType type) {
        if (type instanceof RefType)
            return REFERENCE;
        if (!(type instanceof PrimitiveType))
            throw new Error();
        PrimitiveType p = (PrimitiveType) type;
        if (!pmap.containsKey(p))
            throw new Error();
        return (TypeInfo) pmap.get(p);
    }

    public final static TypeInfo INT = new Integral(TypeConstants.INT) {
        public char mnemonic() {
            return 'i';
        }

        public int opcodeOffset() {
            return 0;
        }
    };
    public final static TypeInfo LONG = new Primitive(TypeConstants.LONG) {
        public char mnemonic() {
            return 'l';
        }

        public int opcodeOffset() {
            return 1;
        }
    };
    public final static TypeInfo FLOAT = new Primitive(TypeConstants.FLOAT) {
        public char mnemonic() {
            return 'f';
        }

        public int opcodeOffset() {
            return 2;
        }
    };
    public final static TypeInfo DOUBLE = new Primitive(TypeConstants.DOUBLE) {
        public char mnemonic() {
            return 'd';
        }

        public int opcodeOffset() {
            return 3;
        }
    };
    public final static TypeInfo REFERENCE = new TypeInfo() {
        public char mnemonic() {
            return 'a';
        }

        public int opcodeOffset() {
            return 4;
        }
    };
    public final static TypeInfo BYTE = new Integral(TypeConstants.BYTE) {
        public char mnemonic() {
            return 'b';
        }

        public int opcodeOffset() {
            return 5;
        }
    };
    public final static TypeInfo BOOLEAN = new Integral(TypeConstants.BOOLEAN) {
        public char mnemonic() {
            return 'z';
        }

        public int opcodeOffset() {
            return 5;
        }
    };
    public final static TypeInfo CHAR = new Integral(TypeConstants.CHAR) {
        public char mnemonic() {
            return 'c';
        }

        public int opcodeOffset() {
            return 6;
        }
    };
    public final static TypeInfo SHORT = new Integral(TypeConstants.SHORT) {
        public char mnemonic() {
            return 's';
        }

        public int opcodeOffset() {
            return 7;
        }
    };
    public final static TypeInfo VOID = new TypeInfo() {
        public char mnemonic() {
            return ' ';
        }

        public int opcodeOffset() {
            return 5;
        }
    };
}
