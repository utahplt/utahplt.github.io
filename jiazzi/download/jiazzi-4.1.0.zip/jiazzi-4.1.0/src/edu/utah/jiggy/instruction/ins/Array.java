/*
 * Copyright (c) 2004, 2005, 2006 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.bytecode.ins outins.Array */

package edu.utah.jiggy.instruction.ins;

import java.io.*;

import edu.utah.jiggy.clazz.ClassModel;
import edu.utah.jiggy.meta.shape.ShapeKey;
import edu.utah.jiggy.meta.type.ArrayType;
import edu.utah.jiggy.meta.type.Environment;
import edu.utah.jiggy.meta.type.PrimitiveType;
import edu.utah.jiggy.meta.type.RefType;
import edu.utah.jiggy.meta.type.TypeConstants;
import edu.utah.jiggy.meta.type.TypeType;

public abstract class Array extends Instruction implements
        Instruction.Imperative {
    static void activate() {
        (new Array.New.Primitive()).put00();
        (new Array.New.Ref()).put00();
        (new Array.New.Multi()).put00();
        (new Array.Length()).put00();
        TypeInfo types[] = {
            TypeInfo.INT,
            TypeInfo.LONG,
            TypeInfo.FLOAT,
            TypeInfo.DOUBLE,
            TypeInfo.REFERENCE,
            TypeInfo.BYTE,
            TypeInfo.CHAR,
            TypeInfo.SHORT };
        for (int i = 0; i < types.length; i++) {
            (new Array.Simple.Load(types[i])).put00();
            (new Array.Simple.Store(types[i])).put00();
        }
    }

    public Array() {
        super();
    }

    public abstract static class New extends Array {
        public New() {
            super();
        }

        public static abstract class OneD extends Array.New {
            public int argCount() {
                return 1;
            }

            public void execute(Machine m) {
                Value length = m.pop();
                this.args().add(length);
                m.doError(length.type(m.context).isa(TypeInfo.INT));
                m.push(this);
            }
        }

        public static class Primitive extends Array.New.OneD {
            protected PrimitiveType type;

            public PrimitiveType type() {
                return this.type;
            }

            public String mnemonic() {
                return "newarray";
            }

            public TypeType type(Environment env) {
                return this.type.up();
            }

            public Array.New.Primitive setType(PrimitiveType type) {
                if (type == this.type)
                    return (Array.New.Primitive) this;
                if (type == null)
                    throw new Error();
                Array.New.Primitive copy = (Array.New.Primitive) this.copy();
                copy.type = type;
                return copy;
            }

            public Instruction replace(ReplaceIns replace) {
                Array.New.Primitive ins = (Array.New.Primitive) super
                    .replace(replace);
                if (ins != this)
                    return ins;
                return ins
                    .setType((PrimitiveType) this.type().replace(replace));
            }

            public int opcode() {
                return 188;
            }

            public Primitive() {
                super();
            }

            protected int size() {
                return 2;
            }

            public Instruction read(int pc, DataInputStream input,
                                    ClassModel clazz, ShapeKey mthd)
                    throws IOException {
                Array.New.Primitive copy =
                    ((Array.New.Primitive) super.read(pc, input, clazz, mthd));
                return copy.setType((PrimitiveType) PrimitiveType.arrayMap
                    .get(new Integer(input.readUnsignedByte())));
            }

            public void write(int pc, DataOutputStream out, ClassModel clazz,
                              ShapeKey mthd) throws IOException {
                super.write(pc, out, clazz, mthd);
                out.writeByte(this.type().arrayCode());
            }

            public boolean baseEquals(Instruction ins) {
                return super.baseEquals(ins)
                    && ((this.type == null
                            && ((Array.New.Primitive) ins).type == this.type)
                            || (this.type != null
                                    && this.type.equals(
                                        ((Array.New.Primitive) ins).type)));
            }

            public int baseHashCode() {
                return super.baseHashCode()
                    + (this.type == null ? 0 : this.type.hashCode());
            }
        }

        public static class Ref extends Array.New {
            protected RefType type;

            public String mnemonic() {
                return "anewarray";
            }

            public TypeType type(Environment env) {
                return this.type.up();
            }

            public String toString() {
                return super.toString() + " " + this.type.javaSource();
            }

            public Array.New.Ref setType(RefType type) {
                if (type == this.type)
                    return (Array.New.Ref) this;
                Array.New.Ref copy = (Array.New.Ref) this.copy();
                copy.type = type;
                return copy;
            }

            public Instruction read(int pc, DataInputStream input,
                                    ClassModel clazz, ShapeKey mthd)
                    throws IOException {
                Array.New.Ref copy =
                    (Array.New.Ref) super.read(pc, input, clazz, mthd);
                return copy.setType(clazz.body().pool().get(
                    input.readUnsignedShort()).clazz());
            }

            public Instruction prepareWrite(int pc, ClassModel clazz,
                                            ShapeKey mthd) {
                clazz.body().pool().allocClass(this.type);
                return super.prepareWrite(pc, clazz, mthd);
            }

            public void write(int pc, DataOutputStream out, ClassModel clazz,
                              ShapeKey mthd) throws IOException {
                super.write(pc, out, clazz, mthd);
                out.writeShort(clazz.body().pool().allocClass(this.type));
            }

            public Instruction replace(ReplaceIns replace) {
                Array.New.Ref ins = (Array.New.Ref) super.replace(replace);
                if (ins != this)
                    return ins;
                return ins.setType((RefType) this.type().replace(replace));
            }

            public boolean baseEquals(Instruction ins) {
                if (!super.baseEquals(ins))
                    return false;
                if (this.type == null)
                    return ((Array.New.Ref) ins).type == null;
                else
                    return this.type.equals(((Array.New.Ref) ins).type);
            }

            public int baseHashCode() {
                return super.baseHashCode()
                    + (this.type == null ? 0 : this.type.hashCode());
            }

            public RefType type() {
                return this.type;
            }

            public int opcode() {
                return 189;
            }

            public Ref() {
                super();
            }

            protected int size() {
                return 3;
            }
        }

        public static class Multi extends Array.New {
            protected ArrayType type;
            protected int dimensions;

            public int argCount() {
                return this.dimensions();
            }

            public void execute(Machine m) {
                for (int i = this.dimensions() - 1; i >= 0; i--) {
                    Value length = m.pop();
                    this.args().add(length);
                    m.doError(length.type(m.context).isa(TypeInfo.INT), "");
                }
                m.push(this);
            }

            public TypeType type(Environment env) {
                return this.type;
            }

            public Instruction read(int pc, DataInputStream input,
                                    ClassModel clazz, ShapeKey mthd)
                    throws IOException {
                return ((Array.New.Multi) super.read(pc, input, clazz, mthd))
                    .setArray(
                        (ArrayType) clazz.body().pool().get(
                            input.readUnsignedShort()).clazz()).setDimensions(
                        input.readUnsignedByte());
            }

            public Instruction prepareWrite(int pc, ClassModel clazz,
                                            ShapeKey mthd) {
                // int index =
                clazz.body().pool().allocClass(this.type);
                return super.prepareWrite(pc, clazz, mthd);
            }

            public void write(int pc, DataOutputStream out, ClassModel clazz,
                              ShapeKey mthd) throws IOException {
                super.write(pc, out, clazz, mthd);
                out.writeShort(clazz.body().pool().allocClass(this.type));
                out.writeByte(this.dimensions());
            }

            public Instruction replace(ReplaceIns replace) {
                Array.New.Multi ins = (Array.New.Multi) super.replace(replace);
                if (ins != this)
                    return ins;
                return ins.setArray((ArrayType) this.type.replace(replace));
            }

            public boolean baseEquals(Instruction ins) {
                if (!super.baseEquals(ins))
                    return false;
                else if (this.type == null
                    && ((Array.New.Multi) ins).type != null)
                    return false;
                else if (this.type != null
                    && ((Array.New.Multi) ins).type == null)
                    return false;
                else if (!((Array.New.Multi) ins).type.equals(this.type))
                    return false;
                else
                    return ((Array.New.Multi) ins).dimensions() ==
                        this.dimensions();
            }

            public int baseHashCode() {
                return super.baseHashCode()
                    + (this.type == null ? 0 : this.type.hashCode())
                    + this.dimensions();
            }

            public String mnemonic() {
                return "multianewarray";
            }

            public String toString() {
                return super.toString() + " " + this.type.javaSource() + " "
                    + this.dimensions();
            }

            public Array.New.Multi setArray(ArrayType array) {
                if (array == null)
                    throw new Error();
                if (array == this.type)
                    return (Array.New.Multi) this;
                Array.New.Multi copy = (Array.New.Multi) this.copy();
                copy.type = array;
                return copy;
            }

            public int dimensions() {
                return this.dimensions;
            }

            public Array.New.Multi setDimensions(int dim) {
                if (dim == this.dimensions())
                    return (Array.New.Multi) this;
                Array.New.Multi copy = (Array.New.Multi) this.copy();
                copy.dimensions = dim;
                return copy;
            }

            public int opcode() {
                return 197;
            }

            public ArrayType array() {
                return this.type;
            }

            public Multi() {
                super();
            }

            protected int size() {
                return 4;
            }
        }
    }

    /* atom-edu.utah.jiggy.bytecode.ins outins.Array.Length */
    public static class Length extends Array {
        public String mnemonic() {
            return "arraylength";
        }

        public TypeType type(Environment env) {
            return TypeConstants.INT;
        }

        public int argCount() {
            return 1;
        }

        public void execute(Machine m) {
            Value array = m.pop();
            this.args().add(array);
            m.doError(array.type(m.context) instanceof ArrayType, "");
            m.push(this);
        }

        public int opcode() {
            return 190;
        }

        public Length() {
            super();
        }

        protected int size() {
            return 1;
        }
    }

    public abstract static class Simple extends Array {
        final TypeInfo type;

        public Simple(TypeInfo type) {
            super();
            this.type = type;
        }

        public int argCount() {
            return 2;
        }

        public void execute(Machine m) {
            Value index = m.pop();
            Value array = m.pop();
            this.args().add(array);
            this.args().add(index);
            m.doError(index.type(m.context).isa(TypeInfo.INT), "" + index);
            m.doError(array.type(m.context) instanceof ArrayType, "" + array);
            m.doError(
                ((ArrayType) array.type(m.context)).down().isa(this.typeInfo()),
                "" + array);
        }

        public TypeInfo typeInfo() {
            return this.type;
        }

        public String mnemonic() {
            return "" + this.typeInfo().mnemonic() + "a";
        }

        public int opcode() {
            return this.typeInfo().opcodeOffset();
        }

        protected int size() {
            return 1;
        }

        public static class Load extends Array.Simple {
            public String mnemonic() {
                return super.mnemonic() + "load";
            }

            public int opcode() {
                return super.opcode() + 46;
            }

            public Load(TypeInfo type) {
                super(type);
            }

            public TypeType type(Environment env) {
                return ((ArrayType) ((Value) this.args().get(0)).type(env))
                    .down();
            }

            public void execute(Machine m) {
                super.execute(m);
                m.push(this);
            }
        }

        /* atom-edu.utah.jiggy.bytecode.ins outins.Array.Simple.Store */
        public static class Store extends Array.Simple {
            public String mnemonic() {
                return super.mnemonic() + "store";
            }

            public int opcode() {
                return super.opcode() + 79;
            }

            public Store(TypeInfo type) {
                super(type);
            }

            public int argCount() {
                return super.argCount() + 1;
            }

            public void execute(Machine m) {
                Value stored = m.pop();
                m.doError(stored.type(m.context).isa(this.typeInfo()),
                    "" + stored);
                super.execute(m);
                this.args().add(stored);
                return;
            }
        }
    }
}
