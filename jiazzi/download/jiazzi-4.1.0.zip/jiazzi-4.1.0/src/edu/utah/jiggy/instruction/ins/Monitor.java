/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.bytecode.ins outins.Monitor */

package edu.utah.jiggy.instruction.ins;

import edu.utah.jiggy.meta.type.RefType;

public abstract class Monitor extends Instruction implements
        Instruction.Imperative {
    static void activate() {
        (new Monitor.Enter()).put00();
        (new Monitor.Exit()).put00();
    }

    public int argCount() {
        return 1;
    }

    public void execute(Machine m) {
        Value lock = m.pop();
        this.args().add(lock);
        m.doError(lock.type(m.context) instanceof RefType);
    }

    public Monitor() {
        super();
    }

    public String mnemonic() {
        return "monitor";
    }

    protected int size() {
        return 1;
    }

    /* atom-edu.utah.jiggy.bytecode.ins outins.Monitor.Exit */
    public static class Exit extends Monitor {
        public String mnemonic() {
            return super.mnemonic() + "exit";
        }

        public int opcode() {
            return 195;
        }

        public Exit() {
            super();
        }
    }

    /* atom-edu.utah.jiggy.bytecode.ins outins.Monitor.Enter */
    public static class Enter extends Monitor {
        public String mnemonic() {
            return super.mnemonic() + "enter";
        }

        public int opcode() {
            return 194;
        }

        public Enter() {
            super();
        }
    }
}
