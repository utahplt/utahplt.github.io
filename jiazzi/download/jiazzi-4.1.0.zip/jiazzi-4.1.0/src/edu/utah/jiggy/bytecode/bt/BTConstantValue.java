/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.bytecode outattr.ConstantValue */

package edu.utah.jiggy.bytecode.bt;

import java.io.*;

import edu.utah.jiggy.clazz.ClassModel;
import edu.utah.jiggy.meta.shape.Base;
import edu.utah.jiggy.meta.shape.FieldShape;
import edu.utah.jiggy.meta.shape.MemberShape;
import edu.utah.jiggy.meta.shape.ShapeKey;

public class BTConstantValue extends BTAttr {
    protected Object value;

    public java.lang.Object constant() {
        return this.value;
    }

    public void setConstant(Object value) {
        this.value = value;
    }

    protected boolean isClass() {
        return false;
    }

    public BTAttr readMember(int size, DataInputStream in, ClassModel clazz,
                             BTMember mmbr, MemberShape sfld)
            throws IOException {
        BTConstantValue attr = (BTConstantValue) super.readMember(size, in,
            clazz, mmbr, sfld);
        attr.value = clazz.body().pool().get(in.readUnsignedShort()).constant();
        ((FieldShape) sfld).setConstant(attr.value);
        return attr;
    }

    public boolean prepareWriteMember(ClassModel clazz, ShapeKey mmbr) {
        clazz.body().pool().allocConstant(this.value);
        return super.prepareWriteMember(clazz, mmbr);
    }

    public void writeMember(DataOutputStream out, ClassModel clazz,
                            ShapeKey mmbr) throws IOException {
        super.writeMember(out, clazz, mmbr);
        out.writeShort(clazz.body().pool().allocConstant(this.value));
    }

    public String toString() {
        return super.toString() + ":" + this.value;
    }

    protected int size(ClassModel clazz, Base base) {
        return 2;
    }

    public String name() {
        return "ConstantValue";
    }

    public BTConstantValue() {
        super();
    }
}
