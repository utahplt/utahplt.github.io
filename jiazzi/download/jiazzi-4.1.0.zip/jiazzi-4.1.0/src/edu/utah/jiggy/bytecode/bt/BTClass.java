/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.bytecode outbt.Class */

package edu.utah.jiggy.bytecode.bt;

import java.util.*;
import java.io.*;

import edu.utah.jiggy.clazz.ClassModel;
import edu.utah.jiggy.clazz.TypeModel;
import edu.utah.jiggy.meta.flag.AccessFlag;
import edu.utah.jiggy.meta.flag.BinaryFlag;
import edu.utah.jiggy.meta.flag.Flag;
import edu.utah.jiggy.meta.flag.FlagConstants;
import edu.utah.jiggy.meta.flag.VirtualFlag;
import edu.utah.jiggy.meta.shape.Base;
import edu.utah.jiggy.meta.shape.ClassShape;
import edu.utah.jiggy.meta.shape.FieldShape;
import edu.utah.jiggy.meta.shape.InitShape;
import edu.utah.jiggy.meta.shape.MemberShape;
import edu.utah.jiggy.meta.shape.MethodShape;
import edu.utah.jiggy.meta.shape.NameTypeShape;
import edu.utah.jiggy.meta.shape.ReplaceShape;
import edu.utah.jiggy.meta.shape.ShapeKey;
import edu.utah.jiggy.meta.type.ClassType;

public class BTClass extends BTBase {
    protected BTPool pool = new BTPool();
    protected int minor;
    protected int major;
    // protected Map<shape.Key,bt.Method> methods =
    // new HashMap<shape.Key,bt.Method>();
    protected Map methods = new HashMap();

    // protected Map<shape.Key,bt.Field> fields =
    // new HashMap<shape.Key,bt.Field>();
    protected Map fields = new HashMap();

    public BTClass() {
    }

    public void dump(ClassModel clazz, PrintStream out) {
        System.err.println(clazz);
        out.println("major.minor = " + this.major + "." + this.minor);
        this.pool.dump(out);
        out.println("FIELDS");
        for (Iterator i = this.fields.keySet().iterator();
             i.hasNext();
             /* i = i */) {
            ShapeKey key = (ShapeKey) i.next();
            ((BTField) this.fields.get(key)).dump(key, out);
        }
        out.println("METHODS");
        for (Iterator i = this.methods.keySet().iterator();
             i.hasNext();
             /* i = i */) {
            ShapeKey key = (ShapeKey) i.next();
            ((BTMethod) this.methods.get(key)).dump(key, out);
        }
        super.dump(out);
    }

    public BTClass(ClassModel clazz) {
        /* already shape is set */
        this();
        this.minor = 5;
        this.major = 45;
        TypeModel ctype = (TypeModel) clazz.newType();
        for (Iterator i = ctype.shape().inits().iterator();
             i.hasNext();
             /* i = i */) {
            InitShape init = ctype.shape().actualInit((ShapeKey) i.next());
            BTMethod body = new BTMethod(clazz, init);
            this.methods.put(init.key(), body);
        }
        for (Iterator i = ctype.shape().methods().iterator();
             i.hasNext();
             /* i = i */) {
            MethodShape mthd = ctype.shape().actualMethod((ShapeKey) i.next());
            BTMethod body = new BTMethod(clazz, mthd);
            this.methods.put(mthd.key(), body);
        }
        for (Iterator i = ctype.shape().fields().iterator();
             i.hasNext();
             /* i = i */) {
            FieldShape fld = ctype.shape().actualField((ShapeKey) i.next());
            BTField body = new BTField(clazz, fld);
            this.fields.put(fld.key(), body);
        }
    }

    public BTPool pool() {
        return this.pool;
    }

    public void read(DataInputStream in, ClassModel clazz, ClassShape scls)
            throws IOException {
        if (in.readInt() != 0xCAFEBABE)
            throw new BTClassFormatError("wrong magic", clazz);
        this.setMinor(in.readUnsignedShort());
        this.setMajor(in.readUnsignedShort());
        this.pool.read(in);
        this.pool.resolve(clazz);
        {
            int flags = in.readUnsignedShort();
            TypeModel tcls = (TypeModel) this.pool()
                .get(in.readUnsignedShort()).clazz();
            int zindex = in.readUnsignedShort();

            for (Iterator i = FlagConstants.CLASS_FLAGS.iterator();
                 i.hasNext();
                 /* i = i */) {
                Flag flag = (Flag) i.next();
                if (flag instanceof BinaryFlag)
                    if ((flags & flag.jvmcode()) != 0)
                        scls.set((BinaryFlag) flag);
            }
            scls.set(AccessFlag.parse(flags));
            scls.set(VirtualFlag.parse(flags));

            if (tcls.clazz() != clazz)
                throw new BTClassFormatError("wrong this type: " + tcls.clazz()
                    + " vs. " + clazz, clazz);
            if (zindex == 0) {
                TypeModel ocls = (TypeModel) clazz.pkg().root().env()
                    .findVMClass("java/lang/Object");
                if (ocls.clazz() != clazz)
                    throw new BTClassFormatError(
                        "only object cannot have super " + clazz, clazz);
            } else {
                scls.setZuper((ClassType) this.pool().get(zindex).clazz());
            }
        }
        {
            int count = in.readUnsignedShort();
            for (int i = 0; i < count; i++)
                scls.addInterface((ClassType) this.pool().get(
                    in.readUnsignedShort()).clazz());
        }
        {
            int count = in.readUnsignedShort();
            for (int i = 0; i < count; i++) {
                BTField fld = new BTField();
                FieldShape sfld = new FieldShape();
                fld.read(in, clazz, sfld);
                sfld = (FieldShape) sfld.copy();
                this.fields.put(sfld.key(), fld);
                scls.add(sfld);
            }
        }
        {
            int count = in.readUnsignedShort();
            for (int i = 0; i < count; i++) {
                BTMethod mthd = new BTMethod();
                MethodShape smthd = new MethodShape();
                mthd.read(in, clazz, smthd);
                if (smthd.nameType().name().javaSource().equals("<init>")) {
                    InitShape sinit = smthd.makeInit();
                    this.methods.put(sinit.key(), mthd);
                    scls.add(sinit);
                } else {
                    smthd = (MethodShape) smthd.copy();
                    this.methods.put(smthd.key(), mthd);
                    scls.add(smthd);
                }
            }
        }
        {
            int count = in.readUnsignedShort();
            for (int i = 0; i < count; i++) {
                BTAttr attr = BTAttr.find(clazz.body().pool().get(
                    in.readUnsignedShort()).utf8());
                int size = in.readInt();
                attr = attr.readClass(size, in, clazz, scls);
                if (!attr.isDerived())
                    this.attributes.put(attr, attr);
            }
        }
    }

    public void prepareWrite(ClassModel clazz) {
        if (false)
            System.err.println("PREPARE: " + clazz);

        this.pool.prepareWrite();
        ClassType ctype = clazz.newType();

        /* determine whether abstract */
        if (clazz.shape().isSet(FlagConstants.INTERFACE)
            || ctype.shape().hasAbstractMethods(ctype))
            clazz.shape().set(FlagConstants.ABSTRACT);
        else if (clazz.shape().virtual() == FlagConstants.ABSTRACT)
            clazz.shape().set(FlagConstants.CONCRETE);

        for (Iterator i = ctype.shape().inits().iterator();
             i.hasNext();
             /* i = i */) {
            ShapeKey key = (ShapeKey) i.next();
            ((BTMethod) this.methods.get(key)).prepareWrite(clazz, key);
        }
        for (Iterator i = ctype.shape().methods().iterator();
             i.hasNext();
             /* i = i */) {
            ShapeKey key = (ShapeKey) i.next();
            if (this.methods.containsKey(key))
                ((BTMethod) this.methods.get(key)).prepareWrite(clazz, key);
        }
        for (Iterator i = ctype.shape().fields().iterator();
             i.hasNext();
             /* i = i */) {
            ShapeKey key = (ShapeKey) i.next();
            ((BTField) this.fields.get(key)).prepareWrite(clazz, key);
        }
        clazz.body().pool().allocClass(ctype);
        if (ctype.shape().zuper() != null)
            clazz.body().pool().allocClass(ctype.shape().zuper());
        for (Iterator i = ctype.shape().interfaces().iterator();
             i.hasNext();
             /* i = i */)
            clazz.body().pool().allocClass((ClassType) i.next());

        for (Iterator i = this.attributes.values().iterator();
             i.hasNext();
             /* i = i */) {
            if (!((BTAttr) i.next()).prepareWriteClass(clazz))
                i.remove();
        }
        for (Iterator i = BTAttr.derived(); i.hasNext(); /* i = i */) {
            BTAttr attr = (BTAttr) i.next();
            if (attr.prepareWriteClass(clazz))
                this.attributes.put(attr, attr);
        }
    }

    public void write(DataOutputStream out, ClassModel clazz)
            throws IOException {
        ClassType ctype = clazz.newType();

        out.writeInt(0xCAFEBABE);
        out.writeShort(this.minor());
        out.writeShort((this.major() < 48 ? this.major() : 47));

        int cindex = clazz.body().pool().allocClass(ctype);
        pool.write(out);
        {
            int flags = 0x0020; /* set ACC_SUPER */
            if (clazz.shape().access() == FlagConstants.PRIVATE)
                flags = flags | FlagConstants.PACKAGE.jvmcode();
            else if (clazz.shape().access() == FlagConstants.PROTECTED)
                flags = flags | FlagConstants.PUBLIC.jvmcode();
            else
                flags = flags | clazz.shape().access().jvmcode();
            flags = flags | clazz.shape().virtual().jvmcode();
            if (clazz.shape().isSet(FlagConstants.INTERFACE))
                flags = flags | FlagConstants.INTERFACE.jvmcode();
            out.writeShort(flags | 0x0020);
        }
        if (true) {
            BTPool.Entry e = (BTPool.Entry) clazz.body().pool().entries
                .get(cindex);
            if (!e.clazz().equals(ctype))
                throw new Error("wtf " + e + " " + ctype + " " + clazz);
        }
        out.writeShort(cindex);
        if (ctype.shape().zuper() == null)
            out.writeShort(0);
        else
            out.writeShort(clazz.body().pool()
                .allocClass(ctype.shape().zuper()));

        out.writeShort(ctype.shape().interfaces().size());
        for (Iterator i = ctype.shape().interfaces().iterator();
             i.hasNext();
             /* i = i */) {
            out.writeShort(
                clazz.body().pool().allocClass((ClassType) i.next()));
        }
        out.writeShort(ctype.shape().fields().size());
        for (Iterator i = ctype.shape().fields().iterator();
             i.hasNext();
             /* i = i */) {
            ShapeKey key = (ShapeKey) i.next();
            ((BTField) this.fields.get(key)).write(out, clazz, key);
        }
        {
            int mcount = ctype.shape().inits().size();
            for (Iterator i = ctype.shape().methods().iterator();
                 i.hasNext();
                 /* i = i */)
                if (this.methods.containsKey((ShapeKey) i.next()))
                    mcount++;
            out.writeShort(mcount);
            for (Iterator i = ctype.shape().inits().iterator();
                 i.hasNext();
                 /* i = i */) {
                ShapeKey key = (ShapeKey) i.next();
                ((BTMethod) this.methods.get(key)).write(out, clazz, key);
            }
            for (Iterator i = ctype.shape().methods().iterator();
                 i.hasNext();
                 /* i = i */) {
                ShapeKey key = (ShapeKey) i.next();
                if (this.methods.containsKey(key))
                    ((BTMethod) this.methods.get(key)).write(out, clazz, key);
            }
        }
        out.writeShort(this.attributes.size());
        for (Iterator i = this.attributes.values().iterator();
             i.hasNext();
             /* i = i */) {
            BTAttr attr = (BTAttr) i.next();
            attr.writeClass(out, clazz);
            if (attr.isDerived())
                i.remove();
        }
    }

    public Map methods() {
        return this.methods;
    }

    public Map fields() {
        return this.fields;
    }

    public BTBase copy() {
        BTClass copy = (BTClass) super.copy();
        copy.methods = new HashMap();
        copy.fields = new HashMap();
        return copy;
    }

    public void gjReplace(TypeModel ctype, Base base, ReplaceShape replace) {
        super.gjReplace(ctype, base, replace);
        for (Iterator i = this.fields.keySet().iterator();
             i.hasNext();
             /* i = i */) {
            ShapeKey key = (ShapeKey) i.next();
            ((BTField) this.fields.get(key)).gjReplace(ctype, ctype.shape()
                .actual(key), replace);
        }
        for (Iterator i = this.methods.keySet().iterator();
             i.hasNext();
             /* i = i */) {
            ShapeKey key = (ShapeKey) i.next();
            ((BTMethod) this.methods.get(key)).gjReplace(ctype, ctype.shape()
                .actual(key), replace);
        }
    }

    public BTClass replace(ClassShape shape, ReplaceBT replace) {
        if (replace.clazz() == null)
            throw new Error();
        BTClass copy = (BTClass) this.replace0(replace);
        copy.pool = this.pool.replace(replace);
        for (Iterator i = this.fields.keySet().iterator();
             i.hasNext();
             /* i = i */) {
            ShapeKey key = (ShapeKey) i.next();
            if (replace.mmbr() != null)
                throw new Error();
            replace.set(replace.clazz().shape().actualField(key));
            if (replace.mmbr() == null)
                throw new Error();
            BTField fld = (BTField) this.fields.get(key);
            copy.fields.put(key.replace(replace, replace.clazz()),
                (BTField) fld.replace(replace));
            replace.set((MemberShape) null);
        }
        for (Iterator i = this.methods.keySet().iterator();
             i.hasNext();
             /* i = i */) {
            ShapeKey key = (ShapeKey) i.next();
            if (replace.mmbr() != null)
                throw new Error();
            ShapeKey rkey;

            if (key.nameType() == NameTypeShape.EMPTY) {
                /* constructor */
                replace.set(replace.clazz().shape().actualInit(key));
                rkey = key.replace(replace, replace.clazz());
            } else {
                /* method */
                MethodShape mmbr = replace.clazz().shape().actualMethod(key);
                replace.set(mmbr);
                rkey = mmbr.replace(replace, replace.clazz()).key();
            }
            if (replace.mmbr() == null)
                throw new Error(key + " does not exist in " + replace.clazz());
            BTMethod mthd = (BTMethod) this.methods.get(key);

            copy.methods.put(rkey, (BTMethod) mthd.replace(replace));
            replace.set((MemberShape) null);
        }
        return copy;
    }

    public int minor() {
        return this.minor;
    }

    public int major() {
        return this.major;
    }

    public void setMinor(int a0) {
        this.minor = a0;
    }

    public void setMajor(int a0) {
        this.major = a0;
    }

    // Below here,
    // From `edu.utah.jiggy.instruction/outbt/Class.java'.

    public void buildInstructions(ClassModel clazz) {
        for (Iterator i = this.methods().keySet().iterator();
             i.hasNext();
             /* i = i */) {
            ShapeKey mthd = (ShapeKey) i.next();
            if (((BTMethod) this.methods().get(mthd)).attributes().containsKey(
                BTAttr.CODE))
                ((BTCode) ((BTMethod) this.methods().get(mthd)).attributes()
                    .get(BTAttr.CODE)).buildInstructions(clazz.newType(), mthd);
        }
    }
}
