/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package edu.utah.jiggy.bytecode.bt;

import java.util.*;

import edu.utah.jiggy.meta.shape.ReplaceShape;
import edu.utah.jiggy.meta.shape.ShapeKey;
import edu.utah.jiggy.meta.type.ClassType;

public class ReplaceBT extends ReplaceShape {
    public ReplaceBT() {
        super();
    }

    public ReplaceBT(ReplaceBT replace) {
        super(replace);
        this.methods.putAll(replace.methods);
        this.fields.putAll(replace.fields);
    }

    public ReplaceBT(ReplaceShape replace) {
        super(replace);
    }

    // protected final Map<bt.MethodRef,bt.MethodRef> methods = new
    // HashMap<bt.MethodRef,bt.MethodRef>();
    // protected final Map<bt.FieldRef,bt.FieldRef> fields = new
    // HashMap<bt.FieldRef,bt.FieldRef>();
    protected final Map methods = new HashMap();
    protected final Map fields = new HashMap();

    public String toStringInternal() {
        return super.toString() + " mrefs:" + this.methods + " frefs:"
            + this.fields;
    }

    protected BTMethodRef get(BTMethodRef ref) {
        if (this.methods.containsKey(ref))
            return (BTMethodRef) this.methods.get(ref);
        else
            return ref;
    }

    protected BTFieldRef get(BTFieldRef ref) {
        if (this.fields.containsKey(ref))
            return (BTFieldRef) this.fields.get(ref);
        else
            return ref;
    }

    public void map(BTFieldRef a0, BTFieldRef a1) {
        this.fields.put(a0, a1);
    }

    public void map(BTMethodRef a0, BTMethodRef a1) {
        this.methods.put(a0, a1);
    }

    // Below here,
    // From `edu.utah.jiggy.instruction/outbt/Replace.java'.

    public boolean needBuild = false;

    public String toString() {
        return toStringInternal() + " needBuild=" + this.needBuild;
    }

    public void map(ClassType ctype, ShapeKey key0, ShapeKey key1) {
        super.map(ctype, key0, key1);
        if (key0.procedure().args().size() != key1.procedure().args().size())
            needBuild = true;
    }
}
