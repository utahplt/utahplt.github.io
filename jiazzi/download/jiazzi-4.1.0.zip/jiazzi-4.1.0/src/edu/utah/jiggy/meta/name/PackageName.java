/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package edu.utah.jiggy.meta.name;

public class PackageName extends Name {
    public static final PackageName ANONYMOUS = new PackageName();
    protected PackageName outer = null;

    public PackageName() {
        super();
    }

    public PackageName(String name) {
        super(name.indexOf('.') == -1 ? name
                : name.substring(name.lastIndexOf('.') + 1, name.length()));
        if (name.indexOf('.') != -1)
            this.outer =
                new PackageName(name.substring(0, name.lastIndexOf('.')));
    }

    public PackageName setBase(String name) {
        return (PackageName) this.setName(name);
    }

    public PackageName parse(String name) {
        if (name.indexOf('.') != -1)
            return this.parse(
                name.substring(name.indexOf('.') + 1, name.length()))
                .setOuter(
                    this.parse(name.substring(0, name.indexOf('.'))));
        else
            return this.setBase(name).base();
    }

    public String toString() {
        return this.javaSource();
    }

    public int hashCode() {
        return super.hashCode()
            + (this.outer == null ? 0 : this.outer.hashCode());
    }

    public boolean equals(Object o) {
        if (this == o)
            return true;
        else if (!super.equals(o))
            return false;
        else if (((PackageName) o).outer == this.outer)
            return true;
        else if (((PackageName) o).outer == null)
            return false;
        else if (this.outer == null)
            return false;
        else
            return ((PackageName) o).outer.equals(this.outer);
    }

    public PackageName setOuter(PackageName outer) {
        if (outer == null)
            throw new Error();
        if (outer == this.outer)
            return (PackageName) this;
        PackageName copy = (PackageName) this.copy();
        copy.outer = outer;
        return copy;
    }

    public Name setName(String name) {
        if (name.indexOf('.') != -1)
            throw new Error();
        return super.setName(name);
    }

    public PackageName replaceOuter(PackageName from, PackageName to) {
        if (this.equals(from))
            return to;
        else if (this.outer == null)
            return (PackageName) this;
        else
            return this.setOuter(this.outer.replaceOuter(from, to));
    }

    public boolean isOuter(PackageName pkg) {
        if (pkg.equals(this))
            return true;
        else if (this.outer == null)
            return false;
        else
            return outer.isOuter(pkg);
    }

    public PackageName outer() {
        return this.outer;
    }

    public PackageName base() {
        if (this.outer == null)
            return (PackageName) this;
        PackageName copy = (PackageName) this.copy();
        copy.outer = null;
        return copy;
    }

    public PackageName replace(ReplaceName replace) {
        PackageName copy = replace.get((PackageName) this);
        if (copy != this)
            return copy;
        copy = (PackageName) this.replace0(replace);
        if (this.outer != null)
            copy = copy.setOuter(this.outer.replace(replace));
        return copy;
    }

    public String javaSource() {
        return (this.outer != null ? this.outer.javaSource() + "." : "")
            + this.javaSource0();
    }
}
