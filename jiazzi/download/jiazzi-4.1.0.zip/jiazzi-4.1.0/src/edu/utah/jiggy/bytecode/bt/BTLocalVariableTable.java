/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.bytecode outattr.LocalVariableTable */

package edu.utah.jiggy.bytecode.bt;

import java.util.*;
import java.io.*;

import edu.utah.jiggy.clazz.ClassModel;
import edu.utah.jiggy.instruction.ins.Block;
import edu.utah.jiggy.meta.flag.FlagConstants;
import edu.utah.jiggy.meta.shape.Base;
import edu.utah.jiggy.meta.shape.MemberShape;
import edu.utah.jiggy.meta.shape.ShapeKey;
import edu.utah.jiggy.meta.type.TypeType;

public class BTLocalVariableTable extends BTAttr {
    // protected Set<bt.LocalVariableTable.Entry> entries =
    // new HashSet<bt.LocalVariableTable.Entry>();
    protected Set entries = new HashSet();

    public String toString() {
        return super.toString() + this.entries;
    }

    protected boolean isClass() {
        return false;
    }

    public String name() {
        return "LocalVariableTable";
    }

    protected int size(ClassModel clazz, Base base) {
        return 2 + (this.entries.size() * 10);
    }

    public BTAttr copy() {
        BTLocalVariableTable copy = (BTLocalVariableTable) super.copy();
        copy.entries = new HashSet(copy.entries);
        return copy;
    }

    public BTAttr replaceInternal(ReplaceBT replace) {
        BTLocalVariableTable copy =
            (BTLocalVariableTable) super.replace(replace);
        for (Iterator i = this.entries.iterator(); i.hasNext(); /* i = i */) {
            BTLocalVariableTable.Entry e =
                (BTLocalVariableTable.Entry) i.next();
            TypeType type = e.type().replace(replace);
            if (type != e.type()) {
                if (copy == this)
                    copy = (BTLocalVariableTable) this.copy();
                if (!copy.entries.remove(e))
                    throw new Error();
                copy.entries.add(
                    new BTLocalVariableTable.Entry(
                        e.startPC(), e.length(), e.name(), type, e.index()));
            }
        }
        return copy;
    }

    public Set entries() {
        return this.entries;
    }

    public BTLocalVariableTable() {
        super();
    }

    public BTAttr readMember(int size, DataInputStream in, ClassModel clazz,
                             BTMember mmbr, MemberShape bld) throws IOException {
        BTLocalVariableTable attr =
            (BTLocalVariableTable) super.readMember(size, in, clazz, mmbr, bld);
        int count = in.readUnsignedShort();
        for (int i = 0; i < count; i++) {
            int startPC = in.readUnsignedShort();
            int length = in.readUnsignedShort();
            String name = clazz.body().pool().get(in.readUnsignedShort())
                .utf8();
            String desc = clazz.body().pool().get(in.readUnsignedShort())
                .utf8();
            int index = in.readUnsignedShort();
            attr.entries.add(new BTLocalVariableTable.Entry(startPC, length,
                name, TypeType.parseJvmType(desc, clazz.pkg().root().env()),
                index));
        }
        return attr;
    }

    public boolean prepareWriteMember(ClassModel clazz, ShapeKey mmbr) {
        for (Iterator i = this.entries.iterator(); i.hasNext(); /* i = i */) {
            BTLocalVariableTable.Entry e =
                (BTLocalVariableTable.Entry) i.next();
            clazz.body().pool().allocUtf8(e.name());
            clazz.body().pool().allocUtf8(e.type().jvmTypeString());
        }
        return super.prepareWriteMember(clazz, mmbr);
    }

    public void writeMember(DataOutputStream out, ClassModel clazz,
                            ShapeKey mmbr) throws IOException {
        System.err.println("WRITE: " + this);
        super.writeMember(out, clazz, mmbr);
        out.writeShort(this.entries.size());
        for (Iterator i = this.entries.iterator(); i.hasNext(); /* i = i */) {
            BTLocalVariableTable.Entry e =
                (BTLocalVariableTable.Entry) i.next();
            out.writeShort(e.startPC());
            out.writeShort(e.length());
            out.writeShort(clazz.body().pool().allocUtf8(e.name()));
            out.writeShort(clazz.body().pool().allocUtf8(
                e.type().jvmTypeString()));
            out.writeShort(e.index());
        }
    }

    /* atom-edu.utah.jiggy.bytecode outbt.LocalVariableTable.Entry */
    public static class Entry extends java.lang.Object implements Cloneable {
        int index;
        int startPC;
        final String name;
        final int length;
        final TypeType type;

        public BTLocalVariableTable.Entry copy() {
            try {
                return (BTLocalVariableTable.Entry) this.clone();
            } catch (Throwable t) {
                throw new Error();
            }
        }

        public String toString() {
            return this.startPC + ":" + this.length + ":" + this.name + ":"
                + this.type + ":" + this.index;
        }

        public void setIndex(int index) {
            this.index = index;
        }

        public void setStartPC(int pc) {
            this.startPC = pc;
        }

        public int index() {
            return this.index;
        }

        public int startPC() {
            return this.startPC;
        }

        public java.lang.String name() {
            return this.name;
        }

        public int length() {
            return this.length;
        }

        public TypeType type() {
            return this.type;
        }

        public Entry(int startPC, int length, java.lang.String name,
                     TypeType type, int index) {
            super();
            this.startPC = startPC;
            this.length = length;
            this.name = name;
            this.type = type;
            this.index = index;
        }

        // Below here (in this class),
        // From `edu.utah.jiggy.instruction/outbt/LocalVariableTable.java'.

        public Block block = null;
    }

    // Below here,
    // From `edu.utah.jiggy.instruction/outbt/LocalVariableTable.java'.

    public BTAttr replace(ReplaceBT replace) {
        BTLocalVariableTable copy =
            (BTLocalVariableTable) replaceInternal(replace);
        int n = replace.mmbr().replace(replace).procedure().stackWidth()
            - replace.mmbr().procedure().stackWidth();
        if (n == 0)
            return copy;
        for (Iterator i = copy.entries().iterator(); i.hasNext(); /* i = i */) {
            BTLocalVariableTable.Entry e =
                (BTLocalVariableTable.Entry) i.next();
            if (e.index() <
                    (replace.mmbr().procedure().stackWidth() + 
                            (replace.mmbr().isSet(FlagConstants.STATIC) ?
                                    0 : 1)))
                continue;
            if (copy == this)
                copy = (BTLocalVariableTable) this.copy();
            if (!copy.entries().remove(e))
                throw new Error();
            e = e.copy();
            e.setIndex(e.index() + n);
            copy.entries().add(e);
        }
        return copy;
    }

    public BTAttr updateBranch(Map map) {
        BTLocalVariableTable copy =
            (BTLocalVariableTable) super.updateBranch(map);
        for (Iterator i = this.entries().iterator(); i.hasNext(); /* i = i */) {
            BTLocalVariableTable.Entry e =
                (BTLocalVariableTable.Entry) i.next();
            Block b = (Block) map.get(e.block);
            if (b == null)
                continue;
            if (copy == this)
                copy = (BTLocalVariableTable) this.copy();
            if (!copy.entries().remove(e))
                throw new Error();
            e = e.copy();
            e.block = b;
            copy.entries().add(e);
        }
        return copy;
    }

    public void setBlocks(BTCode code) {
        for (Iterator i = this.entries().iterator(); i.hasNext(); /* i = i */) {
            BTLocalVariableTable.Entry e =
                (BTLocalVariableTable.Entry) i.next();
            e.block = code.findTarget(e.startPC());
        }
        return;
    }

    protected boolean prepareWrite(ClassModel clazz, Base base) {
        if (!super.prepareWrite(clazz, base))
            return false;
        for (Iterator i = this.entries().iterator(); i.hasNext(); /* i = i */) {
            BTLocalVariableTable.Entry e =
                (BTLocalVariableTable.Entry) i.next();
            if (e.block != null)
                e.setStartPC(e.block.getPC());
        }
        return true;
    }
}
