/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.bytecode outclazz.JarSaver */

package edu.utah.jiggy.clazz;

import java.io.*;
import java.util.jar.*;

public class JarModelSaver extends ModelSaver {
    final JarOutputStream jar;

    public JarModelSaver(JarOutputStream jar) {
        super();
        this.jar = jar;
    }

    public String toString() {
        return this.jar.toString();
    }

    public void close() throws IOException {
    }

    protected OutputStream forClass(ClassModel clazz) throws IOException {
        JarEntry e = new JarEntry(clazz.internalName() + ".class");
        /* e.setTime(clazz.modified()); */
        this.jar.putNextEntry(e);
        return this.jar;
    }

    protected void forPackage(PackageModel pkg) throws IOException {
        if (!pkg.internalName().equals(""))
            this.jar.putNextEntry(new JarEntry(pkg.internalName() + '/'));
    }
}
