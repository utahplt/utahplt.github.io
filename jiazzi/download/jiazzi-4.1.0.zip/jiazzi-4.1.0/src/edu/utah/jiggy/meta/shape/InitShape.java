/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.core outshape.IsInit */

package edu.utah.jiggy.meta.shape;

import java.util.*;

import edu.utah.jiggy.meta.flag.FlagConstants;

public class InitShape extends MemberShape {
    protected ProcedureShape procedure;
    protected ThrowzShape throwz = new ThrowzShape();

    public void set(ProcedureShape p) {
        this.procedure = p;
    }

    public void set(ThrowzShape t) {
        this.throwz = t;
    }

    public String toString() {
        return super.toString() + " " + this.procedure + " " + this.throwz;
    }

    public String javaSource(String cname) {
        return super.javaSource(cname) + cname + this.procedure.javaSource()
            + this.throwz.javaSource();
    }

    protected Set supported() {
        return FlagConstants.INIT_FLAGS;
    }

    public ProcedureShape procedure() {
        return this.procedure;
    }

    public ThrowzShape throwz() {
        return this.throwz;
    }

    public InitShape() {
        super();
    }

    // Below here,
    // From `edu.utah.jiggy.bytecode/outshape/Init.java'.

    public String jvmNameString() {
        return "<init>";
    }

    public String jvmTypeString() {
        return this.procedure().jvmTypeString() + super.jvmTypeString();
    }
}
