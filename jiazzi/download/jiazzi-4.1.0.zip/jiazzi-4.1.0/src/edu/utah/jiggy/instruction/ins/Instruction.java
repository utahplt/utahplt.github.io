/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.bytecode.ins outins.Instruction */

package edu.utah.jiggy.instruction.ins;

import java.util.*;
import java.io.*;

import edu.utah.jiggy.clazz.ClassModel;
import edu.utah.jiggy.meta.shape.ShapeKey;
import edu.utah.jiggy.meta.type.Environment;
import edu.utah.jiggy.meta.type.TypeType;

public abstract class Instruction extends Value implements Cloneable {
    // private static final Map<Integer,ins.Instruction> instructions =
    // new HashMap<Integer,ins.Instruction>();
    private static final Map instructions = new HashMap();
    static {
        Arithmetic.activate();
        Array.activate();
        CheckRef.activate();
        Compare.activate();
        Condition.activate();
        Constant.activate();
        Convert.activate();
        Dup.activate();
        Field.activate();
        Goto.activate();
        Increment.activate();
        JumpStoreReturn.activate();
        Local.activate();
        Method.activate();
        Monitor.activate();
        New.activate();
        Nop.activate();
        Pop.activate();
        Ret.activate();
        Return.activate();
        Swap.activate();
        Switch.activate();
        Throw.activate();
    }

    protected void put00() {
        Instruction ins0 =
            (Instruction) instructions.put(
                new Integer(this.opcode()), (Instruction) this);
        if (ins0 != null)
            throw new Error(ins0 + " already at " + this.opcode()
                + " so cannot add " + this);
        // System.err.println("PUT00: " + this.opcode() + "\t" + this);
    }

    public void write(int pc, DataOutputStream out, ClassModel clazz,
                      ShapeKey mthd) throws IOException {
        out.writeByte(this.opcode());
        return;
    }

    public void writeWide(int pc, DataOutputStream out, ClassModel clazz,
                          ShapeKey mthd) throws IOException {
        if (!this.isWide())
            throw new Error("not wide: " + this);
        out.writeByte(196);
        out.writeByte(this.opcode());
        return;
    }

    public Instruction prepareWrite(int pc, ClassModel clazz, ShapeKey mthd) {
        return (Instruction) this;
    }

    public static Instruction readInstruction(int pc, DataInputStream input,
                                              ClassModel clazz, ShapeKey mthd)
            throws IOException {
        int start = input.available();
        int opcode = input.readUnsignedByte();
        boolean isWide;
        if (opcode == 196) {
            isWide = true;
            opcode = input.readUnsignedByte();
        } else
            isWide = false;
        Instruction ins =
            (Instruction) Instruction.instructions.get(new Integer(opcode));
        if (ins == null)
            throw new Error("cannot find instruction for opcode " + opcode
                + " in " + clazz + " " + mthd + " " + pc);
        try {
            if (isWide || ins.isWide())
                ins = ins.readWide(pc, input, clazz, mthd);
            else
                ins = ins.read(pc, input, clazz, mthd);
            ins = ins.copy();
        } catch (IOException ioe) {
            ioe.printStackTrace();
            throw new Error("should not happen: " + ioe + " " + ins + " "
                + opcode);
        }
        if (ins.size(pc) > start - input.available())
            throw new Error("impossible: " + ins + " " + ins.size(pc) + " "
                + start + " " + input.available());
        if (start == input.available())
            throw new Error("that can't happen! " + ins);
        return ins;
    }

    public Instruction read(int pc, DataInputStream input, ClassModel clazz,
                            ShapeKey mthd) throws IOException {
        return (Instruction) this.copy();
    }

    public Instruction readWide(int pc, DataInputStream input,
                                ClassModel clazz, ShapeKey mthd)
            throws IOException {
        throw new Error("wide not supported for " + this);
    }

    public Instruction copy() {
        try {
            return (Instruction) this.clone();
        } catch (CloneNotSupportedException e) {
            throw new Error("" + e);
        }
    }

    public Instruction replace(ReplaceIns replace) {
        Instruction ins = replace.get((Instruction) this);
        return ins;
    }

    public int baseHashCode() {
        return this.opcode();
    }

    public int argCount() {
        return 0;
    }

    public boolean baseEquals(Instruction i) {
        return this.opcode() == i.opcode();
    }

    public Block block;

    public Block block() {
        return this.block;
    }

    public void setBlock(Block block) {
        this.block = block;
    }

    public int hashCode() {
        if (this instanceof Instruction.Imperative)
            return super.hashCode();
        else {
            return this.baseHashCode()
                + (this.args == null ? 0 : this.args.hashCode());
        }
    }

    public boolean equals(Object o) {
        if (!(o instanceof Instruction))
            return false;
        else
            return ((Instruction) o).equals((Instruction) this);
    }

    public boolean equals(Instruction i) {
        if (this instanceof Instruction.Imperative)
            return this == i;
        else if (!this.baseEquals(i))
            return false;
        if (this.args == null && ((Instruction) i).args == null)
            return true;
        if (this.args == null || ((Instruction) i).args == null)
            return false;
        return this.args.equals(((Instruction) i).args);
    }

    public String toString() {
        String s = "";
        s = s + (this.isWide() ? "wide " : "") + this.mnemonic();
        return s;
    }

    public abstract String mnemonic();

    public abstract int opcode();

    protected int size(int pc) {
        return this.size();
    }

    protected int size() {
        return 0;
    }

    public final int size0(int pc) {
        return this.size(pc);
    }

    public boolean isWide() {
        return false;
    }

    private int pc;
    // private List<ins.Value> args = null;
    private List args = null;

    public int pc() {
        return this.pc;
    }

    public void setPC(int pc) {
        this.pc = pc;
    }

    public List args() {
        if (this.args == null)
            this.args = new ArrayList();
        return this.args;
    }

    public String argString() {
        if (this.args == null || this.args.isEmpty())
            return "";
        String s = "";
        for (Iterator i = this.args.iterator(); i.hasNext(); /* i = i */) {
            s = s + ((Value) i.next()).valueString();
            if (i.hasNext())
                s = s + ", ";
        }
        return s;
    }

    public TypeType type(Environment env) {
        return null; /* no type */
    }

    public String valueString() {
        return "v" + this.pc;
    }

    public void execute(Machine m) {
        ;
    }

    public static interface Imperative {
    }

    public Instruction() {
        super();
    }

    public static class Multi extends Instruction {
        public final List list = new ArrayList();

        public String mnemonic() {
            return "multi";
        }

        public int opcode() {
            return 0;
        }
    }
}
