/*
 * Copyright (c) 2004, 2005, 2006 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package edu.utah.jiggy.clazz;

import java.util.*;

import edu.utah.jiggy.meta.flag.AccessFlag;
import edu.utah.jiggy.meta.flag.FlagConstants;
import edu.utah.jiggy.meta.name.ClassName;
import edu.utah.jiggy.meta.shape.ClassShape;
import edu.utah.jiggy.meta.shape.TypeShape;
import edu.utah.jiggy.meta.type.ClassType;
import edu.utah.jiggy.meta.type.PackageType;
import edu.utah.jiggy.meta.type.TypeType;

public class TypeModel extends ClassType {
    private final ClassModel clazz;

    public boolean isShapeSet() {
        return this.clazz.isShapeSet();
    }

    public ClassName name() {
        return this.clazz.name();
    }

    public ClassShape rawShape() {
        return this.clazz.shape();
    }

    public TypeShape shape() {
        return new TypeShape(this.rawShape(), this);
    }

    public String toString() {
        return this.clazz.toString();
    }

    public int hashCode() {
        return this.clazz.hashCode();
    }

    public boolean equals(TypeType type) {
        if (!super.equals(type))
            return type.reverseEquals(this);
        else if (!(type instanceof TypeModel))
            return type.reverseEquals(this);
        else if (((TypeModel) type).clazz != this.clazz)
            return type.reverseEquals(this);
        else
            return true;
    }

    public ClassType inner(ClassName name) {
        if (name.pkg() != null)
            throw new Error();
        ClassModel clazz = (ClassModel) this.clazz.pkg().classes().get(
            name.setOuter(this.clazz.name()).nopkg());
        TypeModel copy = new TypeModel(this, clazz);
        return copy;
    }

    public ClassType outer() {
        return (this.clazz.outer() == null ?
                null : this.clazz.outer().newType());
    }

    public Set inners() {
        // Set<type.Class> inners = new HashSet<type.Class>();
        Set inners = new HashSet();
        for (Iterator i = this.clazz.pkg().classes().values().iterator();
             i.hasNext();
             /* i = i */) {
            ClassModel inner = (ClassModel) i.next();
            if (inner.outer() != this.clazz)
                continue;
            inners.add(inner.newType());
        }
        return inners;
    }

    public ClassModel clazz() {
        return this.clazz;
    }

    protected TypeModel(ClassModel clazz) {
        super();
        this.clazz = clazz;
    }

    private TypeModel(TypeModel original, ClassModel newClazz) {
        super(original);
        this.clazz = newClazz;
    }

    public PackageType pkg0() {
        return this.clazz.pkg();
    }

    // TODO: delete `scope', because it is unused.
    public AccessFlag scope(ClassType clazz) {
        if (clazz instanceof TypeModel) {
            if (((TypeModel) clazz).clazz.pkg() == this.clazz.pkg())
                return FlagConstants.PACKAGE;
        }
        return super.scope(clazz);
    }
}
