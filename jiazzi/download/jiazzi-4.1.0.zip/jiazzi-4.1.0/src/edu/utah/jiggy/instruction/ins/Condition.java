/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.bytecode.ins outins.Branch */

package edu.utah.jiggy.instruction.ins;

import java.io.*;
import java.util.*;

import edu.utah.jiggy.bytecode.bt.BTMethod;
import edu.utah.jiggy.clazz.ClassModel;
import edu.utah.jiggy.meta.shape.ShapeKey;
import edu.utah.jiggy.meta.type.RefType;

public abstract class Condition extends Goto {

    public String toString() {
        return super.toString() + " else " + this.defaultTarget();
    }

    static void activate() {
        {
            Condition.Test conds[] = { GT, NE, GE, LE, LT, EQ };
            for (int i = 0; i < conds.length; i++) {
                (new Condition.Zero(conds[i])).put00();
                (new Condition.Compare(conds[i], TypeInfo.INT)).put00();
            }
        }
        {
            Condition.Test conds[] = { EQ, NE };
            for (int i = 0; i < conds.length; i++) {
                (new Condition.Compare(conds[i], TypeInfo.REFERENCE)).put00();
                (new Condition.Null(conds[i])).put00();
            }
        }
    }

    public final static Condition.Test.GreaterThan GT =
        new Condition.Test.GreaterThan();
    public final static Condition.Test.NotEqual NE =
        new Condition.Test.NotEqual();
    public final static Condition.Test.GreaterEqual GE =
        new Condition.Test.GreaterEqual();
    public final static Condition.Test.LessEqual LE =
        new Condition.Test.LessEqual();
    public final static Condition.Test.LessThan LT =
        new Condition.Test.LessThan();
    public final static Condition.Test.Equal EQ =
        new Condition.Test.Equal();
    protected Block defaultTarget;
    final Condition.Test test;

    public Branch updateBranch(Map map) {
        Condition copy = (Condition) super.updateBranch(map);
        if (!map.containsKey(this.defaultTarget))
            return copy;
        if (copy == this)
            copy = (Condition) this.copy();
        copy.defaultTarget = (Block) map.get(this.defaultTarget);
        return copy;
    }

    public void execute(Machine m) {
        ;
    }

    public Iterator targets() {
        return new Iterator() {
            int n = 0;

            public boolean hasNext() {
                return this.n < 2;
            }

            public Object next() {
                this.n++;
                if (this.n == 1)
                    return Condition.this.target;
                else if (this.n == 2)
                    return Condition.this.defaultTarget;
                else
                    throw new Error();
            }

            public void remove() {
                throw new Error();
            }
        };
    }

    public int baseHashCode() {
        return super.baseHashCode()
            + (this.defaultTarget == null ? 0 : this.defaultTarget.hashCode());
    }

    public boolean baseEquals(Instruction ins0) {
        return super.baseEquals(ins0)
            && (((Condition) ins0).defaultTarget == this.defaultTarget);
    }

    public Condition setDefault(Block target) {
        Condition copy = (Condition) this.copy();
        copy.defaultTarget = target;
        return copy;
    }

    public Block defaultTarget() {
        return this.defaultTarget;
    }

    public Condition.Test test() {
        return this.test;
    }

    public Condition(Condition.Test test) {
        super();
        this.test = test;
    }

    protected int size() {
        return 3;
    }

    public Instruction read(int pc, DataInputStream input, ClassModel clazz,
                            ShapeKey mthd) throws IOException {
        return ((Condition) super.read(pc, input, clazz, mthd))
            .setDefault(((BTMethod) clazz.body().methods().get(mthd)).code()
                .findTarget(pc + this.size()));
    }

    public void write(int pc, DataOutputStream out, ClassModel clazz,
                      ShapeKey mthd) throws IOException {
        super.write(pc, out, clazz, mthd);
        if (pc + this.size() != this.defaultTarget().getPC())
            throw new Error("not supported");
    }

    public static class Zero extends Condition {
        public String mnemonic() {
            return "if" + this.test().mnemonic();
        }

        public int opcode() {
            return 153 + this.test().opcodeOffset();
        }

        public Zero(Condition.Test test) {
            super(test);
        }

        public int argCount() {
            return 1;
        }

        public void execute(Machine m) {
            super.execute(m);
            Value v = m.pop();
            this.args().add(v);
            m.doError(v.type(m.context).isa(TypeInfo.INT), "");
            return;
        }
    }

    public static class Compare extends Condition {
        protected final TypeInfo type;

        public int argCount() {
            return super.argCount() + 2;
        }

        public void execute(Machine m) {
            super.execute(m);
            Value v1 = m.pop();
            Value v0 = m.pop();
            this.args().add(v0);
            this.args().add(v1);
            m.doError(v0.type(m.context).isa(this.typeInfo()), "");
            m.doError(v1.type(m.context).isa(this.typeInfo()), "");
        }

        public String mnemonic() {
            return "if_" + this.typeInfo().mnemonic() + "cmp"
                + this.test().mnemonic();
        }

        public TypeInfo typeInfo() {
            return this.type;
        }

        public int opcode() {
            if (this.typeInfo() == TypeInfo.INT)
                return 159 + this.test().opcodeOffset();
            else
                return 165 + this.test().opcodeOffset();
        }

        public Compare(Condition.Test condition, TypeInfo type) {
            super(condition);
            this.type = type;
            if (type != TypeInfo.INT && type != TypeInfo.REFERENCE)
                throw new Error();
        }
    }

    public static class Null extends Condition {
        public int argCount() {
            return 1;
        }

        public void execute(Machine m) {
            Value v0 = m.pop();
            this.args().add(v0);
            m.doError(v0.type(m.context) instanceof RefType, "");
        }

        public String mnemonic() {
            return "if" + (this.test() == NE ? "non" : "") + "null";
        }

        public int opcode() {
            return 198 + (this.test() == NE ? 1 : 0);
        }

        public Null(Condition.Test test) {
            super(test);
        }
    }

    public abstract static class Test extends Object {
        public abstract int opcodeOffset();

        public abstract String mnemonic();

        public Test() {
            super();
        }

        public static class Equal extends Condition.Test {
            public Equal() {
                super();
            }

            public int opcodeOffset() {
                return 0;
            }

            public String mnemonic() {
                return "eq";
            }
        }

        public static class GreaterThan extends Condition.Test {
            public GreaterThan() {
                super();
            }

            public int opcodeOffset() {
                return 4;
            }

            public String mnemonic() {
                return "gt";
            }
        }

        public static class LessEqual extends Condition.Test {
            public LessEqual() {
                super();
            }

            public int opcodeOffset() {
                return 5;
            }

            public String mnemonic() {
                return "le";
            }
        }

        public static class GreaterEqual extends Condition.Test {
            public GreaterEqual() {
                super();
            }

            public int opcodeOffset() {
                return 3;
            }

            public String mnemonic() {
                return "ge";
            }
        }

        public static class NotEqual extends Condition.Test {
            public NotEqual() {
                super();
            }

            public int opcodeOffset() {
                return 1;
            }

            public String mnemonic() {
                return "neq";
            }
        }

        public static class LessThan extends Condition.Test {
            public LessThan() {
                super();
            }

            public int opcodeOffset() {
                return 2;
            }

            public String mnemonic() {
                return "lt";
            }
        }
    }
}
