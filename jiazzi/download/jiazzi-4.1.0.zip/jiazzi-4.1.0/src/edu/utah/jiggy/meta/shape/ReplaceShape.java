/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.core outshape.ReplaceName */

package edu.utah.jiggy.meta.shape;

import java.util.*;

import edu.utah.jiazzi.unit.ArgVar;
import edu.utah.jiggy.meta.type.ClassType;
import edu.utah.jiggy.meta.type.ReplaceType;

public class ReplaceShape extends ReplaceType {

    private ClassType clazz;
    private MemberShape mmbr;

    public ClassType clazz() {
        return this.clazz;
    }

    public MemberShape mmbr() {
        return this.mmbr;
    }

    public void set(ClassType clazz) {
        this.clazz = clazz;
    }

    public void set(MemberShape mmbr) {
        this.mmbr = mmbr;
    }

    // protected final Map<type.Class,Map<shape.Key,shape.Key>> keys =
    // new HashMap<type.Class,Map<shape.Key,shape.Key>>();
    protected final Map keys = new HashMap();

    public String toString() {
        return super.toString() + " keys:" + this.keys.toString() + " ("
            + this.clazz + ":" + this.mmbr + ")";
    }

    public ReplaceShape() {
    }

    public ReplaceShape(ReplaceShape replace) {
        super(replace);
        for (Iterator i = replace.keys.keySet().iterator();
             i.hasNext();
             /* i = i */) {
            ClassType ctype = (ClassType) i.next();
            this.keys.put(ctype, new HashMap());
            ((Map) this.keys.get(ctype)).putAll((Map) replace.keys.get(ctype));
        }
    }

    public ReplaceShape(ReplaceType replace) {
        super(replace);
    }

    protected ShapeKey get(ShapeKey key, ClassType ctype) {
        while (ctype != null) {
            if (!this.keys.containsKey(ctype)
                || !((Map) this.keys.get(ctype)).containsKey(key)) {
                return key;
                // if (ctype.shape().zuper() == null) return key;
                // shape.ShapeKey ret = this.get(key, ctype.shape().zuper());
                /* speed things up! */
                // this.map(ctype, key, ret);
                // return ret;
            } else {
                return (ShapeKey) ((Map) this.keys.get(ctype)).get(key);
            }
        }
        return key;
    }

    public void map(ClassType ctype, ShapeKey key0, ShapeKey key1) {
        // if (key0.procedure().args().size() != key1.procedure().args().size())
        // throw new Error(key0 + " " + key1);
        if (!this.keys.containsKey(ctype))
            this.keys.put(ctype, new HashMap());
        ((Map) this.keys.get(ctype)).put(key0, key1);
    }

    // Below here,
    // From `edu.utah.jiazzi.core/outshape/Replace.java'.

    // public final Map<unit.ArgVar,shape.Procedure> argVars =
    // new HashMap<unit.ArgVar,shape.Procedure>();
    public final Map argVars = new HashMap();

    public void map(ArgVar var, ProcedureShape p) {
        this.argVars.put(var, p);
    }
}
