/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.core outshape.TypeShape */

package edu.utah.jiggy.meta.shape;

import java.util.*;

import edu.utah.jiggy.meta.flag.FlagConstants;
import edu.utah.jiggy.meta.type.ClassType;

public class TypeShape extends java.lang.Object {
    final ClassType type;
    public final ClassShape raw;

    public TypeShape(ClassShape shape, ClassType type) {
        super();
        if (shape == null)
            throw new Error();
        this.type = type;
        this.raw = shape;
    }

    public ClassShape shape0() {
        return this.raw;
    }

    public ClassType type() {
        return this.type;
    }

    public ClassType zuper() {
        return this.shape0().zuper;
    }

    public Set interfaces() {
        return this.shape0().interfaces;
    }

    public Set fields() {
        return this.shape0()
            .select(this.shape0().fields, ShapeSelector.ACCEPT_ALL);
    }

    public Set methods() {
        return this.shape0()
            .select(this.shape0().methods, ShapeSelector.ACCEPT_ALL);
    }

    public Set inits() {
        return this.shape0()
            .select(this.shape0().inits, ShapeSelector.ACCEPT_ALL);
    }

    public Set fields(ShapeSelector s) {
        return this.shape0().select(this.shape0().fields, s);
    }

    public Set methods(ShapeSelector s) {
        return this.shape0().select(this.shape0().methods, s);
    }

    public Set inits(ShapeSelector s) {
        return this.shape0().select(this.shape0().inits, s);
    }

    public FieldShape actualField(ShapeKey key) {
        return (FieldShape) this.shape0().fields.get(key);
    }

    public MethodShape actualMethod(ShapeKey key) {
        return (MethodShape) this.shape0().methods.get(key);
    }

    public InitShape actualInit(ShapeKey key) {
        return (InitShape) this.shape0().inits.get(key);
    }

    public MemberShape actual(ShapeKey key) {
        if (this.shape0().fields.containsKey(key))
            return this.actualField(key);
        else if (this.shape0().methods.containsKey(key))
            return this.actualMethod(key);
        else if (this.shape0().inits.containsKey(key))
            return this.actualInit(key);
        else
            throw new Error();
    }

    public ClassType freshMethod(ShapeKey key) {
        return this.shape0().freshMethod(this.type, key);
    }

    public ClassType lookupField(ShapeKey key) {
        return this.shape0().lookupField(this.type, key);
    }

    public ClassType lookupMethod(ShapeKey key) {
        return this.shape0().lookupMethod(this.type, key);
    }

    // Below here,
    // From `edu.utah.jiggy.bytecode/outshape/Type.java'.

    public boolean hasAbstractMethods(ClassType ctype) {
        if (!this.hasAbstractMethods0(ctype))
            return false;
        do {
            for (Iterator i = this.interfaces().iterator();
                 i.hasNext();
                 /* i = i */) {
                ClassType intf = (ClassType) i.next();
                for (Iterator j = intf.shape().methods().iterator();
                     j.hasNext();
                     /* j = j */) {
                    ShapeKey key = (ShapeKey) j.next();
                    MethodShape mthd =
                        ctype.shape().lookupMethod(key).shape()
                        .actualMethod(key);
                    if (mthd.isSet(FlagConstants.ABSTRACT))
                        return false;
                }
            }
        } while (ctype.rawShape().checkInterfaces());

        return true;
    }

    public boolean hasAbstractMethods0(ClassType ctype) {
        if (this.zuper() != null
            && this.zuper().shape().hasAbstractMethods0(ctype))
            return true;
        for (Iterator i = this.methods().iterator(); i.hasNext(); /* i = i */) {
            MethodShape mthd0 = this.actualMethod((ShapeKey) i.next());
            if (mthd0.isSet(FlagConstants.STATIC))
                continue;
            MethodShape mthd =
                ctype.shape().lookupMethod(mthd0.key()).shape()
                .actualMethod(mthd0.key());
            if (mthd.isSet(FlagConstants.ABSTRACT))
                return true;
        }
        return false;
    }
}
