/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package edu.utah.jiggy.meta.type;

import java.util.HashMap;
import java.util.Map;

public class PrimitiveType extends TypeType {
    public PrimitiveType() {
        super();
        // Following line from constructor in
        // `edu.utah.jiggy.bytecode/outtype/Primitive.java'.
        TypeType.primitives.put(
            new Character(this.code()),
            (PrimitiveType) this);
        // Following line from constructor in
        // `edu.utah.jiggy.instruction/outtype/Primitive.java'.
        if (this.stackWidth() > 0)
            if (arrayMap.put(
                    new Integer(this.arrayCode()), (PrimitiveType) this)
                != null)
                throw new Error();
    }

    public int hashCode() {
        return super.hashCode() + this.getClass().hashCode();
    }

    public boolean equals(TypeType type) {
        if (!(type instanceof PrimitiveType))
            return type.reverseEquals(this);
        PrimitiveType ptype = (PrimitiveType) type;
        if (!super.equals(ptype))
            return type.reverseEquals(this);
        else if (this != ptype)
            return type.reverseEquals(this);
        else
            return true;
    }

    // Below here,
    // From `edu.utah.jiggy.bytecode/outtype/Primitive.java'.

    protected char code() {
        throw new Error();
    }

    public String jvmTypeString() {
        return "" + this.code();
    }

    // Below here,
    // From `edu.utah.jiggy.instruction/outtype/Primitive.java'.

    // public static final Map<Integer,type.Primitive> arrayMap =
    // new HashMap<Integer,type.Primitive>();
    public static final Map arrayMap = new HashMap();

    public int arrayCode() {
        throw new Error("abstract: " + this);
    }
}
