/*
 * Copyright (c) 2004, 2005, 2006 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package edu.utah.jiggy.meta.shape;

import java.util.*;
import java.io.*;

import edu.utah.jiggy.meta.flag.FlagConstants;
import edu.utah.jiggy.meta.flag.VirtualFlag;
import edu.utah.jiggy.meta.name.MemberName;
import edu.utah.jiggy.meta.type.ClassType;

/* aspects can be rules */

public class ClassShape extends Base {

    protected ClassType zuper;
    protected VirtualFlag virtual;
    // protected InterfaceSet interfaces;
    // protected MemberSet<shape.IsField> fields;
    // protected MemberSet<shape.IsMethod> methods;
    // protected MemberSet<shape.IsInit> inits;
    // protected byte state = STATE_NULL;

    protected Set interfaces = new HashSet();
    protected Map fields = new HashMap();
    protected Map methods = new HashMap();
    protected Map inits = new HashMap();

    // protected Set<type.Class> interfaces = new HashSet<type.Class>();
    // protected Map<shape.ShapeKey,shape.FieldShape> fields = new
    // HashMap<shape.ShapeKey,shape.FieldShape>();
    // protected Map<shape.ShapeKey,shape.MethodShape> methods = new
    // HashMap<shape.ShapeKey,shape.MethodShape>();
    // protected Map<shape.ShapeKey,shape.InitShape> inits = new
    // HashMap<shape.ShapeKey,shape.InitShape>();

    public void print(ClassType clazz, String indent, PrintStream out,
                      String emsg) {
        if (clazz.outer() == null)
            out.println(
                indent + "package " + clazz.pkg0().name().javaSource() + ";");

        boolean intf = this.isSet(FlagConstants.INTERFACE);
        out.print(indent + this.javaSource());
        if (intf)
            out.print("interface ");
        else
            out.print("class ");
        out.print(clazz.name().base().javaSource());
        if (!intf && this.zuper != null) {
            out.print(" extends " + this.zuper.javaSource());
        }
        if (!this.interfaces.isEmpty()) {
            if (intf)
                out.print(" extends ");
            else
                out.print(" implements ");
            for (Iterator i = this.interfaces.iterator();
                 i.hasNext();
                 /* i = i */) {
                out.print(((ClassType) i.next()).javaSource());
                if (i.hasNext())
                    out.print(", ");
            }
        }
        out.println(" {");
        for (Iterator i = this.methods.keySet().iterator();
             i.hasNext();
             /* i = i */) {
            MethodShape mthd = (MethodShape) this.methods.get(i.next());
            out.print("  " + indent + mthd.javaSource(null));
            if (emsg != null && mthd.virtual().isa(FlagConstants.CONCRETE)) {
                out.println(" {");
                out.println("    " + indent + "throw new java.lang.Error(\""
                    + emsg + "\");");
                out.println("  " + indent + "}");
            } else
                out.println(";");
        }
        for (Iterator i = this.inits.keySet().iterator();
             i.hasNext();
             /* i = i */) {
            InitShape init = (InitShape) this.inits.get(i.next());
            out.print("  " + indent
                + init.javaSource(clazz.name().base().javaSource()));

            if (emsg != null) {
                out.println(" {");
                out.print("  " + indent + "  ");
                if (this.zuper != null) {
                    out.print("super(");
                    if (this.zuper.shape().inits().contains(init.key())) {
                        for (Iterator j = init.procedure().args().iterator();
                             j.hasNext();
                             /* j = j */) {
                            out.print(((ArgShape) j.next()).name());
                            if (j.hasNext())
                                out.print(", ");
                        }
                    } else {
                        if (!this.zuper.shape().inits().iterator().hasNext())
                            throw new Error(this.zuper
                                + " does not have constructors!");
                        ShapeKey ikey =
                            (ShapeKey) this.zuper.shape().inits().iterator()
                            .next();
                        if (ikey == null)
                            throw new Error(clazz + " " + this.zuper + " "
                                + this.zuper.shape().inits());
                        InitShape init0 = this.zuper.shape().actualInit(ikey);
                        if (init0 == null)
                            throw new Error();
                        if (init0.procedure() == null)
                            throw new Error();
                        for (Iterator j = init0.procedure().args().iterator();
                             j.hasNext();
                             /* j = j */) {
                            out.print(
                                ((ArgShape) j.next()).type().defaultValue());
                            if (j.hasNext())
                                out.print(", ");
                        }
                    }
                }
                out.println(");");
                out.println("  " + indent + "}");
            } else
                out.println(";");
        }
        for (Iterator i = this.fields.keySet().iterator();
             i.hasNext();
             /* i = i */) {
            FieldShape fld = (FieldShape) this.fields.get(i.next());
            out.print("  " + indent + fld.javaSource(null));
            if (fld.constant() == null) {
                out.print(" = " + fld.nameType().type().defaultValue());
            }
            out.println(";");
        }
        for (Iterator i = clazz.inners().iterator(); i.hasNext(); /* i = i */) {
            ClassType inner = (ClassType) i.next();
            inner.rawShape().print(inner, "  " + indent, out, emsg);
        }
        out.println(indent + "}");
    }

    // private static final byte STATE_NULL = 0;
    // private static final byte STATE_PRE = 1;
    // private static final byte STATE_NORM = 2;

    public void setZuper(ClassType zuper) {
        this.zuper = zuper;
    }

    protected Set supported() {
        return FlagConstants.CLASS_FLAGS;
    }

    public void set(VirtualFlag v) {
        this.validate(v);
        this.virtual = v;
    }

    public void addInterface(ClassType intf) {
        this.interfaces.add(intf);
    }

    public void add(FieldShape fld) {
        this.fields.put(fld.key(), fld);
    }

    public void add(MethodShape mthd) {
        this.methods.put(mthd.key(), mthd);
    }

    public void add(InitShape init) {
        this.inits.put(init.key(), init);
    }

    public String javaSource() {
        return super.javaSource0();
    }

    public ClassShape() {
        super();
    }

    public String toString() {
        return super.toString() + " " + this.zuper + " " + this.interfaces
            + " " + this.fields.values() + " " + this.methods.values() + " "
            + this.inits.values();
    }

    public void setVirtual(VirtualFlag vr) {
        this.virtual = vr;
    }

    public ClassShape bridge(ClassType type) {
        return (ClassShape) this.copy();
    }

    public void add(ClassShape shape) {
        this.interfaces.addAll(shape.interfaces);
        /* no clobber copies */
        copyIntoSafe(shape.methods, this.methods);
        copyIntoSafe(shape.fields, this.fields);
        copyIntoSafe(shape.inits, this.inits);
    }

    public void subtract(ClassShape shape) {
        /* this.interfaces.removeAll(shape.interfaces); */
        this.fields.keySet().removeAll(shape.fields.keySet());
        if (true)
            this.methods.keySet().removeAll(shape.methods.keySet());
        else {
            for (Iterator i = shape.methods.values().iterator();
                 i.hasNext();
                 /* i = i */) {
                MethodShape mthd0 = (MethodShape) i.next();
                if (!this.methods.containsKey(mthd0.key()))
                    continue;
                MethodShape mthd1 = (MethodShape) this.methods.get(mthd0.key());
                if (!mthd1.matches(mthd0))
                    throw new Error(mthd1 + " in " + this + " does not match "
                        + mthd0 + " in " + shape);
                if (mthd0.matches(mthd1)) {
                    if (!this.methods.keySet().remove(mthd0.key()))
                        throw new Error();
                    if (this.methods.keySet().contains(mthd0.key()))
                        throw new Error();
                } else {
                }
            }
        }
    }

    public Base copy() {
        ClassShape copy = (ClassShape) super.copy();
        copy.interfaces = new HashSet(this.interfaces);
        copy.methods = new HashMap(this.methods);
        copy.fields = new HashMap(this.fields);
        copy.inits = new HashMap(this.inits);
        return copy;
    }

    public ClassShape replace(ReplaceShape replace) {
        if (replace.clazz().shape().raw != this)
            throw new Error();
        // replace.set(clazz);

        ClassShape copy = (ClassShape) super.copy();

        if (this.zuper != null)
            copy.zuper = (ClassType) this.zuper.replace(replace);
        else
            copy.zuper = null;

        copy.interfaces = new HashSet();
        for (Iterator i = this.interfaces.iterator(); i.hasNext(); /* i = i */)
            copy.interfaces.add(
                (ClassType) ((ClassType) i.next()).replace(replace));

        copy.fields = this.replace(this.fields, replace);
        copy.methods = this.replace(this.methods, replace);
        copy.inits = this.replace(this.inits, replace);
        // replace.set((type.ClassName) null);
        return copy;
    }

    public VirtualFlag virtual() {
        return this.virtual;
    }

    public ClassShape collapse(Set visible) {
        ClassShape copy = (ClassShape) this.copy();
        if (this.methods.size() != copy.methods.size())
            throw new Error("wtf");
        if (this.interfaces.size() != copy.interfaces.size())
            throw new Error("wtf");
        ClassType z = this.zuper;
        while (true) {
            if (false)
                System.err.println("zuper " + z + " "
                    + visible.contains(z.raw()));
            if (z == null || visible.contains(z.raw()))
                break;
            for (Iterator i = z.shape().methods().iterator();
                 i.hasNext();
                 /* i = i */) {
                ShapeKey mthd = (ShapeKey) i.next();
                if (!copy.methods.containsKey(mthd)) {
                    copy.methods.put(mthd, z.shape().actualMethod(mthd));
                    // System.err.println("add " + mthd + " from " + z);
                }
            }
            for (Iterator i = z.shape().fields().iterator();
                 i.hasNext();
                 /* i = i */) {
                ShapeKey fld = (ShapeKey) i.next();
                // System.err.println("add " + fld + " from " + z);
                copy.fields.put(fld, z.shape().actualField(fld));
            }
            z = z.shape().zuper();
        }
        copy.zuper = z;

        for (Iterator i = this.interfaces.iterator();
             i.hasNext();
             /* i = i */) {
            ClassType intf = (ClassType) i.next();
            if (!visible.contains(intf))
                copy.interfaces.remove(intf);
            for (Iterator j = intf.shape().methods().iterator();
                 j.hasNext();
                 /* j = j */) {
                ShapeKey mthd = (ShapeKey) j.next();
                if (!copy.methods.containsKey(mthd)) {
                    // System.err.println("add " + mthd + " from " + intf);
                    copy.methods.put(mthd, intf.shape().actualMethod(mthd));
                }
            }
            for (Iterator j = intf.shape().fields().iterator();
                 j.hasNext();
                 /* j = j */) {
                ShapeKey fld = (ShapeKey) j.next();
                if (!copy.fields.containsKey(fld)) {
                    // System.err.println("add " + fld + " from " + intf);
                    copy.fields.put(fld, intf.shape().actualField(fld));
                }
            }
        }
        return copy;
    }

    public boolean equals(Object o) {
        ClassShape clazz = (ClassShape) o;
        return this.matches(clazz) && clazz.matches((ClassShape) this);
    }

    public int hashCode() {
        throw new Error(this + " shouldn't be hashed!");
    }

    public boolean matches(ClassShape m) {
        return this.matches((ClassShape) m, new PrintStream(
            new ByteArrayOutputStream()));
    }

    /*
     * public shape.ClassName lookup[N](shape.ShapeKey key) { if
     * (this.getSet[N]().containsKey(key)) return (shape.ClassName) this;
     * type.ClassName found = this.lookup[N](null, key); if (found == null)
     * return null; else return found.rawShape; } public type.ClassName
     * lookup[N](type.ClassName ctype, shape.ShapeKey key) { if
     * (this.getSet[N]().containsKey(key)) return ctype; for (type.ClassName z =
     * this.zuper; z != null; z = z.shape().zuper()) { if
     * (z.shape().getSet[N]().contains(key)) return z; } for (Iterator<type.ClassName>
     * i = this.interfaces.iterator(); i.hasNext(); i = i) { type.ClassName intf =
     * i.next(); if (intf.shape().getSet[N]().contains(key)) return intf; } if
     * (this.checkInterfaces()) return this.lookup[N](ctype, key); else return
     * null; }
     */

    public ClassShape lookupField(ShapeKey key) {
        if (this.fields.containsKey(key))
            return (ClassShape) this;
        ClassType found = this.lookupField(null, key);
        if (found == null)
            return null;
        else
            return found.rawShape();
    }

    /* gross */
    public boolean checkInterfaces() {
        boolean ret = false;
        for (ClassType z = this.zuper; z != null; z = z.shape().zuper()) {
            if (this.interfaces.addAll(z.shape().interfaces()))
                ret = true;
        }
        for (Iterator i = this.interfaces.iterator();
             i.hasNext();
             /* i = i */) {
            ClassType intf = (ClassType) i.next();
            if (this.interfaces.addAll(intf.shape().interfaces())) {
                ret = true;
                i = this.interfaces.iterator();
            }
        }
        return ret;
    }

    public ClassType lookupField(ClassType ctype, ShapeKey key) {
        if (this.fields.containsKey(key))
            return ctype;
        for (ClassType z = this.zuper; z != null; z = z.shape().zuper()) {
            if (z.shape().fields().contains(key))
                return z;
        }
        for (Iterator i = this.interfaces.iterator();
             i.hasNext();
             /* i = i */) {
            ClassType intf = (ClassType) i.next();
            if (intf.shape().fields().contains(key))
                return intf;
        }
        if (this.checkInterfaces())
            return this.lookupField(ctype, key);
        else
            return null;
    }

    public ClassType freshMethod(ClassType self, ShapeKey key) {
        if (this.zuper != null) {
            if (this.zuper.isShapeSet()) {
                // System.err.print(" " + this.zuper.shape());
                if (this.zuper.shape() != null) {
                    if (false) {
                        System.err.print(
                            "FND " + self.javaSource() + " " + key);
                        System.err.print(" " + this.zuper.javaSource());
                        System.err.print(" " + this.zuper.isShapeSet());
                        System.err.print(" " + this.zuper.shape().methods());
                    }
                }
            } else {
                if (false) {
                    System.err.print("FND " + self.javaSource() + " " + key
                        + " " + this.zuper.javaSource() + " no");
                    System.err.println();
                }
            }
        }
        if (this.zuper != null && this.zuper.isShapeSet()) {
            // throw new Error(this.zuper + " " + this.zuper.shape());

            ClassType ctype =
                this.zuper.rawShape().freshMethod(this.zuper, key);
            if (ctype != null)
                return ctype;
        }
        for (Iterator i = this.interfaces.iterator();
             i.hasNext();
             /* i = i */) {
            ClassType intf = (ClassType) i.next();
            if (!intf.isShapeSet())
                continue;
            ClassType ctype = intf.rawShape().freshMethod(intf, key);
            if (ctype != null)
                return ctype;
        }
        if (this.methods.containsKey(key))
            return self;
        else
            return null;
    }

    public ClassShape lookupMethod(ShapeKey key) {
        if (this.methods.containsKey(key))
            return (ClassShape) this;
        ClassType ctype = this.lookupMethod(null, key);
        if (ctype == null)
            return null;
        else
            return ctype.rawShape();
    }

    public ClassType lookupMethod(ClassType ctype, ShapeKey key) {
        if (this.methods.containsKey(key))
            return ctype;
        for (ClassType z = this.zuper; z != null; z = z.shape().zuper()) {
            if (z.shape().methods().contains(key))
                return z;
        }
        for (Iterator i = this.interfaces.iterator();
             i.hasNext();
             /* i = i */) {
            ClassType intf = (ClassType) i.next();
            if (intf.shape().methods().contains(key))
                return intf;
        }
        if (this.checkInterfaces())
            return this.lookupMethod(ctype, key);
        else
            return null;
    }

    public MethodShape actualMethod(ShapeKey key) {
        ClassShape found = this.lookupMethod(key);
        return (MethodShape) found.methods.get(key);
    }

    public FieldShape actualField(ShapeKey key) {
        ClassShape found = this.lookupField(key);
        return (FieldShape) found.fields.get(key);
    }

    public boolean matches(ClassShape clazz, PrintStream out) {
        boolean pass = true;
        if (!super.matches(clazz)) {
            pass = false;

            out.println("flag mismatch " + this.virtual() + " " + this.access()
                + " " + this.binaries + " vs. " + clazz.virtual() + " "
                + clazz.access() + " " + clazz.binaries());
        }
        if (false && clazz.virtual().isa(FlagConstants.CONCRETE)
            && this.virtual().isa(FlagConstants.ABSTRACT)) {
            /* XXX: disabled */
            /* ensure all abstract methods are concrete */
            for (Iterator i = this.interfaces.iterator();
                 i.hasNext();
                 /* i = i */) {
                ClassType intf = (ClassType) i.next();
                for (Iterator j = intf.shape().methods().iterator();
                     j.hasNext();
                     /* j = j */) {
                    ShapeKey key = (ShapeKey) j.next();
                    MethodShape mthd = this.actualMethod(key);
                    if (!mthd.virtual().isa(FlagConstants.CONCRETE)) {
                        pass = false;
                        out.println(this.lookupMethod(key).actualMethod(key)
                            .javaSource(""));
                        out.println(clazz.lookupMethod(key).actualMethod(key)
                            .javaSource(""));

                        out.println("method " + mthd.javaSource("")
                            + " from interface " + intf.javaSource()
                            + " is still abstract so class "
                            + clazz.javaSource() + " cannot become concrete");
                    }
                }
            }
            for (Iterator j = this.methods.values().iterator();
                 j.hasNext();
                 /* j = j */) {
                MethodShape mthd = (MethodShape) j.next();
                if (!mthd.virtual().isa(FlagConstants.CONCRETE)) {
                    pass = false;
                    out.println("2 method " + mthd.javaSource("")
                        + " still abstract so class cannot become concrete");
                }
            }
            for (ClassType t = this.zuper; t != null; t = t.shape().zuper()) {
                for (Iterator j = t.shape().methods().iterator();
                     j.hasNext();
                     /* j = j */) {
                    ShapeKey key = (ShapeKey) j.next();
                    MethodShape mthd = this.actualMethod(key);
                    if (!mthd.virtual().isa(FlagConstants.CONCRETE)) {
                        pass = false;
                        out.println(
                            "3 method "
                            + mthd.javaSource("")
                            + " still abstract so class cannot become concrete");
                    }
                }
            }
        }
        if (((this.zuper == null || clazz.zuper == null)
                && !(this.zuper == null && clazz.zuper == null))
            || !this.zuper.equals(clazz.zuper)) {
            pass = false;
            out.println("super mismatch, super is actually " + this.zuper
                + " but expected " + clazz.zuper);
        }
        for (Iterator i = clazz.interfaces.iterator();
             i.hasNext();
             /* i = i */) {
            ClassType intf0 = (ClassType) i.next();
            if (!this.interfaces.contains(intf0)) {
                out.println("interface " + intf0 + " not matched in "
                    + this.interfaces);
                pass = false;
            }
        }
        if (!this.matches(new Lookup() {
            public Object lookup(ClassShape shape, ShapeKey key) {
                ClassShape found = shape.lookupField(key);
                if (found == null)
                    return null;
                else
                    return found.fields.get(key);
            }
        }, clazz.fields, out))
            pass = false;

        if (!this.matches(new Lookup() {
            public Object lookup(ClassShape shape, ShapeKey key) {
                ClassShape found = shape.lookupMethod(key);
                if (found == null)
                    return null;
                else
                    return found.methods.get(key);
            }

            public Map members(ClassShape shape) {
                return shape.methods;
            }
        }, clazz.methods, out))
            pass = false;

        if (!this.matches(new Lookup() {
            public Object lookup(ClassShape shape, ShapeKey key) {
                if (!shape.inits.containsKey(key))
                    return null;
                else
                    return shape.inits.get(key);
            }

            public Map members(ClassShape shape) {
                return shape.inits;
            }
        }, clazz.inits, out))
            pass = false;

        for (Iterator i = this.methods.values().iterator();
             i.hasNext();
             /* i = i */) {
            MethodShape mthd = (MethodShape) i.next();
            ClassShape found = clazz.lookupMethod(mthd.key());
            /* XXX: disabled */
            if (false && mthd.virtual() == FlagConstants.ABSTRACT) {
                // Advice.failIfFalse(found != null);
                if (false && found == null) {
                    if (clazz.zuper != null
                        && clazz.zuper.rawShape().lookupMethod(mthd.key()) != null)
                        throw new Error("you wenti "
                            + clazz.zuper.rawShape().lookupMethod(mthd.key()));
                    pass = false;
                    out.println("method \"" + mthd.javaSource("")
                        + "\" cannot be hidden by match");
                } else if (!mthd.matches(
                            (MemberShape) found.methods.get(mthd.key()))) {
                    // throw new Error(mthd + " vs. " +
                    // found.methods.get(mthd.key()));
                } else if (((MethodShape) found.methods.get(mthd.key()))
                    .virtual() != FlagConstants.ABSTRACT)
                    throw new Error();
            } else if (mthd.virtual() == FlagConstants.FINAL) {
                if ((found != null)
                    && ((MethodShape) found.methods.get(mthd.key())).virtual()
                       != FlagConstants.FINAL
                    && !mthd.nameType().name().equals(
                        new MemberName("<clinit>"))) {
                    pass = false;
                    out.println("method \""
                        + mthd.javaSource("")
                        + "\" must be final in match, not \""
                        + ((MethodShape) found.methods.get(mthd.key()))
                            .javaSource("") + "\"");
                }
            }
        }
        return pass;
    }

    /*
     * only detects structural problems
     */
    public boolean verify(PrintStream out) {
        boolean pass = true;

        if (this.zuper != null
            && this.zuper.rawShape().isSet(FlagConstants.INTERFACE)) {
            pass = false;
            out.println("super class " + this.zuper + " is not a class");
        }
        for (Iterator i = this.interfaces.iterator();
             i.hasNext();
             /* i = i */) {
            ClassType intf = (ClassType) i.next();
            if (!intf.rawShape().isSet(FlagConstants.INTERFACE)) {
                pass = false;
                out.println("declared interface " + intf
                    + " is not really an interface");
            }
        }
        if (this.isSet(FlagConstants.FINAL)) {
            for (Iterator i = this.methods.values().iterator();
                 i.hasNext();
                 /* i = i */) {
                MethodShape m = (MethodShape) i.next();
                if (m.isSet(FlagConstants.FINAL))
                    continue;
                if (m.isSet(FlagConstants.STATIC))
                    continue;
                if (m.isSet(FlagConstants.PRIVATE))
                    continue;
                /* all methods in final class are final */
                m.set(FlagConstants.FINAL);
            }
        }
        if (this.isSet(FlagConstants.INTERFACE)) {
            if (!this.inits.isEmpty()) {
                pass = false;
                out.println("interface cannot contain constructors: "
                    + this.inits.values());
            }
            if (this.zuper == null || this.zuper.rawShape().zuper != null) {
                pass = false;
                out.println("super class " + this.zuper + " is not Object");
            }
            for (Iterator i = this.methods.values().iterator();
                 i.hasNext();
                 /* i = i */) {
                MethodShape m = (MethodShape) i.next();
                if (!m.nameType().name().equals(new MemberName("<clinit>"))
                    && (!m.access().isa(FlagConstants.PUBLIC)
                        || m.virtual() != FlagConstants.ABSTRACT
                        || m.isSet(FlagConstants.STATIC))) {
                    pass = false;
                    out.println(
                        m + " has wrong modifiers for interface method");
                }
            }
            for (Iterator i = this.fields.values().iterator();
                 i.hasNext();
                 /* i = i */) {
                FieldShape m = (FieldShape) i.next();
                if (!m.access().isa(FlagConstants.PUBLIC)
                    || !m.isSet(FlagConstants.IMMUTABLE)
                    || !m.isSet(FlagConstants.STATIC)) {
                    pass = false;
                    out.println(m + " has wrong modifiers for interface field");
                }
            }
        }
        /* check for cyclic inheritance */
        Set visited = new HashSet();
        Set interfaces = new HashSet();

        interfaces.addAll(this.interfaces);
        for (ClassType zuper = this.zuper;
             zuper != null;
             zuper = zuper.rawShape().zuper) {
            if (!visited.add(zuper)) {
                pass = false;
                out.println("class cycle detected: " + zuper);
            }
            interfaces.addAll(zuper.shape().interfaces());
        }
        for (Iterator i = interfaces.iterator(); i.hasNext(); /* i = i */) {
            ClassType intf = (ClassType) i.next();
            if (visited.contains(intf))
                continue;
            visited.add(intf);
            if (interfaces.addAll(intf.shape().interfaces()))
                i = interfaces.iterator();
        }
        this.interfaces.addAll(interfaces);
        return pass;
    }

    protected Map replace(Map map, ReplaceShape replace) {
        HashMap nmap = new HashMap();
        for (Iterator i = map.values().iterator(); i.hasNext(); /* i = i */) {
            MemberShape m = (MemberShape) i.next();
            m = (MemberShape) m.replace(replace, replace.clazz());
            nmap.put(m.key(), m);
        }
        return nmap;
    }

    protected void copyIntoSafe(Map from, Map to) {
        for (Iterator i = from.keySet().iterator(); i.hasNext(); /* i = i */) {
            Object key = i.next();
            if (to.containsKey(key))
                continue;
            to.put(key, from.get(key));
        }
    }

    static interface Lookup {
        public Object lookup(ClassShape clazz, ShapeKey key);
    }

    protected boolean matches(Lookup lookup, Map sinkMap, PrintStream out) {
        boolean pass = true;
        for (Iterator i = sinkMap.values().iterator();
             i.hasNext();
             /* i = i */) {
            MemberShape sink = (MemberShape) i.next();
            MemberShape source =
                (MemberShape) lookup.lookup((ClassShape) this, sink.key());
            if (source == null) {
                String kind = sink.getClass().getName();
                kind = kind.substring(
                    kind.lastIndexOf('.') + 1, kind.length())
                    .toLowerCase();
                out.println("missing " + kind + " \""
                    + sink.javaSource("<init>") + "\"");
                pass = false;
            } else if (!source.matches(sink)) {
                out.println(
                    "\"" + source.javaSource("<init>")
                    + "\" does not match \"" + sink.javaSource("<init>")
                    + "\"");
                pass = false;
            }
        }
        return pass;
    }

    protected Set select(final Map map, final ShapeSelector s) {
        return new AbstractSet() {
            // public boolean contains(ShapeKey key)
            public boolean contains(Object obj) {
                ShapeKey key = (ShapeKey) obj;
                if (!map.containsKey(key))
                    return false;
                else if (!s.accept((MemberShape) map.get(key)))
                    return false;
                else
                    return true;
            }

            public int size() {
                if (s == ShapeSelector.ACCEPT_ALL)
                    return map.size();
                else
                    throw new UnsupportedOperationException();
            }

            // public boolean add(ShapeKey key)
            public boolean add(Object obj) {
                throw new UnsupportedOperationException();
            }

            // public boolean remove(ShapeKey key)
            public boolean remove(Object obj) {
                throw new UnsupportedOperationException();
            }

            public Iterator iterator() {
                final Iterator i = map.keySet().iterator();
                return new Iterator() {
                    ShapeKey next;

                    private void forward() {
                        while (i.hasNext()) {
                            this.next = (ShapeKey) i.next();
                            if (s.accept((MemberShape) map.get(this.next)))
                                return;
                        }
                        this.next = null;
                    }

                    {
                        this.forward();
                    }

                    public boolean hasNext() {
                        return this.next != null;
                    }

                    public Object next() {
                        ShapeKey ret = this.next;
                        this.forward();
                        return ret;
                    }

                    public void remove() {
                        throw new UnsupportedOperationException();
                    }
                };
            }
        };
    }
}
