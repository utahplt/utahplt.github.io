/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.bytecode.ins outins.Compare */

package edu.utah.jiggy.instruction.ins;

import edu.utah.jiggy.meta.type.Environment;
import edu.utah.jiggy.meta.type.TypeConstants;
import edu.utah.jiggy.meta.type.TypeType;

public abstract class Compare extends SimpleTyped {

    public int argCount() {
        return 2;
    }

    public void execute(Machine m) {
        Value value1 = m.pop();
        Value value0 = m.pop();
        this.args().add(value0);
        this.args().add(value1);
        m.doError(value0.type(m.context).isa(this.typeInfo()));
        m.doError(value1.type(m.context).isa(this.typeInfo()));
        m.push(this);
    }

    public TypeType type(Environment env) {
        return TypeConstants.INT;
    }

    static void activate() {
        (new Compare.Long()).put00();
        TypeInfo types[] = { TypeInfo.FLOAT, TypeInfo.DOUBLE };
        for (int i = 0; i < types.length; i++)
            for (int j = 0; j < 2; j++)
                (new Compare.Fixed(types[i], j == 0)).put00();
    }

    public Compare(TypeInfo type) {
        super(type);
    }

    protected int size() {
        return 1;
    }

    public String mnemonic() {
        return this.typeInfo().mnemonic() + "cmp";
    }

    /* atom-edu.utah.jiggy.bytecode.ins outins.Compare.Fixed */
    public static class Fixed extends Compare {
        final boolean isPositiveNan;

        public boolean isPositiveNan() {
            return this.isPositiveNan;
        }

        public java.lang.String mnemonic() {
            return super.mnemonic() + (this.isPositiveNan() ? 'g' : 'l');
        }

        public int opcode() {
            return 149
                + ((this.typeInfo().opcodeOffset()
                        - TypeInfo.FLOAT.opcodeOffset()) * 2)
                + (this.isPositiveNan() ? 1 : 0);
        }

        public Fixed(TypeInfo type, boolean isPositiveNan) {
            super(type);
            this.isPositiveNan = isPositiveNan;
        }
    }

    public static class Long extends Compare {
        public int opcode() {
            return 148;
        }

        public Long() {
            super(TypeInfo.LONG);
        }
    }
}
