/*
 * Copyright (c) 2004, 2005, 2006 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package edu.utah.jiggy.clazz;

import java.io.*;
import java.util.jar.*;
import java.util.*;

import edu.utah.jiggy.meta.name.ClassName;
import edu.utah.jiggy.meta.name.PackageName;

public class JarModelRoot extends ModelRoot {
    // protected
    // public
    public static final char SEP = '/';

    final JarFile jar;

    public JarModelRoot(File jar) {
        super();
        try {
            this.jar = new JarFile(jar);
            this.setModified(jar.lastModified());
        } catch (IOException e) {
            throw new Error(jar.getName() + " " + e);
        }
        this.loadAll();
    }

    public String toString() {
        return this.jar.getName();
    }

    private void loadAll() {
        for (Enumeration i = this.jar.entries();
             i.hasMoreElements();
             /* i = i */) {
            JarEntry e = (JarEntry) i.nextElement();
            String name = e.getName();
            if (!name.endsWith(".class"))
                continue;
            name = name.substring(0, name.length() - (".class").length());

            PackageName pname = this.parsePackage(
                name.substring(0, name.lastIndexOf(SEP)),
                SEP);
            ClassName cname = this.parseClass(
                name.substring(name.lastIndexOf(SEP) + 1, name.length()));

            PackageModel pkg;
            if (this.packages().containsKey(pname))
                pkg = (PackageModel) this.packages().get(pname);
            else
                pkg = new PackageModel(this, pname);
            // ClassModel clazz =
            new ClassModel(pkg, cname);
        }
    }

    protected DataInputStream readClass(ClassModel clazz) {
        try {
            String path = clazz.pkg().name().javaSource().replace('.', SEP)
                + SEP + clazz.name().nopkg().javaSource().replace('.', '$')
                + ".class";

            JarEntry je = this.jar.getJarEntry(path);
            if (je == null || je.isDirectory()) {
                System.err.println("warning: cannot find " + path + " in "
                    + this);
                return null;
            }
            return new DataInputStream(this.jar.getInputStream(je));
        } catch (IOException ioe) {
            throw new Error("" + ioe);
        }
    }
}
