/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.bytecode outattr.Exceptions */

package edu.utah.jiggy.bytecode.bt;

import java.util.*;
import java.io.*;

import edu.utah.jiggy.clazz.ClassModel;
import edu.utah.jiggy.meta.shape.Base;
import edu.utah.jiggy.meta.shape.FieldShape;
import edu.utah.jiggy.meta.shape.InitShape;
import edu.utah.jiggy.meta.shape.MemberShape;
import edu.utah.jiggy.meta.shape.MethodShape;
import edu.utah.jiggy.meta.shape.ShapeKey;
import edu.utah.jiggy.meta.shape.ThrowzShape;
import edu.utah.jiggy.meta.type.ClassType;

public class BTExceptions extends BTAttr {
    protected boolean isClass() {
        return false;
    }

    public boolean isDerived() {
        return true;
    }

    public String name() {
        return "Exceptions";
    }

    public BTAttr readMember(int size, DataInputStream in, ClassModel clazz,
                             BTMember mmbr, MemberShape smthd)
            throws IOException {
        BTAttr attr = super.readMember(size, in, clazz, mmbr, smthd);
        int count = in.readUnsignedShort();
        for (int i = 0; i < count; i++) {
            ClassType etype = (ClassType) clazz.body().pool().get(
                in.readUnsignedShort()).clazz();
            smthd.set(smthd.throwz().add(etype));
        }
        return attr;
    }

    protected ThrowzShape throwz(ClassModel clazz, ShapeKey mmbr) {
        MemberShape shape = clazz.newType().shape().actual(mmbr);
        if (shape instanceof InitShape)
            return ((InitShape) shape).throwz();
        else
            return ((MethodShape) shape).throwz();
    }

    public boolean prepareWriteMember(ClassModel clazz, ShapeKey mmbr) {
        if (clazz.newType().shape().actual(mmbr) instanceof FieldShape)
            return false;
        ThrowzShape throwz = this.throwz(clazz, mmbr);
        if (throwz.members().isEmpty())
            return false;
        for (Iterator i = throwz.members().iterator(); i.hasNext(); /* i = i */)
            clazz.body().pool().allocClass((ClassType) i.next());
        return super.prepareWriteMember(clazz, mmbr);
    }

    public void writeMember(DataOutputStream out, ClassModel clazz,
                            ShapeKey mmbr) throws IOException {
        super.writeMember(out, clazz, mmbr);
        ThrowzShape throwz = this.throwz(clazz, mmbr);
        out.writeShort(throwz.members().size());
        for (Iterator i = throwz.members().iterator(); i.hasNext(); /* i = i */)
            out.writeShort(
                clazz.body().pool().allocClass((ClassType) i.next()));
    }

    protected int size(ClassModel clazz, Base base) {
        return 2 +
            (this.throwz(clazz, ((MemberShape) base).key()).members().size()
                * 2);
    }
}
