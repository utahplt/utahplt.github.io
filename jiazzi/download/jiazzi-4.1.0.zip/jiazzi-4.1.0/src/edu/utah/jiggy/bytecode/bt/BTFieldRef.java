/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.bytecode outbt.FieldRef */

package edu.utah.jiggy.bytecode.bt;

import edu.utah.jiggy.meta.shape.ProcedureShape;
import edu.utah.jiggy.meta.shape.ShapeKey;
import edu.utah.jiggy.meta.type.ClassType;

public class BTFieldRef extends BTMemberRef {
    public BTFieldRef replace(ReplaceBT replace) {
        BTFieldRef ref = (BTFieldRef) this;
        ref = replace.get(ref);
        if (ref != this)
            return ref;
        else
            return (BTFieldRef) super.replace0(replace);
    }

    public BTMemberRef replace0(ReplaceBT replace) {
        return this.replace(replace);
    }

    public BTFieldRef setClass(ClassType clazz) {
        return (BTFieldRef) this.setClass0(clazz);
    }

    public BTFieldRef setMember(ShapeKey member) {
        if (member.procedure() != ProcedureShape.EMPTY)
            throw new Error();
        return (BTFieldRef) this.setMember0(member);
    }

    public BTFieldRef() {
        super();
    }

    public BTFieldRef(ClassType clazz, ShapeKey m) {
        super(clazz, m);
    }
}
