/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.bytecode outbt.MemberRef */

package edu.utah.jiggy.bytecode.bt;

import edu.utah.jiggy.meta.shape.ShapeKey;
import edu.utah.jiggy.meta.type.ClassType;

public abstract class BTMemberRef extends java.lang.Object implements
        java.lang.Cloneable {
    protected ClassType clazz;
    protected ShapeKey member;

    protected BTMemberRef copy0() {
        try {
            return (BTMemberRef) this.clone();
        } catch (Exception e) {
            throw new Error();
        }
    }

    public BTMemberRef replace0(ReplaceBT replace) {
        ClassType ctype = this.clazz();

        BTMemberRef mref = this.setClass0(
            (ClassType) this.clazz().replace(replace)).setMember0(
            this.member().replace(replace, ctype));

        return mref;
    }

    public BTMemberRef setClass0(ClassType clazz) {
        if (this.clazz != null && clazz.equals(this.clazz))
            return (BTMemberRef) this;
        BTMemberRef ref = this.copy0();
        ref.clazz = clazz;
        return ref;
    }

    public BTMemberRef setMember0(ShapeKey member) {
        if (this.member != null && member.equals(this.member))
            return (BTMemberRef) this;
        BTMemberRef ref = this.copy0();
        ref.member = member;
        return ref;
    }

    public String toString() {
        return (this.clazz == null ? "null" : this.clazz.javaSource()) + ":"
            + this.member;
    }

    public int hashCode() {
        int hc = 0;
        if (this.clazz != null)
            hc += this.clazz.hashCode();
        if (this.member != null)
            hc += this.member.hashCode();
        return hc;
    }

    public boolean equals(Object o) {
        if (!(o instanceof BTMemberRef))
            return false;
        BTMemberRef ref = (BTMemberRef) o;
        return ref.clazz.equals(this.clazz) && ref.member.equals(this.member);
    }

    public ClassType clazz() {
        return this.clazz;
    }

    public ShapeKey member() {
        return this.member;
    }

    public BTMemberRef() {
        super();
    }

    public BTMemberRef(ClassType clazz, ShapeKey member) {
        this.clazz = clazz;
        this.member = member;
    }
}
