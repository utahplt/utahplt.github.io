/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.meta outshape.Environment */

package edu.utah.jiggy.meta.type;

import java.util.*;

import edu.utah.jiggy.meta.name.ClassName;
import edu.utah.jiggy.meta.name.PackageName;

public class Environment extends java.lang.Object implements
        java.lang.Cloneable {
    // protected List<type.Root> roots = new ArrayList<type.Root>();
    protected List roots = new ArrayList();

    public Environment addRoot(Root root) {
        try {
            Environment env = (Environment) this.clone();
            env.roots = new ArrayList(this.roots);
            env.roots.add(root);
            return env;
        } catch (CloneNotSupportedException e) {
            throw new Error("" + e);
        }
    }

    public Environment prependRoot(Root root) {
        try {
            Environment env = (Environment) this.clone();
            env.roots = new ArrayList(this.roots);
            env.roots.add(0, root);
            return env;
        } catch (CloneNotSupportedException e) {
            throw new Error("" + e);
        }
    }

    public String toString() {
        return this.roots.toString();

    }

    public ClassType findClass(ClassName name) {
        for (Iterator i = this.roots.iterator(); i.hasNext(); /* i = i */) {
            Root root = (Root) i.next();
            if (!root.containsPackage(name.pkg()))
                continue;
            PackageType pkg = root.findPackage(name.pkg());
            if (!pkg.containsClass(name.nopkg()))
                continue;
            return pkg.findClass(name.nopkg());
        }
        throw new Error("cannot find class " + name + " in " + this);
    }

    public boolean containsPackage(PackageName name) {
        for (Iterator i = this.roots.iterator(); i.hasNext(); /* i = i */) {
            Root root = (Root) i.next();
            if (root.containsPackage(name))
                return true;
        }
        return false;
    }

    public PackageType findPackage(PackageName name) {
        for (Iterator i = this.roots.iterator(); i.hasNext(); /* i = i */) {
            Root root = (Root) i.next();
            if (root.containsPackage(name))
                return root.findPackage(name);
        }
        throw new Error("cannot find package " + name + " in " + this);
    }

    public Environment() {
        super();
    }

    // Below here,
    // From `edu.utah.jiggy.bytecode/outtype/Environment.java'.

    public ClassType findVMClass(String nm) {
        PackageName pname;
        if (nm.indexOf('/') == -1)
            pname = PackageName.ANONYMOUS;
        else
            pname =
                new PackageName(nm.substring(0, nm.lastIndexOf('/'))
                    .replace('/', '.'));
        nm = nm.substring(nm.lastIndexOf('/') + 1, nm.length());
        ClassName cname =
            (new ClassName()).parse(nm.replace('$', '.')).setPackage(pname);
        return this.findClass(cname);
    }

    public GJVariableType findTypeVariable(String name) {
        return new GJVariableType(
            name,
            this.findClass(new ClassName("java.lang.Object")));
    }
}
