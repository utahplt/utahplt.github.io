/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.bytecode.ins outins.Target */

package edu.utah.jiggy.instruction.ins;

import java.io.*;

import java.util.*;

import edu.utah.jiggy.bytecode.bt.BTCode;
import edu.utah.jiggy.meta.type.Environment;

public class Block implements Comparable, Cloneable {
    protected int pc;

    // public Set<ins.Value.Phi> phis = new HashSet<ins.Value.Phi>();
    // protected List<ins.Instruction> instructions =
    // new ArrayList<ins.Instruction>();
    // protected List<bt.Code.ExceptionEntry> exceptions =
    // new ArrayList<bt.Code.ExceptionEntry>();
    public Set phis = new HashSet();
    protected List instructions = new ArrayList();
    protected List exceptions = new ArrayList();

    // public Set<ins.Block> mergedWith =
    // new HashSet<ins.Block>();
    public Set mergedWith = new HashSet();

    // public List<ins.Value> stack;
    // public List<ins.Value> locals;
    public List stack;
    public List locals;

    public Branch branch;
    public Block dominator;
    public Block merge;

    public Block copy() {
        Block copy;
        try {
            copy = (Block) this.clone();
        } catch (Throwable t) {
            throw new Error();
        }
        if ((copy.branch == null) != (this.branch == null))
            throw new Error();
        copy.stack = null;
        copy.locals = null;
        copy.mergedWith.clear();
        copy.exceptions = new ArrayList(this.exceptions);
        copy.instructions = new ArrayList(this.instructions);
        this.phis.clear();
        this.dominator = null;
        this.merge = null;
        return copy;
    }

    public void updateBranch(Map map) {
        if (this.branch != null) {
            Branch nbranch;
            try {
                nbranch = this.branch.updateBranch(map);
            } catch (Error e) {
                System.err.println("bad: " + this.branch);
                throw e;
            }
            if (nbranch == null)
                throw new Error();
            this.branch = nbranch;
        }
        for (int i = 0; i < this.exceptions.size(); i++) {
            this.exceptions.set(i, ((BTCode.ExceptionEntry) this.exceptions
                .get(i)).updateBranch(map));
        }
    }

    public void replace(ReplaceIns replace) {
        for (ListIterator i = this.instructions.listIterator();
             i.hasNext();
             /* i = i */) {
            Instruction s0 = (Instruction) i.next();
            Instruction s1 = s0.replace(replace);
            if (s0 == s1)
                continue;

            if (s1 instanceof Instruction.Multi) {
                Instruction.Multi multi = (Instruction.Multi) s1;
                i.remove();
                for (Iterator k = multi.list.iterator();
                     k.hasNext();
                     /* k = k */)
                    i.add((Instruction) k.next());
            } else
                i.set(s1);
        }
        if (this.branch != null && this.branch.replace(replace) == null)
            throw new Error();
        if (this.branch != null)
            this.branch = (Branch) this.branch.replace(replace);
        for (int i = 0; i < this.exceptions.size(); i++) {
            this.exceptions.set(i,
                ((BTCode.ExceptionEntry)
                        this.exceptions.get(i)).replace(replace));
        }
    }

    public String dfaString() {
        return this.stack + " " + this.locals + " " + this.phis + " "
            + this.mergedWith;
    }

    public void clearDFAState() {
        this.stack = null;
        this.locals = null;
        this.phis.clear();
        this.mergedWith.clear();
    }

    public int compareTo(java.lang.Object o) {
        return this.getPC() - ((Block) o).getPC();
    }

    public Set predecessors() {
        return this.mergedWith;
    }

    public int rank() {
        if (this.dominator == null)
            return 0;
        else
            return this.dominator.rank() + 1;
    }

    public static class DomComparator implements
            java.util.Comparator /* <ins.Block> */ {
        public int compare(Block b0, Block b1) {
            if (b0 == null || b1 == null)
                throw new Error();
            if (b0 == b1)
                return 0;
            Block cdom = commonDominator(b0, b1);
            if (cdom == b0)
                return -1;
            if (cdom == b1)
                return +1;
            while (b0.dominator != cdom)
                b0 = b0.dominator;
            while (b1.dominator != cdom)
                b1 = b1.dominator;
            for (Iterator i = b1.predecessors().iterator();
                 i.hasNext();
                 /* i = i */)
                if (b0.dominates((Block) i.next()))
                    return -1;
            for (Iterator i = b0.predecessors().iterator();
                 i.hasNext();
                 /* i = i */)
                if (b1.dominates((Block) i.next()))
                    return +1;
            return (b0.hashCode() - b1.hashCode());
        }

        public int compare(Object o0, Object o1) {
            return this.compare((Block) o0, (Block) o1);
        }
    }

    public Set phis() {
        return this.phis;
    }

    public void print(Environment env, PrintStream out) {
        out.print(this);
        if (this.dominator() != null)
            out.print(" [" + this.dominator() + "]");
        // if (!this.exceptions.isEmpty()) out.print(" " + this.exceptions);
        out.println();
        if (this.stack != null && !this.stack.isEmpty()) {
            out.print("STACK: ");
            for (Iterator i = this.stack.iterator();
                 i.hasNext();
                 /* i = i */) {
                out.print(((Value) i.next()).valueString());
                if (i.hasNext())
                    out.print(", ");
            }
            out.println();
        }
        if (this.locals != null && !this.locals.isEmpty()) {
            out.print("LOCAL: ");
            int j = 0;
            for (Iterator i = this.locals.iterator();
                 i.hasNext();
                 /* i = i */) {
                out.print(j + "=" + ((Value) i.next()).valueString());
                if (i.hasNext())
                    out.print(", ");
                j++;
            }
            out.println();
        }
        for (Iterator j = this.phis().iterator(); j.hasNext(); /* j = j */)
            out.println("  " + j.next());
        for (Iterator j = this.instructions().iterator();
             j.hasNext();
             /* j = j */) {
            Instruction v = (Instruction) j.next();
            out.print("  ");
            if (false && env != null && v.type(env) != null)
                out.print(v.valueString() + " = ");
            out.print(v);
            if (!v.args().isEmpty())
                out.print("(" + v.argString() + ")");
            out.println();
        }
        if (this.branch() != null) {
            out.print("  " + this.branch());
            if (!this.branch().args().isEmpty())
                out.print("(" + this.branch().argString() + ")");
            out.println();
        }
    }

    public Set sinks() {
        Set set = new HashSet();
        this.sinks(set);
        return set;
    }

    public void sinks(Set sinks) {
        Iterator i = this.branches().iterator();
        if (!i.hasNext())
            sinks.add((Block) this);
        else
            while (i.hasNext()) {
                Block target = (Block) i.next();
                /* backwards branch */
                if (target.dominates((Block) this))
                    continue;
                target.sinks(sinks);
            }
    }

    public Set branches() {
        if (this.branch == null)
            throw new Error();
        /*
         * { ArrayList<ins.Block> l = new ArrayList<ins.Block>();
         * l.add(blocks.get(blocks.indexOf((ins.Block) this) + 1)); return
         * l.iterator(); }
         */
        else if (this.branch instanceof Ret) {
            Value v = (Value) this.branch().args().get(0);
            if (v instanceof Instruction) {
                Block ret = ((JumpStoreReturn) v).ret();
                Set l = new HashSet();
                l.add(ret);
                return l;
            } else if (v instanceof Value.Phi) {
                LinkedList process = new LinkedList();
                HashSet set = new HashSet();
                process.add((Value.Phi) v);
                while (!process.isEmpty()) {
                    Value.Phi p = (Value.Phi) process.remove(0);
                    for (Iterator i = p.args(); i.hasNext(); /* i = i */) {
                        Value v0 = (Value) i.next();
                        if (v0 instanceof Value.Phi)
                            process.add((Value.Phi) v0);
                        else {
                            Block ret = ((JumpStoreReturn) v0).ret();
                            set.add(ret);
                        }
                    }
                }
                if (set.isEmpty())
                    throw new Error();
                return set;
            } else
                throw new Error();
        } else {
            return this.branch.targetSet();
        }
    }

    public List instructions() {
        return this.instructions;
    }

    public Branch branch() {
        return this.branch;
    }

    public void setBranch(Branch branch) {
        this.branch = branch;
    }

    public void setDominator(Block block) {
        this.dominator = block;
    }

    public Block dominator() {
        return this.dominator;
    }

    public static Block commonDominator(Block b0, Block b1) {
        if (b0 == null || b1 == null)
            throw new Error("not should happen!");
        if (b0 == b1)
            return b0;
        if (b0.dominates(b1))
            return b0;
        else if (b1.dominates(b0))
            return b1;
        return commonDominator(b0.dominator, b1.dominator);
    }

    public boolean dominates(Block b) {
        if (this == b)
            return true;
        else if (b.dominator == null)
            return false;
        else
            return this.dominates(b.dominator);
    }

    public boolean reaches(Block b, boolean revbranch) {
        if (b == this)
            return true;
        if (revbranch)
            return false;
        Set bset = this.branches();
        if (bset.size() == 0)
            return false;
        for (Iterator i = bset.iterator(); i.hasNext(); /* i = i */) {
            Block target = (Block) i.next();
            if (target.reaches(b, target.dominates((Block) this)))
                return true;
        }
        return false;
    }

    static int S_DEPTH = 0;

    public boolean postDominates(Block b, boolean allowTerminate) {
        int n = this.postDominates(b, (this.dominates(b) ? (Block) this : b),
            allowTerminate);
        return n == PD_BLOCK_FOUND;
    }

    final static int PD_NOT_FOUND = 0;
    final static int PD_TERMINATE = 1;
    final static int PD_BLOCK_FOUND = 2;

    public int postDominates(Block block, Block highPoint,
                             boolean allowTerminate) {
        if (false) {
            System.err.print("PD: " + this + " " + block + " " + highPoint
                + " " + allowTerminate + " " + this.dominates(block));
            for (Iterator i = block.branches().iterator();
                 i.hasNext();
                 /* i = i */) {
                Block target = (Block) i.next();
                System.err.print(" [" + target + " " + target.dominates(block)
                    + "]");
            }
            System.err.println();
        }
        if (this == block)
            return PD_BLOCK_FOUND;
        Iterator i = block.branches().iterator();
        if (!i.hasNext()) {
            if (allowTerminate)
                return PD_TERMINATE;
            else
                return PD_NOT_FOUND;
        }
        int ret = PD_TERMINATE;
        while (i.hasNext()) {
            Block target = (Block) i.next();
            if (target.dominates(block)) {
                if (highPoint.dominates(target))
                    continue;
                else if (this.dominates(block))
                    return PD_NOT_FOUND;
                else
                    /* this.postDominates(target, target, allowTerminate); */
                    return PD_NOT_FOUND;
            } else {
                int n = this.postDominates(target, highPoint, allowTerminate);
                if (n == PD_NOT_FOUND)
                    return n;
                if (n == PD_BLOCK_FOUND)
                    ret = PD_BLOCK_FOUND;
            }
        }
        return ret;
    }

    public List exceptions() {
        return this.exceptions;
    }

    public String toString() {
        return "L" + this.pc
            + (true ? "" : "[" + (this.hashCode() % 1000) + "]");
    }

    public int getPC() {
        return this.pc;
    }

    public Block(int pc) {
        super();
        this.pc = pc;
    }

    public void setPC(int pc) {
        if (this.pc != pc) {
            // System.err.println(this.pc + " -> " + pc);
            this.pc = pc;
        }
    }

    public int offset(int pc) {
        return this.pc - pc;
    }
}
