/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package edu.utah.jiggy.clazz;

import java.io.DataInputStream;
import java.io.File;
import java.util.*;

import edu.utah.jiggy.bytecode.bt.BTCallGraph;
import edu.utah.jiggy.bytecode.bt.BTMethod;
import edu.utah.jiggy.bytecode.bt.ReplaceBT;
import edu.utah.jiggy.meta.name.ClassName;
import edu.utah.jiggy.meta.name.PackageName;
import edu.utah.jiggy.meta.shape.InitShape;
import edu.utah.jiggy.meta.shape.ShapeKey;
import edu.utah.jiggy.meta.type.ClassType;
import edu.utah.jiggy.meta.type.Environment;
import edu.utah.jiggy.meta.type.PackageType;
import edu.utah.jiggy.meta.type.Root;

public abstract class ModelRoot extends Root {
    protected Environment env;

    public Environment env() {
        return this.env;
    }

    public void setEnvironment(Environment env) {
        this.env = env;
    }

    // protected final Map<name.Package,clazz.Package> packages =
    protected final Map packages = new HashMap() {
        // public PackageModel get(PackageName pkg)
        public Object get(Object obj) {
            PackageName pkg = (PackageName) obj;
            if (this.containsKey(pkg))
                return (PackageModel) super.get(pkg);
            missPackage(pkg);
            if (!this.containsKey(pkg))
                throw new Error(pkg + " was not really added to " + this);
            return (PackageModel) super.get(pkg);
        }
    };

    // protected final Map<name.Package,clazz.Package> READ_packages =
    protected final Map READ_packages = Collections
        .unmodifiableMap(this.packages);

    public ModelRoot() {
        super();
    }

    public Map packages() {
        return this.READ_packages;
    }

    public void missClass(ClassName clazz) {
        throw new Error("cannot find class "
            + clazz
            + " in "
            + this
            + (this.packages().containsKey(clazz.pkg()) ? " "
                + ((PackageModel) this.packages().get(clazz.pkg())).classes()
                    .keySet() : ""));
    }

    public void missPackage(PackageName pkg) {
        throw new Error("cannot find package " + pkg + " in " + this);
    }

    public PackageType findPackage(PackageName pkg) {
        return (PackageType) this.packages().get(pkg);
    }

    public boolean containsPackage(PackageName pkg) {
        return this.packages().containsKey(pkg);
    }

    // Below here,
    // From `edu.utah.jiggy.bytecode/outclazz/Root.java'.

    long modified;

    /* establishes all packages and classes */

    public BTCallGraph callGraph() {
        throw new Error();
    }

    public void replace0(NullModelRoot copy, ReplaceBT replace) {
        for (Iterator i = this.packages().values().iterator();
             i.hasNext();
             /* i = i */) {
            PackageModel opkg = (PackageModel) i.next();
            PackageModel npkg =
                new PackageModel(copy, opkg.name().replace(replace));
            if (opkg.replace(replace) != npkg)
                throw new Error("[" + opkg.replace(replace) + "] vs [" + npkg
                    + "]");
            for (Iterator j = opkg.classes().values().iterator();
                 j.hasNext();
                 /* j = j */) {
                ClassModel ocls = (ClassModel) j.next();
                if (replace.clazz() != null)
                    throw new Error();
                replace.set(ocls.newType());
                ClassName cname = ocls.name().replace(replace).nopkg();
                ClassModel ncls = new ClassModel(npkg, cname);
                if (npkg.classes().get(cname) != ncls)
                    throw new Error("" + npkg.classes().values());
                try {
                    if (!ocls.newType().replace(replace).equals(ncls.newType()))
                        throw new Error();
                } catch (Error e) {
                    System.err.println("ERROR " + ncls + " "
                        + ocls.name().replace(replace).nopkg());
                    throw e;
                }
                replace.set((ClassType) null);
            }
        }
    }

    /* copies over the bodies */
    public void replace1(NullModelRoot copy, ReplaceBT replace) {
        if (this == copy)
            throw new Error("you wenti!");
        for (Iterator i = this.packages().values().iterator();
             i.hasNext();
             /* i = i */) {
            for (Iterator j = ((PackageModel) i.next()).classes().values()
                     .iterator();
                 j.hasNext();
                 /* j = j */) {
                ClassModel ocls = (ClassModel) j.next();
                ClassModel ncls =
                    ((TypeModel) ocls.newType().replace(replace)).clazz();
                TypeModel otype = (TypeModel) ocls.newType();
                if (replace.clazz() != null)
                    throw new Error();
                replace.set(otype);
                TypeModel ntype = (TypeModel) ncls.newType();
                if (ocls == ncls)
                    throw new Error("problem: " + ocls + " " + replace);
                ncls.setShape(ocls.shape().replace(replace));
                ncls.setBody(ocls.body().replace(ocls.shape(), replace));
                if (false) {
                    for (Iterator k = otype.shape().inits().iterator();
                         k.hasNext();
                         /* k = k */) {
                        ShapeKey key0 = (ShapeKey) k.next();
                        ShapeKey key1 = key0.replace(replace, otype);
                        InitShape init0 = otype.shape().actualInit(key0);
                        InitShape init1 = ntype.shape().actualInit(key1);
                        BTMethod binit0 =
                            (BTMethod) ocls.body().methods().get(key0);
                        BTMethod binit1 =
                            (BTMethod) ncls.body().methods().get(key1);
                        if (binit0.orig != binit1.orig)
                            throw new Error(binit0.orig + " " + binit1.orig);
                        if (init0.procedure().args().size() !=
                            init1.procedure().args().size())
                            throw new Error(init0 + " " + init1);
                        System.err.println(otype + " " + key0 + " " + init0
                            + " " + binit0);
                        System.err.println(ntype + " " + key1 + " " + init1
                            + " " + binit1);
                    }
                }
                replace.set((ClassType) null);
            }
        }
    }

    public void setModified(long modified) {
        this.modified = modified;
    }

    public long modified() {
        return this.modified;
    }

    protected PackageName parsePackage(String name, char sep) {
        if (name.indexOf(sep) == -1)
            return new PackageName(name);
        else
            return (new PackageName(
                name.substring(name.lastIndexOf(sep) + 1, name.length())))
                .setOuter(this.parsePackage(
                    name.substring(0, name.lastIndexOf(sep)),
                    sep));
    }

    protected ClassName parseClass(String name) {
        if (name.indexOf('$') == -1)
            return new ClassName(name);
        else
            return (new ClassName(
                name.substring(name.lastIndexOf('$') + 1, name.length())))
                .setOuter(this.parseClass(
                    name.substring(0, name.lastIndexOf('$'))));
    }

    protected DataInputStream readClass(ClassModel cls) {
        throw new Error("abstract");
    }

    public static final Environment CLASSPATH;

    static {
        String cp0 = System.getProperty("sun.boot.class.path", null);
        String cp1 = System.getProperty("java.class.path", null);
        String cp;
        if (cp0 == null)
            cp = cp1;
        else if (cp1 == null)
            cp = cp0;
        else
            cp = cp0 + File.pathSeparator + cp1;
        StringTokenizer st = new StringTokenizer(cp, File.pathSeparator);
        final Set roots = new HashSet();
        while (st.hasMoreTokens()) {
            String path = st.nextToken();
            File f = new File(path);
            if (!f.exists())
                continue;
            roots.add(path.endsWith(".jar") ?
                    (ModelRoot) new JarModelRoot((File) f) :
                        (ModelRoot) new DirModelRoot((File) f));
        }
        {
            Environment env = new Environment() {
                public String toString() {
                    return "CLASSPATH";
                }
            };
            for (Iterator i = roots.iterator(); i.hasNext(); /* i = i */) {
                env = env.addRoot((ModelRoot) i.next());
            }
            CLASSPATH = env;
        }
        for (Iterator i = roots.iterator(); i.hasNext(); /* i = i */)
            ((ModelRoot) i.next()).setEnvironment(CLASSPATH);
        System.err.println("CLASSPATH set to " + roots);
    }
}
