/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.bytecode.ins outins.Increment */

package edu.utah.jiggy.instruction.ins;

import java.io.*;

import edu.utah.jiggy.clazz.ClassModel;
import edu.utah.jiggy.meta.flag.FlagConstants;
import edu.utah.jiggy.meta.shape.ShapeKey;
import edu.utah.jiggy.meta.type.Environment;
import edu.utah.jiggy.meta.type.TypeType;

public class Increment extends Instruction {
    static void activate() {
        (new Increment()).put00();
    }

    protected int index;
    protected int inc;

    public Instruction replace(ReplaceIns replace) {
        Instruction instr = super.replace(replace);
        if (instr != this)
            return instr;
        /* determine if arguments are added */
        int n = replace.mmbr().replace(replace).procedure().stackWidth()
            - replace.mmbr().procedure().stackWidth();
        if (n != 0) {
            if (this.index() >=
                (replace.mmbr().procedure().stackWidth()
                        + (replace.mmbr().isSet(FlagConstants.STATIC) ?
                                0 : 1))) {
                /* n is number of single wide arguments added to method */
                /* move local index up by n places */
                return this.setIndex(this.index() + n);
            }
        }
        return this;
    }

    public int argCount() {
        return 1;
    }

    public void execute(Machine m) {
        Value incremented = m.load(index);
        this.args().add(incremented);
        m.doError(incremented.type(m.context).isa(TypeInfo.INT));
        m.store(index, this);
    }

    public TypeType type(Environment env) {
        return ((Value) this.args().get(0)).type(env);
    }

    public int index() {
        return this.index;
    }

    public int baseHashCode() {
        return super.baseHashCode() + this.index + this.inc;
    }

    public boolean baseEquals(Instruction ins) {
        return super.baseEquals(ins)
            && ((Increment) ins).index == this.index
            && ((Increment) ins).inc == this.inc;
    }

    public String toString() {
        return super.toString() + " " + this.index + " " + this.inc;
    }

    public String mnemonic() {
        return "iinc";
    }

    public Increment setIncrement(int inc) {
        Increment copy = (Increment) this.copy();
        copy.inc = inc;
        return copy;
    }

    public Increment setIndex(int index) {
        Increment copy = (Increment) this.copy();
        copy.index = index;
        return copy;
    }

    public boolean isWide() {
        return this.index > 255 || this.inc < -127 || this.inc > 127;
    }

    public int opcode() {
        return 132;
    }

    public int increment() {
        return this.inc;
    }

    public Increment() {
        super();
    }

    protected int size() {
        if (!this.isWide())
            return 3;
        else
            return 5;
    }

    public Instruction read(int pc, DataInputStream input, ClassModel clazz,
                            ShapeKey mthd) throws IOException {
        Increment copy = (Increment) super.read(pc, input, clazz, mthd);
        return copy.setIndex(
            input.readUnsignedByte()).setIncrement(input.readByte());
    }

    public Instruction readWide(int pc, DataInputStream input,
                                ClassModel clazz, ShapeKey mthd)
            throws IOException {
        Increment copy = (Increment) super.readWide(pc, input, clazz, mthd);
        return copy.setIndex(
            input.readUnsignedShort()).setIncrement(input.readShort());
    }

    public void write(int pc, DataOutputStream out, ClassModel clazz,
                      ShapeKey mthd) throws IOException {
        super.write(pc, out, clazz, mthd);
        out.writeByte(this.index());
        out.writeByte(this.inc);
        return;
    }

    public void writeWide(int pc, DataOutputStream out, ClassModel clazz,
                          ShapeKey mthd) throws IOException {
        super.writeWide(pc, out, clazz, mthd);
        out.writeShort(this.index());
        out.writeShort(this.inc);
        return;
    }
}
