/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package edu.utah.jiggy.clazz;

import java.util.*;

import edu.utah.jiggy.meta.name.ClassName;
import edu.utah.jiggy.meta.name.PackageName;
import edu.utah.jiggy.meta.type.ClassType;
import edu.utah.jiggy.meta.type.PackageType;
import edu.utah.jiggy.meta.type.Root;

public class PackageModel extends PackageType {
    protected final PackageName name;
    protected final ModelRoot root;

    void missClass(ClassName name) {
        this.root().missClass(name.setPackage(this.name()));
    }

    // protected final Map<name.Class,clazz.Class> classes =
    protected final Map classes = new HashMap() {
        // public ClassModel get(ClassName clazz) {
        public Object get(Object obj) {
            ClassName clazz = (ClassName) obj;
            clazz = clazz.nopkg();
            if (this.containsKey(clazz))
                return (ClassModel) super.get(clazz);
            missClass(clazz);
            if (!this.containsKey(clazz))
                throw new Error(clazz + " was not really added to " + this);
            return (ClassModel) super.get(clazz);
        }
    };

    public ClassType findClass(ClassName name) {
        return ((ClassModel) this.classes.get(name.nopkg())).newType();
    }

    public boolean containsClass(ClassName name) {
        return this.classes.containsKey(name.nopkg());
    }

    // protected final Map<name.Class,clazz.Class> READ_classes =
    protected final Map READ_classes = Collections
        .unmodifiableMap(this.classes);

    public String toString() {
        return this.root.toString() + ":" + this.name().toString();
    }

    public PackageModel(ModelRoot root, PackageName name) {
        this.name = name;
        this.root = root;
        if (((ModelRoot) root).packages.put(name, (PackageModel) this) != null)
            throw new Error("package " + name + " already exists in " + root);
    }

    public void detach() {
        if (this.root().packages.remove(this.name) != this)
            throw new Error();
    }

    public Map classes() {
        return this.READ_classes;
    }

    public PackageName name() {
        return this.name;
    }

    public ModelRoot root() {
        return this.root;
    }

    public Root root0() {
        return this.root();
    }

    // Below here,
    // From `edu.utah.jiggy.bytecode/outclazz/Package.java'.

    public String internalName() {
        return this.name().javaSource().replace('.', '/');
    }
}
