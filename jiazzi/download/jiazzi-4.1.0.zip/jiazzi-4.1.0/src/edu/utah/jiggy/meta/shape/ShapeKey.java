/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.core outshape.ShapeKey */

package edu.utah.jiggy.meta.shape;

import edu.utah.jiggy.meta.name.MemberName;
import edu.utah.jiggy.meta.type.ClassType;
import edu.utah.jiggy.meta.type.Environment;
import edu.utah.jiggy.meta.type.TypeConstants;
import edu.utah.jiggy.meta.type.TypeType;

public class ShapeKey extends Object implements Cloneable {
    protected NameTypeShape nameType = NameTypeShape.EMPTY;
    protected ProcedureShape procedure = ProcedureShape.EMPTY;

    public String toString() {
        return (this.nameType == NameTypeShape.EMPTY ? ""
                : this.nameType.toString())
            + (this.procedure == ProcedureShape.EMPTY ? ""
                    : this.procedure.toString());
    }

    public ShapeKey copy() {
        try {
            return (ShapeKey) this.clone();
        } catch (Throwable t) {
            throw new Error("" + t);
        }
    }

    public NameTypeShape nameType() {
        return this.nameType;
    }

    public ProcedureShape procedure() {
        return this.procedure;
    }

    public ShapeKey set(NameTypeShape nt) {
        if (nt == null)
            throw new Error();
        ShapeKey key = (ShapeKey) this.copy();
        key.nameType = nt;
        return key;
    }

    public ShapeKey set(ProcedureShape p) {
        if (p == null)
            throw new Error();
        ShapeKey key = (ShapeKey) this.copy();
        key.procedure = p;
        return key;
    }

    public int hashCode() {
        int hc = 0;
        if (this.nameType != NameTypeShape.EMPTY) {
            if (this.nameType == null)
                throw new Error();
            if (this.nameType.name == null)
                throw new Error("" + this.nameType.type);
            if (this.nameType.type == null)
                throw new Error("" + this.nameType.name);
            hc = hc
                + (this.nameType.name.hashCode()
                        + this.nameType.type.hashCode());
        }
        if (this.procedure != ProcedureShape.EMPTY)
            hc = hc + (this.procedure.args.hashCode());
        return hc;
    }

    public boolean equals(Object e) {
        if (e == null)
            throw new Error();
        ShapeKey key = (ShapeKey) e;
        if (!key.nameType.matches(this.nameType))
            return false;
        if (!key.procedure.matches(this.procedure))
            return false;
        return true;
    }

    public ShapeKey replace(ReplaceShape replace) {
        return this.replace(replace, replace.clazz());
    }

    public ShapeKey replace(ReplaceShape replace, ClassType ctype) {
        ShapeKey key = replace.get((ShapeKey) this, ctype);
        if (key == this) {
            ProcedureShape p =
                (ProcedureShape) this.procedure().replace(replace);
            NameTypeShape nt = (NameTypeShape) this.nameType().replace(replace);
            if (nt != NameTypeShape.EMPTY) {
                if (nt == null)
                    throw new Error();
                if (ctype == null)
                    throw new Error("ctype is null");
                if (nt.name() == null)
                    throw new Error(nt + " not well formed!");
                if (ctype.name() == null)
                    throw new Error(ctype + " not well formed!");
                MemberName m =
                    (MemberName) nt.name().replace(ctype.name(), replace);
                if (m != nt.name())
                    nt = nt.setName(m); /* don't forget to translate name! */
            }
            if (p != key.procedure())
                key = key.set(p);
            if (nt != key.nameType())
                key = key.set(nt);
        }
        // if (key.procedure().args().size() != this.procedure().args().size())
        // throw new Error(key + " " + this);
        return key;
    }

    // Below here,
    // From `edu.utah.jiggy.bytecode/outshapr/Key.java'.

    public String jvmNameString() {
        if (this.nameType() == NameTypeShape.EMPTY)
            return "<init>";
        else
            return this.nameType().name().javaSource();
    }

    public String jvmTypeString() {
        if (this.procedure() == ProcedureShape.EMPTY)
            return this.nameType().type().jvmTypeString();
        else
            return this.procedure().jvmTypeString()
                + (this.nameType() == NameTypeShape.EMPTY ?
                        TypeConstants.VOID.jvmTypeString() :
                            this.nameType().type().jvmTypeString());
    }

    public ShapeKey parseJvmType(String str, Environment env) {
        if (str.charAt(0) == '(' && str.charAt(1) != ')')
            return (ShapeKey) TypeType.parseJvmType(
                str.substring(1, str.length()),
                env,
                new TypeType.Rest() {
                ShapeKey key = (ShapeKey) ShapeKey.this;

                public Object doit(TypeType type, String string,
                                   Environment env) {
                    this.key = this.key.set(this.key.procedure().addArg(type));
                    if (string.charAt(0) == ')') {
                        this.key =
                            this.key.set(
                                this.key.nameType().setType(
                                    TypeType.parseJvmType(
                                        string.substring(1, string.length()),
                                        env)));
                        return this.key;
                    } else
                        return TypeType.parseJvmType(string, env, this);
                }
            });
        else if (str.charAt(0) == '(' && str.charAt(1) == ')')
            return this.set(
                this.nameType().setType(
                    TypeType.parseJvmType(
                        str.substring(2, str.length()),
                        env)))
                        .set(new ProcedureShape());
        else
            return this.set(
                this.nameType().setType(TypeType.parseJvmType(str, env)))
                .set(ProcedureShape.EMPTY);
    }
}
