/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.bytecode outbt.Attr */

package edu.utah.jiggy.bytecode.bt;

import java.io.*;
import java.util.*;

import edu.utah.jiggy.clazz.ClassModel;
import edu.utah.jiggy.meta.shape.Base;
import edu.utah.jiggy.meta.shape.ClassShape;
import edu.utah.jiggy.meta.shape.MemberShape;
import edu.utah.jiggy.meta.shape.ShapeKey;

public abstract class BTAttr extends Object implements Cloneable {
    // private static final Set<bt.Attr> derived = new HashSet<bt.Attr>();
    // private static final Map<String,bt.Attr> map = new
    // HashMap<String,bt.Attr>();
    private static final Set derived = new HashSet();
    private static final Map map = new HashMap();

    public void dump(PrintStream out) {
        out.println(this);
    }

    public static BTAttr find(String name) {
        if (map.containsKey(name))
            return (BTAttr) map.get(name);
        return new BTUnknown(name);
    }

    public static Iterator derived() {
        return Collections.unmodifiableSet(derived).iterator();
    }

    protected BTAttr() {
    }

    protected void register() {
        if (this.isDerived())
            derived.add((BTAttr) this);
        map.put(this.name(), (BTAttr) this);
    }

    public boolean isDerived() {
        return false;
    }

    protected boolean isClass() {
        return true;
    }

    protected boolean isMember() {
        return true;
    }

    public abstract String name();

    public BTAttr replace(ReplaceBT replace) {
        if (this.isDerived())
            throw new Error(this + " should be generated, not replace");
        return (BTAttr) this;
    }

    public int hashCode() {
        return this.name().hashCode();
    }

    public boolean equals(Object o) {
        return ((BTAttr) o).name().equals(this.name());
    }

    public String toString() {
        return this.name();
    }

    public BTAttr copy() {
        // if (this.isDerived()) return (bt.Attr) this;
        try {
            return (BTAttr) this.clone();
        } catch (Exception e) {
            throw new Error(e + "");
        }
    }

    protected int size(ClassModel clazz, Base base) {
        return 0;
    }

    protected BTAttr read(int size, DataInputStream in, ClassModel clazz,
                          BTBase base, Base shape) throws IOException {
        return (BTAttr) this.copy();
    }

    int prep = -1;

    protected boolean prepareWrite(ClassModel clazz, Base base) {
        int index = clazz.body().pool().allocUtf8(this.name());
        if (index == 0)
            throw new Error(this.name() + " @ 0?");
        this.prep = index;
        return true;
    }

    protected void write(DataOutputStream out, ClassModel clazz, Base base)
            throws IOException {
        int sz = clazz.body().pool().size();
        int index = clazz.body().pool().allocUtf8(this.name());
        if (index >= sz)
            throw new Error("wtf??? " + index + " " + sz + " " + this.prep);
        if (false && index == (clazz.body().pool().size() - 1))
            System.err.println(this + " " + clazz.newType().javaSource() + " "
                + clazz.body().pool().size());
        out.writeShort(index);
        out.writeInt(this.size(clazz, base));
    }

    public BTAttr readClass(int size, DataInputStream in, ClassModel clazz,
                            ClassShape shape) throws IOException {
        if (!this.isClass())
            throw new BTClassFormatError("attribute " + this
                + " does not belong in class", clazz);
        return this.read(size, in, clazz, clazz.body(), shape);
    }

    public boolean prepareWriteClass(ClassModel clazz) {
        if (!this.isClass())
            return false;
        return this.prepareWrite(clazz, clazz.shape());
    }

    public void writeClass(DataOutputStream out, ClassModel clazz)
            throws IOException {
        if (!this.isClass())
            throw new Error();
        this.write(out, clazz, clazz.shape());
    }

    public BTAttr readMember(int size, DataInputStream in, ClassModel clazz,
                             BTMember mmbr, MemberShape shape)
            throws IOException {
        if (!this.isMember())
            throw new BTClassFormatError("attribute " + this
                + " does not belong in member", clazz);
        return this.read(size, in, clazz, mmbr, shape);
    }

    public boolean prepareWriteMember(ClassModel clazz, ShapeKey mmbr) {
        if (!this.isMember())
            return false;
        return this.prepareWrite(clazz, clazz.newType().shape().actual(mmbr));
    }

    public void writeMember(DataOutputStream out, ClassModel clazz,
                            ShapeKey mmbr) throws IOException {
        if (!this.isMember())
            throw new Error();
        this.write(out, clazz, clazz.newType().shape().actual(mmbr));
    }

    public static final BTConstantValue CONSTANT_VALUE = new BTConstantValue();
    public static final BTCode CODE = new BTCode();
    public static final BTExceptions EXCEPTIONS = new BTExceptions();
    public static final BTInnerClasses INNER_CLASSES = new BTInnerClasses();
    public static final BTSynthetic SYNTHETIC = new BTSynthetic();
    public static final BTSourceFile SOURCE_FILE = new BTSourceFile();
    public static final BTLineNumberTable LINE_NUMBER_TABLE =
        new BTLineNumberTable();
    public static final BTLocalVariableTable LOCAL_VARIABLE_TABLE =
        new BTLocalVariableTable();
    public static final BTDeprecated DEPRECATED = new BTDeprecated();
    // public static final BTSignature SIGNATURE = new BTSignature();

    static {
        CONSTANT_VALUE.register();
        CODE.register();
        EXCEPTIONS.register();
        INNER_CLASSES.register();
        SYNTHETIC.register();
        SOURCE_FILE.register();
        LINE_NUMBER_TABLE.register();
        // LOCAL_VARIABLE_TABLE.register();
        DEPRECATED.register();
        // SIGNATURE.register();
    }

    // Below here,
    // From `edu.utah.jiggy.instruction/outbt/Attr.java'.

    public void setBlocks(BTCode code) {
        return;
    }

    public BTAttr updateBranch(Map map) {
        return (BTAttr) this;
    }
}
