/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package edu.utah.jiggy.meta.shape;

import edu.utah.jiggy.meta.flag.AccessFlag;
import edu.utah.jiggy.meta.flag.BinaryFlag;
import edu.utah.jiggy.meta.flag.FlagConstants;
import edu.utah.jiggy.meta.flag.VirtualFlag;

public interface ShapeSelector {
    public abstract boolean accept(MemberShape m);

    public static final ShapeSelector ACCEPT_ALL = new ShapeSelector() {
        public boolean accept(MemberShape m) {
            return true;
        }
    };

    public static final ShapeSelector PROTECTED_INSTANCE =
        new ShapeSelector.And(
            new ShapeSelector.Access(FlagConstants.PROTECTED),
            new ShapeSelector.NegBinary(FlagConstants.STATIC));
    public static final ShapeSelector PACKAGE_INSTANCE =
        new ShapeSelector.And(
            new ShapeSelector.Access(FlagConstants.PACKAGE),
            new ShapeSelector.NegBinary(FlagConstants.STATIC));

    public static final ShapeSelector PROTECTED =
        new ShapeSelector.Access(FlagConstants.PROTECTED);
    public static final ShapeSelector PACKAGE =
        new ShapeSelector.Access(FlagConstants.PACKAGE);
    public static final ShapeSelector CONCRETE =
        new ShapeSelector.Virtual(FlagConstants.CONCRETE);

    public static class And extends java.lang.Object implements ShapeSelector {
        final ShapeSelector s0;
        final ShapeSelector s1;

        public And(ShapeSelector s0, ShapeSelector s1) {
            this.s0 = s0;
            this.s1 = s1;
        }

        public boolean accept(MemberShape m) {
            return this.s0.accept(m) && this.s1.accept(m);
        }
    }

    public static class Access extends java.lang.Object implements
            ShapeSelector {
        final AccessFlag acc;

        public Access(AccessFlag acc) {
            this.acc = acc;
        }

        public boolean accept(MemberShape m) {
            return m.access().isa(this.acc);
        }
    }

    public static class Virtual extends java.lang.Object implements
            ShapeSelector {
        final VirtualFlag virt;

        public Virtual(VirtualFlag virt) {
            this.virt = virt;
        }

        public boolean accept(MemberShape m) {
            return m.virtual().isa(this.virt);
        }
    }

    public static class Binary extends java.lang.Object implements
            ShapeSelector {
        final BinaryFlag bin;

        public Binary(BinaryFlag bin) {
            this.bin = bin;
        }

        public boolean accept(MemberShape m) {
            return m.isSet(this.bin);
        }
    }

    public static class NegBinary extends java.lang.Object implements
            ShapeSelector {
        final BinaryFlag bin;

        public NegBinary(BinaryFlag bin) {
            this.bin = bin;
        }

        public boolean accept(MemberShape m) {
            return !m.isSet(this.bin);
        }
    }
}
