/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package edu.utah.jiggy.meta.flag;

import java.util.*;

public interface FlagConstants {

    public static final Set PACKAGEMEMBER_FLAGS0 = new HashSet();
    public static final Set CLASSMEMBER_FLAGS0 = new HashSet();
    public static final Set CLASS_FLAGS0 = new HashSet();
    public static final Set FIELD_FLAGS0 = new HashSet();
    public static final Set METHOD_FLAGS0 = new HashSet();
    public static final Set INIT_FLAGS0 = new HashSet();

    public static final Set PACKAGEMEMBER_FLAGS =
        Collections.unmodifiableSet(PACKAGEMEMBER_FLAGS0);
    public static final Set CLASSMEMBER_FLAGS =
        Collections.unmodifiableSet(CLASSMEMBER_FLAGS0);
    public static final Set CLASS_FLAGS =
        Collections.unmodifiableSet(CLASS_FLAGS0);
    public static final Set FIELD_FLAGS =
        Collections.unmodifiableSet(FIELD_FLAGS0);
    public static final Set METHOD_FLAGS =
        Collections.unmodifiableSet(METHOD_FLAGS0);
    public static final Set INIT_FLAGS =
        Collections.unmodifiableSet(INIT_FLAGS0);

    // protected
    // public
    public static final PrivateFlag PRIVATE = new PrivateFlag();
    public static final PackageFlag PACKAGE = new PackageFlag();
    public static final ProtectedFlag PROTECTED = new ProtectedFlag();
    public static final PublicFlag PUBLIC = new PublicFlag();

    public static final AbstractFlag ABSTRACT = new AbstractFlag();
    public static final ConcreteFlag CONCRETE = new ConcreteFlag();
    public static final FinalFlag FINAL = new FinalFlag();

    public static final StaticFlag STATIC = new StaticFlag();
    public static final InterfaceFlag INTERFACE = new InterfaceFlag();
    public static final ImmutableFlag IMMUTABLE = new ImmutableFlag();

    /*
     * public static final flag.Flags INTERFACE_METHOD_FLAGS = (new
     * flag.Flags()).set(PUBLIC).set(ABSTRACT).set(INSTANCE).set(NATURAL);
     * public static final flag.Flags INTERFACE_FIELD_FLAGS = (new
     * flag.Flags()).set(PUBLIC).set(FINAL).set(STATIC).set(NATURAL); public
     * static final flag.Flags CLASS_DEFAULT = (new
     * flag.Flags()).set(DEFAULT).set(CONCRETE).set(INSTANCE).set(REALCLASS);
     * 
     * static { if (FINAL.parent() != CONCRETE) throw new Error(); if
     * (PUBLIC.parent() != PROTECTED) throw new Error(); }
     */

    // Below here,
    // From `edu.utah.jiggy.bytecode/outflag/Constants.java'.
    public final static StrictFlag STRICT = new StrictFlag();
    public final static SynchronizedFlag SYNCHRONIZED = new SynchronizedFlag();
    public final static NativeFlag NATIVE = new NativeFlag();
    public final static SyntheticFlag SYNTHETIC = new SyntheticFlag();
    public final static DeprecatedFlag DEPRECATED = new DeprecatedFlag();
    public final static VolatileFlag VOLATILE = new VolatileFlag();
    public final static TransientFlag TRANSIENT = new TransientFlag();
}
