/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.bytecode.ins outins.Throw */

package edu.utah.jiggy.instruction.ins;

import java.util.*;

import edu.utah.jiggy.meta.name.ClassName;
import edu.utah.jiggy.meta.name.PackageName;
import edu.utah.jiggy.meta.type.TypeType;

public class Throw extends Branch {

    // private static final Iterator<ins.Block> ZERO = (new
    // HashSet<ins.Block>()).iterator();
    private static final Iterator ZERO = (new HashSet()).iterator();

    public java.util.Iterator targets() {
        return ZERO;
    }

    static void activate() {
        (new Throw()).put00();
    }

    public int argCount() {
        return 1;
    }

    public void execute(Machine m) {
        Value thrown = m.pop();
        this.args().add(thrown);
        TypeType eType = m.context.findPackage(new PackageName("java.lang"))
            .findClass(new ClassName("Throwable"));
        m.doError(thrown.type(m.context).isa(eType), "");
    }

    public java.lang.String mnemonic() {
        return "athrow";
    }

    public int opcode() {
        return 191;
    }

    public Throw() {
        super();
    }

    protected int size() {
        return 1;
    }
}
