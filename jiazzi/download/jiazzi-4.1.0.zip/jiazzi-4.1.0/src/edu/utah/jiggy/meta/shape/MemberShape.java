/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.core outshape.MemberName */

package edu.utah.jiggy.meta.shape;

import edu.utah.jiggy.meta.flag.FlagConstants;
import edu.utah.jiggy.meta.type.ClassType;

public abstract class MemberShape extends Base {
    public MemberShape() {
        super();
    }

    public MemberShape replace(ReplaceShape replace) {
        return this.replace(replace, replace.clazz());
    }

    public ShapeKey replaceKey(ReplaceShape replace, ClassType ctype) {
        return (ShapeKey) this.key().replace(replace, ctype);
    }

    public MemberShape replace(ReplaceShape replace, ClassType ctype) {
        if (replace.clazz() == null)
            throw new Error();
        ShapeKey key = this.replaceKey(replace, ctype);
        ThrowzShape t = (ThrowzShape) this.throwz().replace(replace);
        if (key.nameType() != this.nameType()
            || key.procedure() != this.procedure()
            || t != this.throwz()) {
            MemberShape copy = (MemberShape) this.copy();
            if (key.nameType() != this.nameType())
                copy.set(key.nameType());
            if (key.procedure() != this.procedure())
                copy.set(key.procedure());
            if (t != this.throwz())
                copy.set(t);
            return copy;
        } else
            return (MemberShape) this;
    }

    public NameTypeShape nameType() {
        return NameTypeShape.EMPTY;
    }

    public ProcedureShape procedure() {
        return ProcedureShape.EMPTY;
    }

    public ThrowzShape throwz() {
        return ThrowzShape.EMPTY;
    }

    public String toString() {
        return this.javaSource("<init>");
    }

    public String javaSource(String cname) {
        return this.javaSource0();
    }

    public ShapeKey key() {
        ShapeKey key = new ShapeKey();
        key.procedure = this.procedure();
        key.nameType = this.nameType();
        return key;
    }

    public void set(NameTypeShape s) {
        if (s == NameTypeShape.EMPTY)
            return;
        throw new Error(s + " not supported in " + this.getClass());
    }

    public void set(ProcedureShape s) {
        if (s == ProcedureShape.EMPTY)
            return;
        throw new Error(s + " not supported in " + this.getClass());
    }

    public void set(ThrowzShape s) {
        if (s == ThrowzShape.EMPTY)
            return;
        throw new Error(s + " not supported in " + this.getClass());
    }

    public boolean matches(MemberShape m) {
        if (!super.matches(m))
            return false;
        if (!this.nameType().matches(m.nameType()))
            return false;
        if (!this.procedure().matches(m.procedure()))
            return false;
        if (!this.throwz().matches(m.throwz()))
            return false;
        if (!this.virtual().isa(m.virtual())) {
            if (this.virtual() == FlagConstants.ABSTRACT
                && m.virtual() == FlagConstants.CONCRETE)
                return true;
            else
                return false;
        }
        return true;
    }

    // Below here,
    // From `edu.utah.jiggy.bytecode/outshape/Member.java'.

    public String jvmNameString() {
        return this.nameType().name().javaSource();
    }

    public String jvmTypeString() {
        return this.nameType().type().jvmTypeString();
    }

    // Below here,
    // From `edu.utah.jiggy.instruction/outshape/Member.java'.

    public int stackWidth() {
        int c = this.procedure().stackWidth();
        if (this.isSet(FlagConstants.STATIC))
            return c;
        return c + 1;
    }
}
