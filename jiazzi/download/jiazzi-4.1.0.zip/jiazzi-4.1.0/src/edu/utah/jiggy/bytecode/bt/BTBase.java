/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.bytecode outbt.BTBase */

package edu.utah.jiggy.bytecode.bt;

import java.util.*;
import java.io.*;

import edu.utah.jiggy.clazz.TypeModel;
import edu.utah.jiggy.meta.shape.Base;
import edu.utah.jiggy.meta.shape.ReplaceShape;
import edu.utah.jiggy.meta.type.GJVariableType;
import edu.utah.jiggy.meta.type.TypeType;

public abstract class BTBase extends Object implements Cloneable {
    // protected Map<bt.Attr,bt.Attr> attributes = new
    // HashMap<bt.Attr,bt.Attr>();
    // protected List<type.GJVariable> generics =
    // new ArrayList<type.GJVariable>();
    protected Map attributes = new HashMap();
    protected List generics = new ArrayList();

    public void dump(PrintStream out) {
        out.println("ATTRIBUTES");
        for (Iterator i = this.attributes.values().iterator();
             i.hasNext();
             /* i = i */)
            ((BTAttr) i.next()).dump(out);
    }

    public void gjReplace(TypeModel ctype, Base base, ReplaceShape replace) {
        for (Iterator i = this.generics().iterator();
             i.hasNext();
             /* i = i */) {
            GJVariableType gj = (GJVariableType) i.next();
            replace.map(gj.name(), gj);
        }
    }

    public BTBase copy() {
        try {
            BTBase copy = (BTBase) this.clone();
            copy.attributes = new HashMap(this.attributes);
            copy.generics = new ArrayList();
            return copy;
        } catch (Exception e) {
            throw new Error("" + e);
        }
    }

    public BTBase replace0(ReplaceBT replace) {
        BTBase copy = this.copy();
        Set toAdd = new HashSet();
        for (Iterator i = copy.attributes.values().iterator();
             i.hasNext();
             /* i = i */) {
            BTAttr attr0 = (BTAttr) i.next();
            BTAttr attr1 = attr0.replace(replace);
            if (attr0 == attr1)
                continue;
            i.remove();
            toAdd.add(attr1);
        }
        for (Iterator i = toAdd.iterator(); i.hasNext(); /* i = i */) {
            BTAttr attr = (BTAttr) i.next();
            if (copy.attributes().put(attr, attr) != null)
                throw new Error();
        }
        for (Iterator i = this.generics.iterator(); i.hasNext(); /* i = i */) {
            GJVariableType gjv = (GJVariableType) i.next();
            TypeType tp = gjv.replace(replace);
            if (!(tp instanceof GJVariableType))
                throw new Error("wtf! Why is " + gjv + " mapped to " + tp
                    + "? " + replace);
            copy.generics.add((GJVariableType) tp);
        }
        return copy;
    }

    public Map attributes() {
        return this.attributes;
    }

    public List generics() {
        return this.generics;
    }

    protected BTBase() {
        super();
    }
}
