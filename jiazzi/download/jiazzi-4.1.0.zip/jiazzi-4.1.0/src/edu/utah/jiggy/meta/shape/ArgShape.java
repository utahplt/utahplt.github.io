/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.core outshape.ArgShape */

package edu.utah.jiggy.meta.shape;

import edu.utah.jiggy.meta.type.ReplaceType;
import edu.utah.jiggy.meta.type.TypeType;

public class ArgShape extends ShapeElement {
    protected TypeType type;
    protected String name;

    public int hashCode() {
        return this.type.hashCode();
    }

    public boolean matches(ShapeElement m) {
        ArgShape arg = (ArgShape) m;
        if (!this.type.equals(arg.type))
            return false;
        else
            return true;
    }

    public boolean equals(Object o) {
        return this.matches((ArgShape) o);
    }

    public String toString() {
        return this.name + " : " + this.type;
    }

    public ArgShape setType(TypeType type) {
        if (type == null)
            throw new Error("cannot set a null type!");
        ArgShape arg = (ArgShape) this.copy();
        arg.type = type;
        return arg;
    }

    public ShapeElement replace(ReplaceType replace) {
        ArgShape arg = (ArgShape) super.replace(replace);

        TypeType type = arg.type.replace(replace);
        if (type == null)
            throw new Error("replace for " + arg.type + " is null for "
                + replace);
        if (type != arg.type)
            return arg.setType(type);
        else
            return arg;
    }

    public TypeType type() {
        return this.type;
    }

    public String javaSource() {
        return this.type.javaSource() + " " + this.name;
    }

    public ArgShape setName(java.lang.String name) {
        ArgShape arg = (ArgShape) this.copy();
        arg.name = name;
        return arg;
    }

    public java.lang.String name() {
        return this.name;
    }

    public ArgShape() {
        super();
    }
}
