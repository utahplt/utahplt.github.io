/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package edu.utah.jiggy.meta.type;

public class GJVariableType extends RefType {
    protected final String name;
    protected final ClassType bound;

    public GJVariableType(java.lang.String name, ClassType bound) {
        super();
        this.name = name;
        this.bound = bound;
    }

    public String name() {
        return this.name;
    }

    public ClassType bound() {
        return this.bound;
    }

    public String toString() {
        return this.name + "::" + this.bound;
    }

    public String javaSource() {
        return this.name();
    }

    public int hashCode() {
        return this.bound.hashCode();
    }

    public boolean equals(TypeType tp) {
        if (tp == this)
            return true;
        else if (tp instanceof GJVariableType) {
            if (this.name.equals(((GJVariableType) tp).name)
                && this.bound.equals(((GJVariableType) tp).bound))
                return true;
            else
                return false;
        } else
            return this.bound().equals(tp);
    }

    public boolean reverseEquals(TypeType tp) {
        return this.equals(tp);
    }

    public boolean isa(TypeType tp) {
        throw new Error("not ok to use isa here!");
    }

    public TypeType replaceAux(ReplaceType replace) {
        {
            TypeType type = super.replace(replace);
            if (type != this && type instanceof GJVariableType)
                return type;
        }
        ClassType bound = (ClassType) this.bound.replace(replace);
        if (this.bound != bound) {
            return new GJVariableType(this.name, bound);
        } else
            return this;
    }

    // Below here,
    // From `edu.utah.jiggy.bytecode/outtype/GJVariable.java'.

    public String jvmTypeString() {
        return this.bound().jvmTypeString();
    }

    public String gjTypeString() {
        return 'T' + this.name() + ';';
    }

    public TypeType replace(ReplaceType replace) {
        GJVariableType ret = (GJVariableType) replace.get(this.name());
        if (ret != null)
            return ret;
        else
            return this.replaceAux(replace);
    }
}
