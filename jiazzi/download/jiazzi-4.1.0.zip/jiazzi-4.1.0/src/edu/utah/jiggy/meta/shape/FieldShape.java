/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.core outshape.IsField */

package edu.utah.jiggy.meta.shape;

import java.util.*;

import edu.utah.jiggy.meta.flag.FlagConstants;
import edu.utah.jiggy.meta.flag.VirtualFlag;

public class FieldShape extends MemberShape {
    protected NameTypeShape nameType;
    protected Object constant;

    public Object constant() {
        return this.constant;
    }

    public void setConstant(Object constant) {
        this.constant = constant;
    }

    public FieldShape() {
        super();
    }

    public void set(NameTypeShape nameType) {
        this.nameType = nameType;
    }

    public void set(VirtualFlag virt) {
        if (virt == FlagConstants.FINAL)
            this.set(FlagConstants.IMMUTABLE);
        else
            super.set(virt);
    }

    protected Set supported() {
        return FlagConstants.FIELD_FLAGS;
    }

    public String toString() {
        return super.toString() + " " + " " + this.nameType
            + (this.constant() == null ? "" : " = " + this.constant());
    }

    public String javaSource(String cname) {
        return super.javaSource(cname) + this.nameType.javaSource()
            + (this.constant() == null ? "" : " = " + this.constant());
    }

    public NameTypeShape nameType() {
        return this.nameType;
    }

    public boolean matches(MemberShape m) {
        if (!super.matches(m))
            return false;
        if (((FieldShape) m).constant() != null) {
            if (this.constant() == null)
                return false;
            if (!this.constant().equals(((FieldShape) m).constant()))
                return false;
        }
        return true;
    }
}
