/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.core outname.Name */
// package outname;

package edu.utah.jiggy.meta.name;

public abstract class Name extends java.lang.Object implements
        java.lang.Cloneable {
    protected String begin = "";
    protected String end = "";
    protected VariableName var = VariableName.NULL;

    public Name() {
        super();
    }

    void validate(String name) {
        if ((name.indexOf('.') != -1)
            || (name.indexOf('[') != -1)
            || (name.indexOf(']') != -1))
            throw new Error(name + " invalid " + name);
    }

    public Name(String name) {
        this.validate(name);
        this.begin = name;
    }

    public VariableName var() {
        return this.var;
    }

    public String begin() {
        return this.begin;
    }

    public String end() {
        return this.end;
    }

    public int hashCode() {
        return this.javaSource0().hashCode();
    }

    public Name setVariable(VariableName var) {
        if (var == this.var)
            return (Name) this;
        Name copy = this.copy();
        copy.var = var;
        return copy;
    }

    public Name setName(String name) {
        this.validate(name);
        if (name == this.begin
            && this.end == ""
            && this.var == VariableName.NULL)
            return (Name) this;
        if (name.indexOf('.') != -1)
            throw new Error(name + " invalid");
        Name copy = this.copy();
        copy.begin = name;
        copy.var = VariableName.NULL;
        copy.end = "";
        return copy;
    }

    public boolean equals(Object o) {
        if (o == this)
            return true;
        else
            return this.javaSource0().equals(((Name) o).javaSource0());
    }

    protected Name copy() {
        try {
            return (Name) super.clone();
        } catch (Exception e) {
            e.printStackTrace();
            throw new Error("could not clone " + this);
        }
    }

    public Name setBegin(String name) {
        this.validate(name);
        if (this.begin.equals(name))
            return (Name) this;
        Name copy = this.copy();
        copy.begin = name;
        return copy;
    }

    public Name setEnd(String name) {
        this.validate(name);
        if (this.end.equals(name))
            return (Name) this;
        Name copy = this.copy();
        copy.end = name;
        return copy;
    }

    public Name setExpanded(ExpandedName exp) {
        if (exp.var == this.var
            && exp.prepend.length() == 0
            && exp.append.length() == 0)
            return (Name) this;
        else
            return this.setVariable(exp.var)
                .setBegin(this.begin + exp.prepend)
                .setEnd(this.end + exp.append);
    }

    protected Name replace0(ReplaceName replace) {
        return this.setExpanded(replace.get(this.var));
    }

    protected String javaSource0() {
        return this.begin + this.var.text() + this.end;
    }
}
