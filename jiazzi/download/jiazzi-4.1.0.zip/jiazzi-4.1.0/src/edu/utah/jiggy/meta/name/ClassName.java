/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

//
// atom-edu.utah.jiggy.core outClass

package edu.utah.jiggy.meta.name;

public class ClassName extends Name {
    protected PackageName pkg;
    protected ClassName outer;

    public ClassName() {
        super();
    }

    public ClassName(String name) {
        super(name.indexOf('.') != -1 ? name.substring(
            name.lastIndexOf('.') + 1, name.length()) : name);
        if (name.indexOf('.') != -1)
            this.pkg =
                new PackageName(name.substring(0, name.lastIndexOf('.')));
    }

    public ClassName setBase(String name) {
        return (ClassName) this.setName(name);
    }

    public ClassName parse(String name) {
        if (name.indexOf('.') != -1) {
            ClassName outer =
                new ClassName(name.substring(0, name.indexOf('.')));
            if (this.pkg != null)
                outer = outer.setPackage(this.pkg);
            if (this.outer != null)
                outer = outer.setOuter(this.outer);
            return this.setOuter(outer).parse(
                name.substring(name.indexOf('.') + 1, name.length()));
        } else {
            return this.setBase(name);
        }
    }

    public ClassName setPackage(PackageName pkg) {
        if (pkg == null)
            throw new Error();
        if (pkg == this.pkg)
            return (ClassName) this;
        if (this.outer != null)
            return this.setOuter(this.outer.setPackage(pkg));
        else {
            ClassName copy = (ClassName) this.copy();
            copy.pkg = pkg;
            return copy;
        }
    }

    public ClassName setOuter(ClassName outer) {
        if (outer == null)
            throw new Error();
        if (outer == this.outer)
            return (ClassName) this;
        ClassName copy = (ClassName) this.copy();
        copy.outer = outer;
        copy.pkg = outer.pkg;
        return copy;
    }

    public PackageName pkg() {
        return this.pkg;
    }

    public ClassName outer() {
        return this.outer;
    }

    public ClassName base() {
        if (this.pkg == null && this.outer == null)
            return (ClassName) this;
        ClassName copy = (ClassName) this.copy();
        copy.pkg = null;
        copy.outer = null;
        return copy;
    }

    public ClassName nopkg() {
        if (this.outer != null)
            return this.setOuter(this.outer.nopkg());
        if (this.pkg == null)
            return (ClassName) this;
        else {
            ClassName copy = (ClassName) this.copy();
            copy.pkg = null;
            return copy;
        }
    }

    public ClassName replace(ReplaceName replace) {
        ClassName copy = replace.get((ClassName) this);
        if (copy != this)
            return copy;
        copy = (ClassName) this.replace0(replace);
        if (this.outer != null)
            copy = copy.setOuter(this.outer.replace(replace));
        else if (this.pkg != null)
            copy = copy.setPackage(this.pkg.replace(replace));
        return copy;
    }

    public String toString() {
        return (this.pkg == null && this.outer == null ? ""
                : (this.outer != null ? this.outer.toString() + "$"
                   : this.pkg.toString() + "."))
            + this.begin
            + (this.var == VariableName.NULL ? ""
                    : ("[" + this.var.text() + "]"))
            + this.end;
    }

    public int hashCode() {
        return super.hashCode()
            + (this.outer != null ? this.outer.hashCode()
                    : this.pkg != null ? this.pkg.hashCode() : 0);
    }

    public String javaSource() {
        if (false && this.outer == null && this.pkg == null)
            throw new Error("cannot output java source for class name "
                + this.javaSource0());
        return this.javaSource1();
    }

    public String javaSource1() {
        return (this.outer != null ? this.outer.javaSource1() + '.'
                : (this.pkg != null
                        && !this.pkg.equals(PackageName.ANONYMOUS)) ?
                                this.pkg.javaSource() + '.'
                                : "")
            + this.javaSource0();
    }

    public boolean equals(Object o) {
        if (this == o)
            return true;
        else if (!super.equals(o))
            return false;
        ClassName nm = (ClassName) o;

        if (nm.outer == null && this.outer == null) {
            if (this.pkg == nm.pkg)
                return true;
            if (this.pkg == null || nm.pkg == null)
                return false;
            return this.pkg.equals(nm.pkg);
        } else if (nm.outer == null || this.outer == null)
            return false;
        else
            return this.outer.equals(nm.outer);
    }
}
