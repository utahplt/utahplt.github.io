/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package edu.utah.jiggy.instruction.ins;

import java.util.*;
import java.io.*;

public class Split extends Control {
    // final Set<ins.Merge> merges = new HashSet<ins.Merge>();
    final Set merges = new HashSet();
    final Block head;
    Block exit;

    // Map<ins.Block,ins.Split.Target> targets =
    // new HashMap<ins.Block,ins.Split.Target>();

    public Set merges() {
        return this.merges;
    }

    public Block entrance() {
        return this.head;
    }

    public String toString() {
        return "split-" + this.entrance();
    }

    public void print(PrintStream out) {
        out.println("merges=" + this.merges);
        super.print(out);
    }

    public Block findExit(boolean revbranch, Block b) {
        if (this.parent().isExit(b))
            return null;
        if (b.dominates(this.entrance()))
            return null;

        // System.err.print(this + " " + revbranch + " " + b);
        for (Iterator i = this.entrance().branches().iterator();
             i.hasNext();
             /* i = i */) {
            Block t = (Block) i.next();
            // System.err.print(" [" + t + " " + b.postDominates(t, true) +
            // "]");
            if (!b.postDominates(t, true))
                break;
            if (!i.hasNext()) {
                // System.err.println(".");
                return b;
            }
        }
        // System.err.print(".. ");
        Block ret = null;
        if (!revbranch) {
            for (Iterator i = b.branches().iterator();
                 i.hasNext();
                 /* i = i */) {
                Block t = (Block) i.next();
                Block ret0 = this.findExit(t.dominates(b), t);
                if (ret0 == null)
                    continue;
                if (ret != null && ret0 != ret)
                    throw new Error(this + " " + ret + " " + ret0 + " " + b
                        + " " + t);
                ret = ret0;
            }
        }
        // System.err.println(ret);
        return ret;
    }

    public void notify(Merge merge) {
        Block branch0, branch1;
        {
            Iterator i = this.head.branches().iterator();
            branch0 = (Block) i.next();
            branch1 = (Block) i.next();
        }
        if (false)
            System.err.println("notify " + merge + " " + branch0 + " "
                + branch1 + " " + branch0.reaches(merge.block(), false) + " "
                + branch1.reaches(merge.block(), false));

        if (branch0.reaches(merge.block(), false)
            && branch1.reaches(merge.block(), false)) {
            this.merges().add(merge);
            merge.splits().add((Split) this);
        }
        if (!this.entrance().dominates(merge.block()))
            super.notify(merge);
    }

    public void process() {
        /* assume "two" block branch for now */
        if (this.head.branches().size() != 2)
            throw new Error(this.head + " " + this.head.branches());
        Block branch0, branch1;
        {
            Iterator i = this.head.branches().iterator();
            branch0 = (Block) i.next();
            branch1 = (Block) i.next();
        }

        this.exit = this.findExit(branch0.dominates(this.head), branch0);
        if (this.exit == this.entrance())
            throw new Error(this + " " + branch0.dominates(this.head) + " "
                + branch0 + " "
                + this.findExit(branch1.dominates(this.head), branch1));

        try {
            if (this.isMerge(this.head, branch0)) {
                this.target(branch0).notify(this.findMerge(branch0));
            } else if (!branch0.dominates(this.head))
                this.target(branch0).process();
        } catch (Error e) {
            System.err.println(this.target(branch1));
            throw e;
        }
        try {
            if (this.isMerge(this.head, branch1)) {
                this.target(branch1).notify(this.findMerge(branch1));
            } else if (!branch1.dominates(this.head))
                this.target(branch1).process();
        } catch (Error e) {
            System.err.println(this.target(branch1));
            throw e;
        }
        try {
            if (this.target(branch1).exit() != null
                && !this.target(branch1).exit().dominates(this.entrance())) {
                if (this.isExit(this.target(branch1).exit()))
                    throw new Error();
                // if (this.target(branch1).exit() ==
                // this.target(branch1).entrance()) throw new
                // Error(this.target(branch1) + "");
                this.process(this.target(branch1).exit());
            }
            if (this.target(branch0).exit() != null
                && this.target(branch0).exit() != this.target(branch1).exit()
                && !this.target(branch0).exit().dominates(this.entrance())) {
                if (this.isExit(this.target(branch0).exit()))
                    throw new Error();
                // if (this.target(branch0).exit() ==
                // this.target(branch0).entrance()) throw new Error();
                this.process(this.target(branch0).exit());
            }
        } catch (Error e) {
            System.err.println("split " + this + " " + this.exit());
            throw e;
        }
    }

    public Block exit() {
        return this.exit;
    }

    public Split.Target target(Block a0) {
        return (Split.Target) this.children.get(a0);
    }

    public Split(Control parent, Block head) {
        super(parent);
        this.head = head;
        for (Iterator i = this.head.branches().iterator();
             i.hasNext();
             /* i = i */) {
            Block target = (Block) i.next();
            this.order.add(target);
            this.children.put(target, new Split.Target((Split) this, target));
        }
    }

    public static class Target extends Control {
        final Block target;
        Block exit;

        public Block entrance() {
            return this.target;
        }

        public void process() {
            this.process(this.target);
        }

        public void notify(Merge merge) {
            super.notify(merge);
            if (this.parent().isExit(merge.block()))
                return;
            if (this.exit != null && this.parent().isExit(this.exit))
                throw new Error(
                    "WTF??? " + this + " " + this.exit + " " + merge);
            if (merge.block().dominates(this.target))
                return;

            if (this.exit == null)
                this.exit = merge.block();
            else if (this.exit.postDominates(merge.block(), true))
                this.exit = merge.block();
            else if (merge.block().postDominates(this.exit, true)) {
                ;
            } else
                throw new Error(this + " " + this.exit + " " + merge);
        }

        public Block exit() {
            return this.exit;
        }

        public String toString() {
            return "target-" + this.parent().entrance() + "-" + this.target;
        }

        public Target(Split parent, Block target) {
            super(parent);
            this.target = target;
        }
    }
}
