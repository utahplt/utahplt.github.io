/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.bytecode.ins outins.JumpStoreReturn */

package edu.utah.jiggy.instruction.ins;

import java.io.*;
import java.util.*;

import edu.utah.jiggy.bytecode.bt.BTMethod;
import edu.utah.jiggy.clazz.ClassModel;
import edu.utah.jiggy.meta.shape.ShapeKey;
import edu.utah.jiggy.meta.type.Environment;
import edu.utah.jiggy.meta.type.TypeConstants;
import edu.utah.jiggy.meta.type.TypeType;

public class JumpStoreReturn extends Goto implements Instruction.Imperative {
    static void activate() {
        (new JumpStoreReturn()).put00();
        (new JumpStoreReturn.Wide()).put00();
    }

    public void execute(Machine m) {
        m.push(this);
    }

    public TypeType type(Environment env) {
        return TypeConstants.JAL;
    }

    public Branch updateBranch(Map map) {
        JumpStoreReturn copy = (JumpStoreReturn) super.updateBranch(map);
        if (!map.containsKey(this.ret))
            return copy;
        if (copy == this)
            copy = (JumpStoreReturn) this.copy();
        copy.ret = (Block) map.get(this.ret);
        return copy;
    }

    protected Block ret;

    public java.lang.String mnemonic() {
        return "jsr";
    }

    public Block ret() {
        return this.ret;
    }

    public Instruction read(int pc, DataInputStream input, ClassModel clazz,
                            ShapeKey mthd) throws IOException {
        return ((JumpStoreReturn) super.read(pc, input, clazz, mthd))
            .setReturn(
                ((BTMethod) clazz.body().methods().get(mthd)).code()
                .findTarget(pc + this.size()));
    }

    public Instruction readWide(int pc, DataInputStream input,
                                ClassModel clazz, ShapeKey mthd)
            throws IOException {
        return ((JumpStoreReturn) super.readWide(pc, input, clazz, mthd))
            .setReturn(
                ((BTMethod) clazz.body().methods().get(mthd)).code()
                .findTarget(pc + this.size()));
    }

    public void write(int pc, DataOutputStream out, ClassModel clazz,
                      ShapeKey mthd) throws IOException {
        super.write(pc, out, clazz, mthd);
        if (pc + this.size() != this.ret.getPC())
            throw new Error("not supported");
    }

    public void writeWide(int pc, DataOutputStream out, ClassModel clazz,
                          ShapeKey mthd) throws IOException {
        super.writeWide(pc, out, clazz, mthd);
        if (pc + this.size() != this.ret.getPC())
            throw new Error("not supported");
    }

    public JumpStoreReturn setReturn(Block ret) {
        JumpStoreReturn copy = (JumpStoreReturn) this.copy();
        copy.ret = ret;
        return copy;
    }

    public int opcode() {
        return 168;
    }

    public JumpStoreReturn() {
        super();
    }

    /* atom-edu.utah.jiggy.bytecode.ins outins.JumpStoreReturn.Wide */
    public static class Wide extends JumpStoreReturn {
        public Wide() {
            super();
        }

        public java.lang.String mnemonic() {
            return "jsr_w";
        }

        public int opcode() {
            return 201;
        }

        public boolean isWide() {
            return true;
        }

        public Instruction read(int pc, DataInputStream input,
                                ClassModel clazz, ShapeKey mthd)
                throws IOException {
            return this.readWide(pc, input, clazz, mthd);
        }

        public void write(int pc, DataOutputStream out, ClassModel clazz,
                          ShapeKey mthd) throws IOException {
            this.writeWide(pc, out, clazz, mthd);
        }
    }
}
