/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.bytecode.ins outins.Switch */

package edu.utah.jiggy.instruction.ins;

import java.util.*;
import java.io.*;

import edu.utah.jiggy.bytecode.bt.BTMethod;
import edu.utah.jiggy.clazz.ClassModel;
import edu.utah.jiggy.meta.shape.ShapeKey;

public abstract class Switch extends Branch {
    static void activate() {
        (new Switch.Table()).put00();
        (new Switch.Lookup()).put00();
    }

    protected Block defaultTarget;
    // protected List<ins.Block> targets = new ArrayList<ins.Block>();
    protected List targets = new ArrayList();

    public Branch updateBranch(Map map) {
        if (this.getDefault() == null)
            throw new Error();
        Switch copy = (Switch) super.updateBranch(map);

        for (int i = 0; i < this.targets.size(); i++) {
            Block b0 = (Block) map.get(this.targets.get(i));
            if (b0 == null)
                continue;
            if (copy == this)
                copy = (Switch) this.copy();
            copy.targets.set(i, b0);
        }
        {
            Block b0 = (Block) map.get(this.defaultTarget);
            if (b0 != null) {
                if (copy == this)
                    copy = (Switch) this.copy();
                copy.defaultTarget = b0;
            }
        }
        if (copy.getDefault() == null)
            throw new Error(this + " " + this.getDefault() + " " + map);
        return copy;
    }

    public int argCount() {
        return 1;
    }

    public void execute(Machine m) {
        Value index = m.pop();
        m.doError(index.type(m.context).isa(TypeInfo.INT), "");
        this.args().add(index);
    }

    public Iterator targets() {
        final Iterator i = this.targets.iterator();
        return new Iterator() {
            boolean b = true;

            public boolean hasNext() {
                return b;
            }

            public Object next() {
                if (i.hasNext())
                    return i.next();
                else {
                    if (!this.b)
                        throw new Error();
                    this.b = false;
                    return Switch.this.defaultTarget;
                }
            }

            public void remove() {
                throw new Error();
            }
        };
    }

    public int baseHashCode() {
        return super.baseHashCode() + (this.defaultTarget == null ? 0 : 1)
            + this.targets.hashCode();
    }

    public boolean baseEquals(Instruction ins0) {
        return super.baseEquals(ins0)
            && (((Switch) ins0).defaultTarget == this.defaultTarget)
            && (((Switch) ins0).targets.equals(this.defaultTarget));
    }

    public String toString() {
        return super.toString() + " " + this.targets.size() + ":"
            + this.targets + " " + this.defaultTarget;
    }

    public Instruction copy() {
        Switch copy = (Switch) super.copy();
        copy.targets = new ArrayList(copy.targets);
        return copy;
    }

    public Switch setDefault(Block target) {
        Switch copy = (Switch) this.copy();
        copy.defaultTarget = target;
        return copy;
    }

    public Block getDefault() {
        return this.defaultTarget;
    }

    public List targetList() {
        return this.targets;
    }

    protected int size() {
        throw new Error("shortcut not supported");
    }

    public int padding(int pc) {
        for (int i = 0; true; i++) {
            if (((pc + i) % 4) == 0)
                return i;
        }
    }

    protected int size(int pc) {
        return 1 + this.padding(pc + 1) + 4;

    }

    public Instruction read(int pc, DataInputStream input, ClassModel clazz,
                            ShapeKey mthd) throws IOException {
        Switch copy = (Switch) super.read(pc, input, clazz, mthd);
        for (int i = 0; i < this.padding(pc + 1); i++)
            if (input.readUnsignedByte() != 0)
                throw new Error();
        int defaultOffset = input.readInt();
        Block b = ((BTMethod) clazz.body().methods().get(mthd)).code()
            .findTarget(pc + defaultOffset);
        if (b == null)
            throw new Error(clazz + " " + mthd + " " + defaultOffset);
        copy = copy.setDefault(b);

        if (copy.getDefault() == null)
            throw new Error();

        return copy;
    }

    public void write(int pc, DataOutputStream out, ClassModel clazz,
                      ShapeKey mthd) throws IOException {
        super.write(pc, out, clazz, mthd);
        /* padding */
        for (int i = 0; i < this.padding(pc + 1); i++)
            out.writeByte(0);
        out.writeInt(this.getDefault().offset(pc));
    }

    public Switch() {
        super();
    }

    /* atom-edu.utah.jiggy.bytecode.ins outins.Switch.Table */
    public static class Table extends Switch {
        protected int low;
        protected int high;

        public int baseHashCode() {
            return super.baseHashCode() + this.low + this.high;
        }

        public boolean baseEquals(Instruction ins0) {
            return super.baseEquals(ins0)
                && (((Switch.Table) ins0).low == this.low)
                && (((Switch.Table) ins0).high == this.high);
        }

        public int low() {
            return this.low;
        }

        public int high() {
            return this.high;
        }

        protected int size(int pc) {
            if ((this.high() - this.low() + 1) != this.targets.size())
                throw new Error();
            return super.size(pc) + 8 + (this.targets.size() * 4);
        }

        public Instruction read(int pc, DataInputStream input,
                                ClassModel clazz, ShapeKey mthd)
                throws IOException {
            Switch.Table copy =
                (Switch.Table) super.read(pc, input, clazz, mthd);
            if (copy == this)
                throw new Error();
            copy.low = input.readInt();
            copy.high = input.readInt();
            if (!(copy.high() >= copy.low()))
                throw new Error();
            for (int i = 0; i < copy.high() - copy.low() + 1; i++)
                copy.targets.add(
                    ((BTMethod) clazz.body().methods().get(mthd)).code()
                    .findTarget(pc + input.readInt()));
            if (copy.targets.size() != (copy.high() - copy.low() + 1))
                throw new Error();

            return copy;
        }

        public void write(int pc, DataOutputStream out, ClassModel clazz,
                          ShapeKey mthd) throws IOException {
            super.write(pc, out, clazz, mthd);
            out.writeInt(this.low());
            out.writeInt(this.high());
            if (this.targets.size() != (this.high() - this.low() + 1))
                throw new Error();
            for (int i = 0; i < this.high() - this.low() + 1; i++)
                out.writeInt(((Block) this.targets.get(i)).offset(pc));
        }

        public String mnemonic() {
            return "tableswitch";
        }

        public String toString() {
            return super.toString() + " " + this.low + ":" + this.high;
        }

        public int opcode() {
            return 170;
        }

        public Switch.Table setLow(int a0) {
            Switch.Table copy = (Switch.Table) this.copy();
            copy.low = a0;
            return copy;
        }

        public Switch.Table add(Block target) {
            Switch.Table copy = (Switch.Table) this.copy();
            copy.targets.add(target);
            return copy;
        }

        public Switch.Table setHigh(int a0) {
            Switch.Table copy = (Switch.Table) this.copy();
            copy.high = a0;
            return copy;
        }

        public Table() {
            super();
        }

        protected int size() {
            throw new Error("cannot compute!");
        }
    }

    /* atom-edu.utah.jiggy.bytecode.ins outins.Switch.Lookup */
    public static class Lookup extends Switch {
        // protected List<Integer> matches = new ArrayList<Integer>();
        protected List matches = new ArrayList();

        public String toString() {
            return super.toString() + " " + this.matches;
        }

        public int baseHashCode() {
            return super.baseHashCode() + this.matches.hashCode();
        }

        public boolean baseEquals(Instruction ins0) {
            return super.baseEquals(ins0)
                && (((Switch.Lookup) ins0).matches.equals(this.matches));
        }

        public Instruction copy() {
            Switch.Lookup copy = (Switch.Lookup) super.copy();
            copy.matches = new ArrayList(this.matches);
            return copy;
        }

        public String mnemonic() {
            return "lookupswitch";
        }

        public Switch.Lookup add(int match, Block target) {
            Switch.Lookup copy = (Switch.Lookup) this.copy();
            copy.matches.add(new Integer(match));
            copy.targets.add(target);
            return copy;
        }

        public Instruction read(int pc, DataInputStream input,
                                ClassModel clazz, ShapeKey mthd)
                throws IOException {
            Switch.Lookup copy =
                (Switch.Lookup) super.read(pc, input, clazz, mthd);
            int npairs = input.readInt();
            for (int i = 0; i < npairs; i++) {
                int match = input.readInt();
                Block target = ((BTMethod) clazz.body().methods().get(mthd))
                    .code().findTarget(pc + input.readInt());
                copy.targets.add(target);
                copy.matches.add(new Integer(match));
            }
            return copy;
        }

        public void write(int pc, DataOutputStream out, ClassModel clazz,
                          ShapeKey mthd) throws IOException {
            super.write(pc, out, clazz, mthd);
            out.writeInt(this.targets.size());
            for (int i = 0; i < this.targets.size(); i++) {
                out.writeInt(this.match(i));
                out.writeInt(((Block) this.targets.get(i)).offset(pc));
            }
        }

        public int opcode() {
            return 171;
        }

        public int match(int index) {
            return ((Integer) this.matches.get(index)).intValue();
        }

        protected int size(int pc) {
            return super.size(pc) + 4 + (this.targets.size() * 8);
        }

        public Lookup() {
            super();
        }
    }
}
