/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.meta outshape.ThrowzShape */

package edu.utah.jiggy.meta.shape;

import java.util.*;

import edu.utah.jiggy.meta.type.ClassType;
import edu.utah.jiggy.meta.type.ReplaceType;

public class ThrowzShape extends ShapeElement {
    protected Set members = new HashSet();

    public static final ThrowzShape EMPTY = new ThrowzShape();

    public ShapeElement copy() {
        ThrowzShape copy = (ThrowzShape) super.copy();
        copy.members = new HashSet(this.members);
        return copy;
    }

    public ThrowzShape add(ClassType ctype) {
        if (this.members.contains(ctype))
            return (ThrowzShape) this;
        ThrowzShape copy = (ThrowzShape) this.copy();
        copy.members.add(ctype);
        return copy;
    }

    public java.util.Set members() {
        return this.members;
    }

    public String toString() {
        return this.members.toString();
    }

    public boolean matches(ShapeElement e) {
        ThrowzShape t = (ThrowzShape) e;
        for (Iterator i = t.members.iterator(); i.hasNext(); /* i = i */) {
            ClassType ctype0 = (ClassType) i.next();
            if (this.members.contains(ctype0))
                continue;
            for (Iterator j = this.members.iterator(); true; /* j = j */) {
                if (!j.hasNext())
                    return false;
                ClassType ctype1 = (ClassType) j.next();
                if (ctype0.isa(ctype1)) {
                    this.members.add(ctype0);
                    break;
                }
            }
        }
        return true;
    }

    public ShapeElement replace(ReplaceType replace) {
        if (this == EMPTY)
            return EMPTY;
        ThrowzShape copy = (ThrowzShape) super.replace(replace);
        for (Iterator i = this.members.iterator(); i.hasNext(); /* i = i */) {
            ClassType ctype0 = (ClassType) i.next();
            ClassType ctype1 = (ClassType) ctype0.replace(replace);
            if (ctype0 != ctype1 && copy == this)
                copy = (ThrowzShape) this.copy();
            if (ctype0 != ctype1) {
                if (!copy.members.remove(ctype0))
                    throw new Error();
                if (!copy.members.add(ctype1))
                    throw new Error();
            }
        }
        return copy;
    }

    public ThrowzShape() {
        super();
    }

    public String javaSource() {
        String str = "";
        if (!this.members.isEmpty()) {
            str = str + " throws ";
            for (Iterator i = this.members().iterator();
                 i.hasNext();
                 /* i = i */) {
                str = str + ((ClassType) i.next()).javaSource();
                if (i.hasNext())
                    str = str + ", ";
            }
        }
        return str;
    }
}
