/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package edu.utah.jiggy.meta.flag;

public abstract class Flag implements FlagConstants {
    // protected
    // public
    public Flag() {
        super();
        if (this instanceof IsClassMember)
            FlagConstants.CLASSMEMBER_FLAGS0.add((Flag) this);
        else if (this instanceof IsPackageMember)
            FlagConstants.PACKAGEMEMBER_FLAGS0.add((Flag) this);
        else if (this instanceof IsClass) {
            FlagConstants.CLASSMEMBER_FLAGS0.add((Flag) this);
            FlagConstants.PACKAGEMEMBER_FLAGS0.add((Flag) this);
        } else {
            FlagConstants.CLASSMEMBER_FLAGS0.add((Flag) this);
        }
        if (this instanceof IsClass)
            FlagConstants.CLASS_FLAGS0.add((Flag) this);
        if (this instanceof IsField)
            FlagConstants.FIELD_FLAGS0.add((Flag) this);
        if (this instanceof IsMethod)
            FlagConstants.METHOD_FLAGS0.add((Flag) this);
        if (this instanceof IsInit)
            FlagConstants.INIT_FLAGS0.add((Flag) this);
    }

    /* default, no appearence in source code */
    public String javaSource() {
        return "";
    }

    public String toString() {
        String name = this.getClass().getName();
        name = name.substring(name.lastIndexOf('.') + 1, name.length());
        return name;
    }

    // Below here,
    // From `edu.utah.jiggy.bytecode/outflag/Flag.java'.

    public int jvmcode() {
        return 0;
    }
}
