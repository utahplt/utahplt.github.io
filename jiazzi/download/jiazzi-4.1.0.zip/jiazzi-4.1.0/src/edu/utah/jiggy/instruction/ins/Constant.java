/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.bytecode.ins outins.Constant */

package edu.utah.jiggy.instruction.ins;

import java.io.*;

import edu.utah.jiggy.clazz.ClassModel;
import edu.utah.jiggy.meta.name.ClassName;
import edu.utah.jiggy.meta.name.PackageName;
import edu.utah.jiggy.meta.shape.ShapeKey;
import edu.utah.jiggy.meta.type.Environment;
import edu.utah.jiggy.meta.type.RefType;
import edu.utah.jiggy.meta.type.TypeConstants;
import edu.utah.jiggy.meta.type.TypeType;

public abstract class Constant extends Instruction {
    static void activate() {
        (new Constant.Load(false, false)).put00();
        (new Constant.Load(true, false)).put00();
        (new Constant.Load(true, true)).put00();

        (new Constant.Immediate(TypeInfo.INT, -1)).put00();
        TypeInfo types[] = {
            TypeInfo.REFERENCE,
            TypeInfo.INT,
            TypeInfo.LONG,
            TypeInfo.FLOAT,
            TypeInfo.DOUBLE, };
        int limit[] = { 1, 6, 2, 3, 2 };
        for (int i = 0; i < types.length; i++)
            for (int j = 0; j < limit[i]; j++)
                (new Constant.Immediate(types[i], j)).put00();

        (new Constant.Push.Byte()).put00();
        (new Constant.Push.Short()).put00();
    }

    public Constant() {
        super();
    }

    public abstract Object constantObject();

    public TypeType type(Environment env) {
        if (false) {
        } else if (this.constantObject() instanceof Integer)
            return TypeConstants.INT;
        else if (this.constantObject() instanceof Float)
            return TypeConstants.FLOAT;
        else if (this.constantObject() instanceof Double)
            return TypeConstants.DOUBLE;
        else if (this.constantObject() instanceof Long)
            return TypeConstants.LONG;
        else if (this.constantObject() instanceof String) {
            if (env == null)
                return new RefType() {};
            return env.findPackage(new PackageName("java.lang")).findClass(
                new ClassName("String"));
        } else if (this.constantObject() == null) {
            if (env == null)
                return new RefType() {};
            return env.findPackage(new PackageName("java.lang")).findClass(
                new ClassName("Object"));
        }
        throw new Error(this + " has no type?");

    }

    public void execute(Machine m) {
        super.execute(m);
        m.push(this);
    }

    public boolean baseEquals(Instruction ins) {
        return super.baseEquals(ins)
            && ((Constant) ins).constantObject().equals(this.constantObject());
    }

    public int baseHashCode() {
        return super.baseHashCode()
            + (this.constantObject() == null ? 0 : this.constantObject()
                .hashCode());
    }

    /* atom-edu.utah.jiggy.bytecode.ins outins.Constant.Load */
    public static class Load extends Constant {
        protected boolean isWide;
        protected final boolean is64;
        protected Object constant;

        public Instruction read(int pc, DataInputStream input,
                                ClassModel clazz, ShapeKey mthd)
                throws IOException {
            int index;
            Constant.Load copy = (Constant.Load) super.read(pc, input, clazz,
                mthd);
            if (this.isWide)
                index = input.readUnsignedShort();
            else
                index = input.readUnsignedByte();
            return copy.setConstant(clazz.body().pool().get(index).constant());
        }

        public Instruction prepareWrite(int pc, ClassModel clazz, ShapeKey mthd) {
            int index = clazz.body().pool().allocConstant(this.constant);
            if (!this.is64 && ((index > 255) != this.isWide)) {
                Constant.Load copy = (Constant.Load) this.copy();
                copy.isWide = (index > 255);
                return copy;
            } else
                return super.prepareWrite(pc, clazz, mthd);
        }

        public void write(int pc, DataOutputStream out, ClassModel clazz,
                          ShapeKey mthd) throws IOException {
            super.write(pc, out, clazz, mthd);
            int index = clazz.body().pool().allocConstant(this.constant);
            if (this.isWide)
                out.writeShort(index);
            else
                out.writeByte(index);
        }

        public Constant.Load setConstant(Object constant) {
            Constant.Load copy = (Constant.Load) this.copy();
            copy.constant = constant;
            return copy;
        }

        public String mnemonic() {
            return "ldc" + (this.is64 ? "2" : "") + (this.isWide ? "_w" : "");
        }

        public String toString() {
            return super.toString() + " " + this.constantObject();
        }

        public int opcode() {
            if (!this.isWide)
                return 18;
            else if (!this.is64)
                return 19;
            else
                return 20;
        }

        public Object constantObject() {
            return this.constant;
        }

        public Load(boolean isWide, boolean is64) {
            super();
            this.isWide = isWide;
            this.is64 = is64;
            if (is64 && !isWide)
                throw new Error("invalid ldc");
        }

        protected int size() {
            if (!this.isWide && !this.is64)
                return 2;
            else
                return 3;
        }
    }

    public static class Immediate extends Constant {
        protected final TypeInfo type;
        protected final int constant;

        public Immediate(TypeInfo type, int constant) {
            this.type = type;
            this.constant = constant;
        }

        public String mnemonic() {
            String str = this.typeInfo().mnemonic() + "const_";
            if (this.typeInfo() == TypeInfo.REFERENCE)
                return str + "null";
            else
                return str
                    + (this.constant() < 0 ? -this.constant() : this.constant());
        }

        public TypeInfo typeInfo() {
            return this.type;
        }

        public int constant() {
            return this.constant;
        }

        public Object constantObject() {
            if (this.typeInfo() == TypeInfo.INT)
                return new Integer(this.constant);
            else if (this.typeInfo() == TypeInfo.FLOAT)
                return new Float((float) this.constant);
            else if (this.typeInfo() == TypeInfo.LONG)
                return new Long((long) this.constant);
            else if (this.typeInfo() == TypeInfo.DOUBLE)
                return new Double((double) this.constant);
            else if (this.typeInfo() == TypeInfo.REFERENCE)
                return null;
            else
                throw new Error();
        }

        public int opcode() {
            if (this.typeInfo() == TypeInfo.INT)
                return 3 + this.constant();
            else if (this.typeInfo() == TypeInfo.REFERENCE)
                return 1;
            else if (this.typeInfo() == TypeInfo.LONG)
                return 9 + this.constant();
            else if (this.typeInfo() == TypeInfo.FLOAT)
                return 11 + this.constant();
            else if (this.typeInfo() == TypeInfo.DOUBLE)
                return 14 + this.constant();
            else
                throw new Error();
        }

        protected int size() {
            return 1;
        }
    }

    public static abstract class Push extends Constant {
        protected int constant;

        public Push() {
        }

        public int constant() {
            return this.constant;
        }

        public Object constantObject() {
            return new Integer(this.constant);
        }

        public String mnemonic() {
            return "ipush";
        }

        public String toString() {
            return super.toString() + " " + this.constant;
        }

        public Constant.Push setConstant(int constant) {
            Constant.Push copy = (Constant.Push) this.copy();
            copy.constant = constant;
            return copy;
        }

        public static class Byte extends Constant.Push {
            public Byte() {
            }

            public int opcode() {
                return 16;
            }

            public Instruction read(int pc, DataInputStream input,
                                    ClassModel clazz, ShapeKey mthd)
                    throws IOException {
                Constant.Push.Byte copy =
                    (Constant.Push.Byte) super.read(pc, input, clazz, mthd);
                return copy.setConstant(input.readByte());
            }

            public void write(int pc, DataOutputStream out, ClassModel clazz,
                              ShapeKey mthd) throws IOException {
                super.write(pc, out, clazz, mthd);
                out.writeByte(this.constant);
            }

            protected int size() {
                return 2;
            }

            public String mnemonic() {
                return "b" + super.mnemonic();
            }
        }

        public static class Short extends Constant.Push {
            public Short() {
            }

            public int opcode() {
                return 17;
            }

            public Instruction read(int pc, DataInputStream input,
                                    ClassModel clazz, ShapeKey mthd)
                    throws IOException {
                Constant.Push.Short copy =
                    (Constant.Push.Short) super.read(pc, input, clazz, mthd);
                return copy.setConstant(input.readShort());
            }

            public void write(int pc, DataOutputStream out, ClassModel clazz,
                              ShapeKey mthd) throws IOException {
                super.write(pc, out, clazz, mthd);
                out.writeShort(this.constant);
            }

            protected int size() {
                return 3;
            }

            public String mnemonic() {
                return "s" + super.mnemonic();
            }
        }
    }
}
