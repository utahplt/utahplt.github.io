/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.bytecode.ins outins.Convert */

package edu.utah.jiggy.instruction.ins;

import edu.utah.jiggy.meta.type.Environment;
import edu.utah.jiggy.meta.type.TypeType;

public class Convert extends Instruction {
    public void execute(Machine m) {
        Value value = m.pop();
        m.doError(value.type(m.context).isa(this.from));
        this.args().add(value);
        m.push(this);
    }

    public TypeType type(Environment env) {
        return ((TypeInfo.Primitive) to).ptype;
    }

    static void activate() {
        {
            TypeInfo types[] = {
                TypeInfo.INT,
                TypeInfo.LONG,
                TypeInfo.FLOAT,
                TypeInfo.DOUBLE };
            for (int i = 0; i < types.length; i++)
                for (int j = 0; j < types.length; j++) {
                    if (i == j)
                        continue;
                    (new Convert(types[i], types[j])).put00();
                }
        }
        {
            TypeInfo types[] = { TypeInfo.BYTE, TypeInfo.CHAR, TypeInfo.SHORT };
            for (int i = 0; i < types.length; i++)
                (new Convert(TypeInfo.INT, types[i])).put00();
        }
    }

    final TypeInfo from;
    final TypeInfo to;

    public java.lang.String mnemonic() {
        return this.from.mnemonic() + "2" + this.to.mnemonic();
    }

    public int opcode() {
        if (this.from == TypeInfo.INT
            && this.to.opcodeOffset() > TypeInfo.DOUBLE.opcodeOffset()) {
            return 145 + this.to.opcodeOffset() - TypeInfo.BYTE.opcodeOffset();
        } else {
            int n = 133 + (3 * this.from.opcodeOffset());
            if (false)
                throw new Error();
            else if (this.to.opcodeOffset() == this.from.opcodeOffset())
                throw new Error();
            else if (this.to.opcodeOffset() < this.from.opcodeOffset())
                n += this.to.opcodeOffset();
            else if (this.to.opcodeOffset() > this.from.opcodeOffset())
                n += (this.to.opcodeOffset() - 1);
            else
                throw new Error();
            return n;
        }
    }

    public TypeInfo toType() {
        return this.to;
    }

    public TypeInfo fromType() {
        return this.from;
    }

    public Convert(TypeInfo from, TypeInfo to) {
        super();
        this.from = from;
        this.to = to;
    }

    protected int size() {
        return 1;
    }
}
