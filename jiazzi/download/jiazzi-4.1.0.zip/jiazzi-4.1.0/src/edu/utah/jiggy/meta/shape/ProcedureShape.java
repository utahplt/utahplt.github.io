/*
 * Copyright (c) 2004, 2005, 2006 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package edu.utah.jiggy.meta.shape;

import java.util.*;

import edu.utah.jiazzi.unit.ArgVar;
import edu.utah.jiggy.meta.type.ReplaceType;
import edu.utah.jiggy.meta.type.TypeType;

public class ProcedureShape extends ShapeElement {
    public static final ProcedureShape EMPTY = new ProcedureShape();

    protected List args = new ArrayList(); // ArrayList<shape.Args>

    public List args() {
        return this.args;
    }

    public ShapeElement copy() {
        ProcedureShape copy = (ProcedureShape) super.copy();
        copy.args = new ArrayList(this.args);
        return copy;
    }

    public ProcedureShape addArg(ArgShape arg) {
        ProcedureShape copy = (ProcedureShape) this.copy();
        copy.args.add(arg);
        return copy;
    }

    public ProcedureShape addArg(TypeType type) {
        ProcedureShape copy = (ProcedureShape) this.copy();
        copy.args.add(
            (new ArgShape()).setName("a" + copy.args.size()).setType(type));
        return copy;
    }

    public String javaSource() {
        String str = "(";
        for (Iterator i = this.args().iterator(); i.hasNext(); /* i = i */) {
            str = str + ((ArgShape) i.next()).javaSource();
            if (i.hasNext())
                str = str + ", ";
        }
        str = str + ")";
        return str;
    }

    public boolean matchesInternal(ShapeElement e) {
        if (!super.matches(e))
            return false;
        if (this == EMPTY || e == EMPTY)
            return e == this;
        ProcedureShape p = (ProcedureShape) e;
        if (!this.args.equals(p.args))
            return false;
        return true;
    }

    public ShapeElement replaceInternal(ReplaceType replace) {
        if (this == EMPTY)
            return EMPTY;
        ProcedureShape copy = (ProcedureShape) super.replace(replace);
        for (int i = 0; i < this.args.size(); i++) {
            ArgShape a0 = (ArgShape) this.args.get(i);
            ArgShape a1 = (ArgShape) a0.replace(replace);
            if (a0 == a1)
                continue;
            if (copy == this)
                copy = (ProcedureShape) this.copy();
            if (copy.args.set(i, a1) != a0)
                throw new Error();
        }
        if (copy.args.size() != this.args.size())
            throw new Error("was \"" + this + "\" now \"" + copy + "\"");
        return copy;
    }

    public String toStringInternal() {
        if (this == EMPTY)
            return "<empty>";
        else
            return this.javaSource();
    }

    public ProcedureShape() {
        super();
    }

    // Below here,
    // From `edu.utah.jiggy.bytecode/outshape/Procedure.java'.

    public String jvmTypeString() {
        String str = "(";
        for (Iterator i = this.args().iterator(); i.hasNext(); /* i = i */) {
            str = str + ((ArgShape) i.next()).type().jvmTypeString();
        }
        return str + ")";
    }

    // Below here,
    // From `edu.utah.jiggy.instruction/outshape/Procedure.java'.

    public int stackWidth() {
        int count = 0;
        for (Iterator i = this.args().iterator(); i.hasNext(); /* i = i */) {
            ArgShape arg = (ArgShape) i.next();
            if (arg.type().stackWidth() == 0)
                throw new Error();
            count += arg.type().stackWidth();
        }
        return count;
    }

    // Below here,
    // From `edu.utah.jiazzi.core/outshape/Procedure.java'.

    public ArgVar argVar;

    public ProcedureShape set(ArgVar a0) {
        ProcedureShape p = (ProcedureShape) this.copy();
        p.argVar = a0;
        return p;
    }

    public String toString() {
        String s = toStringInternal();
        if (this.argVar != null)
            s += "[" + argVar.name() + "]";
        return s;
    }

    public ArgVar argVar() {
        return this.argVar;
    }

    public boolean matches(ShapeElement e) {
        if (!matchesInternal(e))
            return false;
        return true;
    }

    public ShapeElement replace(ReplaceType replace) {
        ProcedureShape p = (ProcedureShape) replaceInternal(replace);
        if (this.argVar == null || !(replace instanceof ReplaceShape))
            return p;
        ReplaceShape sreplace = (ReplaceShape) replace;
        ProcedureShape p0 = this.argVar.replace(sreplace);
        if (p0.args().size() == 0 && p0.argVar() == this.argVar)
            return p;
        for (Iterator i = p0.args().iterator(); i.hasNext(); /* i = i */)
            p = p.addArg((ArgShape) i.next());
        p = p.set(p0.argVar());
        return p;
    }
}
