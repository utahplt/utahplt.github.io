/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package edu.utah.jiggy.meta.name;

import java.util.*;

public class ReplaceName extends java.lang.Object {
    // Map<ClassName,Map<MemberName,MemberName>>
    protected final Map members = new HashMap();
    // Map<ClassName,ClassName>
    protected final Map classes = new HashMap();
    // Map<PackageName,PackageName>
    protected final Map packages = new HashMap();
    // Map<VariableName,ExpandedName>
    protected final Map variables = new HashMap();

    public ReplaceName() {
    }

    public ReplaceName(ReplaceName replace) {
        this.classes.putAll(replace.classes);
        this.packages.putAll(replace.packages);
        this.variables.putAll(replace.variables);
        for (Iterator i = replace.members.keySet().iterator();
             i.hasNext();
             /* Nothing */) {
            ClassName cname = (ClassName) i.next();
            this.members.put(cname, new HashMap());
            ((HashMap) this.members.get(cname))
                .putAll((HashMap) replace.members.get(cname));
        }
    }

    public String toString() {
        return this.classes + " " + this.packages + " " + this.members + " "
            + this.variables;
    }

    protected ExpandedName get(VariableName var) {
        if (this.variables.containsKey(var))
            return (ExpandedName) this.variables.get(var);
        else
            return new ExpandedName("", var, "");
    }

    protected MemberName get(ClassName clazz, MemberName name) {
        if (this.members.containsKey(clazz)
            && ((HashMap) this.members.get(clazz)).containsKey(name))
            return (MemberName) ((HashMap) this.members.get(clazz)).get(name);
        else
            return name;
    }

    protected ClassName get(ClassName clazz) {
        if (this.classes.containsKey(clazz))
            return (ClassName) this.classes.get(clazz);
        else
            return clazz;
    }

    protected PackageName get(PackageName pkg) {
        if (this.packages.containsKey(pkg))
            return (PackageName) this.packages.get(pkg);
        else
            return pkg;
    }

    public void map(VariableName var, ExpandedName exp) {
        this.variables.put(var, exp);
    }

    public void map(ClassName clazz, MemberName name0, MemberName name1) {
        if (!this.members.containsKey(clazz))
            this.members.put(clazz, new HashMap());
        ((HashMap) this.members.get(clazz)).put(name0, name1);
    }

    public void map(ClassName name0, ClassName name1) {
        if (name0.pkg() == null)
            throw new Error("" + name0);
        if (name1.pkg() != null)
            throw new Error("" + name1);
        this.classes.put(name0, name1);
    }

    public void map(PackageName name0, PackageName name1) {
        this.packages.put(name0, name1);
    }
}
