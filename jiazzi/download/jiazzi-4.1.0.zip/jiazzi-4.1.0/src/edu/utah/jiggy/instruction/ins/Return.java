/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.bytecode.ins outins.Return */

package edu.utah.jiggy.instruction.ins;

import java.util.*;

public class Return extends Branch {
    private final TypeInfo type;

    public TypeInfo typeInfo() {
        return this.type;
    }

    // private static final Iterator<ins.Block> ZERO = (new
    // HashSet<ins.Block>()).iterator();
    private static final Iterator ZERO = (new HashSet()).iterator();

    public int argCount() {
        return (this.typeInfo() == TypeInfo.VOID ? 0 : 1);
    }

    public java.util.Iterator targets() {
        return ZERO;
    }

    static void activate() {
        TypeInfo types[] = {
            TypeInfo.INT,
            TypeInfo.LONG,
            TypeInfo.FLOAT,
            TypeInfo.DOUBLE,
            TypeInfo.REFERENCE,
            TypeInfo.VOID };
        for (int i = 0; i < types.length; i++)
            (new Return(types[i])).put00();
    }

    public java.lang.String mnemonic() {
        return (this.typeInfo().mnemonic() == ' ' ? "" : ""
            + this.typeInfo().mnemonic())
            + "return";
    }

    public int opcode() {
        return 172 + this.typeInfo().opcodeOffset();
    }

    public Return(TypeInfo type) {
        super();
        this.type = type;
    }

    public void execute(Machine m) {
        if (this.typeInfo() != TypeInfo.VOID) {
            Value returned = m.pop();
            this.args().add(returned);
            m.doError(returned.type(m.context).isa(this.typeInfo()), "");
        }
    }

    protected int size() {
        return 1;
    }
}
