/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package edu.utah.jiggy.meta.type;

import java.util.*;
import edu.utah.jiggy.meta.name.ReplaceName;

public class ReplaceType extends ReplaceName {
    // protected final Map<TypeType,TypeType> types = new
    // HashMap<TypeType,TypeType>();
    // protected final Map<PackageType,PackageType> packages =
    // new HashMap<PackageType,PackageType>();
    // protected final Map<Root,Root> roots =
    // new HashMap<Root,Root>();
    protected final Map types = new HashMap();
    protected final Map packages = new HashMap();
    protected final Map roots = new HashMap();

    public ReplaceType() {
    }

    public ReplaceType(ReplaceType replace) {
        super(replace);
        this.types.putAll(replace.types);
        this.packages.putAll(replace.packages);
        this.roots.putAll(replace.roots);
        // Following line from copy constructor in
        // `edu.utah.jiggy.bytecode/outtype/Replace.java'.
        this.map.putAll(replace.map);
    }

    public ReplaceType(ReplaceName replace) {
        super(replace);
    }

    public String toString() {
        return (super.toString() + " types:" + this.types + " pkgs:"
            + this.packages + " roots:" + this.roots
            // Following from `toString' in
            // `edu.utah.jiggy.bytecode/outtype/Replace.java'.
            + " gjs:" + this.map);
    }

    public void map(TypeType type0, TypeType type1) {
        this.types.put(type0, type1);
    }

    public void map(PackageType pkg0, PackageType pkg1) {
        this.packages.put(pkg0, pkg1);
    }

    public void map(Root root0, Root root1) {
        this.roots.put(root0, root1);
    }

    protected TypeType get(TypeType type) {
        if (this.types.containsKey(type))
            return (TypeType) this.types.get(type);
        else
            return type;
    }

    protected PackageType get(PackageType pkg) {
        if (this.packages.containsKey(pkg))
            return (PackageType) this.packages.get(pkg);
        else
            return pkg;
    }

    protected Root get(Root root) {
        if (this.roots.containsKey(root))
            return (Root) this.roots.get(root);
        else
            return root;
    }

    // Below here,
    // From `edu.utah.jiggy.bytecode/outtype/Replace.java'.

    // protected final Map<String,type.GJVariable> map =
    // new HashMap<String,type.GJVariable>();
    protected final Map map = new HashMap();

    protected GJVariableType get(String name) {
        if (this.map.containsKey(name))
            return (GJVariableType) this.map.get(name);
        else
            return null;
    }

    public void map(String name, GJVariableType gjv) {
        this.map.put(name, gjv);
    }
}
