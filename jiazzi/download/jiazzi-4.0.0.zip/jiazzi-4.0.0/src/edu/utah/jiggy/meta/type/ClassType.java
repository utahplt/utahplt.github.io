/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package edu.utah.jiggy.meta.type;

import edu.utah.jiggy.instruction.ins.Machine;
import edu.utah.jiggy.meta.flag.AccessFlag;
import edu.utah.jiggy.meta.name.ClassName;
import edu.utah.jiggy.meta.shape.ClassShape;
import edu.utah.jiggy.meta.shape.TypeShape;

import java.util.*;

public abstract class ClassType extends RefType {
    // protected List<RefType> params = new ArrayList<RefType>();
    protected List params = new ArrayList();

    protected ClassType() {
    }

    /* raw types are same as class types here */
    public ClassType raw() {
        if (this.params.size() == 0)
            return (ClassType) this;
        ClassType copy = (ClassType) super.copy();
        copy.params = new ArrayList();
        return copy;
    }

    public ClassType setRaw(ClassType raw) {
        return raw;
    }

    public abstract ClassType outer();

    public abstract boolean isShapeSet();

    public abstract ClassType inner(ClassName name);

    public abstract ClassType setShape(ClassShape shape);

    public abstract TypeShape shape();

    public abstract ClassShape rawShape();

    public abstract PackageType pkg0();

    public ClassType addParam(RefType ref) {
        ClassType copy = (ClassType) this.copy();
        copy.params.add(ref);
        return copy;
    }

    public List params() {
        return Collections.unmodifiableList(this.params);
    }

    public TypeType copy() {
        ClassType copy = (ClassType) super.copy();
        copy.params = new ArrayList(this.params);
        return copy;
    }

    public AccessFlag scope(ClassType clazz) {
        return AccessFlag.PUBLIC;
    }

    public TypeType replace(ReplaceType replace) {
        ClassType ret;
        ret = (ClassType) super.replace(replace);
        if (ret == this) {
            if (!this.equals(this.raw()))
                ret = this.setRaw((ClassType) this.raw().replace(replace));
            else {
                try {
                    ret = this.pkg0().replace(replace).findClass(
                        this.name().replace(replace).nopkg());
                } catch (Error e) {
                    System.err.println(this.pkg0() + " vs. "
                        + this.pkg0().replace(replace));
                    System.err.println(this.name() + " vs. "
                        + this.name().replace(replace));
                    System.err.println(replace);
                    throw e;
                }
            }
        }
        if (ret != this)
            ret.params = new ArrayList(this.params);
        for (int i = 0; i < this.params.size(); i++) {
            RefType param0 = (RefType) this.params.get(i);
            RefType param1 = (RefType) param0.replace(replace);
            if (param0 == param1)
                continue;
            if (ret == this)
                ret = (ClassType) this.copy();
            ret.params.set(i, param1);
        }
        return ret;
    }

    public boolean isa(TypeType type) {
        if (super.isa(type))
            return true;
        else if (!(type instanceof ClassType))
            return false;
        ClassType ctype = (ClassType) type;
        if (this.shape().interfaces().contains(ctype))
            return true;
        else if (this.shape().zuper() == null)
            return false;
        else
            return this.shape().zuper().isa(ctype);
    }

    public abstract ClassName name();

    public String javaSource() {
        String s = this.name().javaSource();
        if (this.params.isEmpty())
            return s;
        s = s + '<';
        for (Iterator i = this.params.iterator(); i.hasNext(); /* i = i */) {
            s = s + ((RefType) i.next()).javaSource();
            if (i.hasNext())
                s = s + ", ";
        }
        return s + '>';
    }

    // public abstract Set<ClassType> inners();
    public abstract Set inners();

    // Below here,
    // From `edu.utah.jiggy.bytecode/outtype/Class.java'.

    public String jvmTypeString() {
        return "L" + this.jvmClassString() + ";";
    }

    public String jvmClassString() {
        if (this.pkg0() == null)
            throw new Error();
        return this.pkg0().name().javaSource().replace('.', '/') + '/'
            + this.name().nopkg().javaSource().replace('.', '$');
    }

    public String gjTypeString() {
        String sig = 'L' + this.jvmClassString();
        if (!this.params().isEmpty()) {
            sig += "<";
            for (Iterator i = this.params().iterator();
                 i.hasNext();
                 /* i = i */)
                sig += ((RefType) i.next()).gjTypeString();
            sig += ">";
        }
        sig += ';';

        return sig;
    }

    // Below here,
    // From `edu.utah.jiggy.instruction/outtype/Class.java'.

    public TypeType merge(TypeType t, Machine m) {
        if (t instanceof ClassType) {
            if (this.isa(t))
                return t;
            if (t.isa(this))
                return this;
            return this.shape().zuper().merge(t, m);
        } else
            return super.merge(t, m);
    }
}
