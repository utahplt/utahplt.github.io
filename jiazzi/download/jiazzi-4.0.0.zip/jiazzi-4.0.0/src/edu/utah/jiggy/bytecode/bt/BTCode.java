/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.bytecode outbt.Code */

package edu.utah.jiggy.bytecode.bt;

import java.util.*;
import java.util.jar.JarOutputStream;
import java.io.*;

import edu.utah.jiggy.clazz.ClassModel;
import edu.utah.jiggy.clazz.DirModelRoot;
import edu.utah.jiggy.clazz.JarModelRoot;
import edu.utah.jiggy.clazz.JarModelSaver;
import edu.utah.jiggy.clazz.ModelRoot;
import edu.utah.jiggy.clazz.NullModelRoot;
import edu.utah.jiggy.clazz.PackageModel;
import edu.utah.jiggy.clazz.TypeModel;
import edu.utah.jiggy.instruction.ins.Block;
import edu.utah.jiggy.instruction.ins.Branch;
import edu.utah.jiggy.instruction.ins.Goto;
import edu.utah.jiggy.instruction.ins.Instruction;
import edu.utah.jiggy.instruction.ins.Machine;
import edu.utah.jiggy.instruction.ins.ReplaceIns;
import edu.utah.jiggy.instruction.ins.Root;
import edu.utah.jiggy.instruction.ins.Value;
import edu.utah.jiggy.meta.flag.FlagConstants;
import edu.utah.jiggy.meta.name.ClassName;
import edu.utah.jiggy.meta.name.MemberName;
import edu.utah.jiggy.meta.name.PackageName;
import edu.utah.jiggy.meta.shape.ArgShape;
import edu.utah.jiggy.meta.shape.Base;
import edu.utah.jiggy.meta.shape.MemberShape;
import edu.utah.jiggy.meta.shape.MethodShape;
import edu.utah.jiggy.meta.shape.NameTypeShape;
import edu.utah.jiggy.meta.shape.ProcedureShape;
import edu.utah.jiggy.meta.shape.ShapeKey;
import edu.utah.jiggy.meta.type.ClassType;
import edu.utah.jiggy.meta.type.Environment;
import edu.utah.jiggy.meta.type.TypeConstants;

public class BTCode extends BTAttr {
    protected int maxLocal;
    int maxStack;
    // protected List<bt.Code.ExceptionEntry> etable = new
    // ArrayList<bt.Code.ExceptionEntry>();
    // protected Map<BTAttr,BTAttr> attributes = new HashMap<BTAttr,BTAttr>();
    protected List etable = new ArrayList();
    protected Map attributes = new HashMap();
    protected byte b[] = new byte[0];

    protected boolean isClass() {
        return false;
    }

    public String toString() {
        return super.toString() + ":" + this.maxStack + ":" + this.maxLocal
            + ":" + this.etable + ":" + this.attributes.values();
    }

    public void dumpCodeInternal(PrintStream out) {
        out.println("code: " + this.b.length + " bytes");
    }

    public void dump(PrintStream out) {
        out.println(this.name());
        out.println("stack: " + this.maxStack);
        out.println("local: " + this.maxLocal);
        out.println("etable: " + this.etable);
        this.dumpCode(out);
        out.println("ATTRIBUTES");
        for (Iterator i = this.attributes.values().iterator();
             i.hasNext();
             /* i = i */)
            ((BTAttr) i.next()).dump(out);
    }

    public BTAttr copyInternal() {
        BTCode copy = (BTCode) super.copy();
        copy.etable = new ArrayList(copy.etable);
        copy.attributes = new HashMap(copy.attributes);
        copy.b = new byte[this.b.length];
        System.arraycopy(this.b, 0, copy.b, 0, this.b.length);
        return copy;
    }

    protected byte[] getCodeBytes() {
        return this.b;
    }

    protected void setCodeBytes(byte[] b) {
        this.b = b;
    }

    public List etable() {
        return this.etable;
    }

    public int maxLocal() {
        return this.maxLocal;
    }

    public int maxStack() {
        return this.maxStack;
    }

    public String name() {
        return "Code";
    }

    public void setMaxStack(int n) {
        this.maxStack = n;
    }

    public void setMaxLocal(int n) {
        this.maxLocal = n;
    }

    public Map attributes() {
        return this.attributes;
    }

    public BTCode() {
        super();
    }

    public BTAttr replaceInternal(ReplaceBT replace) {
        BTCode copy = (BTCode) this.copy();
        for (ListIterator i = copy.etable.listIterator();
             i.hasNext();
             /* i = i */) {
            BTCode.ExceptionEntry e0 = (BTCode.ExceptionEntry) i.next();
            if (e0.catchType() != null) {
                ClassType catchType = (ClassType) e0.catchType().replace(
                    replace);
                if (catchType != e0.catchType()) {
                    BTCode.ExceptionEntry e1 = e0.copy();
                    e1.catchType = catchType;
                    i.set(e1);
                }
            }
        }
        // Set<BTAttr> toAdd = new HashSet<BTAttr>();
        Set toAdd = new HashSet();
        for (Iterator i = copy.attributes.values().iterator();
             i.hasNext();
             /* i = i */) {
            BTAttr attr0 = (BTAttr) i.next();
            BTAttr attr1 = attr0.replace(replace);
            if (attr0 != attr1)
                continue;
            i.remove();
            toAdd.add(attr1);
        }
        for (Iterator i = toAdd.iterator(); i.hasNext(); /* i = i */) {
            BTAttr attr = (BTAttr) i.next();
            if (copy.attributes().put(attr, attr) != null)
                throw new Error();
        }
        return copy;
    }

    String toHex(int csize) {
        String s = null;
        for (int i = 0; i < 8; i++) {
            int n = (csize >> ((8 - i - 1) * 4)) & 0x0000000F;
            if (n == 0 && s == null)
                continue;
            if (s == null)
                s = "";
            if (n <= 9)
                s += ("" + n);
            else
                s += ("" + ('a' + (n - 10)));
        }
        if (s == null)
            return "0";
        else
            return s;
    }

    public BTAttr readMember(int size, DataInputStream in, ClassModel clazz,
                             BTMember mmbr, MemberShape smthd)
            throws IOException {
        BTCode code = (BTCode) super.readMember(size, in, clazz, mmbr, smthd);
        int stack = in.readUnsignedShort();
        int local = in.readUnsignedShort();
        code.setMaxStack(stack);
        code.setMaxLocal(local);
        int csize = in.readInt();
        if (csize > (1 << 16)) {
            System.err.println("code for " + smthd.javaSource("")
                + " is too long at " + csize + " bytes " + toHex(csize)
                + " stack=" + toHex(stack) + " local=" + toHex(local)
                + " size=" + size);
            csize = csize & 0x0000FFFF;
            System.err.println(csize);
        }
        code.b = new byte[csize];
        in.readFully(code.b);
        {
            int esize = in.readUnsignedShort();
            for (int i = 0; i < esize; i++) {
                int startPC = in.readUnsignedShort();
                int endPC = in.readUnsignedShort();
                int handlerPC = in.readUnsignedShort();
                int catchType = in.readUnsignedShort();
                try {
                    code.etable.add(
                        new BTCode.ExceptionEntry(
                            startPC,
                            endPC,
                            handlerPC,
                            (catchType == 0 ? null :
                                (ClassType) clazz.body().pool().get(catchType).
                                clazz())));
                } catch (RuntimeException e) {
                    System.err.println(toHex(esize) + " " + toHex(startPC)
                        + " " + toHex(endPC) + " " + toHex(handlerPC) + " "
                        + toHex(catchType));
                    throw e;
                }
            }
        }
        {
            int asize = in.readUnsignedShort();
            for (int i = 0; i < asize; i++) {
                BTAttr attr = BTAttr.find(clazz.body().pool().get(
                    in.readUnsignedShort()).utf8());
                int size0 = in.readInt();
                attr = attr.readMember(size0, in, clazz, mmbr, smthd);
                if (attr.isDerived())
                    throw new Error(
                        "derived attribtues not supported for code " + mmbr
                            + " " + smthd);
                code.attributes.put(attr, attr);
            }
        }
        return code;
    }

    public boolean prepareWriteMemberInternal(ClassModel clazz, ShapeKey mmbr) {
        for (Iterator i = this.etable.iterator(); i.hasNext(); /* i = i */) {
            BTCode.ExceptionEntry e = (BTCode.ExceptionEntry) i.next();
            if (e.catchType() != null) {
                clazz.body().pool().allocClass(e.catchType());
            }
        }
        for (Iterator i = this.attributes.values().iterator();
             i.hasNext();
             /* i = i */) {
            if (!((BTAttr) i.next()).prepareWriteMember(clazz, mmbr))
                i.remove();
        }
        return super.prepareWriteMember(clazz, mmbr);
    }

    public void writeMemberInternal(DataOutputStream out, ClassModel clazz,
                                    ShapeKey mmbr) throws IOException {
        super.writeMember(out, clazz, mmbr);
        out.writeShort(this.maxStack());
        out.writeShort(this.maxLocal());

        int size = this.b.length;
        if (size > (1 << 16))
            throw new Error("code for " + mmbr + " is too long at " + size
                + " bytes");
        out.writeInt(size);

        out.write(this.b);
        out.writeShort(this.etable.size());
        for (Iterator i = this.etable.iterator(); i.hasNext(); /* i = i */) {
            BTCode.ExceptionEntry e = (BTCode.ExceptionEntry) i.next();
            out.writeShort(e.startPC());
            out.writeShort(e.endPC());
            out.writeShort(e.handlerPC());
            out.writeShort(e.catchType() == null ? 0 : clazz.body().pool()
                .allocClass(e.catchType()));
        }
        out.writeShort(this.attributes.keySet().size());
        for (Iterator i = this.attributes.values().iterator();
             i.hasNext();
             /* i = i */) {
            ((BTAttr) i.next()).writeMember(out, clazz, mmbr);
        }
        return;
    }

    protected int size(ClassModel clazz, Base base) {
        int n = 8 + this.b.length + 2 + (this.etable.size() * 8) + 2;
        for (Iterator i = this.attributes.values().iterator();
             i.hasNext();
             /* i = i */) {
            n += (6 + ((BTAttr) this.attributes.get((BTAttr) i.next())).size(
                clazz, base));
        }
        return n;
    }

    /* atom-edu.utah.jiggy.bytecode outbt.Code.ExceptionEntry */
    public static class ExceptionEntry extends Object implements Cloneable {
        protected int endPC;
        protected int startPC;
        protected ClassType catchType;
        protected int handlerPC;

        public BTCode.ExceptionEntry copy() {
            try {
                return (BTCode.ExceptionEntry) this.clone();
            } catch (Exception e) {
                throw new Error("" + e);
            }
        }

        public BTCode.ExceptionEntry replace(ReplaceBT replace) {
            if (this.catchType != null) {
                ClassType ctype = (ClassType) this.catchType.replace(replace);
                if (ctype != this.catchType) {
                    BTCode.ExceptionEntry ee = this.copy();
                    ee.catchType = ctype;
                    return ee;
                }
            }
            return (BTCode.ExceptionEntry) this;
        }

        protected void setEndPC(int n) {
            this.endPC = n;
        }

        public int endPC() {
            return this.endPC;
        }

        protected void setStartPC(int n) {
            this.startPC = n;
        }

        public int startPC() {
            return this.startPC;
        }

        public ClassType catchType() {
            return this.catchType;
        }

        protected void setHandlerPC(int n) {
            this.handlerPC = n;
        }

        public int handlerPC() {
            return this.handlerPC;
        }

        public String toStringInternal() {
            return this.startPC + ":" + this.endPC + ":" + this.handlerPC + ":"
                + this.catchType.javaSource();
        }

        public ExceptionEntry(int startPC, int endPC, int handlerPC,
                              ClassType catchType) {
            super();
            this.startPC = startPC;
            this.endPC = endPC;
            this.handlerPC = handlerPC;
            this.catchType = catchType;
        }

        // Below here,
        // From `edu.utah.jiggy.instruction/outbt/Code.java'.

        public Block start;
        public Block end;
        public Block handler;
        private Value.Exception value;

        public BTCode.ExceptionEntry updateBranch(Map map) {
            BTCode.ExceptionEntry copy = (BTCode.ExceptionEntry) this;
            Block s0 = (Block) map.get(this.start);
            Block e0 = (Block) map.get(this.end);
            Block h0 = (Block) map.get(this.handler);
            if ((s0 != null || e0 != null || h0 != null) && (copy == this))
                copy = this.copy();
            if (s0 != null)
                copy.start = s0;
            if (e0 != null)
                copy.end = e0;
            if (h0 != null)
                copy.handler = h0;
            return copy;
        }

        public Value.Exception value() {
            if (this.value == null)
                this.value = new Value.Exception((BTCode.ExceptionEntry) this);
            return this.value;
        }

        public Object clone() throws CloneNotSupportedException {
            Object o = super.clone();
            ((ExceptionEntry) o).value = null;
            return o;
        }

        public void prepareWrite() {
            if (this.start != null)
                this.setStartPC(this.start.getPC());
            if (this.end != null)
                this.setEndPC(this.end.getPC());
            if (this.handler != null)
                this.setHandlerPC(this.handler.getPC());
        }

        public String toString() {
            return toStringInternal() + " " + this.start + "-" + this.end + ":"
                + this.handler;
        }
    }

    // Below here,
    // From `edu.utah.jiggy.instruction/outbt/Code.java'.

    // public List<ins.Block> blocks;
    public List blocks;
    public Root root;

    public void dumpCode(PrintStream out) {
        dumpCodeInternal(out);
        if (this.blocks != null)
            for (Iterator i = this.blocks.iterator(); i.hasNext(); /* i = i */)
                ((Block) i.next()).print(null, out);
    }

    public Root head() {
        return this.root;
    }

    public BTAttr copy() {
        BTCode code = (BTCode) copyInternal();
        if (this.blocks != null) {
            // Map<ins.Block,ins.Block> map = new
            // HashMap<ins.Block,ins.Block>();
            Map map = new HashMap();
            code.blocks = new ArrayList();
            for (Iterator i = this.blocks.iterator();
                 i.hasNext();
                 /* i = i */) {
                Block b0 = (Block) i.next();
                Block b1 = (Block) b0.copy();
                map.put(b0, b1);
                code.blocks.add(b1);
            }
            for (Iterator i = code.blocks.iterator(); i.hasNext(); /* i = i */)
                ((Block) i.next()).updateBranch(map);
            for (ListIterator i = code.etable().listIterator();
                 i.hasNext();
                 /* i = i */)
                i.set(((BTCode.ExceptionEntry) i.next()).updateBranch(map));

            // Set<bt.Attr> toAdd = new HashSet<bt.Attr>();
            Set toAdd = new HashSet();

            for (Iterator i = code.attributes().values().iterator();
                 i.hasNext();
                 /* i = i */) {
                BTAttr attr = (BTAttr) i.next();
                BTAttr attr0 = attr.updateBranch(map);
                if (attr == attr0)
                    continue;
                toAdd.add(attr0);
                i.remove();

                if (code.attributes().get(attr) == attr)
                    throw new Error();
            }
            for (Iterator i = toAdd.iterator(); i.hasNext(); /* i = i */) {
                BTAttr attr = (BTAttr) i.next();
                if (code.attributes().containsKey(attr))
                    throw new Error();
                if (code.attributes().put(attr, attr) != null)
                    throw new Error();
            }
        }
        return code;
    }

    public BTAttr replace(ReplaceBT replace) {
        if (this.blocks == null && replace.needBuild)
            this.buildInstructions(replace.clazz(), replace.mmbr().key());

        BTCode code = (BTCode) replaceInternal(replace);
        if (this.blocks != null && code == this)
            code = (BTCode) this.copy();
        int n = replace.mmbr().replace(replace).procedure().stackWidth()
            - replace.mmbr().procedure().stackWidth();

        if (n != 0 && !replace.needBuild)
            throw new Error();

        if (n != 0 || replace.needBuild) {
            if (this.blocks != null && code.blocks == null)
                throw new Error();
            // System.err.println("BEFORE");
            // code.printInstructions(null, System.err);
        }
        if (code == this)
            return code;
        code.replace0(replace);
        return code;
    }

    public void replace0(ReplaceBT replace) {
        int n = replace.mmbr().replace(replace).procedure().stackWidth()
            - replace.mmbr().procedure().stackWidth();

        if (n != 0) {
            this.setMaxLocal(this.maxLocal() + n);
            this.setMaxStack(this.maxStack() + n);
        }
        if (replace.needBuild) {
            ReplaceIns ireplace;
            if (replace instanceof ReplaceIns)
                ireplace = (ReplaceIns) replace;
            else
                ireplace = new ReplaceIns(replace);
            if (this.blocks == null)
                throw new Error("" + replace);

            for (Iterator i = this.blocks.iterator();
                 i.hasNext();
                 /* i = i */) {
                Block b = (Block) i.next();
                b.replace(ireplace);
            }
            // System.err.println("AFTER");
            // code.printInstructions(null, System.err);
        }
    }

    public boolean prepareWriteMember(ClassModel clazz, ShapeKey mmbr) {
        if (this.blocks != null) {
            int pc = 0;
            for (Iterator i = this.blocks.iterator();
                 i.hasNext();
                 /* i = i */) {
                Block b = (Block) i.next();
                b.setPC(pc);
                for (ListIterator j = b.instructions().listIterator();
                     j.hasNext();
                     /* j = j */) {
                    Instruction s = (Instruction) j.next();
                    j.set(s.prepareWrite(pc, clazz, mmbr));
                    pc += s.size0(pc);
                }
                if (b.branch() != null) {
                    b.setBranch(
                        (Branch) b.branch().prepareWrite(pc, clazz, mmbr));
                    pc += b.branch().size0(pc);
                }
            }
            for (Iterator i = this.etable().iterator();
                 i.hasNext();
                 /* i = i */) {
                BTCode.ExceptionEntry e = (BTCode.ExceptionEntry) i.next();
                e.prepareWrite();
            }
        }
        return prepareWriteMemberInternal(clazz, mmbr);
    }

    public void printInstructions(Environment env, PrintStream out) {
        for (Iterator i = this.blocks.iterator(); i.hasNext(); /* i = i */) {
            Block b = (Block) i.next();
            b.print(env, out);
        }
    }

    public void writeMember(DataOutputStream out, ClassModel clazz,
                            ShapeKey mmbr) throws java.io.IOException {
        if (this.blocks != null) {
            int pc = 0;
            ByteArrayOutputStream outBytes = new ByteArrayOutputStream();
            DataOutputStream outCode = new DataOutputStream(outBytes);
            for (Iterator i = this.blocks.iterator();
                 i.hasNext();
                 /* i = i */) {
                Block b = (Block) i.next();
                if (pc != b.getPC())
                    throw new Error();
                for (ListIterator j = b.instructions().listIterator();
                     j.hasNext();
                     /* j = j */) {
                    Instruction s = (Instruction) j.next();
                    s.write(pc, outCode, clazz, mmbr);
                    pc += s.size0(pc);
                    if (pc != outCode.size())
                        throw new Error("size mismatch " + pc + " "
                            + outCode.size() + " last instruction: " + s);
                }
                if (b.branch() != null) {
                    int pc0 = pc;
                    if (outCode.size() != pc0)
                        throw new Error();
                    b.branch().write(pc, outCode, clazz, mmbr);
                    pc += b.branch().size0(pc);
                    if (pc != outCode.size())
                        throw new Error("branch=" + b.branch() + " pc0=" + pc0
                            + " pc=" + pc + " actual=" + outCode.size()
                            + " size=" + b.branch().size0(pc));
                }
            }
            this.setCodeBytes(outBytes.toByteArray());
        }
        /*
         * this will write the exception table and attributes
         */
        writeMemberInternal(out, clazz, mmbr);
    }

    // private Map<Integer,ins.Block> targets = null;
    private Map targets = null;

    public Block findTarget(int i) {
        Block b = (Block) this.targets.get(new Integer(i));
        if (b == null)
            throw new Error();
        return b;
    }

    public void buildInstructions(ClassType clazz, ShapeKey mthd) {
        if (this.blocks != null)
            return;

        this.targets = new HashMap() {
            // public Block get(Integer pc)
            public Object get(Object obj) {
                Integer pc = (Integer) obj;
                if (!this.containsKey(pc)) {
                    this.put(pc, new Block(pc.intValue()));
                }
                return (Block) super.get(pc);
            }
        };
        this.findTarget(0);
        // List<ins.Instruction> instructions = new
        // ArrayList<ins.Instruction>();
        List instructions = new ArrayList();
        for (Iterator i = this.etable().iterator(); i.hasNext(); /* i = i */) {
            BTCode.ExceptionEntry e = (BTCode.ExceptionEntry) i.next();
            e.start = this.findTarget(e.startPC());
            e.end = this.findTarget(e.endPC());
            e.handler = this.findTarget(e.handlerPC());
        }
        for (Iterator i = this.attributes().values().iterator();
             i.hasNext();
             /* i = i */)
            ((BTAttr) i.next()).setBlocks((BTCode) this);

        // SortedMap<Integer,ins.Instruction> map = new
        // TreeMap<Integer,ins.Instruction>();
        SortedMap map = new TreeMap();
        try {
            DataInputStream input = new DataInputStream(
                new ByteArrayInputStream(this.getCodeBytes()));
            int length = input.available();
            while (input.available() > 0) {
                int pc = length - input.available();
                Instruction ins0;
                try {
                    ins0 = Instruction.readInstruction(pc, input,
                        ((TypeModel) clazz).clazz(), mthd);
                } catch (Error e) {
                    System.err.println("error in " + clazz + " " + mthd);
                    throw e;
                }
                map.put(new Integer(pc), ins0);
            }
        } catch (IOException ioe) {
            throw new Error("bad io " + ioe);
        }
        this.blocks = new ArrayList();
        {
            int tcount = 0;
            /* make sure 0 is there */
            Block target = null;

            int icount = 0;
            for (Iterator i = map.keySet().iterator();
                 i.hasNext();
                 /* i = i */) {
                Integer pc = (Integer) i.next();
                if (this.targets.containsKey(pc)) {
                    Block target0 = target;
                    target = (Block) this.targets.get(pc);
                    for (Iterator j = this.etable().iterator();
                         j.hasNext();
                         /* j = j */) {
                        BTCode.ExceptionEntry e =
                            (BTCode.ExceptionEntry) j.next();
                        if (pc.intValue() >= e.startPC()
                            && pc.intValue() < e.endPC())
                            target.exceptions().add(e);
                    }
                    /* target.setPC(tcount); */
                    tcount++;
                    this.blocks.add(target);
                    if (target0 != null && target0.branch() == null) {
                        Branch v = (new Goto()).setTarget(target);
                        target0.setBranch(v); // just keep it null if pass thru
                    }
                    if (target.branch() != null)
                        throw new Error(pc + " " + this.targets);
                }
                if (target == null)
                    throw new Error();
                ((Instruction) map.get(pc)).setPC(icount);
                icount++;
                ((Instruction) map.get(pc)).setBlock(target);
                if (map.get(pc) instanceof Branch) {
                    target.setBranch((Branch) map.get(pc));
                } else {
                    target.instructions().add(map.get(pc));
                }
            }
        }
        this.targets = null;
    }

    public List instructions(ClassModel clazz, ShapeKey mthd) {
        if (this.blocks == null)
            this.buildInstructions(clazz.newType(), mthd);
        return this.blocks;
    }

    public static void main(String[] args) throws IOException {
        Environment env = ModelRoot.CLASSPATH;
        ModelRoot from;
        if (args[0].endsWith(".jar"))
            from = new JarModelRoot(new File(args[0])) {};
        else
            from = new DirModelRoot(new File(args[0])) {};
        env = env.addRoot(from);
        from.setEnvironment(env);
        if (from.env() != env)
            throw new Error("whats up with that: " + from + " " + env);

        PackageModel pkg = (PackageModel) from.packages().get(
            new PackageName(args[1]));
        ClassModel clazz = (ClassModel) pkg.classes().get(
            new ClassName(args[2]));
        System.err.println(clazz);

        ShapeKey key = (new ShapeKey()).set(
            (new NameTypeShape()).setName(new MemberName("foo")).setType(
                TypeConstants.VOID)).set(
            new ProcedureShape().addArg(TypeConstants.INT));

        ShapeKey toKey = key.set(key.procedure().addArg(TypeConstants.INT));

        MethodShape mthd = clazz.newType().shape().actualMethod(key);
        System.err.println(mthd);

        ReplaceIns replace = new ReplaceIns();
        NullModelRoot copy = new NullModelRoot() {};
        replace.map(from, copy);
        replace.map(clazz.newType(), key, toKey);
        // replace.set(clazz.newType());
        System.err.println(replace);

        from.replace0(copy, replace);
        from.replace1(copy, replace);

        JarOutputStream jar = new JarOutputStream(new FileOutputStream(args[3]
            + ".jar"));
        JarModelSaver saver = new JarModelSaver(jar);
        saver.save(copy);
        saver.close();
        jar.close();
    }

    public static void main0(String[] args) throws IOException {
        Environment env = ModelRoot.CLASSPATH;
        ModelRoot from;
        if (args[0].endsWith(".jar"))
            from = new JarModelRoot(new File(args[0])) {};
        else
            from = new DirModelRoot(new File(args[0])) {};
        env = env.addRoot(from);
        from.setEnvironment(env);
        if (from.env() != env)
            throw new Error("whats up with that: " + from + " " + env);

        PackageModel pkg = (PackageModel) from.packages().get(
            new PackageName(args[1]));
        ClassModel clazz = (ClassModel) pkg.classes().get(
            new ClassName(args[2]));

        System.out.println(clazz);
        for (Iterator i = clazz.body().methods().keySet().iterator();
             i.hasNext();
             /* i = i */) {
            ShapeKey mthd = (ShapeKey) i.next();
            MemberShape mbr = clazz.newType().shape().actual(mthd);
            BTMethod m = (BTMethod) clazz.body().methods().get(mthd);
            System.out.println("*********** " + mbr.javaSource(""));
            if (m.attributes().containsKey(BTAttr.CODE)) {
                BTCode code = (BTCode) m.attributes().get(BTAttr.CODE);
                code.buildInstructions(clazz.newType(), mthd);
                System.out.println(code);
                code.doDFA(clazz, mbr, env);
                code.setDominators();
                // System.out.println(code.etable());
                code.printInstructions(env, System.out);
                System.out.println();
                System.err.println("start control flow");
                code.doControlFlow();
                System.out.println("*********** " + code.head());
                code.head().print(System.out);
            }
        }
    }

    public void doDFA(ClassModel clazz, MemberShape mthd, Environment env) {
        // Set<ins.Block> dirty = new HashSet<ins.Block>();
        Set dirty = new HashSet();
        /* initialize first machine */
        for (Iterator i = this.blocks.iterator(); i.hasNext(); /* i = i */)
            ((Block) i.next()).clearDFAState();
        {
            Block head = (Block) this.blocks.get(0);
            head.locals = new ArrayList();
            head.stack = new LinkedList();
            int i = 0;
            /* set the arguments */
            if (!mthd.binaries().contains(FlagConstants.STATIC)) {
                Value.This ths = new Value.This(clazz);
                ths.block = head;
                head.locals.add(ths);
                i++;
            }
            for (int j = 0; j < mthd.procedure().args().size(); j++) {
                ArgShape arg = (ArgShape) mthd.procedure().args().get(j);
                Value.Arg varg = new Value.Arg(j, arg);
                varg.block = head;
                head.locals.add(varg);
                i++;
            }
            // XXX: ENE, May 17 2005: is the "i = i" really right? "i = 0"?
            for (/* i = i */; i < this.maxLocal(); i++) {
                head.locals.add(Value.ERROR);
            }
            if (head.locals.size() != this.maxLocal())
                throw new Error();
            /* stack is empty */
            dirty.add(head);
        }
        Machine m = new Machine(env);
        while (!dirty.isEmpty()) {
            Block block;
            {
                Iterator i = dirty.iterator();
                block = (Block) i.next();
                i.remove();
            }
            m.init(block);
            m.isStore = true;
            for (Iterator i = block.instructions().iterator();
                 i.hasNext();
                 /* i = i */) {
                Instruction v = (Instruction) i.next();
                if (m.isStore) {
                    for (Iterator j = block.exceptions().iterator();
                         j.hasNext();
                         /* j = j */) {
                        BTCode.ExceptionEntry e =
                            (BTCode.ExceptionEntry) j.next();
                        if (e.handler == null)
                            throw new Error("how can this be null: " + e);
                        if (e.value().exc != e)
                            throw new Error("WTF? " + e.hashCode() + " "
                                + e.value().hashCode() + " "
                                + e.value().exc.hashCode());
                        if (e.value().exc.handler == null)
                            throw new Error("WTF?");
                        Machine m0 = m.copy();
                        m0.stack.clear();
                        m0.push(e.value());
                        if (m0.mergeInto(block, e.handler))
                            dirty.add(e.handler);
                    }
                }
                m.isStore = false;
                v.args().clear();
                v.execute(m);
            }
            if (block.branch() != null) {
                block.branch().args().clear();
                block.branch().execute(m);
            }
            for (Iterator i = block.branches().iterator();
                 i.hasNext();
                 /* i = i */) {
                Block mergeTo = (Block) i.next();
                try {
                    if (m.mergeInto(block, mergeTo))
                        dirty.add(mergeTo);
                } catch (Error e) {
                    System.err.println(block + " " + m + " "
                        + mergeTo.dfaString() + " " + m);
                    throw e;
                }
            }
        }
        for (Iterator i = this.blocks.iterator(); i.hasNext(); /* i = i */) {
            Block b = (Block) i.next();
            if (b.stack == null) {
                System.err.println("REMOVING DEAD CODE: " + b);
                b.print(null, System.err);
                i.remove();
            }
        }
    }

    public void setDominators() {
        // Map<ins.Block,HashSet<ins.Block>> doms = new
        // HashMap<ins.Block,HashSet<ins.Block>>();
        Map doms = new HashMap();
        for (Iterator i = this.blocks.iterator(); i.hasNext(); /* i = i */)
            doms.put((Block) i.next(), new HashSet());
        // Set<ins.Block> dirty = new HashSet<ins.Block>();
        Set dirty = new HashSet();
        dirty.add(this.blocks.get(0));
        while (!dirty.isEmpty()) {
            Block b;
            {
                Iterator i = dirty.iterator();
                b = (Block) i.next();
                i.remove();
            }
            // HashSet<ins.Block> set = doms.get(b);
            // Iterator<ins.Block> i = b.branches().iterator();
            // Iterator<bt.Code.ExceptionEntry> j = b.exceptions().iterator();
            HashSet set = (HashSet) doms.get(b);
            Iterator i = b.branches().iterator();
            Iterator j = b.exceptions().iterator();
            while (true) {
                Block t;
                if (i.hasNext())
                    t = (Block) i.next();
                else if (j.hasNext())
                    t = ((BTCode.ExceptionEntry) j.next()).handler;
                else
                    break;

                if (t == this.blocks.get(0))
                    continue;
                if (t == b)
                    continue; /* cannot dominate yourself! */
                if (set.contains(t)) /* detected backwards branch */
                    continue;
                // HashSet<ins.Block> set0 = doms.get(t);
                HashSet set0 = (HashSet) doms.get(t);
                if (set0.isEmpty()) {
                    set0.add(b);
                    set0.addAll(set);
                    dirty.add(t);
                } else if (set0.contains(b)) {
                    if (set.size() + 1 == set0.size()) {
                        if (!set0.containsAll(set))
                            throw new Error(set + " vs. " + set0);
                    } else {
                        // Set<ins.Block> set1 = new HashSet<ins.Block>(set0);
                        set0.retainAll(set);
                        // if (set0.equals(set)) throw new Error(set + " vs. " +
                        // set1 + " " + b + " " + t);
                        set0.add(b);
                        dirty.add(t);
                    }
                } else {
                    if (set0.retainAll(set))
                        dirty.add(t);
                }
            }
        }
        // Set<ins.Block> idoms = new HashSet<ins.Block>();
        Set idoms = new HashSet();
        idoms.add(this.blocks.get(0));
        doms.remove(this.blocks.get(0));
        while (true) {
            Block b;
            {
                Iterator i = idoms.iterator();
                b = (Block) i.next();
                i.remove();
            }
            for (Iterator i = doms.keySet().iterator();
                 i.hasNext();
                 /* i = i */) {
                Block b0 = (Block) i.next();
                HashSet set = (HashSet) doms.get(b0);
                if (!set.contains(b))
                    continue;
                if (set.size() == 1) {
                    b0.setDominator(b);
                    i.remove();
                    idoms.add(b0);
                } else {
                    set.remove(b);
                }
            }
            if (doms.keySet().isEmpty())
                break;
            if (idoms.isEmpty() && !doms.keySet().isEmpty())
                throw new Error(doms + " not empty");
        }
    }

    public void doControlFlow() {
        this.root = new Root((Block) this.blocks.get(0));
        this.root.process();
    }
}
