/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.bytecode outclazz.Main */

package edu.utah.jiggy.clazz;

import java.util.*;

import edu.utah.jiggy.meta.shape.ClassShape;
import edu.utah.jiggy.meta.shape.ShapeKey;
import edu.utah.jiggy.meta.type.ClassType;
import edu.utah.jiggy.meta.type.Environment;

public class Main {
    public static void main(java.lang.String[] args) {
        Environment env = ModelRoot.CLASSPATH;
        ClassModel clazz = ((TypeModel) env.findVMClass(args[0])).clazz();
        ClassType ctype = clazz.newType();

        System.out.println("package " + clazz.pkg());
        System.out.print(clazz.shape().access() + " " + clazz.shape().virtual()
            + " " + clazz.shape().binaries());
        System.out.print(" " + clazz.name().base());
        System.out.print(" extends " + ctype.shape().zuper());
        System.out.println(" implements " + ctype.shape().interfaces() + " {");
        for (Iterator i = ctype.shape().fields().iterator();
             i.hasNext();
             /* i = i */)
            System.out.println("  "
                + ctype.shape().actualField(((ShapeKey) i.next())).javaSource(
                    clazz.name().base().javaSource()));
        for (Iterator i = ctype.shape().methods().iterator();
             i.hasNext();
             /* i = i */)
            System.out.println("  "
                + ctype.shape().actualMethod(((ShapeKey) i.next())).javaSource(
                    clazz.name().base().javaSource()));
        for (Iterator i = ctype.shape().inits().iterator();
             i.hasNext();
             /* i = i */)
            System.out.println("  "
                + ctype.shape().actualInit(((ShapeKey) i.next())).javaSource(
                    clazz.name().base().javaSource()));
        System.out.println("}");
        System.out.println();

        clazz.shape().verify(System.err);
        ClassShape shape = clazz.shape().collapse(new HashSet());
        ClassType ctype0 = ctype.setShape(shape);

        System.out.println("{");
        for (Iterator i = ctype0.shape().fields().iterator();
             i.hasNext();
             /* i = i */)
            System.out.println("  "
                + ctype0.shape().actualField(((ShapeKey) i.next())).javaSource(
                    clazz.name().base().javaSource()));
        for (Iterator i = ctype0.shape().methods().iterator();
             i.hasNext();
             /* i = i */)
            System.out.println("  "
                + ctype0.shape().actualMethod(((ShapeKey) i.next()))
                    .javaSource(clazz.name().base().javaSource()));
        for (Iterator i = ctype0.shape().inits().iterator();
             i.hasNext();
             /* i = i */)
            System.out.println("  "
                + ctype0.shape().actualInit(((ShapeKey) i.next())).javaSource(
                    clazz.name().base().javaSource()));
        System.out.println("}");
    }

    public Main() {
    }
}
