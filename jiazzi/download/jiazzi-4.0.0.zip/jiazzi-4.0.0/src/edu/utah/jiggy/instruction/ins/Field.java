/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.bytecode.ins outins.Field */

package edu.utah.jiggy.instruction.ins;

import java.io.*;

import edu.utah.jiggy.bytecode.bt.BTFieldRef;
import edu.utah.jiggy.bytecode.bt.BTMemberRef;
import edu.utah.jiggy.clazz.ClassModel;
import edu.utah.jiggy.meta.shape.ShapeKey;
import edu.utah.jiggy.meta.type.Environment;
import edu.utah.jiggy.meta.type.TypeType;

public abstract class Field extends Ref {
    static void activate() {
        for (int i = 0; i < 2; i++) {
            (new Field.Get(i == 0)).put00();
            (new Field.Put(i == 0)).put00();
        }
    }

    protected BTFieldRef fref;
    protected final boolean isStatic;

    public Field(boolean isStatic) {
        this.isStatic = isStatic;
    }

    protected abstract boolean isGet();

    protected boolean isStatic() {
        return this.isStatic;
    }

    public Field setField(BTFieldRef fref) {
        if (fref == this.fref)
            return (Field) this;
        Field copy = (Field) this.copy();
        copy.fref = fref;
        return copy;
    }

    public BTFieldRef field() {
        return this.fref;
    }

    public BTMemberRef member() {
        return this.field();
    }

    public int opcode() {
        return 178 + ((this.isStatic ? 0 : 1) * 2) + (this.isGet() ? 0 : 1);
    }

    public String mnemonic() {
        return (this.isGet() ? "get" : "put")
            + (this.isStatic ? "static" : "field");
    }

    public String toString() {
        return super.toString() + " " + this.fref;
    }

    public int baseHashCode() {
        return super.baseHashCode()
            + (this.fref == null ? 0 : this.fref.hashCode());
    }

    public boolean baseEquals(Instruction ins0) {
        if (!super.baseEquals(ins0))
            return false;
        Field ins = (Field) ins0;
        if (ins.fref == null || this.fref == null)
            return ins.fref == this.fref;
        else
            return ins.fref.equals(this.fref);
    }

    public Instruction read(int pc, DataInputStream input, ClassModel clazz,
                            ShapeKey mthd) throws IOException {
        Field copy = (Field) super.read(pc, input, clazz, mthd);
        return copy.setField(
            clazz.body().pool().get(input.readUnsignedShort()).fref());
    }

    public Instruction prepareWrite(int pc, ClassModel clazz, ShapeKey mthd) {
        int index = clazz.body().pool().allocField(this.fref);
        return super.prepareWrite(pc, clazz, mthd);
    }

    public void write(int pc, DataOutputStream out, ClassModel clazz,
                      ShapeKey mthd) throws IOException {
        super.write(pc, out, clazz, mthd);
        out.writeShort(clazz.body().pool().allocField(this.fref));
    }

    public Instruction replace(ReplaceIns replace) {
        Instruction copy = super.replace(replace);
        if (copy != this)
            return copy;
        else
            return this.setField(this.fref.replace(replace));
    }

    public int argCount() {
        return (this.isStatic() ? 0 : 1);
    }

    public void execute(Machine m) {
        if (!this.isStatic()) {
            Value object = m.pop();
            m.doError(object.type(m.context).isa(this.fref.clazz()));
            this.args().add(object);
        }
    }

    public static class Get extends Field {
        public void execute(Machine m) {
            super.execute(m);
            m.push(this);
        }

        public boolean isGet() {
            return true;
        }

        public Get(boolean isStatic) {
            super(isStatic);
        }

        public TypeType type(Environment env) {
            return this.fref.member().nameType().type();
        }
    }

    public static class Put extends Field {

        public boolean isGet() {
            return false;
        }

        public Put(boolean isStatic) {
            super(isStatic);
        }

        public int argCount() {
            return super.argCount() + 1;
        }

        public void execute(Machine m) {
            Value put = m.pop();
            super.execute(m);
            this.args().add(put);
            m.doError(put.type(m.context).isa(
                this.fref.member().nameType().type()));
        }
    }
}
