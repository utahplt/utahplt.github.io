/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.bytecode.ins outins.Method */

package edu.utah.jiggy.instruction.ins;

import java.util.*;
import java.io.*;

import edu.utah.jiggy.bytecode.bt.BTMemberRef;
import edu.utah.jiggy.bytecode.bt.BTMethodRef;
import edu.utah.jiggy.clazz.ClassModel;
import edu.utah.jiggy.meta.flag.FlagConstants;
import edu.utah.jiggy.meta.shape.ArgShape;
import edu.utah.jiggy.meta.shape.MemberShape;
import edu.utah.jiggy.meta.shape.NameTypeShape;
import edu.utah.jiggy.meta.shape.ShapeKey;
import edu.utah.jiggy.meta.type.ClassType;
import edu.utah.jiggy.meta.type.Environment;
import edu.utah.jiggy.meta.type.TypeConstants;
import edu.utah.jiggy.meta.type.TypeType;

public abstract class Method extends Ref {
    protected BTMethodRef mref;

    /*
     * public int argCount() { return
     * this.mref.member().procedure().args().size() + (this instanceof Static ?
     * 0 : 1); }
     */

    public void execute(Machine m) {
        // List<shape.Arg> margs = this.mref.member().procedure().args();
        List margs = this.mref.member().procedure().args();

        Value[] args = new Value[margs.size()];
        for (int i = 0; i < margs.size(); i++) {
            int j = args.length - i - 1;
            args[j] = m.pop();
            TypeType atype =
                ((ArgShape) margs.get(margs.size() - i - 1)).type();
            m.doError(args[j].type(m.context).isa(atype), "" + atype);
        }

        if (!(this instanceof Static)) {
            Value object = m.pop();
            m.doError(object.type(m.context).isa(this.mref.clazz()));
            this.args().add(object);
        }
        for (int i = 0; i < args.length; i++)
            this.args().add(args[i]);
        if (this.mref.member().nameType().type() != TypeConstants.VOID)
            m.push(this);

    }

    public TypeType type(Environment env) {
        return this.mref.member().nameType().type();
    }

    static void activate() {
        (new Method.Virtual()).put00();
        (new Method.Static()).put00();
        (new Method.Special()).put00();
        (new Method.Interface()).put00();
    }

    public Method setMethod(BTMethodRef mref) {
        Method copy = (Method) this.copy();
        copy.mref = mref;
        return copy;
    }

    public BTMethodRef method() {
        return this.mref;
    }

    public BTMemberRef member() {
        return this.method();
    }

    public Method() {
        super();
    }

    public String toString() {
        return super.toString() + " " + this.mref;
    }

    public int baseHashCode() {
        return super.baseHashCode()
            + (this.mref == null ? 0 : this.mref.hashCode());
    }

    public boolean baseEquals(Instruction ins0) {
        if (!super.baseEquals(ins0))
            return false;
        Method ins = (Method) ins0;
        if (ins.mref == null || this.mref == null)
            return ins.mref == this.mref;
        else
            return ins.mref.equals(this.mref);
    }

    public Instruction read(int pc, DataInputStream input, ClassModel clazz,
                            ShapeKey mthd) throws IOException {
        Method copy = (Method) super.read(pc, input, clazz, mthd);
        return copy.setMethod(
            clazz.body().pool().get(input.readUnsignedShort()).mref());
    }

    public Instruction prepareWrite(int pc, ClassModel clazz, ShapeKey mthd) {
        int index = clazz.body().pool().allocMethod(
            this.mref,
            this instanceof Method.Interface);

        if (false && this instanceof Special
            && this.mref.member().nameType() != NameTypeShape.EMPTY)
            System.err.println("prepare " + clazz.pkg().root() + " "
                + clazz.name() + " " + mthd + " " + this + " " + index);
        return super.prepareWrite(pc, clazz, mthd);
    }

    public void write(int pc, DataOutputStream out, ClassModel clazz,
                      ShapeKey mthd) throws IOException {
        super.write(pc, out, clazz, mthd);
        out.writeShort(
            clazz.body().pool().allocMethod(
                this.mref,
                this instanceof Method.Interface));
    }

    public Instruction replace(ReplaceIns replace) {
        Instruction copy = super.replace(replace);
        if (copy != this)
            return copy;
        BTMethodRef mref = this.mref.replace(replace);

        if (false) {
            if (this.mref.member().nameType().name().javaSource()
                    .equals("loadAll")) {
                System.err.println("0 REPLACE " + this.mref + " -> "
                    + ((Method) copy).mref + " " + copy);
            }
        }

        if (mref != this.mref) {
            ClassType fresh =
                replace.clazz().shape().freshMethod(replace.mmbr().key());
            if (fresh == null) {
                if (false)
                    throw new Error(replace.clazz() + " "
                        + replace.mmbr().key());
                fresh = replace.clazz();
            }
            MemberShape mmbr = replace.mmbr().replace(replace, fresh);

            boolean printit = false;

            while (true) {
                if (mmbr.key().nameType() != NameTypeShape.EMPTY)
                    break;
                if (mmbr.key().equals(mref.member()) && this instanceof Special)
                    break;
                if (replace.clazz().isa(this.mref.clazz()))
                    break;
                if (!replace.clazz().isShapeSet())
                    break;
                if (replace.clazz().shape().zuper() != this.mref.clazz())
                    break;
                if (!mref.clazz().isShapeSet())
                    break;
                if (!mref.clazz().shape().actualMethod(mref.member())
                        .isSet(FlagConstants.PRIVATE))
                    break;
                /* do the right target */
                if (replace.clazz().shape().zuper() == null)
                    throw new Error();
                mref = (BTMethodRef) mref.setClass(
                    (ClassType) replace.clazz().shape().zuper().replace(replace));
                if (false)
                    System.err.println(replace.clazz().pkg0().root0() + " "
                        + replace.clazz().name() + " " + this.mref + " -> "
                        + mref);
                printit = true;
                break;
            }
            copy = this.setMethod(mref);
            if (false) {
                if (this.mref.member().nameType().name().javaSource()
                        .equals("loadAll")) {
                    System.err.println("1 REPLACE " + this.mref + " -> "
                        + ((Method) copy).mref + " " + copy);
                }
            }

            int n = mref.member().procedure().stackWidth()
                - this.mref.member().procedure().stackWidth();

            int m = mmbr.procedure().stackWidth()
                - replace.mmbr().procedure().stackWidth();

            int k = this.mref.member().procedure().stackWidth();
            int j = replace.mmbr().procedure().stackWidth();

            if (!replace.mmbr().isSet(FlagConstants.STATIC))
                j += 1;
            if (n != 0 && n != m)
                throw new Error("caller=" + replace.clazz() + "."
                    + replace.mmbr().key() + " -> " + mmbr.key() + " "
                    + "callee=" + this.mref + " -> " + mref + " "
                    + replace.clazz() + " vs. " + fresh);
            if (n != 0) {
                Instruction.Multi multi = new Instruction.Multi();
                for (int i = 0; i < n; i++) {
                    ArgShape arg =
                        (ArgShape) mref.member().procedure().args().get(k + i);
                    // get all the new arguments....hope no doubles or longs!
                    multi.list.add(
                        (new Local.Load(TypeInfo.get(arg.type())))
                        .setIndex(j + i));
                }
                multi.list.add(copy);
                // if (printit) System.err.println("INSERTING " + multi.list);
                return multi;
            }
        }
        return copy;
    }

    public static class Static extends Method {
        public int opcode() {
            return 184;
        }

        public java.lang.String mnemonic() {
            return "invokestatic";
        }

        public Static() {
            super();
        }
    }

    public static class Virtual extends Method {
        public int opcode() {
            return 182;
        }

        public java.lang.String mnemonic() {
            return "invokevirtual";
        }

        public Virtual() {
            super();
        }
    }

    public static class Interface extends Method.Virtual {
        public int opcode() {
            return 185;
        }

        public java.lang.String mnemonic() {
            return "invokeinterface";
        }

        protected int size() {
            return 5;
        }

        public Instruction read(int pc, DataInputStream input,
                                ClassModel clazz, ShapeKey mthd)
                throws IOException {
            Method.Interface ins =
                (Method.Interface) super.read(pc, input, clazz, mthd);
            int count = input.readUnsignedByte();
            if (count == 0)
                throw new Error("must have at least this!");
            // if (count != this.count()) throw new Error(this + " " + count + "
            // " + this.count());
            if (input.readUnsignedByte() != 0)
                throw new Error();
            return ins;
        }

        public String toString() {
            return super.toString() + " [" + this.count() + "]";
        }

        int count() {
            return this.mref.member().procedure().stackWidth() + 1;
        }

        public void write(int pc, DataOutputStream out, ClassModel clazz,
                          ShapeKey mthd) throws IOException {
            super.write(pc, out, clazz, mthd);
            out.writeByte(this.count());
            out.writeByte(0);
        }

        public Interface() {
            super();
        }
    }

    public static class Special extends Method {
        public int opcode() {
            return 183;
        }

        public void execute(Machine m) {
            super.execute(m);
            if (this.mref.member().nameType() == NameTypeShape.EMPTY) {
            }
        }

        public java.lang.String mnemonic() {
            return "invokespecial";
        }

        public Special() {
            super();
        }
    }
}
