/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package edu.utah.jiggy.clazz;

import java.io.DataInputStream;
import java.io.IOException;

import edu.utah.jiggy.bytecode.bt.BTClass;
import edu.utah.jiggy.bytecode.bt.ReplaceBT;
import edu.utah.jiggy.meta.name.ClassName;
import edu.utah.jiggy.meta.shape.ClassShape;
import edu.utah.jiggy.meta.type.ClassType;

public class ClassModel extends Object {
    protected final PackageModel pkg;
    protected final ClassName name;
    protected ClassShape shape;

    public void setShape(ClassShape shape) {
        this.shape = shape;
    }

    public ClassShape shapeInternal() {
        if (this.shape == null)
            throw new Error("shape not set for " + this);
        return this.shape;
    }

    public boolean isShapeSetInternal() {
        return this.shape != null;
    }

    public ClassModel(PackageModel pkg, ClassName name) {
        if (name.pkg() != null)
            throw new Error();
        this.name = name;
        this.pkg = pkg;
        if (((PackageModel) pkg).classes.put(name, (ClassModel) this) != null)
            throw new Error("class " + name + " already exists in " + pkg);
    }

    public ClassName name0() {
        return this.name;
    }

    public ClassType newType() {
        TypeModel ctype = new TypeModel() {};
        ctype.clazz = (ClassModel) this;
        return ctype;
    }

    public PackageModel pkg() {
        return this.pkg;
    }

    public ClassName name() {
        return this.name0().setPackage(this.pkg.name());
    }

    public String toString() {
        return this.pkg + "." + this.name0();
    }

    public ClassModel outer() {
        if (this.name0().outer() == null)
            return null;
        else
            return (ClassModel) this.pkg().classes().get(this.name0().outer());
    }

    // Below here,
    // From `edu.utah.jiggy.bytecode/outclazz/Class.java'.

    protected BTClass body;
    protected boolean isUnnamed;

    public void setCastThis() {

    }

    public BTClass body() {
        if (!this.isBodySet()) {
            if (!isShapeSetInternal()) {
                try {
                    DataInputStream in = this.pkg().root().readClass(
                        (ClassModel) this);
                    BTClass body = new BTClass();
                    ClassShape bld = new ClassShape();
                    this.setBody(body);
                    this.setShape(bld);
                    body.read(in, (ClassModel) this, bld);
                    ReplaceBT replace = new ReplaceBT();
                    // body.gjReplace((TypeModel) this.newType(), bld, replace);
                    replace.set(this.newType());

                    this.setShape(bld.replace(replace));
                    this.setBody(body.replace(bld, replace));
                } catch (IOException ioe) {
                    ioe.printStackTrace();
                    throw new Error("" + ioe);
                } catch (Error e) {
                    System.err.println("error loading "
                        + this.newType().javaSource() + " from "
                        + this.pkg().root());
                    throw e;
                } catch (RuntimeException e) {
                    System.err.println("error loading "
                        + this.newType().javaSource() + " from "
                        + this.pkg().root());
                    throw e;
                }
            } else {
                BTClass body = new BTClass((ClassModel) this);
                this.setBody(body);
            }
        }
        return this.body;
    }

    public ClassShape shape() {
        if (!isShapeSetInternal()) {
            if (this.isBodySet())
                throw new Error("huh? " + this);
            this.body(); /* will load shape */
            if (!isShapeSetInternal())
                throw new Error("huh? " + this);
        }
        return shapeInternal();
    }

    public boolean isShapeSet() {
        if (isShapeSetInternal())
            return true;
        if (this.pkg().root() instanceof NullModelRoot)
            return false;
        return true;
    }

    public void setBody(BTClass a0) {
        this.body = a0;
    }

    public boolean isBodySet() {
        return this.body != null;
    }

    public boolean isUnnamed() {
        return this.isUnnamed;
    }

    public void setUnnamed() {
        this.isUnnamed = true;
    }

    private String internalName(ClassName clazz) {
        if (clazz.outer() != null)
            return internalName(clazz.outer()) + '$'
                + clazz.base().javaSource();
        else
            return clazz.pkg().javaSource().replace('.', '/') + '/'
                + clazz.base().javaSource();
    }

    public String internalName() {
        return this.internalName(this.name());
    }
}
