/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.bytecode.ins outins.Goto */

package edu.utah.jiggy.instruction.ins;

import java.io.*;
import java.util.*;

import edu.utah.jiggy.bytecode.bt.BTMethod;
import edu.utah.jiggy.clazz.ClassModel;
import edu.utah.jiggy.meta.shape.ShapeKey;

public class Goto extends Branch {
    protected Block target;

    public Branch updateBranch(Map map) {
        Goto copy = (Goto) super.updateBranch(map);
        if (!map.containsKey(this.target))
            return copy;
        if (copy == this)
            copy = (Goto) this.copy();
        copy.target = (Block) map.get(this.target);
        return copy;
    }

    static void activate() {
        (new Goto()).put00();
        (new Goto.Wide()).put00();
    }

    public Iterator targets() {
        return new Iterator() {
            boolean next = true;

            public boolean hasNext() {
                return this.next;
            }

            public Object next() {
                if (!this.next)
                    throw new Error();
                this.next = false;
                return Goto.this.target;
            }

            public void remove() {
                throw new Error();
            }
        };
    }

    public String mnemonic() {
        return "goto";
    }

    public String toString() {
        return super.toString() + " " + this.target;
    }

    public int baseHashCode() {
        return super.baseHashCode()
            + (this.target == null ? 0 : this.target.hashCode());
    }

    public boolean baseEquals(Instruction ins0) {
        return super.baseEquals(ins0) && (((Goto) ins0).target == this.target);
    }

    public Goto setTarget(Block target) {
        Goto copy = (Goto) this.copy();
        copy.target = target;
        return copy;
    }

    public int opcode() {
        return 167;
    }

    public Block target() {
        return this.target;
    }

    public Goto() {
        super();
    }

    protected int size() {
        return 3;
    }

    public Instruction read(int pc, DataInputStream input, ClassModel clazz,
                            ShapeKey mthd) throws IOException {
        Goto copy = (Goto) super.read(pc, input, clazz, mthd);
        return copy.setTarget(
            ((BTMethod) clazz.body().methods().get(mthd)).code()
            .findTarget(pc + input.readShort()));
    }

    public Instruction readWide(int pc, DataInputStream input,
                                ClassModel clazz, ShapeKey mthd)
            throws IOException {
        Goto copy = (Goto) super.readWide(pc, input, clazz, mthd);
        return this.setTarget(
            ((BTMethod) clazz.body().methods().get(mthd)).code()
            .findTarget(pc + input.readInt()));
    }

    public void write(int pc, DataOutputStream out, ClassModel clazz,
                      ShapeKey mthd) throws IOException {
        super.write(pc, out, clazz, mthd);
        out.writeShort(this.target().offset(pc));
    }

    public void writeWide(int pc, DataOutputStream out, ClassModel clazz,
                          ShapeKey mthd) throws IOException {
        super.writeWide(pc, out, clazz, mthd);
        out.writeInt(this.target().offset(pc));
    }

    /* atom-edu.utah.jiggy.bytecode.ins outins.Goto.Wide */
    public static class Wide extends Goto {
        public Wide() {
            super();
        }

        public int opcode() {
            return 200;
        }

        public String mnemonic() {
            return "goto_w";
        }

        protected int size() {
            return 5;
        }

        public boolean isWide() {
            return true;
        }

        public Instruction read(int pc, DataInputStream input,
                                ClassModel clazz, ShapeKey mthd)
                throws IOException {
            throw new Error("isWide");
        }

        public void write(int pc, DataOutputStream out, ClassModel clazz,
                          ShapeKey mthd) throws IOException {
            throw new Error("isWide");
        }
    }
}
