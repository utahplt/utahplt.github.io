/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package edu.utah.jiggy.meta.type;

import java.util.HashMap;
import java.util.Map;

import edu.utah.jiggy.instruction.ins.Machine;
import edu.utah.jiggy.instruction.ins.TypeInfo;

public abstract class TypeType implements Cloneable, TypeConstants {
    public TypeType() {
        super();
    }

    public ArrayType up() {
        return new ArrayType((TypeType) this, 1);
    }

    public String javaSource() {
        return "<error>";
    }

    public String toString() {
        return this.javaSource();
    }

    public String defaultValue() {
        throw new Error();
    }

    public TypeType replace(ReplaceType replace) {
        return replace.get((TypeType) this);
    }

    public int hashCode() {
        return 0;
    }

    public boolean equals(Object o) {
        if (!(o instanceof TypeType))
            return false;
        else
            return this.equals((TypeType) o);
    }

    public boolean equals(TypeType type) {
        return true;
    }

    public boolean reverseEquals(TypeType type) {
        return false;
    }

    /*
     * public boolean matches(TypeType type) { return this.equals(type); }
     */
    public String dbgString() {
        return this.toString();
    }

    public boolean isa(TypeType type) {
        if (this == type || this.equals(type))
            return true;
        else
            return false;
    }

    public TypeType copy() {
        try {
            return (TypeType) this.clone();
        } catch (Throwable t) {
            t.printStackTrace();
            throw new Error();
        }
    }

    // Below here,
    // From `edu.utah.jiggy.bytecode/outtype/Type.java'.

    // static final Map<Character,type.Primitive> primitives =
    // new HashMap<Character,type.Primitive>();
    static final Map primitives = new HashMap();

    static {
        TypeType tp = TypeConstants.VOID;
    }

    public String jvmTypeString() {
        throw new Error();
    }

    public String gjTypeString() {
        return this.jvmTypeString();
    }

    public static interface Rest {
        public Object doit(TypeType type, String string, Environment env);
    }

    public static TypeType parseJvmType(String string, Environment env) {
        return (TypeType) parseJvmType(string, env, new Rest() {
            public Object doit(TypeType type, String string, Environment env) {
                if (string.length() != 0)
                    throw new Error("still " + string + " left after parsing "
                        + type);
                return type;
            }
        });
    }

    // public static <A> A parseJvmType(String string, type.Environment env,
    // final Type.Rest<A> rest) {
    public static Object parseJvmType(String string, Environment env,
                                      final Rest rest) {
        if (primitives.containsKey(new Character(string.charAt(0))))
            return rest.doit(
                (TypeType) primitives.get(new Character(string.charAt(0))),
                string.substring(1, string.length()),
                env);
        else if (string.charAt(0) == '[')
            return parseJvmType(
                string.substring(1, string.length()),
                env,
                new Rest() {
                    public Object doit(TypeType type, String string,
                                       Environment env) {
                        return rest.doit(type.up(), string, env);
                    }
                });
        else if (string.charAt(0) == 'L') {
            int part = string.indexOf(';');
            if (string.indexOf('<') != -1 && string.indexOf('<') < part)
                part = string.indexOf('<');
            final ClassType clazz = env.findVMClass(string.substring(1, part));
            final String orig = string;
            if (string.charAt(part) == '<') {
                return parseJvmType(
                    string.substring(part + 1, string.length()),
                    env,
                    new Rest() {
                        ClassType clazz0 = clazz;

                        public Object doit(TypeType type, String string,
                                           Environment env) {
                            this.clazz0 = this.clazz0.addParam((RefType) type);
                            if (string.length() == 0)
                                throw new Error("missing >; in \"" + orig
                                    + "\"");

                            if (string.charAt(0) == '>') {
                                if (string.charAt(1) != ';')
                                    throw new Error(string + " malformed");
                                return rest.doit(
                                    this.clazz0,
                                    string.substring(2, string.length()),
                                    env);
                            } else {
                                return TypeType.parseJvmType(string, env, this);
                            }
                        }
                    });
            } else
                return rest.doit(
                    clazz,
                    string.substring(string.indexOf(';') + 1, string.length()),
                    env);
        } else if (string.charAt(0) == 'T') {
            return rest.doit(
                env.findTypeVariable(string.substring(1, string.indexOf(';'))),
                string.substring(string.indexOf(';') + 1, string.length()),
                env);
        } else
            throw new Error("do not recognize \"" + string + "\" as type");
    }

    // Below here,
    // From `edu.utah.jiggy.instruction/outtype/Type.java'.

    public int stackWidth() {
        return 1;
    }

    public TypeInfo localTypeInfo() {
        throw new Error();
    }

    public boolean isa(TypeInfo type) {
        return this.localTypeInfo().isa(type);
    }

    public TypeType merge(TypeType t, Machine m) {
        if (this == t)
            return t;
        else
            return TypeConstants.ERROR;
    }
}
