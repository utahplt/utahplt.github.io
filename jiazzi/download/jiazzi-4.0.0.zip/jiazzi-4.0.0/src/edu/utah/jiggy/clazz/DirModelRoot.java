/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package edu.utah.jiggy.clazz;

import java.io.*;

import edu.utah.jiggy.meta.name.ClassName;
import edu.utah.jiggy.meta.name.PackageName;

public class DirModelRoot extends ModelRoot {
    // protected
    // public
    final File dir;

    public DirModelRoot(File dir) {
        super();
        this.dir = dir;
        this.setModified(0);
        this.loadAll0(this.dir);
    }

    public String toString() {
        return this.dir.toString();
    }

    private void loadAll0(File current) {
        File[] files = current.listFiles();
        for (int i = 0; i < files.length; i++) {
            if (files[i].isDirectory()) {
                this.loadAll0(files[i]);
                continue;
            }
            if (files[i].lastModified() > this.modified())
                this.setModified(files[i].lastModified());

            String name = files[i].getPath();
            if (!name.endsWith(".class"))
                continue;
            if (!name.startsWith(this.dir.getPath() + File.separatorChar))
                throw new Error(name + " vs. " + this.dir.getPath()
                    + File.separatorChar);

            String name0 = name;
            name = name.substring(
                this.dir.getPath().length() + 1,
                name.length() - (".class").length());

            if (name.lastIndexOf(File.separatorChar) == -1)
                throw new Error("\"" + name + "\" \"" + name0
                    + "\" not well formed filename! " + File.separatorChar);

            PackageName pname = this.parsePackage(
                name.substring(0, name.lastIndexOf(File.separatorChar)),
                File.separatorChar);
            ClassName cname = this.parseClass(
                name.substring(name.lastIndexOf(File.separatorChar) + 1,
                    name.length()));
            PackageModel pkg;
            if (this.packages().containsKey(pname))
                pkg = (PackageModel) this.packages().get(pname);
            else
                pkg = new PackageModel(this, pname);
            ClassModel clazz = new ClassModel(pkg, cname);
        }
    }

    protected DataInputStream readClass(ClassModel clazz) {
        try {
            String path =
                clazz.pkg().name().javaSource().replace('.', File.separatorChar)
                + File.separatorChar
                + clazz.name().nopkg().toString().replace('.', '$') + ".class";
            File f = new File(this.dir, path);
            if (!f.exists() || f.isDirectory())
                throw new Error("error loading " + path + " for " + clazz + " "
                    + f);
            return new DataInputStream(new FileInputStream(f));
        } catch (IOException ioe) {
            throw new Error("" + ioe);
        }
    }
}
