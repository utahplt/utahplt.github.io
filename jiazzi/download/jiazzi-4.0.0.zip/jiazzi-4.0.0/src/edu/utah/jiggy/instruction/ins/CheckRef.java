/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.bytecode.ins outins.CheckRef */

package edu.utah.jiggy.instruction.ins;

import java.io.*;

import edu.utah.jiggy.clazz.ClassModel;
import edu.utah.jiggy.meta.shape.ShapeKey;
import edu.utah.jiggy.meta.type.Environment;
import edu.utah.jiggy.meta.type.RefType;
import edu.utah.jiggy.meta.type.TypeConstants;
import edu.utah.jiggy.meta.type.TypeType;

public abstract class CheckRef extends Instruction {
    static void activate() {
        (new CheckRef.Checkcast()).put00();
        (new CheckRef.Instanceof()).put00();
    }

    protected RefType type;

    public int argCount() {
        return 1;
    }

    public void execute(Machine m) {
        Value value = m.pop();
        this.args().add(value);
        m.doError(value.type(m.context) instanceof RefType, "");
    }

    public CheckRef setRef(RefType type) {
        CheckRef copy = (CheckRef) this.copy();
        copy.type = type;
        return copy;
    }

    public RefType ref() {
        return this.type;
    }

    protected int size() {
        return 3;
    }

    public Instruction read(int pc, DataInputStream input, ClassModel clazz,
                            ShapeKey mthd) throws IOException {
        return ((CheckRef) super.read(pc, input, clazz, mthd))
            .setRef(clazz.body().pool().get(input.readUnsignedShort()).clazz());
    }

    public Instruction prepareWrite(int pc, ClassModel clazz, ShapeKey mthd) {
        int index = clazz.body().pool().allocClass(this.type);
        return super.prepareWrite(pc, clazz, mthd);
    }

    public void write(int pc, DataOutputStream out, ClassModel clazz,
                      ShapeKey mthd) throws IOException {
        super.write(pc, out, clazz, mthd);
        out.writeShort(clazz.body().pool().allocClass(this.type));
    }

    public Instruction replace(ReplaceIns replace) {
        CheckRef ins = (CheckRef) super.replace(replace);
        if (ins != this)
            return ins;
        return this.setRef((RefType) this.type.replace(replace));
    }

    public boolean baseEquals(Instruction ins) {
        if (!super.baseEquals(ins))
            return false;
        else if (this.type == null)
            return ((CheckRef) ins).type == null;
        else
            return this.type.equals(((CheckRef) ins).type);
    }

    public int baseHashCode() {
        return super.baseHashCode()
            + (this.type == null ? 0 : this.type.hashCode());
    }

    public String toString() {
        return super.toString() + " " + this.type.javaSource();
    }

    public CheckRef() {
    }

    /* atom-edu.utah.jiggy.bytecode.ins outCheckRef.Checkcast */
    public static class Checkcast extends CheckRef {
        public Checkcast() {
            super();
        }

        public TypeType type(Environment env) {
            return this.type;
        }

        public void execute(Machine m) {
            super.execute(m);
            m.push(this);
        }

        public int opcode() {
            return 192;
        }

        public String mnemonic() {
            return "checkcast";
        }
    }

    /* atom-edu.utah.jiggy.bytecode.ins outCheckRef.Instanceof */
    public static class Instanceof extends CheckRef {
        public Instanceof() {
            super();
        }

        public TypeType type(Environment env) {
            return TypeConstants.BOOLEAN;
        }

        public void machine(Machine m) {
            super.execute(m);
            m.push(this);
        }

        public int opcode() {
            return 193;
        }

        public String mnemonic() {
            return "instanceof";
        }
    }
}
