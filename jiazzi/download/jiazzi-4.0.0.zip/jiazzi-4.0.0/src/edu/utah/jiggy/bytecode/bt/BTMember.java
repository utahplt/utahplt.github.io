/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiggy.bytecode outbt.Member */

package edu.utah.jiggy.bytecode.bt;

import java.util.*;
import java.io.*;

import edu.utah.jiggy.clazz.ClassModel;
import edu.utah.jiggy.meta.flag.AccessFlag;
import edu.utah.jiggy.meta.flag.BinaryFlag;
import edu.utah.jiggy.meta.flag.Flag;
import edu.utah.jiggy.meta.flag.FlagConstants;
import edu.utah.jiggy.meta.flag.VirtualFlag;
import edu.utah.jiggy.meta.name.MemberName;
import edu.utah.jiggy.meta.shape.MemberShape;
import edu.utah.jiggy.meta.shape.NameTypeShape;
import edu.utah.jiggy.meta.shape.ProcedureShape;
import edu.utah.jiggy.meta.shape.ShapeKey;
import edu.utah.jiggy.meta.shape.ThrowzShape;

public abstract class BTMember extends BTBase {
    public BTMember() {
        super();
    }

    public void dump(ShapeKey key, PrintStream out) {
        String str = this.getClass().getName();
        str = str.substring(str.lastIndexOf('.') + 1, str.length());
        out.println("MEMBER " + str + " " + key);
        super.dump(out);
    }

    public void read(DataInputStream in, ClassModel clazz, MemberShape bld)
            throws IOException {
        int flags = in.readShort();
        int nameIndex = in.readUnsignedShort();
        int typeIndex = in.readUnsignedShort();
        for (Iterator i = (this instanceof BTField ? FlagConstants.FIELD_FLAGS
                : FlagConstants.METHOD_FLAGS).iterator();
             i.hasNext();
             /* i = i */) {
            Flag flag = (Flag) i.next();
            if (flag instanceof BinaryFlag)
                if ((flags & flag.jvmcode()) != 0)
                    bld.set((BinaryFlag) flag);
        }
        bld.set(AccessFlag.parse(flags));
        bld.set(VirtualFlag.parse(flags));

        ShapeKey key = new ShapeKey();
        key = key.set(new NameTypeShape());
        key = key.set(new ProcedureShape());
        String name = clazz.body().pool().get(nameIndex).utf8();
        key = key.set(key.nameType().setName(new MemberName(name)));
        String typeString = clazz.body().pool().get(typeIndex).utf8();
        key = key.parseJvmType(typeString, clazz.pkg().root().env());
        if (key.nameType() != NameTypeShape.EMPTY)
            bld.set(key.nameType());
        if (key.procedure() != ProcedureShape.EMPTY)
            bld.set(key.procedure());
        if (bld.procedure().args().size() != key.procedure().args().size())
            throw new Error(clazz + " " + bld + " vs. " + key);

        int count = in.readUnsignedShort();
        BTAttr last = null;
        for (int i = 0; i < count; i++) {
            int index = in.readUnsignedShort();
            if (index >= clazz.body().pool().size())
                throw new Error(index + " " + clazz.body().pool().size() + " "
                    + last);
            BTAttr attr = BTAttr.find(clazz.body().pool().get(index).utf8());
            last = attr;
            int size = in.readInt();
            try {
                attr = attr.readMember(size, in, clazz, (BTMember) this, bld);
                if (bld.procedure().args().size() !=
                    key.procedure().args().size())
                    throw new Error(clazz + " \"" + bld.key() + "\" vs. \""
                        + key + "\" " + attr);
                if (!attr.isDerived())
                    this.attributes.put(attr, attr);
            } catch (Error e) {
                System.err.println("error in " + key + " in " + clazz);
                throw e;
            }
        }
    }

    public void prepareWrite(ClassModel clazz, ShapeKey key) {
        if (key.procedure().args().size() !=
            clazz.newType().shape().actual(key).procedure().args().size())
            throw new Error(key + " " + clazz.newType().shape().actual(key));

        clazz.body().pool().allocUtf8(key.jvmNameString());
        clazz.body().pool().allocUtf8(key.jvmTypeString());
        BTAttr attr = null;
        try {
            for (Iterator i = this.attributes.values().iterator();
                 i.hasNext();
                 /* i = i */) {
                attr = (BTAttr) i.next();
                if (!attr.prepareWriteMember(clazz, key))
                    i.remove();
            }
        } catch (Error e) {
            System.err.println("attr=" + attr + " clazz=" + clazz + " key="
                + key);
            throw e;
        }
        ThrowzShape throwz = clazz.newType().shape().actual(key).throwz();
        for (Iterator i = BTAttr.derived(); i.hasNext(); /* i = i */) {
            attr = (BTAttr) i.next();
            BTAttr nattr = attr.copy();
            if (nattr.prepareWriteMember(clazz, key))
                this.attributes.put(attr, nattr);
        }
    }

    public void write(DataOutputStream out, ClassModel clazz, ShapeKey key)
            throws IOException {
        {
            int flags = 0;
            MemberShape shape = clazz.newType().shape().actual(key);

            flags = flags | shape.access().jvmcode();
            flags = flags | shape.virtual().jvmcode();
            for (Iterator i = (this instanceof BTField ? FlagConstants.FIELD_FLAGS
                    : FlagConstants.METHOD_FLAGS).iterator();
                 i.hasNext();
                 /* i = i */) {
                Flag flag = (Flag) i.next();
                if (flag instanceof BinaryFlag)
                    if (shape.isSet((BinaryFlag) flag))
                        flags = flags | flag.jvmcode();
            }
            out.writeShort(flags);
        }
        out.writeShort(clazz.body().pool().findUtf8(key.jvmNameString()));
        out.writeShort(clazz.body().pool().findUtf8(key.jvmTypeString()));

        out.writeShort(this.attributes.size());
        for (Iterator i = this.attributes.values().iterator();
             i.hasNext();
             /* i = i */) {
            BTAttr attr = (BTAttr) i.next();
            attr.writeMember(out, clazz, key);
            if (attr.isDerived())
                i.remove();
        }
    }

    public BTMember replace(ReplaceBT replace) {
        BTMember copy = (BTMember) super.replace0(replace);
        return copy;
    }
}
