/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package edu.utah.jiggy.bytecode.bt;

import java.io.*;
import java.util.*;

import edu.utah.jiggy.clazz.ClassModel;
import edu.utah.jiggy.meta.shape.ArgShape;
import edu.utah.jiggy.meta.shape.Base;
import edu.utah.jiggy.meta.shape.ClassShape;
import edu.utah.jiggy.meta.shape.FieldShape;
import edu.utah.jiggy.meta.shape.MemberShape;
import edu.utah.jiggy.meta.shape.NameTypeShape;
import edu.utah.jiggy.meta.shape.ProcedureShape;
import edu.utah.jiggy.meta.shape.ShapeKey;
import edu.utah.jiggy.meta.shape.ThrowzShape;
import edu.utah.jiggy.meta.shape.TypeShape;
import edu.utah.jiggy.meta.type.ClassType;
import edu.utah.jiggy.meta.type.Environment;
import edu.utah.jiggy.meta.type.GJVariableType;
import edu.utah.jiggy.meta.type.TypeType;

public abstract class BTSignature extends BTAttr implements java.lang.Cloneable {
    public String name() {
        return "Signature";
    }

    public boolean isDerived() {
        return true;
    }

    public BTSignature() {
        super();
    }

    public BTAttr readClass(int size, DataInputStream in, ClassModel clazz,
                            ClassShape shape) throws IOException {
        BTSignature attr =
            (BTSignature) super.readClass(size, in, clazz, shape);
        String sig = clazz.body().pool().get(in.readUnsignedShort()).utf8();
        // System.err.println("class sig: \"" + sig + "\"");

        if (sig.charAt(0) == '<') {
            sig = this.parseParam(
                sig.substring(1, sig.length()),
                clazz.pkg().root().env(),
                clazz.body().generics());
            sig = sig.substring(sig.indexOf('>') + 1, sig.length());
            /* just ignore vars for now! */
        }
        /* read super and interface types */
        TypeType.parseJvmType(sig, clazz.pkg().root().env(),
            new TypeType.Rest() {
                boolean isSuperClass = true;

                public Object doit(TypeType type, String string,
                                   Environment env) {
                    /* just ignore! */
                    if (this.isSuperClass) {
                        ClassType zuper = (ClassType) type;
                        this.isSuperClass = false;
                    } else {
                        ClassType intf = (ClassType) type;
                    }
                    return null;
                }
            });
        return attr;
    }

    public BTAttr readMember(int size, DataInputStream in, ClassModel clazz,
                             BTMember mmbr, MemberShape bld) throws IOException {
        BTSignature attr =
            (BTSignature) super.readMember(size, in, clazz, mmbr, bld);
        int index = in.readUnsignedShort();
        String sig = clazz.body().pool().get(index).utf8();

        ShapeKey key = new ShapeKey();
        key = key.set(new NameTypeShape());
        key = key.set(new ProcedureShape());

        if (bld instanceof FieldShape) {
            try {
                TypeType type =
                    TypeType.parseJvmType(sig, clazz.pkg().root().env());
                bld.set(bld.nameType().setType(type));
            } catch (Error e) {
                System.err.println("index = " + index + ", " + sig);
                throw e;
            }
        } else {
            String orig = sig;
            /* this is the most confusing, either constructor or... */
            if (sig.charAt(0) == '<')
                sig = this.parseParam(
                    sig.substring(1, sig.length()),
                    clazz.pkg().root().env(),
                    mmbr.generics());

            String body = (sig.indexOf('^') == -1 ?
                    sig : sig.substring(0, sig.indexOf('^')));
            key = key.parseJvmType(body, clazz.pkg().root().env());

            bld.set(bld.nameType().setType(key.nameType().type()));

            if (key.procedure().args().size() == bld.procedure().args().size())
                bld.set(key.procedure());
            else {
                if (false)
                    throw new Error(bld.javaSource("<init>") + " \t" + key
                        + " \t" + sig + " \t" + orig);
            }

            if (sig.indexOf('^') != -1) {
                TypeType.Rest rest = new TypeType.Rest() {
                    ThrowzShape throwz = new ThrowzShape();

                    public Object doit(TypeType type, String string,
                                       Environment env) {
                        this.throwz = this.throwz.add((ClassType) type);
                        if (string.length() == 0)
                            return this.throwz;
                        else
                            return TypeType.parseJvmType(string, env, this);
                    }
                };
                ThrowzShape throwz = (ThrowzShape) TypeType.parseJvmType(sig
                    .substring(sig.indexOf('^') + 1, sig.length()), clazz.pkg()
                    .root().env(), rest);
                /* ignore throwz to... */
            }
        }
        return attr;
    }

    public boolean prepareWriteClass(ClassModel clazz) {
        if (clazz.newType().shape().zuper() == null)
            return false;
        String sig = "";
        if (!clazz.body().generics().isEmpty()) {
            sig = "<";
            for (Iterator i = clazz.body().generics().iterator();
                 i.hasNext();
                 /* i = i */) {
                GJVariableType gj = (GJVariableType) i.next();
                sig += (gj.name() + ":" + gj.bound().jvmTypeString());
            }
            sig += ">";
        }
        TypeShape shape = clazz.newType().shape();
        sig += shape.zuper().jvmTypeString();
        for (Iterator i = shape.interfaces().iterator();
             i.hasNext();
             /* i = i */)
            sig += ((ClassType) i.next()).jvmTypeString();
        this.toWriteSig = sig;
        clazz.body().pool().allocUtf8(sig);
        return super.prepareWriteClass(clazz);
    }

    String toWriteSig = null;

    public boolean prepareWriteMember(ClassModel clazz, ShapeKey key) {
        String sig = "";
        if (key.procedure() == ProcedureShape.EMPTY) {
            sig = key.nameType().type().gjTypeString();
        } else {
            /* care about methods only */
            MemberShape mthd;
            if (clazz.newType().shape().inits().contains(key))
                mthd = clazz.newType().shape().actualInit(key);
            else
                mthd = clazz.newType().shape().actualMethod(key);
            BTMember mmbr = (BTMember) clazz.body().methods().get(key);
            if (!mmbr.generics().isEmpty()) {
                sig = "<";
                for (Iterator i = mmbr.generics().iterator();
                     i.hasNext();
                     /* i = i */) {
                    GJVariableType gj = (GJVariableType) i.next();
                    sig += (gj.name() + ":" + gj.bound().jvmTypeString());
                }
                sig += ">";
            }
            sig += "(";
            for (Iterator i = mthd.procedure().args().iterator();
                 i.hasNext();
                 /* i = i */)
                sig += ((ArgShape) i.next()).type().gjTypeString();
            sig += ")";
            sig += mthd.nameType().type().gjTypeString();
            if (!mthd.throwz().members().isEmpty()) {
                sig += "^";
                for (Iterator i = mthd.throwz().members().iterator();
                     i.hasNext();
                     /* i = i */)
                    sig += ((ClassType) i.next()).gjTypeString();
            }
        }
        this.toWriteSig = sig;
        clazz.body().pool().allocUtf8(sig);
        return super.prepareWriteMember(clazz, key);
    }

    protected void write(DataOutputStream out, ClassModel clazz, Base base)
            throws IOException {
        super.write(out, clazz, base);
        // System.err.println("write sig \"" + this.toWriteSig + "\"");
        out.writeShort(clazz.body().pool().allocUtf8(this.toWriteSig));
        this.toWriteSig = null;
    }

    protected int size(ClassModel clazz, Base base) {
        return 2;
    }

    String parseParam(final String sig, Environment env, final List vars) {
        final String name = sig.substring(0, sig.indexOf(':'));
        return (String) TypeType.parseJvmType(
            sig.substring(sig.indexOf(':') + 1, sig.length()),
            env,
            new TypeType.Rest() {
                public Object doit(TypeType type, String string,
                                   Environment env) {
                    vars.add(new GJVariableType(name, (ClassType) type));
                    if (string.length() == 0)
                        throw new Error("missing > " + sig);
                    if (string.charAt(0) != '>')
                        return BTSignature.this.parseParam(string, env, vars);
                    else
                        return string.substring(1, string.length());
                }
            });
    }
}
