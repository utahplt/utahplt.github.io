// $ANTLR 2.7.1: "parser.g" -> "JParser.java"$

/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

  package edu.utah.jiazzi.parser;
   
  import java.util.*;

  import edu.utah.jiazzi.loc.LocPackage;
  import edu.utah.jiazzi.loc.LocRoot;
  import edu.utah.jiazzi.loc.Local;
  import edu.utah.jiazzi.unit.ArgVar;
  import edu.utah.jiazzi.unit.AtomUnit;
  import edu.utah.jiazzi.unit.CompoundUnit;
  import edu.utah.jiazzi.unit.Unit;
  import edu.utah.jiazzi.unit.UnitClass;
  import edu.utah.jiazzi.unit.UnitEnvironment;
  import edu.utah.jiazzi.unit.UnitOpen;
  import edu.utah.jiazzi.unit.UnitPackage;
  import edu.utah.jiazzi.unit.UnitRoot;
  import edu.utah.jiazzi.unit.UnitSignature;
  import edu.utah.jiggy.clazz.PackageModel;
  import edu.utah.jiggy.meta.flag.FlagConstants;
  import edu.utah.jiggy.meta.name.ClassName;
  import edu.utah.jiggy.meta.name.ExpandedName;
  import edu.utah.jiggy.meta.name.MemberName;
  import edu.utah.jiggy.meta.name.Name;
  import edu.utah.jiggy.meta.name.PackageName;
  import edu.utah.jiggy.meta.name.VariableName;
  import edu.utah.jiggy.meta.shape.ArgShape;
  import edu.utah.jiggy.meta.shape.Builder;
  import edu.utah.jiggy.meta.shape.ClassShape;
  import edu.utah.jiggy.meta.shape.FieldShape;
  import edu.utah.jiggy.meta.shape.InitShape;
  import edu.utah.jiggy.meta.shape.MethodShape;
  import edu.utah.jiggy.meta.shape.NameTypeShape;
  import edu.utah.jiggy.meta.shape.ProcedureShape;
  import edu.utah.jiggy.meta.shape.ThrowzShape;
  import edu.utah.jiggy.meta.type.ClassType;
  import edu.utah.jiggy.meta.type.PackageType;
  import edu.utah.jiggy.meta.type.PrimitiveType;
  import edu.utah.jiggy.meta.type.RefType;
  import edu.utah.jiggy.meta.type.Root;
  import edu.utah.jiggy.meta.type.TypeConstants;
  import edu.utah.jiggy.meta.type.TypeType;
  import edu.utah.jiggy.meta.type.VariableType;

import antlr.TokenBuffer;
import antlr.TokenStreamException;
import antlr.TokenStreamIOException;
import antlr.ANTLRException;
import antlr.LLkParser;
import antlr.Token;
import antlr.TokenStream;
import antlr.RecognitionException;
import antlr.NoViableAltException;
import antlr.MismatchedTokenException;
import antlr.SemanticException;
import antlr.ParserSharedInputState;
import antlr.collections.impl.BitSet;
import antlr.collections.AST;
import antlr.ASTPair;
import antlr.collections.impl.ASTArray;

public class JParser extends antlr.LLkParser
       implements JParserTokenTypes
 {

  private UnitEnvironment env;
  public void setEnvironment(UnitEnvironment env) {
    this.env = env;
  }
  public void reportError(String str) {
    this.env.err().println("" + str);
    this.env.fail();
  }
  public void reportError(antlr.RecognitionException exc) {
    this.reportError(exc.toString());
  }

protected JParser(TokenBuffer tokenBuf, int k) {
  super(tokenBuf,k);
  tokenNames = _tokenNames;
}

public JParser(TokenBuffer tokenBuf) {
  this(tokenBuf,6);
}

protected JParser(TokenStream lexer, int k) {
  super(lexer,k);
  tokenNames = _tokenNames;
}

public JParser(TokenStream lexer) {
  this(lexer,6);
}

public JParser(ParserSharedInputState state) {
  super(state,6);
  tokenNames = _tokenNames;
}

	public final String  keyword_r(
		
	) throws RecognitionException, TokenStreamException {
		String id;
		
		
		id = null;
		
		
		try {      // for error handling
			{
			switch ( LA(1)) {
			case JIAZZI_empty:
			{
				match(JIAZZI_empty);
				if ( inputState.guessing==0 ) {
					id = "empty";
				}
				break;
			}
			case JIAZZI_name:
			{
				match(JIAZZI_name);
				if ( inputState.guessing==0 ) {
					id = "name";
				}
				break;
			}
			case JIAZZI_arg:
			{
				match(JIAZZI_arg);
				if ( inputState.guessing==0 ) {
					id = "arg";
				}
				break;
			}
			case JIAZZI_open:
			{
				match(JIAZZI_open);
				if ( inputState.guessing==0 ) {
					id = "open";
				}
				break;
			}
			case JIAZZI_bind:
			{
				match(JIAZZI_bind);
				if ( inputState.guessing==0 ) {
					id = "bind";
				}
				break;
			}
			case JIAZZI_link:
			{
				match(JIAZZI_link);
				if ( inputState.guessing==0 ) {
					id = "link";
				}
				break;
			}
			case JIAZZI_local:
			{
				match(JIAZZI_local);
				if ( inputState.guessing==0 ) {
					id = "local";
				}
				break;
			}
			case JIAZZI_to:
			{
				match(JIAZZI_to);
				if ( inputState.guessing==0 ) {
					id = "to";
				}
				break;
			}
			case JIAZZI_unit:
			{
				match(JIAZZI_unit);
				if ( inputState.guessing==0 ) {
					id = "unit";
				}
				break;
			}
			case JIAZZI_atom:
			{
				match(JIAZZI_atom);
				if ( inputState.guessing==0 ) {
					id = "atom";
				}
				break;
			}
			case JIAZZI_compound:
			{
				match(JIAZZI_compound);
				if ( inputState.guessing==0 ) {
					id = "compound";
				}
				break;
			}
			case JIAZZI_signature:
			{
				match(JIAZZI_signature);
				if ( inputState.guessing==0 ) {
					id = "signature";
				}
				break;
			}
			case JIAZZI_generic:
			{
				match(JIAZZI_generic);
				if ( inputState.guessing==0 ) {
					id = "generic";
				}
				break;
			}
			case JIAZZI_export:
			{
				match(JIAZZI_export);
				if ( inputState.guessing==0 ) {
					id = "export";
				}
				break;
			}
			case JIAZZI_external:
			{
				match(JIAZZI_external);
				if ( inputState.guessing==0 ) {
					id = "external";
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_0);
			} else {
			  throw ex;
			}
		}
		return id;
	}
	
	public final String  var_r(
		
	) throws RecognitionException, TokenStreamException {
		String str;
		
		Token  id = null;
		
		str = null;
		
		
		try {      // for error handling
			id = LT(1);
			match(ID);
			if ( inputState.guessing==0 ) {
				
				str = id.getText();
				if (str.charAt(0) != '[' ||
				str.charAt(str.length() - 1) != ']')
				throw new antlr.RecognitionException("expecting single bracked id, not \"" + id + "\"");
				str = str.substring(1, str.length() -1);
				if (str.indexOf('[') != -1 ||
				str.indexOf(']') != -1)
				throw new antlr.RecognitionException("expecting single bracked id, not \"" + id + "\"");
				
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_1);
			} else {
			  throw ex;
			}
		}
		return str;
	}
	
	public final ExpandedName  expanded0_r(
		UnitEnvironment env, UnitRoot root
	) throws RecognitionException, TokenStreamException {
		ExpandedName exp;
		
		Token  id = null;
		
		exp = null;
		VariableName var;
		String text;
		
		
		try {      // for error handling
			{
			switch ( LA(1)) {
			case ID:
			{
				{
				id = LT(1);
				match(ID);
				if ( inputState.guessing==0 ) {
					
					text = id.getText();
					if (text.indexOf('[') == -1) { // ']'
					exp = new ExpandedName(text, VariableName.NULL, "");
					} else {
					String btext = text.substring(0, text.indexOf('['));
					String etext = text.substring(text.indexOf(']') + 1, text.length());
					String vtext = text.substring(text.indexOf('[') + 1, text.indexOf(']'));
					if (root instanceof UnitSignature && 
						((UnitSignature) root).lexemes().containsKey(vtext)) {
					UnitSignature sig = (UnitSignature) root;
					exp = new ExpandedName("", sig.findNameVar(vtext), "");
					exp = exp.prepend(btext).append(etext);
					} else {
					
					this.reportError("cannot find name variable " + vtext + " in " + root);
					var = VariableName.NULL;
					}
					}
					
				}
				}
				break;
			}
			case JIAZZI_unit:
			case JIAZZI_atom:
			case JIAZZI_compound:
			case JIAZZI_signature:
			case JIAZZI_bind:
			case JIAZZI_link:
			case JIAZZI_to:
			case JIAZZI_open:
			case JIAZZI_name:
			case JIAZZI_arg:
			case JIAZZI_generic:
			case JIAZZI_export:
			case JIAZZI_local:
			case JIAZZI_empty:
			case JIAZZI_external:
			{
				{
				if ( inputState.guessing==0 ) {
					
					
				}
				text=keyword_r();
				if ( inputState.guessing==0 ) {
					
					exp = new ExpandedName(text, VariableName.NULL, "");
					
				}
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_2);
			} else {
			  throw ex;
			}
		}
		return exp;
	}
	
	public final ExpandedName  expanded_r(
		UnitEnvironment env, UnitRoot root
	) throws RecognitionException, TokenStreamException {
		ExpandedName exp;
		
		
		exp = null;
		
		
		try {      // for error handling
			switch ( LA(1)) {
			case JIAZZI_unit:
			case JIAZZI_atom:
			case JIAZZI_compound:
			case JIAZZI_signature:
			case JIAZZI_bind:
			case JIAZZI_link:
			case JIAZZI_to:
			case JIAZZI_open:
			case JIAZZI_name:
			case JIAZZI_arg:
			case JIAZZI_generic:
			case JIAZZI_export:
			case JIAZZI_local:
			case JIAZZI_empty:
			case JIAZZI_external:
			case ID:
			{
				{
				exp=expanded0_r(env,root);
				}
				break;
			}
			case DQUOTE:
			{
				{
				match(DQUOTE);
				match(DQUOTE);
				if ( inputState.guessing==0 ) {
					
					exp = new ExpandedName("", VariableName.NULL, "");
					
				}
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_3);
			} else {
			  throw ex;
			}
		}
		return exp;
	}
	
	public final Name  name_r(
		UnitEnvironment env, UnitRoot root, Name nm0
	) throws RecognitionException, TokenStreamException {
		Name nm;
		
		
		nm = nm0;
		ExpandedName exp; 
		
		
		try {      // for error handling
			exp=expanded0_r(env,root);
			if ( inputState.guessing==0 ) {
				
				nm = nm.setExpanded(exp);
				
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_4);
			} else {
			  throw ex;
			}
		}
		return nm;
	}
	
	public final String  longid_r(
		
	) throws RecognitionException, TokenStreamException {
		String id;
		
		
		id = null;
		String id0;
		
		
		try {      // for error handling
			id=id_r();
			{
			_loop14:
			do {
				if ((LA(1)==DOT)) {
					match(DOT);
					id0=id_r();
					if ( inputState.guessing==0 ) {
						
						id = id + '.' + id0;
						
					}
				}
				else {
					break _loop14;
				}
				
			} while (true);
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_5);
			} else {
			  throw ex;
			}
		}
		return id;
	}
	
	public final String  id_r(
		
	) throws RecognitionException, TokenStreamException {
		String id;
		
		Token  id0 = null;
		
		id = null;
		
		
		try {      // for error handling
			{
			switch ( LA(1)) {
			case ID:
			{
				{
				id0 = LT(1);
				match(ID);
				if ( inputState.guessing==0 ) {
					
					id = id0.getText(); 
					if (id.indexOf('[') != -1) 
					throw new antlr.RecognitionException("not expecting variable \"" + id + "\"");
					
				}
				}
				break;
			}
			case JIAZZI_unit:
			case JIAZZI_atom:
			case JIAZZI_compound:
			case JIAZZI_signature:
			case JIAZZI_bind:
			case JIAZZI_link:
			case JIAZZI_to:
			case JIAZZI_open:
			case JIAZZI_name:
			case JIAZZI_arg:
			case JIAZZI_generic:
			case JIAZZI_export:
			case JIAZZI_local:
			case JIAZZI_empty:
			case JIAZZI_external:
			{
				id=keyword_r();
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_6);
			} else {
			  throw ex;
			}
		}
		return id;
	}
	
	public final ClassName  classname_r(
		UnitEnvironment env, UnitRoot unit
	) throws RecognitionException, TokenStreamException {
		ClassName cname;
		
		
		cname = new ClassName();
		Name nm;
		ClassName CONSTANT = new ClassName("");
		
		
		try {      // for error handling
			nm=name_r(env,unit,CONSTANT);
			if ( inputState.guessing==0 ) {
				
				cname = (ClassName) nm;
				
			}
			{
			_loop21:
			do {
				if ((LA(1)==DOLLAR)) {
					{
					match(DOLLAR);
					}
					if ( inputState.guessing==0 ) {
						
						
					}
					nm=name_r(env,unit,CONSTANT);
					if ( inputState.guessing==0 ) {
						
						cname = ((ClassName) nm).setOuter(cname);
						
					}
				}
				else {
					break _loop21;
				}
				
			} while (true);
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_7);
			} else {
			  throw ex;
			}
		}
		return cname;
	}
	
	public final PackageName  pkgname_r(
		
	) throws RecognitionException, TokenStreamException {
		PackageName pname;
		
		
		pname = null;
		String pn;
		
		
		try {      // for error handling
			pn=longid_r();
			if ( inputState.guessing==0 ) {
				
				pname = new PackageName(pn);
				
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_8);
			} else {
			  throw ex;
			}
		}
		return pname;
	}
	
	public final UnitPackage  pkg_decl_r(
		UnitEnvironment env, UnitRoot root
	) throws RecognitionException, TokenStreamException {
		UnitPackage upkg;
		
		
		upkg = null;
		PackageName pkgname;
		String signame;
		
		
		try {      // for error handling
			pkgname=pkgname_r();
			if ( inputState.guessing==0 ) {
				
				if (root.packages().containsKey(pkgname)) {
				upkg = (UnitPackage) root.packages().get(pkgname);
				this.reportError(upkg + " already package in " + root);
				
				} else upkg = new UnitPackage(root, pkgname);
				
			}
			{
			switch ( LA(1)) {
			case JIAZZI_extends:
			{
				match(JIAZZI_extends);
				pkgname=pkgname_r();
				if ( inputState.guessing==0 ) {
					
					if (!root.packages().containsKey(pkgname)) {
					this.reportError(pkgname + " not found in " + root);
					
					} else {
					UnitPackage epkg = (UnitPackage) root.packages().get(pkgname);
					upkg.setExtended(epkg);
					}
					
				}
				break;
			}
			case SEMI:
			case COMMA:
			case COLON:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			switch ( LA(1)) {
			case COLON:
			{
				match(COLON);
				signame=longid_r();
				if ( inputState.guessing==0 ) {
					
					upkg.setSignature(env.findSignature(signame));
					
				}
				break;
			}
			case SEMI:
			case COMMA:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_9);
			} else {
			  throw ex;
			}
		}
		return upkg;
	}
	
	public final VariableName  lexeme_decl_r(
		UnitEnvironment env, UnitSignature root
	) throws RecognitionException, TokenStreamException {
		VariableName var;
		
		
		var = null;
		String name;
		
		
		try {      // for error handling
			name=var_r();
			if ( inputState.guessing==0 ) {
				
				var = root.findNameVar(name);
				if (var != null) {
				this.reportError(var + " already lexeme in " + root);
				
				} else {
				var = root.newLexeme(name);
				}
				
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_9);
			} else {
			  throw ex;
			}
		}
		return var;
	}
	
	public final ArgVar  arg_decl_r(
		UnitEnvironment env, UnitSignature root
	) throws RecognitionException, TokenStreamException {
		ArgVar var;
		
		
		var = null;
		String name;
		
		
		try {      // for error handling
			name=var_r();
			if ( inputState.guessing==0 ) {
				
				var = root.findArgVar(name);
				if (var != null) {
				var = (ArgVar) root.argVars().get(name);
				this.reportError(var + " already argument paramater in " + root);
				
				} else {
				var = root.newArgVar(name);
				}
				
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_9);
			} else {
			  throw ex;
			}
		}
		return var;
	}
	
	public final VariableType  generic_decl_r(
		UnitEnvironment env, UnitRoot root
	) throws RecognitionException, TokenStreamException {
		VariableType var;
		
		
		var = null;
		String name;
		RefType bound=null;
		
		
		try {      // for error handling
			name=id_r();
			{
			switch ( LA(1)) {
			case SEMI:
			case COMMA:
			{
				if ( inputState.guessing==0 ) {
					
					bound = env.platform().findClass(new ClassName("java.lang.Object"));
					
				}
				break;
			}
			case COLON:
			{
				{
				match(COLON);
				bound=generic_bind_type_r(env,root,root);
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			if ( inputState.guessing==0 ) {
				
				if (root.generics().containsKey(name)) {
				var = (VariableType) root.generics().get(name);
				this.reportError(var + " already generic in " + root);
				
				} else if (!(bound instanceof ClassType)) {
				this.reportError("bound for " + var + " must be class type");
				
				} else {
				var =  root.newGeneric(name, (ClassType) bound);
				}
				
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_9);
			} else {
			  throw ex;
			}
		}
		return var;
	}
	
	public final RefType  generic_bind_type_r(
		UnitEnvironment env, UnitRoot root, Root search
	) throws RecognitionException, TokenStreamException {
		RefType ctype;
		
		
		ctype = null;
		ClassName cname=null;
		PackageType pkg=null;
		PackageName pkgname = null;
		String part=null;
		
		
		try {      // for error handling
			part=id_r();
			{
			switch ( LA(1)) {
			case DOT:
			{
				{
				match(DOT);
				if ( inputState.guessing==0 ) {
					
					pkgname = new PackageName(part);
					
				}
				{
				_loop219:
				do {
					if ((_tokenSet_10.member(LA(1))) && (LA(2)==DOT)) {
						part=id_r();
						match(DOT);
						if ( inputState.guessing==0 ) {
							
							pkgname = (new PackageName(part)).setOuter(pkgname);
							
						}
					}
					else {
						break _loop219;
					}
					
				} while (true);
				}
				if ( inputState.guessing==0 ) {
					
					if (search.containsPackage(pkgname)) {
					pkg = search.findPackage(pkgname);
					if (search instanceof UnitRoot) {
					if (!((UnitPackage) pkg).isParam()) {
						 
						this.reportError(pkg + " is not a parameter package");
					}
					((UnitPackage) pkg).resolve(env, UnitPackage.CLASS_RESOLVED);
					} else {
					if (!((LocPackage) pkg).isSource()) {
						 
						this.reportError(pkg + " is not a source package");
					}
					/* resolve the package...hope its variables are bound appropriately. */
					((LocPackage) pkg).resolveInit(env);
					}
					} else {
					pkg = env.platform().findPackage(pkgname);
					if (pkg == null) {
					
					this.reportError("cannot find " + pkg + " in " + root + " or " + env.platform());
					pkg = env.platform().findPackage(new PackageName("java.lang"));
					}
					}
					
				}
				ctype=classtype1_r(env,root,pkg);
				}
				break;
			}
			case JIAZZI_to:
			case SEMI:
			case COMMA:
			{
				{
				if ( inputState.guessing==0 ) {
					
					pkg = env.platform().findPackage(new PackageName("java.lang"));
					cname = new ClassName(part);
					if (pkg.containsClass(cname)) {
					ctype = pkg.findClass(cname);
					} else if (root.generics().containsKey(part)) {
					ctype = (RefType) root.generics().get(part);
					} else {
					
					this.reportError("cannot find " + part + " in java.lang or generics");
					ctype = pkg.findClass(new ClassName("Object"));
					}
					
				}
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_11);
			} else {
			  throw ex;
			}
		}
		return ctype;
	}
	
	public final UnitPackage  bind_upkg_r(
		UnitEnvironment env, UnitRoot root
	) throws RecognitionException, TokenStreamException {
		UnitPackage upkg;
		
		
		PackageName pkgname;
		upkg = null;
		
		
		try {      // for error handling
			pkgname=pkgname_r();
			if ( inputState.guessing==0 ) {
				
				if (!root.packages().containsKey(pkgname)) {
				this.reportError("cannot find package " + pkgname + " in " + root);
				
				} else {
				upkg = (UnitPackage) root.packages().get(pkgname);
				if (upkg.sig() == null) {
				this.reportError(upkg + " in " + root + " does not have signature so cannot be bound");
				
				}
				}
				
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_12);
			} else {
			  throw ex;
			}
		}
		return upkg;
	}
	
	public final void bind_pkg_r(
		UnitEnvironment env, UnitRoot root
	) throws RecognitionException, TokenStreamException {
		
		
		PackageType fpkg=null;
		UnitPackage upkg=null;
		UnitPackage tpkg=null;
		PackageName pkgname=null;
		
		
		try {      // for error handling
			{
			switch ( LA(1)) {
			case WILD:
			{
				{
				match(WILD);
				match(JIAZZI_to);
				upkg=bind_upkg_r(env,root);
				match(AT);
				match(WILD);
				if ( inputState.guessing==0 ) {
					
					for (Iterator i = upkg.sig().params().iterator(); i.hasNext(); /* i = i */) {
					tpkg = (UnitPackage) i.next();
					if (upkg.pkgBindings().containsKey(tpkg)) continue;
					if (!root.packages().containsKey(tpkg.name())) continue;
					fpkg = (PackageType) root.packages().get(tpkg.name());
					if (fpkg == null) continue;
					if (!((UnitPackage) fpkg).isParam()) continue;
					upkg.bind(tpkg, fpkg);
					}
					
				}
				}
				break;
			}
			case JIAZZI_unit:
			case JIAZZI_atom:
			case JIAZZI_compound:
			case JIAZZI_signature:
			case JIAZZI_bind:
			case JIAZZI_link:
			case JIAZZI_to:
			case JIAZZI_open:
			case JIAZZI_name:
			case JIAZZI_arg:
			case JIAZZI_generic:
			case JIAZZI_export:
			case JIAZZI_local:
			case JIAZZI_empty:
			case JIAZZI_external:
			case ID:
			{
				{
				pkgname=pkgname_r();
				match(JIAZZI_to);
				if ( inputState.guessing==0 ) {
					
					if (root.packages().containsKey(pkgname) &&
					((UnitPackage) root.packages().get(pkgname)).isParam()) {
						fpkg = (UnitPackage) root.packages().get(pkgname);
						if (fpkg == null) throw new Error("what the hell");
					} else {
						if (!env.platform().containsPackage(pkgname)) {
						  this.reportError("cannot find package " + pkgname + " in " + root + " or " + env.platform());
						  fpkg = null;
						} else {
						  fpkg = env.platform().findPackage(pkgname);
						}
					}
					
				}
				{
				switch ( LA(1)) {
				case JIAZZI_unit:
				case JIAZZI_atom:
				case JIAZZI_compound:
				case JIAZZI_signature:
				case JIAZZI_bind:
				case JIAZZI_link:
				case JIAZZI_to:
				case JIAZZI_open:
				case JIAZZI_name:
				case JIAZZI_arg:
				case JIAZZI_generic:
				case JIAZZI_export:
				case JIAZZI_local:
				case JIAZZI_empty:
				case JIAZZI_external:
				case ID:
				{
					{
					upkg=bind_upkg_r(env,root);
					match(AT);
					pkgname=pkgname_r();
					if ( inputState.guessing==0 ) {
						
						if (upkg.isOpen()) {
						boolean pass = false;
						UnitPackage ops[] = { upkg.open().in(), upkg.open().out(), upkg.open().fixed() };
						for (int i = 0; i < ops.length; i++) {
						if (!ops[i].sig().packages().containsKey(pkgname)) continue;
						tpkg = (UnitPackage) ops[i].sig().packages().get(pkgname);
						if (!tpkg.isParam()) continue;
						if (fpkg != null) 
							ops[i].bind(tpkg, fpkg);
						pass = true;
						}
						if (!pass) {
						this.reportError(pkgname + " is not a package parameter of " + upkg.sig() + " for " + upkg);
						
						}
						} else {
						if (!upkg.sig().packages().containsKey(pkgname)) {
						this.reportError(pkgname + " is not a package parameter of " + upkg.sig() + " for " + upkg);
						
						fpkg = null;
						} 
						tpkg = (UnitPackage) upkg.sig().packages().get(pkgname);
						if (tpkg != null && !tpkg.isParam()) {
						this.reportError(tpkg + " is not a package parameter");
						
						} else {
						if (tpkg != null && !upkg.pkgBindings().containsKey(tpkg) && fpkg != null) 
							upkg.bind(tpkg, fpkg);
						}
						}
						
					}
					}
					break;
				}
				case WILD:
				{
					{
					match(WILD);
					match(AT);
					pkgname=pkgname_r();
					if ( inputState.guessing==0 ) {
						
						for (Iterator i = root.packages().values().iterator(); i.hasNext(); /* i = i */) {
						upkg = (UnitPackage) i.next();
						if (upkg.sig() == null) continue;
						if (!upkg.sig().packages().containsKey(pkgname)) continue;
						tpkg = (UnitPackage) upkg.sig().packages().get(pkgname);
						if (!tpkg.isParam()) continue;
						if (upkg.pkgBindings().containsKey(tpkg)) continue;
						if (fpkg != null) 
						upkg.bind(tpkg, fpkg);
						}
						
					}
					}
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_13);
			} else {
			  throw ex;
			}
		}
	}
	
	public final void sigbind_r(
		UnitEnvironment env, UnitSignature usig
	) throws RecognitionException, TokenStreamException {
		
		
		ExpandedName exp;
		ProcedureShape proc;
		String vname;
		
		
		try {      // for error handling
			vname=var_r();
			match(EQUAL);
			{
			switch ( LA(1)) {
			case JIAZZI_unit:
			case JIAZZI_atom:
			case JIAZZI_compound:
			case JIAZZI_signature:
			case JIAZZI_bind:
			case JIAZZI_link:
			case JIAZZI_to:
			case JIAZZI_open:
			case JIAZZI_name:
			case JIAZZI_arg:
			case JIAZZI_generic:
			case JIAZZI_export:
			case JIAZZI_local:
			case JIAZZI_empty:
			case JIAZZI_external:
			case DQUOTE:
			case ID:
			{
				{
				exp=expanded_r(env,usig);
				if ( inputState.guessing==0 ) {
					
					if (!usig.bindNameVar(vname, exp)) {
					this.reportError(usig + " does not have a argument parameter " + vname);
					
					}
					
				}
				}
				break;
			}
			case LPAREN:
			{
				{
				proc=proc_r(env,usig);
				if ( inputState.guessing==0 ) {
					
					if (!usig.bindArgVar(vname, proc)) {
					this.reportError(usig + " does not have a argument parameter " + vname);
					
					}
					
				}
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_3);
			} else {
			  throw ex;
			}
		}
	}
	
	public final ProcedureShape  proc_r(
		UnitEnvironment env, UnitSignature sig
	) throws RecognitionException, TokenStreamException {
		ProcedureShape proc;
		
		
		proc = new ProcedureShape();
		String vname;
		
		
		try {      // for error handling
			match(LPAREN);
			{
			switch ( LA(1)) {
			case JIAZZI_unit:
			case JIAZZI_atom:
			case JIAZZI_compound:
			case JIAZZI_signature:
			case JIAZZI_bind:
			case JIAZZI_link:
			case JIAZZI_to:
			case JIAZZI_open:
			case JIAZZI_name:
			case JIAZZI_arg:
			case JIAZZI_generic:
			case JIAZZI_export:
			case JIAZZI_local:
			case JIAZZI_empty:
			case JIAZZI_external:
			case JIAZZI_void:
			case JIAZZI_boolean:
			case JIAZZI_byte:
			case JIAZZI_short:
			case JIAZZI_char:
			case JIAZZI_int:
			case JIAZZI_long:
			case JIAZZI_double:
			case JIAZZI_float:
			case ID:
			{
				proc=arg_r(env,sig,proc);
				{
				_loop131:
				do {
					if ((LA(1)==COMMA)) {
						{
						match(COMMA);
						}
						proc=arg_r(env,sig,proc);
					}
					else {
						break _loop131;
					}
					
				} while (true);
				}
				break;
			}
			case RPAREN:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			match(RPAREN);
			{
			switch ( LA(1)) {
			case ID:
			{
				vname=var_r();
				if ( inputState.guessing==0 ) {
					
					ArgVar var = sig.findArgVar(vname);
					if (var == null) {
					
					this.reportError("cannot find arg parameter \"" + vname + "\" in " + sig);
					} else {
					proc = proc.set(var);
					}
					
				}
				break;
			}
			case JIAZZI_throws:
			case JIAZZI_true:
			case JIAZZI_false:
			case EQUAL:
			case SEMI:
			case BRACKETS:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_14);
			} else {
			  throw ex;
			}
		}
		return proc;
	}
	
	public final void bind_generic_r(
		UnitEnvironment env, UnitRoot root
	) throws RecognitionException, TokenStreamException {
		
		
		RefType ref;
		UnitPackage upkg;
		VariableType var;
		String vname;
		
		
		try {      // for error handling
			{
			switch ( LA(1)) {
			case WILD:
			{
				{
				match(WILD);
				match(JIAZZI_to);
				upkg=bind_upkg_r(env,root);
				match(AT);
				match(WILD);
				if ( inputState.guessing==0 ) {
					
					for (Iterator i = root.generics().values().iterator(); i.hasNext(); /* i = i */) {
					VariableType fvar = (VariableType) i.next();
					if (!upkg.sig().generics().containsKey(fvar.name())) continue;
					var = (VariableType) upkg.sig().generics().get(fvar.name());
					if (upkg.genericBindings().containsKey(var)) continue;
					upkg.bind(var, fvar);
					}
					
				}
				}
				break;
			}
			case JIAZZI_unit:
			case JIAZZI_atom:
			case JIAZZI_compound:
			case JIAZZI_signature:
			case JIAZZI_bind:
			case JIAZZI_link:
			case JIAZZI_to:
			case JIAZZI_open:
			case JIAZZI_name:
			case JIAZZI_arg:
			case JIAZZI_generic:
			case JIAZZI_export:
			case JIAZZI_local:
			case JIAZZI_empty:
			case JIAZZI_external:
			case ID:
			{
				{
				ref=generic_bind_type_r(env,root,root);
				match(JIAZZI_to);
				if ( inputState.guessing==0 ) {
					
					
				}
				{
				switch ( LA(1)) {
				case JIAZZI_unit:
				case JIAZZI_atom:
				case JIAZZI_compound:
				case JIAZZI_signature:
				case JIAZZI_bind:
				case JIAZZI_link:
				case JIAZZI_to:
				case JIAZZI_open:
				case JIAZZI_name:
				case JIAZZI_arg:
				case JIAZZI_generic:
				case JIAZZI_export:
				case JIAZZI_local:
				case JIAZZI_empty:
				case JIAZZI_external:
				case ID:
				{
					{
					upkg=bind_upkg_r(env,root);
					match(AT);
					vname=id_r();
					if ( inputState.guessing==0 ) {
						
						if (!upkg.sig().generics().containsKey(vname)) {
						this.reportError(upkg + " does not have a generic parameter " + vname);
						
						} else {
						var = (VariableType) upkg.sig().generics().get(vname);
						if (!upkg.genericBindings().containsKey(var))
						upkg.bind(var, ref);
						}
						
					}
					}
					break;
				}
				case WILD:
				{
					{
					match(WILD);
					match(AT);
					vname=id_r();
					if ( inputState.guessing==0 ) {
						
						for (Iterator i = root.packages().values().iterator(); i.hasNext(); /* i = i */) {
						upkg = (UnitPackage) i.next();
						if (upkg.sig() == null) continue;
						if (!upkg.sig().generics().containsKey(vname)) continue;
						var = (VariableType) upkg.sig().generics().get(vname);
						if (!upkg.genericBindings().containsKey(var)) 
						upkg.bind(var, ref);
						}
						
					}
					}
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_13);
			} else {
			  throw ex;
			}
		}
	}
	
	public final UnitSignature  signature_r(
		UnitEnvironment env
	) throws RecognitionException, TokenStreamException {
		UnitSignature sig;
		
		
		sig = null;
		String name, pname = null;
		UnitPackage upkg;
		VariableType generic;
		VariableName lexeme;
		ArgVar arg;
		int n = 0;
		PackageName pkgname;
		// List<PackageModel> old = new ArrayList<PackageModel>(env.defaults);
		List old = new ArrayList(env.defaults);
		env.defaults.clear();
		// if (!env.defaults.isEmpty()) throw new Error("unexpected");
		env.defaults.add((PackageModel) env.platform().findPackage(new PackageName("java.lang")));
		
		
		try {      // for error handling
			{
			_loop53:
			do {
				if ((LA(1)==JIAZZI_external)) {
					match(JIAZZI_external);
					{
					switch ( LA(1)) {
					case JIAZZI_package:
					{
						match(JIAZZI_package);
						break;
					}
					case JIAZZI_unit:
					case JIAZZI_atom:
					case JIAZZI_compound:
					case JIAZZI_signature:
					case JIAZZI_bind:
					case JIAZZI_link:
					case JIAZZI_to:
					case JIAZZI_open:
					case JIAZZI_name:
					case JIAZZI_arg:
					case JIAZZI_generic:
					case JIAZZI_export:
					case JIAZZI_local:
					case JIAZZI_empty:
					case JIAZZI_external:
					case ID:
					{
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					}
					}
					pkgname=pkgname_r();
					if ( inputState.guessing==0 ) {
						
						env.defaults.add((PackageModel) env.platform().findPackage(pkgname));
						
					}
					match(SEMI);
				}
				else {
					break _loop53;
				}
				
			} while (true);
			}
			match(JIAZZI_signature);
			name=longid_r();
			if ( inputState.guessing==0 ) {
				
				sig = new UnitSignature(name);
				
			}
			match(EQUAL);
			{
			_loop58:
			do {
				if ((_tokenSet_10.member(LA(1)))) {
					{
					if ((_tokenSet_10.member(LA(1))) && (LA(2)==COLON)) {
						{
						pname=id_r();
						match(COLON);
						}
					}
					else if ((_tokenSet_10.member(LA(1))) && (LA(2)==PLUS||LA(2)==DOT)) {
						{
						if ( inputState.guessing==0 ) {
							pname = "$$" + n; n++;
						}
						}
					}
					else {
						throw new NoViableAltException(LT(1), getFilename());
					}
					
					}
					name=longid_r();
					if ( inputState.guessing==0 ) {
						
						UnitSignature zsig = env.findSignature(name);
						UnitPackage zpkg = new UnitPackage(sig, new PackageName(pname));
						zpkg.setSignature(zsig);
						sig.makeSuper(zpkg);
						
					}
					match(PLUS);
				}
				else {
					break _loop58;
				}
				
			} while (true);
			}
			{
			match(LCURLY);
			{
			_loop76:
			do {
				if ((_tokenSet_15.member(LA(1)))) {
					{
					switch ( LA(1)) {
					case JIAZZI_package:
					{
						{
						match(JIAZZI_package);
						upkg=pkg_decl_r(env,sig);
						if ( inputState.guessing==0 ) {
							sig.makeParam(upkg);
						}
						{
						_loop64:
						do {
							if ((LA(1)==COMMA)) {
								match(COMMA);
								upkg=pkg_decl_r(env,sig);
								if ( inputState.guessing==0 ) {
									sig.makeParam(upkg);
								}
							}
							else {
								break _loop64;
							}
							
						} while (true);
						}
						}
						break;
					}
					case JIAZZI_name:
					{
						{
						{
						match(JIAZZI_name);
						}
						lexeme=lexeme_decl_r(env,sig);
						{
						_loop68:
						do {
							if ((LA(1)==COMMA)) {
								match(COMMA);
								lexeme=lexeme_decl_r(env,sig);
							}
							else {
								break _loop68;
							}
							
						} while (true);
						}
						}
						break;
					}
					case JIAZZI_arg:
					{
						{
						{
						match(JIAZZI_arg);
						}
						arg=arg_decl_r(env,sig);
						{
						_loop72:
						do {
							if ((LA(1)==COMMA)) {
								match(COMMA);
								arg=arg_decl_r(env,sig);
							}
							else {
								break _loop72;
							}
							
						} while (true);
						}
						}
						break;
					}
					case JIAZZI_generic:
					{
						{
						match(JIAZZI_generic);
						generic=generic_decl_r(env,sig);
						{
						_loop75:
						do {
							if ((LA(1)==COMMA)) {
								match(COMMA);
								generic=generic_decl_r(env,sig);
							}
							else {
								break _loop75;
							}
							
						} while (true);
						}
						}
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					}
					}
					match(SEMI);
				}
				else {
					break _loop76;
				}
				
			} while (true);
			}
			{
			_loop78:
			do {
				if ((LA(1)==ID)) {
					sigbind_r(env,sig);
					match(SEMI);
				}
				else {
					break _loop78;
				}
				
			} while (true);
			}
			{
			_loop89:
			do {
				if ((LA(1)==JIAZZI_bind)) {
					match(JIAZZI_bind);
					{
					switch ( LA(1)) {
					case JIAZZI_package:
					{
						{
						match(JIAZZI_package);
						{
						_loop84:
						do {
							if ((_tokenSet_16.member(LA(1)))) {
								{
								switch ( LA(1)) {
								case COMMA:
								{
									match(COMMA);
									break;
								}
								case JIAZZI_unit:
								case JIAZZI_atom:
								case JIAZZI_compound:
								case JIAZZI_signature:
								case JIAZZI_bind:
								case JIAZZI_link:
								case JIAZZI_to:
								case JIAZZI_open:
								case JIAZZI_name:
								case JIAZZI_arg:
								case JIAZZI_generic:
								case JIAZZI_export:
								case JIAZZI_local:
								case JIAZZI_empty:
								case JIAZZI_external:
								case WILD:
								case ID:
								{
									break;
								}
								default:
								{
									throw new NoViableAltException(LT(1), getFilename());
								}
								}
								}
								bind_pkg_r(env,sig);
							}
							else {
								break _loop84;
							}
							
						} while (true);
						}
						}
						break;
					}
					case JIAZZI_generic:
					{
						{
						match(JIAZZI_generic);
						{
						_loop88:
						do {
							if ((_tokenSet_16.member(LA(1)))) {
								{
								switch ( LA(1)) {
								case COMMA:
								{
									match(COMMA);
									break;
								}
								case JIAZZI_unit:
								case JIAZZI_atom:
								case JIAZZI_compound:
								case JIAZZI_signature:
								case JIAZZI_bind:
								case JIAZZI_link:
								case JIAZZI_to:
								case JIAZZI_open:
								case JIAZZI_name:
								case JIAZZI_arg:
								case JIAZZI_generic:
								case JIAZZI_export:
								case JIAZZI_local:
								case JIAZZI_empty:
								case JIAZZI_external:
								case WILD:
								case ID:
								{
									break;
								}
								default:
								{
									throw new NoViableAltException(LT(1), getFilename());
								}
								}
								}
								bind_generic_r(env,sig);
							}
							else {
								break _loop88;
							}
							
						} while (true);
						}
						}
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					}
					}
					match(SEMI);
				}
				else {
					break _loop89;
				}
				
			} while (true);
			}
			{
			_loop91:
			do {
				if ((_tokenSet_17.member(LA(1)))) {
					outerclass_r(env, sig);
				}
				else {
					break _loop91;
				}
				
			} while (true);
			}
			match(RCURLY);
			}
			if ( inputState.guessing==0 ) {
				
				env.defaults.clear();
				env.defaults.addAll(old);
				
			}
		}
		catch (antlr.TokenStreamException e) {
			if (inputState.guessing==0) {
				
				this.reportError("" + e);
				
				
			} else {
				throw e;
			}
		}
		return sig;
	}
	
	public final void outerclass_r(
		UnitEnvironment env, UnitSignature sig
	) throws RecognitionException, TokenStreamException {
		
		
		Builder bld = new Builder();
		UnitClass ucls;
		
		
		try {      // for error handling
			flags_r(bld);
			ucls=class_r(env, sig, bld, null);
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_18);
			} else {
			  throw ex;
			}
		}
	}
	
	public final void flags_r(
		Builder shape
	) throws RecognitionException, TokenStreamException {
		
		
		shape.set(FlagConstants.PUBLIC);
		shape.set(FlagConstants.CONCRETE);
		/* bld.set(FlagConstants.INSTANCE); */
		
		
		try {      // for error handling
			{
			_loop96:
			do {
				switch ( LA(1)) {
				case JIAZZI_public:
				{
					match(JIAZZI_public);
					break;
				}
				case JIAZZI_protected:
				{
					match(JIAZZI_protected);
					if ( inputState.guessing==0 ) {
						shape.set(FlagConstants.PROTECTED);
					}
					break;
				}
				case JIAZZI_abstract:
				{
					match(JIAZZI_abstract);
					if ( inputState.guessing==0 ) {
						shape.set(FlagConstants.ABSTRACT);
					}
					break;
				}
				case JIAZZI_final:
				{
					match(JIAZZI_final);
					if ( inputState.guessing==0 ) {
						shape.set(FlagConstants.FINAL);
					}
					break;
				}
				case JIAZZI_static:
				{
					match(JIAZZI_static);
					if ( inputState.guessing==0 ) {
						shape.set(FlagConstants.STATIC);
					}
					break;
				}
				default:
				{
					break _loop96;
				}
				}
			} while (true);
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_19);
			} else {
			  throw ex;
			}
		}
	}
	
	public final UnitClass  class_r(
		UnitEnvironment env, UnitSignature sig, Builder bld, UnitClass outer
	) throws RecognitionException, TokenStreamException {
		UnitClass ucls;
		
		
		ClassName cname=new ClassName("");
		ucls = null;
		ClassShape shape=null;
		ExpandedName exp=null;
		ClassType zuper=null;
		Builder bld1 = new Builder();
		UnitClass inner=null;
		String iname=null;
		Name nm = null;
		
		
		try {      // for error handling
			{
			switch ( LA(1)) {
			case JIAZZI_interface:
			{
				match(JIAZZI_interface);
				if ( inputState.guessing==0 ) {
					
					bld.set(FlagConstants.INTERFACE);
					bld.set(FlagConstants.ABSTRACT);
					
				}
				break;
			}
			case JIAZZI_class:
			{
				match(JIAZZI_class);
				if ( inputState.guessing==0 ) {
					
					
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			nm=name_r(env,sig,cname);
			if ( inputState.guessing==0 ) {
				
				cname = (ClassName) nm;
				if (outer != null) cname = cname.setOuter(outer.name());
				if (sig.self().containsClass(cname.nopkg())) {
				ucls = (UnitClass) sig.self().classes().get(cname.nopkg());
				} else {
				ucls = new UnitClass(sig.self(), cname.nopkg());
				}
				if (ucls.isShapeSet()) {
				shape = ucls.shape();
				} else {
				shape = new ClassShape();
				ucls.setShape(shape);
				shape.add(bld);
				}
				
			}
			{
			switch ( LA(1)) {
			case JIAZZI_extends:
			{
				match(JIAZZI_extends);
				{
				_loop102:
				do {
					if ((_tokenSet_20.member(LA(1)))) {
						{
						switch ( LA(1)) {
						case COMMA:
						{
							match(COMMA);
							break;
						}
						case JIAZZI_unit:
						case JIAZZI_atom:
						case JIAZZI_compound:
						case JIAZZI_signature:
						case JIAZZI_bind:
						case JIAZZI_link:
						case JIAZZI_to:
						case JIAZZI_open:
						case JIAZZI_name:
						case JIAZZI_arg:
						case JIAZZI_generic:
						case JIAZZI_export:
						case JIAZZI_local:
						case JIAZZI_empty:
						case JIAZZI_external:
						case ID:
						{
							break;
						}
						default:
						{
							throw new NoViableAltException(LT(1), getFilename());
						}
						}
						}
						zuper=supertype_r(env, sig);
						if ( inputState.guessing==0 ) {
							
							if (shape.binaries().contains(FlagConstants.INTERFACE))
							shape.addInterface(zuper);
							else shape.setZuper(zuper);
							
						}
					}
					else {
						break _loop102;
					}
					
				} while (true);
				}
				break;
			}
			case JIAZZI_implements:
			case PLUS:
			case LCURLY:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			switch ( LA(1)) {
			case JIAZZI_implements:
			{
				match(JIAZZI_implements);
				{
				_loop106:
				do {
					if ((_tokenSet_20.member(LA(1)))) {
						{
						switch ( LA(1)) {
						case COMMA:
						{
							match(COMMA);
							break;
						}
						case JIAZZI_unit:
						case JIAZZI_atom:
						case JIAZZI_compound:
						case JIAZZI_signature:
						case JIAZZI_bind:
						case JIAZZI_link:
						case JIAZZI_to:
						case JIAZZI_open:
						case JIAZZI_name:
						case JIAZZI_arg:
						case JIAZZI_generic:
						case JIAZZI_export:
						case JIAZZI_local:
						case JIAZZI_empty:
						case JIAZZI_external:
						case ID:
						{
							break;
						}
						default:
						{
							throw new NoViableAltException(LT(1), getFilename());
						}
						}
						}
						zuper=supertype_r(env, sig);
						if ( inputState.guessing==0 ) {
							
							shape.addInterface(zuper);
							
						}
					}
					else {
						break _loop106;
					}
					
				} while (true);
				}
				break;
			}
			case PLUS:
			case LCURLY:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			switch ( LA(1)) {
			case PLUS:
			{
				match(PLUS);
				match(EQUAL);
				break;
			}
			case LCURLY:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			match(LCURLY);
			{
			_loop113:
			do {
				if ((_tokenSet_21.member(LA(1)))) {
					if ( inputState.guessing==0 ) {
						
						bld1 = new Builder();
						
					}
					flags_r(bld1);
					if ( inputState.guessing==0 ) {
						
						
					}
					{
					switch ( LA(1)) {
					case JIAZZI_class:
					case JIAZZI_interface:
					{
						{
						inner=class_r(env, sig, bld1, ucls);
						if ( inputState.guessing==0 ) {
							
							
							
						}
						}
						break;
					}
					case JIAZZI_unit:
					case JIAZZI_atom:
					case JIAZZI_compound:
					case JIAZZI_signature:
					case JIAZZI_bind:
					case JIAZZI_link:
					case JIAZZI_to:
					case JIAZZI_open:
					case JIAZZI_name:
					case JIAZZI_arg:
					case JIAZZI_generic:
					case JIAZZI_export:
					case JIAZZI_local:
					case JIAZZI_empty:
					case JIAZZI_external:
					case JIAZZI_void:
					case JIAZZI_boolean:
					case JIAZZI_byte:
					case JIAZZI_short:
					case JIAZZI_char:
					case JIAZZI_int:
					case JIAZZI_long:
					case JIAZZI_double:
					case JIAZZI_float:
					case JIAZZI_true:
					case JIAZZI_false:
					case LPAREN:
					case EQUAL:
					case SEMI:
					case ID:
					{
						{
						member_r(env,sig,shape,bld1);
						}
						match(SEMI);
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					}
					}
				}
				else {
					break _loop113;
				}
				
			} while (true);
			}
			match(RCURLY);
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_22);
			} else {
			  throw ex;
			}
		}
		return ucls;
	}
	
	public final MemberName  membername_r(
		UnitEnvironment env, UnitSignature sig
	) throws RecognitionException, TokenStreamException {
		MemberName nm;
		
		
		nm = new MemberName();
		Name nm0;
		
		
		try {      // for error handling
			nm0=name_r(env, sig, nm);
			if ( inputState.guessing==0 ) {
				
				nm = (MemberName) nm0;
				
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_23);
			} else {
			  throw ex;
			}
		}
		return nm;
	}
	
	public final ClassType  supertype_r(
		UnitEnvironment env, UnitSignature sig
	) throws RecognitionException, TokenStreamException {
		ClassType ctype;
		
		
		String name;
		ctype = null;
		ClassName cname = null;
		ClassName inner;
		
		
		try {      // for error handling
			name=id_r();
			{
			switch ( LA(1)) {
			case DOT:
			{
				ctype=classtype_r(env, sig, name);
				break;
			}
			case JIAZZI_unit:
			case JIAZZI_atom:
			case JIAZZI_compound:
			case JIAZZI_signature:
			case JIAZZI_bind:
			case JIAZZI_link:
			case JIAZZI_to:
			case JIAZZI_open:
			case JIAZZI_name:
			case JIAZZI_arg:
			case JIAZZI_generic:
			case JIAZZI_export:
			case JIAZZI_local:
			case JIAZZI_empty:
			case JIAZZI_external:
			case JIAZZI_implements:
			case JIAZZI_true:
			case JIAZZI_false:
			case PLUS:
			case LCURLY:
			case EQUAL:
			case SEMI:
			case COMMA:
			case DOLLAR:
			case ID:
			case BRACKETS:
			{
				{
				if ( inputState.guessing==0 ) {
					
					// PackageType pkg = env.platform().findPackage(new PackageName("java.lang"));
					cname = new ClassName(name);
					
				}
				{
				switch ( LA(1)) {
				case DOLLAR:
				{
					match(DOLLAR);
					inner=classname_r(env,sig);
					if ( inputState.guessing==0 ) {
						
						cname = inner.setOuter(cname);
						
					}
					break;
				}
				case JIAZZI_unit:
				case JIAZZI_atom:
				case JIAZZI_compound:
				case JIAZZI_signature:
				case JIAZZI_bind:
				case JIAZZI_link:
				case JIAZZI_to:
				case JIAZZI_open:
				case JIAZZI_name:
				case JIAZZI_arg:
				case JIAZZI_generic:
				case JIAZZI_export:
				case JIAZZI_local:
				case JIAZZI_empty:
				case JIAZZI_external:
				case JIAZZI_implements:
				case JIAZZI_true:
				case JIAZZI_false:
				case PLUS:
				case LCURLY:
				case EQUAL:
				case SEMI:
				case COMMA:
				case ID:
				case BRACKETS:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				if ( inputState.guessing==0 ) {
					
					if (sig.self().containsClass(cname)) {
					ctype = sig.self().findClass(cname);
					} else  for (Iterator i = env.defaults.iterator(); i.hasNext(); /* i = i */) {
					PackageModel pkg = (PackageModel) i.next();
					if (pkg.containsClass(cname)) ctype = pkg.findClass(cname);
					if (ctype != null) break;
					}
					if (ctype == null) {
					if (sig.self().containsClass(cname)) {
					ctype = sig.self().findClass(cname);
					} else {
					UnitClass ucls = new UnitClass(sig.self(), cname);
					ctype = sig.self().findClass(cname);
					}
					}
					// this.reportError("cannot find class " + cname + " in java.lang");
					//  
					// ctype = pkg.findClass(new ClassName("Object"));
					
				}
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_24);
			} else {
			  throw ex;
			}
		}
		return ctype;
	}
	
	public final void member_r(
		UnitEnvironment env, UnitSignature sig, ClassShape shape, Builder bld
	) throws RecognitionException, TokenStreamException {
		
		
		ExpandedName exp;
		NameTypeShape nt = null;
		ProcedureShape proc = null;
		ThrowzShape throwz = null;
		Object cnst = null;
		
		
		try {      // for error handling
			if ( inputState.guessing==0 ) {
			}
			{
			{
			if ((_tokenSet_10.member(LA(1))) && (_tokenSet_23.member(LA(2)))) {
				exp=expanded0_r(env,sig);
			}
			else if ((_tokenSet_25.member(LA(1))) && (_tokenSet_26.member(LA(2)))) {
				nt=nt_r(env,sig);
			}
			else if ((_tokenSet_23.member(LA(1)))) {
				if ( inputState.guessing==0 ) {
				}
			}
			else {
				throw new NoViableAltException(LT(1), getFilename());
			}
			
			}
			{
			switch ( LA(1)) {
			case LPAREN:
			{
				proc=proc_r(env,sig);
				throwz=throwz_r(env,sig);
				if ( inputState.guessing==0 ) {
				}
				{
				_loop124:
				do {
					if ((LA(1)==BRACKETS)) {
						match(BRACKETS);
						if ( inputState.guessing==0 ) {
							
								 if (nt != null) nt = nt.setType(nt.type().up());
							
						}
					}
					else {
						break _loop124;
					}
					
				} while (true);
				}
				break;
			}
			case JIAZZI_true:
			case JIAZZI_false:
			case EQUAL:
			case SEMI:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			switch ( LA(1)) {
			case JIAZZI_true:
			case JIAZZI_false:
			case EQUAL:
			{
				cnst=constant_r();
				break;
			}
			case SEMI:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			}
			if ( inputState.guessing==0 ) {
				
				if (false) {
				} else if (nt == null && proc != null) {
				InitShape init = new InitShape();
				init.add(bld);
				init.set(proc); init.set(throwz);
				shape.add(init);
				} else if (proc == null && nt != null) {
				FieldShape fld = new FieldShape();
				fld.add(bld);
				fld.set(nt);
				if (shape.binaries().contains(FlagConstants.INTERFACE)) {
				fld.set(FlagConstants.STATIC);
				fld.set(FlagConstants.IMMUTABLE);
				}
				if (cnst != null) {
				if (cnst instanceof Integer && !nt.type().equals(TypeConstants.INT)) {
					 
					this.reportError("integer compile time constant cannot be added to " + fld);
				}
				if (cnst instanceof Boolean && !nt.type().equals(TypeConstants.BOOLEAN)) {
					 
					this.reportError("boolean compile time constant cannot be added to " + fld);
				}
				if (!fld.isSet(FlagConstants.STATIC) || !fld.isSet(FlagConstants.IMMUTABLE)) {
					 
					this.reportError("compile time constant cannot be added to " + fld);
				}
				fld.setConstant(cnst);
				}
				shape.add(fld);
				} else if (proc != null && nt != null) {
				MethodShape mthd = new MethodShape();
				mthd.add(bld);
				mthd.set(nt); mthd.set(proc); mthd.set(throwz);
				if (shape.binaries().contains(FlagConstants.INTERFACE)) {
				mthd.set(FlagConstants.ABSTRACT);
				}
				shape.add(mthd);
				}
				
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_3);
			} else {
			  throw ex;
			}
		}
	}
	
	public final Object  constant_r(
		
	) throws RecognitionException, TokenStreamException {
		Object cnst;
		
		Token  a = null;
		Token  c = null;
		
		cnst = null;
		boolean minus = false;
		
		
		try {      // for error handling
			switch ( LA(1)) {
			case EQUAL:
			{
				match(EQUAL);
				{
				{
				switch ( LA(1)) {
				case MINUS:
				{
					match(MINUS);
					if ( inputState.guessing==0 ) {
						minus = true;
					}
					break;
				}
				case INTEGER_TEN:
				case INTEGER_HEX:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				{
				switch ( LA(1)) {
				case INTEGER_TEN:
				{
					a = LT(1);
					match(INTEGER_TEN);
					if ( inputState.guessing==0 ) {
						
						cnst = Integer.valueOf(a.getText(), 10);
						
					}
					break;
				}
				case INTEGER_HEX:
				{
					c = LT(1);
					match(INTEGER_HEX);
					if ( inputState.guessing==0 ) {
						
						cnst = Integer.valueOf(a.getText().substring(2, a.getText().length()), 16);
						
					}
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				if ( inputState.guessing==0 ) {
					
					if (minus) cnst = new Integer(-((Integer) cnst).intValue());
					
				}
				}
				break;
			}
			case JIAZZI_true:
			case JIAZZI_false:
			{
				{
				switch ( LA(1)) {
				case JIAZZI_true:
				{
					match(JIAZZI_true);
					if ( inputState.guessing==0 ) {
						cnst = new Boolean(true);
					}
					break;
				}
				case JIAZZI_false:
				{
					match(JIAZZI_false);
					if ( inputState.guessing==0 ) {
						cnst = new Boolean(false);
					}
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_3);
			} else {
			  throw ex;
			}
		}
		return cnst;
	}
	
	public final NameTypeShape  nt_r(
		UnitEnvironment env, UnitSignature sig
	) throws RecognitionException, TokenStreamException {
		NameTypeShape nt;
		
		
		nt = new NameTypeShape();
		TypeType tp;
		MemberName mmbr;
		
		
		try {      // for error handling
			tp=type_r(env,sig);
			mmbr=membername_r(env,sig);
			if ( inputState.guessing==0 ) {
				
				nt = nt.setType(tp).setName(mmbr);
				
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_23);
			} else {
			  throw ex;
			}
		}
		return nt;
	}
	
	public final ThrowzShape  throwz_r(
		UnitEnvironment env, UnitSignature sig
	) throws RecognitionException, TokenStreamException {
		ThrowzShape throwz;
		
		
		ClassType ctype;
		throwz = new ThrowzShape();
		
		
		try {      // for error handling
			{
			switch ( LA(1)) {
			case JIAZZI_throws:
			{
				match(JIAZZI_throws);
				ctype=supertype_r(env,sig);
				if ( inputState.guessing==0 ) {
					
					throwz = throwz.add(ctype);
					
				}
				{
				_loop137:
				do {
					if ((LA(1)==COMMA)) {
						{
						match(COMMA);
						}
						ctype=supertype_r(env,sig);
						if ( inputState.guessing==0 ) {
							
							throwz = throwz.add(ctype);
							
						}
					}
					else {
						break _loop137;
					}
					
				} while (true);
				}
				break;
			}
			case JIAZZI_true:
			case JIAZZI_false:
			case EQUAL:
			case SEMI:
			case BRACKETS:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_27);
			} else {
			  throw ex;
			}
		}
		return throwz;
	}
	
	public final TypeType  type_r(
		UnitEnvironment env, UnitSignature sig
	) throws RecognitionException, TokenStreamException {
		TypeType tp;
		
		
		tp = null;
		
		
		try {      // for error handling
			{
			switch ( LA(1)) {
			case JIAZZI_void:
			case JIAZZI_boolean:
			case JIAZZI_byte:
			case JIAZZI_short:
			case JIAZZI_char:
			case JIAZZI_int:
			case JIAZZI_long:
			case JIAZZI_double:
			case JIAZZI_float:
			{
				tp=primitive_r();
				break;
			}
			case JIAZZI_unit:
			case JIAZZI_atom:
			case JIAZZI_compound:
			case JIAZZI_signature:
			case JIAZZI_bind:
			case JIAZZI_link:
			case JIAZZI_to:
			case JIAZZI_open:
			case JIAZZI_name:
			case JIAZZI_arg:
			case JIAZZI_generic:
			case JIAZZI_export:
			case JIAZZI_local:
			case JIAZZI_empty:
			case JIAZZI_external:
			case ID:
			{
				tp=reftype0_r(env,sig);
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			_loop145:
			do {
				if ((LA(1)==BRACKETS)) {
					match(BRACKETS);
					if ( inputState.guessing==0 ) {
						
						tp = tp.up();
						
					}
				}
				else {
					break _loop145;
				}
				
			} while (true);
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_28);
			} else {
			  throw ex;
			}
		}
		return tp;
	}
	
	public final ProcedureShape  arg_r(
		UnitEnvironment env, UnitSignature sig, ProcedureShape proc0
	) throws RecognitionException, TokenStreamException {
		ProcedureShape proc;
		
		
		proc = proc0;
		TypeType tp;
		String name;
		
		
		try {      // for error handling
			tp=type_r(env,sig);
			{
			switch ( LA(1)) {
			case JIAZZI_unit:
			case JIAZZI_atom:
			case JIAZZI_compound:
			case JIAZZI_signature:
			case JIAZZI_bind:
			case JIAZZI_link:
			case JIAZZI_to:
			case JIAZZI_open:
			case JIAZZI_name:
			case JIAZZI_arg:
			case JIAZZI_generic:
			case JIAZZI_export:
			case JIAZZI_local:
			case JIAZZI_empty:
			case JIAZZI_external:
			case ID:
			{
				name=id_r();
				{
				_loop141:
				do {
					if ((LA(1)==BRACKETS)) {
						match(BRACKETS);
						if ( inputState.guessing==0 ) {
							
							tp = tp.up();
							
						}
					}
					else {
						break _loop141;
					}
					
				} while (true);
				}
				if ( inputState.guessing==0 ) {
					
					proc = proc.addArg((new ArgShape()).setType(tp).setName(name));
					
				}
				break;
			}
			case RPAREN:
			case COMMA:
			{
				if ( inputState.guessing==0 ) {
					
					proc = proc.addArg(tp);
					
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_29);
			} else {
			  throw ex;
			}
		}
		return proc;
	}
	
	public final PrimitiveType  primitive_r(
		
	) throws RecognitionException, TokenStreamException {
		PrimitiveType tp;
		
		
		tp = null;
		
		
		try {      // for error handling
			{
			switch ( LA(1)) {
			case JIAZZI_boolean:
			{
				match(JIAZZI_boolean);
				if ( inputState.guessing==0 ) {
					tp = TypeConstants.BOOLEAN;
				}
				break;
			}
			case JIAZZI_byte:
			{
				match(JIAZZI_byte);
				if ( inputState.guessing==0 ) {
					tp = TypeConstants.BYTE;
				}
				break;
			}
			case JIAZZI_char:
			{
				match(JIAZZI_char);
				if ( inputState.guessing==0 ) {
					tp = TypeConstants.CHAR;
				}
				break;
			}
			case JIAZZI_short:
			{
				match(JIAZZI_short);
				if ( inputState.guessing==0 ) {
					tp = TypeConstants.SHORT;
				}
				break;
			}
			case JIAZZI_int:
			{
				match(JIAZZI_int);
				if ( inputState.guessing==0 ) {
					tp = TypeConstants.INT;
				}
				break;
			}
			case JIAZZI_long:
			{
				match(JIAZZI_long);
				if ( inputState.guessing==0 ) {
					tp = TypeConstants.LONG;
				}
				break;
			}
			case JIAZZI_float:
			{
				match(JIAZZI_float);
				if ( inputState.guessing==0 ) {
					tp = TypeConstants.FLOAT;
				}
				break;
			}
			case JIAZZI_double:
			{
				match(JIAZZI_double);
				if ( inputState.guessing==0 ) {
					tp = TypeConstants.DOUBLE;
				}
				break;
			}
			case JIAZZI_void:
			{
				match(JIAZZI_void);
				if ( inputState.guessing==0 ) {
					tp = TypeConstants.VOID;
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_30);
			} else {
			  throw ex;
			}
		}
		return tp;
	}
	
	public final RefType  reftype0_r(
		UnitEnvironment env, UnitRoot root
	) throws RecognitionException, TokenStreamException {
		RefType ref;
		
		
		ref = null;
		ExpandedName exp;
		String name = null;
		RefType param;
		ClassName inner;
		ClassName CONSTANT = new ClassName("");
		ClassName cname = null;
		
		
		try {      // for error handling
			exp=expanded0_r(env,root);
			{
			switch ( LA(1)) {
			case DOT:
			{
				{
				if ( inputState.guessing==0 ) {
					
					if (exp.var() != VariableName.NULL) {
					
					this.reportError("not expecting variable in package name " + exp);
					}
					name = exp.extract();
					
				}
				ref=classtype_r(env, root, name);
				}
				break;
			}
			case JIAZZI_unit:
			case JIAZZI_atom:
			case JIAZZI_compound:
			case JIAZZI_signature:
			case JIAZZI_bind:
			case JIAZZI_link:
			case JIAZZI_to:
			case JIAZZI_open:
			case JIAZZI_name:
			case JIAZZI_arg:
			case JIAZZI_generic:
			case JIAZZI_export:
			case JIAZZI_local:
			case JIAZZI_empty:
			case JIAZZI_external:
			case JIAZZI_void:
			case JIAZZI_boolean:
			case JIAZZI_byte:
			case JIAZZI_short:
			case JIAZZI_char:
			case JIAZZI_int:
			case JIAZZI_long:
			case JIAZZI_double:
			case JIAZZI_float:
			case LT:
			case GT:
			case RPAREN:
			case COMMA:
			case DOLLAR:
			case ID:
			case BRACKETS:
			{
				{
				if ( inputState.guessing==0 ) {
					
					cname = (ClassName) (new ClassName()).setExpanded(exp);
					
				}
				{
				switch ( LA(1)) {
				case DOLLAR:
				{
					{
					match(DOLLAR);
					}
					inner=classname_r(env,root);
					if ( inputState.guessing==0 ) {
						
						cname = inner.setOuter(cname);
						
					}
					break;
				}
				case JIAZZI_unit:
				case JIAZZI_atom:
				case JIAZZI_compound:
				case JIAZZI_signature:
				case JIAZZI_bind:
				case JIAZZI_link:
				case JIAZZI_to:
				case JIAZZI_open:
				case JIAZZI_name:
				case JIAZZI_arg:
				case JIAZZI_generic:
				case JIAZZI_export:
				case JIAZZI_local:
				case JIAZZI_empty:
				case JIAZZI_external:
				case JIAZZI_void:
				case JIAZZI_boolean:
				case JIAZZI_byte:
				case JIAZZI_short:
				case JIAZZI_char:
				case JIAZZI_int:
				case JIAZZI_long:
				case JIAZZI_double:
				case JIAZZI_float:
				case LT:
				case GT:
				case RPAREN:
				case COMMA:
				case ID:
				case BRACKETS:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				if ( inputState.guessing==0 ) {
					
					name = null;
					if (exp.var() == VariableName.NULL) name = exp.extract();
					// PackageType jlpkg = env.platform().findPackage(new PackageName("java.lang"));
					// System.err.println("XXX " + name + " " + exp + " " + exp.var() + " " + root.generics().keySet());
					
					ref = null;
					if (name != null && root.generics().containsKey(name)) {
					ref = (VariableType) root.generics().get(name);
					} else if (root instanceof UnitSignature &&
						     ((UnitSignature) root).self().containsClass(cname)) {
					ref = ((UnitSignature) root).self().findClass(cname);
					} else for (Iterator i = env.defaults.iterator(); i.hasNext(); /* i = i */) {
					PackageModel pkg = (PackageModel) i.next();
					if (pkg.containsClass(cname)) {
					ref = pkg.findClass(cname);
					break;
					}
					}
					if (ref == null && (root instanceof UnitSignature)) {
					UnitSignature usig = (UnitSignature) root;
					if (usig.self().containsClass(cname)) {
					ref = usig.self().findClass(cname);
					} else { 
					UnitClass ucls = new UnitClass(usig.self(), cname);
					ref = usig.self().findClass(cname);
					}
					} 
					if (ref == null) {
					this.reportError("cannot find class " + cname + " in " + root + "'s generics or in java.lang");
					ref = env.platform().findPackage(new PackageName("java.lang")).findClass(new ClassName("Object"));
					}
					
				}
				{
				{
				switch ( LA(1)) {
				case LT:
				{
					match(LT);
					{
					int _cnt165=0;
					_loop165:
					do {
						if ((_tokenSet_31.member(LA(1)))) {
							{
							switch ( LA(1)) {
							case COMMA:
							{
								match(COMMA);
								break;
							}
							case JIAZZI_unit:
							case JIAZZI_atom:
							case JIAZZI_compound:
							case JIAZZI_signature:
							case JIAZZI_bind:
							case JIAZZI_link:
							case JIAZZI_to:
							case JIAZZI_open:
							case JIAZZI_name:
							case JIAZZI_arg:
							case JIAZZI_generic:
							case JIAZZI_export:
							case JIAZZI_local:
							case JIAZZI_empty:
							case JIAZZI_external:
							case JIAZZI_void:
							case JIAZZI_boolean:
							case JIAZZI_byte:
							case JIAZZI_short:
							case JIAZZI_char:
							case JIAZZI_int:
							case JIAZZI_long:
							case JIAZZI_double:
							case JIAZZI_float:
							case ID:
							{
								break;
							}
							default:
							{
								throw new NoViableAltException(LT(1), getFilename());
							}
							}
							}
							param=reftype_r(env,root);
							if ( inputState.guessing==0 ) {
								
								ref = ((ClassType) ref).addParam(param);
								
							}
						}
						else {
							if ( _cnt165>=1 ) { break _loop165; } else {throw new NoViableAltException(LT(1), getFilename());}
						}
						
						_cnt165++;
					} while (true);
					}
					match(GT);
					break;
				}
				case JIAZZI_unit:
				case JIAZZI_atom:
				case JIAZZI_compound:
				case JIAZZI_signature:
				case JIAZZI_bind:
				case JIAZZI_link:
				case JIAZZI_to:
				case JIAZZI_open:
				case JIAZZI_name:
				case JIAZZI_arg:
				case JIAZZI_generic:
				case JIAZZI_export:
				case JIAZZI_local:
				case JIAZZI_empty:
				case JIAZZI_external:
				case JIAZZI_void:
				case JIAZZI_boolean:
				case JIAZZI_byte:
				case JIAZZI_short:
				case JIAZZI_char:
				case JIAZZI_int:
				case JIAZZI_long:
				case JIAZZI_double:
				case JIAZZI_float:
				case GT:
				case RPAREN:
				case COMMA:
				case ID:
				case BRACKETS:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				}
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_32);
			} else {
			  throw ex;
			}
		}
		return ref;
	}
	
	public final RefType  reftype_r(
		UnitEnvironment env, UnitRoot root
	) throws RecognitionException, TokenStreamException {
		RefType tref;
		
		
		tref = null;
		PrimitiveType tp;
		
		
		try {      // for error handling
			{
			switch ( LA(1)) {
			case JIAZZI_void:
			case JIAZZI_boolean:
			case JIAZZI_byte:
			case JIAZZI_short:
			case JIAZZI_char:
			case JIAZZI_int:
			case JIAZZI_long:
			case JIAZZI_double:
			case JIAZZI_float:
			{
				{
				tp=primitive_r();
				match(BRACKETS);
				if ( inputState.guessing==0 ) {
					
					tref = tp.up();
					
				}
				}
				break;
			}
			case JIAZZI_unit:
			case JIAZZI_atom:
			case JIAZZI_compound:
			case JIAZZI_signature:
			case JIAZZI_bind:
			case JIAZZI_link:
			case JIAZZI_to:
			case JIAZZI_open:
			case JIAZZI_name:
			case JIAZZI_arg:
			case JIAZZI_generic:
			case JIAZZI_export:
			case JIAZZI_local:
			case JIAZZI_empty:
			case JIAZZI_external:
			case ID:
			{
				tref=reftype0_r(env,root);
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			_loop150:
			do {
				if ((LA(1)==BRACKETS)) {
					match(BRACKETS);
					if ( inputState.guessing==0 ) {
						
						tref = tref.up();
						
					}
				}
				else {
					break _loop150;
				}
				
			} while (true);
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_33);
			} else {
			  throw ex;
			}
		}
		return tref;
	}
	
	public final ClassType  classtype_r(
		UnitEnvironment env, UnitRoot root, String name
	) throws RecognitionException, TokenStreamException {
		ClassType ctype;
		
		
		ctype = null;
		String sname;
		PackageType pkg = null;
		
		
		try {      // for error handling
			{
			{
			_loop169:
			do {
				if ((LA(1)==DOT) && (_tokenSet_10.member(LA(2))) && (LA(3)==DOT)) {
					match(DOT);
					sname=id_r();
					if ( inputState.guessing==0 ) {
						
						name = name + '.' + sname;
						
					}
				}
				else {
					break _loop169;
				}
				
			} while (true);
			}
			if ( inputState.guessing==0 ) {
				
				PackageName pname = new PackageName(name);
				if (root.packages().containsKey(pname) &&
				((UnitPackage) root.packages().get(pname)).isParam()) pkg = (UnitPackage) root.packages().get(pname);
				else if (env.platform().containsPackage(pname)) pkg = env.platform().findPackage(pname);
				else {
				this.reportError("cannot find package " + pname + " in " + root + " or classpath " + env.platform());
				pkg = null;
				}
				
			}
			match(DOT);
			}
			ctype=classtype1_r(env, root, pkg);
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_34);
			} else {
			  throw ex;
			}
		}
		return ctype;
	}
	
	public final ClassType  classtype1_r(
		UnitEnvironment env, UnitRoot root, PackageType pkg
	) throws RecognitionException, TokenStreamException {
		ClassType ctype;
		
		
		ClassName cname;
		ctype=null;
		RefType param;
		
		
		try {      // for error handling
			cname=classname_r(env,root);
			if ( inputState.guessing==0 ) {
				
				if (pkg != null && pkg.containsClass(cname)) {
				ctype = pkg.findClass(cname);
				} else {
				if (pkg != null && !pkg.containsClass(cname)) {
				this.reportError("cannot find " + cname + " in " + pkg);
				}
				ctype = env.platform().findClass(new ClassName("java.lang.Object"));
				}
				
			}
			{
			switch ( LA(1)) {
			case LT:
			{
				match(LT);
				{
				int _cnt174=0;
				_loop174:
				do {
					if ((_tokenSet_31.member(LA(1)))) {
						{
						switch ( LA(1)) {
						case COMMA:
						{
							match(COMMA);
							break;
						}
						case JIAZZI_unit:
						case JIAZZI_atom:
						case JIAZZI_compound:
						case JIAZZI_signature:
						case JIAZZI_bind:
						case JIAZZI_link:
						case JIAZZI_to:
						case JIAZZI_open:
						case JIAZZI_name:
						case JIAZZI_arg:
						case JIAZZI_generic:
						case JIAZZI_export:
						case JIAZZI_local:
						case JIAZZI_empty:
						case JIAZZI_external:
						case JIAZZI_void:
						case JIAZZI_boolean:
						case JIAZZI_byte:
						case JIAZZI_short:
						case JIAZZI_char:
						case JIAZZI_int:
						case JIAZZI_long:
						case JIAZZI_double:
						case JIAZZI_float:
						case ID:
						{
							break;
						}
						default:
						{
							throw new NoViableAltException(LT(1), getFilename());
						}
						}
						}
						param=reftype_r(env,root);
						if ( inputState.guessing==0 ) {
							
							ctype = ((ClassType) ctype).addParam(param);
							
						}
					}
					else {
						if ( _cnt174>=1 ) { break _loop174; } else {throw new NoViableAltException(LT(1), getFilename());}
					}
					
					_cnt174++;
				} while (true);
				}
				match(GT);
				break;
			}
			case JIAZZI_unit:
			case JIAZZI_atom:
			case JIAZZI_compound:
			case JIAZZI_signature:
			case JIAZZI_bind:
			case JIAZZI_link:
			case JIAZZI_to:
			case JIAZZI_open:
			case JIAZZI_name:
			case JIAZZI_arg:
			case JIAZZI_generic:
			case JIAZZI_export:
			case JIAZZI_local:
			case JIAZZI_empty:
			case JIAZZI_external:
			case JIAZZI_implements:
			case JIAZZI_void:
			case JIAZZI_boolean:
			case JIAZZI_byte:
			case JIAZZI_short:
			case JIAZZI_char:
			case JIAZZI_int:
			case JIAZZI_long:
			case JIAZZI_double:
			case JIAZZI_float:
			case JIAZZI_true:
			case JIAZZI_false:
			case PLUS:
			case GT:
			case LCURLY:
			case RPAREN:
			case EQUAL:
			case SEMI:
			case COMMA:
			case ID:
			case BRACKETS:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_34);
			} else {
			  throw ex;
			}
		}
		return ctype;
	}
	
	public final Unit  unit_r(
		UnitEnvironment env
	) throws RecognitionException, TokenStreamException {
		Unit unit;
		
		
		unit = null;
		
		
		try {      // for error handling
			{
			switch ( LA(1)) {
			case JIAZZI_atom:
			{
				match(JIAZZI_atom);
				unit=atom_r(env);
				break;
			}
			case JIAZZI_compound:
			{
				match(JIAZZI_compound);
				unit=compound_r(env);
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
		}
		catch (antlr.TokenStreamException e) {
			if (inputState.guessing==0) {
				
				this.reportError("" + e);
				
				
			} else {
				throw e;
			}
		}
		return unit;
	}
	
	public final AtomUnit  atom_r(
		UnitEnvironment env
	) throws RecognitionException, TokenStreamException {
		AtomUnit atom;
		
		
		atom = null;
		String uname; 
		
		
		try {      // for error handling
			{
			uname=longid_r();
			if ( inputState.guessing==0 ) {
				
				atom = new AtomUnit(uname);
				
			}
			{
			match(LCURLY);
			unitsignature_r(env,atom);
			}
			if ( inputState.guessing==0 ) {
			}
			match(RCURLY);
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_35);
			} else {
			  throw ex;
			}
		}
		return atom;
	}
	
	public final CompoundUnit  compound_r(
		UnitEnvironment env
	) throws RecognitionException, TokenStreamException {
		CompoundUnit compound;
		
		
		compound = null;
		String uname;   
		
		
		try {      // for error handling
			{
			uname=longid_r();
			if ( inputState.guessing==0 ) {
				
				compound = new CompoundUnit(uname);
				
			}
			{
			match(LCURLY);
			unitsignature_r(env,compound);
			if ( inputState.guessing==0 ) {
				
				
			}
			{
			if ((LA(1)==RCURLY) && (LA(2)==LCURLY)) {
				match(RCURLY);
				match(LCURLY);
			}
			else if ((LA(1)==JIAZZI_link||LA(1)==RCURLY) && (_tokenSet_36.member(LA(2)))) {
			}
			else {
				throw new NoViableAltException(LT(1), getFilename());
			}
			
			}
			linkage_r(env,compound);
			}
			match(RCURLY);
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_35);
			} else {
			  throw ex;
			}
		}
		return compound;
	}
	
	public final void unitsignature_r(
		UnitEnvironment env, Unit unit
	) throws RecognitionException, TokenStreamException {
		
		
		VariableType generic=null;
		VariableName lexeme=null;
		UnitPackage upkg=null;
		int mode = -1; 
		String pname;
		String sid = null;
		final int IMPORT = 0;
		final int EXPORT = 1;
		final int OPEN = 2;
		UnitOpen open = null;
		
		
		try {      // for error handling
			{
			{
			_loop198:
			do {
				if ((_tokenSet_37.member(LA(1)))) {
					{
					switch ( LA(1)) {
					case JIAZZI_generic:
					{
						{
						match(JIAZZI_generic);
						generic=generic_decl_r(env,unit);
						{
						_loop192:
						do {
							if ((LA(1)==COMMA)) {
								match(COMMA);
								generic=generic_decl_r(env,unit);
							}
							else {
								break _loop192;
							}
							
						} while (true);
						}
						}
						break;
					}
					case JIAZZI_open:
					{
						{
						open_r(env,unit);
						}
						break;
					}
					case JIAZZI_import:
					case JIAZZI_export:
					{
						{
						{
						switch ( LA(1)) {
						case JIAZZI_import:
						{
							{
							match(JIAZZI_import);
							if ( inputState.guessing==0 ) {
								mode = IMPORT;
							}
							}
							break;
						}
						case JIAZZI_export:
						{
							{
							match(JIAZZI_export);
							if ( inputState.guessing==0 ) {
								mode = EXPORT;
							}
							}
							break;
						}
						default:
						{
							throw new NoViableAltException(LT(1), getFilename());
						}
						}
						}
						upkg=pkg_decl_r(env,unit);
						if ( inputState.guessing==0 ) {
							
								switch (mode) {
								case IMPORT: unit.makeImport(upkg); break;
								case EXPORT: unit.makeExport(upkg); break;
								default: throw new Error("stupid");
								}
							
						}
						}
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					}
					}
					match(SEMI);
				}
				else {
					break _loop198;
				}
				
			} while (true);
			}
			{
			_loop209:
			do {
				if ((LA(1)==JIAZZI_bind)) {
					match(JIAZZI_bind);
					{
					switch ( LA(1)) {
					case JIAZZI_package:
					{
						{
						match(JIAZZI_package);
						{
						_loop204:
						do {
							if ((_tokenSet_16.member(LA(1)))) {
								{
								switch ( LA(1)) {
								case COMMA:
								{
									match(COMMA);
									break;
								}
								case JIAZZI_unit:
								case JIAZZI_atom:
								case JIAZZI_compound:
								case JIAZZI_signature:
								case JIAZZI_bind:
								case JIAZZI_link:
								case JIAZZI_to:
								case JIAZZI_open:
								case JIAZZI_name:
								case JIAZZI_arg:
								case JIAZZI_generic:
								case JIAZZI_export:
								case JIAZZI_local:
								case JIAZZI_empty:
								case JIAZZI_external:
								case WILD:
								case ID:
								{
									break;
								}
								default:
								{
									throw new NoViableAltException(LT(1), getFilename());
								}
								}
								}
								bind_pkg_r(env,unit);
							}
							else {
								break _loop204;
							}
							
						} while (true);
						}
						}
						break;
					}
					case JIAZZI_generic:
					{
						{
						match(JIAZZI_generic);
						{
						_loop208:
						do {
							if ((_tokenSet_16.member(LA(1)))) {
								{
								switch ( LA(1)) {
								case COMMA:
								{
									match(COMMA);
									break;
								}
								case JIAZZI_unit:
								case JIAZZI_atom:
								case JIAZZI_compound:
								case JIAZZI_signature:
								case JIAZZI_bind:
								case JIAZZI_link:
								case JIAZZI_to:
								case JIAZZI_open:
								case JIAZZI_name:
								case JIAZZI_arg:
								case JIAZZI_generic:
								case JIAZZI_export:
								case JIAZZI_local:
								case JIAZZI_empty:
								case JIAZZI_external:
								case WILD:
								case ID:
								{
									break;
								}
								default:
								{
									throw new NoViableAltException(LT(1), getFilename());
								}
								}
								}
								bind_generic_r(env,unit);
							}
							else {
								break _loop208;
							}
							
						} while (true);
						}
						}
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					}
					}
					match(SEMI);
				}
				else {
					break _loop209;
				}
				
			} while (true);
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_38);
			} else {
			  throw ex;
			}
		}
	}
	
	public final void linkage_r(
		UnitEnvironment env, CompoundUnit unit
	) throws RecognitionException, TokenStreamException {
		
		
		unit.self().resolveInit(env);
		
		
		try {      // for error handling
			{
			_loop240:
			do {
				if ((LA(1)==JIAZZI_link)) {
					{
					if ((LA(1)==JIAZZI_link) && (LA(2)==JIAZZI_unit)) {
						{
						{
						{
						match(JIAZZI_link);
						match(JIAZZI_unit);
						}
						}
						local_decl_r(env, unit);
						{
						_loop231:
						do {
							if ((LA(1)==COMMA)) {
								{
								match(COMMA);
								}
								local_decl_r(env, unit);
							}
							else {
								break _loop231;
							}
							
						} while (true);
						}
						}
					}
					else if ((LA(1)==JIAZZI_link) && (LA(2)==JIAZZI_package)) {
						{
						match(JIAZZI_link);
						match(JIAZZI_package);
						link_pkg_r(env, unit);
						{
						_loop235:
						do {
							if ((LA(1)==COMMA)) {
								{
								match(COMMA);
								}
								link_pkg_r(env, unit);
							}
							else {
								break _loop235;
							}
							
						} while (true);
						}
						}
					}
					else if ((LA(1)==JIAZZI_link) && (LA(2)==JIAZZI_generic)) {
						{
						match(JIAZZI_link);
						match(JIAZZI_generic);
						link_generic_r(env, unit);
						{
						_loop239:
						do {
							if ((LA(1)==COMMA)) {
								{
								match(COMMA);
								}
								link_generic_r(env, unit);
							}
							else {
								break _loop239;
							}
							
						} while (true);
						}
						}
					}
					else {
						throw new NoViableAltException(LT(1), getFilename());
					}
					
					}
					match(SEMI);
				}
				else {
					break _loop240;
				}
				
			} while (true);
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_39);
			} else {
			  throw ex;
			}
		}
	}
	
	public final void open_r(
		UnitEnvironment env, Unit unit
	) throws RecognitionException, TokenStreamException {
		
		
		UnitOpen open = null;
		String pname = null;
		String sid = null;
		
		
		try {      // for error handling
			{
			match(JIAZZI_open);
			pname=id_r();
			match(COLON);
			if ( inputState.guessing==0 ) {
				
				open = new UnitOpen(unit, pname);
				
			}
			{
			switch ( LA(1)) {
			case AT:
			{
				{
				match(AT);
				match(JIAZZI_empty);
				}
				break;
			}
			case JIAZZI_unit:
			case JIAZZI_atom:
			case JIAZZI_compound:
			case JIAZZI_signature:
			case JIAZZI_bind:
			case JIAZZI_link:
			case JIAZZI_to:
			case JIAZZI_open:
			case JIAZZI_name:
			case JIAZZI_arg:
			case JIAZZI_generic:
			case JIAZZI_export:
			case JIAZZI_local:
			case JIAZZI_empty:
			case JIAZZI_external:
			case ID:
			{
				{
				sid=longid_r();
				if ( inputState.guessing==0 ) {
					
					UnitSignature usig = env.findSignature(sid);
					open.in().setSignature(usig);
					
				}
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			match(MINUS);
			match(GT);
			sid=longid_r();
			if ( inputState.guessing==0 ) {
				
				UnitSignature usig = env.findSignature(sid);
				open.out().setSignature(usig);
				
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_3);
			} else {
			  throw ex;
			}
		}
	}
	
	public final void local_decl_r(
		UnitEnvironment env, CompoundUnit unit
	) throws RecognitionException, TokenStreamException {
		
		
		String lname = null;
		String uname;
		ExpandedName exp;
		
		
		try {      // for error handling
			{
			if ((_tokenSet_10.member(LA(1))) && (LA(2)==COLON)) {
				lname=id_r();
				match(COLON);
			}
			else if ((_tokenSet_10.member(LA(1))) && (LA(2)==SEMI||LA(2)==COMMA||LA(2)==DOT)) {
				if ( inputState.guessing==0 ) {
					lname = null;
				}
			}
			else {
				throw new NoViableAltException(LT(1), getFilename());
			}
			
			}
			uname=longid_r();
			if ( inputState.guessing==0 ) {
				
				Unit lunit = env.findUnit(uname);
				Local local;
				if (lname == null) local = unit.newLocal(lunit);
				else local = unit.newLocal(lname, lunit);
				local.resolveInit(env);
				
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_9);
			} else {
			  throw ex;
			}
		}
	}
	
	public final void link_pkg_r(
		UnitEnvironment env, CompoundUnit unit
	) throws RecognitionException, TokenStreamException {
		
		
		LocPackage from=null;
		LocPackage to=null;
		LocRoot local=null;
		PackageName pkgname=null;
		
		
		try {      // for error handling
			{
			switch ( LA(1)) {
			case WILD:
			{
				{
				match(WILD);
				match(JIAZZI_to);
				local=local_r(env,unit);
				match(AT);
				match(WILD);
				if ( inputState.guessing==0 ) {
					
					if (local != null) {
					for (Iterator i = local.packages().values().iterator(); i.hasNext(); /* i = i */) {
					to = (LocPackage) i.next(); 
					if (!to.isSink()) continue;
					if (local.pkgLinkage().containsKey(to)) continue;
					if (!unit.self().packages().containsKey(to.name())) continue;
					from = (LocPackage) unit.self().packages().get(to.name());
					if (!from.isSource()) continue;
					local.link(to, from);
					}
					}
					
				}
				}
				break;
			}
			case JIAZZI_unit:
			case JIAZZI_atom:
			case JIAZZI_compound:
			case JIAZZI_signature:
			case JIAZZI_bind:
			case JIAZZI_link:
			case JIAZZI_to:
			case JIAZZI_open:
			case JIAZZI_name:
			case JIAZZI_arg:
			case JIAZZI_generic:
			case JIAZZI_export:
			case JIAZZI_local:
			case JIAZZI_empty:
			case JIAZZI_external:
			case ID:
			{
				{
				{
				boolean synPredMatched257 = false;
				if (((_tokenSet_10.member(LA(1))) && (LA(2)==AT))) {
					int _m257 = mark();
					synPredMatched257 = true;
					inputState.guessing++;
					try {
						{
						match(ID);
						match(AT);
						}
					}
					catch (RecognitionException pe) {
						synPredMatched257 = false;
					}
					rewind(_m257);
					inputState.guessing--;
				}
				if ( synPredMatched257 ) {
					local=local_r(env,unit);
					match(AT);
				}
				else if ((_tokenSet_10.member(LA(1))) && (LA(2)==JIAZZI_to||LA(2)==DOT)) {
					if ( inputState.guessing==0 ) {
						local = unit.self();
					}
				}
				else {
					throw new NoViableAltException(LT(1), getFilename());
				}
				
				}
				pkgname=pkgname_r();
				if ( inputState.guessing==0 ) {
					
					from = null;
					if (local != null) {
					if (!local.packages().containsKey(pkgname)) {
					this.reportError("cannot find package " + pkgname + " in local " + local.name());
					
					} else {
					from = (LocPackage) local.packages().get(pkgname);
					if (!from.isSource() && !from.isOpen()) {
						this.reportError(local.packages().get(pkgname) + " in local " + local.name() + " is not source");
						 
					} 
					}
					}
					
				}
				match(JIAZZI_to);
				{
				switch ( LA(1)) {
				case WILD:
				{
					{
					match(WILD);
					match(AT);
					pkgname=pkgname_r();
					if ( inputState.guessing==0 ) {
						
						for (Iterator i = unit.allLocals(); i.hasNext(); /* i = i */) {
						local = (LocRoot) i.next();
						if (!local.packages().containsKey(pkgname)) continue;
						to = (LocPackage) local.packages().get(pkgname);
						if (!to.isSink()) continue;
						if (local.pkgLinkage().containsKey(to)) continue;
						if (from != null) {
						if (from.isOpen())
							local.link(to, from.out());
						else local.link(to, from);
						}
						}
						
					}
					}
					break;
				}
				case JIAZZI_unit:
				case JIAZZI_atom:
				case JIAZZI_compound:
				case JIAZZI_signature:
				case JIAZZI_bind:
				case JIAZZI_link:
				case JIAZZI_to:
				case JIAZZI_open:
				case JIAZZI_name:
				case JIAZZI_arg:
				case JIAZZI_generic:
				case JIAZZI_export:
				case JIAZZI_local:
				case JIAZZI_empty:
				case JIAZZI_external:
				case ID:
				{
					{
					{
					boolean synPredMatched263 = false;
					if (((_tokenSet_10.member(LA(1))) && (LA(2)==AT))) {
						int _m263 = mark();
						synPredMatched263 = true;
						inputState.guessing++;
						try {
							{
							match(ID);
							match(AT);
							}
						}
						catch (RecognitionException pe) {
							synPredMatched263 = false;
						}
						rewind(_m263);
						inputState.guessing--;
					}
					if ( synPredMatched263 ) {
						local=local_r(env,unit);
						match(AT);
					}
					else if ((_tokenSet_10.member(LA(1))) && (LA(2)==SEMI||LA(2)==COMMA||LA(2)==DOT)) {
						if ( inputState.guessing==0 ) {
							local = unit.self();
						}
					}
					else {
						throw new NoViableAltException(LT(1), getFilename());
					}
					
					}
					pkgname=pkgname_r();
					if ( inputState.guessing==0 ) {
						
						
						if (!local.packages().containsKey(pkgname)) {
						this.reportError("package " + pkgname + " not in " + local);
						
						} else {
						to = (LocPackage) local.packages().get(pkgname);
						
						if (to.isOpen()) {
						if (from == null) {
							this.reportError("cannot connect wild to open package " + pkgname);
							 
						} else if (!from.isOpen()) {
							this.reportError("cannot connect " + from + " to open package " + pkgname);
							 
						} else {
							local.link(to.in(), from.out());
						}
						} else if (!to.isSink()) {
						this.reportError(to + " is not a sink");
						} else if (!local.pkgLinkage().containsKey(to)) 
						if (from != null) {
							if (from.isOpen())
							  local.link(to, from.out());
							else
							  local.link(to, from);
						}
						}
						
					}
					}
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_9);
			} else {
			  throw ex;
			}
		}
	}
	
	public final void link_generic_r(
		UnitEnvironment env, CompoundUnit unit
	) throws RecognitionException, TokenStreamException {
		
		
		RefType ref;
		Local local;
		LocRoot source = null;
		String vname;
		
		
		try {      // for error handling
			{
			switch ( LA(1)) {
			case WILD:
			{
				{
				match(WILD);
				match(JIAZZI_to);
				local=local_r(env,unit);
				match(AT);
				match(WILD);
				if ( inputState.guessing==0 ) {
					
					if (local != null) {
					for (Iterator i = local.unit().generics().values().iterator(); i.hasNext(); /* i = i */) {
					VariableType var = (VariableType) i.next();
					if (!unit.generics().containsKey(var.name())) continue;
					if (local.genericLinkage().containsKey(var)) continue;
					local.link(var, (VariableType) unit.generics().get(var.name()));
					}
					}
					
				}
				}
				break;
			}
			case JIAZZI_unit:
			case JIAZZI_atom:
			case JIAZZI_compound:
			case JIAZZI_signature:
			case JIAZZI_bind:
			case JIAZZI_link:
			case JIAZZI_to:
			case JIAZZI_open:
			case JIAZZI_name:
			case JIAZZI_arg:
			case JIAZZI_generic:
			case JIAZZI_export:
			case JIAZZI_local:
			case JIAZZI_empty:
			case JIAZZI_external:
			case ID:
			{
				{
				{
				if ((_tokenSet_10.member(LA(1))) && (LA(2)==AT)) {
					{
					source=local_r(env,unit);
					match(AT);
					}
				}
				else if ((_tokenSet_10.member(LA(1))) && (LA(2)==JIAZZI_to||LA(2)==DOT)) {
					if ( inputState.guessing==0 ) {
						source = unit.self();
					}
				}
				else {
					throw new NoViableAltException(LT(1), getFilename());
				}
				
				}
				ref=generic_bind_type_r(env,unit,source);
				match(JIAZZI_to);
				{
				switch ( LA(1)) {
				case WILD:
				{
					{
					match(WILD);
					match(AT);
					vname=id_r();
					if ( inputState.guessing==0 ) {
						
						for (Iterator i = unit.locals().values().iterator(); i.hasNext(); /* i = i */) {
						local = (Local) i.next();
						if (!local.unit().generics().containsKey(vname)) continue;
						VariableType var = (VariableType) local.unit().generics().get(vname);
						if (local.genericLinkage().containsKey(var)) continue;
						local.link(var, ref);
						}
						
					}
					}
					break;
				}
				case JIAZZI_unit:
				case JIAZZI_atom:
				case JIAZZI_compound:
				case JIAZZI_signature:
				case JIAZZI_bind:
				case JIAZZI_link:
				case JIAZZI_to:
				case JIAZZI_open:
				case JIAZZI_name:
				case JIAZZI_arg:
				case JIAZZI_generic:
				case JIAZZI_export:
				case JIAZZI_local:
				case JIAZZI_empty:
				case JIAZZI_external:
				case ID:
				{
					{
					local=local_r(env,unit);
					match(AT);
					vname=id_r();
					if ( inputState.guessing==0 ) {
						
						if (local.unit().generics().containsKey(vname)) {
						VariableType var = (VariableType) local.unit().generics().get(vname);
						if (!local.genericLinkage().containsKey(var)) {
						local.link(var, ref);
						}
						}
						
					}
					}
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_9);
			} else {
			  throw ex;
			}
		}
	}
	
	public final Local  local_r(
		UnitEnvironment env, CompoundUnit unit
	) throws RecognitionException, TokenStreamException {
		Local local;
		
		
		local = null;
		String lname;
		
		
		try {      // for error handling
			lname=id_r();
			if ( inputState.guessing==0 ) {
				
				if (!unit.locals().containsKey(lname)) {
				
				this.reportError("cannot find local " + lname + " in " + unit);
				} else local = (Local) unit.locals().get(lname);
				
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				consume();
				consumeUntil(_tokenSet_12);
			} else {
			  throw ex;
			}
		}
		return local;
	}
	
	
	public static final String[] _tokenNames = {
		"<0>",
		"EOF",
		"<2>",
		"NULL_TREE_LOOKAHEAD",
		"\"unit\"",
		"\"atom\"",
		"\"compound\"",
		"\"signature\"",
		"\"bind\"",
		"\"link\"",
		"\"to\"",
		"\"open\"",
		"\"name\"",
		"\"arg\"",
		"\"lexeme\"",
		"\"generic\"",
		"\"import\"",
		"\"export\"",
		"\"local\"",
		"\"empty\"",
		"\"external\"",
		"\"package\"",
		"\"class\"",
		"\"interface\"",
		"\"extends\"",
		"\"throws\"",
		"\"public\"",
		"\"protected\"",
		"\"static\"",
		"\"final\"",
		"\"abstract\"",
		"\"implements\"",
		"\"void\"",
		"\"boolean\"",
		"\"byte\"",
		"\"short\"",
		"\"char\"",
		"\"int\"",
		"\"long\"",
		"\"double\"",
		"\"float\"",
		"\"native\"",
		"\"synchronized\"",
		"\"transient\"",
		"\"volatile\"",
		"\"true\"",
		"\"false\"",
		"WS",
		"ML_COMMENT",
		"SL_COMMENT",
		"PLUS",
		"LT",
		"GT",
		"LCURLY",
		"RCURLY",
		"PIPE",
		"LPAREN",
		"RPAREN",
		"EQUAL",
		"MINUS",
		"SEMI",
		"WILD",
		"COMMA",
		"COLON",
		"AT",
		"DOLLAR",
		"DOT",
		"DQUOTE",
		"CHAR_LITERAL",
		"STRING_LITERAL",
		"LBRACK",
		"RBRACK",
		"LETTER",
		"NUMBER",
		"an identifier",
		"ID",
		"brackets",
		"ESC",
		"HEX_DIGIT",
		"INTEGER_TEN",
		"INTEGER_HEX"
	};
	
	private static final long _tokenSet_0_data_[] = { -55061345424457744L, 6151L, 0L, 0L };
	public static final BitSet _tokenSet_0 = new BitSet(_tokenSet_0_data_);
	private static final long _tokenSet_1_data_[] = { 6052943452335767552L, 4096L, 0L, 0L };
	public static final BitSet _tokenSet_1 = new BitSet(_tokenSet_1_data_);
	private static final long _tokenSet_2_data_[] = { 6286006929913200624L, 6150L, 0L, 0L };
	public static final BitSet _tokenSet_2 = new BitSet(_tokenSet_2_data_);
	private static final long _tokenSet_3_data_[] = { 1152921504606846976L, 0L };
	public static final BitSet _tokenSet_3 = new BitSet(_tokenSet_3_data_);
	private static final long _tokenSet_4_data_[] = { 6286006929913200624L, 6146L, 0L, 0L };
	public static final BitSet _tokenSet_4 = new BitSet(_tokenSet_4_data_);
	private static final long _tokenSet_5_data_[] = { -278097276971335696L, 2049L, 0L, 0L };
	public static final BitSet _tokenSet_5 = new BitSet(_tokenSet_5_data_);
	private static final long _tokenSet_6_data_[] = { -133876533631729680L, 6151L, 0L, 0L };
	public static final BitSet _tokenSet_6 = new BitSet(_tokenSet_6_data_);
	private static final long _tokenSet_7_data_[] = { 6213949335858495472L, 6144L, 0L, 0L };
	public static final BitSet _tokenSet_7 = new BitSet(_tokenSet_7_data_);
	private static final long _tokenSet_8_data_[] = { -1152921504588054544L, 2049L, 0L, 0L };
	public static final BitSet _tokenSet_8 = new BitSet(_tokenSet_8_data_);
	private static final long _tokenSet_9_data_[] = { 5764607523034234880L, 0L };
	public static final BitSet _tokenSet_9 = new BitSet(_tokenSet_9_data_);
	private static final long _tokenSet_10_data_[] = { 2015216L, 2048L, 0L, 0L };
	public static final BitSet _tokenSet_10 = new BitSet(_tokenSet_10_data_);
	private static final long _tokenSet_11_data_[] = { 5764607523034235904L, 0L };
	public static final BitSet _tokenSet_11 = new BitSet(_tokenSet_11_data_);
	private static final long _tokenSet_12_data_[] = { 0L, 1L, 0L, 0L };
	public static final BitSet _tokenSet_12 = new BitSet(_tokenSet_12_data_);
	private static final long _tokenSet_13_data_[] = { 8070450532249944048L, 2048L, 0L, 0L };
	public static final BitSet _tokenSet_13 = new BitSet(_tokenSet_13_data_);
	private static final long _tokenSet_14_data_[] = { 1441257433908379648L, 4096L, 0L, 0L };
	public static final BitSet _tokenSet_14 = new BitSet(_tokenSet_14_data_);
	private static final long _tokenSet_15_data_[] = { 2142208L, 0L };
	public static final BitSet _tokenSet_15 = new BitSet(_tokenSet_15_data_);
	private static final long _tokenSet_16_data_[] = { 6917529027643097072L, 2048L, 0L, 0L };
	public static final BitSet _tokenSet_16 = new BitSet(_tokenSet_16_data_);
	private static final long _tokenSet_17_data_[] = { 2092957696L, 0L };
	public static final BitSet _tokenSet_17 = new BitSet(_tokenSet_17_data_);
	private static final long _tokenSet_18_data_[] = { 18014400602439680L, 0L };
	public static final BitSet _tokenSet_18 = new BitSet(_tokenSet_18_data_);
	private static final long _tokenSet_19_data_[] = { 1513317222655639536L, 2048L, 0L, 0L };
	public static final BitSet _tokenSet_19 = new BitSet(_tokenSet_19_data_);
	private static final long _tokenSet_20_data_[] = { 4611686018429403120L, 2048L, 0L, 0L };
	public static final BitSet _tokenSet_20 = new BitSet(_tokenSet_20_data_);
	private static final long _tokenSet_21_data_[] = { 1513317224736014320L, 2048L, 0L, 0L };
	public static final BitSet _tokenSet_21 = new BitSet(_tokenSet_21_data_);
	private static final long _tokenSet_22_data_[] = { 1531331623245496304L, 2048L, 0L, 0L };
	public static final BitSet _tokenSet_22 = new BitSet(_tokenSet_22_data_);
	private static final long _tokenSet_23_data_[] = { 1513315027912753152L, 0L };
	public static final BitSet _tokenSet_23 = new BitSet(_tokenSet_23_data_);
	private static final long _tokenSet_24_data_[] = { 6063076553613295600L, 6144L, 0L, 0L };
	public static final BitSet _tokenSet_24 = new BitSet(_tokenSet_24_data_);
	private static final long _tokenSet_25_data_[] = { 2194730303472L, 2048L, 0L, 0L };
	public static final BitSet _tokenSet_25 = new BitSet(_tokenSet_25_data_);
	private static final long _tokenSet_26_data_[] = { 2251799815700464L, 6150L, 0L, 0L };
	public static final BitSet _tokenSet_26 = new BitSet(_tokenSet_26_data_);
	private static final long _tokenSet_27_data_[] = { 1441257433874825216L, 4096L, 0L, 0L };
	public static final BitSet _tokenSet_27 = new BitSet(_tokenSet_27_data_);
	private static final long _tokenSet_28_data_[] = { 4755801206505258992L, 2048L, 0L, 0L };
	public static final BitSet _tokenSet_28 = new BitSet(_tokenSet_28_data_);
	private static final long _tokenSet_29_data_[] = { 4755801206503243776L, 0L };
	public static final BitSet _tokenSet_29 = new BitSet(_tokenSet_29_data_);
	private static final long _tokenSet_30_data_[] = { 4755801206505258992L, 6144L, 0L, 0L };
	public static final BitSet _tokenSet_30 = new BitSet(_tokenSet_30_data_);
	private static final long _tokenSet_31_data_[] = { 4611688213157691376L, 2048L, 0L, 0L };
	public static final BitSet _tokenSet_31 = new BitSet(_tokenSet_31_data_);
	private static final long _tokenSet_32_data_[] = { 4760307000860917744L, 6144L, 0L, 0L };
	public static final BitSet _tokenSet_32 = new BitSet(_tokenSet_32_data_);
	private static final long _tokenSet_33_data_[] = { 4616191812785061872L, 2048L, 0L, 0L };
	public static final BitSet _tokenSet_33 = new BitSet(_tokenSet_33_data_);
	private static final long _tokenSet_34_data_[] = { 6211697536044810224L, 6144L, 0L, 0L };
	public static final BitSet _tokenSet_34 = new BitSet(_tokenSet_34_data_);
	private static final long _tokenSet_35_data_[] = { 2L, 0L };
	public static final BitSet _tokenSet_35 = new BitSet(_tokenSet_35_data_);
	private static final long _tokenSet_36_data_[] = { 2129938L, 0L };
	public static final BitSet _tokenSet_36 = new BitSet(_tokenSet_36_data_);
	private static final long _tokenSet_37_data_[] = { 231424L, 0L };
	public static final BitSet _tokenSet_37 = new BitSet(_tokenSet_37_data_);
	private static final long _tokenSet_38_data_[] = { 18014398509482496L, 0L };
	public static final BitSet _tokenSet_38 = new BitSet(_tokenSet_38_data_);
	private static final long _tokenSet_39_data_[] = { 18014398509481984L, 0L };
	public static final BitSet _tokenSet_39 = new BitSet(_tokenSet_39_data_);
	
	}
