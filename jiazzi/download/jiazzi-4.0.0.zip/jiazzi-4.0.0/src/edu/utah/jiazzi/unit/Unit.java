/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-edu.utah.jiazzi.core outunit.Root */

package edu.utah.jiazzi.unit;

import java.util.*;

import edu.utah.jiggy.clazz.ClassModel;
import edu.utah.jiggy.clazz.ModelRoot;
import edu.utah.jiggy.clazz.PackageModel;
import edu.utah.jiggy.clazz.TypeModel;
import edu.utah.jiggy.meta.flag.FlagConstants;
import edu.utah.jiggy.meta.name.ClassName;
import edu.utah.jiggy.meta.shape.ReplaceShape;
import edu.utah.jiggy.meta.type.ClassType;
import edu.utah.jiggy.meta.type.VariableType;

public abstract class Unit extends UnitRoot {
    private final String name;
    public boolean isResolved = false;

    public String toString() {
        return this.name;
    }

    // public final HashSet<UnitPackage> imports = new HashSet<UnitPackage>();
    // public final HashSet<UnitPackage> exports = new HashSet<UnitPackage>();
    // public final HashSet<UnitOpen> opens = new HashSet<UnitOpen>();
    public final HashSet imports = new HashSet();
    public final HashSet exports = new HashSet();
    public final HashSet opens = new HashSet();
    // ENE, May 19 2005: following was commented-out in original Jiazzi.
    // public final HashSet<UnitPackage> noports = new HashSet<unit.Package>();

    // private final Set<UnitPackage> READ_imports =
    // Collections.unmodifiableSet(this.imports);
    // private final Set<UnitPackage> READ_exports =
    // Collections.unmodifiableSet(this.exports);
    // private final Set<UnitOpen> READ_opens =
    // Collections.unmodifiableSet(this.opens);
    private final Set READ_imports = Collections.unmodifiableSet(this.imports);
    private final Set READ_exports = Collections.unmodifiableSet(this.exports);
    private final Set READ_opens = Collections.unmodifiableSet(this.opens);
    // ENE, May 19 2005: following was commented-out in orginal Jiazzi.
    // private final Set<UnitPackage> READ_noports =
    // Collections.unmodifiableSet(this.noports);

    private ModelRoot stub = null;
    private ModelRoot built = null;

    public void makeExport(UnitPackage upkg) {
        if (upkg.exists())
            throw new Error();
        this.exports.add(upkg);
    }

    public void makeImport(UnitPackage upkg) {
        if (upkg.exists())
            throw new Error();
        this.imports.add(upkg);
    }

    public long modifiedSource(UnitEnvironment env) {
        long m = env.modified((Unit) this);
        for (Iterator i = this.packages().values().iterator();
             i.hasNext();
             /* i = i */) {
            UnitPackage upkg = (UnitPackage) i.next();
            if (upkg.sig() == null)
                continue;
            long m0 = upkg.sig().modified(env);
            if (m0 > m)
                m = m0;
        }
        return m;
    }

    public long modifiedBuilt(UnitEnvironment env) {
        ModelRoot stub = this.newStub0(env);
        ModelRoot built = env.loadBuilt((Unit) this, stub);
        if (built == null)
            return 0;
        else
            return env.modified(built);
    }

    public long modifiedRaw(UnitEnvironment env) {
        return this.modifiedSource(env);
    }

    public java.lang.String name() {
        return this.name;
    }

    public ModelRoot newStub0(UnitEnvironment env) {
        ModelRoot stub = env.newStub((Unit) this);
        for (Iterator i = this.imports().iterator();
             i.hasNext();
             /* i = i */) {
            UnitPackage upkg = (UnitPackage) i.next();
            PackageModel spkg = new PackageModel(stub, upkg.name());
            for (Iterator j = upkg.classes().values().iterator();
                 j.hasNext();
                 /* j = j */) {
                UnitClass ucls = (UnitClass) j.next();
                ClassModel scls = new ClassModel(spkg, ucls.name().nopkg());
            }
        }
        if (!this.generics().isEmpty()) {
            PackageModel spkg = new PackageModel(stub, TVAR);
            for (Iterator i = this.generics().values().iterator();
                 i.hasNext();
                 /* i = i */) {
                ClassModel scls = new ClassModel(spkg, new ClassName(
                    ((VariableType) i.next()).name()));
            }
        }
        return stub;
    }

    public ModelRoot newStub1(UnitEnvironment env, ModelRoot stub,
                              ModelRoot built) {
        ReplaceShape u2r = new ReplaceShape();
        this.u2r(built, stub, u2r);
        for (Iterator i = this.imports().iterator(); i.hasNext(); /* i = i */)
            for (Iterator j = ((UnitPackage) i.next()).classes().values()
                     .iterator();
                 j.hasNext();
                 /* j = j */) {
                UnitClass ucls = (UnitClass) j.next();
                ClassModel rcls = ((TypeModel) ucls.newType().replace(u2r))
                    .clazz();
                u2r.set(ucls.newType());
                rcls.setShape(ucls.shape().replace(u2r));
                u2r.set((ClassType) null);
            }
        return stub;
    }

    public ModelRoot stub() {
        if (this.stub == null)
            throw new Error("built not created yet!");
        return this.stub;
    }

    public ModelRoot built() {
        if (this.built == null)
            throw new Error("built not created yet!");
        return this.built;
    }

    public final void build(UnitEnvironment env) {
        if (this.built != null)
            return;
        this.resolve(env);
        if (env.hasFailed()) {
            env.err().println("cannot link " + this + " with errors");
            return;
        }
        this.stub = this.newStub0(env);
        if (this.modifiedBuilt(env) < this.modifiedRaw(env)) {
            System.err.println("linking " + this);
            env.pushErrorPreface("linking " + this);
            this.built = env.newBuilt((Unit) this);
            this.buildInner(env);
            if (env.hasFailed()) {
                this.built = null;
                this.stub = null;
                env.err().println("cannot link " + this + " with errors");
            } else {
                if (this.stub == null || this.built == null)
                    throw new Error("0");
                this.newStub1(env, this.stub, this.built);
                System.err.println("saving " + this);
                env.save((Unit) this);
            }
            env.popErrorPreface();
        } else {
            this.built = env.loadBuilt((Unit) this, this.stub);
            if (this.built == null) {
                env.fail();
                env.err().println(this + " cannot be built");
            } else {
                System.err.println(this + " is up to date");
                this.newStub1(env, this.stub, this.built);
            }
        }
    }

    protected void buildInner(UnitEnvironment env) {
        throw new Error("abstract");
    }

    public void missClass(ClassName clazz) {
        // System.err.println("miss " + clazz + " " + this.packages().keySet() +
        // " " + this.packages());
        if (this.packages().keySet().contains(clazz.pkg())) {
            // System.err.println(this.packages().get(clazz.pkg()).classes().keySet());
        }
        if (((UnitPackage) this.packages().get(clazz.pkg()))
            .containsClass(clazz.nopkg())) {
            if (true)
                throw new Error("WTF?");
            new UnitClass((UnitPackage) this.packages().get(clazz.pkg()), clazz
                .nopkg());
        } else
            super.missClass(clazz);
    }

    public Set imports() {
        return this.READ_imports;
    }

    public Set opens() {
        return this.READ_opens;
    }

    /*
     * public Set<UnitPackage> noports() { return this.READ_noports; }
     */
    public Set exports() {
        return this.READ_exports;
    }

    public Unit(String name) {
        super();
        this.name = name;
    }

    public void resolve(UnitEnvironment env) {
        if (this.isResolved)
            return;
        this.isResolved = true;
        env.pushErrorPreface("checking " + this);

        System.err.println("checking signature of " + this);

        for (Iterator i = this.opens().iterator(); i.hasNext(); /* i = i */) {
            UnitOpen open = (UnitOpen) i.next();
            if (open.in().signature != null)
                open.in().bind(open.in().signature.self(), open.fixed());
            if (open.out().signature != null)
                open.out().bind(open.out().signature.self(), open.fixed());
            if (open.fixed().signature != null)
                open.fixed().bind(open.fixed().signature.self(), open.fixed());
        }
        for (Iterator i = this.packages().values().iterator();
             i.hasNext();
             /* i = i */) {
            UnitPackage upkg = (UnitPackage) i.next();
            if (upkg.signature != null) {
                if (!upkg.isBound(upkg.signature.self()))
                    upkg.bind(upkg.signature.self(), upkg);
            }
            upkg.setDefaults(this);
        }

        for (Iterator i = this.packages().values().iterator();
             i.hasNext();
             /* i = i */) {
            /* only done once */
            ((UnitPackage) i.next()).resolve(env, UnitPackage.CLASS_RESOLVED);
        }

        for (Iterator i = this.packages().values().iterator();
             i.hasNext();
             /* i = i */) {
            /* only done once */
            ((UnitPackage) i.next()).resolve(env, UnitPackage.SHAPE_RESOLVED);
        }

        for (Iterator i = this.packages().values().iterator();
             i.hasNext();
             /* i = i */) {
            /* only done once */
            ((UnitPackage) i.next()).resolve(env, UnitPackage.FULL_RESOLVED);
        }

        // for (Iterator i = this.opens().iterator(); i.hasNext(); i = i)
        // ((UnitOpen) i.next()).process(env);

        for (Iterator i = this.packages().values().iterator();
             i.hasNext();
             /* i = i */) {
            UnitPackage upkg = (UnitPackage) i.next();

            for (Iterator j = upkg.classes().values().iterator();
                 j.hasNext();
                 /* j = j */) {
                UnitClass ucls = (UnitClass) j.next();
                env.pushErrorPreface("checking class " + ucls.name()
                    + " in unit " + this.name());
                if (!ucls.shape().verify(env.err())) {
                    env.err().println("failed initial verification");
                    env.fail();
                }
                env.popErrorPreface();
            }
        }
        for (Iterator i = this.generics().values().iterator();
             i.hasNext();
             /* i = i */) {
            VariableType tv = (VariableType) i.next();
            if (tv.bound().rawShape().isSet(FlagConstants.FINAL)) {
                env.err().println(tv + " bound to final class " + tv.bound());
                env.fail();
            }
        }
        env.popErrorPreface();
    }

    protected void u2r(ModelRoot built, ModelRoot stub, ReplaceShape u2r) {
        if (built == null)
            throw new Error("WTF?");
        for (Iterator i = this.exports().iterator();
             i.hasNext();
             /* i = i */) {
            UnitPackage upkg = (UnitPackage) i.next();
            PackageModel rpkg = (PackageModel) built.packages()
                .get(upkg.name());
            u2r.map(upkg, rpkg);
        }
        for (Iterator i = this.imports().iterator();
             i.hasNext();
             /* i = i */) {
            UnitPackage upkg = (UnitPackage) i.next();
            PackageModel rpkg = (PackageModel) stub.packages().get(upkg.name());
            u2r.map(upkg, rpkg);
        }
        for (Iterator i = this.generics().values().iterator();
             i.hasNext();
             /* i = i */) {
            VariableType tv = (VariableType) i.next();
            u2r.map(tv,
                ((ClassModel) ((PackageModel) stub.packages().get(TVAR))
                    .classes().get(new ClassName(tv.name()))).newType());
        }
    }
    /*
     * protected void r2u(ModelRoot built, ModelRoot stub, ReplaceShape r2u) {
     * for (Iterator<UnitPackage> i = this.exports().iterator(); i.hasNext(); i =
     * i) { UnitPackage upkg = i.next(); PackageModel rpkg =
     * built.packages().get(upkg.name()); r2u.map(rpkg, upkg); } for (Iterator<UnitPackage>
     * i = this.imports().iterator(); i.hasNext(); i = i) { UnitPackage upkg =
     * i.next(); PackageModel rpkg = stub.packages().get(upkg.name());
     * r2u.map(rpkg, upkg); } for (Iterator<type.Variable> i =
     * this.generics().values().iterator(); i.hasNext(); i = i) { type.Variable
     * tv = i.next(); r2u.map(stub.packages().get(TVAR).classes().get(new
     * ClassName(tv.name())).newType(), tv); } }
     */
}
