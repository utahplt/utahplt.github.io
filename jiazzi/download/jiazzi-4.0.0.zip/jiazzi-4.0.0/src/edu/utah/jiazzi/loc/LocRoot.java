/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package edu.utah.jiazzi.loc;

import java.util.*;

import edu.utah.jiazzi.unit.ArgVar;
import edu.utah.jiazzi.unit.CompoundUnit;
import edu.utah.jiazzi.unit.Unit;
import edu.utah.jiazzi.unit.UnitClass;
import edu.utah.jiazzi.unit.UnitEnvironment;
import edu.utah.jiazzi.unit.UnitPackage;
import edu.utah.jiggy.meta.flag.FlagConstants;
import edu.utah.jiggy.meta.name.ClassName;
import edu.utah.jiggy.meta.name.ExpandedName;
import edu.utah.jiggy.meta.name.PackageName;
import edu.utah.jiggy.meta.name.ReplaceName;
import edu.utah.jiggy.meta.name.VariableName;
import edu.utah.jiggy.meta.shape.MemberShape;
import edu.utah.jiggy.meta.shape.ProcedureShape;
import edu.utah.jiggy.meta.shape.ReplaceShape;
import edu.utah.jiggy.meta.shape.ShapeKey;
import edu.utah.jiggy.meta.shape.ShapeSelector;
import edu.utah.jiggy.meta.type.ClassType;
import edu.utah.jiggy.meta.type.Environment;
import edu.utah.jiggy.meta.type.PackageType;
import edu.utah.jiggy.meta.type.ReplaceType;
import edu.utah.jiggy.meta.type.Root;
import edu.utah.jiggy.meta.type.VariableType;

public abstract class LocRoot extends Root {
    protected Environment env;

    public Environment env() {
        return this.env;
    }

    public void setEnvironment(Environment env) {
        this.env = env;
    }

    // protected final Map<name.Package,clazz.Package> packages =
    protected final Map packages = new HashMap() {
        // public LocPackage get(PackageName pkg)
        public Object get(Object obj) {
            PackageName pkg = (PackageName) obj;
            if (this.containsKey(pkg))
                return (LocPackage) super.get(pkg);
            missPackage(pkg);
            if (!this.containsKey(pkg))
                throw new Error(pkg + " was not really added to " + this);
            return (LocPackage) super.get(pkg);
        }
    };

    // protected final Map<name.Package,clazz.Package> READ_packages =
    // Collections.unmodifiableMap(this.packages);
    protected final Map READ_packages = Collections
        .unmodifiableMap(this.packages);

    public LocRoot() {
        super();
    }

    public Map packages() {
        return this.READ_packages;
    }

    public void missClass(ClassName clazz) {
        throw new Error("cannot find class "
            + clazz
            + " in "
            + this
            + (this.packages().containsKey(clazz.pkg()) ? " "
                + ((LocPackage) this.packages().get(clazz.pkg())).classes()
                    .keySet() : ""));
    }

    public void missPackage(PackageName pkg) {
        throw new Error("cannot find package " + pkg + " in " + this);
    }

    public PackageType findPackage(PackageName pkg) {
        return (PackageType) this.packages().get(pkg);
    }

    public boolean containsPackage(PackageName pkg) {
        return this.packages().containsKey(pkg);
    }

    // Below here,
    // From `edu.utah.jiazzi.core/outloc/Root.java'.

    protected String name;
    protected CompoundUnit parent;
    private static boolean dbg = false;

    public final boolean isSelf() {
        return this instanceof Self;
    }

    // protected final Map<loc.Package,loc.Package> pkgLinkage =
    // new HashMap<loc.Package,loc.Package>();
    protected final Map pkgLinkage = new HashMap();

    // protected final Map<loc.Package,loc.Package> READ_pkgLinkage =
    // Collections.unmodifiableMap(this.pkgLinkage);
    protected final Map READ_pkgLinkage = Collections
        .unmodifiableMap(this.pkgLinkage);

    public boolean isLinked(LocPackage pkg) {
        return this.pkgLinkage.keySet().contains(pkg);
    }

    // public final Map<String,type.Class> bounds =
    // new HashMap<String,type.Class>();
    public final Map bounds = new HashMap();

    public CompoundUnit parent() {
        return this.parent;
    }

    public LocPackage get(UnitPackage upkg) {
        if (upkg.root() != this.unit())
            throw new Error();
        return (LocPackage) this.packages().get(upkg.name());
    }

    public String toString() {
        return this.unit().name() + "[" + this.name + "]";
    }

    public String name() {
        return this.name;
    }

    public Map pkgLinkage() {
        return this.READ_pkgLinkage;
    }

    public void link(LocPackage to, LocPackage from) {
        if (to.root() != this)
            throw new Error(to.root() + " vs. " + this);
        if (from.root().parent != this.parent)
            throw new Error(from + " wrong parent " + from.root().parent
                + " vs. " + this.parent);
        if (!from.isSource())
            throw new Error(from + " not source");
        if (!to.isSink())
            throw new Error(to + " not sink");
        if (this.pkgLinkage.put(to, from) != null)
            throw new Error(to + " " + from + " already set");
    }

    public Unit unit() {
        throw new Error("abstract");
    }

    protected LocPackage translate(UnitPackage upkg) {
        LocPackage lpkg = (LocPackage) this.packages().get(upkg.name());

        if (lpkg.isSource())
            return lpkg;
        else if (!this.pkgLinkage().containsKey(lpkg)) {
            if (lpkg.classes().isEmpty())
                return null;
            else
                throw new Error("cannot translate " + lpkg + " "
                    + this.pkgLinkage() + " " + lpkg.classes().size() + " "
                    + lpkg.classes().keySet());
        }
        LocPackage tpkg = (LocPackage) this.pkgLinkage().get(lpkg);
        if (!tpkg.isSource())
            throw new Error("not source " + lpkg + " -> " + tpkg);
        return tpkg;
    }

    protected LocClass translate(UnitClass uclazz) {
        return (LocClass) this.translate(uclazz.pkg()).classes().get(
            uclazz.name().nopkg());
    }

    public void u2lType(ReplaceType u2l, UnitEnvironment env) {
    }

    public void u2lName(ReplaceName u2l, UnitEnvironment env) {
        for (Iterator i = this.packages().values().iterator();
             i.hasNext();
             /* i = i */) {
            LocPackage lpkg = (LocPackage) i.next();
            lpkg.u2lName(u2l, env);
        }
    }

    public void u2lArg(ReplaceShape u2l, UnitEnvironment env) {
        for (Iterator i = this.packages().values().iterator();
             i.hasNext();
             /* i = i */) {
            LocPackage lpkg = (LocPackage) i.next();
            lpkg.u2lArg(u2l, env);
        }
    }

    /* called as soon as the local is declared */
    boolean isResolved = false;

    public void resolveInit(UnitEnvironment env) {
        if (this.isResolved)
            return;
        // if (this.unit().isResolved == false) throw new Error();
        this.unit().resolve(env);
        this.isResolved = true;

        for (Iterator i = this.unit().packages().values().iterator();
             i.hasNext();
             /* i = i */) {
            UnitPackage upkg = (UnitPackage) i.next();
            LocPackage lpkg = new LocPackage((LocRoot) this, upkg.name());
        }
    }

    public void resolve1(UnitEnvironment env) {
        // this.unit().resolve(env);
        for (Iterator i = this.unit().packages().values().iterator();
             i.hasNext();
             /* i = i */) {
            UnitPackage upkg = (UnitPackage) i.next();
            LocPackage lpkg = (LocPackage) this.packages().get(upkg.name());
            if (upkg.extended() == null)
                continue;
            LocPackage epkg = this.translate(upkg.extended());
            if (epkg != null)
                lpkg.setExtended(epkg);
        }
    }

    public void resolve2(UnitEnvironment env) {

        /* now here set all the classes */

        final ReplaceShape u2l = new ReplaceShape();
        this.u2lName(u2l, env);
        this.u2lArg(u2l, env);

        env.pushErrorPreface("local " + this.name() + " in compound "
            + this.parent.name());
        this.u2lType(u2l, env);

        for (Iterator i = this.unit().packages().values().iterator();
             i.hasNext();
             /* i = i */) {
            UnitPackage upkg = (UnitPackage) i.next();

            LocPackage lpkg = (LocPackage) this.packages().get(upkg.name());
            // Check to see if we can translate upkg -> lpkg
            if (!lpkg.isSource() && !this.pkgLinkage().containsKey(lpkg)
                && !lpkg.classes().isEmpty()) {
                env.fail();
                env.err().println(lpkg + " not linked");
            }
            lpkg = this.translate(upkg);
            if (lpkg == null)
                continue;

            u2l.map(upkg, lpkg);
            for (Iterator j = upkg.classes().values().iterator();
                 j.hasNext();
                 /* j = j */) {
                UnitClass ucls = (UnitClass) j.next();
                ClassName cname = ucls.name().nopkg().replace(u2l);
                if (!cname.equals(ucls.name().nopkg()))
                    if (lpkg.classes().containsKey(cname))
                        u2l.map(ucls.newType(), ((LocClass) lpkg.classes().get(
                            cname)).newType());
            }
        }
        for (Iterator i = this.unit().packages().values().iterator();
             i.hasNext();
             /* i = i */) {
            UnitPackage upkg = (UnitPackage) i.next();
            LocPackage lpkg = this.translate(upkg);
            if (lpkg == null)
                continue;
            if (!lpkg.isSource())
                throw new Error();
            for (Iterator j = upkg.classes().values().iterator();
                 j.hasNext();
                 /* j = j */) {
                UnitClass uclazz = (UnitClass) j.next();
                ClassName cname = uclazz.name().nopkg().replace(u2l);
                LocClass lclazz;
                for (LocPackage epkg = lpkg; true; epkg = epkg.extended) {
                    if (epkg.classes().containsKey(cname)) {
                        lclazz = (LocClass) epkg.classes().get(cname);
                        break;
                    }
                    if (epkg.extended == null) {
                        for (epkg = lpkg; epkg != null; epkg = epkg.extended)
                            System.err.println(epkg + " "
                                + epkg.classes().keySet());

                        throw new Error("mismatch: " + this + " " + lpkg + " "
                            + lpkg.classes().keySet() + " vs. " + this.unit()
                            + " " + upkg + " " + upkg.classes().keySet());
                    }
                }
                u2l.map(uclazz.newType().raw(), lclazz.newType().raw());
            }
        }
        if (dbg)
            System.err.println("U2L: " + this + " " + u2l);

        for (Iterator i = this.unit().packages().values().iterator();
             i.hasNext();
             /* i = i */) {
            UnitPackage upkg = (UnitPackage) i.next();
            LocPackage lpkg = (LocPackage) this.packages().get(upkg.name());
            for (Iterator j = upkg.classes().values().iterator();
                 j.hasNext();
                 /* j = j */) {
                UnitClass uclazz = (UnitClass) j.next();
                LocClass lclazz = (LocClass) lpkg.classes().get(
                    uclazz.name().nopkg().replace(u2l));

                u2l.set(uclazz.newType());
                lclazz.setShape(uclazz.shape().replace(u2l));
                u2l.set((ClassType) null);

                lclazz.fresh
                    .addAll(lclazz.newType().shape().methods(PROT_VIRT));
                for (ClassType etype = uclazz.newType().shape().zuper();
                     etype != null;
                     etype = etype.shape().zuper()) {
                    for (Iterator k = etype.shape().methods(PROT_VIRT)
                             .iterator();
                         k.hasNext();
                         /* k = k */) {
                        u2l.set(etype);
                        ShapeKey key = ((ShapeKey) k.next()).replace(u2l);
                        u2l.set((ClassType) null);
                        lclazz.fresh.remove(key);
                    }
                }
                // if (uclazz.outer() != null)
                // lclazz.setOuter(this.translate(uclazz));
            }
        }
        for (Iterator i = this.unit().generics().values().iterator();
             i.hasNext();
             /* i = i */) {
            VariableType tv = (VariableType) i.next();
            this.bounds.put(tv.name(), (ClassType) tv.bound().replace(u2l));
        }
        env.popErrorPreface();
    }

    public static final ShapeSelector PROT_VIRT = new ShapeSelector() {
        public boolean accept(MemberShape mmbr) {
            return mmbr.access().isa(FlagConstants.PROTECTED)
                && !mmbr.isSet(FlagConstants.STATIC);
        }
    };

    public void setSigLink(UnitEnvironment env) {
        ReplaceShape u2l = new ReplaceShape();
        this.u2lName(u2l, env);
        this.u2lArg(u2l, env);
        this.u2lType(u2l, env);
        for (Iterator i = this.packages().values().iterator();
             i.hasNext();
             /* i = i */) {
            LocPackage lpkg = (LocPackage) i.next();
            for (Iterator j = lpkg.upkg().lexemeBindings().keySet().iterator();
                 j.hasNext();
                 /* j = j */) {
                VariableName var = (VariableName) j.next();
                ExpandedName exp = ((ExpandedName) lpkg.upkg().lexemeBindings()
                    .get(var)).replace(u2l);
                lpkg.lexemeLinkage.put(var, exp);
            }
            for (Iterator j = lpkg.upkg().argVarBindings().keySet().iterator();
                 j.hasNext();
                 /* j = j */) {
                ArgVar var = (ArgVar) j.next();
                ProcedureShape p = (ProcedureShape) ((ProcedureShape) lpkg
                    .upkg().argVarBindings().get(var)).replace(u2l);
                lpkg.argVarLinkage.put(var, p);
            }
        }
    }

    public void doDefaultLink(UnitEnvironment env) {
        if (this instanceof Self)
            return;
        for (Iterator i = this.packages().values().iterator();
             i.hasNext();
             /* i = i */) {
            LocPackage lpkg = (LocPackage) i.next();
            if (!lpkg.upkg().isExport())
                continue;

            /* propogate name variables and argument variables */
            for (Iterator j = lpkg.lexemeLinkage().keySet().iterator();
                 j.hasNext();
                 /* j = j */) {
                VariableName var = (VariableName) j.next();
                // System.err.print("check orig ");
                if (!lpkg.orig(var)) {
                    // System.err.println(" [false]");
                    continue;
                } else {
                    // System.err.println(" [true]");
                }
                /* first propogate backwards */
                LocPackage epkg = lpkg;
                while (true) {
                    if (epkg.upkg().isExport()) {
                        /* no package that is extended */
                        if (epkg.upkg().extended == null)
                            break;
                        epkg = (LocPackage) epkg.root().packages().get(
                            epkg.upkg().extended.name());
                        if (!epkg.upkg().isImport())
                            throw new Error();
                    } else {
                        // if (epkg.root().pkgLinkage().get(epkg) == null) throw
                        // new Error("" + epkg + " " + epkg.root());
                        if (epkg.root().pkgLinkage().get(epkg) == null)
                            break;
                        epkg = (LocPackage) epkg.root().pkgLinkage().get(epkg);
                        if (epkg.root() instanceof Self)
                            break;
                        if (!epkg.upkg().isExport())
                            throw new Error();
                    }
                    if (epkg.isLinked(var))
                        continue;
                    // if (epkg.isLinked(var) && epkg.root() == lpkg.root())
                    // continue; /* would already be linked */
                    // if (epkg.isLinked(var)) throw new Error(lpkg + " " + epkg
                    // + " " + var + " " +
                    // lpkg.linkFor(var) + " " + epkg.linkFor(var));

                    epkg.link(var, lpkg.linkFor(var));
                    // System.err.println("NBWD lpkg=" + lpkg + " epkg=" + epkg
                    // + "(" + epkg.fresh(var) + ") " + var + " " +
                    // epkg.linkFor(var));
                    if (epkg.fresh(var))
                        break;
                }
                epkg = lpkg;
                /* now forward */
                while (true) {
                    if (epkg.upkg().isExport()) {
                        if (epkg.extending == null)
                            break;
                        epkg = epkg.extending;
                        if (epkg.root() instanceof Self)
                            break;
                        if (!epkg.upkg().isExport())
                            throw new Error();
                        /* get to the extended import */
                        epkg = (LocPackage) epkg.root().packages().get(
                            epkg.upkg().extended.name());
                        if (!epkg.upkg().isImport())
                            throw new Error();
                    } else {
                        /* go back to that export */
                        epkg = (LocPackage) epkg.root().packages().get(
                            epkg.upkg().extending.name());
                        if (!epkg.upkg().isExport())
                            throw new Error();
                    }
                    if (epkg.fresh(var))
                        break;
                    if (epkg.isLinked(var))
                        continue;
                    if (epkg.isLinked(var))
                        throw new Error(var + " in " + epkg
                            + " already linked to " + epkg.linkFor(var)
                            + " not " + lpkg.linkFor(var));
                    epkg.link(var, lpkg.linkFor(var));
                    // System.err.println("NFWD lpkg=" + lpkg + " epkg=" + epkg
                    // + "(" + epkg.fresh(var) + ") " + var + " " +
                    // epkg.linkFor(var));
                }
            }
            for (Iterator j = lpkg.argVarLinkage().keySet().iterator();
                 j.hasNext();
                 /* j = j */) {
                ArgVar var = (ArgVar) j.next();
                // System.err.print("check orig ");
                if (!lpkg.orig(var)) {
                    // System.err.println(" [false]");
                    continue;
                } else {
                    // System.err.println(" [true]");
                }
                /* first propogate backwards */
                LocPackage epkg = lpkg;
                while (true) {
                    if (epkg.upkg().isExport()) {
                        /* no package that is extended */
                        if (epkg.upkg().extended == null)
                            break;
                        epkg = (LocPackage) epkg.root().packages().get(
                            epkg.upkg().extended.name());
                        if (!epkg.upkg().isImport())
                            throw new Error();
                    } else {
                        // if (epkg.root().pkgLinkage().get(epkg) == null) throw
                        // new Error("" + epkg + " " + epkg.root());
                        if (epkg.root().pkgLinkage().get(epkg) == null)
                            break;
                        epkg = (LocPackage) epkg.root().pkgLinkage().get(epkg);
                        if (epkg.root() instanceof Self)
                            break;
                        if (!epkg.upkg().isExport())
                            throw new Error();
                    }
                    if (epkg.isLinked(var))
                        continue;
                    if (epkg.isLinked(var) && epkg.root() == lpkg.root())
                        continue; /* would already be linked */
                    if (epkg.isLinked(var))
                        throw new Error(lpkg + " " + epkg + " " + var + " "
                            + lpkg.linkFor(var) + " " + epkg.linkFor(var));
                    epkg.link(var, lpkg.linkFor(var));
                    // System.err.println("NBWD lpkg=" + lpkg + " epkg=" + epkg
                    // + "(" + epkg.fresh(var) + ") " + var + " " +
                    // epkg.linkFor(var));
                    if (epkg.fresh(var))
                        break;
                }
                epkg = lpkg;
                /* now forward */
                while (true) {
                    if (epkg.upkg().isExport()) {
                        if (epkg.extending == null)
                            break;
                        epkg = epkg.extending;
                        if (epkg.root() instanceof Self)
                            break;
                        if (!epkg.upkg().isExport())
                            throw new Error();
                        /* get to the extended import */
                        epkg = (LocPackage) epkg.root().packages().get(
                            epkg.upkg().extended.name());
                        if (!epkg.upkg().isImport())
                            throw new Error();
                    } else {
                        /* go back to that export */
                        epkg = (LocPackage) epkg.root().packages().get(
                            epkg.upkg().extending.name());
                        if (!epkg.upkg().isExport())
                            throw new Error();
                    }
                    if (epkg.fresh(var))
                        break;
                    if (epkg.isLinked(var))
                        continue;
                    if (epkg.isLinked(var))
                        throw new Error(var + " in " + epkg
                            + " already linked to " + epkg.linkFor(var)
                            + " not " + lpkg.linkFor(var));
                    epkg.link(var, lpkg.linkFor(var));
                    // System.err.println("NFWD lpkg=" + lpkg + " epkg=" + epkg
                    // + "(" + epkg.fresh(var) + ") " + var + " " +
                    // epkg.linkFor(var));
                }
            }
        }
    }
}
