/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package edu.utah.jiazzi.loc;

import java.util.HashSet;
import java.util.Set;

import edu.utah.jiggy.meta.name.ClassName;
import edu.utah.jiggy.meta.shape.ClassShape;
import edu.utah.jiggy.meta.type.ClassType;

public class LocClass extends Object {
    protected final LocPackage pkg;
    protected final ClassName name;
    protected ClassShape shape;

    public void setShape(ClassShape shape) {
        this.shape = shape;
    }

    public ClassShape shape() {
        if (this.shape == null)
            throw new Error("shape not set for " + this);
        return this.shape;
    }

    public boolean isShapeSet() {
        return this.shape != null;
    }

    public LocClass(LocPackage pkg, ClassName name) {
        if (name.pkg() != null)
            throw new Error();
        this.name = name;
        this.pkg = pkg;
        if (((LocPackage) pkg).classes.put(name, (LocClass) this) != null)
            throw new Error("class " + name + " already exists in " + pkg);
    }

    public ClassName name0() {
        return this.name;
    }

    public ClassType newType() {
        LocType ctype = new LocType() {};
        ctype.clazz = (LocClass) this;
        return ctype;
    }

    public LocPackage pkg() {
        return this.pkg;
    }

    public ClassName name() {
        return this.name0().setPackage(this.pkg.name());
    }

    // public String toStringInternal() {
    // return this.pkg + "." + this.name0();
    // }
    public LocClass outer() {
        if (this.name0().outer() == null)
            return null;
        else
            return (LocClass) this.pkg().classes().get(this.name0().outer());
    }

    // Below here,
    // From `edu.utah.jiazzi.core/outloc/Class.java'.

    // public final Set<shape.Key> fresh = new HashSet<shape.Key>();
    public final Set fresh = new HashSet();

    public String toString() {
        return "local class " + this.pkg().root().name() + "@"
            + this.pkg().name() + "." + this.name().nopkg();
    }
}
