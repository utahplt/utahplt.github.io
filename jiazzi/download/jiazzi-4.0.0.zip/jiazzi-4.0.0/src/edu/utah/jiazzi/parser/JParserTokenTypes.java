// $ANTLR 2.7.1: "parser.g" -> "JParser.java"$

/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

  package edu.utah.jiazzi.parser;
   
  import java.util.*;

  import edu.utah.jiazzi.loc.LocPackage;
  import edu.utah.jiazzi.loc.LocRoot;
  import edu.utah.jiazzi.loc.Local;
  import edu.utah.jiazzi.unit.ArgVar;
  import edu.utah.jiazzi.unit.AtomUnit;
  import edu.utah.jiazzi.unit.CompoundUnit;
  import edu.utah.jiazzi.unit.Unit;
  import edu.utah.jiazzi.unit.UnitClass;
  import edu.utah.jiazzi.unit.UnitEnvironment;
  import edu.utah.jiazzi.unit.UnitOpen;
  import edu.utah.jiazzi.unit.UnitPackage;
  import edu.utah.jiazzi.unit.UnitRoot;
  import edu.utah.jiazzi.unit.UnitSignature;
  import edu.utah.jiggy.clazz.PackageModel;
  import edu.utah.jiggy.meta.flag.FlagConstants;
  import edu.utah.jiggy.meta.name.ClassName;
  import edu.utah.jiggy.meta.name.ExpandedName;
  import edu.utah.jiggy.meta.name.MemberName;
  import edu.utah.jiggy.meta.name.Name;
  import edu.utah.jiggy.meta.name.PackageName;
  import edu.utah.jiggy.meta.name.VariableName;
  import edu.utah.jiggy.meta.shape.ArgShape;
  import edu.utah.jiggy.meta.shape.Builder;
  import edu.utah.jiggy.meta.shape.ClassShape;
  import edu.utah.jiggy.meta.shape.FieldShape;
  import edu.utah.jiggy.meta.shape.InitShape;
  import edu.utah.jiggy.meta.shape.MethodShape;
  import edu.utah.jiggy.meta.shape.NameTypeShape;
  import edu.utah.jiggy.meta.shape.ProcedureShape;
  import edu.utah.jiggy.meta.shape.ThrowzShape;
  import edu.utah.jiggy.meta.type.ClassType;
  import edu.utah.jiggy.meta.type.PackageType;
  import edu.utah.jiggy.meta.type.PrimitiveType;
  import edu.utah.jiggy.meta.type.RefType;
  import edu.utah.jiggy.meta.type.Root;
  import edu.utah.jiggy.meta.type.TypeConstants;
  import edu.utah.jiggy.meta.type.TypeType;
  import edu.utah.jiggy.meta.type.VariableType;

public interface JParserTokenTypes {
	int EOF = 1;
	int NULL_TREE_LOOKAHEAD = 3;
	int JIAZZI_unit = 4;
	int JIAZZI_atom = 5;
	int JIAZZI_compound = 6;
	int JIAZZI_signature = 7;
	int JIAZZI_bind = 8;
	int JIAZZI_link = 9;
	int JIAZZI_to = 10;
	int JIAZZI_open = 11;
	int JIAZZI_name = 12;
	int JIAZZI_arg = 13;
	int JIAZZI_lexeme = 14;
	int JIAZZI_generic = 15;
	int JIAZZI_import = 16;
	int JIAZZI_export = 17;
	int JIAZZI_local = 18;
	int JIAZZI_empty = 19;
	int JIAZZI_external = 20;
	int JIAZZI_package = 21;
	int JIAZZI_class = 22;
	int JIAZZI_interface = 23;
	int JIAZZI_extends = 24;
	int JIAZZI_throws = 25;
	int JIAZZI_public = 26;
	int JIAZZI_protected = 27;
	int JIAZZI_static = 28;
	int JIAZZI_final = 29;
	int JIAZZI_abstract = 30;
	int JIAZZI_implements = 31;
	int JIAZZI_void = 32;
	int JIAZZI_boolean = 33;
	int JIAZZI_byte = 34;
	int JIAZZI_short = 35;
	int JIAZZI_char = 36;
	int JIAZZI_int = 37;
	int JIAZZI_long = 38;
	int JIAZZI_double = 39;
	int JIAZZI_float = 40;
	int JIAZZI_native = 41;
	int JIAZZI_synchronized = 42;
	int JIAZZI_transient = 43;
	int JIAZZI_volatile = 44;
	int JIAZZI_true = 45;
	int JIAZZI_false = 46;
	int WS = 47;
	int ML_COMMENT = 48;
	int SL_COMMENT = 49;
	int PLUS = 50;
	int LT = 51;
	int GT = 52;
	int LCURLY = 53;
	int RCURLY = 54;
	int PIPE = 55;
	int LPAREN = 56;
	int RPAREN = 57;
	int EQUAL = 58;
	int MINUS = 59;
	int SEMI = 60;
	int WILD = 61;
	int COMMA = 62;
	int COLON = 63;
	int AT = 64;
	int DOLLAR = 65;
	int DOT = 66;
	int DQUOTE = 67;
	int CHAR_LITERAL = 68;
	int STRING_LITERAL = 69;
	int LBRACK = 70;
	int RBRACK = 71;
	int LETTER = 72;
	int NUMBER = 73;
	int VAR = 74;
	int ID = 75;
	int BRACKETS = 76;
	int ESC = 77;
	int HEX_DIGIT = 78;
	int INTEGER_TEN = 79;
	int INTEGER_HEX = 80;
}
