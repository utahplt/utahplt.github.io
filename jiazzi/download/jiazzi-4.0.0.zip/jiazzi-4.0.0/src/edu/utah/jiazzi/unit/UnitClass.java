/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package edu.utah.jiazzi.unit;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import edu.utah.jiggy.meta.flag.FlagConstants;
import edu.utah.jiggy.meta.name.ClassName;
import edu.utah.jiggy.meta.shape.ClassShape;
import edu.utah.jiggy.meta.shape.MethodShape;
import edu.utah.jiggy.meta.shape.ShapeKey;
import edu.utah.jiggy.meta.shape.TypeShape;
import edu.utah.jiggy.meta.type.ClassType;

public class UnitClass extends Object {
    protected final UnitPackage pkg;
    protected final ClassName name;
    protected ClassShape shape;

    public void setShape(ClassShape shape) {
        this.shape = shape;
    }

    public ClassShape shape() {
        if (this.shape == null)
            throw new Error("shape not set for " + this);
        return this.shape;
    }

    public boolean isShapeSet() {
        return this.shape != null;
    }

    public UnitClass(UnitPackage pkg, ClassName name) {
        if (name.pkg() != null)
            throw new Error();
        this.name = name;
        this.pkg = pkg;
        if (((UnitPackage) pkg).classes.put(name, (UnitClass) this) != null)
            throw new Error("class " + name + " already exists in " + pkg);
    }

    public ClassName name0() {
        return this.name;
    }

    public ClassType newType() {
        UnitType ctype = new UnitType() {};
        ctype.clazz = (UnitClass) this;
        return ctype;
    }

    public UnitPackage pkg() {
        return this.pkg;
    }

    public ClassName name() {
        return this.name0().setPackage(this.pkg.name());
    }

    // public String toString() {
    // return this.pkg + "." + this.name0();
    // }
    public UnitClass outer() {
        if (this.name0().outer() == null)
            return null;
        else
            return (UnitClass) this.pkg().classes().get(this.name0().outer());
    }

    // Below here,
    // From `edu.utah.jiazzi.core/outunit/Class.java'.

    public String toString() {
        return this.pkg().preface() + "class " + this.name();
    }

    private static final boolean dbg = false;

    public void resolve(UnitEnvironment env) {
        if (dbg)
            System.err.println("resolving class " + this.newType().javaSource()
                + "  \t(" + this.pkg().root() + ")");
        TypeShape ushape = this.newType().shape();
        if (ushape.zuper() == null) {
            this.shape().setZuper(
                env.platform().findClass(new ClassName("java.lang.Object")));
        }
        for (ClassType z = ushape.zuper(); z != null; z = z.shape().zuper())
            for (Iterator i = z.shape().interfaces().iterator();
                 i.hasNext();
                 /* i = i */)
                this.shape().addInterface((ClassType) i.next());

        {
            /*
             * normalize the interfaces...though matching shouldn't depend on
             * this
             */
            // Set<ClassType> set = new HashSet<ClassType>();
            Set set = new HashSet();
            while (!set.containsAll(ushape.interfaces())) {
                if (set.size() >= ushape.interfaces().size())
                    throw new Error();
                for (Iterator i = ushape.interfaces().iterator();
                     i.hasNext();
                     /* i = i */) {
                    ClassType intf = (ClassType) i.next();
                    if (set.contains(intf))
                        continue;
                    set.add(intf);
                    for (Iterator j = intf.shape().interfaces().iterator();
                         j.hasNext();
                         /* j = j */) {
                        this.shape().addInterface((ClassType) j.next());
                    }
                    break;
                }
            }
        }
        if (this.shape().virtual().isa(FlagConstants.CONCRETE)) {
            Iterator i = ushape.interfaces().iterator();
            ClassType z = ushape.zuper();
            while (i.hasNext() || z != null) {
                ClassType zuper;
                if (i.hasNext())
                    zuper = (ClassType) i.next();
                else {
                    zuper = z;
                    z = z.shape().zuper();
                }
                for (Iterator j = zuper.shape().methods().iterator();
                     j.hasNext();
                     /* j = j */) {
                    MethodShape smthd = zuper.shape().actualMethod(
                        (ShapeKey) j.next());
                    ClassType from = ushape.lookupMethod(smthd.key());
                    if (from != null)
                        smthd = from.shape().actualMethod(smthd.key());

                    if (!smthd.virtual().isa(FlagConstants.CONCRETE)) {
                        MethodShape smthd0 = (MethodShape) smthd.copy();
                        smthd0.set(FlagConstants.CONCRETE);
                        this.shape().add(smthd0);
                    }
                }
            }
        }
    }

    /*
     * public void print(PrintStream out, String emsg) { if (this.outer() !=
     * null) throw new Error(); out.println("package " +
     * this.pkg().name().javaSource() + ";"); out.println(); this.print("", out,
     * emsg); } public void print(String indent, PrintStream out, String emsg) {
     * boolean intf =
     * this.shape().binaries().contains(flag.Constants.INTERFACE);
     * out.print(indent + this.shape().javaSource()); if (intf)
     * out.print("interface "); else out.print("class ");
     * out.print(this.name().base().javaSource().toString()); shape.Type ushape =
     * ((unit.Type) this.newType()).shape();
     * 
     * 
     * if (!intf && ushape.zuper() != null) { out.print(" extends " +
     * ushape.zuper().javaSource()); } if (!ushape.interfaces().isEmpty()) { if
     * (intf) out.print(" extends "); else out.print(" implements "); for
     * (Iterator<ClassType> i = ushape.interfaces().iterator(); i.hasNext(); i =
     * i) { out.print(i.next().javaSource()); if (i.hasNext()) out.print(", "); } }
     * out.println(" {"); for (Iterator<ShapeKey> i =
     * ushape.methods().iterator(); i.hasNext(); i = i) { shape.Method mthd =
     * ushape.actualMethod(i.next()); out.print(" " + indent +
     * mthd.javaSource(null)); if (mthd.virtual().isa(flag.Constants.CONCRETE)) {
     * out.println(" {"); out.println(" " + indent + "throw new Error(\"" + emsg +
     * "\");"); out.println(" " + indent + "}"); } else out.println(";"); } for
     * (Iterator<ShapeKey> i = ushape.inits().iterator(); i.hasNext(); i = i) {
     * shape.Init init = ushape.actualInit(i.next()); out.println(" " + indent +
     * init.javaSource(this.name().base().javaSource().toString()) + " {"); if
     * (ushape.zuper() != null) { out.print(" " + indent + "super("); if
     * (ushape.zuper().shape().inits().contains(init.key())) { for (Iterator<shape.Arg>
     * j = init.procedure().args().iterator(); j.hasNext(); j = j) {
     * out.print(j.next().name()); if (j.hasNext()) out.print(", "); } } else {
     * if (!ushape.zuper().shape().inits().iterator().hasNext()) throw new
     * Error(ushape.zuper() + " does not have constructors!"); ShapeKey ikey =
     * ushape.zuper().shape().inits().iterator().next(); if (ikey == null) throw
     * new Error(this.newType() + " " + ushape.zuper() + " " +
     * ushape.zuper().shape().inits()); shape.Init init0 =
     * ushape.zuper().shape().actualInit(ikey); if (init0 == null) throw new
     * Error(); if (init0.procedure() == null) throw new Error(); for (Iterator<shape.Arg>
     * j = init0.procedure().args().iterator(); j.hasNext(); j = j) {
     * out.print(j.next().type().defaultValue()); if (j.hasNext()) out.print(",
     * "); } } } out.println(");"); out.println(" " + indent + "}"); } for
     * (Iterator<ShapeKey> i = ushape.fields().iterator(); i.hasNext(); i = i) {
     * shape.Field fld = ushape.actualField(i.next()); out.print(" " + indent +
     * fld.javaSource(null)); if
     * (fld.binaries().contains(flag.Constants.IMMUTABLE)) { out.print(" = " +
     * fld.nameType().type().defaultValue()); } out.println(";"); } for
     * (Iterator<unit.Class> i = this.pkg().classes().values().iterator();
     * i.hasNext(); i = i) { unit.Class inner = i.next(); if (inner.outer() !=
     * this) continue; inner.print(" " + indent, out, emsg); }
     * out.println(indent + "}"); }
     */
}
