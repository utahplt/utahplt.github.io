/*
 * Copyright (c) 2004, 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* atom-unitdriver0 outjiazzi.Main */

package edu.utah.jiazzi.driver;

import java.io.*;
import java.util.*;
import java.util.jar.*;

import edu.utah.jiazzi.unit.AtomUnit;
import edu.utah.jiazzi.unit.Parser;
import edu.utah.jiazzi.unit.Unit;
import edu.utah.jiazzi.unit.UnitClass;
import edu.utah.jiazzi.unit.UnitEnvironment;
import edu.utah.jiazzi.unit.UnitPackage;
import edu.utah.jiazzi.unit.UnitSignature;
import edu.utah.jiggy.bytecode.bt.BTAttr;
import edu.utah.jiggy.bytecode.bt.BTSourceFile;
import edu.utah.jiggy.bytecode.bt.ReplaceBT;
import edu.utah.jiggy.clazz.ClassModel;
import edu.utah.jiggy.clazz.DirModelRoot;
import edu.utah.jiggy.clazz.JarModelRoot;
import edu.utah.jiggy.clazz.JarModelSaver;
import edu.utah.jiggy.clazz.ModelRoot;
import edu.utah.jiggy.clazz.ModelSaver;
import edu.utah.jiggy.clazz.NullModelRoot;
import edu.utah.jiggy.clazz.PackageModel;
import edu.utah.jiggy.clazz.TypeModel;
import edu.utah.jiggy.meta.flag.FlagConstants;
import edu.utah.jiggy.meta.name.ClassName;
import edu.utah.jiggy.meta.name.PackageName;
import edu.utah.jiggy.meta.shape.ClassShape;
import edu.utah.jiggy.meta.shape.ReplaceShape;
import edu.utah.jiggy.meta.type.ClassType;
import edu.utah.jiggy.meta.type.Environment;
import edu.utah.jiggy.meta.type.VariableType;

public class Main {
    private static void usage() {
        System.err.println(
            "Normal usage::\n"
            //
            + "First arg: name of the unit directory\n"
            //
            + "Second arg: what you want to do:\n\n"
            + ("  `-stub' 1) Generate import stubs for the specified unit.\n")
            + ("          Iterates through the signature files within a"
                    + " specific build and\n")
            + ("          creates Java stubs for imported classes not found in"
                    + " the CLASSPATH.\n")
            + ("          These stubs are needed for compiling a unit's"
                    + " implementation.\n")
            + ("          The stubs are output to `stubs.jar'.\n")
            + ("          2) Produce stubs for the classes that exported from"
                    + " an atomic unit.\n")
            + ("          This happens when Jiazzi cannot find source code for"
                    + " the class\n")
            + ("          implementation.  If source files exist, Jiazzi won't"
                    + " overwrite them.\n\n")
            //
            + ("  `-link' Link specified unit (third arg) together.\n")
            + ("          The unit may be atomic or compound.\n\n")
            //
            + ("  `-dis'  Link unit together (like `-link'), then"
                    + " disassemble the class named\n")
            + ("          by the fourth and fifth args.  The output is sent to"
                    + " stdout.\n\n")
            //
            + "Third arg: the base name of the unit file\n"
            //
            + ("Fourth arg: the package of the class to be disassembled"
                    + " (only for `-dis')\n")
            //
            + ("Fifth arg: the name of the class to be disassembled"
                    + " (only for `-dis')\n")
            //
            + "\nFor version information, use one argument only: `-v'.");
        System.exit(1);
    }

    public static void main(String args[]) {
        // Check before getting the unit directory name (or `-v').
        if (args.length < 1) {
            usage();
        }

        if (args[0].equals("-v")) {
            System.out.println("Jiazzi version " + Version.getVersion());
            System.exit(0);
        }

        final File dir = new File(args[0]);
        UnitEnvironment env = new UnitEnvironment() {
            protected Unit missUnit(String name) {
                // this.pushErrorPreface("reading " + name + ".unit");
                try {
                    DataInputStream input = new DataInputStream(
                        new FileInputStream(new File(dir, name + ".unit")));
                    return (new Parser(this, input, name + ".unit"))
                        .unit_r(this);
                } catch (IOException ioe) {
                    this.err().println(ioe.toString());
                    this.fail();
                    return null;
                } finally {
                    // this.popErrorPreface();
                }
            }

            protected UnitSignature missSignature(String name) {
                // this.pushErrorPreface("reading " + name + ".sig");
                try {
                    DataInputStream input = new DataInputStream(
                        new FileInputStream(new File(dir, name + ".sig")));
                    return (new Parser(this, input, name + ".sig"))
                        .signature_r(this);
                } catch (IOException ioe) {
                    this.err().println(ioe.toString());
                    this.fail();
                    return null;
                } finally {
                    // this.popErrorPreface();
                }
            }

            public String getSource(ClassModel clazz) {
                if (clazz.body().attributes().containsKey(BTAttr.SOURCE_FILE)) {
                    return ((BTSourceFile) clazz.body().attributes().get(
                        BTAttr.SOURCE_FILE)).source();
                } else
                    return super.getSource(clazz);
            }

            public void setSource(ClassModel clazz, String src) {
                if (clazz.body().attributes().containsKey(BTAttr.SOURCE_FILE)) {
                    ((BTSourceFile) clazz.body().attributes().get(
                        BTAttr.SOURCE_FILE)).setSource(src);
                } else
                    super.setSource(clazz, src);
            }

            public long modified(ModelRoot root) {
                return root.modified();
            }

            public long modified(Unit unit) {
                long ret =
                    (new File(dir, unit.name() + ".unit")).lastModified();
                return ret;
            }

            public long modified(UnitSignature sig) {
                long ret = (new File(dir, sig.name() + ".sig")).lastModified();
                return ret;
            }

            public ModelRoot newStub(final Unit unit) {
                return new NullModelRoot() {
                    public String toString() {
                        return "stub_" + unit.name();
                    }
                };
            }

            public ModelRoot newBuilt(final Unit unit) {
                return new NullModelRoot() {
                    public String toString() {
                        return "blt_" + unit.name();
                    }
                };
            }

            public ModelRoot loadRaw(AtomUnit atom, ModelRoot stub) {
                File f = new File(dir, atom.name());
                if (!f.isDirectory())
                    return null;
                // throw new Error(f + " is not directory of classes for " +
                // atom);
                ModelRoot root = new DirModelRoot(f);
                for (Iterator i = atom.imports().iterator();
                     i.hasNext();
                     /* i = i */) {
                    UnitPackage upkg = (UnitPackage) i.next();
                    if (root.packages().containsKey(upkg.name()))
                        ((PackageModel) root.packages().get(upkg.name()))
                            .detach();
                }
                if (root.packages().containsKey(new PackageName("var")))
                    ((PackageModel) root.packages().get(new PackageName("var")))
                        .detach();

                root.setEnvironment(this.platform().prependRoot(root)
                    .prependRoot(stub));
                return root;
            }

            public ModelRoot loadBuilt(Unit unit, ModelRoot stub) {
                File f = new File(dir, unit.name() + ".jar");
                if (!f.exists())
                    return null;
                try {
                    ModelRoot root = new JarModelRoot(f);
                    root.setEnvironment(this.platform().prependRoot(root)
                        .prependRoot(stub));
                    return root;
                } catch (Throwable t) {
                    t.printStackTrace();
                    return null;
                }
            }

            public void copyInto(ModelRoot from, ModelRoot to,
                                 ReplaceShape sreplace) {
                ReplaceBT replace;
                if (from == to)
                    throw new Error("you wenti!");
                if (sreplace instanceof ReplaceBT)
                    replace = (ReplaceBT) sreplace;
                else
                    replace = new ReplaceBT(sreplace);
                from.replace1((NullModelRoot) to, replace);
            }

            public void save(final Unit unit) {
                try {
                    final JarOutputStream jar = new JarOutputStream(
                        new FileOutputStream(
                            new File(dir, unit.name() + ".jar")));

                    ModelSaver saver = new JarModelSaver(jar) {
                        public String toString() {
                            return unit.toString() + ":saver";
                        }

                        public void close() throws IOException {
                            jar.close();
                        }
                    };
                    saver.save(unit.built());
                    saver.close();
                } catch (IOException e) {
                    e.printStackTrace();
                    throw new Error("" + e);
                }
            }

            public PrintStream stub(AtomUnit atom, VariableType var) {
                if (true)
                    throw new Error("should not be called anymore");
                File f = new File(dir, atom.name());
                f = new File(f, "var");
                f.mkdirs();
                if (!f.isDirectory())
                    throw new Error();
                f = new File(f, var.name() + ".java");
                try {
                    return new PrintStream(new FileOutputStream(f));
                } catch (IOException ioe) {
                    throw new Error("" + ioe);
                }
            }

            public PrintStream skeleton(UnitClass uclazz) {
                if (uclazz.outer() != null)
                    throw new Error(
                        "only top level classes can have stub files: "
                        + uclazz);
                File f = new File(dir, ((AtomUnit) uclazz.pkg().root()).name());
                f = new File(f,
                    uclazz.pkg().name().javaSource()
                        .replace('.', File.separatorChar)
                    + File.separatorChar);
                f.mkdirs();
                if (!f.isDirectory())
                    throw new Error("could not make directories: " + f + " "
                        + f.isDirectory());
                f = new File(f, uclazz.name().base().javaSource() + ".java");
                if (f.exists())
                    return null;
                try {
                    return new PrintStream(new FileOutputStream(f));
                } catch (IOException ioe) {
                    throw new Error("" + ioe);
                }
            }

            public void stubs(final AtomUnit atom) {
                NullModelRoot root = new NullModelRoot() {
                    public String toString() {
                        return "stubs.jar";
                    }
                };
                ReplaceShape replace = new ReplaceShape();

                for (Iterator i = atom.imports().iterator();
                     i.hasNext();
                     /* i = i */) {
                    UnitPackage upkg = (UnitPackage) i.next();
                    PackageModel bpkg = new PackageModel(root, upkg.name());
                    replace.map(upkg, bpkg);
                    for (Iterator j = upkg.classes().values().iterator();
                         j.hasNext();
                         /* j = j */) {
                        UnitClass ucls = (UnitClass) j.next();
                        ClassModel bcls =
                            new ClassModel(bpkg, ucls.name().nopkg());
                    }
                }
                PackageModel vpkg =
                    new PackageModel(root, new PackageName("var"));
                for (Iterator i = atom.generics().values().iterator();
                     i.hasNext();
                     /* i = i */) {
                    VariableType var = (VariableType) i.next();
                    ClassModel bcls =
                        new ClassModel(vpkg, new ClassName(var.name()));
                    replace.map(var, bcls.newType());
                }
                // System.err.println(root.packages().keySet());
                for (Iterator i = atom.imports().iterator();
                     i.hasNext();
                     /* i = i */)
                    for (Iterator j = ((UnitPackage) i.next()).classes()
                             .values().iterator();
                         j.hasNext();
                         /* j = j */) {
                        UnitClass ucls = (UnitClass) j.next();
                        ClassModel bcls =
                            ((TypeModel) ucls.newType().replace(replace))
                            .clazz();
                        replace.set(ucls.newType());
                        bcls.setShape(ucls.shape().replace(replace));
                        replace.set((ClassType) null);
                    }
                for (Iterator i = atom.generics().values().iterator();
                     i.hasNext();
                     /* i = i */) {
                    VariableType var = (VariableType) i.next();
                    ClassModel bcls =
                        ((TypeModel) var.replace(replace)).clazz();
                    ClassShape shape = new ClassShape();
                    shape.set(FlagConstants.PUBLIC);
                    shape.set(FlagConstants.ABSTRACT);
                    if (var.bound().rawShape().isSet(FlagConstants.INTERFACE)) {
                        shape.setZuper(this.platform().findClass(
                            new ClassName("java.lang.Object")));
                        shape.addInterface(
                            (ClassType) var.bound().replace(replace));
                    } else {
                        shape.setZuper(
                            (ClassType) var.bound().replace(replace));
                    }
                    bcls.setShape(shape);
                }
                try {
                    File f = new File(dir, atom.name());
                    f.mkdirs();
                    final JarOutputStream jar = new JarOutputStream(
                        new FileOutputStream(new File(f, "stubs.jar")));
                    ModelSaver saver = new JarModelSaver(jar) {
                        public String toString() {
                            return atom.toString() + ":stubs";
                        }
                    };
                    saver.save(root);
                    jar.close();
                } catch (IOException ioe) {
                    throw new Error();
                }
            }

            public Environment platform() {
                return ModelRoot.CLASSPATH;
            }

            public PrintStream err() {
                return this.err;
            }

            PrintStream err = new PrintStream(System.err) {
                boolean isNew = true;

                public void print(String str) {
                    if (this.isNew)
                        super.print(errorPreface() + ": ");
                    this.isNew = false;
                    super.print(str);
                }

                public void println(String str) {
                    if (this.isNew)
                        super.print(errorPreface() + ": ");
                    this.isNew = false;
                    super.println(str);
                    this.isNew = true;
                }
            };
        };
        
        // Check before getting the action.
        if (args.length < 2) {
            usage();
        }
        if (args[1].equals("-stub")) {
            if (args.length != 3) {
                usage();
            }
            Unit unit = env.findUnit(args[2]);
            if (unit == null) {
                System.err.println(args[2] + " failed");
                return;
            }
            unit.resolve(env);
            if (unit instanceof AtomUnit) {
                ((AtomUnit) unit).doStubs(env);
            } else {
                System.err.println(unit + " does not require stubs");
            }

        } else if (args[1].equals("-link")) {
            if (args.length != 3) {
                usage();
            }
            Unit unit = env.findUnit(args[2]);
            if (unit == null) {
                System.err.println(args[2] + " failed");
                return;
            }
            unit.build(env);
            // env.save(unit);

        } else if (args[1].equals("-dis")) {
            if (args.length != 5) {
                usage();
            }
            Unit unit = env.findUnit(args[2]);
            unit.build(env);
            PackageName pname = new PackageName(args[3]);
            ClassName cname = new ClassName(args[4]);
            ClassModel clazz = (ClassModel)
                ((PackageModel) unit.built().packages().get(pname)).classes()
                .get(cname);

            System.out.println(clazz.name().javaSource() + " extends "
                + clazz.newType().shape().zuper().name().javaSource());

            clazz.body().buildInstructions(clazz);
            clazz.body().dump(clazz, System.out);

            /*
             * 
             * for (Iterator<shape.Key> i =
             * clazz.body().fields().keySet().iterator(); i.hasNext(); i = i)
             * System.out.println(" " +
             * clazz.newType().shape().actualField(i.next()).javaSource("") +
             * ";"); for (Iterator<shape.Key> i =
             * clazz.body().methods().keySet().iterator(); i.hasNext(); i = i) {
             * shape.Key mthd = i.next(); bt.Method body =
             * clazz.body().methods().get(mthd); shape.Member shape; if
             * (mthd.nameType() == NameType.EMPTY) { shape =
             * clazz.newType().shape().actualInit(mthd); System.out.println(" " +
             * shape.javaSource("<init>")); } else { shape =
             * clazz.newType().shape().actualMethod(mthd); ClassType from =
             * (ClassType) clazz.newType().shape().freshMethod(mthd);
             * System.out.println(" " + shape.javaSource("<init>") + "
             * overrides from " + from); } if
             * (body.attributes().containsKey(BTAttr.CODE)) { bt.Code code =
             * (bt.Code) body.attributes().get(BTAttr.CODE);
             * code.instructions(clazz,mthd);
             * code.printInstructions(env.platform(), System.out); }
             * System.out.println(); }
             */

        } else
            throw new Error(args[1] + " unrecognized option");
    }
}
