package test;

public class Test extends java.lang.Object {
  public static void main(java.lang.String[] args) {
    System.out.println("hello world");
  }
  public Test() {
    super();
  }
}
