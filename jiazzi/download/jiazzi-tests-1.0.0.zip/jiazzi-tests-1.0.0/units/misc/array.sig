signature array = {
    public class Foo {
        public static final String[] messages;
    }
}
