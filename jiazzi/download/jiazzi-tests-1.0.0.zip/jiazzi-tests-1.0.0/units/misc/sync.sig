signature sync = {
    public class Foo {
        public void bar();
    }
}
