
signature program = {
	class Main extends Object {
		public static void main(String[]);
	}
}
