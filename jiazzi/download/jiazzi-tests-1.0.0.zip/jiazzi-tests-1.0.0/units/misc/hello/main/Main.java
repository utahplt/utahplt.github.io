/**
 * 
 */
package main;

/**
 * @author fluxguest
 *
 */
public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("Hello, world!");
	}
}
