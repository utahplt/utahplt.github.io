/*
 * Copyright (c) 2005 The University of Utah
 *
 * This file is part of Jiazzi.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions, and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

external package java.io;

signature expr = {
    package num, token;

    //

    public abstract class Expr {
        public abstract Expr accept(ExprVisitor ev);
    }

    //

    public abstract class BinaryExpr extends Expr {
    }

    public abstract class UnaryExpr extends Expr {
    }

    public abstract class ErrorExpr extends Expr {
    }

    //

    public class DifferenceExpr extends BinaryExpr {
        public DifferenceExpr(Expr l, Expr r);
    }

    public class EvalErrorExpr extends ErrorExpr {
        public EvalErrorExpr(String s);
        public String getString();
    }

    public class NegativeExpr extends UnaryExpr {
        public NegativeExpr(Expr e);
    }

    public class NumExpr extends Expr {
        public NumExpr(num.Num n);
        public num.Num getNum();
    }

    public class PositiveExpr extends UnaryExpr {
        public PositiveExpr(Expr e);
    }

    public class ProductExpr extends BinaryExpr {
        public ProductExpr(Expr l, Expr r);
    }

    public class RatioExpr extends BinaryExpr {
        public RatioExpr(Expr l, Expr r);
    }

    public class SumExpr extends BinaryExpr {
        public SumExpr(Expr l, Expr r);
    }

    public class TokenErrorExpr extends ErrorExpr {
        public TokenErrorExpr(token.Token t);
        public token.Token getToken();
    }

    //

    public interface ExprVisitor {
    }

    public class Evaluator implements ExprVisitor {
        public Evaluator();
        public Expr eval(Expr e);
    }

    public class Printer implements ExprVisitor {
        public Printer(PrintStream ps);
        public void print(Expr e);
    }
}
