signature maze.locked = z : maze.secure + {
  package maze, game, io;
  bind package maze to *@maze, game to *@game, io to *@io;
  bind lexeme Locked to z@Kind, Key to z@Item;
}
