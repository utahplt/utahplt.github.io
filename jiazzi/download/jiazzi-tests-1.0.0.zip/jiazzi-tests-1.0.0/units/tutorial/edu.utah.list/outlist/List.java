package outlist;
import java.util.*;
public abstract class List extends inlist.List {
  protected var.TYPE items[] = new var.TYPE[1];
  protected int size = 0;

  public static abstract class XXPrefixXX { public XXPrefixXX() {} }

  static String getPrefix() {
    list.List.XXPrefixXX p = new list.List.XXPrefixXX();
    String str = p.getClass().getName();
    str = str.substring(str.lastIndexOf('$') + 1, str.length());
    if (!str.startsWith("XX")) throw new Error("string is " + str);
    str = str.substring(2, str.length());
    while (!str.endsWith("XX")) str = str.substring(0, str.length() - 1);
    str = str.substring(0, str.length() - 2);
    return str;
  }
  static final String PREFIX = getPrefix();

  protected void ensureCapacity(int n) {
    if (this.items.length < n) {
      var.TYPE o[] = this.items;
      if (this.items.length * 2 > n) 
	n = this.items.length * 2;
      this.items = new var.TYPE[n];
      for (int i = 0; i < o.length; i++) {
	this.items[i] = o[i];
      }
    }
  }
  public Iterator iteratorPrefix() {
    return new Iterator() {
	int n = 0; 
	public boolean hasNext() { return this.n < List.this.size; }
	public Object next() { 
	  Object ret = List.this.items[this.n];
	  this.n++;
	  return ret;
	}
	public void remove() {
	  throw new Error("not supported yet");
	}
      };
  }
  public String toString() {
    String s = "";
    for (int i = 0; i < this.size; i++) {
      s += this.items[i];
      if (i < this.size - 1) s += ", ";
    }
    return super.toString() + " " + PREFIX.toLowerCase() + "=[" + s + "]";
  }
  public java.util.List listPrefix() {
    throw new Error("not supported");
  }
  public void addPrefix(var.TYPE item) {
    this.addPrefix(this.size, item);
  }
  public boolean containsPrefix(var.TYPE item) {
    for (int i = 0; i < this.size; i++) {
      if (this.items[i] == item ||
	  (this.items[i] != null && item != null &&
	   this.items[i].equals(item))) return true;
    }
    return false;
  }

  public void addPrefix(int index, var.TYPE item) {
    this.ensureCapacity(this.size + 1);
    for (int i = index; i < this.size; i++) 
      this.items[this.size - i + index] = this.items[this.size - i + index - 1];
    this.items[index] = item;
    this.size++;
  }
  public boolean removePrefix(var.TYPE item) {
    for (int i = 0; i < this.size; i++) {
      if (this.items[i].equals(item)) {
	this.removePrefix(i); return true;
      }
    }
    return false;
  }
  public var.TYPE getPrefix(int index) {
    return this.items[index]; 
  }
  public var.TYPE removePrefix(int index) {
    var.TYPE ret = this.items[index];
    this.items[index] = null;
    for (int i = index; i < this.size - 1; i++) 
      this.items[index] = this.items[index + 1];
    this.size--;
    return ret;
  }
  public int sizePrefix() {
    return this.size;
  }
  public int hashCode() {
    int n = 0; 
    for (int i = 0; i < this.size; i++) 
      if (this.items[i] != null) n += (this.items[i].hashCode() << i);
    return super.hashCode() + n;
  }
  public boolean equals(Object o) {
    if (!super.equals(o)) return false;
    if (!(o instanceof list.List)) return false;
    list.List l = (list.List) o;
    if (this.size != l.size) return false;
    for (int i = 0; i < this.size; i++) {
      var.TYPE item0 = this.items[i];
      var.TYPE item1 = l.items[i];
      if (item0 == item1) continue;
      if (item0 == null || item1 == null) return false;
      else if (!item0.equals(item1)) return false;
    }
    return true;
  }
}
