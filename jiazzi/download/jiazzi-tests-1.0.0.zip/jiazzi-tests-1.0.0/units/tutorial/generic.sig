signature generic = {
  lexeme Generic;
  package generic;
  class [Generic] extends Object { (); }
}
