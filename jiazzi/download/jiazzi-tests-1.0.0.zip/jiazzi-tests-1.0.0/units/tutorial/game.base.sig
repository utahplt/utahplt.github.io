signature game.base = {
  package game, maze;

  abstract class Actor extends Object {
    Actor();
    void setRoom(maze.Room rm);
    maze.Room room(); int direction();
    void rotateDirection(); boolean move();
  }
  class Player extends game.Actor {
    Player();
    void setName(String name);
  }
  abstract class Monster extends game.Actor {
    Monster();
    void doAi();
  }
  abstract class Item {
    Item(); 
  }
}
