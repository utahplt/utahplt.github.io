signature maze.pub = m : maze.magic + l : maze.locked + t : maze.lists + {
  package maze, game, io, util;
  bind package maze to *@maze, game to *@game, io to *@io, util to *@util;
}
