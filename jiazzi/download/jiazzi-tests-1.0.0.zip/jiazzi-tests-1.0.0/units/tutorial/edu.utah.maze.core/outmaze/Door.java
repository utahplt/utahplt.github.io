package outmaze;

public class Door extends java.lang.Object {
  public boolean canPass(game.Actor p) {
    return true;
  }
  public Door() {
    super();
  }
}
