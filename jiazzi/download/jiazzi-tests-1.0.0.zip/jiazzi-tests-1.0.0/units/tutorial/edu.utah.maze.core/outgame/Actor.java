package outgame;

public abstract class Actor extends java.lang.Object {
  int dir = maze.Room.NORTH;
  maze.Room room;

  public int direction() {
    return this.dir;
  }
  public boolean move() {
    if (this.room.getRoom(this.dir) == null) return false;
    else if (this.room.getDoor(this.dir) == null) throw new Error();
    if (!this.room.getDoor(this.dir).canPass((game.Actor) this)) {
      System.err.println(this + " cannot pass through " + this.room.getDoor(this.dir));
      return false;
    }
    this.room = this.room.getRoom(this.dir);
    return true;
  }
  public void rotateDirection() {
    this.dir = (this.dir + 1) % 4;
  }
  public maze.Room room() {
    return this.room;
  }
  public void setRoom(maze.Room rm) {
    this.room = rm;
  }
  public Actor() {
    super();
  }
}
