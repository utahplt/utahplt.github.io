package outgame;

public abstract class Monster extends game.Actor {
  public void doAi() {
    ;
  }
  public Monster() {
    super();
  }
}
