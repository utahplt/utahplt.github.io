package outgame;
import java.util.*;

public class Player extends game.Actor {
  String name;
  public String toString() { return "player " + this.name; }
  public void setName(String name) {
    this.name = name;
  }
  public Player() {
    super();
  }
}
