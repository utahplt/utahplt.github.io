package outgame;

public abstract class Item extends java.lang.Object {
  public Item() {
    super();
  }
}
