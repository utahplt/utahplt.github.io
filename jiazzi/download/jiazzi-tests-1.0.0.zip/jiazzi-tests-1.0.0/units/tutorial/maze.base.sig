signature maze.base = {
  package maze, game, io;
  class Door extends Object {
    Door();
    boolean canPass(game.Actor p);
  }
  class Room extends Object {
    Room();
    maze.Door getDoor(int dir); void setDoor(int dir, maze.Door dr);
    maze.Room getRoom(int dir); void setRoom(int dir, maze.Room rm);
    final static int NORTH = 0; 
    final static int EAST = 1; 
    final static int SOUTH = 2; 
    final static int WEST = 3; 
    final static String [] DIRS;
    void print(io.PrintStream out);
  }
}
