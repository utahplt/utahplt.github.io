package outgame;

public abstract class Player extends ingame.Player {
  public Player() {
    super();
  }
  public abstract static class XXItemXX extends ingame.Player.XXItemXX {
    public XXItemXX() {
      super();
    }
  }
}
