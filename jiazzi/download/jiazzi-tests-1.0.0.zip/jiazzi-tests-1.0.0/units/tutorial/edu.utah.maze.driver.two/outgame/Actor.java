package outgame;

public abstract class Actor extends ingame.Actor {
  public Actor() {
    super();
  }
}
