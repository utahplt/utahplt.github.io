package outgame;

public abstract class Item extends ingame.Item {
  public Item() {
    super();
  }
}
