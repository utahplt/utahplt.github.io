package outgame;

public abstract class Monster extends ingame.Monster {
  public Monster() {
    super();
  }
}
