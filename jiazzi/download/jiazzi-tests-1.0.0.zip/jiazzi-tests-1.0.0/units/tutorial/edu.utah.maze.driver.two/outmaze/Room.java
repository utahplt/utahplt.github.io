package outmaze;

public abstract class Room extends inmaze.Room {
  public Room() {
    super();
  }
  public abstract static class XXActorXX extends inmaze.Room.XXActorXX {
    public XXActorXX() {
      super();
    }
  }
  public abstract static class XXItemXX extends inmaze.Room.XXItemXX {
    public XXItemXX() {
      super();
    }
  }
}
