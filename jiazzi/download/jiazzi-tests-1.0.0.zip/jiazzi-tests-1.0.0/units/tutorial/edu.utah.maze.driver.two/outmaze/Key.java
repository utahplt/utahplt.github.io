package outmaze;

public abstract class Key extends inmaze.Key {
  public Key() {
    super();
  }
}
