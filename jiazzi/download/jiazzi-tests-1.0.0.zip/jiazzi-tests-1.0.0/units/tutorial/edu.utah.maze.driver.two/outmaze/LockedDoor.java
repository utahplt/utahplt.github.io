package outmaze;

public abstract class LockedDoor extends inmaze.LockedDoor {
  public LockedDoor() {
    super();
  }
}
