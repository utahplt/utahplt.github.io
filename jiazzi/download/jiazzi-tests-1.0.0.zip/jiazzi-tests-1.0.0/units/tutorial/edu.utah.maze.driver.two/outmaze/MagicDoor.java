package outmaze;

public abstract class MagicDoor extends inmaze.MagicDoor {
  public MagicDoor() {
    super();
  }
}
