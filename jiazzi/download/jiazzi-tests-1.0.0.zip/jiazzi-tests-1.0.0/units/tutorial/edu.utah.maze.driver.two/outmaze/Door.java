package outmaze;

public abstract class Door extends inmaze.Door {
  public Door() {
    super();
  }
}
