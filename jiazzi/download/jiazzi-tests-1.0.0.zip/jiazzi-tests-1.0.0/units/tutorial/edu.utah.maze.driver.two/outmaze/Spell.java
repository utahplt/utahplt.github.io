package outmaze;

public abstract class Spell extends inmaze.Spell {
  public Spell() {
    super();
  }
}
