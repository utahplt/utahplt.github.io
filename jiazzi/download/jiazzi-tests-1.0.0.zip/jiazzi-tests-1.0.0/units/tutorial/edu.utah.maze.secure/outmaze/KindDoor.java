package outmaze;

public abstract class KindDoor extends maze.Door {
  maze.Item item;
  public void setItem(maze.Item item) {
    this.item = item;
  }
  public String extractKind() {
    String str = this.getClass().getName();
    str = str.substring(str.lastIndexOf('.') + 1, str.length());
    while (!str.endsWith("Door")) str = str.substring(0, str.length() - 1);
    return str.substring(0, str.length() - ("Door").length());
  }
  protected maze.Item neededItem() {
    return this.item;
  }
  public String toString() {
    return this.extractKind().toLowerCase() + "-" + 
      super.toString() + "-" + this.item;
  }
  public boolean canOpen(game.Player p) {
    if (!super.canOpen(p)) return false;
    if (this.item != null) {
      if (!p.containsItem(this.item)) {
	System.out.println(p + " cannot open door because player does not have " + this.item);
	return false;
      }
    }
    return true;
  }
  public KindDoor() {
    super();
  }
}
