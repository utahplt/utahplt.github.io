package outmaze;

public abstract class Item extends game.Item {
  static int sid = 0;
  final int id;
  public Item() {
    super();
    this.id = sid;
    sid++;
  }
  public String toString() {
    String str = this.getClass().getName();
    str = str.substring(str.lastIndexOf('.') + 1, str.length());
    return str.toLowerCase() + "-" + this.id;
  }
}
