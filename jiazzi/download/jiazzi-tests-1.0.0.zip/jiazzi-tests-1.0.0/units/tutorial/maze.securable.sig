signature maze.securable = z : maze.base + {
  package maze, game, io;
  bind package maze to *@maze, game to *@game, io to *@io;
  class Door {
    boolean canOpen(game.Player p);
  }
}
