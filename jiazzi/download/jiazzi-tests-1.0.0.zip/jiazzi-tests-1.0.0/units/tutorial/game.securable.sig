signature game.securable = z : game.base + {
  package game, maze;
  bind package game to z@game, maze to z@maze;
  class Player {
    boolean containsItem(game.Item item);
  }
}
