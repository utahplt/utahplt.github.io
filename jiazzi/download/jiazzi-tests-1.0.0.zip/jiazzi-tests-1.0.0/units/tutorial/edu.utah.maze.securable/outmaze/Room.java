package outmaze;

public abstract class Room extends inmaze.Room {
  public Room() {
    super();
  }
}
