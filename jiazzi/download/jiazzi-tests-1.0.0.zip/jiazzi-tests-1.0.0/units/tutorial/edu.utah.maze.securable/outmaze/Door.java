package outmaze;

public abstract class Door extends inmaze.Door {
  public boolean canOpen(game.Player p) {
    return true;
  }
  public boolean canPass(game.Actor p) {
    if (!super.canPass(p)) return false;
    else if (p instanceof game.Player &&
	     !this.canOpen((game.Player) p)) return false;
    else return true;
  }
  public Door() {
    super();
  }
}
