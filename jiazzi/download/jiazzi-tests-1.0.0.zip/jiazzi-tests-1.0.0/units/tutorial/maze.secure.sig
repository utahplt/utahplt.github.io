signature maze.secure = z : maze.base + {
  lexeme Item, Kind;
  package maze, game, io;
  bind package maze to *@maze, game to *@game, io to *@io;
  class [Kind]Door extends maze.Door {
    ();
    void set[Item](maze.[Item] item);
    protected maze.[Item] needed[Item]();
  }
  class [Item] extends game.Item {
    ();
  }
}
