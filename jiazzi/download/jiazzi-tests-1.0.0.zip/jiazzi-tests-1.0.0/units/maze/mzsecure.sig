  external package java.util;

signature mzsecure = mzbase + {
  name [DEVICE];
  class [DEVICE] extends Item { [DEVICE](); }
  class [DEVICE]Door extends Door {
    [DEVICE]Door();
    [DEVICE] needed[DEVICE]();
    void set[DEVICE]([DEVICE] dvc);
    void toggleOpen();
    boolean isOpen();
  }
  class Player += {
    void add[DEVICE]([DEVICE] dvc);
    void remove[DEVICE]([DEVICE] dvc);
    boolean has[DEVICE]([DEVICE] dvc);
  }
  class Room += {
    void take[DEVICE]([DEVICE] dvc);
  }
}
