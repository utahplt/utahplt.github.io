external package java.util;
signature mzbase = {

  arg [DISPLAY];

  class Maze extends Object {
    Maze();
    Room entrance();
  }
  class Direction {
    ();
    static final Direction   NORTH;
    static final Direction   SOUTH;
    static final Direction   EAST;
    static final Direction   WEST;
    static final Direction[] DIRS;
  }
  abstract class Entity extends Object {
    Entity();
    void display()[DISPLAY];
    void displayFrom(Direction dir)[DISPLAY];
  }
  abstract class Item extends Entity {
    Item();
  }
  class Room extends Entity {
    Room(String name); 
    Room makeRoom(Direction dir, String name);
    void setDoor(Direction dir, Door door);
    Room getRoom(Direction dir);
    Door getDoor(Direction dir);
    String name();
    Set items();
  }
  class Door extends Entity {
    public Door();
    public boolean enter(Player player)[DISPLAY];
  }
  class Player extends Entity {
    Player(String name, Maze mz);
    boolean move(Direction d)[DISPLAY];
    String name();
    Room room();
    void add(Item);
  }

  //  interface MyInterface {
  //void destroy();
  //}
}


