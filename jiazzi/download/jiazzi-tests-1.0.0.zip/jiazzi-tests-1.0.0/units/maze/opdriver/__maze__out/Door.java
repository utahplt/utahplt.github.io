package __maze__out;

public class Door extends __maze__in.Door {
  public Door() {
    super();
  }
}
