package __maze__out;

public class Spell extends __maze__in.Spell {
  public Spell() {
    super();
  }
}
