package __maze__out;

public class SpellDoor extends __maze__in.SpellDoor {
  public SpellDoor() {
    super();
  }
}
