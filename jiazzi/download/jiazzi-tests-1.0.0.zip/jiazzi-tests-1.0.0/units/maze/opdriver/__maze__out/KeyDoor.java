package __maze__out;

public class KeyDoor extends __maze__in.KeyDoor {
  public KeyDoor() {
    super();
  }
}
