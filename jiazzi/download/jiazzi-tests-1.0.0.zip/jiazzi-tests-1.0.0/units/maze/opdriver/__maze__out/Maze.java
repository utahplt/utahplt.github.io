package __maze__out;
import java.io.*;

public class Maze extends __maze__in.Maze {
  public Maze() {
    super();
  }
  public static void main(String args[]) throws IOException {
    maze.Maze mz = new maze.Maze();

    maze.KeyDoor kdoor0 = new maze.KeyDoor();
    maze.KeyDoor kdoor1 = new maze.KeyDoor();
    maze.Key key0 = new maze.Key();
    maze.Key key1 = new maze.Key();
    kdoor0.setKey(key0);
    kdoor1.setKey(key1);


    maze.SpellDoor sdoor0 = new maze.SpellDoor();
    maze.SpellDoor sdoor1 = new maze.SpellDoor();
    maze.Spell spell0 = new maze.Spell();
    maze.Spell spell1 = new maze.Spell();
    sdoor0.setSpell(spell0);
    sdoor1.setSpell(spell1);

    mz.entrance().items().add(spell0);
    mz.entrance().items().add(spell1);
    mz.entrance().items().add(key0);
    mz.entrance().items().add(key1);

    maze.Room br = mz.entrance().makeRoom(maze.Direction.NORTH, "ballroom");
    mz.entrance().setDoor(maze.Direction.NORTH, new maze.Door());


    maze.Room dr = br.makeRoom(maze.Direction.WEST, "dining room");
    br.setDoor(maze.Direction.WEST, sdoor0);

    maze.Room kt = mz.entrance().makeRoom(maze.Direction.SOUTH, "kitchen");
    mz.entrance().setDoor(maze.Direction.SOUTH, kdoor0);

    maze.Room xt = kt.makeRoom(maze.Direction.SOUTH, "closet");
    kt.setDoor(maze.Direction.SOUTH, kdoor1);

    maze.Player p = new maze.Player(args[0], mz);
    p.exec(System.out, new BufferedReader(new InputStreamReader(System.in)));
  }
}
