package __maze__out;

public abstract class Entity extends __maze__in.Entity {
  public Entity() {
    super();
  }
}
