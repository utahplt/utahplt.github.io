package __maze__out;

public class Key extends __maze__in.Key {
  public Key() {
    super();
  }
}
