package __maze__out;
import java.io.*;

public class Player extends __maze__in.Player {
  public Player(java.lang.String name, maze.Maze mz) {
    super(name, mz);
  }
  public void use(maze.Key key, maze.KeyDoor door, PrintStream out, int indent) {
    this.indent(out, indent);
    out.print("trying to use ");
    super.use(key,door,out,indent);
  }
  public void cast(maze.Spell spell, PrintStream out, int indent) {
    this.indent(out, indent);
    out.print("trying to cast ");
    super.cast(spell,out,indent);
  }
}
