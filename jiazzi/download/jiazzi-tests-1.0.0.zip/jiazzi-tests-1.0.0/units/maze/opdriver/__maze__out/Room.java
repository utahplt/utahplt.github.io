package __maze__out;
import java.io.*;

public class Room extends __maze__in.Room {
  public Room(java.lang.String name) {
    super(name);
  }
}
