signature mzmagloccli = mzmagloc + mzcli + {
}
