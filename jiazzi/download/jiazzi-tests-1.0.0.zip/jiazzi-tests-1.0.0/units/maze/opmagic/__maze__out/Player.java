package __maze__out;

public class Player extends __maze__in.Player {
  public maze.Spell casting;
  public String toString() { 
    return super.toString() + (this.casting == null ? "" : " casting " + this.casting);
  }
  public void cast(maze.Spell spell) {
    if (!this.hasSpell(spell)) return;
    this.removeSpell(spell);
    this.casting = spell;
    this.casting.display();
  }
  public Player(java.lang.String name, maze.Maze mz) {
    super(name, mz);
  }
}
