package __maze__out;

public class Room extends __maze__in.Room {
  public Room(java.lang.String name) {
    super(name);
  }
  public void takeSpell(maze.Spell spell) {
    super.takeSpell(spell);
    // this.allSpells().remove(spell);
  }
}
