package __maze__out;

public class SpellDoor extends __maze__in.SpellDoor {
  public SpellDoor() {
    super();
  }
  public boolean enter(maze.Player p) {
    if (p.casting != this.neededSpell()) {
      p.cast(this.neededSpell());
    }
    if (p.casting != this.neededSpell()) return false;
    boolean b0 = this.isOpen();
    if (!b0)
      this.toggleOpen();
    boolean b1 = super.enter(p);
    if (!b0)
      this.toggleOpen();
    return b1;
  }
}
