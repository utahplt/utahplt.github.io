
signature mzmagic = mzsecure + {
  [DEVICE] = Spell;
  class Player += {
    void cast(Spell spell)[DISPLAY];
  }
}
