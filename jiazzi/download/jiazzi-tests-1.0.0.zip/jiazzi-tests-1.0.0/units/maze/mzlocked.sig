signature mzlocked = mzsecure + {
  [DEVICE] = Key;
  class Player += {
    void use(Key key, KeyDoor door)[DISPLAY];
  }
}
