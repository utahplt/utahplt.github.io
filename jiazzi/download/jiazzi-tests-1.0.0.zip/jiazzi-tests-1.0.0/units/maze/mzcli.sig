  external package java.io;

signature mzcli = mzbase + {
  [DISPLAY] = (PrintStream out, int indent);

  abstract class Entity += {
    void indent(PrintStream out, int indent);
  }
  class Player += {
    void exec(PrintStream out, BufferedReader reader) throws IOException;
  }
}
