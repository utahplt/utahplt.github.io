package __maze__out;

public abstract class Item extends __maze__in.Item {
  public Item() {
    super();
  }
}
