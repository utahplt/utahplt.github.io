package __maze__out;

public class Direction extends __maze__in.Direction {
  public Direction() {
    super();
  }
}
