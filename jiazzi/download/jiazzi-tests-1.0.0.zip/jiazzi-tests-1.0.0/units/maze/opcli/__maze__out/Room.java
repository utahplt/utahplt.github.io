package __maze__out;
import java.io.*;

public class Room extends __maze__in.Room {
  public Room(java.lang.String name) {
    super(name);
  }
  public void display(PrintStream out, int indent) {
    this.indent(out, indent);
    out.println("" + this);
    super.display(out, indent + 1);
  }
}
