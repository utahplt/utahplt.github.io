package __maze__out;
import java.io.*;

public class Maze extends __maze__in.Maze {
  public Maze() {
    super();
  }
}
