package __maze__out;
import java.io.*;
import java.util.*;

public class Player extends __maze__in.Player {

  public boolean move(maze.Direction dir, PrintStream out, int indent) {
    if (!super.move(dir, out, indent)) {
      this.indent(out, indent);
      out.println(this + " cannot move " + dir);
      return false;
    } else {
      out.println(this + " moved " + dir);
      this.room().display(out, indent);
      return true;
    }
  }
  public void help(PrintStream out) {
    out.println("commands");
    out.println("  move {north,east,south,west}");
    out.println("  get [item-name]");
    out.println("  help");
  }
  public void exec(PrintStream out, BufferedReader reader) throws IOException {
    this.help(out);
    this.room().display(out, 0);
    while (true) {
      String line = reader.readLine();
      line = line.toLowerCase();
      // out.println(line);
      if (line.startsWith("look")) this.room().display(out, 0);
      if (line.startsWith("move ")) {
	line = line.substring(("move ").length(), line.length());
	int dirc = line.charAt(0);
	maze.Direction dir;
	switch (dirc) {
	case 'n': dir = maze.Direction.NORTH; break;
	case 's': dir = maze.Direction.SOUTH; break;
	case 'e': dir = maze.Direction.EAST;  break;
	case 'w': dir = maze.Direction.WEST;  break;
	default: throw new Error();
	}
	this.move(dir, out, 0);
      }
      if (line.startsWith("get ")) {
	line = line.substring(("get ").length(), line.length());
	for (Iterator i = this.room().items().iterator(); true; i = i) {
	  if (!i.hasNext()) {
	    out.println("cannot get " + line);
	    break;
	  }
	  maze.Item item = (maze.Item) i.next();
	  String id = item.toString();
	  id = id.toLowerCase();
	  if (line.startsWith(id)) {
	    out.println("got " + item);
	    this.add(item);
	    break;
	  }
	}
      }
      if (line.startsWith("help")) this.help(out);
    }
  }
  public Player(java.lang.String name, maze.Maze mz) {
    super(name, mz);
  }
}
