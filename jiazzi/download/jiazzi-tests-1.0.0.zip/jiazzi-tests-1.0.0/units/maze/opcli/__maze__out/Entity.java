package __maze__out;
import java.io.*;
public abstract class Entity extends __maze__in.Entity {
  public Entity() {
    super();
  }
  public void indent(PrintStream out, int indent) {
    if (indent == 0) return;
    out.print(" "); this.indent(out, indent - 1);
  }
  public void display(PrintStream out, int indent) {
    this.indent(out, indent); 
    out.println(this);
  }
  public void displayFrom(maze.Direction dir, PrintStream out, int indent) {
    this.indent(out, indent); 
    out.println(dir + ": " + this);
    if (false) super.displayFrom(dir, out, indent + 1);
  }
}
