package __maze__out;

import java.io.*;

public class Door extends __maze__in.Door {
  public Door() {
    super();
  }
  public String toString() { return "door"; }
}
