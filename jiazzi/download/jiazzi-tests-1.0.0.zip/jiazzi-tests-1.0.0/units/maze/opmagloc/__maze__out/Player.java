package __maze__out;

public class Player extends __maze__in.Player {
  public Player(java.lang.String nm) {
    super(nm);
  }
}
