package __maze__out;

public class Item extends __maze__in.Item {
  public Item() {
    super();
  }
}
