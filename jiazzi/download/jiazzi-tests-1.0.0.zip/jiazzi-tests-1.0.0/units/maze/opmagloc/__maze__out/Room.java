package __maze__out;

public class Room extends __maze__in.Room {
  public Room() {
    super();
  }
}
