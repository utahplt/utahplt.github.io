package outfoo;
public abstract class Foo1 extends outfoo.Foo0 implements ppp.MyInterface {
  public Foo1() {
        super();
  }
}
