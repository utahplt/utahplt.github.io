package outfoo;
public class Foo2 extends outfoo.Foo1 implements ppp.MyInterface {
  public void foo(ppp.Maze maze) {
    throw new Error("skeleton, please implement");
  }
  public void destroy() {
    throw new Error("skeleton, please implement");
  }
  public Foo2() {
        super();
  }
}
