package outfoo;
public abstract class Foo0 extends ppp.Maze implements ppp.MyInterface {
  public abstract void foo(ppp.Maze maze);
  public Foo0() {
        super();
  }
}
