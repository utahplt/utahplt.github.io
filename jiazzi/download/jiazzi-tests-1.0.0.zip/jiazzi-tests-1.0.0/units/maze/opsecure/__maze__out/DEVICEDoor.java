package __maze__out;

public class DEVICEDoor extends maze.Door {
  maze.DEVICE dvc;
  boolean isOpen = false;
  public maze.DEVICE neededDEVICE() {
    return this.dvc;
  }
  public void setDEVICE(maze.DEVICE dvc) {
    this.dvc = dvc;
  }
  public boolean enter(maze.Player player) {
    if (!super.enter(player)) return false;
    return this.isOpen;
  }
  public void display() {
    super.display();
    if (this.dvc != null) this.dvc.display();
  }
  public String toString() { 
    return super.toString() + (this.dvc == null ? "" : " " + this.dvc) + (" open=" + this.isOpen);
  }
  public boolean isOpen() { return this.isOpen; }
  public void toggleOpen() {
    this.isOpen = !this.isOpen;
  }
  public DEVICEDoor() {
    super();
  }
}
