package __maze__out;
import java.util.*;

public class Player extends __maze__in.Player {
  Set devices = new HashSet();
  public String toString() { return super.toString() + " " + this.devices; }

  public void display() {
    super.display();
    for (Iterator i = this.devices.iterator(); i.hasNext(); i = i) 
      ((DEVICE) i.next()).display();
  }
  public boolean hasDEVICE(maze.DEVICE dvc) {
    return this.devices.contains(dvc);
  }
  public void addDEVICE(maze.DEVICE dvc) {
    this.devices.add(dvc);
  }
  public void add(maze.Item item) {
    if (item instanceof maze.DEVICE) {
      this.room().takeDEVICE((maze.DEVICE) item);
      this.addDEVICE((maze.DEVICE) item);
    } else super.add(item);
  }
  public void removeDEVICE(maze.DEVICE dvc) {
    this.devices.remove(dvc);
  }
  public Player(String name, maze.Maze mz) {
    super(name, mz);
  }
}
