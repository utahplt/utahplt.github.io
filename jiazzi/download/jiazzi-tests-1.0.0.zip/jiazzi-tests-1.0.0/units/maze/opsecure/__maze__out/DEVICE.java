package __maze__out;

public class DEVICE extends maze.Item {
  static int sn = 0;
  final int n;
  public String toString() {
    String s = this.getClass().getName();
    s = s.substring(s.lastIndexOf('.') + 1, s.length());
    return s + "-" + this.n;
  }
  public DEVICE() {
    super();
    this.n = sn;
    sn++;
  }
}
