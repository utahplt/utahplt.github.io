package __maze__out;
import java.util.*;

public class Room extends __maze__in.Room {
  public void takeDEVICE(maze.DEVICE dvc) {
    return;
  }
  public Room(String name) {
    super(name);
  }
}
