signature mzmagloc = mzmagic + mzlocked + {
}
