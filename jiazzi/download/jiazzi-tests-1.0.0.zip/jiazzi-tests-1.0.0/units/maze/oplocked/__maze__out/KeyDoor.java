package __maze__out;

public class KeyDoor extends __maze__in.KeyDoor {
  public KeyDoor() {
    super();
  }
  public boolean enter(maze.Player player) {
    if (!this.isOpen()) {
      player.use(this.neededKey(), (maze.KeyDoor) this);
    }
    if (!this.isOpen()) return false;
    return super.enter(player);
  }
}
