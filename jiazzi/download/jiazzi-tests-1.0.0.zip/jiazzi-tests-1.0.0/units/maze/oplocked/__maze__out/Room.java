package __maze__out;
import java.util.*;
public class Room extends __maze__in.Room {
  public Room(java.lang.String name) {
    super(name);
  }
  public void takeKey(maze.Key key) {
    super.takeKey(key);
    this.items().remove(key);
  }
}
