package __maze__out;

public class Maze extends __maze__in.Maze {
  public Maze() {
    super();
  }
}
