package __maze__out;

public class Player extends __maze__in.Player {
  public void use(maze.Key key, maze.KeyDoor door) {
    key.display();
    if (!this.hasKey(key)) return;
    if (door.neededKey() != key) return;
    door.toggleOpen();
  }
  public Player(java.lang.String name, maze.Maze mz) {
    super(name, mz);
  }
}
