package __maze__out;
import java.util.*;

public class Maze extends java.lang.Object {
  final maze.Room entrance;
  // public final Map<Point,maze.Room> rooms =
  //   new HashMap<Point,maze.Room>();
  public final Map rooms =
    new HashMap();

  public maze.Room entrance() {
    return this.entrance;
  }
  public Maze() {
    super();
    try {
      this.entrance = new maze.Room("entrance");
      this.entrance.mz = (maze.Maze) this;
      this.entrance.pos = new Point(0, 0);
    } finally {
      this.rooms.put(new Point(0, 0), this.entrance);
    }
  }

  public static void main(String args[]) {
    System.out.println("main: " + (new maze.Maze()).getClass());
  }
}
