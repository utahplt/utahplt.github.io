package __maze__out;

public abstract class Item extends maze.Entity {
  public Item() {
    super();
  }
}
