package __maze__out;
import java.util.*;

public class Room extends maze.Entity {

  Set items = new HashSet();
  public String name;
  protected final maze.Door doors[] = new maze.Door[maze.Direction.DIRS.length];
  public Point pos;
  public maze.Maze mz;

  public Set items() { return this.items; }
  public void display() {
    for (int i = 0; i < maze.Direction.DIRS.length; i++) {
      maze.Direction dir = maze.Direction.DIRS[i];
      if (this.doors[i] == null) continue;
      this.doors[i].displayFrom(dir);
    }
    for (Iterator i = this.items.iterator(); i.hasNext(); i = i) {
      maze.Item item = (maze.Item) i.next();
      item.display();
    }
  }
  public void setDoor(maze.Direction dir, maze.Door door) {
    if (this.doors[dir.index] != null) {
      throw new Error(this.doors[dir.index] + " already exists " + dir + " in " + this);
    }
    maze.Room room = this.getRoom(dir);
    if (room == null) 
      throw new Error("no room " + dir + " of " + this + " to make door");
    this.doors[dir.index] = door;
    if (room.doors[dir.neg.index] != null) throw new Error();
    room.doors[dir.neg.index] = door;
  }
  public maze.Door getDoor(maze.Direction dir) {
    return this.doors[dir.index];
  }
  public maze.Room getRoom(maze.Direction dir) {
    Point p = this.pos.add(dir.point);
    return (maze.Room) this.mz.rooms.get(p);
  }
  public maze.Room makeRoom(maze.Direction dir, java.lang.String name) {
    Point p = this.pos.add(dir.point);
    if (this.mz.rooms.containsKey(p)) {
      throw new Error("cannot create room " + name + " because " + this.mz.rooms.get(p) +
		      " already exists to " + dir + " of " + this);
    }
    maze.Room room = new maze.Room(name);
    room.pos = p;
    room.mz = this.mz;
    this.mz.rooms.put(p, room);
    return room;
  }
  public java.lang.String name() {
    return this.name;
  }
  public String toString() {
    return "room " + this.name;
  }
  public Room(java.lang.String name) {
    super();
    this.name = name;
  }
}
