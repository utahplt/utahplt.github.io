package __maze__out;

public abstract class Entity extends java.lang.Object {
  public void display() {
  }

  public void displayFrom(maze.Direction dir) {
    this.display();
  }
  public Entity() {
    super();
  }
}
