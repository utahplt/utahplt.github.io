package __maze__out;

public class Door extends maze.Entity {
  public void display() {}
  public Door() {
    super();
  }
  public boolean enter(maze.Player p) {
    return true;
  }
}
