package __maze__out;

public class Player extends maze.Entity {
  maze.Room room;
  public String name;
  public void display() {
  }
  public java.lang.String name() {
    return this.name;
  }
  public maze.Room room() { return this.room; }
  public boolean move(maze.Direction dir) {
    maze.Door door = this.room.getDoor(dir);
    if (door == null) return false;
    if (!door.enter((maze.Player) this)) return false;
    this.room = this.room.getRoom(dir);
    return true;
  }
  public String toString() { return "player " + this.name; }
  public Player(java.lang.String name, maze.Maze mz) {
    super();
    this.name = name;
    this.room = mz.entrance();
  }
  public void add(maze.Item item) {
    System.err.println("BUG: no handler for item " + item);
  }
}
