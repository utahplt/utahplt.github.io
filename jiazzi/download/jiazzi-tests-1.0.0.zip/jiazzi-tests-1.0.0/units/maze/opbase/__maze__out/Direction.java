package __maze__out;

public class Direction extends java.lang.Object {
  public String label;
  public int index;
  public  Point point;
  public maze.Direction neg;
  public Direction() {
  }
  public String toString() { return this.label; }
  public final static maze.Direction SOUTH = new maze.Direction();
  public final static maze.Direction WEST = new maze.Direction();
  public final static maze.Direction NORTH = new maze.Direction();
  public final static maze.Direction EAST = new maze.Direction();
  static {
    SOUTH.point = new Point(  0, +1);
    NORTH.point = new Point(  0, -1);
    EAST.point = new Point( +1,  0);
    WEST.point = new Point( -1,  0);

    SOUTH.label = "south";
    NORTH.label = "north";
    EAST.label = "east";
    WEST.label = "west";

    SOUTH.neg = NORTH;
    NORTH.neg = SOUTH;
    WEST.neg = EAST;
    EAST.neg = WEST;
  }
  public final static maze.Direction[] DIRS = {
    SOUTH, WEST, NORTH, EAST
  };
  static {
    for (int i = 0; i < DIRS.length; i++) 
      DIRS[i].index = i;
  }
}
