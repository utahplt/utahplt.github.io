package __maze__out;
import java.util.*;

  public  class Point {
    final int x;
    final int y;
    public int getX() { return this.x; }
    public int getY() { return this.y; }
    public Point(int x, int y) {
      this.x = x; this.y = y;
    }
    public Point add(Point point) {
      return new Point(this.x + point.x, this.y + point.y);
    }
    public int hashCode() { return this.x + this.y; }
    public boolean equals(Object obj) {
      if (!(obj instanceof Point)) return false;
      Point p = (Point) obj;
      return p.x == this.x && p.y == this.y;
    }
  }

