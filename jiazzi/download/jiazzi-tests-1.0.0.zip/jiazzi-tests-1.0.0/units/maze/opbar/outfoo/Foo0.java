package outfoo;
public abstract class Foo0 extends infoo.Foo0 implements ppp.MyInterface {
  public Foo0() {
        super();
  }
}
