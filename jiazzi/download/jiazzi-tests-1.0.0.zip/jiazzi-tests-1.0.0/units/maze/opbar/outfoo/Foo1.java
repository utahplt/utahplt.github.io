package outfoo;
public abstract class Foo1 extends infoo.Foo1 implements ppp.MyInterface {
  public Foo1() {
        super();
  }
}
