package outfoo;
public class Foo2 extends infoo.Foo2 implements ppp.MyInterface {
  public Foo2() {
        super();
  }
}
