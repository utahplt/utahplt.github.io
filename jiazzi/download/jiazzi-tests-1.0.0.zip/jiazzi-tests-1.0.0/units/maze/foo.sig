signature foo = {
  package p;
  abstract class Foo0 extends p.Maze implements p.MyInterface { 
    (); 
    abstract void foo(p.Maze maze);
  }
  abstract class Foo1 extends Foo0 {
    ();
  }
  class Foo2 extends Foo1 {
    ();
  }
}
