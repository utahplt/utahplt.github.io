external package org.omg.CORBA;

signature corba = {
  class Foo {
    void foo(Object o0, org.omg.CORBA.Object o1);
  }
}
