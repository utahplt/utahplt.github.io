/*
 * Created on Sep 29, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package edu.utah.jiggy.meta.flag.tests;

import junit.framework.TestCase;
import edu.utah.jiggy.meta.flag.*;

/**
 * @author swalton
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class FlagTest extends TestCase {
	
	//--- Flag is faux-abstract, so we can just create an instance through an empty override.
	Flag flag = new Flag(){};

	public final void testFlag() {
		//--- Everything is done in the constants.
	}
	
	public final void testJavaSource() throws Exception {
		if ( !flag.javaSource().equals("") )
			throw new Exception(flag.getClass().getSuperclass().getName() + ".javaSource(): must be ''");
	}

	/*
	 * Class under test for String toString()
	 */
	public final void testToString() throws Exception {
		if ( !flag.toString().equals("FlagTest$1") )
			throw new Exception(flag.getClass().getSuperclass().getName() + ".toString(): must be 'Flag'");
	}

	public final void testJvmcode() throws Exception {
		if ( flag.jvmcode() != edu.utah.jiggy.Constants.JVM_oblique )
			throw new Exception(flag.getClass().getSuperclass().getName() + ".jvmcode(): must be zero");
	}

}
