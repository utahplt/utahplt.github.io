/*
 * Created on Sep 29, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package edu.utah.jiggy;

/**
 * @author swalton
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Constants {
	public static final int JVM_oblique = 0;
	public static final int JVM_AbstractFlag = 0x400;
}
