/*
 * Created on Sep 29, 2005
 *
 */
package edu.utah.jiggy.meta.flag.tests;

import junit.framework.TestCase;
import edu.utah.jiggy.meta.flag.*;

/**
 * @author swalton
 */
public class AbstractFlagTest extends TestCase {

	AbstractFlag flag = new AbstractFlag();
	
	public final void testJvmcode() throws Exception {
		if ( flag.jvmcode() != edu.utah.jiggy.Constants.JVM_AbstractFlag )
			throw new Exception(flag.getClass().getName() + ".jvmcode(): must be " + edu.utah.jiggy.Constants.JVM_AbstractFlag);
	}

	/*
	 * Class under test for java.lang.String javaSource()
	 */
	public final void testJavaSource() throws Exception {
		if ( !flag.javaSource().equals("abstract ") )
			throw new Exception(flag.getClass().getName() + ".javaSource(): must be 'abstract '");
	}

	public final void testAbstractFlag() throws Exception {
		if ( !FlagConstants.CLASSMEMBER_FLAGS0.contains(this) )
			throw new Exception(flag.getClass().getName() + ".CONSTRUCTOR failed to add self to CLASSMEMBER_FLAGS0");
		if ( !FlagConstants.CLASS_FLAGS0.contains(this) )
			throw new Exception(flag.getClass().getName() + ".CONSTRUCTOR failed to add self to CLASS_FLAGS0");
		if ( !FlagConstants.FIELD_FLAGS0.contains(this) )
			throw new Exception(flag.getClass().getName() + ".CONSTRUCTOR failed to add self to FIELD_FLAGS0");
	}

	public final void testParent() throws Exception {
		if ( flag.parent() != null )
			throw new Exception(flag.getClass().getName() + ".parent must be null");
	}

	public final void testIsa() throws Exception {
		if ( !flag.isa(flag) )
			throw new Exception(flag.getClass().getName() + ".isa failure: '" + flag.getClass().getName() + "' is valid");
//		VirtualFlag vf = flag.getClass().getSuperclass();
	}

	public final void testVirtualFlag() {
		//TODO Implement VirtualFlag().
	}

	public final void testParse() {
		//TODO Implement parse().
	}

	public final void testParentA() {
		//TODO Implement parentA().
	}

	public final void testUse() {
		//TODO Implement Use().
	}

	public final void testParent0() {
		//TODO Implement parent0().
	}

	public final void testIsa0() {
		//TODO Implement isa0().
	}

	public final void testAdvancingFlag() {
		//TODO Implement AdvancingFlag().
	}

	public final void testFlag() {
		//TODO Implement Flag().
	}

	/*
	 * Class under test for String javaSource()
	 */
	public final void testJavaSource1() {
		//TODO Implement javaSource().
	}

	/*
	 * Class under test for String toString()
	 */
	public final void testToString() {
		//TODO Implement toString().
	}

}
