package edu.utah.jiazzi.tests;

import java.io.File;

import edu.utah.jiazzi.driver.Main;
import junit.framework.TestCase;

public class HelloTest extends TestCase {

	private void assertFileExists(String pathname) {
		File f = new File(pathname);
		assertTrue("file \"" + pathname + "\" does not exist",
				f.exists());
	}
	
	private void deleteFileIfExists(String pathname) throws Exception{
		File f = new File(pathname);
		if (f.exists() == false)
			return;
		if (f.delete() != true)
			throw new Exception("cannot delete file \"" + pathname + "\"");
	}
	
	/* (non-Javadoc)
	 * @see junit.framework.TestCase#setUp()
	 */
	protected void setUp() throws Exception {
		super.setUp();
		
		// testEmpty()
		// testHello()
	}

	public void testEmpty() throws Exception {
        String unitsDirname = "units"
            + File.separator + "misc";
		String mainFilename = unitsDirname
            + File.separator + "empty"
			+ File.separator + "main"
			+ File.separator + "Main.java";
		String stubsFilename = unitsDirname
			+ File.separator + "empty"
			+ File.separator + "stubs.jar";
		
		deleteFileIfExists(mainFilename);
		deleteFileIfExists(stubsFilename);
		
		// First arg:  name of the unit directory.
		// Second arg: what you want to do (`-stub').
		// Third arg:  for `-stub', the base name of the unit file.
		String args[] = { unitsDirname, "-stub", "empty" };
		Main.main(args);
		assertFileExists(mainFilename);
		assertFileExists(stubsFilename);
	}
	
	public void testHello() throws Exception {
        String unitsDirname = "units"
            + File.separator + "misc";
		String stubsFilename = unitsDirname
			+ File.separator + "hello"
			+ File.separator + "stubs.jar";

		deleteFileIfExists(stubsFilename);

		// First arg:  name of the unit directory.
		// Second arg: what you want to do (`-stub').
		// Third arg:  for `-stub', the base name of the unit file.
		String args[] = { unitsDirname, "-stub", "hello" };
		Main.main(args);
		assertFileExists(stubsFilename);
        
        // TODO: compile the unit sources
        // TODO: invoke Jiazzi to link the unit
	}
	
	public void testLink() throws Exception {
        String unitsDirname = "units"
            + File.separator + "misc";
		String link1Filename = unitsDirname
			+ File.separator + "link1.jar";

		deleteFileIfExists(link1Filename);
		
		String args[] = { unitsDirname, "-link", "link1" };
		Main.main(args);
		assertFileExists(link1Filename);
	}
}
