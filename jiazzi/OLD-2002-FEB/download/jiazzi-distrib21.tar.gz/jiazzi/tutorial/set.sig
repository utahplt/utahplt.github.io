signature set = z:generic + {
  package set, util;
  lexeme Set, Kind;
  generic KEY;
  bind lexeme [Set] to z@Generic;
  
  class [Set] {

    boolean contains[Kind](KEY);
    int hashCode[Kind](KEY);
    boolean equals[Kind](KEY,KEY);

    boolean add[Kind](KEY);
    boolean remove[Kind](KEY);
    boolean addAll[Kind](set.[Set]);
    boolean removeAll[Kind](set.[Set]);

    util.Set<KEY> set[Kind]();
    util.Iterator<KEY> iterator[Kind]();
  }
}
