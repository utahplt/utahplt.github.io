signature gjlist = g:generic + {
  lexeme List, Prefix;
  generic TYPE;
  package list, util;
  bind package list to g@generic;
  bind lexeme [List] to g@Generic;
  /* override */
  class [List] {
    static class XX[Prefix]XX { (); }
    ();
    int size[Prefix]();
    void add[Prefix](TYPE item);
    void add[Prefix](int index, TYPE item);
    boolean remove[Prefix](TYPE item);
    boolean contains[Prefix](TYPE item);
    TYPE remove[Prefix](int index);
    TYPE get[Prefix](int index);

    util.Iterator<TYPE> iterator[Prefix]();
    util.List<TYPE> list[Prefix](); 
  }
}
