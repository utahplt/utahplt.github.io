signature maze.base = {
  package maze, game, io;
  class Door extends Object {
    Door();
    boolean canPass(game.Actor p);
  }
  class Room extends Object {
    Room();
    maze.Door getDoor(int dir); void setDoor(int dir, maze.Door dr);
    maze.Room getRoom(int dir); void setRoom(int dir, maze.Room rm);
    final static int NORTH; final static int EAST; 
    final static int SOUTH; final static int WEST; 
    final static String [] DIRS;
    void print(io.PrintStream out);
  }
}
