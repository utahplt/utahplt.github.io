signature maze.lists = z : maze.base + p : list + i : list + {
  package maze, game, io, util;
  bind package maze to z@maze, game to z@game, io to z@io;
  bind package maze to *@list, util to *@util;

  bind name Room to *@List, Actor to p@Prefix, Item to i@Prefix;
  bind type game.Actor to  p@TYPE, game.Item to i@TYPE;
}

