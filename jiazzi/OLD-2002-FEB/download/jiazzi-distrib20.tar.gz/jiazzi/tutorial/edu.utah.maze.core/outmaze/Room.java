package outmaze;

public class Room extends java.lang.Object {
  protected maze.Door[] doors = new maze.Door[4];
  protected maze.Room[] rooms = new maze.Room[4];
  game.Item item;
  static int sid = 0;
  int id;

  public String toString() {
    return "room-" + this.id;
  }
  public void print(java.io.PrintStream out) {
    out.println(this);
    for (int i = 0; i < doors.length; i++) {
      if (doors[i] != null) {
	out.println("door in " + maze.Room.DIRS[i]);
      }
    }
  }
  public maze.Door getDoor(int dir) { return this.doors[dir]; }
  public maze.Room getRoom(int dir) { return this.rooms[dir]; }
  public void setDoor(int dir, maze.Door dr) {
    this.doors[dir] = dr;
    this.makeConsistent(dir);
  }
  public void setRoom(int dir, maze.Room rm) {
    this.rooms[dir] = rm;
    this.makeConsistent(dir);
  }
  public void makeConsistent(int dir) {
    if (this.rooms[dir] != null) {
      if (this.doors[dir] != null)
	this.rooms[dir].doors[3 - dir] = this.doors[dir];
      else if (this.rooms[dir].doors[3 - dir] != null)
	this.doors[dir] = this.rooms[dir].doors[3 - dir];
      this.rooms[dir].rooms[3 - dir] = (maze.Room) this;
    }
  }
  public void setItem(game.Item item) {
    this.item = item;
  }
  public game.Item getItem() {
    return this.item;
  }
  public Room() {
    super();
    this.id = sid;
    sid++;
  }
  public final static int NORTH = 0; /* 0 */
  public final static int SOUTH = 3; /* 3 */
  public final static int EAST = 1; /* 1 */
  public final static int WEST = 2; /* 2 */
  public final static String[] DIRS = new String[4];
  static {
    DIRS[maze.Room.NORTH] = "north";
    DIRS[maze.Room.SOUTH] = "south";
    DIRS[maze.Room.WEST] = "west";
    DIRS[maze.Room.EAST] = "east";
  }
}
