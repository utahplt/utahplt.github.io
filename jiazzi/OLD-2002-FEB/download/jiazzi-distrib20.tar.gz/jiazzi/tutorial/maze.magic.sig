signature maze.magic = z : maze.secure + {
  package maze, game, io;
  bind package maze to *@maze, game to *@game, io to *@io;
  bind name Magic to z@Kind, Spell to z@Item;
}
