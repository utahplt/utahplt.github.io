signature maze.locked = z : maze.secure + {
  package maze, game, io;
  bind package maze to *@maze, game to *@game, io to *@io;
  bind name Locked to z@Kind, Key to z@Item;
}
