signature game.lists = z0 : game.base + z1 : list + {
  package game, maze, util, io;
  bind package game to *@game, maze to *@maze, game to *@list, util to *@util, io to *@io;
  bind name Player to *@List, Item to *@Prefix;
  bind type game.Item to *@TYPE;
}
