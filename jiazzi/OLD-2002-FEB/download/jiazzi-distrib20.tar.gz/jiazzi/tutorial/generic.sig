signature generic = {
  name Generic;
  package generic;
  class *[Generic] extends Object { (); }
}
