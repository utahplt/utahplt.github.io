signature test = {
  class Test { 
    Test(); 
    static void main(String args[]);
  }
}
