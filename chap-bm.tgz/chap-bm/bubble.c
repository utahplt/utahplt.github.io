#include <stdlib.h>

#define SIZE 10000

int *make_vec()
{
  int i, *vec;
  vec = (int *)malloc(SIZE * sizeof(int));
  for (i = 0; i < SIZE; i++)
    vec[i] = SIZE - i;
  return vec;
}

static void bubble_sort(int *vec) 
{
  int i, changed = 1, a, b;

  while (changed) {
    changed = 0;

    for (i = 0; i < SIZE - 1; i++) {
      a = vec[i];
      b = vec[i+1];
      if (a > b) {
        vec[i] = b;
        vec[i+1] = a;
        changed = 1;
      }
    }
  }
}
  
int main()
{
  bubble_sort(make_vec());
  return 0;
}
