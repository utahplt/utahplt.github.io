#lang racket/base
(require (for-syntax racket/base))

(provide test
         test-blame
         test-no-exn
         tests-done)

(define tests 0)
(define (tests-done)
  (printf "~a tests\n" tests)
  (set! tests 0))

(define-syntax (test-no-exn stx)
  (syntax-case stx ()
    [(_ get)
     (with-syntax ([line (syntax-line stx)]
                   [file (let ([s (syntax-source stx)])
                           (if (string? s)
                               s
                               ""))])
       (syntax (test (begin get (void)) (void) line file)))]))

(define-syntax (test stx)
  (syntax-case stx ()
    [(_ get expected)
     (with-syntax ([line (syntax-line stx)]
                   [file (let ([s (syntax-source stx)])
                           (if (string? s)
                               s
                               ""))])
       (syntax (test get expected line file)))]
    [(_ get expected line file)
     (syntax (test/proc (cons file line)
                        (λ () get)
                        expected))]))

(define (test/proc line get expected)
  ;(printf "testing ~s\n" line)
  (set! tests (+ tests 1))
  (let ([got (with-handlers ([exn? values])
               (get))])
    (cond
      [(equal? got expected)
       (void)]
      [(exn? got)
       (fprintf (current-error-port)
                "FAILED: expected ~s got exn, line ~a\n" 
                expected line)
       ((error-display-handler) (exn-message got) got)]
      [else
       (fprintf (current-error-port)
                "FAILED: expected ~s got ~s, line ~a\n" 
                expected got line)])))

(define-syntax (test-blame stx)
  (syntax-case stx ()
    [(_ who get)
     (with-syntax ([line (syntax-line stx)])
       (syntax (test/blame line who (λ () get))))]))

(define (test/blame line who get)
  ;(printf "testing ~s\n" line)
  (set! tests (+ tests 1))
  (let ([got (with-handlers ([exn? values])
               (get))])
    (cond
      [(and (exn? got)
            (regexp-match #rx"broke the contract" (exn-message got)))
       (unless (regexp-match (regexp (format "~a broke the contract" who))
                             (exn-message got))
         (fprintf (current-error-port)
                  "FAILED: expected blame to go to ~s got ~s, line ~a\n" 
                  who
                  (exn-message got)
                  line))]
      [else
       (fprintf (current-error-port)
                "FAILED: expected blame-exn got ~s, line ~a\n" 
                got line)
       (when (exn? got)
         ((error-display-handler) (exn-message got) got))])))
