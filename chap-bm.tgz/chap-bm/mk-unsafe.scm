(import (rnrs)
        (larceny compiler))

(compiler-switches 'fast-unsafe)
(compile-file "bubble.scm")
(compile-file "struct-bm.scm")
