#lang racket/base
(require racket/class
         racket/draw
         plot
         slideshow/pict
         (prefix-in file: file/convertible))

'make
(define p 
  (begin ; time 
   (plot3d-pict (isosurfaces3d (compose abs max) -1 1 -1 1 -1 1))))
'to-png
(define bstr
  (time (file:convert p 'png-bytes)))

#|
(define rdc (new record-dc% [width (pict-width p)] [height (pict-height p)]))
(send rdc set-smoothing 'aligned)
'record
(time (draw-pict p rdc 0 0))
(define d (send rdc get-recorded-datum))
'record->proc
(define proc (time (recorded-datum->procedure d)))

(define bm (make-bitmap (pict-width p) (pict-height p)))
(define bdc (make-object bitmap-dc% bm))
'apply-proc
(time (proc bdc))

(send bdc erase)
'get-proc
(define proc2 (time (send rdc get-recorded-procedure)))
'apply-direct-proc
(time (proc2 bdc))

(with-output-to-file "/tmp/plot.png" 
  #:exists 'truncate
  (lambda () (write-bytes bstr)))


|#

(require ffi/unsafe)
(list (get-ffi-obj 'proc_makes #f _int)
      (get-ffi-obj 'proc_apps #f _int)
      (get-ffi-obj 'struct_apps #f _int))

