; code to illustrate the capabilities of the SAPI interface

; load the extension, will "require" do this?
(load-extension "Release/SchemeSpeak.dll")

; add some voices
(add-voice "Mary")
(add-voice "Mike")

; Let Mary say something
(speak "Mary" "This is a test of this speech system.")
; Mike will wait for Mary to finish
(speak "Mike" "This is an interrupted speech by Mike.")

; the following is supposed to interrupt Mike, of course that is very
; timing dependent. I just wanted to illustrate that it works.
; It simply waits for about 3 seconds and then calls stop-speech.
; I cons up a list of the results of now-speaking as I wait

(do ((i 0 (+ i 1))
     (lst () (cons (now-speaking) lst))) 
  ((= i 16) (cons (cons 'lastcomplete (stop-speech)) lst))
  (sleep 0.2))

; introduce ourselves
(speak "Mary" "This is Mary.")
(speak "Mike" "And I'm Mike!")

; add some more voices
; but wait until all is quiet
(do () ((not (speaking?))))
(add-voice "Mary in Hall")
(add-voice "Mike in Hall")
(add-voice "Freddy")
(add-voice "Sam")
(speak "Mary in Hall" "This is Mary in a big hall.")
(speak "Mike in Hall" "Mike can speak from the hall also.")
(speak "Freddy" "I'm Freddy, a little kid.")
(speak "Sam" "I'm Sam, a really big guy.")

; now we can try to show off some tricks with our voices
(speak "Mary" "\\Pit=100\\ Mary with a lower voice.")
(speak "Mike" "\\Pit=200\\ \\Spd=250\\ Mike can get excited!")

