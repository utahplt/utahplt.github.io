// MS Speech API Interface for DrScheme
// Gary Bishop
// 22 December 1999

/* I've separated the SAPI specific code from the Scheme specific code to make it clear
   what does what. They could, of course, be combined into smaller and simpler code.
*/

#include <windows.h>
#include <stdio.h>
#include <initguid.h>
#include <spchwrap.h>
#include <escheme.h>

/* helper for widening strings. Man I hate having to do this! */
static WCHAR* widen(const char* str)
{
	int str_len = strlen(str);
	WCHAR *wstr = new WCHAR[str_len+2];
	if(wstr == 0)
		return 0;
	MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, str, -1, wstr, str_len+2);
	return wstr;
}

/* this object lets me know when actions have happened in the TTS engine */

/* I'm having to fool with these variables to get an indication of what speech (if any)
   was interrupted. They tell you, with SpeakID, when it starts speaking a buffer, but they
   only tell you when they are done with *all* buffers. So I have to guess about interruptions.
   */

static int g_nextSequence;		// the sequence number used on the speech as it is queued
static int g_currentSequence;	// the sequence for the text currently being spoken
static int g_lastSequence;		// the last buffer that I think was completely spoken
static int g_lastBookMark;		// the last BookMark I saw

class CQueueNotify : public CSTTTSQueueNotifySink {
public:
   STDMETHOD (BookMark)(DWORD);
   STDMETHOD (SpeakID)(DWORD);
   STDMETHOD (Stop)();
} g_QueueNotify;

STDMETHODIMP CQueueNotify::BookMark(DWORD bm)
{
	g_lastBookMark = bm; // just save it for reporting if asked
   return NOERROR;
}

STDMETHODIMP CQueueNotify::SpeakID(DWORD seq)
{
	g_lastSequence = g_currentSequence; // save the one that is now complete (I think)
	g_currentSequence = seq; // make this one current
   return NOERROR;
}

STDMETHODIMP CQueueNotify::Stop()
{
	g_lastSequence = g_currentSequence; // when all done, note that the current one is complete
	return NOERROR;
}

// this is the TTS queue object
static PCSTTTSQueue gTTSQueue = 0;

// so I can report back what went wrong
static char* error_message = "No Error";

static int initSpeech()
{
    CoInitialize(NULL);
	
	gTTSQueue = new CSTTTSQueue;
	if(gTTSQueue == 0) {
		error_message = "Out of Memory";
		return 0;
	}

	HRESULT hRes = gTTSQueue->Init();
	if(FAILED(hRes)) {
		error_message = "CSTTTSQueue::Init failed";
		return 0;
	}

	hRes = gTTSQueue->Register((PISTTTSQUEUENOTIFYSINK)&g_QueueNotify);
	if(FAILED(hRes)) {
		error_message = "CSTTSQueue::Register failed";
		return 0;
	}

	return 1;
}

// I'd need the ability to unload the extension to use this
static void wrapSpeech()
{
	delete gTTSQueue;
	CoUninitialize ();
}

// add a speech engine to the queue object. Do this, at least once, before attempting to
// speak any text. The first voice will be the "default" which is used if the name you
// specify later in the speak call doesn't match any of the voices you have added
// You can add a voice only when no voice is speaking
static int addVoice(const char* name)
{
	// man do I hate wide characters! I have to do this stupid conversion because the
	// interface demands wchars

	// set up the mode info structure to select the engine with the specifide name
	TTSMODEINFOW mode;
	ZeroMemory(&mode, sizeof(mode));
	MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, 
		name, -1, 
		mode.szModeName, sizeof(mode.szModeName)/sizeof(WCHAR));

	// create the engine object
	CTTSMode* engine = new CTTSMode;
	if(engine == 0) {
		error_message = "Out of memory";
		return 0;
	}

	// attach to the specified engine
	HRESULT hRes = engine->Init(&mode);
	if(FAILED(hRes)) {
		error_message = "CTTSMode::Init failed";
		return 0;
	}

	// add the engine to the queue object
	hRes = gTTSQueue->TTSAdd(mode.szModeName, engine);
	if(FAILED(hRes)) {
		error_message = "CSTTTSQueue::TTSAdd failed";
		return 0;
	}

	return 1;
}

// speak some text. This would be trivial if not for all the buffer hacking
static int doSpeech(const char* name, const char* text)
{
	// yuck I hate these wide character conversions!
	WCHAR *wname = widen(name);
	WCHAR *wtext = widen(text);

	// now that we've converted the string to wide characters we can queue it for speaking
	g_nextSequence++;
    HRESULT hRes = gTTSQueue->Speak(wtext, wname, g_nextSequence);

	// clean up the buffers 
	delete [] wname;
	delete [] wtext;

	if(FAILED(hRes)) {
		error_message = "CSTTTSQueue::Speak failed";
		return 0;
	}

	return 1;
}

// stop the speech engine and clear the queue
static int stopSpeech()
{
	HRESULT hRes = gTTSQueue->AudioReset();

	if(FAILED(hRes)) {
		error_message = "CSTTTSQueue::AudioReset failed";
		return 0;
	}

	return 1;
}

// determine if it is still talking
static int isSpeaking()
{
	return gTTSQueue->IsSpeaking();
}

// set the speed, remember to previous speed
static int setSpeed(const char* name, int nspeed)
{
	// first widen the name
	WCHAR *wname = widen(name);

	PCTTSMode tts = gTTSQueue->TTSGet(wname);
	if(tts == NULL) {
		return -1;
	}

	int ospeed = tts->SpeedGet();

	if(nspeed >= 0) {
		tts->SpeedSet(nspeed);
	}

	return ospeed;
}
	
// set the pitch, remember to previous pitch
static int setPitch(const char* name, int npitch)
{
	// first widen the name
	WCHAR *wname = widen(name);

	PCTTSMode tts = gTTSQueue->TTSGet(wname);
	if(tts == NULL) {
		return -1;
	}

	int opitch = tts->PitchGet();

	if(npitch >= 0) {
		tts->PitchSet(npitch);
	}

	return opitch;
}
	
// set the volume, remember to previous volume
static int setVolume(const char* name, int nvolume)
{
	// first widen the name
	WCHAR *wname = widen(name);

	PCTTSMode tts = gTTSQueue->TTSGet(wname);
	if(tts == NULL) {
		return -1;
	}

	int ovolume = tts->VolumeGet() & 0xffff; // just get the lower bits we're doing mono

	if(nvolume >= 0) {
		tts->VolumeSet(nvolume);
	}

	return ovolume;
}
	
/* the SAPI functions are above, the Scheme functions are below */

static Scheme_Object *sch_speak(int argc, Scheme_Object **argv)
{
	Scheme_Object *str = argv[1];
	Scheme_Object *voice = argv[0];

	// check argument types
	if(!SCHEME_STRINGP(str))
		scheme_wrong_type("speak", "string", 1, argc, argv);
	if(!SCHEME_STRINGP(voice))
		scheme_wrong_type("speak", "string", 0, argc, argv);

	// do the deed
	int r = doSpeech(SCHEME_STR_VAL(voice), SCHEME_STR_VAL(str));

	return r==0 ? scheme_false : scheme_make_integer(g_nextSequence);
}

static Scheme_Object *sch_add_voice(int argc, Scheme_Object **argv)
{
	Scheme_Object *voice = argv[0];

	// check argument type
	if(!SCHEME_STRINGP(voice))
		scheme_wrong_type("add-voice", "string", 0, argc, argv);

	// do the deed
	int r = addVoice(SCHEME_STR_VAL(voice));

	return r==0 ? scheme_false : scheme_true;
}

static Scheme_Object *sch_stop_speech(int argc, Scheme_Object **argv)
{
	if(isSpeaking()) {
		// set backward to the last we knew was successfully spoken
		g_currentSequence = g_lastSequence;
		stopSpeech();
	}
	Scheme_Object *res = scheme_make_integer(g_currentSequence);
	return res;
}

static Scheme_Object *sch_speech_error_message(int argc, Scheme_Object **argv)
{
	return scheme_make_string(error_message);
}

static Scheme_Object *sch_is_speaking(int argc, Scheme_Object **argv)
{
	int r = isSpeaking();
	return r==0 ? scheme_false : scheme_true;
}

static Scheme_Object *sch_speaking_sequence(int argc, Scheme_Object **argv)
{
	if(isSpeaking())
		return scheme_make_integer(g_currentSequence);
	else
		return scheme_false;
}

static Scheme_Object *sch_finished_speaking(int argc, Scheme_Object **argv)
{
	return scheme_make_integer(g_lastSequence);
}

static Scheme_Object *sch_set_speed(int argc, Scheme_Object **argv)
{
	Scheme_Object* name = argv[0];
	if(!SCHEME_STRINGP(name))
		scheme_wrong_type("speech-speed", "string", 0, argc, argv);

	int nval = -1;
	if(argc == 2) {
		Scheme_Object* arg = argv[1];
		if(!SCHEME_INTP(arg))
			scheme_wrong_type("speech-speed", "integer", 1, argc, argv);
		nval = SCHEME_INT_VAL(arg);
	}

	int oval = setSpeed(SCHEME_STR_VAL(name), nval);

	return scheme_make_integer(oval);
}

static Scheme_Object *sch_set_pitch(int argc, Scheme_Object **argv)
{
	Scheme_Object* name = argv[0];
	if(!SCHEME_STRINGP(name))
		scheme_wrong_type("speech-pitch", "string", 0, argc, argv);

	int nval = -1;
	if(argc == 2) {
		Scheme_Object* arg = argv[1];
		if(!SCHEME_INTP(arg))
			scheme_wrong_type("speech-pitch", "integer", 1, argc, argv);
		nval = SCHEME_INT_VAL(arg);
	}

	int oval = setPitch(SCHEME_STR_VAL(name), nval);

	return scheme_make_integer(oval);
}

static Scheme_Object *sch_set_volume(int argc, Scheme_Object **argv)
{
	Scheme_Object* name = argv[0];
	if(!SCHEME_STRINGP(name))
		scheme_wrong_type("speech-volume", "string", 0, argc, argv);

	int nval = -1;
	if(argc == 2) {
		Scheme_Object* arg = argv[1];
		if(!SCHEME_INTP(arg))
			scheme_wrong_type("speech-volume", "integer", 1, argc, argv);
		nval = SCHEME_INT_VAL(arg);
	}

	int oval = setVolume(SCHEME_STR_VAL(name), nval);

	return scheme_make_integer(oval);
}


Scheme_Object *scheme_reload(Scheme_Env *env)
{
	/* Package the C implementation of speak into a Scheme procedure value: */
	Scheme_Object *proc;
	proc = scheme_make_prim_w_arity(sch_speak, "speak", 2, 2);
	scheme_add_global("speak", proc, env);
	
	proc = scheme_make_prim_w_arity(sch_stop_speech, "stop-speech", 0, 0);
	scheme_add_global("stop-speech", proc, env);
	
	proc = scheme_make_prim_w_arity(sch_add_voice, "add-voice", 1, 1);
	scheme_add_global("add-voice", proc, env);

	proc = scheme_make_prim_w_arity(sch_speech_error_message, "speech-error-message", 0, 0);
	scheme_add_global("speech-error-message", proc, env);

	proc = scheme_make_prim_w_arity(sch_is_speaking, "speaking?", 0, 0);
	scheme_add_global("speaking?", proc, env);

	proc = scheme_make_prim_w_arity(sch_speaking_sequence, "now-speaking", 0, 0);
	scheme_add_global("now-speaking", proc, env);

	proc = scheme_make_prim_w_arity(sch_finished_speaking, "last-spoken", 0, 0);
	scheme_add_global("last-spoken", proc, env);

	proc = scheme_make_prim_w_arity(sch_set_speed, "speech-speed", 1, 2);
	scheme_add_global("speech-speed", proc, env);

	proc = scheme_make_prim_w_arity(sch_set_pitch, "speech-pitch", 1, 2);
	scheme_add_global("speech-pitch", proc, env);

	proc = scheme_make_prim_w_arity(sch_set_volume, "speech-volume", 1, 2);
	scheme_add_global("speech-volume", proc, env);

	return scheme_true;
}

Scheme_Object *scheme_initialize(Scheme_Env *env)
{
	// initialize only on the first load
	int r = initSpeech();
	if(r) {
		return scheme_reload(env);
	}
	return scheme_false;
}


