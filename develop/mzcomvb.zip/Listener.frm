VERSION 5.00
Begin VB.Form frmListener 
   Caption         =   "MzScheme Listener"
   ClientHeight    =   7185
   ClientLeft      =   60
   ClientTop       =   630
   ClientWidth     =   10560
   LinkTopic       =   "Form1"
   ScaleHeight     =   7185
   ScaleWidth      =   10560
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton cmdEval 
      Caption         =   "&Eval"
      Height          =   375
      Left            =   4800
      TabIndex        =   0
      TabStop         =   0   'False
      Top             =   6720
      Width           =   975
   End
   Begin VB.TextBox txtOut 
      Height          =   6135
      Left            =   5400
      MultiLine       =   -1  'True
      ScrollBars      =   2  'Vertical
      TabIndex        =   7
      TabStop         =   0   'False
      Top             =   480
      Width           =   5055
   End
   Begin VB.CommandButton cmdExit 
      Caption         =   "E&xit"
      Height          =   375
      Left            =   9720
      TabIndex        =   2
      Top             =   6720
      Width           =   735
   End
   Begin VB.CommandButton cmdClearTranscript 
      Caption         =   "Clear Transcript"
      Height          =   255
      Left            =   7260
      TabIndex        =   4
      Top             =   6720
      Width           =   1335
   End
   Begin VB.CommandButton cmdClearEditor 
      Caption         =   "Clear Editor"
      Height          =   255
      Left            =   1980
      TabIndex        =   3
      Top             =   6720
      Width           =   1335
   End
   Begin VB.TextBox txtIn 
      Height          =   6135
      Left            =   120
      MultiLine       =   -1  'True
      ScrollBars      =   2  'Vertical
      TabIndex        =   1
      TabStop         =   0   'False
      Top             =   480
      Width           =   5055
   End
   Begin VB.Label Label2 
      AutoSize        =   -1  'True
      Caption         =   "Editor"
      Height          =   195
      Left            =   120
      TabIndex        =   6
      Top             =   240
      Width           =   405
   End
   Begin VB.Label Label1 
      AutoSize        =   -1  'True
      Caption         =   "Transcript"
      Height          =   195
      Left            =   5400
      TabIndex        =   5
      Top             =   240
      Width           =   705
   End
   Begin VB.Menu mnuScheme 
      Caption         =   "&Scheme"
      Begin VB.Menu mnuLoad 
         Caption         =   "&Load"
      End
      Begin VB.Menu mnuReset 
         Caption         =   "&Reset"
      End
      Begin VB.Menu mnuAboutMzCOM 
         Caption         =   "About &MzCOM"
      End
      Begin VB.Menu mnuAboutScheme 
         Caption         =   "&About Scheme"
      End
   End
End
Attribute VB_Name = "frmListener"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'VB 6.0 Test code for MzCOM
'Copyright (c) Apr, May 2000 by Andre van Meulebrouck (vanmeule@acm.org)
'Expressions in txtIn.Text must be highlighted (selected), then press "Eval" button.
'MzCOM Type library must be registered in Project -> References
Private m_objMzCOM As MzObj
Private WithEvents MzObjEvent As MzObj
Attribute MzObjEvent.VB_VarHelpID = -1
Private Sub cmdClearEditor_Click()
    txtIn.Text = ""
    txtIn.SetFocus
End Sub

Private Sub cmdClearTranscript_Click()
    txtOut.Text = ""
End Sub
Private Sub cmdEval_Click()
    Screen.MousePointer = vbHourglass
    Dim strOut As String
    Dim blnSuccess As Boolean
    blnSuccess = EvalSexprs(m_objMzCOM, txtIn.SelText, strOut)
    If blnSuccess Then
        'evaluation success
        Call TranscriptNewline
        txtOut.Text = txtOut.Text & strOut
    Else
        'evaluation failure
    End If
    Screen.MousePointer = vbNormal
End Sub
Private Function EvalSexprs(schObj As MzObj, strIn As String, strOut As String) As Boolean
    EvalSexprs = False
    On Error GoTo errExit
    strOut = schObj.Eval(strIn)
    EvalSexprs = True
    Exit Function
errExit:
    strOut = Err.description
End Function
Private Sub cmdExit_Click()
  Unload Me
End Sub

Private Sub DirLoadName_Change()
    filLoadName.Path = DirLoadName.Path
End Sub

Private Sub DriLoadName_Change()
    DirLoadName.Path = DriLoadName
End Sub

Private Sub Form_Load()
   Set m_objMzCOM = New MzObj
   Set MzObjEvent = m_objMzCOM
End Sub
Private Sub TranscriptNewline()
  If txtOut.Text <> "" Then
      txtOut.Text = txtOut.Text & vbCrLf
  End If
End Sub
Private Function strLISPifyFileName(ByVal str As String) As String
    Dim intLoc As Integer
    intLoc = InStr(str, "\")
    If intLoc = 0 Then
        strLISPifyFileName = str
    Else
        strLISPifyFileName = Mid$(str, 1, intLoc) & "\" & strLISPifyFileName(Mid$(str, intLoc + 1))
    End If
End Function
Private Sub mnuAboutMzCOM_Click()
    m_objMzCOM.About
End Sub

Private Sub mnuAboutScheme_Click()
    frmAboutScheme.Show vbModal
End Sub

Private Sub mnuLoad_Click()
    On Error GoTo errExit
    frmDirBox.Show vbModal
    If frmDirBox.OkayPressed Then
        Dim strFileName As String
        Dim str As String
        strFileName = strLISPifyFileName(frmDirBox.FileName)
        str = "(load """ & strFileName & """)"
        txtIn.Text = txtIn.Text & str & vbNewLine
        'now that we've built the string, evaluation the load
        Screen.MousePointer = vbHourglass
        Dim strOut As String
        Dim blnSuccess As Boolean
        blnSuccess = EvalSexprs(m_objMzCOM, str, strOut)
        If blnSuccess Then
            'evaluation success
            Call TranscriptNewline
            txtOut.Text = txtOut.Text & strOut
        Else
            'evaluation failure
        End If
        Screen.MousePointer = vbNormal
    End If
    Exit Sub
errExit:
    Call TranscriptNewline
    txtOut.Text = txtOut.Text & strOut
End Sub

Private Sub mnuReset_Click()
    m_objMzCOM.Reset
End Sub

Private Sub MzObjEvent_SchemeError(ByVal description As String)
  Call TranscriptNewline
  txtOut.Text = txtOut.Text & description
End Sub
