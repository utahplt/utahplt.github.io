VERSION 5.00
Begin VB.Form frmDirBox 
   Caption         =   "Filename Entry"
   ClientHeight    =   6600
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   7575
   LinkTopic       =   "Form1"
   ScaleHeight     =   6600
   ScaleWidth      =   7575
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton cmdCancel 
      Caption         =   "Cancel"
      Height          =   495
      Left            =   6600
      TabIndex        =   4
      Top             =   6000
      Width           =   855
   End
   Begin VB.CommandButton cmdOk 
      Caption         =   "OK"
      Height          =   495
      Left            =   5640
      TabIndex        =   3
      Top             =   6000
      Width           =   855
   End
   Begin VB.FileListBox filLoadName 
      Height          =   2430
      Left            =   120
      TabIndex        =   2
      Top             =   3480
      Width           =   7335
   End
   Begin VB.DirListBox DirLoadName 
      Height          =   2790
      Left            =   120
      TabIndex        =   1
      Top             =   600
      Width           =   7335
   End
   Begin VB.DriveListBox DriLoadName 
      Height          =   315
      Left            =   120
      TabIndex        =   0
      Top             =   240
      Width           =   7335
   End
End
Attribute VB_Name = "frmDirBox"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Private m_strFileName As String
Private m_blnOkay As Boolean
Public Property Get FileName() As String
    FileName = m_strFileName
End Property
Public Property Get OkayPressed() As Boolean
    OkayPressed = m_blnOkay
End Property
Private Sub cmdCancel_Click()
    m_blnOkay = False
    Me.Hide
End Sub
Private Sub OKclick()
    m_blnOkay = True
    m_strFileName = DirLoadName.Path & "\" & filLoadName.FileName
    Me.Hide
End Sub
Private Sub cmdOK_Click()
    Call OKclick
End Sub

Private Sub DirLoadName_Change()
    filLoadName.Path = DirLoadName.Path
End Sub

Private Sub DriLoadName_Change()
    DirLoadName.Path = DriLoadName.Drive
End Sub

Private Sub Form_Load()
    m_strFileName = ""
End Sub

