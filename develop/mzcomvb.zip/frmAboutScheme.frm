VERSION 5.00
Begin VB.Form frmAboutScheme 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "About Scheme"
   ClientHeight    =   3885
   ClientLeft      =   105
   ClientTop       =   675
   ClientWidth     =   7215
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   3885
   ScaleWidth      =   7215
   StartUpPosition =   2  'CenterScreen
   Begin VB.TextBox txt 
      Height          =   2775
      Left            =   240
      Locked          =   -1  'True
      MultiLine       =   -1  'True
      TabIndex        =   1
      Top             =   240
      Width           =   6735
   End
   Begin VB.CommandButton cmdOK 
      Caption         =   "OK"
      Height          =   495
      Left            =   6480
      TabIndex        =   0
      Top             =   3240
      Width           =   495
   End
End
Attribute VB_Name = "frmAboutScheme"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub cmdOK_Click()
    Unload Me
End Sub

Private Sub Form_Load()
    txt.Text = "MzScheme is based on R5RS (Revised^5 Report on Scheme)." & vbNewLine
    txt.Text = txt.Text & vbNewLine & _
        "R5RS reference:  http://www.cs.rice.edu/CS/PLT/packages/doc/r5rs/"
End Sub

Private Sub Text1_Change()

End Sub
