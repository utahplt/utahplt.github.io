To install the Visual Basic 6.0 test suite for MzCOM do the following.

1)  Put all the files in a directory of your choice.
2)  Double click on mzcom.exe (which is an ActiveX out-of-process server) to register it.
3)  Run Visual Basic 6.0 and open the existing project (in the directory you placed it):  
    MzSchemeInVB.
4)  Go to Project -> References, and make sure MzCOM 1.0 Type Library is checked and that 
    the pathname for mzcom.exe references the pathname used in step 1.
5)  You should now be able to run the Visual Basic Test Suite.  Type in expressions, 
    highlight them, then click the Eval button.

Here is the code for the factorial function, which can be used as a test:

(define fact (lambda (n) (if (zero? n) 1 (* n (fact (- n 1))))))

Invoke the factorial function by calling it with an argument:

(fact 5) 

should return 120.

(fact 700) 

will return a large bignum.

* * *

MzScheme is based on R5RS (Revised^5 Report on Scheme).

For documentation on MzScheme see:

http://www.cs.rice.edu/CS/PLT/packages/doc/r5rs/