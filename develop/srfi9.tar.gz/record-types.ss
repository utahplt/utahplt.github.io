(define-signature libmike:record-type^
  (define-record-type))
