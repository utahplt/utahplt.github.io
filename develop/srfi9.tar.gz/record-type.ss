(begin-elaboration-time 
 (require-library "invoke.ss")
 (require-relative-library "record-types.ss"))

(define-values/invoke-unit/sig libmike:record-type^
  (require-relative-library "record-typer.ss") #f)

(define-macro define-record-type define-record-type)
