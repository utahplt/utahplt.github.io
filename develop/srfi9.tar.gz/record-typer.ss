(begin-elaboration-time
 (require-relative-library "record-types.ss"))

(unit/sig libmike:record-type^
    (import)
  (include "record-type.scm"))
