;; SRFI 9

(define (define-record-type type constructor-template predicate
                            . field-descriptions)
    (let* ((real-constructor (gensym))
           ;; normalize away Richard's leading :
           (type-name (symbol->string type))
           (type (if (char=? (string-ref type-name 0) #\:)
                     (string->symbol (substring type-name 1 (string-length type-name)))
                     type)))
      `(#%begin
	,(let loop ((rest field-descriptions)
		    (reverse-names '()))
	   (cond
             ((null? rest)
	     `(#%define-values
	       ,(append `(,(string->symbol (string-append "struct:"
							  (symbol->string type)))
			  ,real-constructor ,predicate)
			(reverse reverse-names))
               (#%struct ,type ,(map car field-descriptions))))
	    ((null? (cddr (car rest)))
	     (loop (cdr rest)
		   (cons (gensym)
			 (cons (cadr (car rest))
			       reverse-names))))
	    (else
	     (loop (cdr rest)
		   (cons (caddr (car rest))
			 (cons (cadr (car rest))
			       reverse-names))))))
	(#%define ,constructor-template
		  ,(record-constructor-call real-constructor
					    (cdr constructor-template)
					    (map car field-descriptions))))))

(define (record-constructor-call real-constructor constructor-tags field-tags)
    (let loop ((constructor-tags constructor-tags)
	       (field-tags field-tags)
	       (reverse-result '()))
      (cond
       ((and (null? constructor-tags)
	     (null? field-tags))
	`(, real-constructor . ,(reverse reverse-result)))
       ((null? field-tags)
	(raise-syntax-error 'define-record-type
			    "invalid constructor syntax"
			    constructor-tags))
       ((and (not (null? constructor-tags))
	     (eq? (car constructor-tags)
		  (car field-tags)))
	(loop (cdr constructor-tags)
	      (cdr field-tags)
	      (cons (car constructor-tags) reverse-result)))
       (else
	(loop constructor-tags
	      (cdr field-tags)
	      (cons '(#%void) reverse-result))))))
