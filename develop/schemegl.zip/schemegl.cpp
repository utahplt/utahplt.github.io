/*
 * Scheme GL version 1.0
 * By Olivier ORABONA
 * -----------------------------------------------------
 * TODO list :
 * - Find a way to load image data inside DrScheme and make it
 *   work with OpenGL here.
 * Changelog:
 * - N/A
 * Done List:
 * - OpenGL up to v1.1 partially implemented.
 */

#include <escheme.h>

#ifdef _WIN32
#	include <windows.h>
#else
#   define stricmp strcasecmp
#   define strnicmp strncasecmp
#endif
#include <GL/gl.h>

#ifndef GL_VERSION_1_1
#	error "You must have at least an OpenGL v1.1 implementation!"
#endif

#include "gl-protos.h"
#include "gl-prims.h"
#include "gl-enums.h"

/*
 * Some global defs & declarations
 */

#define SCMGL_VERSION "1.0"
static char* gl_prefix = "gl_";

/*
 * SchemeGL specific primitives
 */
static Scheme_Object* scm_sglInit(void* p, int argc, Scheme_Object** argv) {
	if(SCHEME_SYMBOLP(argv[0]))
		gl_prefix = SCHEME_SYM_VAL(argv[0]);

	return scheme_void;
}

static long scmgl_GetEnumFromSymbol(Scheme_Object* e_num) {
	if(!SCHEME_SYMBOLP(e_num))
		return GL_INVALID_ENUM;

	char* symbol = SCHEME_SYM_VAL(e_num);

	int plen = strlen(gl_prefix);

	if(strnicmp(symbol,gl_prefix,plen))
		return GL_INVALID_ENUM;

	int slen = strlen(symbol);
	
	int i = 0;
	while(scmgl_enums[i].name!=NULL && stricmp(symbol+plen,scmgl_enums[i].name))
		i++;
	
	if(scmgl_enums[i].name == NULL)
		return GL_INVALID_ENUM;
	return scmgl_enums[i].value;
}

/*
 * "Raw" OpenGL implementation
 */
static Scheme_Object* scm_glGetString(void* p, int argc, Scheme_Object** argv) {
	GLenum e_val = (GLenum) scmgl_GetEnumFromSymbol(argv[0]);
	if(e_val == GL_INVALID_ENUM)
		scheme_signal_error("Wrong Enum %S !",argv[0]);
	return scheme_make_string((char*)glGetString(e_val));
}

static Scheme_Object* scm_glClear(void *p, int argc, Scheme_Object** argv) {
	if(!SCHEME_PAIRP(argv[0]))
		scheme_wrong_type((char*)p, "list",0,argc,argv);

	Scheme_Object* tmp = argv[0];
	GLbitfield bf = 0;
	GLbitfield e_val;

	while(SCHEME_PAIRP(tmp)) {
		e_val = (GLbitfield) scmgl_GetEnumFromSymbol(SCHEME_CAR(tmp));
		if(e_val == GL_INVALID_ENUM) {
			scheme_signal_error("Bad input : %S", SCHEME_CAR(tmp));
		}
		bf |= e_val;
		tmp = SCHEME_CDR(tmp);
	}
	
	glClear(bf);
	return scheme_void;
}

static Scheme_Object* scm_glClearColor(void* p, int argc, Scheme_Object** argv) {
	GLclampf t[4];
	for(int i=0; i < 4; i++) {
		if(SCHEME_FLOATP(argv[i]))
			t[i] = (GLclampf) scheme_real_to_double(argv[i]);
		else
			scheme_wrong_type((char*)p, "float", i, argc, argv);
	}
	glClearColor(t[0], t[1], t[2], t[3]);
	return scheme_void;
}

static Scheme_Object* scm_glFlush(void* p, int argc, Scheme_Object** argv) {
	glFlush();
	return scheme_void;
}

static Scheme_Object* scm_glFinish(void* p, int argc, Scheme_Object** argv) {
	glFinish();
	return scheme_void;
}

static Scheme_Object* scm_glBegin(void* p, int argc, Scheme_Object** argv) {
	if(SCHEME_SYMBOLP(argv[0])) {
		GLenum e_val = (GLenum) scmgl_GetEnumFromSymbol(argv[0]);
		if(e_val == GL_INVALID_ENUM)
			scheme_signal_error("Bad input : %S", argv[0]);
		glBegin(e_val);
	} else
		scheme_wrong_type((char*)p, "enum", 0, argc, argv);
	return scheme_void;
}

static Scheme_Object* scm_glEnd(void* p, int argc, Scheme_Object** argv) {
	glEnd();
	return scheme_void;
}

static Scheme_Object* scm_glVertex(void* p, int argc, Scheme_Object** argv) {
	/*
	 * Since there is no simple way to use vectors, There will be only values.
	 */
	
	GLfloat t[4];

	for(int i = 0; i < argc; i++) {
		if(SCHEME_FLOATP(argv[i]))
			t[i] = (GLfloat) scheme_real_to_double(argv[i]);
		else if(SCHEME_INTP(argv[i]))
			t[i] = (GLfloat) SCHEME_INT_VAL(argv[i]);
		else
			scheme_wrong_type((char*)p, "float", i, argc, argv);
	}

	switch(argc) {
	case 2:
		{
			glVertex2fv(t);
			break;
		}
	case 3:
		{
			glVertex3fv(t);
			break;
		}
	case 4:
		{
			glVertex4fv(t);
			break;
		}
	default:
		{
			scheme_signal_error("Hmmm we should never had landed here.");
			break;
		}
	}

	return scheme_void;
}

static Scheme_Object* scm_glColor(void* p, int argc, Scheme_Object** argv) {
	/*
	 * Still no support for scheme vectors. See scm_glVertex.
	 */

	GLfloat t[4];

	for(int i = 0; i < argc; i++) {
		if(SCHEME_FLOATP(argv[i]))
			t[i] = (GLfloat) scheme_real_to_double(argv[i]);
		else
			scheme_wrong_type((char*)p, "float", i, argc, argv);
	}

	switch(argc) {
	case 3:
		{
			glColor3fv(t);
			break;
		}
	case 4:
		{
			glColor4fv(t);
			break;
		}
	default:
		{
			scheme_signal_error("Hmmm we should never had landed here.");
			break;
		}
	}

	return scheme_void;
}

static Scheme_Object* scm_glMatrixMode(void* p, int argc, Scheme_Object** argv) {
	if(SCHEME_SYMBOLP(argv[0])) {
		GLenum e_val = (GLenum) scmgl_GetEnumFromSymbol(argv[0]);
		if(e_val == GL_INVALID_ENUM)
			scheme_signal_error("Bad input : %S", argv[0]);
		glMatrixMode(e_val);
	} else
		scheme_wrong_type((char*)p, "enum", 0, argc, argv);
	return scheme_void;
}

static Scheme_Object* scm_glLoadIdentity(void* p, int argc, Scheme_Object** argv) {
	glLoadIdentity();
	return scheme_void;
}

static Scheme_Object* scm_glOrtho(void* p, int argc, Scheme_Object** argv) {
	GLdouble t[6];

	for(int i = 0; i < 6; i++) {
		if(SCHEME_FLOATP(argv[i]))
			t[i] = scheme_real_to_double(argv[i]);
		else
			scheme_wrong_type((char*)p, "float", i, argc, argv);
	}

	glOrtho(t[0],t[1],t[2],t[3],t[4],t[5]);
	return scheme_void;
}

static Scheme_Object* scm_glNormal(void* p, int argc, Scheme_Object** argv) {
	GLdouble t[3];

	for(int i = 0; i < 3; i++) {
		if(SCHEME_FLOATP(argv[i]))
			t[i] = scheme_real_to_double(argv[i]);
		else if(SCHEME_INTP(argv[i]))
			t[i] = (GLdouble) SCHEME_INT_VAL(argv[i]);
		else
			scheme_wrong_type((char*)p, "float", i, argc, argv);
	}

	glNormal3f(t[0],t[1],t[2]);
	return scheme_void;
}

static Scheme_Object* scm_glShadeModel(void* p, int argc, Scheme_Object** argv) {
	if(SCHEME_SYMBOLP(argv[0])) {
		GLenum e_val = (GLenum) scmgl_GetEnumFromSymbol(argv[0]);
		if(e_val == GL_INVALID_ENUM)
			scheme_signal_error("Bad input : %S", argv[0]);
		glShadeModel(e_val);
	} else
		scheme_wrong_type((char*)p, "enum", 0, argc, argv);
	return scheme_void;
}

static Scheme_Object* scm_glViewport(void* p, int argc, Scheme_Object** argv) {
	GLint t1[2];
	GLsizei t2[2];
	for(int i = 0; i < 2; i++) {
		if(SCHEME_INTP(argv[i]))
			t1[i] = SCHEME_INT_VAL(argv[i]);
		else
			scheme_wrong_type((char*)p, "integer",i,argc,argv);
		if(SCHEME_INTP(argv[i+2]))
			t2[i] = SCHEME_INT_VAL(argv[i+2]);
		else
			scheme_wrong_type((char*)p, "integer",i+2,argc,argv);
	}
	glViewport(t1[0],t1[1],t2[0],t2[1]);
	return scheme_void;
}

static Scheme_Object* scm_glFrustum(void* p, int argc, Scheme_Object** argv) {
	GLdouble t[6];

	for(int i = 0; i < 6; i++) {
		if(SCHEME_FLOATP(argv[i]))
			t[i] = scheme_real_to_double(argv[i]);
		else if(SCHEME_INTP(argv[i]))
			t[i] = (GLdouble) SCHEME_INT_VAL(argv[i]);
		else
			scheme_wrong_type((char*)p, "float", i, argc, argv);
	}

	glFrustum(t[0],t[1],t[2],t[3],t[4],t[5]);
	return scheme_void;
}

static Scheme_Object* scm_glTranslate(void* p, int argc, Scheme_Object** argv) {
	GLdouble t[3];

	for(int i = 0; i < 3; i++) {
		if(SCHEME_FLOATP(argv[i]))
			t[i] = scheme_real_to_double(argv[i]);
		else
			scheme_wrong_type((char*)p, "float", i, argc, argv);
	}

	glTranslatef(t[0],t[1],t[2]);
	return scheme_void;
}

static Scheme_Object* scm_glEnable(void* p, int argc, Scheme_Object** argv) {
	GLenum e_val;

	if(SCHEME_SYMBOLP(argv[0])) {
		e_val = (GLenum) scmgl_GetEnumFromSymbol(argv[0]);
		if(e_val == GL_INVALID_ENUM)
			scheme_signal_error("Bad input : %S", argv[0]);
		glEnable(e_val);
	} else if(SCHEME_PAIRP(argv[0])) {
		Scheme_Object* tmp = argv[0];

		while(SCHEME_PAIRP(tmp)) {
			e_val = (GLenum) scmgl_GetEnumFromSymbol(SCHEME_CAR(tmp));
			if(e_val == GL_INVALID_ENUM)
				scheme_signal_error("Bad input : %S", SCHEME_CAR(tmp));
			glEnable(e_val);
			tmp = SCHEME_CDR(tmp);
		}
	} else
		scheme_wrong_type((char*)p, "list or symbol",0,argc,argv);
	
	return scheme_void;
}

static Scheme_Object* scm_glLight(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_SYMBOLP(argv[0]))
		scheme_wrong_type((char*)p, "symbol",0,argc,argv);
	if(!SCHEME_SYMBOLP(argv[1]))
		scheme_wrong_type((char*)p, "symbol",0,argc,argv);
	if(!SCHEME_PAIRP(argv[2]))
		scheme_wrong_type((char*)p, "list", 0, argc, argv);
	
	GLenum lnum = (GLenum) scmgl_GetEnumFromSymbol(argv[0]);
	GLenum pname = (GLenum) scmgl_GetEnumFromSymbol(argv[1]);
	GLfloat v[4];

	Scheme_Object* tmp = argv[2];

	int i = 0;

	while(SCHEME_PAIRP(tmp)) {
		v[i++] = (GLfloat) scheme_real_to_double(SCHEME_CAR(tmp));
		tmp = SCHEME_CDR(tmp);
	}

	glLightfv(lnum, pname, v);
	return scheme_void;
}

static Scheme_Object* scm_glNewList(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_INTP(argv[0]))
		scheme_wrong_type((char*)p, "positive integer", 0, argc, argv);
	if(!SCHEME_SYMBOLP(argv[1]))
		scheme_wrong_type((char*)p, "symbol", 1, argc, argv);
	
	GLenum e_val = (GLenum) scmgl_GetEnumFromSymbol(argv[1]);

	glNewList((GLuint) SCHEME_INT_VAL(argv[0]), e_val);
	return scheme_void;
}

static Scheme_Object* scm_glEndList(void* p, int argc, Scheme_Object** argv) {
	glEndList();
	return scheme_void;
}

static Scheme_Object* scm_glGenLists(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_INTP(argv[0]))
		scheme_wrong_type((char*)p, "integer", 0, argc, argv);

	GLuint ret = glGenLists((GLsizei) SCHEME_INT_VAL(argv[0]));

	return scheme_make_integer_value_from_unsigned(ret);
}

static Scheme_Object* scm_glMaterial(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_SYMBOLP(argv[0]))
		scheme_wrong_type((char*)p, "symbol", 0, argc, argv);
	if(!SCHEME_SYMBOLP(argv[1]))
		scheme_wrong_type((char*)p, "symbol", 0, argc, argv);
	if(!SCHEME_PAIRP(argv[2]))
		scheme_wrong_type((char*)p, "list", 0, argc, argv);

	Scheme_Object* tmp = argv[2];

	GLfloat v[4];

	int i = 0;

	while(SCHEME_PAIRP(tmp)) {
		v[i++] = (GLfloat) scheme_real_to_double(SCHEME_CAR(tmp));
		tmp = SCHEME_CDR(tmp);
	}

	GLenum face = (GLenum) scmgl_GetEnumFromSymbol(argv[0]);
	GLenum pname = (GLenum) scmgl_GetEnumFromSymbol(argv[1]);

	glMaterialfv(face, pname, v);
	return scheme_void;
}

static Scheme_Object* scm_glPushMatrix(void* p, int argc, Scheme_Object** argv) {
	glPushMatrix();
	return scheme_void;
}

static Scheme_Object* scm_glPopMatrix(void* p, int argc, Scheme_Object** argv) {
	glPopMatrix();
	return scheme_void;
}

static Scheme_Object* scm_glCallList(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_INTP(argv[0]))
		scheme_wrong_type((char*)p, "integer",0,argc,argv);

	glCallList((GLuint) SCHEME_INT_VAL(argv[0]));
	return scheme_void;
}

static Scheme_Object* scm_glRotate(void* p, int argc, Scheme_Object** argv) {
	GLdouble t[4];

	for(int i = 0; i < 4; i++) {
		if(SCHEME_FLOATP(argv[i]))
			t[i] = scheme_real_to_double(argv[i]);
		else
			scheme_wrong_type((char*)p, "double", i, argc, argv);
	}

	glRotated(t[0],t[1],t[2],t[3]);
	return scheme_void;
}

/* Last minute note :
 * This function will ignore the 2nd parameter : GLenum type
 * For clarity and simplicity, double is assumed to be the default type.
 * The prototype is the same :
 * (glVertexPointer 2 'foo 0 #(1.0 2.0 3.0 4.0))
 */
static Scheme_Object* scm_glVertexPointer(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_INTP(argv[0]))
		scheme_wrong_type((char*)p, "integer", 0, argc, argv);
	
	GLint size = SCHEME_INT_VAL(argv[0]);
	if(size < 2 || size > 4)
		scheme_signal_error("Only values 2, 3 or 4 allowed for size");

	if(!SCHEME_SYMBOLP(argv[1]))
		scheme_wrong_type((char*)p, "symbol", 1, argc, argv);

#ifdef BUGGY
	GLenum type = (GLenum) scmgl_GetEnumFromSymbol(argv[1]);
	if(type == GL_INVALID_ENUM)
		scheme_signal_error("Bad symbol : %S !", argv[1]);
#endif

	if(!SCHEME_INTP(argv[2]))
		scheme_wrong_type((char*)p, "integer", 2, argc, argv);

	/* Now working with vectors. I'll make changes backwards asap */
	if(!SCHEME_VECTORP(argv[3]))
		scheme_wrong_type((char*)p, "vector", 3, argc, argv);

	GLsizei stride = SCHEME_INT_VAL(argv[2]);

	Scheme_Object** vec_els = SCHEME_VEC_ELS(argv[3]);
	int vec_size = SCHEME_VEC_SIZE(argv[3]);

	/* We could add some other extra checks but this is not our primary
	 * goal here. Just do "as if". No further help yet.
	 */

	GLdouble* ptr = (GLdouble*) malloc(vec_size*sizeof(GLdouble));

	for(int i = 0; i < vec_size; i++) {
		if(!SCHEME_DBLP(vec_els[i]))
			scheme_wrong_type((char*)p, "float", 3, argc, argv);
		ptr[i] = SCHEME_DBL_VAL(vec_els[i]);
	}

	glVertexPointer(size,GL_DOUBLE,stride,ptr);
	free(ptr);
	return scheme_void;
}

/* Same comment as above */
static Scheme_Object* scm_glColorPointer(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_INTP(argv[0]))
		scheme_wrong_type((char*)p, "integer", 0, argc, argv);
	
	GLint size = SCHEME_INT_VAL(argv[0]);
	if(size < 2 || size > 4)
		scheme_signal_error("Only values 2, 3 or 4 allowed for size");

	if(!SCHEME_SYMBOLP(argv[1]))
		scheme_wrong_type((char*)p, "symbol", 1, argc, argv);

#ifdef BUGGY
	GLenum type = (GLenum) scmgl_GetEnumFromSymbol(argv[1]);
	if(type == GL_INVALID_ENUM)
		scheme_signal_error("Bad symbol : %S !", argv[1]);
#endif

	if(!SCHEME_INTP(argv[2]))
		scheme_wrong_type((char*)p, "integer", 2, argc, argv);

	/* Now working with vectors. I'll make changes backwards asap */
	if(!SCHEME_VECTORP(argv[3]))
		scheme_wrong_type((char*)p, "vector", 3, argc, argv);

	GLsizei stride = SCHEME_INT_VAL(argv[2]);

	Scheme_Object** vec_els = SCHEME_VEC_ELS(argv[3]);
	int vec_size = SCHEME_VEC_SIZE(argv[3]);

	/* We could add some other extra checks but this is not our primary
	 * goal here. Just do "as if". No further help yet.
	 */

	GLdouble* ptr = (GLdouble*) malloc(vec_size*sizeof(GLdouble));

	for(int i = 0; i < vec_size; i++) {
		if(!SCHEME_DBLP(vec_els[i]))
			scheme_wrong_type((char*)p, "double", 3, argc, argv);
		ptr[i] = SCHEME_DBL_VAL(vec_els[i]);
	}

	glColorPointer(size,GL_DOUBLE,stride,ptr);
	free(ptr);
	return scheme_void;
}
	
/* Same comment as scm_glVertexPointer */
static Scheme_Object* scm_glIndexPointer(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_SYMBOLP(argv[0]))
		scheme_wrong_type((char*)p, "symbol", 0, argc, argv);
	if(!SCHEME_INTP(argv[1]))
		scheme_wrong_type((char*)p, "integer", 1, argc, argv);
	if(!SCHEME_VECTORP(argv[2]))
		scheme_wrong_type((char*)p, "vector", 1, argc, argv);

	GLsizei stride = SCHEME_INT_VAL(argv[1]);

	Scheme_Object** vec_els = SCHEME_VEC_ELS(argv[2]);
	int vec_size = SCHEME_VEC_SIZE(argv[2]);

	GLdouble* ptr = (GLdouble*) malloc(vec_size*sizeof(GLdouble));

	for(int i = 0; i < vec_size; i++) {
		if(!SCHEME_DBLP(vec_els[i]))
			scheme_wrong_type((char*)p, "double", 2, argc, argv);
		ptr[i] = SCHEME_DBL_VAL(vec_els[i]);
	}

	glIndexPointer(GL_DOUBLE,stride,ptr);
	free(ptr);
	return scheme_void;
}

/* Same comment as scm_glVertexPointer */
static Scheme_Object* scm_glNormalPointer(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_SYMBOLP(argv[0]))
		scheme_wrong_type((char*)p, "symbol", 0, argc, argv);
	if(!SCHEME_INTP(argv[1]))
		scheme_wrong_type((char*)p, "integer", 1, argc, argv);
	if(!SCHEME_VECTORP(argv[2]))
		scheme_wrong_type((char*)p, "vector", 1, argc, argv);

	GLsizei stride = SCHEME_INT_VAL(argv[1]);

	Scheme_Object** vec_els = SCHEME_VEC_ELS(argv[2]);
	int vec_size = SCHEME_VEC_SIZE(argv[2]);

	GLdouble* ptr = (GLdouble*) malloc(vec_size*sizeof(GLdouble));

	for(int i = 0; i < vec_size; i++) {
		if(!SCHEME_DBLP(vec_els[i]))
			scheme_wrong_type((char*)p, "double", 2, argc, argv);
		ptr[i] = SCHEME_DBL_VAL(vec_els[i]);
	}

	glNormalPointer(GL_DOUBLE,stride,ptr);
	free(ptr);
	return scheme_void;
}

/* Same comment as scm_glVertexPointer */
static Scheme_Object* scm_glTexCoordPointer(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_INTP(argv[0]))
		scheme_wrong_type((char*)p, "integer", 0, argc, argv);
	
	GLint size = SCHEME_INT_VAL(argv[0]);
	if(size < 2 || size > 4)
		scheme_signal_error("Only values 2, 3 or 4 allowed for size");

	if(!SCHEME_SYMBOLP(argv[1]))
		scheme_wrong_type((char*)p, "symbol", 1, argc, argv);

#ifdef BUGGY
	GLenum type = (GLenum) scmgl_GetEnumFromSymbol(argv[1]);
	if(type == GL_INVALID_ENUM)
		scheme_signal_error("Bad symbol : %S !", argv[1]);
#endif

	if(!SCHEME_INTP(argv[2]))
		scheme_wrong_type((char*)p, "integer", 2, argc, argv);

	/* Now working with vectors. I'll make changes backwards asap */
	if(!SCHEME_VECTORP(argv[3]))
		scheme_wrong_type((char*)p, "vector", 3, argc, argv);

	GLsizei stride = SCHEME_INT_VAL(argv[2]);

	Scheme_Object** vec_els = SCHEME_VEC_ELS(argv[3]);
	int vec_size = SCHEME_VEC_SIZE(argv[3]);

	/* We could add some other extra checks but this is not our primary
	 * goal here. Just do "as if". No further help yet.
	 */

	GLdouble* ptr = (GLdouble*) malloc(vec_size*sizeof(GLdouble));

	for(int i = 0; i < vec_size; i++) {
		if(!SCHEME_DBLP(vec_els[i]))
			scheme_wrong_type((char*)p, "double", 3, argc, argv);
		ptr[i] = SCHEME_DBL_VAL(vec_els[i]);
	}

	glTexCoordPointer(size,GL_DOUBLE,stride,ptr);
	free(ptr);
	return scheme_void;
}

static Scheme_Object* scm_glEdgeFlagPointer(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_INTP(argv[0]))
		scheme_wrong_type((char*)p, "integer", 0, argc, argv);
	if(!SCHEME_VECTORP(argv[1]))
		scheme_wrong_type((char*)p, "vector", 1, argc, argv);
	GLsizei stride = SCHEME_INT_VAL(argv[2]);

	Scheme_Object** vec_els = SCHEME_VEC_ELS(argv[1]);
	int vec_size = SCHEME_VEC_SIZE(argv[1]);

	GLboolean* ptr = (GLboolean*) malloc(vec_size*sizeof(GLboolean));

	for(int i = 0; i < vec_size; i++) {
		if(SCHEME_TRUEP(vec_els[i]))
			ptr[i] = GL_TRUE;
		else if(SCHEME_FALSEP(vec_els[i]))
			ptr[i] = GL_FALSE;
		else
			scheme_wrong_type((char*)p, "boolean", 1, argc, argv);
	}

	glEdgeFlagPointer(stride,ptr);
	free(ptr);
	return scheme_void;
}

static Scheme_Object* scm_glRasterPos(void* p, int argc, Scheme_Object** argv) {
	/*
	 * Still no support for scheme vectors. See scm_glVertex.
	 */

	GLdouble t[4];

	for(int i = 0; i < argc; i++) {
		if(SCHEME_DBLP(argv[i]))
			t[i] = (GLdouble) SCHEME_DBL_VAL(argv[i]);
		else
			scheme_wrong_type((char*)p, "double", i, argc, argv);
	}

	switch(argc) {
	case 2:
		{
			glRasterPos2dv(t);
			break;
		}
	case 3:
		{
			glRasterPos3dv(t);
			break;
		}
	case 4:
		{
			glRasterPos4dv(t);
			break;
		}
	default:
		{
			scheme_signal_error("Hmmm we should never had landed here.");
			break;
		}
	}

	return scheme_void;
}

static Scheme_Object* scm_glTexCoord(void* p, int argc, Scheme_Object** argv) {
	/*
	 * Still no support for scheme vectors. See scm_glVertex.
	 */

	GLdouble t[4];

	for(int i = 0; i < argc; i++) {
		if(SCHEME_DBLP(argv[i]))
			t[i] = (GLdouble) SCHEME_DBL_VAL(argv[i]);
		else
			scheme_wrong_type((char*)p, "double", i, argc, argv);
	}

	switch(argc) {
	case 1:
		{
			glTexCoord1dv(t);
			break;
		}
	case 2:
		{
			glTexCoord2dv(t);
			break;
		}
	case 3:
		{
			glTexCoord3dv(t);
			break;
		}
	case 4:
		{
			glTexCoord4dv(t);
			break;
		}
	default:
		{
			scheme_signal_error("Hmmm we should never had landed here.");
			break;
		}
	}

	return scheme_void;
}

static Scheme_Object* scm_glEvalCoord(void* p, int argc, Scheme_Object** argv) {
	/*
	 * Still no support for scheme vectors. See scm_glVertex.
	 */

	GLdouble t[2];

	for(int i = 0; i < argc; i++) {
		if(SCHEME_DBLP(argv[i]))
			t[i] = (GLdouble) SCHEME_DBL_VAL(argv[i]);
		else
			scheme_wrong_type((char*)p, "double", i, argc, argv);
	}

	switch(argc) {
	case 1:
		{
			glEvalCoord1dv(t);
			break;
		}
	case 2:
		{
			glEvalCoord2dv(t);
			break;
		}
	default:
		{
			scheme_signal_error("Hmmm we should never had landed here.");
			break;
		}
	}

	return scheme_void;
}

static Scheme_Object* scm_glIndex(void* p, int argc, Scheme_Object** argv) {
	/* No support here for vectors */
	if(SCHEME_DBLP(argv[0]))
		glIndexd(SCHEME_DBL_VAL(argv[0]));
	else
		scheme_wrong_type((char*)p, "double", 0, argc, argv);
	return scheme_void;
}

static Scheme_Object* scm_glAccum(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_SYMBOLP(argv[0]))
		scheme_wrong_type((char*)p, "symbol", 0, argc, argv);
	if(!SCHEME_FLOATP(argv[1]))
		scheme_wrong_type((char*)p, "float", 1, argc, argv);

	GLenum e_val = (GLenum) scmgl_GetEnumFromSymbol(argv[0]);
	if(e_val == GL_INVALID_ENUM)
		scheme_signal_error("Bad enum : %S", argv[0]);

	glAccum(e_val,SCHEME_FLOAT_VAL(argv[1]));
	return scheme_void;
}

static Scheme_Object* scm_glArrayElement(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_INTP(argv[0]))
		scheme_wrong_type((char*)p, "integer", 0, argc, argv);
	glArrayElement(SCHEME_INT_VAL(argv[0]));
	return scheme_void;
}

static Scheme_Object* scm_glBlendFunc(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_SYMBOLP(argv[0]))
		scheme_wrong_type((char*)p, "symbol", 0, argc, argv);
	if(!SCHEME_SYMBOLP(argv[1]))
		scheme_wrong_type((char*)p, "symbol", 1, argc, argv);
	
	GLenum sfactor = (GLenum) scmgl_GetEnumFromSymbol(argv[0]);
	GLenum dfactor = (GLenum) scmgl_GetEnumFromSymbol(argv[1]);

	if(sfactor == GL_INVALID_ENUM || dfactor == GL_INVALID_ENUM)
		scheme_signal_error("Bad enum : %S or %S", argv[0], argv[1]);

	glBlendFunc(sfactor,dfactor);
	return scheme_void;
}

static Scheme_Object* scm_glRect(void* p, int argc, Scheme_Object** argv) {
	GLdouble t[4];
	for(int i = 0; i < argc; i++) {
		if(!SCHEME_DBLP(argv[i]))
			scheme_wrong_type((char*)p, "double", i, argc, argv);
		t[i] = SCHEME_DBL_VAL(argv[i]);
	}

	glRectd(t[0],t[1],t[2],t[3]);
	return scheme_void;
}

static Scheme_Object* scm_glRenderMode(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_SYMBOLP(argv[0]))
		scheme_wrong_type((char*)p, "symbol", 0, argc, argv);

	GLenum e_val = (GLenum) scmgl_GetEnumFromSymbol(argv[0]);
	if(e_val == GL_INVALID_ENUM)
		scheme_signal_error("Bad enum : %S", argv[0]);

	GLint ret = glRenderMode(e_val);
	return scheme_make_integer(ret);
}

static Scheme_Object* scm_glClearAccum(void* p, int argc, Scheme_Object** argv) {
	GLfloat t[4];

	for(int i = 0; i < argc; i++) {
		if(!SCHEME_FLOATP(argv[i]))
			scheme_wrong_type((char*)p, "float", i, argc, argv);
		t[i] = SCHEME_FLOAT_VAL(argv[i]);
	}

	glClearAccum(t[0],t[1],t[2],t[3]);
	return scheme_void;
}

static Scheme_Object* scm_glClearDepth(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_FLOATP(argv[0]))
		scheme_wrong_type((char*)p,"float",0,argc,argv);

	GLclampf depth = (GLclampf) SCHEME_FLOAT_VAL(argv[0]);
	glClearDepth(depth);
	return scheme_void;
}

static Scheme_Object* scm_glClearIndex(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_FLOATP(argv[0]))
		scheme_wrong_type((char*)p,"float",0,argc,argv);

	GLfloat c = (GLfloat) SCHEME_FLOAT_VAL(argv[0]);
	glClearIndex(c);
	return scheme_void;
}

static Scheme_Object* scm_glClearStencil(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_INTP(argv[0]))
		scheme_wrong_type((char*)p,"integer",0,argc,argv);

	GLint s = (GLint) SCHEME_INT_VAL(argv[0]);
	glClearStencil(s);
	return scheme_void;
}

static Scheme_Object* scm_glPopAttrib(void* p, int argc, Scheme_Object** argv) {
	glPopAttrib();
	return scheme_void;
}

static Scheme_Object* scm_glPopClientAttrib(void* p, int argc, Scheme_Object** argv) {
	glPopClientAttrib();
	return scheme_void;
}

static Scheme_Object* scm_glPopName(void* p, int argc, Scheme_Object** argv) {
	glPopName();
	return scheme_void;
}

static Scheme_Object* scm_glInitNames(void* p, int argc, Scheme_Object** argv) {
	glInitNames();
	return scheme_void;
}

static Scheme_Object* scm_glGetError(void* p, int argc, Scheme_Object** argv) {
	/* Ok, this time we'll have to trick. Since we do not (yet?) support GLU
	 * we don't care about extra GLU errors. As of OpenGL 1.1 and 1.2, there
	 * is only a limited (ie: 7) GL error codes.
	 * We case each one and then we return the corresponding symbol.
	 * In scheme : (if (equal? (glGetError) 'gl_no_error) (display "Fine!"))
	 */

	GLenum e_val = glGetError();

	int s_malloc;
	char* symbol;

	switch(e_val)
	{
	case GL_NO_ERROR:
		{
			char tmp[] = "no_error";
			s_malloc = strlen(tmp)*sizeof(char);
			symbol = (char*) malloc(s_malloc);
			strcpy(symbol,tmp);
			break;
		}
	case GL_INVALID_ENUM:
		{
			char tmp[] = "invalid_enum";
			s_malloc = strlen(tmp)*sizeof(char);
			symbol = (char*) malloc(s_malloc);
			strcpy(symbol,tmp);
			break;
		}
	case GL_INVALID_VALUE:
		{
			char tmp[] = "invalid_value";
			s_malloc = strlen(tmp)*sizeof(char);
			symbol = (char*) malloc(s_malloc);
			strcpy(symbol,tmp);
			break;
		}
	case GL_INVALID_OPERATION:
		{
			char tmp[] = "invalid_operation";
			s_malloc = strlen(tmp)*sizeof(char);
			symbol = (char*) malloc(s_malloc);
			strcpy(symbol,tmp);
			break;
		}
	case GL_STACK_OVERFLOW:
		{
			char tmp[] = "stack_overflow";
			s_malloc = strlen(tmp)*sizeof(char);
			symbol = (char*) malloc(s_malloc);
			strcpy(symbol,tmp);
			break;
		}
	case GL_STACK_UNDERFLOW:
		{
			char tmp[] = "stack_underflow";
			s_malloc = strlen(tmp)*sizeof(char);
			symbol = (char*) malloc(s_malloc);
			strcpy(symbol,tmp);
			break;
		}
	case GL_OUT_OF_MEMORY:
		{
			char tmp[] = "out_of_memory";
			s_malloc = strlen(tmp)*sizeof(char);
			symbol = (char*) malloc(s_malloc);
			strcpy(symbol,tmp);
			break;
		}
	}

	char* ret = (char*) malloc(s_malloc+strlen(gl_prefix)*sizeof(char));
	strcpy(ret,gl_prefix);
	strcat(ret,symbol);
	Scheme_Object* sret = scheme_intern_symbol(ret);
	free(symbol);
	free(ret);
	return sret;
}

static Scheme_Object* scm_glIsEnabled(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_SYMBOLP(argv[0]))
		scheme_wrong_type((char*)p, "symbol", 0, argc, argv);

	GLenum e_val = (GLenum) scmgl_GetEnumFromSymbol(argv[0]);

	if(e_val == GL_INVALID_ENUM)
		scheme_signal_error("Bad enum : %S", argv[0]);

	if(glIsEnabled(e_val))
		return scheme_true;
	else
		return scheme_false;
}

static Scheme_Object* scm_glIsList(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_INTP(argv[0]))
		scheme_wrong_type((char*)p, "unsigned integer", 0, argc, argv);

	unsigned int list = SCHEME_INT_VAL(argv[0]);

	if(glIsList(list))
		return scheme_true;
	else
		return scheme_false;
}

static Scheme_Object* scm_glIsTexture(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_INTP(argv[0]))
		scheme_wrong_type((char*)p, "unsigned integer", 0, argc, argv);

	unsigned int texture = SCHEME_INT_VAL(argv[0]);

	if(glIsTexture(texture))
		return scheme_true;
	else
		return scheme_false;
}
	
static Scheme_Object* scm_glDisable(void* p, int argc, Scheme_Object** argv) {
	GLenum e_val;

	if(SCHEME_SYMBOLP(argv[0])) {
		e_val = (GLenum) scmgl_GetEnumFromSymbol(argv[0]);
		if(e_val == GL_INVALID_ENUM)
			scheme_signal_error("Bad input : %S", argv[0]);
		glDisable(e_val);
	} else if(SCHEME_PAIRP(argv[0])) {
		Scheme_Object* tmp = argv[0];

		while(SCHEME_PAIRP(tmp)) {
			e_val = (GLenum) scmgl_GetEnumFromSymbol(SCHEME_CAR(tmp));
			if(e_val == GL_INVALID_ENUM)
				scheme_signal_error("Bad input : %S", SCHEME_CAR(tmp));
			glDisable(e_val);
			tmp = SCHEME_CDR(tmp);
		}
	} else
		scheme_wrong_type((char*)p, "list or symbol",0,argc,argv);
	
	return scheme_void;
}

static Scheme_Object* scm_glLineStipple(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_INTP(argv[0]))
		scheme_wrong_type((char*)p, "integer", 0, argc, argv);
	if(!SCHEME_INTP(argv[1]))
		scheme_wrong_type((char*)p, "integer", 1, argc, argv);

	glLineStipple(SCHEME_INT_VAL(argv[0]),(GLushort)SCHEME_INT_VAL(argv[1]));
	return scheme_void;
}

static Scheme_Object* scm_glLineWidth(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_FLOATP(argv[0]))
		scheme_wrong_type((char*)p, "float", 0, argc, argv);

	glLineWidth(SCHEME_FLOAT_VAL(argv[0]));
	return scheme_void;
}

static Scheme_Object* scm_glLoadName(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_INTP(argv[0]))
		scheme_wrong_type((char*)p, "unsigned integer", 0, argc, argv);
	
	GLuint name = (GLuint) SCHEME_INT_VAL(argv[0]);
	glLoadName(name);
	return scheme_void;
}

static Scheme_Object* scm_glListBase(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_INTP(argv[0]))
		scheme_wrong_type((char*)p, "unsigned integer", 0, argc, argv);
	
	GLuint base = (GLuint) SCHEME_INT_VAL(argv[0]);
	glListBase(base);
	return scheme_void;
}

static Scheme_Object* scm_glIndexMask(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_INTP(argv[0]))
		scheme_wrong_type((char*)p, "unsigned integer", 0, argc, argv);
	
	GLuint mask = (GLuint) SCHEME_INT_VAL(argv[0]);
	glIndexMask(mask);
	return scheme_void;
}

static Scheme_Object* scm_glPushName(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_INTP(argv[0]))
		scheme_wrong_type((char*)p, "unsigned integer", 0, argc, argv);
	
	GLuint name = (GLuint) SCHEME_INT_VAL(argv[0]);
	glPushName(name);
	return scheme_void;
}

static Scheme_Object* scm_glStencilMask(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_INTP(argv[0]))
		scheme_wrong_type((char*)p, "unsigned integer", 0, argc, argv);
	
	GLuint mask = (GLuint) SCHEME_INT_VAL(argv[0]);
	glStencilMask(mask);
	return scheme_void;
}

static Scheme_Object* scm_glEvalPoint1(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_INTP(argv[0]))
		scheme_wrong_type((char*)p, "integer", 0, argc, argv);

	glEvalPoint1(SCHEME_INT_VAL(argv[0]));
	return scheme_void;
}

static Scheme_Object* scm_glEvalPoint2(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_INTP(argv[0]))
		scheme_wrong_type((char*)p, "integer", 0, argc, argv);

	if(!SCHEME_INTP(argv[1]))
		scheme_wrong_type((char*)p, "integer", 1, argc, argv);

	glEvalPoint2(SCHEME_INT_VAL(argv[0]), SCHEME_INT_VAL(argv[1]));
	return scheme_void;
}

static Scheme_Object* scm_glReadBuffer(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_SYMBOLP(argv[0]))
		scheme_wrong_type((char*)p, "symbol", 0, argc, argv);

	GLenum e_val = (GLenum) scmgl_GetEnumFromSymbol(argv[0]);
	if(e_val == GL_INVALID_ENUM)
		scheme_signal_error("Bad enum : %S", argv[0]);

	glReadBuffer(e_val);
	return scheme_void;
}

static Scheme_Object* scm_glPolygonMode(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_SYMBOLP(argv[0]))
		scheme_wrong_type((char*)p, "symbol", 0, argc, argv);
	if(!SCHEME_SYMBOLP(argv[1]))
		scheme_wrong_type((char*)p, "symbol", 1, argc, argv);

	GLenum face = (GLenum) scmgl_GetEnumFromSymbol(argv[0]);
	GLenum mode = (GLenum) scmgl_GetEnumFromSymbol(argv[1]);
	if(face == GL_INVALID_ENUM)
		scheme_signal_error("Bad enum : %S", argv[0]);
	if(mode == GL_INVALID_ENUM)
		scheme_signal_error("Bad enum : %S", argv[1]);

	glPolygonMode(face,mode);
	return scheme_void;
}

static Scheme_Object* scm_glPointSize(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_FLOATP(argv[0]))
		scheme_wrong_type((char*)p, "float", 0, argc, argv);

	GLfloat size = (GLfloat) SCHEME_FLOAT_VAL(argv[0]);
	glPointSize(size);
	return scheme_void;
}

static Scheme_Object* scm_glPassThrough(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_FLOATP(argv[0]))
		scheme_wrong_type((char*)p, "float", 0, argc, argv);

	GLfloat token = (GLfloat) SCHEME_FLOAT_VAL(argv[0]);
	glPassThrough(token);
	return scheme_void;
}

static Scheme_Object* scm_glLogicOp(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_SYMBOLP(argv[0]))
		scheme_wrong_type((char*)p, "symbol", 0, argc, argv);

	GLenum e_val = (GLenum) scmgl_GetEnumFromSymbol(argv[0]);
	if(e_val == GL_INVALID_ENUM)
		scheme_signal_error("Bad enum : %S", argv[0]);

	glLogicOp(e_val);
	return scheme_void;
}

static Scheme_Object* scm_glHint(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_SYMBOLP(argv[0]))
		scheme_wrong_type((char*)p, "symbol", 0, argc, argv);
	if(!SCHEME_SYMBOLP(argv[1]))
		scheme_wrong_type((char*)p, "symbol", 1, argc, argv);

	GLenum target = (GLenum) scmgl_GetEnumFromSymbol(argv[0]);
	GLenum mode = (GLenum) scmgl_GetEnumFromSymbol(argv[1]);
	if(target == GL_INVALID_ENUM)
		scheme_signal_error("Bad enum : %S", argv[0]);
	if(mode == GL_INVALID_ENUM)
		scheme_signal_error("Bad enum : %S", argv[1]);

	glHint(target,mode);
	return scheme_void;
}

static Scheme_Object* scm_glFrontFace(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_SYMBOLP(argv[0]))
		scheme_wrong_type((char*)p, "symbol", 0, argc, argv);

	GLenum e_val = (GLenum) scmgl_GetEnumFromSymbol(argv[0]);
	if(e_val == GL_INVALID_ENUM)
		scheme_signal_error("Bad enum : %S", argv[0]);

	glFrontFace(e_val);
	return scheme_void;
}

static Scheme_Object* scm_glDrawBuffer(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_SYMBOLP(argv[0]))
		scheme_wrong_type((char*)p, "symbol", 0, argc, argv);

	GLenum e_val = (GLenum) scmgl_GetEnumFromSymbol(argv[0]);
	if(e_val == GL_INVALID_ENUM)
		scheme_signal_error("Bad enum : %S", argv[0]);

	glDrawBuffer(e_val);
	return scheme_void;
}

static Scheme_Object* scm_glDisableClientState(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_SYMBOLP(argv[0]))
		scheme_wrong_type((char*)p, "symbol", 0, argc, argv);

	GLenum e_val = (GLenum) scmgl_GetEnumFromSymbol(argv[0]);
	if(e_val == GL_INVALID_ENUM)
		scheme_signal_error("Bad enum : %S", argv[0]);

	glDisableClientState(e_val);
	return scheme_void;
}

static Scheme_Object* scm_glDepthFunc(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_SYMBOLP(argv[0]))
		scheme_wrong_type((char*)p, "symbol", 0, argc, argv);

	GLenum e_val = (GLenum) scmgl_GetEnumFromSymbol(argv[0]);
	if(e_val == GL_INVALID_ENUM)
		scheme_signal_error("Bad enum : %S", argv[0]);

	glDepthFunc(e_val);
	return scheme_void;
}

static Scheme_Object* scm_glCullFace(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_SYMBOLP(argv[0]))
		scheme_wrong_type((char*)p, "symbol", 0, argc, argv);

	GLenum e_val = (GLenum) scmgl_GetEnumFromSymbol(argv[0]);
	if(e_val == GL_INVALID_ENUM)
		scheme_signal_error("Bad enum : %S", argv[0]);

	glCullFace(e_val);
	return scheme_void;
}

static Scheme_Object* scm_glScale(void* p, int argc, Scheme_Object** argv) {
	GLdouble t[3];

	for(int i = 0; i < argc; i++) {
		if(!SCHEME_DBLP(argv[i]))
			scheme_wrong_type((char*)p, "double", i, argc, argv);
		t[i] = SCHEME_DBL_VAL(argv[i]);
	}

	glScaled(t[0],t[1],t[2]);
	return scheme_void;
}

static Scheme_Object* scm_glColorMaterial(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_SYMBOLP(argv[0]))
		scheme_wrong_type((char*)p, "symbol", 0, argc, argv);
	if(!SCHEME_SYMBOLP(argv[1]))
		scheme_wrong_type((char*)p, "symbol", 1, argc, argv);

	GLenum face = (GLenum) scmgl_GetEnumFromSymbol(argv[0]);
	GLenum mode = (GLenum) scmgl_GetEnumFromSymbol(argv[1]);
	if(face == GL_INVALID_ENUM)
		scheme_signal_error("Bad enum : %S", argv[0]);
	if(mode == GL_INVALID_ENUM)
		scheme_signal_error("Bad enum : %S", argv[1]);

	glColorMaterial(face,mode);
	return scheme_void;
}

static Scheme_Object* scm_glDepthMask(void* p, int argc, Scheme_Object** argv) {
	if(scheme_equal(argv[0],scheme_true))
		glDepthMask(GL_TRUE);
	else if(scheme_equal(argv[0],scheme_false))
		glDepthMask(GL_FALSE);
	else
		scheme_wrong_type((char*)p, "boolean", 0, argc, argv);

	return scheme_void;
}

static Scheme_Object* scm_glPixelStore(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_SYMBOLP(argv[0]))
		scheme_wrong_type((char*)p, "symbol", 0, argc, argv);
	if(!SCHEME_FLOATP(argv[1]))
		scheme_wrong_type((char*)p, "float", 1, argc, argv);

	GLenum pname = (GLenum) scmgl_GetEnumFromSymbol(argv[0]);
	if(pname == GL_INVALID_ENUM)
		scheme_signal_error("Bad enum : %S", argv[0]);

	glPixelStoref(pname, SCHEME_FLOAT_VAL(argv[1]));
	return scheme_void;
}

static Scheme_Object* scm_glPixelTransfer(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_SYMBOLP(argv[0]))
		scheme_wrong_type((char*)p, "symbol", 0, argc, argv);
	if(!SCHEME_FLOATP(argv[1]))
		scheme_wrong_type((char*)p, "float", 1, argc, argv);

	GLenum pname = (GLenum) scmgl_GetEnumFromSymbol(argv[0]);
	if(pname == GL_INVALID_ENUM)
		scheme_signal_error("Bad enum : %S", argv[0]);

	glPixelTransferf(pname, SCHEME_FLOAT_VAL(argv[1]));
	return scheme_void;
}

static Scheme_Object* scm_glPixelZoom(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_FLOATP(argv[0]))
		scheme_wrong_type((char*)p, "float", 0, argc, argv);

	if(!SCHEME_FLOATP(argv[1]))
		scheme_wrong_type((char*)p, "float", 1, argc, argv);

	glPixelZoom(SCHEME_FLOAT_VAL(argv[0]), SCHEME_FLOAT_VAL(argv[1]));
	return scheme_void;
}

static Scheme_Object* scm_glPolygonOffset(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_FLOATP(argv[0]))
		scheme_wrong_type((char*)p, "float", 0, argc, argv);

	if(!SCHEME_FLOATP(argv[1]))
		scheme_wrong_type((char*)p, "float", 1, argc, argv);

	glPolygonOffset(SCHEME_FLOAT_VAL(argv[0]), SCHEME_FLOAT_VAL(argv[1]));
	return scheme_void;
}

static Scheme_Object* scm_glStencilOp(void* p, int argc, Scheme_Object** argv) {
	GLenum t[3];
	
	for(int i = 0; i < argc; i++) {
		if(!SCHEME_SYMBOLP(argv[i]))
			scheme_wrong_type((char*)p, "symbol", i, argc, argv);
		t[i] = (GLenum) scmgl_GetEnumFromSymbol(argv[i]);
		if(t[i] == GL_INVALID_ENUM)
			scheme_signal_error("Bad enum : %S", argv[0]);
	}

	glStencilOp(t[0],t[1],t[2]);
	return scheme_void;
}

static Scheme_Object* scm_glStencilFunc(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_SYMBOLP(argv[0]))
		scheme_wrong_type((char*)p, "symbol", 0, argc, argv);
	if(!SCHEME_INTP(argv[1]))
		scheme_wrong_type((char*)p, "integer", 1, argc, argv);
	if(!SCHEME_INTP(argv[2]))
		scheme_wrong_type((char*)p, "unsigned integer", 2, argc, argv);

	GLenum func = (GLenum) scmgl_GetEnumFromSymbol(argv[0]);
	if(func == GL_INVALID_ENUM)
		scheme_signal_error("Bad enum : %S", argv[0]);

	glStencilFunc(func,SCHEME_INT_VAL(argv[1]),(GLuint) SCHEME_INT_VAL(argv[2]));
	return scheme_void;
}

static Scheme_Object* scm_glMapGrid1(void* p, int argc, Scheme_Object** argv) {
	/* I know that we will only use t[1..2] but we waste only 1 GLdouble in
	 * memory instead of one more instruction t[i - 1] (here t[i]).
	 * If you are not happy you can easily change this behavior anyway.
	 */
	GLdouble t[3];

	if(!SCHEME_INTP(argv[0]))
		scheme_wrong_type((char*)p, "integer", 0, argc, argv);

	GLint un = SCHEME_INT_VAL(argv[0]);

	for(int i = 1; i < argc; i++) {
		if(!SCHEME_DBLP(argv[i]))
			scheme_wrong_type((char*)p, "double", i, argc, argv);
		t[i] = SCHEME_DBL_VAL(argv[i]);
	}

	glMapGrid1d(un,t[1],t[2]);
	return scheme_void;
}

static Scheme_Object* scm_glMapGrid2(void* p, int argc, Scheme_Object** argv) {
	/* Ok this time we also waste 1 GLdouble but on the other hand we simplify
	 * drastically our main loop. I may someday optimize it a bit more.
	 * In the meantime you can always hack around this code.
	 */
	GLdouble t[5];

	if(!SCHEME_INTP(argv[0]))
		scheme_wrong_type((char*)p, "integer", 0, argc, argv);
	if(!SCHEME_INTP(argv[2]))
		scheme_wrong_type((char*)p, "integer", 2, argc, argv);

	GLint un = SCHEME_INT_VAL(argv[0]);
	GLint vn = SCHEME_INT_VAL(argv[2]);

	for(int i = 0; i < argc; i++) {
		if(i%3) {
			if(!SCHEME_DBLP(argv[i]))
				scheme_wrong_type((char*)p, "double", i, argc, argv);
			t[i-1] = SCHEME_DBL_VAL(argv[i]);
		}
	}

	glMapGrid2d(un,t[0],t[1],vn,t[3],t[4]);
	return scheme_void;
}

static Scheme_Object* scm_glEnableClientState(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_PAIRP(argv[0]))
		scheme_wrong_type((char*)p, "list",0,argc,argv);

	Scheme_Object* tmp = argv[0];
	GLenum e_val;

	while(SCHEME_PAIRP(tmp)) {
		e_val = (GLenum) scmgl_GetEnumFromSymbol(SCHEME_CAR(tmp));
		if(e_val == GL_INVALID_ENUM) {
			scheme_signal_error("Bad input : %S", SCHEME_CAR(tmp));
		}
		glEnableClientState(e_val);
		tmp = SCHEME_CDR(tmp);
	}
	
	return scheme_void;
}

static Scheme_Object* scm_glEvalMesh1(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_SYMBOLP(argv[0]))
		scheme_wrong_type((char*)p, "symbol", 0, argc, argv);
	if(!SCHEME_INTP(argv[1]))
		scheme_wrong_type((char*)p, "integer", 1, argc, argv);
	if(!SCHEME_INTP(argv[2]))
		scheme_wrong_type((char*)p, "integer", 2, argc, argv);

	GLenum mode = (GLenum) scmgl_GetEnumFromSymbol(argv[0]);
	if(mode == GL_INVALID_ENUM)
		scheme_signal_error("Bad enum : %S", argv[0]);

	glEvalMesh1(mode,SCHEME_INT_VAL(argv[1]),SCHEME_INT_VAL(argv[2]));
	return scheme_void;
}

static Scheme_Object* scm_glEvalMesh2(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_SYMBOLP(argv[0]))
		scheme_wrong_type((char*)p, "symbol", 0, argc, argv);

	GLint t[5];
	for(int i = 1;i < argc; i++) {
		if(!SCHEME_INTP(argv[i]))
			scheme_wrong_type((char*)p, "integer", i, argc, argv);
		t[i] = SCHEME_INT_VAL(argv[i]);
	}

	GLenum mode = (GLenum) scmgl_GetEnumFromSymbol(argv[0]);
	if(mode == GL_INVALID_ENUM)
		scheme_signal_error("Bad enum : %S", argv[0]);

	glEvalMesh2(mode,t[1],t[2],t[3],t[4]);
	return scheme_void;
}

static Scheme_Object* scm_glColorMask(void* p, int argc, Scheme_Object** argv) {
	GLboolean t[4];

	for(int i = 0; i < argc; i++) {
		if(SCHEME_TRUEP(argv[i]))
			t[i] = GL_TRUE;
		else if(SCHEME_FALSEP(argv[i]))
			t[i] = GL_FALSE;
		else
			scheme_wrong_type((char*)p, "boolean", i, argc, argv);
	}

	glColorMask(t[0],t[1],t[2],t[3]);
	return scheme_void;
}

static Scheme_Object* scm_glBindTexture(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_SYMBOLP(argv[0]))
		scheme_wrong_type((char*)p, "symbol", 0, argc, argv);
	if(!SCHEME_INTP(argv[1]))
		scheme_wrong_type((char*)p, "unsigned integer", 1, argc, argv);

	GLenum target = (GLenum) scmgl_GetEnumFromSymbol(argv[0]);
	if(target == GL_INVALID_ENUM)
		scheme_signal_error("Bad enum : %S", argv[0]);

	glBindTexture(target,(GLuint) SCHEME_INT_VAL(argv[1]));
	return scheme_void;
}

static Scheme_Object* scm_glDeleteLists(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_INTP(argv[0]))
		scheme_wrong_type((char*)p, "integer", 0, argc, argv);
	if(!SCHEME_INTP(argv[1]))
		scheme_wrong_type((char*)p, "unsigned integer", 1, argc, argv);

	glDeleteLists(SCHEME_INT_VAL(argv[0]), (GLsizei) SCHEME_INT_VAL(argv[1]));
	return scheme_void;
}

static Scheme_Object* scm_glDrawArrays(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_SYMBOLP(argv[0]))
		scheme_wrong_type((char*)p, "symbol", 0, argc, argv);
	if(!SCHEME_INTP(argv[1]))
		scheme_wrong_type((char*)p, "integer", 1, argc, argv);
	if(!SCHEME_INTP(argv[2]))
		scheme_wrong_type((char*)p, "unsigned integer", 2, argc, argv);

	GLenum mode = (GLenum) scmgl_GetEnumFromSymbol(argv[0]);
	if(mode == GL_INVALID_ENUM)
		scheme_signal_error("Bad enum : %S", argv[0]);

	glEvalMesh1(mode,SCHEME_INT_VAL(argv[1]),(GLsizei) SCHEME_INT_VAL(argv[2]));
	return scheme_void;
}

static Scheme_Object* scm_glCopyPixels(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_SYMBOLP(argv[4]))
		scheme_wrong_type((char*)p, "symbol", 4, argc, argv);

	GLenum mode = (GLenum) scmgl_GetEnumFromSymbol(argv[4]);
	if(mode == GL_INVALID_ENUM)
		scheme_signal_error("Bad enum : %S", argv[0]);

	GLint t[2];
	GLsizei u[2];

	for(int i = 0; i < 2; i++) {
		if(!SCHEME_INTP(argv[i]))
			scheme_wrong_type((char*)p, "integer", i, argc, argv);
		if(!SCHEME_INTP(argv[i+2]))
			scheme_wrong_type((char*)p, "unsigned integer", i+2, argc, argv);
		t[i] = SCHEME_INT_VAL(argv[i]);
		u[i] = SCHEME_INT_VAL(argv[i+2]);
	}

	glCopyPixels(t[0],t[1],u[0],u[1],mode);
	return scheme_void;
}

static Scheme_Object* scm_glDepthRange(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_DBLP(argv[0]))
		scheme_wrong_type((char*)p, "double", 0, argc, argv);

	if(!SCHEME_DBLP(argv[1]))
		scheme_wrong_type((char*)p, "double", 1, argc, argv);

	glDepthRange((GLclampd) SCHEME_DBL_VAL(argv[0]), (GLclampd) SCHEME_DBL_VAL(argv[1]));
	return scheme_void;
}

static Scheme_Object* scm_glEdgeFlag(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_VECTORP(argv[0])) {
		if(SCHEME_TRUEP(argv[0]))
			glEdgeFlag(GL_TRUE);
		else if(SCHEME_FALSEP(argv[0]))
			glEdgeFlag(GL_FALSE);
		else
			scheme_wrong_type((char*)p, "boolean", 0, argc, argv);
	} else {
		int vec_size = SCHEME_VEC_SIZE(argv[0]);
		Scheme_Object** vec_els = SCHEME_VEC_ELS(argv[0]);

		GLboolean* t = (GLboolean*) malloc(vec_size*sizeof(GLboolean));

		for(int i = 0; i < vec_size; i++) {
			if(scheme_equal(argv[i],scheme_true))
				t[i] = GL_TRUE;
			else if(scheme_equal(argv[i],scheme_false))
				t[i] = GL_FALSE;
			else
				scheme_wrong_type((char*)p, "vector of booleans", 0, argc, argv);
		}

		glEdgeFlagv(t);
		free(t);
	}
	return scheme_void;
}
			
static Scheme_Object* scm_glFog(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_SYMBOLP(argv[0]))
		scheme_wrong_type((char*)p, "symbol", 0, argc, argv);

	GLenum pname = (GLenum) scmgl_GetEnumFromSymbol(argv[0]);
	if(pname == GL_INVALID_ENUM)
		scheme_signal_error("Bad enum : %S",argv[0]);

	if(!SCHEME_VECTORP(argv[1])) {
		if(SCHEME_FLOATP(argv[1]))
			glFogf(pname,SCHEME_FLOAT_VAL(argv[1]));
		else if(SCHEME_SYMBOLP(argv[1])) {
			GLenum temp = (GLenum) scmgl_GetEnumFromSymbol(argv[1]);
			if(temp == GL_INVALID_ENUM)
				scheme_signal_error("Bad enum : %S", argv[1]);
			glFogi(pname,temp);
		} else
			scheme_wrong_type((char*)p, "vector, float or symbol", 1, argc, argv);
	} else {
		int vec_size = SCHEME_VEC_SIZE(argv[1]);
		Scheme_Object** vec_els = SCHEME_VEC_ELS(argv[1]);

		GLfloat* t = (GLfloat*) malloc(vec_size*sizeof(GLfloat));

		for(int i = 0; i < vec_size; i++) {
			if(!SCHEME_FLOATP(vec_els[i]))
				scheme_wrong_type((char*)p, "vector of floats", 1, argc, argv);
			t[i] = SCHEME_FLOAT_VAL(vec_els[i]);
		}

		glFogfv(pname,t);
		free(t);
	}
	return scheme_void;
}

/* Last minute note:
 * As for performance and ease of use, there will be only one glGet* per "type".
 * glGetBoolean will be binded for ease of use in scheme for these primitives #t and #f,
 * glGetDouble for numbers as because conversion from double is the less restrictive.
 */
static Scheme_Object* scm_glGetDouble(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_SYMBOLP(argv[0]))
		scheme_wrong_type((char*)p, "symbol", 0, argc, argv);

	GLenum pname = (GLenum) scmgl_GetEnumFromSymbol(argv[0]);
	if(pname == GL_INVALID_ENUM)
		scheme_signal_error("Bad enum : %S",argv[0]);

	int vec_size = SCHEME_VEC_SIZE(argv[1]);
	Scheme_Object** vec_els = SCHEME_VEC_ELS(argv[1]);

	GLdouble* gd = (GLdouble*) malloc(vec_size*sizeof(GLdouble));
	glGetDoublev(pname,gd);

	for(int i = 0; i < vec_size; i++)
		vec_els[i] = scheme_make_double(gd[i]);

	return scheme_void;
}

static Scheme_Object* scm_glGetBoolean(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_SYMBOLP(argv[0]))
		scheme_wrong_type((char*)p, "symbol", 0, argc, argv);

	GLenum pname = (GLenum) scmgl_GetEnumFromSymbol(argv[0]);
	if(pname == GL_INVALID_ENUM)
		scheme_signal_error("Bad enum : %S",argv[0]);

	int vec_size = SCHEME_VEC_SIZE(argv[1]);
	Scheme_Object** vec_els = SCHEME_VEC_ELS(argv[1]);

	GLboolean* gb = (GLboolean*) malloc(vec_size*sizeof(GLboolean));
	glGetBooleanv(pname,gb);

	for(int i = 0; i < vec_size; i++) {
		if(gb[i] == GL_FALSE)
			vec_els[i] = scheme_false;
		else
			vec_els[i] = scheme_true;
	}

	return scheme_void;
}

static Scheme_Object* scm_glLightModel(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_SYMBOLP(argv[0]))
		scheme_wrong_type((char*)p,"symbol",0,argc,argv);

	GLenum pname = scmgl_GetEnumFromSymbol(argv[0]);
	if(pname == GL_INVALID_ENUM)
		scheme_signal_error("Bad enum : %S",argv[0]);

	GLfloat param[4];

	if(SCHEME_SYMBOLP(argv[1]))
		param[0] = (GLfloat) scmgl_GetEnumFromSymbol(argv[1]);
	else if(SCHEME_FLOATP(argv[1]))
		param[0] = SCHEME_FLOAT_VAL(argv[1]);
	else if(SCHEME_VECTORP(argv[1]) && SCHEME_VEC_SIZE(argv[1]) == 4) {
		Scheme_Object** vec_els = SCHEME_VEC_ELS(argv[1]);
		for(int i = 0; i < 4; i++) {
			if(!SCHEME_FLOATP(vec_els[i]))
				scheme_wrong_type((char*)p, "vector of floats", 1, argc, argv);
			param[i] = SCHEME_FLOAT_VAL(vec_els[i]);
		}
	} else
		scheme_signal_error("Bad input parameter : %S", argv[1]);
	glLightModelfv(pname,param);
	return scheme_void;
}

static Scheme_Object* scm_glAlphaFunc(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_SYMBOLP(argv[0]))
		scheme_wrong_type((char*)p, "symbol", 0, argc, argv);
	if(!SCHEME_DBLP(argv[1]))
		scheme_wrong_type((char*)p, "double", 1, argc, argv);

	GLenum param = scmgl_GetEnumFromSymbol(argv[0]);
	if(param == GL_INVALID_ENUM)
		scheme_signal_error("Bad enum : %S",argv[0]);

	GLclampf ref = (GLclampf) SCHEME_DBL_VAL(argv[1]);

	glAlphaFunc(param,ref);
	return scheme_void;
}

static Scheme_Object* scm_glLoadMatrix(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_VECTORP(argv[0]))
		scheme_wrong_type((char*)p, "vector", 0, argc, argv);

	Scheme_Object** vec_els = SCHEME_VEC_ELS(argv[0]);

	int vec_size = SCHEME_VEC_SIZE(argv[0]);

	GLdouble* m = (GLdouble*) malloc(vec_size*sizeof(GLdouble));

	for(int i = 0; i < vec_size; i++) {
		if(!SCHEME_DBLP(vec_els[i]))
			scheme_wrong_type((char*)p, "vector of doubles", 0, argc, argv);
		m[i] = SCHEME_DBL_VAL(vec_els[i]);
	}

	glLoadMatrixd(m);
	free(m);
	return scheme_void;
}

static Scheme_Object* scm_glScissor(void* p, int argc, Scheme_Object** argv) {
	GLint t[4];

	for(int i = 0; i < argc; i++) {
		if(!SCHEME_INTP(argv[i]))
			scheme_wrong_type((char*)p, "integer", i, argc, argv);
		t[i] = SCHEME_INT_VAL(argv[i]);
	}
	glScissor(t[0],t[1],t[2],t[3]);
	return scheme_void;
}

static Scheme_Object* scm_glCopyTexImage1D(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_SYMBOLP(argv[0]))
		scheme_wrong_type((char*)p,"symbol",0,argc,argv);
	if(!SCHEME_SYMBOLP(argv[2]))
		scheme_wrong_type((char*)p,"symbol",2,argc,argv);
	if(!SCHEME_INTP(argv[1]))
		scheme_wrong_type((char*)p,"integer",1,argc,argv);

	GLint level = SCHEME_INT_VAL(argv[1]);
	GLenum target = scmgl_GetEnumFromSymbol(argv[0]);
	GLenum internalFormat = scmgl_GetEnumFromSymbol(argv[2]);

	if(target == GL_INVALID_ENUM)
		scheme_signal_error("Bad enum : %S",argv[0]);
	if(internalFormat == GL_INVALID_ENUM)
		scheme_signal_error("Bad enum : %S",argv[2]);

	GLint t[4];

	for(int i = 3; i < argc; i++) {
		if(!SCHEME_INTP(argv[i]))
			scheme_wrong_type((char*)p, "integer", i, argc, argv);
		t[i-3] = SCHEME_INT_VAL(argv[i]);
	}

	glCopyTexImage1D(target,level,internalFormat,t[0],t[1],t[2],t[3]);
	return scheme_void;
}

static Scheme_Object* scm_glCopyTexImage2D(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_SYMBOLP(argv[0]))
		scheme_wrong_type((char*)p,"symbol",0,argc,argv);
	if(!SCHEME_SYMBOLP(argv[2]))
		scheme_wrong_type((char*)p,"symbol",2,argc,argv);
	if(!SCHEME_INTP(argv[1]))
		scheme_wrong_type((char*)p,"integer",1,argc,argv);

	GLint level = SCHEME_INT_VAL(argv[1]);
	GLenum target = scmgl_GetEnumFromSymbol(argv[0]);
	GLenum internalFormat = scmgl_GetEnumFromSymbol(argv[2]);

	if(target == GL_INVALID_ENUM)
		scheme_signal_error("Bad enum : %S",argv[0]);
	if(internalFormat == GL_INVALID_ENUM)
		scheme_signal_error("Bad enum : %S",argv[2]);

	GLint t[5];

	for(int i = 3; i < argc; i++) {
		if(!SCHEME_INTP(argv[i]))
			scheme_wrong_type((char*)p, "integer", i, argc, argv);
		t[i-3] = SCHEME_INT_VAL(argv[i]);
	}

	glCopyTexImage2D(target,level,internalFormat,t[0],t[1],t[2],t[3],t[4]);
	return scheme_void;
}

static Scheme_Object* scm_glCopyTexSubImage1D(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_SYMBOLP(argv[0]))
		scheme_wrong_type((char*)p,"symbol",0,argc,argv);

	GLenum target = scmgl_GetEnumFromSymbol(argv[0]);
	if(target == GL_INVALID_ENUM)
		scheme_signal_error("Bad enum : %S",argv[0]);

	GLint t[5];

	for(int i = 1; i < argc; i++) {
		if(!SCHEME_INTP(argv[i]))
			scheme_wrong_type((char*)p, "integer", i, argc, argv);
		t[i-1] = SCHEME_INT_VAL(argv[i]);
	}

	glCopyTexSubImage1D(target,t[0],t[1],t[2],t[3],t[4]);
	return scheme_void;
}

static Scheme_Object* scm_glCopyTexSubImage2D(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_SYMBOLP(argv[0]))
		scheme_wrong_type((char*)p,"symbol",0,argc,argv);

	GLenum target = scmgl_GetEnumFromSymbol(argv[0]);
	if(target == GL_INVALID_ENUM)
		scheme_signal_error("Bad enum : %S",argv[0]);

	GLint t[7];

	for(int i = 1; i < argc; i++) {
		if(!SCHEME_INTP(argv[i]))
			scheme_wrong_type((char*)p, "integer", i, argc, argv);
		t[i-1] = SCHEME_INT_VAL(argv[i]);
	}

	glCopyTexSubImage2D(target,t[0],t[1],t[2],t[3],t[4],t[5],t[6]);
	return scheme_void;
}

static Scheme_Object* scm_glMultMatrix(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_VECTORP(argv[0]))
		scheme_wrong_type((char*)p, "vector", 0, argc, argv);

	Scheme_Object** vec_els = SCHEME_VEC_ELS(argv[0]);

	int vec_size = SCHEME_VEC_SIZE(argv[0]);

	GLdouble* m = (GLdouble*) malloc(vec_size*sizeof(GLdouble));

	for(int i = 0; i < vec_size; i++) {
		if(!SCHEME_DBLP(vec_els[i]))
			scheme_wrong_type((char*)p, "vector of doubles", 0, argc, argv);
		m[i] = SCHEME_DBL_VAL(vec_els[i]);
	}

	glMultMatrixd(m);
	free(m);
	return scheme_void;
}

static Scheme_Object* scm_glTexParameter(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_SYMBOLP(argv[0]))
		scheme_wrong_type((char*)p,"symbol",0,argc,argv);
	if(!SCHEME_SYMBOLP(argv[1]))
		scheme_wrong_type((char*)p,"symbol",1,argc,argv);

	GLenum target = scmgl_GetEnumFromSymbol(argv[0]);
	GLenum pname = scmgl_GetEnumFromSymbol(argv[1]);

	if(target == GL_INVALID_ENUM)
		scheme_signal_error("Bad enum : %S",argv[0]);
	if(pname == GL_INVALID_ENUM)
		scheme_signal_error("Bad enum : %S",argv[1]);

	GLfloat param[4];

	if(SCHEME_SYMBOLP(argv[1]))
		param[0] = (GLfloat) scmgl_GetEnumFromSymbol(argv[1]);
	else if(SCHEME_FLOATP(argv[1]))
		param[0] = SCHEME_FLOAT_VAL(argv[1]);
	else if(SCHEME_VECTORP(argv[1]) && SCHEME_VEC_SIZE(argv[1]) == 4) {
		Scheme_Object** vec_els = SCHEME_VEC_ELS(argv[1]);
		for(int i = 0; i < 4; i++) {
			if(!SCHEME_FLOATP(vec_els[i]))
				scheme_wrong_type((char*)p, "vector of floats", 1, argc, argv);
			param[i] = SCHEME_FLOAT_VAL(vec_els[i]);
		}
	} else
		scheme_signal_error("Bad input parameter : %S", argv[1]);
	glTexParameterfv(target,pname,param);
	return scheme_void;
}

static Scheme_Object* scm_glPixelMap(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_SYMBOLP(argv[0]))
		scheme_wrong_type((char*)p, "symbol",0, argc, argv);
	if(!SCHEME_INTP(argv[1]))
		scheme_wrong_type((char*)p, "integer", 1, argc, argv);
	if(!SCHEME_VECTORP(argv[2]))
		scheme_wrong_type((char*)p, "vector", 2, argc, argv);

	GLenum map = scmgl_GetEnumFromSymbol(argv[0]);
	if(map == GL_INVALID_ENUM)
		scheme_signal_error("Bad enum : %S",argv[0]);

	int mapsize = SCHEME_INT_VAL(argv[1]);
	Scheme_Object** vec_els = SCHEME_VEC_ELS(argv[2]);

	int vec_size = SCHEME_VEC_SIZE(argv[0]);

	GLfloat* values = (GLfloat*) malloc(vec_size*sizeof(GLfloat));

	for(int i = 0; i < vec_size; i++) {
		if(!SCHEME_FLOATP(vec_els[i]))
			scheme_wrong_type((char*)p, "vector of floats", 2, argc, argv);
		values[i] = SCHEME_FLOAT_VAL(vec_els[i]);
	}

	glPixelMapfv(map,mapsize,values);
	free(values);
	return scheme_void;
}

static Scheme_Object* scm_glPushAttrib(void *p, int argc, Scheme_Object** argv) {
	if(!SCHEME_PAIRP(argv[0]))
		scheme_wrong_type((char*)p, "list",0,argc,argv);

	Scheme_Object* tmp = argv[0];
	GLbitfield bf = 0;
	GLbitfield e_val;

	while(SCHEME_PAIRP(tmp)) {
		e_val = (GLbitfield) scmgl_GetEnumFromSymbol(SCHEME_CAR(tmp));
		if(e_val == GL_INVALID_ENUM) {
			scheme_signal_error("Bad input : %S", SCHEME_CAR(tmp));
		}
		bf |= e_val;
		tmp = SCHEME_CDR(tmp);
	}
	
	glPushAttrib(bf);
	return scheme_void;
}

static Scheme_Object* scm_glPushClientAttrib(void *p, int argc, Scheme_Object** argv) {
	if(!SCHEME_PAIRP(argv[0]))
		scheme_wrong_type((char*)p, "list",0,argc,argv);

	Scheme_Object* tmp = argv[0];
	GLbitfield bf = 0;
	GLbitfield e_val;

	while(SCHEME_PAIRP(tmp)) {
		e_val = (GLbitfield) scmgl_GetEnumFromSymbol(SCHEME_CAR(tmp));
		if(e_val == GL_INVALID_ENUM) {
			scheme_signal_error("Bad input : %S", SCHEME_CAR(tmp));
		}
		bf |= e_val;
		tmp = SCHEME_CDR(tmp);
	}
	
	glPushClientAttrib(bf);
	return scheme_void;
}

static Scheme_Object* scm_glTexEnv(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_SYMBOLP(argv[0]))
		scheme_wrong_type((char*)p,"symbol",0,argc,argv);
	if(!SCHEME_SYMBOLP(argv[1]))
		scheme_wrong_type((char*)p,"symbol",1,argc,argv);

	GLenum target = scmgl_GetEnumFromSymbol(argv[0]);
	GLenum pname = scmgl_GetEnumFromSymbol(argv[1]);

	if(target == GL_INVALID_ENUM)
		scheme_signal_error("Bad enum : %S",argv[0]);
	if(pname == GL_INVALID_ENUM)
		scheme_signal_error("Bad enum : %S",argv[1]);

	GLfloat param[4];

	if(SCHEME_SYMBOLP(argv[1]))
		param[0] = (GLfloat) scmgl_GetEnumFromSymbol(argv[1]);
	else if(SCHEME_FLOATP(argv[1]))
		param[0] = SCHEME_FLOAT_VAL(argv[1]);
	else if(SCHEME_VECTORP(argv[1]) && SCHEME_VEC_SIZE(argv[1]) == 4) {
		Scheme_Object** vec_els = SCHEME_VEC_ELS(argv[1]);
		for(int i = 0; i < 4; i++) {
			if(!SCHEME_FLOATP(vec_els[i]))
				scheme_wrong_type((char*)p, "vector of floats", 1, argc, argv);
			param[i] = SCHEME_FLOAT_VAL(vec_els[i]);
		}
	} else
		scheme_signal_error("Bad input parameter : %S", argv[1]);
	glTexEnvfv(target,pname,param);
	return scheme_void;
}

static Scheme_Object* scm_glTexGen(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_SYMBOLP(argv[0]))
		scheme_wrong_type((char*)p,"symbol",0,argc,argv);
	if(!SCHEME_SYMBOLP(argv[1]))
		scheme_wrong_type((char*)p,"symbol",1,argc,argv);

	GLenum target = scmgl_GetEnumFromSymbol(argv[0]);
	GLenum pname = scmgl_GetEnumFromSymbol(argv[1]);

	if(target == GL_INVALID_ENUM)
		scheme_signal_error("Bad enum : %S",argv[0]);
	if(pname == GL_INVALID_ENUM)
		scheme_signal_error("Bad enum : %S",argv[1]);

	GLfloat param[4];

	if(SCHEME_SYMBOLP(argv[1]))
		param[0] = (GLfloat) scmgl_GetEnumFromSymbol(argv[1]);
	else if(SCHEME_FLOATP(argv[1]))
		param[0] = SCHEME_FLOAT_VAL(argv[1]);
	else if(SCHEME_VECTORP(argv[1]) && SCHEME_VEC_SIZE(argv[1]) == 4) {
		Scheme_Object** vec_els = SCHEME_VEC_ELS(argv[1]);
		for(int i = 0; i < 4; i++) {
			if(!SCHEME_FLOATP(vec_els[i]))
				scheme_wrong_type((char*)p, "vector of floats", 1, argc, argv);
			param[i] = SCHEME_FLOAT_VAL(vec_els[i]);
		}
	} else
		scheme_signal_error("Bad input parameter : %S", argv[1]);
	glTexGenfv(target,pname,param);
	return scheme_void;
}

static Scheme_Object* scm_glPolygonStipple(void* p, int argc, Scheme_Object** argv) {
	GLubyte mask[32];

	if(!SCHEME_VECTORP(argv[0]))
		scheme_wrong_type((char*)p,"vector",0,argc,argv);

	Scheme_Object** vec_els = SCHEME_VEC_ELS(argv[0]);
	if(SCHEME_VEC_SIZE(argv[0]) != 32)
		scheme_signal_error("Vector length must be 32 !");

	for(int i = 0; i < 32; i++) {
		if(!SCHEME_INTP(vec_els[i]))
			scheme_wrong_type((char*)p, "vector of unsigned bytes", 0, argc, argv);

		mask[i] = (GLubyte) SCHEME_INT_VAL(vec_els[i]);
	}

	glPolygonStipple(mask);
	return scheme_void;
}

static Scheme_Object* scm_glCallLists(void* p, int argc, Scheme_Object** argv) {
	if(!SCHEME_INTP(argv[0]))
		scheme_wrong_type((char*)p,"integer",0,argc,argv);
	if(!SCHEME_SYMBOLP(argv[1]))
		scheme_wrong_type((char*)p,"symbol",1,argc,argv);
	if(!SCHEME_VECTORP(argv[2]))
		scheme_wrong_type((char*)p,"vector",2,argc,argv);

	GLenum pname = scmgl_GetEnumFromSymbol(argv[1]);

	if(pname == GL_INVALID_ENUM)
		scheme_signal_error("Bad enum : %S",argv[1]);

	GLsizei n = SCHEME_INT_VAL(argv[0]);
	int vec_size = SCHEME_VEC_SIZE(argv[2]);
	GLuint* lists = (GLuint*) malloc(vec_size*sizeof(GLuint));

	Scheme_Object** vec_els = SCHEME_VEC_ELS(argv[2]);
	for(int i = 0; i < vec_size; i++) {
		if(!SCHEME_INTP(vec_els[i]))
			scheme_wrong_type((char*)p, "vector of integers", 2, argc, argv);
		lists[i] = SCHEME_INT_VAL(vec_els[i]);
	}

	glCallLists(n,pname,lists);
	return scheme_void;
}

static Scheme_Object* scm_glGetPolygonStipple(void* p, int argc, Scheme_Object** argv) {
	GLubyte mask[32];

	if(!SCHEME_VECTORP(argv[0]))
		scheme_wrong_type((char*)p,"vector",0,argc,argv);

	Scheme_Object** vec_els = SCHEME_VEC_ELS(argv[0]);
	if(SCHEME_VEC_SIZE(argv[0]) != 32)
		scheme_signal_error("Vector length must be 32 !");

	glGetPolygonStipple(mask);

	for(int i = 0; i < 32; i++)
		vec_els[i] = scheme_make_integer(mask[i]);

	return scheme_void;
}

/*
 * MzScheme register extensions
 */
Scheme_Object* scheme_initialize( Scheme_Env* s_env) {
	int i = 0;
    Scheme_Object* prim;
    while(scmgl_exports[i].name!=NULL) {
		prim = scheme_make_closed_prim_w_arity(scmgl_exports[i].prim, \
			scmgl_exports[i].name, \
			scmgl_exports[i].name, \
			scmgl_exports[i].mina, \
			scmgl_exports[i].maxa);
		scheme_add_global(scmgl_exports[i].name,prim,s_env);
		i++;
	}
#ifdef NDEBUG
	return scheme_void;
#else
	return scheme_make_string("SchemeGL version " SCMGL_VERSION ". Built on " __DATE__".");
#endif /* NDEBUG */
}

Scheme_Object* scheme_reload( Scheme_Env* s_env) {
	return scheme_initialize(s_env);
}

Scheme_Object* scheme_module_name() {
	return scheme_false;
}

