;; $Id: gears.ss,v 1.36 2002/12/10 06:19:48 neil Exp $
;;
;; This is a version of the venerable "gears" demo for PLT Scheme 200 using
;; Scott Owens' SGL OpenGL bindings.  It was ported from "glxgears.c" 1.3 from
;; XFree86, which had the following notices:
;;
;;     Copyright (C) 1999-2001  Brian Paul   All Rights Reserved.
;;
;;     Permission is hereby granted, free of charge, to any person obtaining a
;;     copy of this software and associated documentation files (the
;;     "Software"), to deal in the Software without restriction, including
;;     without limitation the rights to use, copy, modify, merge, publish,
;;     distribute, sublicense, and/or sell copies of the Software, and to
;;     permit persons to whom the Software is furnished to do so, subject to
;;     the following conditions:
;;
;;     The above copyright notice and this permission notice shall be included
;;     in all copies or substantial portions of the Software.
;;
;;     XFree86: xc/programs/glxgears/glxgears.c,v 1.3 2001/11/03 17:29:20 dawes
;;
;;     This is a port of the infamous "gears" demo to straight GLX (i.e. no
;;     GLUT).  Port by Brian Paul 23 March 2001.
;;
;; To run, evaluate this file in DrScheme, or execute "mred -r gears.ss"
;; from your OS shell.  If your version of SGL is missing "gl-end-list", then
;; add a line "void glEndList( void );" to file "collects/sgl/gl-specs/gl11.h",
;; and execute "setup-plt -l sgl".
;;
;; Scheme port by Neil W. Van Dyke <neil@neilvandyke.org>, 23 November 2002.
;; Originally called glxgears.ss.  Minor modifications since.
;; See "http://www.neilvandyke.org/opengl-plt/" for more information.

; This version is somewhat modified to use my SchemeGL v1.1 library.
; Some other code cleanups meanwhile ...

(require (lib "mred.ss" "mred")
         (lib "class.ss")
         (lib "math.ss"))

(load-extension "schemegl")

(define controls? #t)

(define n 0)

(define gears-canvas%
  (class* canvas% ()
    
    (inherit with-gl-context swap-gl-buffers)
    
    (define rotation 0.0)
    
    (define view-rotx 20.0)
    (define view-roty 30.0)
    (define view-rotz 0.0)
    
    (define gear1 #f)
    (define gear2 #f)
    (define gear3 #f)
    
    (define step? #f)
    
    (define/public (move-left)
      (set! view-roty (+ view-roty 5.0)))
    
    (define/public (move-right)
      (set! view-roty (- view-roty 5.0)))
    
    (define/public (move-up)
      (set! view-rotx (+ view-rotx 5.0)))
    
    (define/public (move-down)
      (set! view-rotx (- view-rotx 5.0)))
    
    (define (build-gear inner-radius    ; radius of hole at center
                        outer-radius    ; radius at center of teeth
                        width           ; width of gear
                        teeth           ; number of teeth
                        tooth-depth)    ; depth of tooth
      (let* ((r0             inner-radius)
             (r1             (- outer-radius (/ tooth-depth 2.0)))
             (r2             (+ outer-radius (/ tooth-depth 2.0)))
             (da             (/ (* 2.0 pi) teeth 4.0))
             (da2            (* da 2))
             (da3            (* da 3))
             (half-width     (* width 0.5))
             (neg-half-width (- half-width)))
        
        ;; TODO: Generalize away some more redundant program text.
        
        (glShadeModel 'gl_flat)
        
        (glNormal 0.0 0.0 1.0)
        
        ;; Draw front face.
        (glBegin 'gl_quad_strip)
        (do ((i 0 (+ 1 i))) ((> i teeth))
          (let* ((angle     (/ (* i 2.0 pi) teeth))
                 (cos-angle (cos angle))
                 (sin-angle (sin angle)))
            (glVertex (* r0 cos-angle) (* r0 sin-angle) half-width)
            (glVertex (* r1 cos-angle) (* r1 sin-angle) half-width)
            (when (< i teeth)
              (glVertex (* r0 cos-angle)
                        (* r0 sin-angle)
                        (* half-width))
              (glVertex (* r1 (cos (+ angle da3)))
                        (* r1 (sin (+ angle da3)))
                        half-width))))
        (glEnd)
        
        ;; Draw front sides of teeth.
        (glBegin 'gl_quads)
        (do ((i 0 (+ 1 i))) ((= i teeth))
          (let ((angle (/ (* i 2.0 pi) teeth)))
            (glVertex (* r1 (cos angle))
                      (* r1 (sin angle))
                      half-width)
            (glVertex (* r2 (cos (+ angle da)))
                      (* r2 (sin (+ angle da)))
                      half-width)
            (glVertex (* r2 (cos (+ angle da2)))
                      (* r2 (sin (+ angle da2)))
                      half-width)
            (glVertex (* r1 (cos (+ angle da3)))
                      (* r1 (sin (+ angle da3)))
                      half-width)))
        (glEnd)
        
        (glNormal 0.0 0.0 -1.0)
        
        ;; Draw back face.
        (glBegin 'gl_quad_strip)
        (do ((i 0 (+ 1 i))) ((> i teeth))
          (let* ((angle     (/ (* i 2.0 pi) teeth))
                 (cos-angle (cos angle))
                 (sin-angle (sin angle)))
            (glVertex (* r1 cos-angle) (* r1 sin-angle) neg-half-width)
            (glVertex (* r0 cos-angle) (* r0 sin-angle) neg-half-width)
            (when (< i teeth)
              (glVertex (* r1 (cos (+ angle da3)))
                        (* r1 (sin (+ angle da3)))
                        neg-half-width)
              (glVertex (* r0 cos-angle)
                        (* r0 sin-angle)
                        neg-half-width))))
        (glEnd)
        
        ;; Draw back sides of teeth.
        (glBegin 'gl_quads)
        (do ((i 0 (+ 1 i))) ((= i teeth))
          (let ((angle (/ (* i 2.0 pi) teeth)))
            (glVertex (* r1 (cos (+ angle da3)))
                      (* r1 (sin (+ angle da3)))
                      neg-half-width)
            (glVertex (* r2 (cos (+ angle da2)))
                      (* r2 (sin (+ angle da2)))
                      neg-half-width)
            (glVertex (* r2 (cos (+ angle da)))
                      (* r2 (sin (+ angle da)))
                      neg-half-width)
            (glVertex (* r1 (cos angle))
                      (* r1 (sin angle))
                      neg-half-width)))
        (glEnd)
        
        ;; Draw outward faces of teeth.
        (glBegin 'gl_quad_strip)
        (do ((i 0 (+ 1 i))) ((= i teeth))
          (let* ((angle     (/ (* i 2.0 pi) teeth))
                 (cos-angle (cos angle))
                 (sin-angle (sin angle)))
            
            (glVertex (* r1 cos-angle) (* r1 sin-angle) half-width)
            (glVertex (* r1 cos-angle) (* r1 sin-angle) neg-half-width)
            
            (let* ((u   (- (* r2 (cos (+ angle da))) (* r1 cos-angle)))
                   (v   (- (* r2 (sin (+ angle da))) (* r1 sin-angle)))
                   (len (sqrt (+ (* u u) (* v v)))))
              (glNormal (/ v len) (- (/ u len)) 0.0))
            
            (glVertex (* r2 (cos (+ angle da)))
                      (* r2 (sin (+ angle da)))
                      half-width)
            (glVertex (* r2 (cos (+ angle da)))
                      (* r2 (sin (+ angle da)))
                      neg-half-width)
            (glNormal cos-angle sin-angle 0.0)
            (glVertex (* r2 (cos (+ angle da2)))
                      (* r2 (sin (+ angle da2)))
                      half-width)
            (glVertex (* r2 (cos (+ angle da2)))
                      (* r2 (sin (+ angle da2)))
                      neg-half-width)
            
            (let ((u (- (* r1 (cos (+ angle da3)))
                        (* r2 (cos (+ angle da2)))))
                  (v (- (* r1 (sin (+ angle da3)))
                        (* r2 (sin (+ angle da2))))))
              (glNormal v (- u) 0.0))
            
            (glVertex (* r1 (cos (+ angle da3)))
                      (* r1 (sin (+ angle da3)))
                      half-width)
            (glVertex (* r1 (cos (+ angle da3)))
                      (* r1 (sin (+ angle da3)))
                      neg-half-width)
            (glNormal cos-angle sin-angle 0.0)))
        
        (glVertex (* r1 (cos 0)) (* r1 (sin 0)) half-width)
        (glVertex (* r1 (cos 0)) (* r1 (sin 0)) neg-half-width)
        (glEnd)
        
        (glShadeModel 'gl_smooth)
        
        ;; Draw inside radius cylinder.
        (glBegin 'gl_quad_strip)
        (do ((i 0 (+ 1 i))) ((> i teeth))
          (let* ((angle     (/ (* i 2.0 pi) teeth))
                 (cos-angle (cos angle))
                 (sin-angle (sin angle)))
            (glNormal (- cos-angle) (- sin-angle) 0.0)
            (glVertex (* r0 cos-angle) (* r0 sin-angle) neg-half-width)
            (glVertex (* r0 cos-angle) (* r0 sin-angle) half-width)))
        (glEnd)))
    
    (define/override (on-size width height)
      (with-gl-context
       (lambda ()
         (unless gear1
           (printf "  RENDERER:   ~A\n" (glGetString 'gl_renderer))
           (printf "  VERSION:    ~A\n" (glGetString 'gl_version))
           (printf "  VENDOR:     ~A\n" (glGetString 'gl_vendor))
           (printf "  EXTENSIONS: ~A\n" (glGetString 'gl_extensions)))
         
         (glViewport 0 0 width height)
         (glMatrixMode 'gl_projection)
         (glLoadIdentity)
         (let ((h (exact->inexact (/ height width))))
           (glFrustum -1.0 1.0 (- h) h 5.0 60.0))
         (glMatrixMode 'gl_modelview)
         (glLoadIdentity)
         (glTranslate 0.0 0.0 -40.0)
         
         (glLight 'gl_light0 'gl_position '(5.0 5.0 10.0 0.0))
         (glEnable '(gl_cull_face gl_lighting gl_light0 gl_depth_test))
         
         (unless gear1
           
           (set! gear1 (glGenLists 1))
           (glNewList gear1 'gl_compile)
           (glMaterial 'gl_front
                       'gl_ambient_and_diffuse
                       '(0.8 0.1 0.0 1.0))
           (build-gear 1.0 4.0 1.0 20 0.7)
           (glEndList)
           
           (set! gear2 (glGenLists 1))
           (glNewList gear2 'gl_compile)
           (glMaterial 'gl_front
                       'gl_ambient_and_diffuse
                       '(0.0 0.8 0.2 1.0))
           (build-gear 0.5 2.0 2.0 10 0.7)
           (glEndList)
           
           (set! gear3 (glGenLists 1))
           (glNewList gear3 'gl_compile)
           (glMaterial 'gl_front
                       'gl_ambient_and_diffuse
                       '(0.2 0.2 1.0 1.0))
           (build-gear 1.3 2.0 0.5 10 0.7)
           (glEndList)
           
           (glEnable '(gl_normalize))))))
    
    (define (update-paint)
      (with-gl-context
       (lambda ()
         
         (glClearColor 0.0 0.0 0.0 0.0)
         (glClear '(gl_color_buffer_bit gl_depth_buffer_bit))
         
         (glPushMatrix)
         (glRotate view-rotx 1.0 0.0 0.0)
         (glRotate view-roty 0.0 1.0 0.0)
         (glRotate view-rotz 0.0 0.0 1.0)
         
         (glPushMatrix)
         (glTranslate -3.0 -2.0 0.0)
         (glRotate rotation 0.0 0.0 1.0)
         (glCallList gear1)
         (glPopMatrix)
         
         (glPushMatrix)
         (glTranslate 3.1 -2.0 0.0)
         (glRotate (- (* -2.0 rotation) 9.0) 0.0 0.0 1.0)
         (glCallList gear2)
         (glPopMatrix)
         
         (glPushMatrix)
         (glTranslate -3.1 4.2 0.0)
         (glRotate (- (* -2.0 rotation) 25.0) 0.0 0.0 1.0)
         (glCallList gear3)
         (glPopMatrix)
         
         (glPopMatrix)
         
         (glFlush)
         (swap-gl-buffers))))
    
    (define/override (on-paint)
      (set! n (add1 n))
      (update-paint)
      (when step?
        (set! rotation (modulo (+ 2.0 rotation) 360)))
      (queue-callback (lambda x (send this on-paint)) #f))
    
    (define/public (start-button b e)
      (if step?
          (begin
            (send b set-label "Start")
            (set! step? #f))
          (begin
            (send b set-label "Stop")
            (set! step? #t))))
    
    (super-instantiate () (style '(gl)))))

;(let* ((f (make-object frame% "gears.ss" #f #f #f #f #f '(no-resize-border no-caption)))
(let* ((f (make-object frame% "gears.ss" #f))
       (c (instantiate gears-canvas% (f) (min-width 300) (min-height 300))))
  
  (instantiate timer% ((lambda timer-callback
                         (send f set-label (string-append "gears.ss .::. FPS : " (number->string n)))
                         (set! n 0)) 1000 #f))

  (when controls?
    (let ((h (instantiate horizontal-panel% (f) (alignment '(center center)) (stretchable-height #f))))
      (instantiate button% ("&Start" h (lambda (b e) (send c start-button b e))) (stretchable-width #t) (stretchable-height #t))
      (let ((h (instantiate horizontal-panel% (h) (alignment '(center center)))))
        (instantiate button% ("&Left" h (lambda x (send c move-left)))
          (stretchable-width #t))
        (let ((v (instantiate vertical-panel% (h)
                   (alignment '(center center)) (stretchable-width #f))))
          (instantiate button% ("&Up" v (lambda x (send c move-up)))
            (stretchable-width #t))
          (instantiate button% ("&Down" v (lambda x (send c move-down)))
            (stretchable-width #t)))
        (instantiate button% ("&Right" h (lambda x (send c move-right)))
          (stretchable-width #t))
        (instantiate button% ("&Exit" h (lambda x (exit)))
          (stretchable-width #t)))))
  (send f show #t))

;;eof
