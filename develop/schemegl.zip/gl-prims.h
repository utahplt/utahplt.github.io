/*
 * OpenGL Scheme Primitives Header file
 * Version 1.0 -- by Olivier ORABONA
 *
 * This header was created to avoid main source code overload.
 * It contains all primitives supported by SchemeGL 1.0 depending on
 * OpenGL (and GLUT if enabled) implementations.
 *
 */

/*
 * Currently exported (and thus supported) OpenGL functions
 */

struct scm_exports_t {
	char* name;
	Scheme_Closed_Prim* prim;
	int mina;
	int maxa;
};

#define MAKE_PRIMF(p,n) { #p, scm_ ## p, n, n }
#define MAKE_PRIM(p,i,a) { #p, scm_ ## p, i, a }

static const struct scm_exports_t scmgl_exports[] = \
{
	/* SchemeGL specific */
	MAKE_PRIMF(sglInit,1),
	/* OpenGL bindings */
	MAKE_PRIMF(glGetString,1),
	MAKE_PRIMF(glClear,1),
	MAKE_PRIMF(glClearColor,4),
	MAKE_PRIMF(glFlush,0),
	MAKE_PRIMF(glFinish,0),
	MAKE_PRIMF(glBegin,1),
	MAKE_PRIMF(glEnd,0),
	MAKE_PRIM(glVertex,2,4),
	MAKE_PRIM(glColor,3,4),
	MAKE_PRIMF(glMatrixMode,1),
	MAKE_PRIMF(glLoadIdentity,0),
	MAKE_PRIMF(glOrtho,6),
	MAKE_PRIMF(glNormal,3),
	MAKE_PRIMF(glShadeModel,1),
	MAKE_PRIMF(glViewport,4),
	MAKE_PRIMF(glFrustum,6),
	MAKE_PRIMF(glTranslate,3),
	MAKE_PRIMF(glEnable,1),
	MAKE_PRIMF(glLight,3),
	MAKE_PRIMF(glNewList,2),
	MAKE_PRIMF(glEndList,0),
	MAKE_PRIMF(glGenLists,1),
	MAKE_PRIMF(glMaterial,3),
	MAKE_PRIMF(glPushMatrix,0),
	MAKE_PRIMF(glPopMatrix,0),
	MAKE_PRIMF(glCallList,1),
	MAKE_PRIMF(glRotate,4),
	MAKE_PRIMF(glVertexPointer,4),
	MAKE_PRIMF(glIndexPointer,3),
	MAKE_PRIMF(glColorPointer,3),
	MAKE_PRIMF(glNormalPointer,3),
	MAKE_PRIMF(glTexCoordPointer,4),
	MAKE_PRIMF(glEdgeFlagPointer,2),
	MAKE_PRIM(glRasterPos,2,4),
	MAKE_PRIM(glTexCoord,2,4),
	MAKE_PRIM(glEvalCoord,2,2),	/* FIXME: when vectorization will be okay */
	MAKE_PRIMF(glIndex,1),
	MAKE_PRIMF(glAccum,2),
	MAKE_PRIMF(glArrayElement,1),
	MAKE_PRIMF(glBlendFunc,2),
	MAKE_PRIMF(glRect,4),
	MAKE_PRIMF(glRenderMode,1),
	MAKE_PRIMF(glClearAccum,4),
	MAKE_PRIMF(glClearDepth,1),
	MAKE_PRIMF(glClearIndex,1),
	MAKE_PRIMF(glClearStencil,1),
	MAKE_PRIMF(glPopAttrib,0),
	MAKE_PRIMF(glPopClientAttrib,0),
	MAKE_PRIMF(glPopName,0),
	MAKE_PRIMF(glInitNames,0),
	MAKE_PRIMF(glGetError,0),
	MAKE_PRIMF(glIsEnabled,1),
	MAKE_PRIMF(glIsList,1),
	MAKE_PRIMF(glIsTexture,1),
	MAKE_PRIMF(glDisable,1),
	MAKE_PRIMF(glLineStipple,2),
	MAKE_PRIMF(glLineWidth,1),
	MAKE_PRIMF(glLoadName,1),
	MAKE_PRIMF(glListBase,1),
	MAKE_PRIMF(glIndexMask,1),
	MAKE_PRIMF(glPushName,1),
	MAKE_PRIMF(glStencilMask,1),
	MAKE_PRIMF(glEvalPoint1,1),
	MAKE_PRIMF(glEvalPoint2,2),
	MAKE_PRIMF(glShadeModel,1),
	MAKE_PRIMF(glReadBuffer,1),
	MAKE_PRIMF(glPolygonMode,2),
	MAKE_PRIMF(glPointSize,1),
	MAKE_PRIMF(glPassThrough,1),
	MAKE_PRIMF(glLogicOp,1),
	MAKE_PRIMF(glHint,2),
	MAKE_PRIMF(glFrontFace,1),
	MAKE_PRIMF(glDrawBuffer,1),
	MAKE_PRIMF(glDisableClientState,1),
	MAKE_PRIMF(glDepthFunc,1),
	MAKE_PRIMF(glCullFace,1),
	MAKE_PRIMF(glScale,3),
	MAKE_PRIMF(glColorMaterial,2),
	MAKE_PRIMF(glDepthMask,1),
	MAKE_PRIMF(glPixelStore,2),
	MAKE_PRIMF(glPixelTransfer,2),
	MAKE_PRIMF(glPixelZoom,2),
	MAKE_PRIMF(glPolygonOffset,2),
	MAKE_PRIMF(glStencilOp,3),
	MAKE_PRIMF(glStencilFunc,3),
	MAKE_PRIMF(glMapGrid1,3),
	MAKE_PRIMF(glMapGrid2,6),
	MAKE_PRIMF(glEnableClientState,1),
	MAKE_PRIMF(glEvalMesh1,3),
	MAKE_PRIMF(glEvalMesh2,5),
	MAKE_PRIMF(glColorMask,4),
	MAKE_PRIMF(glBindTexture,2),
	MAKE_PRIMF(glDeleteLists,2),
	MAKE_PRIMF(glDrawArrays,3),
	MAKE_PRIMF(glCopyPixels,5),
	MAKE_PRIMF(glDepthRange,2),
	MAKE_PRIMF(glEdgeFlag,1),
	MAKE_PRIMF(glFog,2),
	MAKE_PRIMF(glGetDouble,2),
	MAKE_PRIMF(glLightModel,2),
	MAKE_PRIMF(glAlphaFunc,2),
	MAKE_PRIMF(glLoadMatrix,1),
	MAKE_PRIMF(glScissor,4),
	MAKE_PRIMF(glCopyTexImage1D,7),
	MAKE_PRIMF(glCopyTexImage2D,8),
	MAKE_PRIMF(glCopyTexSubImage1D,6),
	MAKE_PRIMF(glCopyTexSubImage2D,8),
	MAKE_PRIMF(glMultMatrix,1),
	MAKE_PRIMF(glTexParameter,3),
	MAKE_PRIMF(glPixelMap,3),
	MAKE_PRIMF(glPushAttrib,1),
	MAKE_PRIMF(glPushClientAttrib,1),
	MAKE_PRIMF(glGetBoolean,2),
	MAKE_PRIMF(glTexEnv,3),
	MAKE_PRIMF(glTexGen,3),
	MAKE_PRIMF(glPolygonStipple,1),
	MAKE_PRIMF(glCallLists,3),
	MAKE_PRIMF(glGetPolygonStipple,1),
	{ NULL, NULL, 0, 0},
};

