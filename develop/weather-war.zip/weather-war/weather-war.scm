;;Weather war
;;Author: Daniel Lyle
;;Date: 9/16/2001
;;Notes: derived from an old Commodore 64 game
;;       (would wait for my friend Mark Gripp to load up this game
;;        off his tape drive -- after 10-15 minutes we would play 
;;        this simple game)

(define frame (make-object frame% "Weather War" #f 525 200 #f #f null)) 

(send frame show #t) 

(define num-weather-types 4)

;;Weather damage table:

(define weather-damage-table%
  (class* object% () ()
    (private               ; 0  1  2  3  4  5  6  7  8  9 10 11 12
                     ;rain:
      [damage-table (vector 
                     (vector 1  2  1  2  1  2  1  2  1  2  1  2  1)
                     ;hail:
                     (vector 1  1  3  1  1  3  1  1  3  1  1  3  1)
                ;lightning:
                     (vector 1  1  1  5  1  1  1  5  1  1  1  5  1)
                  ;tornado:
                     (vector 1  1  1  1  1  7  1  1  1  1  1  7  1))])
    (public
      [get-damage (lambda (roll weather-type)
                    (vector-ref (vector-ref damage-table weather-type) roll))])
    (sequence (super-init))))

(define weather-dmg-tbl (make-object weather-damage-table%))

(define weather-snd-effects%
  (class* object% () ()
    (public
      [play-snd-fx (lambda (weather no-block?)
                     (cond ((= weather 0)
                            (play-sound "RAINFIBL.WAV" no-block?))
                           ((= weather 1)
                            (play-sound "HAIL.WAV" no-block?))
                           ((= weather 2)
                            (play-sound "PATRUMBL.WAV" no-block?))
                           ((= weather 3)
                            (play-sound "gusting_winds.wav" no-block?))))
                           ])
    (sequence (super-init))))

(define weather-snd-fx (make-object weather-snd-effects%))

    

(define castle% 
  (class* object% ()(hit-pts) 
    (private 
      [endurance hit-pts]) 
    (public 
      [get-hp (lambda () endurance)] 
      [set-hp! (lambda (hp) (set! endurance hp))]
      [dead? (lambda() (<= endurance 0))] 
      [hit! (lambda (damage) (set! endurance (max 0 (- endurance damage))))]) 
    (sequence (super-init)))) 

(define castle-1 (make-object castle% 30))
(define castle-2 (make-object castle% 30))

(define castle-viewer% 
  (class* canvas% () (parent castle-bitmap castle) 
    (private 
      [my-castle castle] 
      
      [castle-bm castle-bitmap] 
      [castle-dc (make-object bitmap-dc% castle-bitmap)]) 
    (override 
      [on-paint (lambda() (send (send this get-dc) draw-bitmap castle-bm 0 0 'xor (make-object color% 0 0 0)))]) 
    (public 
      [hit! (lambda (damage) (begin 
                         (send castle-dc draw-line 0 0 damage 30) 
                         (send this on-paint) 
                         (send my-castle hit! damage)))]) 
    (sequence (super-init parent)))) 

(define main-panel (make-object horizontal-panel% frame)) 
  
;;------left-panel
(define left-player-panel (make-object vertical-panel% main-panel null))
(send left-player-panel stretchable-width #t)
(define castle-1-view (make-object castle-viewer% left-player-panel (make-object bitmap% "castle1.gif" 'gif) castle-1)) 
(send castle-1-view stretchable-width #t)
(define player1-hp-txt-fld (make-object text-field% "Hit Pts Remaining:" left-player-panel 
  (lambda (txt-fld control-event)()) (number->string (send castle-1 get-hp)) '(single)))
;;-------center panel (weather-select panel and attack! button)------
(define center-panel (make-object vertical-panel% main-panel null)) 
(send center-panel stretchable-width #f) 
(define weather-select-box (make-object radio-box% "Weather" '("rain" "hail" "lightning" "tornado")
center-panel  (lambda (radio-box control-event)()) '(vertical))) 
(send weather-select-box stretchable-width #t)

(define attack (make-object button% "Attack!" center-panel (lambda(button control-event) 
       (begin 
;;player-1 (user)       
         (send castle-2-view hit! (send weather-dmg-tbl get-damage (random 10) (send weather-select-box get-selection)))
         (send weather-snd-fx play-snd-fx (send weather-select-box get-selection) #t)
         (send player2-hp-txt-fld set-value (number->string (send castle-2 get-hp)))
;;player-2 (computer)
         (sleep 3)
         (send weather-select-box set-selection (random num-weather-types))
         (send castle-1-view hit! (send weather-dmg-tbl get-damage (random 10) (send weather-select-box get-selection)))
         (send weather-snd-fx play-snd-fx (send weather-select-box get-selection) #t)
         (send player1-hp-txt-fld set-value (number->string (send castle-1 get-hp)))
         (cond ((send castle-1 dead?)
                (send game-result-txt-fld set-value "player 2 wins!"))
               ((send castle-2 dead?)
                (send game-result-txt-fld set-value "player 1 wins!")))
         )) null)) 

(define game-result-txt-fld (make-object text-field% "Game Result:" center-panel (lambda (txt-fld control-event)()) "" '(single)))                                                             
;;-----right-panel
(define right-player-panel (make-object vertical-panel% main-panel null))
(send right-player-panel stretchable-width #t)
(define castle-2-view (make-object castle-viewer% right-player-panel (make-object bitmap% "castle1.gif" 'gif) castle-2))  
(send castle-2-view stretchable-width #t) 
(define player2-hp-txt-fld (make-object text-field% "Hit Pts Remaining:" right-player-panel 
  (lambda (txt-fld control-event)()) (number->string (send castle-2 get-hp)) '(single)))
  
  
  
