#include <iostream>

#include <setjmp.h>

#include <GL/glut.h>

#include <scheme.h>
#include <sched.h>

using namespace std;

////////////////////////////////////////////////////////////////////////////////

static Scheme_Env    *env;
static jmp_buf toplevel;
static int is_multi_thread = 0;

////////////////////////////////////////////////////////////////////////////////

void notify_multithread(int on)
{
	is_multi_thread = on;
}

////////////////////////////////////////////////////////////////////////////////

int main(int argc, char *argv[])
{
	env = scheme_basic_env();
	
	scheme_notify_multithread = notify_multithread;

	if (scheme_setjmp(scheme_error_buf))
		cout << "Load error" << endl;

	scheme_load("t1.ss");
}
