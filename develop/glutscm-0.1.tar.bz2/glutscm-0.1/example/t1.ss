;; This example assumes you have glscm, the
;; OpenGL MzScheme extension, developed by Robert Kooima
;; and available at http://aoeu.snth.net/

(load-extension "../../glscm/glscm.so")
(load-extension "../glutscm.so")

(define (initGL)
  (glMatrixMode GL_PROJECTION)
  (glLoadIdentity)
  (glOrtho -1.0 1.0 -1.0 1.0 -10.0 10.0)
  (glClearColor 0.0 0.0 0.0 0.0))

(define (display-callback)
  (glMatrixMode GL_MODELVIEW)
  (glPushMatrix)
  (glEnable GL_DEPTH_TEST)
  (glClear (+ GL_COLOR_BUFFER_BIT
              GL_DEPTH_BUFFER_BIT))
  (glScalef .3 .3 .3)
  (glColor3f 1.0 1.0 1.0)
  (glutWireDodecahedron)
  (glPopMatrix)
  (glFlush)
  (glutSwapBuffers))

(define (passive-motion-callback x y)
  (printf "Moved: (~a, ~a)~n" x y))

(let ([escape (lambda () #f)])
  (define (keyboard-callback k x y)
    (cond
     ([(= (char->integer k) 27) (escape)])
     ([else
       (printf "<key: ~a> <x: ~a> <y: ~a>~n" k x y)])))
  
  (glutInit) 
  (initGL)
  (glutInitDisplayMode (+ GLUT_RGBA
                          GLUT_DEPTH
                          GLUT_DOUBLE))
  (glutInitWindowSize 500 500)
  (glutCreateWindow "Teste")
  (glutDisplayFunc display-callback)
  (glutKeyboardFunc keyboard-callback)
  (glutPassiveMotionFunc passive-motion-callback)
  
  (let/ec cont
    (set! escape cont)
    (glutMainLoop)))
