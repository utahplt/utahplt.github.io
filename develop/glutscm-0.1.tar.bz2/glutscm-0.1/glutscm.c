/*
 * GLUTSCM 0.1 -- A GLUT extension for MzScheme
 *
 * Copyright (C) 2003 Carlos E. Scheidegger 
 *                    <carlos.scheidegger@terra.com.br>
 *
 * This  library is  free  software; you  can  redistribute it  and/or
 * modify it under the terms  of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but
 * WITHOUT  ANY  WARRANTY;  without   even  the  implied  warranty  of
 * MERCHANTABILITY or  FITNESS FOR A  PARTICULAR PURPOSE. See  the GNU
 * Lesser General Public License for more details.
 *
 * This is based in GLSCM, by Robert Kooima
 */

#include "escheme.h"
#include <GL/glut.h>
#include <stdio.h>

/*****************************************************************************/
/* Error signaling                                                           */

static void scheme_type_error(const char *name, const char *type,
			      Scheme_Object *arg)
{
	scheme_signal_error("%s: expects type <%s>, given %V",
			    name, type, arg);
}

/*****************************************************************************/
/* Argument Handlers                                                         */

static int arg_bool(const char *name, Scheme_Object *arg)
{
	return (SCHEME_FALSEP(arg)) ? 0 : 1;
}

static int arg_int(const char *name, Scheme_Object *arg)
{
	if (SCHEME_INTP(arg))
		return SCHEME_INT_VAL(arg);
	else
		scheme_type_error(name, "exact integer", arg);

	return 0;
}

static int arg_pos(const char *name, Scheme_Object *arg)
{
	if (SCHEME_INTP(arg) && SCHEME_INT_VAL(arg) >= 0)
		return SCHEME_INT_VAL(arg);
	else
		scheme_type_error(name, "non-negative exact integer", arg);

	return 0;
}

static double arg_real(const char *name, Scheme_Object *arg)
{
	double x = 0.0;

	if (SCHEME_FLOATP(arg))
		x = scheme_real_to_double(arg);
	else
		scheme_type_error(name, "real", arg);

	return x;
}

static const char *arg_str(const char *name, Scheme_Object *arg)
{
	const char *x = NULL;

	if (SCHEME_STRINGP(arg))
		x = SCHEME_STR_VAL(arg);
	else
		scheme_type_error(name, "string", arg);

	return x;
}

static Scheme_Object* arg_proc(const char *name, Scheme_Object *arg)
{
	if (!(SCHEME_PROCP(arg)))
		scheme_type_error(name, "procedure", arg);

	return arg;
}

/*****************************************************************************/
/* Argument Macros                                                           */

#define arg_GLenum(data, arg)		\
	  ((GLenum)      arg_pos ((char *) data, arg))
#define arg_GLfloat(data, arg)		\
	  ((GLfloat)     arg_real((char *) data, arg))
#define arg_GLdouble(data, arg)		\
	  ((GLdouble)    arg_real((char *) data, arg))
#define arg_GLint(data, arg)		\
	  ((GLint)       arg_int ((char *) data, arg))

/*****************************************************************************/
/* Primitive functions                                                       */

/*****************************************************************************/
/* GLUT initialization sub-API                                               */

#define SCHEME_PROC(name) \
  static Scheme_Object *name(void *p, int c, Scheme_Object **v)

SCHEME_PROC(scm_Init)
{
	char argv0[] = "scmglut";
	int argc = c+1;

	/* it's a collectable malloc so that we don't leak
	   in case of type errors */

	char **argv = (char **) scheme_malloc_atomic((sizeof (char *)) * argc);
	int i;

	argv[0] = argv0;
	for (i = 0; i<c; i++)
		argv[i+1] = (char *) arg_str(p, v[i]);

	glutInit(&argc, argv);
	
	return scheme_void;
}

SCHEME_PROC(scm_InitDisplayMode)
{
	glutInitDisplayMode(arg_int(p, v[0]));
	return scheme_void;
}

SCHEME_PROC(scm_InitDisplayString)
{
	glutInitDisplayString(arg_str(p, v[0]));
	return scheme_void;
}

SCHEME_PROC(scm_InitWindowPosition)
{
	glutInitWindowPosition(arg_int(p, v[0]),
			       arg_int(p, v[1]));
	return scheme_void;
}

SCHEME_PROC(scm_InitWindowSize)
{
	glutInitWindowSize(arg_int(p, v[0]),
			   arg_int(p, v[1]));
	return scheme_void;
}

SCHEME_PROC(scm_MainLoop)
{
	glutMainLoop();
	return scheme_void;
}

/*****************************************************************************/
/* GLUT window sub-API                                                       */

/* todo: create window type */
SCHEME_PROC(scm_CreateWindow)
{
	int result = glutCreateWindow(arg_str(p, v[0]));	
	return scheme_make_integer(result);
}

SCHEME_PROC(scm_CreateSubWindow)
{
	int result = glutCreateSubWindow(arg_int(p, v[0]), /* will be a
							      window type
							      someday */
					 arg_int(p, v[1]),
					 arg_int(p, v[2]),
					 arg_int(p, v[3]),
					 arg_int(p, v[4]));
	return scheme_make_integer(result);
}

SCHEME_PROC(scm_DestroyWindow)
{
	glutDestroyWindow(arg_int(p, v[0])); /* will be a window
					      type someday */
	return scheme_void;
}

SCHEME_PROC(scm_PostRedisplay)
{
	glutPostRedisplay();
	return scheme_void;
}

SCHEME_PROC(scm_PostWindowRedisplay)
{
	glutPostWindowRedisplay(arg_int(p, v[0])); /* will be a window
						      type someday */
}

SCHEME_PROC(scm_SwapBuffers)
{
	glutSwapBuffers();
	return scheme_void;
}

SCHEME_PROC(scm_GetWindow)
{
	int win = glutGetWindow(); 					      
	return scheme_make_integer(win); /* will be a window type someday */
}

SCHEME_PROC(scm_SetWindow)
{
	glutSetWindow(arg_int(p, v[0])); /* will be a window type someday */
	return scheme_void;
}

SCHEME_PROC(scm_SetWindowTitle)
{
	glutSetWindowTitle(arg_str(p, v[0]));
	return scheme_void;
}

SCHEME_PROC(scm_SetIconTitle)
{
	glutSetIconTitle(arg_str(p, v[0]));
	return scheme_void;
}

SCHEME_PROC(scm_PositionWindow)
{
	glutPositionWindow(arg_int(p, v[0]),
			   arg_int(p, v[1]));
	return scheme_void;
}

SCHEME_PROC(scm_ReshapeWindow)
{
	glutReshapeWindow(arg_int(p, v[0]),
			  arg_int(p, v[1]));
	return scheme_void;
}

SCHEME_PROC(scm_PopWindow)
{
	glutPopWindow();
	return scheme_void;
}

SCHEME_PROC(scm_PushWindow)
{
	glutPushWindow();
	return scheme_void;
}

SCHEME_PROC(scm_IconifyWindow)
{
	glutIconifyWindow();
	return scheme_void;
}

SCHEME_PROC(scm_ShowWindow)
{
	glutShowWindow();
	return scheme_void;
}

SCHEME_PROC(scm_HideWindow)
{
	glutHideWindow();
	return scheme_void;
}

#if (GLUT_API_VERSION >= 3)
SCHEME_PROC(scm_FullScreen)
{
	glutFullScreen();
	return scheme_void;
}

SCHEME_PROC(scm_SetCursor)
{
	glutSetCursor(arg_int(p, v[0])); /* this should be a cursor type */
	return scheme_void;
}

#if (GLUT_API_VERSION >= 4 || GLUT_XLIB_IMPLEMENTATION >= 9)
SCHEME_PROC(scm_WarpPointer)
{
	glutWarpPointer(arg_int(p, v[0]),
			arg_int(p, v[1]));
	return scheme_void;
}
#endif

/*****************************************************************************/
/* GLUT overlay sub-API                                                      */

SCHEME_PROC(scm_EstablishOverlay)
{
	glutEstablishOverlay();
	return scheme_void;
}

SCHEME_PROC(scm_RemoveOverlay)
{
	glutRemoveOverlay();
	return scheme_void;
}

SCHEME_PROC(scm_UseLayer)
{
	glutUseLayer(arg_GLenum(p, v[0]));
	return scheme_void;
}

SCHEME_PROC(scm_PostOverlayRedisplay)
{
	glutPostOverlayRedisplay();
	return scheme_void;
}

#if (GLUT_API_VERSION >= 4 || GLUT_XLIB_IMPLEMENTATION >= 11)
SCHEME_PROC(scm_PostWindowOverlayRedisplay)
{
	glutPostWindowOverlayRedisplay(arg_int(p, v[0]));
	return scheme_void;
}
#endif

SCHEME_PROC(scm_ShowOverlay)
{
	glutShowOverlay();
	return scheme_void;
}

SCHEME_PROC(scm_HideOverlay)
{
	return scheme_void;
}
#endif

/*****************************************************************************/
/* GLUT menu sub-API                                                         */

/* Todo */

SCHEME_PROC(scm_CreateMenu)
{
	return scheme_void;
}

SCHEME_PROC(scm_DestroyMenu)
{
	glutDestroyMenu(arg_int(p, v[0]));
	return scheme_void;
}

SCHEME_PROC(scm_GetMenu)
{
	int menu = glutGetMenu();
	return scheme_make_integer(menu);
}

SCHEME_PROC(scm_SetMenu)
{
	glutSetMenu(arg_int(p, v[0]));
	return scheme_void;
}

SCHEME_PROC(scm_AddMenuEntry)
{
	glutAddMenuEntry(arg_str(p, v[0]),
			 arg_int(p, v[1]));
	return scheme_void;
}

SCHEME_PROC(scm_AddSubMenu)
{
	glutAddSubMenu(arg_str(p, v[0]),
		       arg_int(p, v[1]));
	return scheme_void;
}

SCHEME_PROC(scm_ChangeToMenuEntry)
{
	glutChangeToMenuEntry(arg_int(p, v[0]),
			      arg_str(p, v[1]),
			      arg_int(p, v[2]));
	return scheme_void;
}

SCHEME_PROC(scm_ChangeToSubMenu)
{
	glutChangeToSubMenu(arg_int(p, v[0]),
			    arg_str(p, v[1]),
			    arg_int(p, v[2]));			 
	return scheme_void;
}

SCHEME_PROC(scm_RemoveMenuItem)
{
	glutRemoveMenuItem(arg_int(p, v[0]));
	return scheme_void;
}

SCHEME_PROC(scm_AttachMenu)
{
	glutAttachMenu(arg_int(p, v[0]));
	return scheme_void;
}

SCHEME_PROC(scm_DetachMenu)
{
	glutDetachMenu(arg_int(p, v[0]));
	return scheme_void;
}

/*****************************************************************************/
/* GLUT window callback sub-API                                              */

static Scheme_Object *displayFuncCallBack;
static void scm_internal_DisplayFunc()
{
	scheme_apply(displayFuncCallBack, 0, NULL);
}

SCHEME_PROC(scm_DisplayFunc)
{
	displayFuncCallBack = arg_proc(p, v[0]);
	glutDisplayFunc(scm_internal_DisplayFunc);
	return scheme_void;
}

/*****************************************************************************/

static Scheme_Object *keyboardFuncCallBack;
static void scm_internal_KeyboardFunc(unsigned char k, int x, int y)
{
	Scheme_Object *args[3] = {
		scheme_make_character(k),
		scheme_make_integer(x),
		scheme_make_integer(y)
	};

	scheme_apply(keyboardFuncCallBack, 3, args);
}

SCHEME_PROC(scm_KeyboardFunc)
{
	keyboardFuncCallBack = arg_proc(p, v[0]);
	glutKeyboardFunc(scm_internal_KeyboardFunc);
	return scheme_void;
}

/*****************************************************************************/

static Scheme_Object *reshapeFuncCallBack;
static void scm_internal_ReshapeFunc(int width, int height)
{
	Scheme_Object *args[2] = {
		scheme_make_integer(width),
		scheme_make_integer(height)
	};

	scheme_apply(reshapeFuncCallBack, 2, args);
}

SCHEME_PROC(scm_ReshapeFunc)
{
	reshapeFuncCallBack = arg_proc(p, v[0]);
	glutReshapeFunc(scm_internal_ReshapeFunc);
	return scheme_void;
}

/*****************************************************************************/

static Scheme_Object *mouseFuncCallBack;
static void scm_internal_MouseFunc(int button, int state, int x, int y)
{
	Scheme_Object *args[4] = {
		scheme_make_integer(button),
		scheme_make_integer(state),
		scheme_make_integer(x),
		scheme_make_integer(y),
	};

	scheme_apply(mouseFuncCallBack, 4, args);
}

SCHEME_PROC(scm_MouseFunc)
{
	mouseFuncCallBack = arg_proc(p, v[0]);
	glutMouseFunc(scm_internal_MouseFunc);
	return scheme_void;
}

/*****************************************************************************/

static Scheme_Object *motionFuncCallBack;
static void scm_internal_MotionFunc(int x, int y)
{
	Scheme_Object *args[2] = {
		scheme_make_integer(x),
		scheme_make_integer(y),
	};

	scheme_apply(motionFuncCallBack, 2, args);
}

SCHEME_PROC(scm_MotionFunc)
{
	motionFuncCallBack = arg_proc(p, v[0]);
	glutMotionFunc(scm_internal_MotionFunc);
	return scheme_void;
}

/*****************************************************************************/

static Scheme_Object *passiveMotionFuncCallBack;
static void scm_internal_PassiveMotionFunc(int x, int y)
{
	Scheme_Object *args[2] = {
		scheme_make_integer(x),
		scheme_make_integer(y),
	};

	scheme_apply(passiveMotionFuncCallBack, 2, args);
}

SCHEME_PROC(scm_PassiveMotionFunc)
{
	passiveMotionFuncCallBack = arg_proc(p, v[0]);
	glutPassiveMotionFunc(scm_internal_PassiveMotionFunc);
	return scheme_void;
}

/*****************************************************************************/

static Scheme_Object *entryFuncCallBack;
static void scm_internal_EntryFunc(int state)
{
	Scheme_Object *args[1] = {
		scheme_make_integer(state),
	};

	scheme_apply(entryFuncCallBack, 1, args);
}

SCHEME_PROC(scm_EntryFunc)
{
	entryFuncCallBack = arg_proc(p, v[0]);
	glutEntryFunc(scm_internal_EntryFunc);
	return scheme_void;
}

/*****************************************************************************/

static Scheme_Object *visibilityFuncCallBack;
static void scm_internal_VisibilityFunc(int state)
{
	Scheme_Object *args[1] = {
		scheme_make_integer(state),
	};
	
	scheme_apply(visibilityFuncCallBack, 1, args);
}

SCHEME_PROC(scm_VisibilityFunc)
{
	visibilityFuncCallBack = arg_proc(p, v[0]);
	glutEntryFunc(scm_internal_VisibilityFunc);
	return scheme_void;
}

/*****************************************************************************/

static Scheme_Object *idleFuncCallBack;
static void scm_internal_IdleFunc()
{
	if (scheme_setjmp(scheme_error_buf) == 0)
		scheme_apply(idleFuncCallBack, 0, NULL);
}

SCHEME_PROC(scm_IdleFunc)
{
	idleFuncCallBack = arg_proc(p, v[0]);
	glutEntryFunc(scm_internal_IdleFunc);
	return scheme_void;
}

/*****************************************************************************/

static Scheme_Object *menuStateFuncCallBack;
static void scm_internal_MenuStateFunc(int state)
{
	Scheme_Object *args[1] = {
		scheme_make_integer(state),
	};
	scheme_apply(menuStateFuncCallBack, 1, args);
}

SCHEME_PROC(scm_MenuStateFunc)
{
	menuStateFuncCallBack = arg_proc(p, v[0]);
	glutMenuStateFunc(scm_internal_MenuStateFunc);
	return scheme_void;
}

/*****************************************************************************/

#if (GLUT_API_VERSION >= 2)

static Scheme_Object *specialFuncCallBack;
static void scm_internal_SpecialFunc(int key, int x, int y)
{
	Scheme_Object *args[3] = {
		scheme_make_integer(key),
		scheme_make_integer(x),
		scheme_make_integer(y),
	};
	scheme_apply(specialFuncCallBack, 3, args);
}

SCHEME_PROC(scm_SpecialFunc)
{
	specialFuncCallBack = arg_proc(p, v[0]);
	glutSpecialFunc(scm_internal_SpecialFunc);
	return scheme_void;
}

/*****************************************************************************/

static Scheme_Object *spaceballMotionFuncCallBack;
static void scm_internal_SpaceballMotionFunc(int x, int y, int z)
{
	Scheme_Object *args[3] = {
		scheme_make_integer(x),
		scheme_make_integer(y),
		scheme_make_integer(z),
	};
	scheme_apply(spaceballMotionFuncCallBack, 3, args);
}

SCHEME_PROC(scm_SpaceballMotionFunc)
{
	spaceballMotionFuncCallBack = arg_proc(p, v[0]);
	glutSpaceballMotionFunc(scm_internal_SpaceballMotionFunc);
	return scheme_void;
}

/*****************************************************************************/

static Scheme_Object *spaceballRotateFuncCallBack;
static void scm_internal_SpaceballRotateFunc(int x, int y, int z)
{
	Scheme_Object *args[3] = {
		scheme_make_integer(x),
		scheme_make_integer(y),
		scheme_make_integer(z),
	};
	scheme_apply(spaceballRotateFuncCallBack, 3, args);
}

SCHEME_PROC(scm_SpaceballRotateFunc)
{
	spaceballRotateFuncCallBack = arg_proc(p, v[0]);
	glutSpaceballRotateFunc(scm_internal_SpaceballRotateFunc);
	return scheme_void;
}

/*****************************************************************************/

static Scheme_Object *spaceballButtonFuncCallBack;
static void scm_internal_SpaceballButtonFunc(int button, int state)
{
	Scheme_Object *args[2] = {
		scheme_make_integer(button),
		scheme_make_integer(state),
	};
	scheme_apply(spaceballButtonFuncCallBack, 2, args);
}

SCHEME_PROC(scm_SpaceballButtonFunc)
{
	spaceballButtonFuncCallBack = arg_proc(p, v[0]);
	glutSpaceballButtonFunc(scm_internal_SpaceballButtonFunc);
	return scheme_void;
}

/*****************************************************************************/

static Scheme_Object *buttonBoxFuncCallBack;
static void scm_internal_ButtonBoxFunc(int button, int state)
{
	Scheme_Object *args[2] = {
		scheme_make_integer(button),
		scheme_make_integer(state),
	};
	scheme_apply(buttonBoxFuncCallBack, 2, args);
}

SCHEME_PROC(scm_ButtonBoxFunc)
{
	buttonBoxFuncCallBack = arg_proc(p, v[0]);
	glutButtonBoxFunc(scm_internal_ButtonBoxFunc);
	return scheme_void;
}

/*****************************************************************************/

static Scheme_Object *dialsFuncCallBack;
static void scm_internal_DialsFunc(int dial, int value)
{
	Scheme_Object *args[2] = {
		scheme_make_integer(dial),
		scheme_make_integer(value),
	};
	scheme_apply(dialsFuncCallBack, 2, args);
}

SCHEME_PROC(scm_DialsFunc)
{
	dialsFuncCallBack = arg_proc(p, v[0]);
	glutDialsFunc(scm_internal_DialsFunc);
	return scheme_void;
}

/*****************************************************************************/

static Scheme_Object *tabletMotionFuncCallBack;
static void scm_internal_TabletMotionFunc(int x, int y)
{
	Scheme_Object *args[2] = {
		scheme_make_integer(x),
		scheme_make_integer(y),
	};
	scheme_apply(tabletMotionFuncCallBack, 2, args);
}

SCHEME_PROC(scm_TabletMotionFunc)
{
	tabletMotionFuncCallBack = arg_proc(p, v[0]);
	glutTabletMotionFunc(scm_internal_TabletMotionFunc);
	return scheme_void;
}

/*****************************************************************************/

static Scheme_Object *tabletButtonFuncCallBack;
static void scm_internal_TabletButtonFunc(int button, int state, int x, int y)
{
	Scheme_Object *args[4] = {
		scheme_make_integer(button),
		scheme_make_integer(state),
		scheme_make_integer(x),
		scheme_make_integer(y),
	};
	scheme_apply(tabletButtonFuncCallBack, 4, args);
}

SCHEME_PROC(scm_TabletButtonFunc)
{
	tabletButtonFuncCallBack = arg_proc(p, v[0]);
	glutTabletButtonFunc(scm_internal_TabletButtonFunc);
	return scheme_void;
}

/*****************************************************************************/

#if (GLUT_API_VERSION >= 3)

static Scheme_Object *menuStatusFuncCallBack;
static void scm_internal_MenuStatusFunc(int status, int x, int y)
{
	Scheme_Object *args[3] = {	
		scheme_make_integer(status),
		scheme_make_integer(x),
		scheme_make_integer(y),
	};
	scheme_apply(menuStatusFuncCallBack, 3, args);
}

SCHEME_PROC(scm_MenuStatusFunc)
{
	menuStatusFuncCallBack = arg_proc(p, v[0]);
	glutMenuStatusFunc(scm_internal_MenuStatusFunc);
	return scheme_void;
}

/*****************************************************************************/

static Scheme_Object *overlayDisplayFuncCallBack;
static void scm_internal_OverlayDisplayFunc()
{
	scheme_apply(overlayDisplayFuncCallBack, 0, NULL);
}

SCHEME_PROC(scm_OverlayDisplayFunc)
{
	overlayDisplayFuncCallBack = arg_proc(p, v[0]);
	glutOverlayDisplayFunc(scm_internal_OverlayDisplayFunc);
	return scheme_void;
}

/*****************************************************************************/

#if (GLUT_API_VERSION >= 4 || GLUT_XLIB_IMPLEMENTATION >= 9)

static Scheme_Object *windowStatusFuncCallBack;
static void scm_internal_WindowStatusFunc(int status)
{
	Scheme_Object *args[1] = {	
		scheme_make_integer(status),
	};
	scheme_apply(windowStatusFuncCallBack, 1, args);
}

SCHEME_PROC(scm_WindowStatusFunc)
{
	windowStatusFuncCallBack = arg_proc(p, v[0]);
	glutWindowStatusFunc(scm_internal_WindowStatusFunc);
	return scheme_void;
}

#endif

/*****************************************************************************/

#if (GLUT_API_VERSION >= 4 || GLUT_XLIB_IMPLEMENTATION >= 13)

static Scheme_Object *keyboardUpFuncCallBack;
static void scm_internal_KeyboardUpFunc(unsigned char key, int x, int y)
{
	Scheme_Object *args[3] = {
		scheme_make_character(key),
		scheme_make_integer(x),
		scheme_make_integer(y),
	};
	scheme_apply(keyboardUpFuncCallBack, 3, args);
}

SCHEME_PROC(scm_KeyboardUpFunc)
{
	keyboardUpFuncCallBack = arg_proc(p, v[0]);
	glutKeyboardUpFunc(scm_internal_KeyboardUpFunc);
	return scheme_void;
}

/*****************************************************************************/

static Scheme_Object *specialUpFuncCallBack;
static void scm_internal_SpecialUpFunc(int key, int x, int y)
{
	Scheme_Object *args[3] = {
		scheme_make_integer(key),
		scheme_make_integer(x),
		scheme_make_integer(y),
	};
	scheme_apply(specialUpFuncCallBack, 3, args);
}

SCHEME_PROC(scm_SpecialUpFunc)
{
	specialUpFuncCallBack = arg_proc(p, v[0]);
	glutSpecialUpFunc(scm_internal_SpecialUpFunc);
	return scheme_void;
}

/*****************************************************************************/

static Scheme_Object *joystickFuncCallBack;
static void scm_internal_JoystickFunc(unsigned int buttonMask, int x, int y, int z)
{
	Scheme_Object *args[4] = {
		scheme_make_integer(buttonMask),
		scheme_make_integer(x),
		scheme_make_integer(y),
		scheme_make_integer(z),
	};
	scheme_apply(joystickFuncCallBack, 4, args);
}

SCHEME_PROC(scm_JoystickFunc)
{
	joystickFuncCallBack = arg_proc(p, v[0]);
	int pollInt = arg_int(p, v[1]);
	glutJoystickFunc(scm_internal_JoystickFunc, pollInt);
	return scheme_void;
}

#endif
#endif
#endif

/*****************************************************************************/
/* GLUT color index sub-API                                                  */

SCHEME_PROC(scm_SetColor)
{
	glutSetColor(arg_int(p, v[0]),
		     arg_GLfloat(p, v[1]),		     
		     arg_GLfloat(p, v[2]),
		     arg_GLfloat(p, v[3]));	     
		     
	return scheme_void;
}

SCHEME_PROC(scm_GetColor)
{
	GLfloat result = glutGetColor(arg_int(p, v[0]),
				      arg_int(p, v[1]));
	return scheme_make_double(result);
}

SCHEME_PROC(scm_CopyColormap)
{
	glutCopyColormap(arg_int(p, v[0]));
	return scheme_void;
}

/*****************************************************************************/
/* GLUT state retrieval sub-API                                              */

SCHEME_PROC(scm_Get)
{
	int get = glutGet(arg_GLenum(p, v[0]));
	return scheme_make_integer(get);
}

SCHEME_PROC(scm_DeviceGet)
{
	int deviceGet = glutDeviceGet(arg_GLenum(p, v[0]));
	return scheme_make_integer(deviceGet);
}


#if (GLUT_API_VERSION >= 2)

/*****************************************************************************/
/* GLUT extension support sub-API                                            */

SCHEME_PROC(scm_ExtensionSupported)
{
	int extensionSupported = glutExtensionSupported(arg_str(p, v[0]));

	return (extensionSupported ?
		scheme_true :
		scheme_false);
}

#endif

#if (GLUT_API_VERSION >= 3)
SCHEME_PROC(scm_GetModifiers)
{
	int modifiers = glutGetModifiers();
	return scheme_make_integer(modifiers);
}

SCHEME_PROC(scm_LayerGet)
{
	int layerGet = glutLayerGet(arg_GLenum(p, v[0]));
	return scheme_make_integer(layerGet);
}
#endif


/*****************************************************************************/
/* GLUT font sub-API                                                         */

/* TODO! */


/*****************************************************************************/
/* GLUT pre-built models sub-API                                             */

SCHEME_PROC(scm_WireSphere)
{
	glutWireSphere(arg_GLdouble(p, v[0]),
		       arg_GLint(p, v[1]),
		       arg_GLint(p, v[2]));
	return scheme_void;
}

SCHEME_PROC(scm_SolidSphere)
{
	glutSolidSphere(arg_GLdouble(p, v[0]),
			arg_GLint(p, v[1]),
			arg_GLint(p, v[2]));
	return scheme_void;
}

SCHEME_PROC(scm_WireCone)
{
	glutWireCone(arg_GLdouble(p, v[0]),
		     arg_GLint(p, v[1]),
		     arg_GLint(p, v[2]),
		     arg_GLint(p, v[3]));
	return scheme_void;
}

SCHEME_PROC(scm_SolidCone)
{
	glutSolidCone(arg_GLdouble(p, v[0]),
		      arg_GLint(p, v[1]),
		      arg_GLint(p, v[2]),
		      arg_GLint(p, v[3]));
	return scheme_void;
}

SCHEME_PROC(scm_WireCube)
{
	glutWireCube(arg_GLdouble(p, v[0]));
	return scheme_void;
}

SCHEME_PROC(scm_SolidCube)
{
	glutSolidCube(arg_GLdouble(p, v[0]));
	return scheme_void;
}

SCHEME_PROC(scm_WireTorus)
{
	glutWireTorus(arg_GLdouble(p, v[0]),
		      arg_GLdouble(p, v[1]),
		      arg_GLint(p, v[2]),
		      arg_GLint(p, v[3]));
	return scheme_void;
}

SCHEME_PROC(scm_SolidTorus)
{
	glutSolidTorus(arg_GLdouble(p, v[0]),
		       arg_GLdouble(p, v[1]),
		       arg_GLint(p, v[2]),
		       arg_GLint(p, v[3]));
	return scheme_void;
}

SCHEME_PROC(scm_WireDodecahedron)
{
	glutWireDodecahedron();
	return scheme_void;
}

SCHEME_PROC(scm_SolidDodecahedron)
{
	glutSolidDodecahedron();
	return scheme_void;
}

SCHEME_PROC(scm_WireTeapot)
{
	glutWireTeapot(arg_GLdouble(p,v[0]));
	return scheme_void;
}

SCHEME_PROC(scm_SolidTeapot)
{
	glutSolidTeapot(arg_GLdouble(p,v[0]));
	return scheme_void;
}

SCHEME_PROC(scm_WireOctahedron)
{
	glutWireOctahedron();
	return scheme_void;
}

SCHEME_PROC(scm_SolidOctahedron)
{
	glutSolidOctahedron();
	return scheme_void;
}

SCHEME_PROC(scm_WireTetrahedron)
{
	glutWireTetrahedron();
	return scheme_void;
}

SCHEME_PROC(scm_SolidTetrahedron)
{
	glutSolidTetrahedron();
	return scheme_void;
}

SCHEME_PROC(scm_WireIcosahedron)
{
	glutWireIcosahedron();
	return scheme_void;
}

SCHEME_PROC(scm_SolidIcosahedron)
{
	glutSolidIcosahedron();
	return scheme_void;
}

#if (GLUT_API_VERSION >= 4 || GLUT_XLIB_IMPLEMENTATION >= 9)
/*****************************************************************************/
/* GLUT video resize sub-API                                                 */

SCHEME_PROC(scm_VideoResizeGet)
{
	int videoResizeGet = glutVideoResizeGet(arg_GLenum(p, v[0]));
	return scheme_make_integer(videoResizeGet);
}

SCHEME_PROC(scm_SetupVideoResizing)
{
	glutSetupVideoResizing();
	return scheme_void;
}

SCHEME_PROC(scm_StopVideoResizing)
{
	glutStopVideoResizing();
	return scheme_void;
}

SCHEME_PROC(scm_VideoResize)
{
	glutVideoResize(arg_int(p, v[0]),
			arg_int(p, v[1]),
			arg_int(p, v[2]),
			arg_int(p, v[3]));
	return scheme_void;
}

SCHEME_PROC(scm_VideoPan)
{
	glutVideoPan(arg_int(p, v[0]),
		     arg_int(p, v[1]),
		     arg_int(p, v[2]),
		     arg_int(p, v[3]));
	return scheme_void;
}

/*****************************************************************************/
/* GLUT debugging sub-API                                                    */

SCHEME_PROC(scm_ReportErrors)
{
	glutReportErrors();
	return scheme_void;
}

#endif


#if (GLUT_API_VERSION >= 4 || GLUT_XLIB_IMPLEMENTATION >= 13)
/*****************************************************************************/
/* GLUT device control sub-API                                               */

SCHEME_PROC(scm_IgnoreKeyRepeat)
{
	glutIgnoreKeyRepeat(arg_int(p, v[0]));
	return scheme_void;
}

SCHEME_PROC(scm_SetKeyRepeat)
{
	glutSetKeyRepeat(arg_int(p, v[0]));
	return scheme_void;
}

SCHEME_PROC(scm_ForceJoystickFunc)
{
	glutForceJoystickFunc();
	return scheme_void;
}

/*****************************************************************************/
/* GLUT device control sub-API                                               */

SCHEME_PROC(scm_GameModeString)
{
	glutGameModeString(arg_str(p, v[0]));
	return scheme_void;
}

SCHEME_PROC(scm_EnterGameMode)
{
	int enterGameMode = glutEnterGameMode();
	return scheme_make_integer(enterGameMode);
}

SCHEME_PROC(scm_LeaveGameMode)
{
	glutLeaveGameMode();
	return scheme_void;
}

SCHEME_PROC(scm_GameModeGet)
{
	glutGameModeGet(arg_GLenum(p, v[0]));
	return scheme_void;
}

#endif


/*****************************************************************************/

struct scm_prim
{
	char *name;
	Scheme_Closed_Prim *prim;
	int mina;
	int maxa;
};

static const struct scm_prim scm_prim[] = {
	{ "glutInit", scm_Init, 0, -1 },
	{ "glutInitDisplayMode", scm_InitDisplayMode, 1, 1 },
	{ "glutInitWindowPosition", scm_InitWindowPosition, 2, 2 },
	{ "glutInitWindowSize", scm_InitWindowSize, 2, 2 },
	{ "glutMainLoop", scm_MainLoop, 0, 0 },
	{ "glutCreateWindow", scm_CreateWindow, 1, 1 },
	{ "glutCreateSubWindow", scm_CreateSubWindow, 5, 5 },
	{ "glutDestroyWindow", scm_DestroyWindow, 1, 1 },
	{ "glutPostRedisplay", scm_PostRedisplay, 0, 0 },
	{ "glutPostWindowRedisplay", scm_PostWindowRedisplay, 1, 1 },
	{ "glutSwapBuffers", scm_SwapBuffers, 0, 0 },
	{ "glutGetWindow", scm_GetWindow, 0, 0 },
	{ "glutSetWindow", scm_SetWindow, 1, 1 },
	{ "glutSetWindowTitle", scm_SetWindowTitle, 1, 1 },
	{ "glutSetIconTitle", scm_SetIconTitle, 1, 1 },
	{ "glutPositionWindow", scm_PositionWindow, 2, 2 },
	{ "glutReshapeWindow", scm_ReshapeWindow, 2, 2 },
	{ "glutPopWindow", scm_PopWindow, 0, 0 },
	{ "glutPushWindow", scm_PushWindow, 0, 0 },
	{ "glutShowWindow", scm_ShowWindow, 0, 0 },
	{ "glutHideWindow", scm_HideWindow, 0, 0 },
#if (GLUT_API_VERSION >= 3)
	{ "glutFullScreen", scm_FullScreen, 0, 0 },
	{ "glutSetCursor", scm_SetCursor, 1, 1 },
#if (GLUT_API_VERSION >= 4 || GLUT_XLIB_IMPLEMENTATION >= 9)
	{ "glutWarpPointer", scm_WarpPointer, 2, 2 },
#endif
	{ "glutEstablishOverlay", scm_EstablishOverlay, 0, 0 },
	{ "glutRemoveOverlay", scm_RemoveOverlay, 0, 0 },
	{ "glutUseLayer", scm_UseLayer, 1, 1 },
	{ "glutPostOverlayRedisplay", scm_PostOverlayRedisplay, 0, 0 },
#if (GLUT_API_VERSION >= 4 || GLUT_XLIB_IMPLEMENTATION >= 11)
	{ "glutPostWindowOverlayRedisplay", scm_PostWindowOverlayRedisplay, 1, 1 },
#endif
	{ "glutShowOverlay", scm_ShowOverlay, 0, 0 },
	{ "glutHideOverlay", scm_HideOverlay, 0, 0 },
#endif
/*	{ "glutCreateMenu", scm_CreateMenu, 1, 1 },*/
	{ "glutDestroyMenu", scm_DestroyMenu, 1, 1 },
	{ "glutGetMenu", scm_GetMenu, 0, 0 },
	{ "glutSetMenu", scm_SetMenu, 1, 1 },
	{ "glutAddMenuEntry", scm_AddMenuEntry, 2, 2 },
	{ "glutAddSubMenu", scm_AddSubMenu, 2, 2 },
	{ "glutChangeToMenuEntry", scm_ChangeToMenuEntry, 3, 3 },
	{ "glutChangeToSubMenu", scm_ChangeToSubMenu, 3, 3 },
	{ "glutRemoveMenuItem", scm_RemoveMenuItem, 1, 1 },
	{ "glutAttachMenu", scm_AttachMenu, 1, 1 },
	{ "glutDetachMenu", scm_DetachMenu, 1, 1 },


	{ "glutDisplayFunc", scm_DisplayFunc, 1, 1 },
	{ "glutReshapeFunc", scm_ReshapeFunc, 1, 1 },
	{ "glutKeyboardFunc", scm_KeyboardFunc, 1, 1 },
	{ "glutMouseFunc", scm_MouseFunc, 1, 1},
	{ "glutMotionFunc", scm_MotionFunc, 1, 1},
	{ "glutPassiveMotionFunc", scm_PassiveMotionFunc, 1, 1},
	{ "glutEntryFunc", scm_EntryFunc, 1, 1},
	{ "glutVisibilityFunc", scm_VisibilityFunc, 1, 1},
	{ "glutIdleFunc", scm_IdleFunc, 1, 1},
	{ "glutMenuStateFunc", scm_MenuStateFunc, 1, 1},
	{ "glutSpecialFunc", scm_SpecialFunc, 1, 1},
	{ "glutSpaceballMotionFunc", scm_SpaceballMotionFunc, 1, 1},
	{ "glutSpaceballRotateFunc", scm_SpaceballRotateFunc, 1, 1},
	{ "glutSpaceballButtonFunc", scm_SpaceballButtonFunc, 1, 1},
	{ "glutDialsFunc", scm_DialsFunc, 1, 1},
	{ "glutTabletMotionFunc", scm_TabletMotionFunc, 1, 1},
	{ "glutTabletButtonFunc", scm_TabletButtonFunc, 1, 1},
	{ "glutMenuStatusFunc", scm_MenuStatusFunc, 1, 1},
	{ "glutOverlayDisplayFunc", scm_OverlayDisplayFunc, 1, 1},
	{ "glutWindowStatusFunc", scm_WindowStatusFunc, 1, 1},
	{ "glutKeyboardUpFunc", scm_KeyboardUpFunc, 1, 1},
	{ "glutSpecialUpFunc", scm_SpecialUpFunc, 1, 1},
	{ "glutJoystickFunc", scm_JoystickFunc, 2, 2},

	{ "glutSetColor", scm_SetColor, 3, 3 },
	{ "glutGetColor", scm_GetColor, 2, 2 },
	{ "glutCopyColormap", scm_CopyColormap, 1, 1 },
	{ "glutGet", scm_Get, 1, 1 },
	{ "glutDeviceGet", scm_DeviceGet, 2, 2 },
#if (GLUT_API_VERSION >= 2)
	{ "glutExtensionSupported", scm_ExtensionSupported, 1, 1 },
#endif
#if (GLUT_API_VERSION >= 3)
	{ "glutGetModifiers", scm_GetModifiers, 0, 0 },
	{ "glutLayerGet", scm_LayerGet, 1, 1 },
#endif
/* Todo! Font sub-API */
	{ "glutWireSphere", scm_WireSphere, 3, 3 },
	{ "glutSolidSphere", scm_SolidSphere, 3, 3 },
	{ "glutWireCone", scm_WireCone, 4, 4 },
	{ "glutSolidCone", scm_SolidCone, 4, 4 },
	{ "glutWireCube", scm_WireCube, 1, 1 },
	{ "glutSolidCube", scm_SolidCube, 1, 1 },
	{ "glutWireTorus", scm_WireTorus, 4, 4 },
	{ "glutSolidTorus", scm_SolidTorus, 4, 4 },
	{ "glutWireDodecahedron", scm_WireDodecahedron, 0, 0 },
	{ "glutSolidDodecahedron", scm_SolidDodecahedron, 0, 0 },
	{ "glutWireTeapot", scm_WireTeapot, 1, 1 },
	{ "glutSolidTeapot", scm_SolidTeapot, 1, 1 },
	{ "glutWireOctahedron", scm_WireOctahedron, 0, 0 },
	{ "glutSolidOctahedron", scm_SolidOctahedron, 0, 0 },
	{ "glutWireTetrahedron", scm_WireTetrahedron, 0, 0 },
	{ "glutSolidTetrahedron", scm_SolidTetrahedron, 0, 0 },
	{ "glutWireIcosahedron", scm_WireIcosahedron, 0, 0 },
	{ "glutSolidIcosahedron", scm_SolidIcosahedron, 0, 0 },
#if (GLUT_API_VERSION >= 4 || GLUT_XLIB_IMPLEMENTATION >= 9)
	{ "glutVideoResizeGet", scm_VideoResizeGet, 1, 1 },
	{ "glutSetupVideoResizing", scm_SetupVideoResizing, 0, 0 },
	{ "glutStopVideoResizing", scm_StopVideoResizing, 0, 0 },
	{ "glutVideoResize", scm_VideoResize, 4, 4 },
	{ "glutVideoPan", scm_VideoPan, 4, 4 },
	{ "glutReportErrors", scm_ReportErrors, 0, 0 },
#endif
#if (GLUT_API_VERSION >= 4 || GLUT_XLIB_IMPLEMENTATION >= 13)
	{ "glutIgnoreKeyRepeat", scm_IgnoreKeyRepeat, 1, 1 },
	{ "glutSetKeyRepeat", scm_SetKeyRepeat, 1, 1 },
	{ "glutForceJoystickFunc", scm_ForceJoystickFunc, 0, 0 },
	{ "glutGameModeString", scm_GameModeString, 1, 1 },
	{ "glutEnterGameMode", scm_EnterGameMode, 0, 0 },
	{ "glutLeaveGameMode", scm_LeaveGameMode, 0, 0 },
	{ "glutGameModeGet", scm_GameModeGet, 1, 1 },
#endif
};

/*****************************************************************************/
/* Enumerations                                                              */

#define MAKE_ENUM(e) { #e, e }

struct scm_enum
{
	const char *name;
	GLenum val;
};

static const struct scm_enum scm_enum[] = {
	
	MAKE_ENUM(GLUT_API_VERSION),
	MAKE_ENUM(GLUT_XLIB_IMPLEMENTATION),
	MAKE_ENUM(GLUT_RGB),
	MAKE_ENUM(GLUT_RGBA),
	MAKE_ENUM(GLUT_INDEX),
	MAKE_ENUM(GLUT_SINGLE),
	MAKE_ENUM(GLUT_DOUBLE),
	MAKE_ENUM(GLUT_ACCUM),
	MAKE_ENUM(GLUT_ALPHA),
	MAKE_ENUM(GLUT_DEPTH),
	MAKE_ENUM(GLUT_STENCIL),
#if (GLUT_API_VERSION >= 2)
	MAKE_ENUM(GLUT_MULTISAMPLE),
	MAKE_ENUM(GLUT_STEREO),
#endif
#if (GLUT_API_VERSION >= 3)
	MAKE_ENUM(GLUT_LUMINANCE),
#endif
	MAKE_ENUM(GLUT_LEFT_BUTTON),
	MAKE_ENUM(GLUT_MIDDLE_BUTTON),
	MAKE_ENUM(GLUT_RIGHT_BUTTON),
	MAKE_ENUM(GLUT_DOWN),
	MAKE_ENUM(GLUT_UP),
#if (GLUT_API_VERSION >= 2)
	MAKE_ENUM(GLUT_KEY_F1),
	MAKE_ENUM(GLUT_KEY_F2),
	MAKE_ENUM(GLUT_KEY_F3),
	MAKE_ENUM(GLUT_KEY_F4),
	MAKE_ENUM(GLUT_KEY_F5),
	MAKE_ENUM(GLUT_KEY_F6),
	MAKE_ENUM(GLUT_KEY_F7),
	MAKE_ENUM(GLUT_KEY_F8),
	MAKE_ENUM(GLUT_KEY_F9),
	MAKE_ENUM(GLUT_KEY_F10),
	MAKE_ENUM(GLUT_KEY_F11),
	MAKE_ENUM(GLUT_KEY_F12),
	MAKE_ENUM(GLUT_KEY_LEFT),
	MAKE_ENUM(GLUT_KEY_UP),
	MAKE_ENUM(GLUT_KEY_RIGHT),
	MAKE_ENUM(GLUT_KEY_DOWN),
	MAKE_ENUM(GLUT_KEY_PAGE_UP),
	MAKE_ENUM(GLUT_KEY_PAGE_DOWN),
	MAKE_ENUM(GLUT_KEY_HOME),
	MAKE_ENUM(GLUT_KEY_END),
	MAKE_ENUM(GLUT_KEY_INSERT),
#endif
	MAKE_ENUM(GLUT_LEFT),
	MAKE_ENUM(GLUT_ENTERED),
	MAKE_ENUM(GLUT_MENU_NOT_IN_USE),
	MAKE_ENUM(GLUT_MENU_IN_USE),
	MAKE_ENUM(GLUT_NOT_VISIBLE),
	MAKE_ENUM(GLUT_VISIBLE),
	MAKE_ENUM(GLUT_HIDDEN),
	MAKE_ENUM(GLUT_FULLY_RETAINED),
	MAKE_ENUM(GLUT_PARTIALLY_RETAINED),
	MAKE_ENUM(GLUT_FULLY_COVERED),
	MAKE_ENUM(GLUT_RED),
	MAKE_ENUM(GLUT_GREEN),
	MAKE_ENUM(GLUT_BLUE),
	MAKE_ENUM(GLUT_NORMAL),
	MAKE_ENUM(GLUT_OVERLAY),

/* todo: do sthing about the font stuff */

	MAKE_ENUM(GLUT_WINDOW_X),
	MAKE_ENUM(GLUT_WINDOW_Y),
	MAKE_ENUM(GLUT_WINDOW_WIDTH),
	MAKE_ENUM(GLUT_WINDOW_HEIGHT),
	MAKE_ENUM(GLUT_WINDOW_BUFFER_SIZE),
	MAKE_ENUM(GLUT_WINDOW_STENCIL_SIZE),
	MAKE_ENUM(GLUT_WINDOW_DEPTH_SIZE),
	MAKE_ENUM(GLUT_WINDOW_RED_SIZE),
	MAKE_ENUM(GLUT_WINDOW_GREEN_SIZE),
	MAKE_ENUM(GLUT_WINDOW_BLUE_SIZE),
	MAKE_ENUM(GLUT_WINDOW_ALPHA_SIZE),
	MAKE_ENUM(GLUT_WINDOW_ACCUM_RED_SIZE),
	MAKE_ENUM(GLUT_WINDOW_ACCUM_GREEN_SIZE),
	MAKE_ENUM(GLUT_WINDOW_ACCUM_BLUE_SIZE),
	MAKE_ENUM(GLUT_WINDOW_ACCUM_ALPHA_SIZE),
	MAKE_ENUM(GLUT_WINDOW_DOUBLEBUFFER),
	MAKE_ENUM(GLUT_WINDOW_RGBA),
	MAKE_ENUM(GLUT_WINDOW_PARENT),
	MAKE_ENUM(GLUT_WINDOW_NUM_CHILDREN),
	MAKE_ENUM(GLUT_WINDOW_COLORMAP_SIZE),
#if (GLUT_API_VERSION >= 2)
	MAKE_ENUM(GLUT_WINDOW_NUM_SAMPLES),
	MAKE_ENUM(GLUT_WINDOW_STEREO),
#endif
#if (GLUT_API_VERSION >= 3)
	MAKE_ENUM(GLUT_WINDOW_CURSOR),
#endif
	MAKE_ENUM(GLUT_SCREEN_WIDTH),
	MAKE_ENUM(GLUT_SCREEN_HEIGHT),
	MAKE_ENUM(GLUT_SCREEN_WIDTH_MM),
	MAKE_ENUM(GLUT_SCREEN_HEIGHT_MM),
	MAKE_ENUM(GLUT_MENU_NUM_ITEMS),
	MAKE_ENUM(GLUT_DISPLAY_MODE_POSSIBLE),
	MAKE_ENUM(GLUT_INIT_WINDOW_X),
	MAKE_ENUM(GLUT_INIT_WINDOW_Y),
	MAKE_ENUM(GLUT_INIT_WINDOW_WIDTH),
	MAKE_ENUM(GLUT_INIT_WINDOW_HEIGHT),
	MAKE_ENUM(GLUT_INIT_DISPLAY_MODE),
#if (GLUT_API_VERSION >= 2)
	MAKE_ENUM(GLUT_ELAPSED_TIME),
#endif
#if (GLUT_API_VERSION >= 4 || GLUT_XLIB_IMPLEMENTATION >= 13)
	MAKE_ENUM(GLUT_WINDOW_FORMAT_ID),
#endif

#if (GLUT_API_VERSION >= 2)
	MAKE_ENUM(GLUT_HAS_KEYBOARD),
	MAKE_ENUM(GLUT_HAS_MOUSE),
	MAKE_ENUM(GLUT_HAS_SPACEBALL),
	MAKE_ENUM(GLUT_HAS_DIAL_AND_BUTTON_BOX),
	MAKE_ENUM(GLUT_HAS_TABLET),
	MAKE_ENUM(GLUT_NUM_MOUSE_BUTTONS),
	MAKE_ENUM(GLUT_NUM_SPACEBALL_BUTTONS),
	MAKE_ENUM(GLUT_NUM_BUTTON_BOX_BUTTONS),
	MAKE_ENUM(GLUT_NUM_DIALS),
	MAKE_ENUM(GLUT_NUM_TABLET_BUTTONS),
#endif
#if (GLUT_API_VERSION >= 4 || GLUT_XLIB_IMPLEMENTATION >= 13)
	MAKE_ENUM(GLUT_DEVICE_IGNORE_KEY_REPEAT),
	MAKE_ENUM(GLUT_DEVICE_KEY_REPEAT),
	MAKE_ENUM(GLUT_HAS_JOYSTICK),
	MAKE_ENUM(GLUT_OWNS_JOYSTICK),
	MAKE_ENUM(GLUT_JOYSTICK_BUTTONS),
	MAKE_ENUM(GLUT_JOYSTICK_AXES),
	MAKE_ENUM(GLUT_JOYSTICK_POLL_RATE),
#endif
#if (GLUT_API_VERSION >= 3)
	MAKE_ENUM(GLUT_OVERLAY_POSSIBLE),
	MAKE_ENUM(GLUT_LAYER_IN_USE),
	MAKE_ENUM(GLUT_HAS_OVERLAY),
	MAKE_ENUM(GLUT_TRANSPARENT_INDEX),
	MAKE_ENUM(GLUT_NORMAL_DAMAGED),
	MAKE_ENUM(GLUT_OVERLAY_DAMAGED),
#if (GLUT_API_VERSION >= 4 || GLUT_XLIB_IMPLEMENTATION >= 9)
	MAKE_ENUM(GLUT_VIDEO_RESIZE_POSSIBLE),
	MAKE_ENUM(GLUT_VIDEO_RESIZE_IN_USE),
	MAKE_ENUM(GLUT_VIDEO_RESIZE_X_DELTA),
	MAKE_ENUM(GLUT_VIDEO_RESIZE_Y_DELTA),
	MAKE_ENUM(GLUT_VIDEO_RESIZE_WIDTH_DELTA),
	MAKE_ENUM(GLUT_VIDEO_RESIZE_HEIGHT_DELTA),
	MAKE_ENUM(GLUT_VIDEO_RESIZE_X),
	MAKE_ENUM(GLUT_VIDEO_RESIZE_Y),
	MAKE_ENUM(GLUT_VIDEO_RESIZE_WIDTH),
	MAKE_ENUM(GLUT_VIDEO_RESIZE_HEIGHT),
#endif
	MAKE_ENUM(GLUT_NORMAL),	
	MAKE_ENUM(GLUT_OVERLAY),
	MAKE_ENUM(GLUT_ACTIVE_SHIFT),
	MAKE_ENUM(GLUT_ACTIVE_CTRL),
	MAKE_ENUM(GLUT_ACTIVE_ALT),
	MAKE_ENUM(GLUT_CURSOR_RIGHT_ARROW),
	MAKE_ENUM(GLUT_CURSOR_LEFT_ARROW),
	MAKE_ENUM(GLUT_CURSOR_INFO),
	MAKE_ENUM(GLUT_CURSOR_DESTROY),
	MAKE_ENUM(GLUT_CURSOR_HELP),
	MAKE_ENUM(GLUT_CURSOR_CYCLE),
	MAKE_ENUM(GLUT_CURSOR_SPRAY),
	MAKE_ENUM(GLUT_CURSOR_WAIT),
	MAKE_ENUM(GLUT_CURSOR_TEXT),
	MAKE_ENUM(GLUT_CURSOR_CROSSHAIR),
	MAKE_ENUM(GLUT_CURSOR_UP_DOWN),
	MAKE_ENUM(GLUT_CURSOR_LEFT_RIGHT),
	MAKE_ENUM(GLUT_CURSOR_TOP_SIDE),
	MAKE_ENUM(GLUT_CURSOR_BOTTOM_SIDE),
	MAKE_ENUM(GLUT_CURSOR_LEFT_SIDE),
	MAKE_ENUM(GLUT_CURSOR_RIGHT_SIDE),
	MAKE_ENUM(GLUT_CURSOR_TOP_LEFT_CORNER),
	MAKE_ENUM(GLUT_CURSOR_TOP_RIGHT_CORNER),
	MAKE_ENUM(GLUT_CURSOR_BOTTOM_RIGHT_CORNER),
	MAKE_ENUM(GLUT_CURSOR_BOTTOM_LEFT_CORNER),
	MAKE_ENUM(GLUT_CURSOR_INHERIT),
	MAKE_ENUM(GLUT_CURSOR_NONE),
	MAKE_ENUM(GLUT_CURSOR_FULL_CROSSHAIR),
#endif
#if (GLUT_API_VERSION >= 4 || GLUT_XLIB_IMPLEMENTATION >= 13)
	MAKE_ENUM(GLUT_KEY_REPEAT_OFF),
	MAKE_ENUM(GLUT_KEY_REPEAT_ON),
	MAKE_ENUM(GLUT_KEY_REPEAT_DEFAULT),
	MAKE_ENUM(GLUT_JOYSTICK_BUTTON_A),
	MAKE_ENUM(GLUT_JOYSTICK_BUTTON_B),
	MAKE_ENUM(GLUT_JOYSTICK_BUTTON_C),
	MAKE_ENUM(GLUT_JOYSTICK_BUTTON_D),
	MAKE_ENUM(GLUT_GAME_MODE_ACTIVE),
	MAKE_ENUM(GLUT_GAME_MODE_POSSIBLE),
	MAKE_ENUM(GLUT_GAME_MODE_WIDTH),
	MAKE_ENUM(GLUT_GAME_MODE_HEIGHT),
	MAKE_ENUM(GLUT_GAME_MODE_PIXEL_DEPTH),
	MAKE_ENUM(GLUT_GAME_MODE_REFRESH_RATE),
	MAKE_ENUM(GLUT_GAME_MODE_DISPLAY_CHANGED),
#endif
};

/*****************************************************************************/
/* Loading primitives and enumerations                                       */

void scheme_load_prim(Scheme_Env *env)
{
	Scheme_Object *prim;
	int i, N = sizeof (scm_prim) / sizeof (struct scm_prim);

	for (i = 0; i < N; i++)
	{
		prim = scheme_make_closed_prim_w_arity(scm_prim[i].prim,
						       scm_prim[i].name,
						       scm_prim[i].name,
						       scm_prim[i].mina,
						       scm_prim[i].maxa);
		scheme_add_global(scm_prim[i].name, prim, env);
	}
}

void scheme_load_enum(Scheme_Env *env)
{
	Scheme_Object *val;
	int i, N = sizeof (scm_enum) / sizeof (struct scm_enum);

	for (i = 0; i < N; i++)
	{
		val = scheme_make_integer_value_from_unsigned((unsigned int)
							      scm_enum[i].val);
		scheme_add_global(scm_enum[i].name, val, env);
	}
}

void scheme_register_traceable_globals(Scheme_Env *env)
{
	/* Mr. GC, can I please still have my 
	 * lovely callbacks? Thanks
         */

	scheme_register_extension_global(displayFuncCallBack,
					 sizeof(Scheme_Object *));
	displayFuncCallBack = scheme_void;

	scheme_register_extension_global(keyboardFuncCallBack,
					 sizeof(Scheme_Object *));
	keyboardFuncCallBack = scheme_void;

	scheme_register_extension_global(mouseFuncCallBack,
					 sizeof(Scheme_Object *));
	mouseFuncCallBack = scheme_void;

	scheme_register_extension_global(motionFuncCallBack,
					 sizeof(Scheme_Object *));
	motionFuncCallBack = scheme_void;

	scheme_register_extension_global(passiveMotionFuncCallBack,
					 sizeof(Scheme_Object *));
	passiveMotionFuncCallBack = scheme_void;

	scheme_register_extension_global(entryFuncCallBack,
					 sizeof(Scheme_Object *));
	entryFuncCallBack = scheme_void;

	scheme_register_extension_global(visibilityFuncCallBack,
					 sizeof(Scheme_Object *));
	visibilityFuncCallBack = scheme_void;

	scheme_register_extension_global(idleFuncCallBack,
					 sizeof(Scheme_Object *));
	idleFuncCallBack = scheme_void;

	scheme_register_extension_global(menuStateFuncCallBack,
					 sizeof(Scheme_Object *));
	menuStateFuncCallBack = scheme_void;

        scheme_register_extension_global(specialFuncCallBack,
					 sizeof(Scheme_Object *));
	specialFuncCallBack = scheme_void;

        scheme_register_extension_global(spaceballMotionFuncCallBack,
					 sizeof(Scheme_Object *));
	spaceballMotionFuncCallBack = scheme_void;

        scheme_register_extension_global(spaceballRotateFuncCallBack,
					 sizeof(Scheme_Object *));
	spaceballRotateFuncCallBack = scheme_void;

	scheme_register_extension_global(spaceballButtonFuncCallBack,
					 sizeof(Scheme_Object *));
	spaceballButtonFuncCallBack = scheme_void;

        scheme_register_extension_global(buttonBoxFuncCallBack,
					 sizeof(Scheme_Object *));
	buttonBoxFuncCallBack = scheme_void;

        scheme_register_extension_global(dialsFuncCallBack,
					 sizeof(Scheme_Object *));
	dialsFuncCallBack = scheme_void;

        scheme_register_extension_global(tabletMotionFuncCallBack,
					 sizeof(Scheme_Object *));
	tabletMotionFuncCallBack = scheme_void;

        scheme_register_extension_global(tabletButtonFuncCallBack,
					 sizeof(Scheme_Object *));
	tabletButtonFuncCallBack = scheme_void;

        scheme_register_extension_global(menuStatusFuncCallBack,
					 sizeof(Scheme_Object *));
	menuStatusFuncCallBack = scheme_void;

        scheme_register_extension_global(overlayDisplayFuncCallBack,
					 sizeof(Scheme_Object *));
	overlayDisplayFuncCallBack = scheme_void;

        scheme_register_extension_global(windowStatusFuncCallBack,
					 sizeof(Scheme_Object *));
	windowStatusFuncCallBack = scheme_void;

        scheme_register_extension_global(keyboardUpFuncCallBack,
					 sizeof(Scheme_Object *));
	keyboardUpFuncCallBack = scheme_void;

        scheme_register_extension_global(specialUpFuncCallBack,
					 sizeof(Scheme_Object *));
	specialUpFuncCallBack = scheme_void;

        scheme_register_extension_global(joystickFuncCallBack,
					 sizeof(Scheme_Object *));
	joystickFuncCallBack = scheme_void;
}

/*****************************************************************************/
/* MzScheme extension interface						     */

Scheme_Object *scheme_reload(Scheme_Env *env)
{
	scheme_register_traceable_globals(env);
	scheme_load_enum(env);
	scheme_load_prim(env);

	return scheme_void;
}

Scheme_Object *scheme_initialize(Scheme_Env *env)
{
	return scheme_reload(env);
}

Scheme_Object *scheme_module_name(void)
{
	return scheme_false;
}

/*---------------------------------------------------------------------------*/
