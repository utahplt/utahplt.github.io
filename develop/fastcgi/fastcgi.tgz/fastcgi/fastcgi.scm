;;   Mzscheme interface for the FastCGI
;; 
;;   Copyright (C) 1999 Jet Infosystems
;; 
;;   This library is free software; you can redistribute it and/or
;;   modify it under the terms of the GNU Lesser General Public
;;   License as published by the Free Software Foundation; either
;;   version 2 of the License, or (at your option) any later version.
;; 
;;   This library is distributed in the hope that it will be useful,
;;   but WITHOUT ANY WARRANTY; without even the implied warranty of
;;   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
;;   Lesser General Public License for more details.
;; 
;;   You should have received a copy of the GNU Lesser General Public
;;   License along with this library; if not, write to the Free Software
;;   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
;;
;;   Author: Ilia Permiov
;;   Email: ilia@jet.msk.su
   

(define-macro fcgi:assert
  (lambda (cond)
    `(unless ,cond
          (error "Assertion failed: " (quote ,cond)))))

;;; I/O routines.

;; Read byte from the port.
(define (fcgi:read-byte port)
  (char->integer (read-char port)))

;; Write byte to the port.
(define (fcgi:write-byte b port)
  (write-char (integer->char b) port))

;; Read a two bytes integer.
(define (fcgi:read-integer2 port)
  (let* ((b0 (fcgi:read-byte port))
         (b1 (fcgi:read-byte port)))
    (+ (* b0 256) b1)))

;; Read a four bytes integer.
(define (fcgi:read-integer4 port)
  (let* ((b0 (fcgi:read-byte port))
         (b1 (fcgi:read-byte port))
         (b2 (fcgi:read-byte port))
         (b3 (fcgi:read-byte port)))
    (+ (* (+ (* (+ (* b0 256) b1) 256) b2) 256) b3)))

;; Write a two bytes integer.
(define (fcgi:write-integer2 i port)
  (fcgi:write-byte (quotient i 256) port)
  (fcgi:write-byte (remainder i 256) port))

;; Write a four bytes integer.
(define (fcgi:write-integer4 n port)
  (fcgi:write-integer2 (quotient n (* 256 256)) port)
  (fcgi:write-integer2 (remainder n (* 256 256)) port))

;; Read a byte or a four byte integer from the port. Most significant bit of 
;; the first byte determines size of the integer: 0 - one byte, 1 - four 
;; bytes. Return pair (number . num-bytes).
(define (fcgi:read-byte-or-integer4 port)
  (let ((b0 (fcgi:read-byte port)))
    (if (< b0 128)
        (cons b0 1)
        (let*
            ((b0 (- b0 128))
             (b1 (fcgi:read-byte port))
             (b2 (fcgi:read-byte port))
             (b3 (fcgi:read-byte port)))
          (cons (+ (* (+ (* (+ (* b0 256) b1) 256) b2) 256) b3) 4)))))

;; Write a byte or a four byte integer to the port. Most significant bit of 
;; the first byte determines size of the integer: 0 - one byte, 1 - four 
;; bytes i.e. 0 <= n <= 127 is written as a one byte and n > 127 as four bytes.
(define (fcgi:write-byte-or-integer4 n port)
  (if (< n 128)
      (fcgi:write-byte n port)
      (fcgi:write-integer4 (+ n (* 127 256 256 256)) port)))

;; Read bytes from the port, return them as a string.
(define (fcgi:read-bytes n port)
  (read-string n port))
;  (let ((s (make-string n #\0)))
;    (let loop ((i 0))
;      (if (< i n)
;          (begin 
;            (string-set! s i (read-char port))
;            (loop (+ i 1)))
;          s))))

;; Write bytes (string) to the port.
(define (fcgi:write-bytes s port)
  (display s port))
;  (let loop ((i 0))
;      (when (< i (string-length s))
;            (fcgi:write-byte (char->integer (string-ref s i)) port)
;            (loop (+ i 1)))))

;;; Low-level FCGI definitions and routines.

;; Listening socket file number
(define fcgi:listensock-fileno 0)

;; Value for version component of FCGI requet header.
(define fcgi:version 1)

;; Number of bytes in a FCGI Header.  Future versions of the protocol
;; will not reduce this number.
(define fcgi:header-len  8)

;; Request types.
(define fcgi:begin-request       1) ; s -> a
(define fcgi:abort-request       2) ; s -> a
(define fcgi:end-request         3) ; a -> s
(define fcgi:params              4) ; s -> a
(define fcgi:stdin               5) ; s -> a
(define fcgi:stdout              6) ; a -> s
(define fcgi:stderr              7) ; a -> s
(define fcgi:data                8) ; s -> a
(define fcgi:get-values          9) ; s -> a
(define fcgi:get-values-result  10) ; a -> s
(define fcgi:unknown-type       11) ; a -> s
(define fcgi:maxtype fcgi:unknown-type)

(define fcgi:record-type-names
  (vector "unkown"
           "begin-request"    
           "abort-request"    
           "end-request"      
           "params"           
           "stdin"            
           "stdout"           
           "stderr"           
           "data"             
           "get-values"
           "get-values-result"
           "unknown-type"))



;; Value for request Id component of FCGI Header
(define fcgi:null-request-id     0)

;; Return i-th byte of the header.
(define (fcgi:header-byte header i)
  (char->integer (string-ref header i)))

;; Identifies the FastCGI protocol version. 
(define (fcgi:request-protocol-version header)
  (fcgi:header-byte header 0))

;; Identifies the FastCGI record type.
(define (fcgi:request-type header)
  (fcgi:header-byte header 1))

;; Identifies the FastCGI request to which the record belongs.
(define (fcgi:request-id header)
  (+ (* (fcgi:header-byte header 2) 256) (fcgi:header-byte header 3)))

;; The number of bytes in the content (2 bytes).
(define (fcgi:request-content-length  header)
  (+ (* (fcgi:header-byte header 4) 256) (fcgi:header-byte header 5)))

;; The number of bytes in the padding.
(define (fcgi:request-padding-length  header)
  (fcgi:header-byte header 6))

;; Skip the number of bytes in the stream.
(define (fcgi:skip-padding num-bytes in-port)
  (fcgi:read-bytes num-bytes in-port))

;; Skip body of a record in the port. 'h' - header of this record.
(define (fcgi:skip-record-body h port)
  (fcgi:skip-padding (fcgi:request-content-length h) port)
  (fcgi:skip-padding (fcgi:request-padding-length h) port))

;; Read record (request) header, return it as a string.
(define (fcgi:read-header port)
  (fcgi:read-bytes fcgi:header-len port))

;; Write record (request) header.
(define (fcgi:write-header type request-id content-length padding-length port)
  (fcgi:write-byte fcgi:version port)
  (fcgi:write-byte type port)
  (fcgi:write-integer2 request-id port)
  (fcgi:write-integer2 content-length port)
  (fcgi:write-byte padding-length port)
  (fcgi:write-byte 0 port) ; Reserved.
  )

;; Mask for flags component of BeginRequest
(define fcgi:keep-conn  1)

;; Values for role component of BeginRequest
(define fcgi:responder  1)
(define fcgi:authorizer 2)
(define fcgi:filter     3)

;; Read body of "begin request" record. Return (role . flags).
(define (fcgi:read-begin-request-body port)
  (let* ((role (fcgi:read-integer2 port))
         (flags (fcgi:read-byte port)))
    ;; Skip reserved bytes.
    (fcgi:skip-padding 5 port)
    (cons role flags)))

;; Values for protocol-status component of "End Request".
(define fcgi:request-complete 0)
(define fcgi:cant-mpx-conn    1)
(define fcgi:overloaded       2)
(define fcgi:unknown-role     3)

;; Write "end request".
(define (fcgi:write-end-request request-id app-status protocol-status port)
  (fcgi:write-header fcgi:end-request request-id 8 0 port)
  (fcgi:write-integer4 app-status port)
  (fcgi:write-byte protocol-status port)
  (fcgi:write-byte 0 port) ; Reserved 
  (fcgi:write-byte 0 port) ; Reserved 
  (fcgi:write-byte 0 port) ; Reserved 
  )

;; Write "unkown type record". 'type' - the unkown type.
(define (fcgi:write-unknown-type request-id type port)
  (fcgi:write-header fcgi:unknown-type request-id 8 0 port)
  (fcgi:write-byte type port)
  (fcgi:write-integer4 0 port) ; Reserved  
  (fcgi:write-integer2 0 port) ; Reserved 
  (fcgi:write-byte 0 port) ; Reserved 
)

;; Read a name-value pair. Return the pair and the number of bytes read:
;; ((name . value) . lenght)
(define (fcgi:read-name-value-pair port)
  (let* ((name-len (fcgi:read-byte-or-integer4 port))
         (val-len (fcgi:read-byte-or-integer4 port))
         (name (fcgi:read-bytes (car name-len) port))
         (value (fcgi:read-bytes (car val-len) port)))
    (cons (cons name value) (+ (car name-len) (cdr name-len) 
                               (car val-len) (cdr val-len)))))

;; Write a name-value pair to the port. 
(define (fcgi:write-name-value-pair p port)
  (let ((name-len (string-length (car p)))
        (val-len (string-length (cdr p))))
    (fcgi:write-byte-or-integer4 name-len port)
    (fcgi:write-byte-or-integer4 val-len port)
    (fcgi:write-bytes (car p) name-len port)
    (fcgi:write-bytes (cdr p) val-len port)))

;; Write a record of the specified type to the port. 
;; 's' - record body (string).
(define (fcgi:write-stream-record rec-type request-id s port)
  (let* ((len (string-length s))
         ;; (padding (- (* (quotient (+ len 7) 8) 8) len))
         (padding 0))
    (fcgi:write-header rec-type request-id len padding port)
    (fcgi:write-bytes s port)
    ; (fcgi:write-bytes (make-string padding #\0) port)
    ))

;; Write a list of name-value pairs to the port. 
(define (fcgi:write-name-value-pairs pairs port)
  (for-each (lambda (p) (fcgi:write-name-value-pairs p port)) pairs))

;; Return the number of bytes the name-value pair 'p' will occupy in a stream.
(define (fcgi:name-value-pair-lenght p)
  (let ((name-len (string-length (car p)))
        (val-len (string-length (cdr p))))
    (+ name-len val-len (if (> name-len 127) 4 1) (if (> val-len 127) 4 1))))

;; Read name-value pairs, length - the number of bytes to read.
;; Return a list of name-value pairs.
(define (fcgi:read-name-value-pairs length port)
  (let loop ((l '()) (rest-len length))
    (if (> rest-len 0)
        (let ((p (fcgi:read-name-value-pair port)))
          (loop (cons (car p) l) (- length (cdr p))))
        (if (= rest-len 0)
            l
            (error "Bad request: a name-value pair crosses record boundary")))
    ))

;; Variable names for "get values" / "get values result" records.

;; The maximum number of concurrent transport connections this application 
;; will accept.
(define fcgi:max-conns-var-name  "FCGI_MAX_CONNS")

;; The maximum number of concurrent requests this application will accept.
(define fcgi:max-reqs-var-name "FCGI_MAX_REQS")

;; "0" if this application does not multiplex connections, otherwise "1".
(define fcgi:mpxs-conns-var-name "FCGI_MPXS_CONNS")

;; Values of FCGI application variables.
(define fcgi:variables `((,fcgi:max-conns-var-name . 1)
                         (,fcgi:max-reqs-var-name . 1)
                         (,fcgi:mpxs-conns-var-name . 0)))

;; Read "get values" request body. Return list of variable names.
(define (fcgi:read-get-values-request-body content-length port)
  (map car (fcgi:read-name-value-pairs content-length port)))

;; Read "params" request body. Return list of (name . value) pairs.
(define (fcgi:read-params-request-body content-length port)
  (fcgi:read-name-value-pairs content-length port))
  
;; Write "get values result" (answer to "get values" request) record.
(define (fcgi:write-get-values-result request-id pairs port)
  (let* ((pairs-len (apply + (map fcgi:name-value-pair-lenght pairs)))
         ;; (padding (- (* (quotient (+ pairs-len 7) 8) 8) pairs-len))
         (padding 0))
    ;; Write header.
    (fcgi:write-header fcgi:get-values-result request-id pairs-len 
                       padding port)
    ;; Write pairs.
    (fcgi:write-name-value-pairs pairs port)
    ;; Write padding bytes.
    ; (fcgi:write-bytes (make-string padding #\0) port)
    ))

;; If 'header' is a managment request header, process it and return #t, 
;; otherwise return #f.
(define (fcgi:process-management-request header in-port out-port)
  (if (= (fcgi:request-type header) fcgi:get-values)
      (let ((names (fcgi:read-get-values-request-body 
                    (fcgi:request-content-length header) in-port)))
        ;; Skip padding.
        (fcgi:read-bytes (fcgi:request-padding-length header) in-port)
        ;; Write response.
        (fcgi:write-get-values-result fcgi:null-request-id 
                                      (collect-if (lambda (x) x) 
                                                  (map assoc names 
                                                       fcgi:variables))
                                      out-port)
        #t)
      #f))

;; Read a request header processing managment requests internally.
(define (fcgi:read-app-record-header in-port out-port)
  (let loop ((r (fcgi:read-header in-port)))
    (if (fcgi:process-management-request r in-port out-port)
        (loop (fcgi:read-header in-port))
        r)))

;; Read "begin request" record from the input stream.
;; Return (request-id role keep-conn)
;; keep-conn - false if the client should close connection after processing 
;; the request.
(define (fcgi:read-begin-record in-port out-port)
  ;; Read header.
  (let ((header (fcgi:read-app-record-header in-port out-port)))
    ;; Check record type.
    (fcgi:assert (= (fcgi:request-type header)))
    (let ((request-id (fcgi:request-id header))
          (padding-bytes (fcgi:request-padding-length header))
          ;; Read request body.
          (request-params (fcgi:read-begin-request-body in-port)))
      ;; Skip padding bytes.
      (fcgi:read-bytes padding-bytes in-port)
      (list request-id (car request-params)
            (= (bitwise-and (cdr request-params) fcgi:keep-conn)
               fcgi:keep-conn)))))


;;; The following functions (with -nmpx suffix) assumes the connection to
;;; the server is not multiplexing. If a record of a different request is
;;; received, we skip it and send "end request" record to the server to inform
;;; it, that the connection does not support  multiplexing.

;; Read a request header from a not multiplexing connection processing 
;; managment records transparently. 
(define (fcgi:read-app-record-header-nmpx request-id in-port out-port)
  (let loop ((r (fcgi:read-header in-port)))
    (cond 
     ;; Management record.
     ((fcgi:process-management-request r in-port out-port)
      (loop (fcgi:read-header in-port)))
     ;; Other request.
     ((not (= request-id (fcgi:request-id r)))
      (begin
        ;; Skip the request body.
        (fcgi:skip-record-body r in-port)
        ;; Inform the server we can't multiplex connections.
        (fcgi:write-end-request (fcgi:request-id r) 200 fcgi:cant-mpx-conn 
                                out-port)
        (loop (fcgi:read-header in-port))))
     ;; Application record of our request.
     (else  r))))

;; Exception that is raised if a request is aborted by the server.
;; request-id is the request identifier.
(define-struct fcgi:request-aborted (request-id))

;; Read a record header processing managment requests internally and raising
;; exception 'fcgi:request-aborted' if a "abort request" record received. 
(define (fcgi:read-record-header-nmpx request-id in-port out-port)
  (let ((h (fcgi:read-app-record-header-nmpx request-id in-port out-port)))
    (if (= (fcgi:request-type h) fcgi:abort-request)
        (begin
          ;; The request has been aborted by the server.
          (fcgi:assert (= (fcgi:request-content-length) 0))
          (fcgi:read-bytes (fcgi:request-padding-length))
          (raise (make-fcgi:request-aborted request-id)))
        h)))

;; Read request envoronment. 
(define (fcgi:read-params-nmpx request-id in-port out-port)
  (let loop ((params '()) 
             (h (fcgi:read-record-header-nmpx request-id in-port out-port)))
    (fcgi:assert (= (fcgi:request-type h) fcgi:params))
    (let ((p (fcgi:read-params-request-body (fcgi:request-content-length h)
                                            in-port)))
      (fcgi:read-bytes (fcgi:request-padding-length h) in-port)
      (if (> (fcgi:request-content-length h) 0)
          ;; Not last record.
          (loop (append params p) 
                (fcgi:read-record-header-nmpx request-id in-port out-port))
          ;; Last record.
          params))))

;; Read stream record header from in-port, 
;; record-type - input stream record type (fcgi:stdin or fcgi:data)
;; return (content-length . padding-length). 
(define (fcgi:read-input-nmpx record-type request-id in-port out-port)
  (let ((h (fcgi:read-record-header-nmpx request-id in-port out-port)))
    (fcgi:assert (= (fcgi:request-type h) fcgi:stdin))
    (cons (fcgi:request-content-length h) (fcgi:request-padding-length h))))

;; Read stdin record header from in-port, 
;; return (content-length . padding-length). 
(define (fcgi:read-stdin-nmpx request-id in-port out-port)
  (fcgi:read-input-nmpx fcgi:stdin request-id in-port out-port))

;; Read data record header from in-port, 
;; return (content-length . padding-length). 
(define (fcgi:read-data-nmpx request-id in-port out-port)
  (fcgi:read-input-nmpx fcgi:data request-id in-port out-port))

;; Make and return a custom input port representing input (stdin or data) 
;; stream of the request.
;; record-type - input stream record type (fcgi:stdin or fcgi:data)
;; request-id - ID of the request
;; in/out-port - input/output ports to communicate with the server.
(define (fcgi:make-input-port-nmpx record-type request-id in-port out-port)
  (let* ((rest 0)
         (padding 0)
         (eof-reached #f)
         (closed #f)
         (getc (lambda ()
                 (fcgi:assert (not closed))
                 (if eof-reached
                     eof
                     (if (= rest 0)
                         (begin
                           ;; End of record.
                           ;; Skip padding.
                           (fcgi:read-bytes padding in-port)
                           ;; Read the next record.
                           (let* ((r (fcgi:read-input-nmpx record-type 
                                                           request-id 
                                                           in-port out-port))
                                  (l (car r))
                                 (p (cdr r)))
                             (if (= l 0)
                                 ;; End of stream.
                                 (begin
                                   (set! eof-reached #t)
                                   eof)
                                 (begin
                                   (set! rest (- l 1))
                                   (set! padding p)
                                   (read-char in-port)))))
                         ;; Not at end of a record.
                         (begin
                           (set! rest (- rest 1))
                           (read-char in-port))))))
         (char-ready (lambda ()
                       (or eof-reached (char-ready? in-port))))
         (close (lambda () (set! closed #t))))
    (make-input-port getc char-ready close)))

;; Make and return a custom input port representing stdin stream of 
;; the request.
;; request-id - ID of the request
;; in/out-port - input/output ports to communicate with the server.
(define (fcgi:make-stdin-port-nmpx request-id in-port out-port)
  (fcgi:make-input-port-nmpx fcgi:stdin request-id in-port out-port))

;; Make and return a custom input port representing data stream of 
;; the request.
;; request-id - ID of the request
;; in/out-port - input/output ports to communicate with the server.
(define (fcgi:make-data-port-nmpx request-id in-port out-port)
  (fcgi:make-input-port-nmpx fcgi:data request-id in-port out-port))
  
;; Make and return an output port representing output stream of
;; the request (stderr or stdout).
;; rec-type - output stream record type (fcgi:stdout or fcgi:stderr)
;; request-id - ID of the request
;; in/out-port - input/output ports to communicate with the server.
(define (fcgi:make-output-port rec-type request-id in-port out-port)
  (let* ((buffer-size 500)
         (closed #f)
         (buffer "")
         (write-func (lambda (s)
                       (fcgi:assert (not closed))
                       (unless (string=? s "")
                               (set! buffer (string-append buffer s))
                               (when (>= (string-length buffer) buffer-size)
                                     (fcgi:write-stream-record rec-type 
                                                               request-id 
                                                               buffer
                                                               out-port)
                                     (set! buffer "")))))
         (close (lambda () 
                  (unless (string=? buffer "")
                          (fcgi:write-stream-record rec-type request-id 
                                                    buffer out-port))
                  (fcgi:write-stream-record rec-type request-id "" out-port)
                  (set! closed #t))))
    (make-output-port write-func close)))
                        
;; Make and return an output port representing stderr stream of
;; the request.
;; request-id - ID of the request
;; in/out-port - input/output ports to communicate with the server.
(define (fcgi:make-stderr-port request-id in-port out-port)
  (fcgi:make-output-port fcgi:stderr request-id in-port out-port))

;; Make and return an output port representing stdout stream of
;; the request.
;; request-id - ID of the request
;; in/out-port - input/output ports to communicate with the server.
(define (fcgi:make-stdout-port request-id in-port out-port)
  (fcgi:make-output-port fcgi:stdout request-id in-port out-port))



;; Accept a request. in/out-port - ports to communicate with the server.
;; Return a list: (end-proc role env stdin data stdout stderr)
;; role is requested role (fcgi:responder, fcgi:authorizer, fcgi:filter)
;; end-proc (app-status protocol-status) - procedure that should be used to
;;                                         finish processing of the request.
;; env - request environment 
;; stdin - request input (stdin) port
;; data - request input (data) port
;; stdout - request output port
;; stderr - request error port
;; For each particular role, only corresponding subset of the ports must be
;; used and only in role-defined order: 
;; - A Responder may use stdin, stdout and stderr (concurrently). 
;; - An authorizer may use stdout and stderr (concurrently). 
;; - A Filter must finish reading stdin before using other streams, then 
;;   it may use data, stdout and stderr (concurrently).
(define (fcgi:accept-request-nmpx in-port out-port)
  (let* ((request-option (fcgi:read-begin-record in-port out-port))
         (request-id (car request-option))
         (role (cadr request-option))
         (keep-conn (caddr request-option)))
    (let* ((request-params (fcgi:read-params-nmpx request-id in-port out-port))
           (stdin (fcgi:make-stdin-port-nmpx request-id in-port out-port))
           (data (fcgi:make-data-port-nmpx request-id in-port out-port))
           (stdout (fcgi:make-stdout-port request-id in-port out-port))
           (stderr (fcgi:make-stderr-port request-id in-port out-port))
           (end-req (lambda (app-status protocol-status) 
                      (close-input-port stdin)
                      (close-input-port data)
                      (close-output-port stdout)
                      (close-output-port stderr)
                      (fcgi:write-end-request request-id app-status 
                                              protocol-status out-port)
                      (unless keep-conn
                              (close-input-port in-port)
                              (close-output-port out-port))
                      keep-conn)))
      (list role end-req request-params stdin data stdout stderr))))

;; Exception that is raised if the application can't play requested role.
(define-struct fcgi:bad-role (role))

(define (fcgi:accept-request-as-responder in-port out-port)
  (let* ((r (fcgi:accept-request-nmpx in-port out-port))
         (role (list-ref r 0))
         (end-proc (list-ref r 1))
         (env (list-ref r 2))
         (stdin (list-ref r 3))
         (stdout (list-ref r 5))
         (stderr (list-ref r 6)))
    (when (not (= role fcgi:responder))
          (fcgi:write-end-request request-id 200 fcgi:unknown-role out-port)
          (raise (make-fcgi:bad-role role)))
    (list end-proc env stdin stdout stderr)))

(define (fcgi:accept-request-as-authorizer in-port out-port)
  (let* ((r (fcgi:accept-request-nmpx in-port out-port))
         (role (list-ref r 0))
         (end-proc (list-ref r 1))
         (env (list-ref r 2))
         (stdin (list-ref r 3))
         (stdout (list-ref r 5))
         (stderr (list-ref r 6)))
    (when (not (= role fcgi:authorizer))
          (fcgi:write-end-request request-id 200 fcgi:unknown-role out-port)
          (raise (make-fcgi:bad-role role)))
    (list end-proc env stdin stdout stderr)))
