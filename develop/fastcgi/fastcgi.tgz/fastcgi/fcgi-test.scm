#! /opt/local/bin/mzscheme -r 

(define debug-port (open-output-file "/tmp/fcgi.log" 'append))

(current-error-port debug-port)
(fprintf (current-error-port) "Script started.~n")

(load-relative "fastcgi.scm")

(define port-num 8888)
(define listener (tcp-listen port-num))

(define request-environment (make-parameter '()))

;; Returns value of a request environment variable.
(define (request-getenv name) 
  (let ((p (assoc name (request-environment))))
    (and p (cdr p))))

(set! getenv request-getenv)

(let loop ((i 1))
    (let-values (;; Accept a request.
                 ((in-port out-port) (tcp-accept listener)))
                ;; Create a thread to process the request.
                (thread 
                 (lambda () 
                   (let* (;; Create the request environment and input/output
                          ;; ports.
                          (r (fcgi:accept-request-as-responder in-port 
                                                               out-port)))
                     (parameterize ((request-environment (list-ref r 1))
                                    (current-error-port (list-ref r 4))
                                    (current-input-port (list-ref r 2))
                                    (current-output-port (list-ref r 3)))
                                   ;; Process the request.
                                   ;; ===================================
                                   (printf "Content-type: text/html~n~n")
                                   (printf "<html><head></head><body>")
                                   (printf "<h1>Request ~a</h1>" i)
                                   (printf "<h2>Environment</h2>")
                                   (printf "<ul>")
                                   (for-each (lambda (name) 
                                               (printf "<li>~a = ~a</li>" name
                                                       (getenv name)))
                                             `("REQUEST_METHOD" 
                                               "QUERY_STRING" 
                                               "REQUEST_URI"
                                               "HTTP_USER_AGENT"))
                                   (printf "</ul>")
                                   (printf "<h2>stdin</h2>")
                                   (let loop ((l (read-line)))
                                     (unless (eof-object? l)
                                             (display l)))
                                   ;; ===================================
                                   ((list-ref r 0) 0 fcgi:request-complete)))))
                (loop (+ 1 i))))
