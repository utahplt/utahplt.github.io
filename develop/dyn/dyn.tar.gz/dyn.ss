#!/bin/sh
string=? ; if [ ! "$1" = "compile" ]; then exec mzscheme -mf "$0" "$@"; fi
string=? ; mzc -v ++ccf -Wall --cc dyn.c || exit 1
string=? ; mzc --ld dyn.so dyn.o || exit 1
string=? ; rm dyn.o              || exit 1
string=? ; chmod -x dyn.so       || exit 1
string=? ; exec mzscheme -mf "$0" "$@"

(load-extension "dyn.so")


;;(dyn-open-lib "libibmeci50.so") - not really needed.

(add-handle-type 'eci)
(add-handle-type 'eci-dict)

(putenv "ECIINI" "/usr/lib/ViaVoiceOutloud/samples/cmdlinespeak/eci.ini")

(define eci:new
  (dyn-function "libibmeci50.so" "eciNew"
                '() 'eci))
(dyn-register-finalizer-for-constructor
 eci:new (dyn-function "libibmeci50.so" "eciDelete"
                       '(eci)))

(define eci:new-dict
  (let ((new (dyn-function "libibmeci50.so" "eciNewDict" '(eci) 'eci-dict))
        (eci-dicts (make-hash-table-weak)))
    (dyn-register-finalizer-for-constructor
     new
     (let ((del (dyn-function "libibmeci50.so" "eciDeleteDict"
                              '(eci eci-dict))))
       (lambda (dict)
         (let ((eci (hash-table-get eci-dicts dict)))
           (hash-table-remove! eci-dicts dict)
           (del eci dict)))))
    (lambda (eci)
      (let ((dict (new eci)))
        (hash-table-put! eci-dicts dict eci)
        dict))))

(define eci:add-text
  (dyn-function "libibmeci50.so" "eciAddText"
                '(eci string) 'boolean))
(define eci:clear-input
  (dyn-function "libibmeci50.so" "eciClearInput"
                '(eci) 'boolean))
(define eci:copy-voice
  (dyn-function "libibmeci50.so" "eciCopyVoice"
                '(eci fixnum fixnum) 'boolean))
;;(define eci:dict-find-first
;;  (dyn-function "libibmeci50.so" "eciDictFindFirst" '()))
;;(define eci:dict-find-next
;;  (dyn-function "libibmeci50.so" "eciDictFindNext" '()))
;;(define eci:dict-lookup
;;  (dyn-function "libibmeci50.so" "eciDictLookup" '()))
;;(define eci:generate-phonemes
;;  (dyn-function "libibmeci50.so" "eciGeneratePhonemes" '()))
;;(define eci:get-dict
;;  (dyn-function "libibmeci50.so" "eciGetDict" '()))
;;(define eci:get-index
;;  (dyn-function "libibmeci50.so" "eciGetIndex" '()))
;;(define eci:get-param
;;  (dyn-function "libibmeci50.so" "eciGetParam" '()))
;;(define eci:get-voice-name
;;  (dyn-function "libibmeci50.so" "eciGetVoiceName" '()))
;;(define eci:get-voice-param
;;  (dyn-function "libibmeci50.so" "eciGetVoiceParam" '()))
;;(define eci:insert-index
;;  (dyn-function "libibmeci50.so" "eciInsertIndex" '()))
;;(define eci:load-dict
;;  (dyn-function "libibmeci50.so" "eciLoadDict" '()))
(define eci:pause
  (dyn-function "libibmeci50.so" "eciPause" '(eci boolean) 'boolean))
;;(define eci:register-callback
;;  (dyn-function "libibmeci50.so" "eciRegisterCallback" '()))
(define eci:reset
  (dyn-function "libibmeci50.so" "eciReset"
                '(eci) 'boolean))
;;(define eci:save-dict
;;  (dyn-function "libibmeci50.so" "eciSaveDict" '()))
;;(define eci:set-dict
;;  (dyn-function "libibmeci50.so" "eciSetDict" '()))
;;(define eci:set-output-buffer
;;  (dyn-function "libibmeci50.so" "eciSetOutputBuffer" '()))
(define eci:set-output-device
  (dyn-function "libibmeci50.so" "eciSetOutputDevice"
                '(eci fixnum) 'boolean))
(define eci:set-output-filename
  (dyn-function "libibmeci50.so" "eciSetOutputFilename"
                '(eci string) 'boolean))
;;(define eci:set-param
;;  (dyn-function "libibmeci50.so" "eciSetParam" '()))
;;(define eci:set-voice-param
;;  (dyn-function "libibmeci50.so" "eciSetVoiceParam" '()))
(define eci:speaking?
  (dyn-function "libibmeci50.so" "eciSpeaking"
                '(eci) 'boolean))
(define eci:speak-text
  (dyn-function "libibmeci50.so" "eciSpeakText"
                '(string boolean) 'boolean))
(define eci:stop
  (dyn-function "libibmeci50.so" "eciStop"
                '(eci) 'boolean))
(define eci:synchronize
  (dyn-function "libibmeci50.so" "eciSynchronize"
                '(eci)))
(define eci:synthesize
  (dyn-function "libibmeci50.so" "eciSynthesize"
                '(eci) 'boolean))
(define eci:synthesize-file
  (dyn-function "libibmeci50.so" "eciSynthesizeFile"
                '(eci string) 'boolean))
(define eci:test-phrase
  (dyn-function "libibmeci50.so" "eciTestPhrase"
                '(eci) 'boolean))
;;(define eci:update-dict
;;  (dyn-function "libibmeci50.so" "eciUpdateDict" '()))
(define eci:version
  (let ((ver (dyn-function "libibmeci50.so" "eciVersion" '(string)))
        (s "                     "))
    (lambda ()
      (ver s)
      (truncate-at-nul s))))

(printf ">>> ~s~%" (eci:version))

(define e (eci:new))
(eci:set-output-device e 0)
(eci:add-text e "1 2 3 4 5 6 7 8 9 10.")

;;(eci:copy-voice e 4 9)
;;(eci:add-text e "`v9 Welcome.")
;;(eci:reset e)
