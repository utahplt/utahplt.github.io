#include "escheme.h"
#include <dlfcn.h>

/*
 * Add enumerations
 * Arrays - allocate a C array, convert all input values
 *     should mark this input so at the end modified values gets copied back
 *     -> can implement integer* etc using this
 * callbacks - using a combo of a func/data thing,
 *     -- handle more C inputs (ignoring them)
 *     -- Scheme closure can hold actual data, no need for more inputs
 * floats/chars?? (different sizes from 32 bits)
 */

/*****************************************************************************/

static Scheme_Type dyn_lib_type;
typedef struct {
  Scheme_Type type;
  void *handle;
  char *filename;
} DynLib;

static Scheme_Hash_Table *opened_dyns;

/* (dyn-open-lib dyn_name) */
static Scheme_Object *dyn_open_lib(int argc, Scheme_Object *argv[])
{
  char *filename;
  void *handle;
  DynLib *dyn;
  if (!SCHEME_STRINGP(argv[0]))
    scheme_wrong_type("dyn-open-lib", "string", 0, argc, argv);
  /* don't touch the filename since the system will look for it */
  filename = SCHEME_STR_VAL(argv[0]);
  dyn = scheme_lookup_in_table(opened_dyns, filename);
  if (!dyn) {
    handle = dlopen(filename, RTLD_NOW | RTLD_GLOBAL);
    if (!handle)
      scheme_raise_exn(MZEXN_I_O_FILESYSTEM,
                       scheme_make_string(filename),
                       "dyn-open-lib: couldn't open \"%s\" (%s)",
                       filename, dlerror());
    dyn = (DynLib*)scheme_malloc_stubborn(sizeof(DynLib));
    dyn->type = dyn_lib_type;
    dyn->handle = handle;
    dyn->filename = filename;
    scheme_end_stubborn_change(dyn);
    scheme_add_to_table(opened_dyns, filename, dyn, 0);
  }
  return (Scheme_Object*)dyn;
}

/*****************************************************************************/

static Scheme_Hash_Table *sym_to_handle;

static Scheme_Type handle_type;
typedef struct {
  Scheme_Type type;
  void *ptr; /* anything can come here */
} Handle;

/* A list used for mapping Scheme_Type to symbol strings, NOT a Scheme type */
typedef struct handle_symbol_struct {
  Scheme_Type   type;
  Scheme_Object *sym;
  struct handle_symbol_struct *next;
} HandleSymbol;
HandleSymbol* handle_to_sym;

#define HANDLE_VAL(x) (((Handle*)x)->ptr)
Scheme_Object *internal_make_handle(Scheme_Type type, void *p)
{
  /* not atomic - a handle might be a pointer */
  Handle *ptr = (Handle*)scheme_malloc_stubborn(sizeof(Handle));
  ptr->type = type;
  ptr->ptr  = p;
  scheme_end_stubborn_change(ptr);
  return (Scheme_Object*)ptr;
}

HandleSymbol *make_handle_symbol(Scheme_Type type,
                                 Scheme_Object* sym, HandleSymbol *p)
{
  /* not atomic - a handle might be a pointer */
  HandleSymbol *hs = (HandleSymbol*)scheme_malloc(sizeof(HandleSymbol));
  hs->type = type;
  hs->sym  = sym;
  return hs;
}

void initialize_handles()
{
  Scheme_Object *sym;
  sym_to_handle = scheme_hash_table(0, SCHEME_hash_ptr, 0, 0);
  scheme_register_extension_global(&sym_to_handle, sizeof(sym_to_handle));
  /* no need to register the list since it is all in the hash table */
  handle_type = scheme_make_type("<handle>");
  sym = scheme_intern_symbol("handle");
  handle_to_sym = make_handle_symbol(handle_type, sym, NULL);
  scheme_add_to_table(sym_to_handle, (void*)sym, handle_to_sym, 0);
}

HandleSymbol *get_handle_symbol(Scheme_Object *obj)
{
  HandleSymbol *p = handle_to_sym;
  Scheme_Type t = SCHEME_TYPE(obj);
  while (p != NULL)
    if (t == p->type) return p;
    else p = p->next;
  return NULL;
}

/* (handle? obj) -> boolean */
static Scheme_Object *handlep(int argc, Scheme_Object *argv[])
{
  return get_handle_symbol(argv[0])==NULL ? scheme_false : scheme_true;
}

/* (make-handle symbol number) -> handle */
/* Generally should not be used (can segfault, no finalizer etc), better let C
 * functions make handles. */
static Scheme_Object *make_handle(int argc, Scheme_Object *argv[])
{
  HandleSymbol *hs;
  unsigned long n;
  if (!SCHEME_SYMBOLP(argv[0]))
    scheme_wrong_type("make-handle", "symbol", 0, argc, argv);
  hs = (HandleSymbol*)scheme_lookup_in_table(sym_to_handle, (void*)(argv[0]));
  if (!SCHEME_INTP(argv[1]) && !SCHEME_BIGNUMP(argv[1]))
    scheme_wrong_type("make-handle", "integer", 1, argc, argv);
  if (!scheme_get_unsigned_int_val(argv[1], &n))
    scheme_raise_exn(MZEXN_MISC, "make-handle: bignum too large.");
  return internal_make_handle(hs->type, (void*)n);
}

/* (null-handle? handle) -> boolean */
static Scheme_Object *null_handle_p(int argc, Scheme_Object *argv[])
{
  if (get_handle_symbol(argv[0]) == NULL)
    scheme_wrong_type("null-handle?", "handle", 0, argc, argv);
  return ((Handle*)argv[0])->ptr == NULL ? scheme_true : scheme_false;
}

/* (get-handle-type handle) -> symbol */
static Scheme_Object *get_handle_type(int argc, Scheme_Object *argv[])
{
  HandleSymbol *hs = get_handle_symbol(argv[0]);
  if (hs == NULL)
    scheme_wrong_type("get-handle-type", "handle", 0, argc, argv);
  return hs->sym;
}

/* (get-handle-value handle) -> integer */
static Scheme_Object *get_handle_value(int argc, Scheme_Object *argv[])
{
  HandleSymbol *hs = get_handle_symbol(argv[0]);
  if (hs == NULL)
    scheme_wrong_type("get-handle-value", "handle", 0, argc, argv);
  return
    scheme_make_integer_value_from_unsigned
      ((unsigned long)(((Handle*)argv[0])->ptr));
}

/*****************************************************************************/

/* (truncate-at-nul str) -> str */
static Scheme_Object *truncate_at_nul(int argc, Scheme_Object *argv[])
{
  int i;
  if (!SCHEME_STRINGP(argv[0]))
    scheme_wrong_type("truncate-at-nul", "string", 0, argc, argv);
  for ( i = 0; SCHEME_STR_VAL(argv[0])[i]; i++ ) ;
  return scheme_make_sized_string(SCHEME_STR_VAL(argv[0]), i, 1);
}

/*****************************************************************************/

/* Some of these are arbitrary */
#define DYN_NO_TYPE        scheme_undefined_type
#define DYN_VOID_TYPE      scheme_void_type
#define DYN_FIXNUM_TYPE    scheme_integer_type
#define DYN_INTEGER_TYPE   scheme_bignum_type
#define DYN_UNSIGNED_TYPE  scheme_manager_type
#define DYN_BOOLEAN_TYPE   scheme_true_type
/*#define DYN_CHARACTER_TYPE scheme_char_type*/
#define DYN_STRING_TYPE    scheme_string_type
/*#define DYN_FLOAT_TYPE     scheme_float_type
#define DYN_DOUBLE_TYPE    scheme_double_type*/
#define DYN_SCHEME_TYPE    scheme_generic_type
#define DYN_AUTO_TYPE      scheme_config_type

Scheme_Type dyn_type(Scheme_Object *x, int error_if_none)
{
  HandleSymbol *p;
  if (!SCHEME_SYMBOLP(x))
    scheme_raise_exn(MZEXN_APPLICATION_TYPE, x,
                     scheme_intern_symbol("type-tag"),
                     "dyn-type: expected a <type-tag> argument; given %s",
                     scheme_make_provided_string(x, 1, NULL));
  #define SYMBOL scheme_intern_symbol
  /* could put these symbols in globals, but no need for efficiency here */
  if (SAME_OBJ((x),SYMBOL("void")))      return DYN_VOID_TYPE;
  if (SAME_OBJ((x),SYMBOL("fixnum")))    return DYN_FIXNUM_TYPE;
  if (SAME_OBJ((x),SYMBOL("integer")))   return DYN_INTEGER_TYPE;
  if (SAME_OBJ((x),SYMBOL("unsigned")))  return DYN_UNSIGNED_TYPE;
  if (SAME_OBJ((x),SYMBOL("boolean")))   return DYN_BOOLEAN_TYPE;
  /*if (SAME_OBJ((x),SYMBOL("character"))) return DYN_CHARACTER_TYPE;*/
  if (SAME_OBJ((x),SYMBOL("string")))    return DYN_STRING_TYPE;
  /*if (SAME_OBJ((x),SYMBOL("float")))     return DYN_FLOAT_TYPE;*/
  /*if (SAME_OBJ((x),SYMBOL("double")))    return DYN_DOUBLE_TYPE;*/
  if (SAME_OBJ((x),SYMBOL("scheme")))    return DYN_SCHEME_TYPE;
  if (SAME_OBJ((x),SYMBOL("auto")))      return DYN_AUTO_TYPE;
  #undef SYMBOL
  p = (HandleSymbol*)scheme_lookup_in_table(sym_to_handle, (void*)x);
  if (p != NULL) return p->type;
  if (error_if_none)
    scheme_raise_exn(MZEXN_APPLICATION_TYPE, x,
                     scheme_intern_symbol("type-tag"),
                     "dyn-type: expected a <type-tag> argument; given %s",
                     scheme_make_provided_string(x, 1, NULL));
  return DYN_NO_TYPE;
}

void *Scheme_to_C(Scheme_Type type, Scheme_Object *obj,
                  char *name, int i, int argc, Scheme_Object *argv[])
{
  if (type == DYN_VOID_TYPE) {
    return (void*)NULL;
  }
  if (type == DYN_FIXNUM_TYPE) {
    if (!SCHEME_INTP(obj))
      scheme_wrong_type(name, "fixnum", i, argc, argv);
    return (void*)SCHEME_INT_VAL(obj);
  }
  if (type == DYN_INTEGER_TYPE) {
    long n;
    if (SCHEME_INTP(obj))
      return (void*)SCHEME_INT_VAL(obj);
    if (!SCHEME_BIGNUMP(obj))
      scheme_wrong_type(name, "integer", i, argc, argv);
    if (!scheme_get_int_val(argv[1], &n))
      scheme_raise_exn(MZEXN_MISC, "%s: bignum too large.", name);
    return (void*)n;
  }
  if (type == DYN_UNSIGNED_TYPE) {
    unsigned long n;
    if (!SCHEME_INTP(obj) && !SCHEME_BIGNUMP(obj))
      scheme_wrong_type(name, "integer", i, argc, argv);
    if (!scheme_get_unsigned_int_val(obj, &n))
      scheme_raise_exn(MZEXN_MISC, "%s: bignum too large.", name);
    return (void*)n;
  }
  if (type == DYN_BOOLEAN_TYPE) {
    if (!SCHEME_BOOLP(obj))
      scheme_wrong_type(name, "boolean", i, argc, argv);
    return (void*)((obj==scheme_false)?0:1);
  }
  /*if (type == DYN_CHARACTER_TYPE) {
    if (!SCHEME_CHARP(obj))
      scheme_wrong_type(name, "character", i, argc, argv);
    return (void*)SCHEME_CHAR_VAL(obj);
  }*/
  if (type == DYN_STRING_TYPE) {
    if (!SCHEME_STRINGP(obj))
      scheme_wrong_type(name, "string", i, argc, argv);
    return (void*)SCHEME_STR_VAL(obj);
  }
  /*if (type == DYN_FLOAT_TYPE) {
    return (void*)(float)scheme_real_to_double(obj);
  }*/
  /*if (type == DYN_DOUBLE_TYPE) {
    return (void*)scheme_real_to_double(obj);
  }*/
  if (type == DYN_SCHEME_TYPE) {
    return (void*)obj;
  }
  if (type == DYN_AUTO_TYPE) {
    if (obj == scheme_false ||
        obj == scheme_null)
      return (void*)0;
    if (obj == scheme_true)
      return (void*)1;
    if (SCHEME_INTP(obj))
      return (void*)SCHEME_INT_VAL(obj);
    if (SCHEME_BIGNUMP(obj)) {
      long n;
      if (!scheme_get_int_val(argv[1], &n))
        scheme_raise_exn(MZEXN_MISC, "%s: bignum too large.", name);
      return (void*)n;
    }
    /* HANDLE CHARACTERS HERE */
    if (SCHEME_STRINGP(obj))
      return (void*)SCHEME_STR_VAL(obj);
    /* HANDLE FLOATS HERE */
    {
      /* Handle or error */
      HandleSymbol *hs = get_handle_symbol(obj);
      if (hs == NULL)
        scheme_wrong_type(name, "auto-convertible", i, argc, argv);
      return HANDLE_VAL(obj);
    }
  }
  /* can be either a handle or a user handle, both behave the same */
  if (SCHEME_TYPE(obj) != type) {
    scheme_wrong_type(name, SCHEME_SYM_VAL(get_handle_symbol(obj)->sym),
                      i, argc, argv);
  }
  return (void*)HANDLE_VAL(obj);
}

Scheme_Object *C_to_Scheme(Scheme_Type type, void *obj)
{
  if (type == DYN_VOID_TYPE)
    return scheme_void;
  if (type == DYN_FIXNUM_TYPE)
    return scheme_make_integer((int)obj);
  if (type == DYN_INTEGER_TYPE)
    return scheme_make_integer_value((long)obj);
  if (type == DYN_UNSIGNED_TYPE)
    return scheme_make_integer_value_from_unsigned((unsigned long)obj);
  if (type == DYN_BOOLEAN_TYPE)
    return ((int)obj) ? scheme_true : scheme_false;
  /*if (type == DYN_CHARACTER_TYPE)
    return scheme_make_char((char)obj);*/
  if (type == DYN_STRING_TYPE) /* return the exact string */
    return scheme_make_string_without_copying((char*)obj);
  /*if (type == DYN_FLOAT_TYPE)
    return scheme_make_double((float)obj);*/ /* use only doubles */
  /*if (type == DYN_DOUBLE_TYPE)
    return scheme_make_double((double)obj);*/
  if (type == DYN_SCHEME_TYPE)
    return (Scheme_Object*)obj;
  if (type == DYN_AUTO_TYPE) /* auto for output is always an integer */
    return scheme_make_integer_value((long)obj);
  /* can be either a handle or a user handle, both behave the same */
  return internal_make_handle(type, (void*)obj);
}

/* (add-handle-type handle-symbol) */
static Scheme_Object *add_handle_type(int argc, Scheme_Object *argv[])
{
  char *tname;
  HandleSymbol *p, *hs;
  if (!SCHEME_SYMBOLP(argv[0]))
    scheme_wrong_type("add-handle-type", "symbol", 0, argc, argv);
  if (dyn_type(argv[0],0) != DYN_NO_TYPE) {
    if (scheme_lookup_in_table(sym_to_handle, (void*)argv[0]))
      /* shut-up, in case loading a file twice... */
      return scheme_void;
    else
      scheme_raise_exn(MZEXN_MISC, "add-handle-type: %s is a built-in type.",
                       SCHEME_SYM_VAL(argv[0]));
  }
  tname = (char*)scheme_malloc_atomic(strlen(SCHEME_SYM_VAL(argv[0]))+12);
  strcpy(tname, "<handle:");
  strcat(tname, SCHEME_SYM_VAL(argv[0]));
  strcat(tname, ">");
  hs = make_handle_symbol(scheme_make_type(tname), argv[0], NULL);
  p = handle_to_sym;
  while (p->next != NULL) p = p->next;
  p->next = hs;
  scheme_add_to_table(sym_to_handle, (void*)argv[0], hs, 0);
  return scheme_void;
}

/* (dyn-convert in-type obj out-type) */
/* For rare situations, can crash... */
static Scheme_Object *dyn_convert(int argc, Scheme_Object *argv[])
{
  Scheme_Type in_t  = dyn_type(argv[0], 1);
  Scheme_Type out_t = dyn_type(argv[2], 1);
  return
    C_to_Scheme(out_t,
                Scheme_to_C(in_t, argv[1], "dyn-convert", 1, argc, argv));
}

/*****************************************************************************/

typedef struct { /* Used for C closures, so no need for a scheme type tag */
  void*   func;
  char*   name;
  int     argc;
  Scheme_Type   otype;
  Scheme_Type   *itypes;
  Scheme_Object *finalizer;
} Wrap;

#define MAXARGS 30
#define A10 a[0],a[1],a[2],a[3],a[4],a[5],a[6],a[7],a[8],a[9],a[10]
#define A20 A10,a[11],a[12],a[13],a[14],a[15],a[16],a[17],a[18],a[19],a[20]
#define BB break;

typedef void *(*FuncType)();

void dyn_finalizer(void *p, void *finalizer)
{
  _scheme_apply((Scheme_Object*)finalizer, 1, (Scheme_Object**)&p);
}

static Scheme_Object *dyn_inner(void *data, int argc, Scheme_Object *argv[])
{
  Scheme_Object *result;
  Wrap *w = (Wrap*)data;
  static void *a[MAXARGS];
  FuncType f = ((FuncType)(w->func));
  void *r;
  int  i;
  for ( i = 0; i < w->argc; i++ )
    a[i] = Scheme_to_C(w->itypes[i], argv[i], w->name, i, argc, argv);
  switch (w->argc) {
  case  0: r = f(); BB
  case  1: r = f(a[0]); BB
  case  2: r = f(a[0],a[1]); BB
  case  3: r = f(a[0],a[1],a[2]); BB
  case  4: r = f(a[0],a[1],a[2],a[3]); BB
  case  5: r = f(a[0],a[1],a[2],a[3],a[4]); BB
  case  6: r = f(a[0],a[1],a[2],a[3],a[4],a[5]); BB
  case  7: r = f(a[0],a[1],a[2],a[3],a[4],a[5],a[6]); BB
  case  8: r = f(a[0],a[1],a[2],a[3],a[4],a[5],a[6],a[7]); BB
  case  9: r = f(a[0],a[1],a[2],a[3],a[4],a[5],a[6],a[7],a[8]); BB
  case 10: r = f(a[0],a[1],a[2],a[3],a[4],a[5],a[6],a[7],a[8],a[9]); BB
  case 11: r = f(A10); BB
  case 12: r = f(A10,a[11]); BB
  case 13: r = f(A10,a[11],a[12]); BB
  case 14: r = f(A10,a[11],a[12],a[13]); BB
  case 15: r = f(A10,a[11],a[12],a[13],a[14]); BB
  case 16: r = f(A10,a[11],a[12],a[13],a[14],a[15]); BB
  case 17: r = f(A10,a[11],a[12],a[13],a[14],a[15],a[16]); BB
  case 18: r = f(A10,a[11],a[12],a[13],a[14],a[15],a[16],a[17]); BB
  case 19: r = f(A10,a[11],a[12],a[13],a[14],a[15],a[16],a[17],a[18]); BB
  case 20: r = f(A10,a[11],a[12],a[13],a[14],a[15],a[16],a[17],a[18],a[19]); BB
  case 21: r = f(A20); BB
  case 22: r = f(A20,a[21]); BB
  case 23: r = f(A20,a[21],a[22]); BB
  case 24: r = f(A20,a[21],a[22],a[23]); BB
  case 25: r = f(A20,a[21],a[22],a[23],a[24]); BB
  case 26: r = f(A20,a[21],a[22],a[23],a[24],a[25]); BB
  case 27: r = f(A20,a[21],a[22],a[23],a[24],a[25],a[26]); BB
  case 28: r = f(A20,a[21],a[22],a[23],a[24],a[25],a[26],a[27]); BB
  case 29: r = f(A20,a[21],a[22],a[23],a[24],a[25],a[26],a[27],a[28]); BB
  case 30: r = f(A20,a[21],a[22],a[23],a[24],a[25],a[26],a[27],a[28],a[29]); BB
  default: r = NULL; /* satisfy the compiler */
  }
  result = C_to_Scheme(w->otype, r);
  if (w->finalizer != scheme_void)
    scheme_register_finalizer(result, dyn_finalizer, w->finalizer, NULL, NULL);
  return result;
}

#undef A10
#undef A20
#undef BB

/*****************************************************************************/

/* (dyn-function dyn-or-dyn_name func-name in-types [out-type]) -> function */
static Scheme_Object *dyn_function(int argc, Scheme_Object *argv[])
{
  DynLib *dyn = NULL;
  char *dsym;
  void *func;
  char *name;
  int  len, i;
  Scheme_Object *p;
  Wrap *w;
  if (SCHEME_TYPE(argv[0]) == dyn_lib_type)
    dyn = (DynLib*)argv[0];
  else if (SCHEME_STRINGP(argv[0]))
    dyn = (DynLib*)(dyn_open_lib(1,&argv[0]));
  else
    scheme_wrong_type("dyn-function", "dynamic-library", 0, argc, argv);
  if (!SCHEME_STRINGP(argv[1]))
    scheme_wrong_type("dyn-function", "string", 0, argc, argv);
  dsym = SCHEME_STR_VAL(argv[1]);
  len = scheme_proper_list_length(argv[2]);
  if (len < 0 || len > MAXARGS)
    scheme_wrong_type("dyn-function", "type-tag-list", 0, argc, argv);
  func = dlsym(dyn->handle, dsym);
  if (func == NULL)
    scheme_raise_exn(MZEXN_I_O_FILESYSTEM,
                     scheme_make_string(dsym),
                     "dyn-function: couldn't get \"%s\" (%s)",
                     dsym, dlerror());
  name = (char*)scheme_malloc_atomic(strlen(dyn->filename)+strlen(dsym)+2);
  strcpy(name, dyn->filename);
  strcat(name, ":");
  strcat(name, dsym);
  w = (Wrap*)scheme_malloc_stubborn(sizeof(Wrap));
  w->func  = func;
  w->name  = name;
  w->otype = (argc == 4) ? dyn_type(argv[3],1) : DYN_VOID_TYPE;
  w->argc  = len;
  w->itypes = scheme_malloc_stubborn(len*sizeof(Scheme_Type));
  for ( p = argv[2], i = 0; p != scheme_null; p = scheme_cdr(p), i++)
    w->itypes[i] = dyn_type(scheme_car(p),1);
  w->finalizer = scheme_void;
  scheme_end_stubborn_change(w->itypes);
  scheme_end_stubborn_change(w);
  return scheme_make_closed_prim_w_arity(dyn_inner, w, name, len, len);
}

/* (dyn-register-finalizer-for-constructor dyn-func-name func)
 *   -- returns void, or old finalizer in case of change.
 *   -- just simple things, better use wills for complicated stuff. */
static Scheme_Object*
dyn_register_finalizer_for_constructor(int argc, Scheme_Object *argv[])
{
  Scheme_Closed_Primitive_Proc *prim = (Scheme_Closed_Primitive_Proc*)argv[0];
  Scheme_Object *old_finalizer;
  if (SCHEME_TYPE(prim) != scheme_closed_prim_type &&
      SCHEME_CLSD_PRIM(prim) != dyn_inner)
    scheme_wrong_type("dyn-register-finalizer-for-constructor",
                      "dyn-function", 0, argc, argv);
  if (!SCHEME_PROCP(argv[1]))
    scheme_wrong_type("dyn-register-finalizer-for-constructor",
                      "function", 1, argc, argv);
  old_finalizer = ((Wrap*)(SCHEME_CLSD_PRIM_DATA(prim)))->finalizer;
  ((Wrap*)(SCHEME_CLSD_PRIM_DATA(prim)))->finalizer = argv[1];
  return old_finalizer;
}

/*****************************************************************************/

#define ADD_PRIM(name,dashed,args) \
  scheme_add_global( \
      dashed, scheme_make_prim_w_arity(name, dashed, args, args), env)
#define ADD_PRIM2(name,dashed,mina, maxa) \
  scheme_add_global( \
      dashed, scheme_make_prim_w_arity(name, dashed, mina, maxa), env)

Scheme_Object *scheme_reload(Scheme_Env *env) {
  ADD_PRIM(dyn_open_lib,     "dyn-open-lib",     1);
  ADD_PRIM2(dyn_function,    "dyn-function",     3, 4);
  ADD_PRIM(dyn_register_finalizer_for_constructor,
           "dyn-register-finalizer-for-constructor", 2);
  ADD_PRIM(truncate_at_nul,  "truncate-at-nul",  1);
  ADD_PRIM(handlep,          "handle?",          1);
  ADD_PRIM(make_handle,      "make-handle",      2);
  ADD_PRIM(null_handle_p,    "null-handle?",     1);
  ADD_PRIM(get_handle_type,  "get-handle-type",  1);
  ADD_PRIM(get_handle_value, "get-handle-value", 1);
  ADD_PRIM(add_handle_type,  "add-handle-type",  1);
  ADD_PRIM(dyn_convert,      "dyn-convert",      3);
  return scheme_void;
}

Scheme_Object *scheme_initialize(Scheme_Env *env) {
  dyn_lib_type = scheme_make_type("<dynamic-library>");
  opened_dyns = scheme_hash_table(0, SCHEME_hash_string, 0, 0);
  scheme_register_extension_global(&opened_dyns, sizeof(opened_dyns));
  initialize_handles();
  return scheme_reload(env);
}

/*****************************************************************************/

