This directory contains implementations of the models in

 Macros that Work Together
 Flatt, Culpepper, Darais, and Findler

to run in Racket version 5.0 or later.

The models sources are

  mm-runtime.ss --- section 3.2
  mm-parse2.ss --- section 3.3
  mm-defmacro.ss --- section 3.4
  mm-stxcase.ss --- section 3.5
  mm-local.ss --- section 3.6
  mm-defs.ss --- section 3.7

Except for the first, each contains a number of examples bound with
`define-example'. Run the file in DrRacket, then for an example like
`simple-parse-example', run it in one of the following ways using the
DrScheme interactions window:

 * (simple-parse-example 'expand) --- produces the expansion result
 * (simple-parse-example 'parse) --- parses the expansion to an AST
