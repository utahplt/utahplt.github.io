#lang scheme
(require redex
         "rewrites.ss"
         "define-example.ss"
         slideshow/pict)

(define-language mini
  
  ;; Executable AST and values:
  [ast var (App ast ast ...) val]
  [val (Fun var ast) atom
       (List val ...) stx (Defs σ)]
  [pre-val desc-other-atom (Defs σ)]
  
  ;; Syntax objects (a subset of values):
  [stx (Stx atom ctx)
       (Stx (List stx ...) ctx)]
  [id (Stx sym ctx)]
  [pre-ctx desc-other-atom (Rename ctx id var σ) (Defs ctx σ)]
  [ctx •
       (Rename ctx id var σ)
       (Mark ctx mrk)
       (Defs ctx σ)]
       
  ;; Literal values:
  [atom sym prim tprim desc-other-atom] ; `desc-other-atom' typesets as "...."
  [desc-other-atom number]
  [sym (Sym var)]
  [prim SE MKS desc-other-prim] ; `desc-other-prim' typesets as "...."
  [desc-other-prim + - CONS CAR CDR LIST]
  [tprim desc-old-tprim NEW-DEFS DEF-BIND]
  [desc-old-tprim LOCAL-VALUE LOCAL-EXPAND]
  [all-tprim NEW-DEFS DEF-BIND LOCAL-VALUE LOCAL-EXPAND] ; for typesetting

  ;; Expand-time environment:
  [env desc-env] ; `desc-env' typesets as prose
  [desc-env ((var transformer) ...)]
  [transformer TFun TLet-Syntax TQuote
               (TVar id) val TStop]
  
  ;; Definition-context and store:
  [σ addr NULL]
  [Σ desc-Σ] ; `desc-Σ' typesets as prose
  [desc-Σ ((σ (id var) ...) ...)]  
  [S desc-S] ; `desc-S' typesets as prose
  [desc-S (σ ...)]

  ;; Use variables for vars, addrs, and marks
  [(var addr mrk) desc-name] ; `desc-name' typesets as prose
  [desc-name variable-not-otherwise-mentioned]
  
  ;; For name generation:
  [gen (number ...)]
  [env+gen (Fst env gen)]
  [mrk+gen (Fst mrk gen)])

;; ----------------------------------------
;; Non-capturing substitution for AST:

(define-metafunction mini
  subst : ast var ast -> ast
  [(subst var var ast_v) ast_v]
  [(subst var_2 var ast_v) var_2]
  [(subst (App ast ...) var ast_v)
   (App (subst ast var ast_v) ...)]
  [(subst (Fun var ast) var ast_v)
   (Fun var ast)]
  [(subst (Fun var_2 ast) var ast_v)
   (Fun var_3 (subst (subst ast var_2 var_3) var ast_v))
   (where var_3 ,(variable-not-in (term ast_v) (term var_2)))]
  [(subst atom var ast_v) atom]
  [(subst (List val ...) var ast_v) 
   (List (subst val var ast_v) ...)]
  [(subst stx var ast_v) stx]
  [(subst (Defs σ) var ast_v) (Defs σ)])

;; ----------------------------------------
;; Generic metafunctions that typeset as set operations:

(define-metafunction mini
  [(is-in? any_1 ()) #f]
  [(is-in? any_1 (any_1 any_2 ...)) #t]
  [(is-in? any_1 (any_2 any_3 ...)) (is-in? any_1 (any_3 ...))])

(define-metafunction mini
  [(emptyset) ()])

(define-metafunction mini
  [(add-elem any_1 any_2) (any_1 . any_2)])

(define-metafunction mini
  [(same? any_1 any_2) ,(equal? (term any_1) (term any_2))])

;; ----------------------------------------
;; Implementation of primitives:

(define-metafunction mini
  [(plus number_1 number_2) ,(+ (term number_1) (term number_2))])
(define-metafunction mini
  [(minus number_1 number_2) ,(+ (term number_1) (term number_2))])

(define-metafunction mini
  δ/stx : prim (val ...) -> val
  [(δ/stx SE ((Stx val ctx))) val]
  [(δ/stx MKS (atom (Stx val ctx))) (Stx atom ctx)]
  [(δ/stx MKS ((List stx ...) (Stx val ctx))) (Stx (List stx ...) ctx)])

(define-metafunction/extension δ/stx mini
  δ : prim (val ...) -> val
  [(δ + (number_1 number_2)) (plus number_1 number_2)]
  [(δ - (number_1 number_2)) (minus number_1 number_2)]
  [(δ CONS (val_1 (List val_2 ...))) (List val_1 val_2 ...)]
  [(δ CAR ((List val_1 val_2 ...))) val_1]
  [(δ CDR ((List val_1 val_2 ...))) (List val_2 ...)]
  [(δ LIST (val ...)) (List val ...)])

;; ----------------------------------------
;; Evaluating AST:

(define-metafunction mini
  eval : ast env mrk+gen Σ -> (StE val env Σ)
  
  ;; standard eval
  [(eval (App (Fun var ast_body) ast_arg) env (Fst mrk gen) Σ)
   (eval (subst ast_body var val) env_1 [Fst mrk (1 . gen)] Σ_1)
   (where [StE val env_1 Σ_1] (eval ast_arg env (Fst mrk (0 . gen)) Σ))]
  [(eval (App prim ast_arg ...) env (Fst mrk gen) Σ)
   [StE (δ prim (val ...)) env_1 Σ_1]
   (where [StE (val ...) env_1 Σ_1] (eval* () (ast_arg ...) env (Fst mrk (0 . gen)) Σ))]
  [(eval val env (Fst mrk gen) Σ) [StE val env Σ]]

  ;; local value
  [(eval (App LOCAL-VALUE ast) env (Fst mrk gen) Σ)
   [StE (lookup env (resolve (mark stx mrk) Σ_1)) env_1 Σ_1]
   (where [StE stx env_1 Σ_1] (eval ast env (Fst mrk gen) Σ))]

  ;; local expand
  [(eval (App LOCAL-EXPAND ast_expr ast_stops ast_defs) env (Fst mrk gen) Σ)
   [StE (mark stx mrk) env_3 Σ_4]
   (where [StE stx_expr env_1 Σ_1] (eval ast_expr env (Fst mrk (0 . gen)) Σ))
   (where [StE (List id_stop ...) env_2 Σ_2] (eval ast_stops env_1 (Fst mrk (1 . gen)) Σ_1))
   (where [StE (Defs σ) env_3 Σ_3] (eval ast_defs env_2 (Fst mrk (2 . gen)) Σ_2))
   (where env_stops (extend* (nostops env_3) (((resolve id_stop Σ_3) TStop) ...)))
   (where stx_new (defs (mark stx_expr mrk) σ))
   (where [St stx Σ_4] (expand stx_new (Fst env_stops (3 . gen)) Σ_3))]
  
  ;; create definition context
  [(eval (App NEW-DEFS) env (Fst mrk gen) Σ)
   [StE (Defs σ) env (alloc Σ σ)]
   (where σ (fresh-variable (Stx (Sym σ) •) gen))]

  ;; bind variable in definition context
  [(eval (App DEF-BIND ast_defs ast_id) env (Fst mrk gen) Σ)
   [StE 0 (extend env_2 var_new (TVar id_new)) Σ_3]
   (where [StE (Defs σ) env_1 Σ_1] (eval ast_defs env (Fst mrk (0 . gen)) Σ))
   (where [StE id env_2 Σ_2] (eval ast_id env_1 (Fst mrk (1 . gen)) Σ_1))
   (where var_new (fresh-variable id gen))
   (where id_new (rename id id var_new))
   (where Σ_3 (store Σ_2 σ (mark id mrk) var_new) )]

  ;; bind expand-time value in definition context
  [(eval (App DEF-BIND ast_defs ast_id ast_stx) env (Fst mrk gen) Σ)
   [StE 0 (extend env_4 var_new val) Σ_5]
   (where [StE (Defs σ) env_1 Σ_1] (eval ast_defs env (Fst mrk (0 . gen)) Σ))
   (where [StE id env_2 Σ_2] (eval ast_id env_1 (Fst mrk (1 . gen)) Σ_1))
   (where [StE stx env_3 Σ_3] (eval ast_stx env_2 (Fst mrk (2 . gen)) Σ_2))
   (where [StE val env_4 Σ_4] (eval (parse stx Σ_3) env_3 (Fst mrk (3 . gen)) Σ_3))
   (where var_new (fresh-variable id gen))
   (where id_new (rename id id var_new))
   (where Σ_5 (store Σ_4 σ (mark id mrk) var_new))])

(define-metafunction mini
  eval* : (val ...) (ast ...) env mrk+gen Σ -> (StE (val ...) env Σ)
  [(eval* (val ...) () env (Fst mrk gen) Σ) (StE (val ...) env Σ)]
  [(eval* (val ...) (ast_0 ast_1 ...) env [Fst mrk (number_0 number ...)] Σ)
   (eval* (val ... val_0) (ast_1 ...) env_1 [Fst mrk (number_1 number ...)] Σ_1)
   (where [StE val_0 env_1 Σ_1] (eval ast_0 env [Fst mrk (number_0 number ...)] Σ))
   (where/hidden number_1 ,(add1 (term number_0)))])
  
;; ----------------------------------------
;; Definition-context store operations:

(define-metafunction mini
  alloc : Σ σ -> Σ
  [(alloc Σ σ) ((σ) . Σ)])

(define-metafunction mini
  store : Σ σ id var -> Σ
  [(store ((σ any_1 ...) any_2 ...) σ id var) 
   ((σ (id var) any_1 ...) any_2 ...)]
  [(store (any_1 any_2 ...) σ id var)
   ,(cons (term any_1) (term (store (any_2 ...) σ id var)))])

(define-metafunction mini
  [(store-lookup (any_1 ... (σ (id var_new) ...) any_2 ...) σ)
   (store-val ((id var_new) ...))]
  [(store-lookup any_1 any_2) #f])

;; ----------------------------------------
;; Syntax-object operations:

(define-metafunction mini
  ;; Adds or cancels a mark
  addremove : mrk (mrk ...) -> (mrk ...)
  [(addremove mrk_1 (mrk_1 mrk_2 ...)) (mrk_2 ...)]
  [(addremove mrk_1 (mrk_2 ...)) (mrk_1 mrk_2 ...)])

(define-metafunction mini
  ;; Extracts all marks in order, removing cancelling pairs
  marksof : id -> (mrk ...)
  [(marksof (Stx val •)) ()]
  [(marksof (Stx val (Mark ctx mrk)))
   (addremove mrk (marksof (Stx val ctx)))]
  [(marksof (Stx val (Rename ctx id var σ))) (marksof (Stx val ctx))]
  [(marksof (Stx val (Defs ctx σ))) (marksof (Stx val ctx))])

(define-metafunction mini
  ;; Unrolls a set of definition-context renamings into `Reaname's
  renames : σ ((id var) ...) ctx -> ctx
  [(renames σ () ctx) ctx]
  [(renames σ ((id var) (id_2 var_2) ...) ctx)
   (renames σ ((id_2 var_2) ...) 
            .((Rename ctx id var σ)))])

(define (bad-resolve-partial-pict)
  (define-metafunction mini
    ;; Resolves an identifier to a variable; this is the heart of
    ;;  the syntax-object support for lexical scope
    resolve : id Σ -> var
    [(resolve (Stx val (Defs ctx σ)) Σ)
     (resolve (Stx val ctx_new) Σ)
     (where (store-val ((id var_new) ...)) (store-lookup Σ σ))
     (where ctx_new (renames σ ((id var_new) ...) ctx))])
  (metafunction->pict resolve))

(define (resolve*-partial-pict)
  (define-metafunction mini
    ;; Resolves an identifier to a variable; this is the heart of
    ;;  the syntax-object support for lexical scope
    resolve* : id Σ S S -> var
    [(resolve* (Stx (Sym var) (Rename ctx id_orig var_new σ)) Σ S_spine S_branch)
     var_new
     (where var_1 (resolve* id_orig Σ S_branch S_branch))
     (where var_2 (resolve* (Stx (Sym var) ctx) Σ (add-elem σ S_spine) S_branch))
     (side-condition (term (same? var_1 var_2)))
     (side-condition (term (same? (marksof id_orig) (marksof (Stx (Sym var) ctx)))))]
    [(resolve* (Stx (Sym var) (Defs ctx σ)) Σ S_spine S_branch)
     (resolve* (Stx (Sym var) ctx) 
               Σ S_spine S_branch)
     (side-condition (term (is-in? σ S_spine)))]
    [(resolve* (Stx (Sym var) (Defs ctx σ)) Σ S_spine S_branch)
     (resolve* (Stx (Sym var) ctx_new) 
               Σ S_spine (add-elem σ S_branch))
     (where (store-val ((id var_new) ...)) (store-lookup Σ σ))
     (where ctx_new (renames σ ((id var_new) ...) ctx))])
  (metafunction->pict resolve*))

(define-metafunction mini
  ;; Resolves an identifier to a variable; this is the heart of
  ;;  the syntax-object support for lexical scope
  resolve* : id Σ S S -> var
  [(resolve* (Stx (Sym var) •) Σ S_spine S_branch) var]
  [(resolve* (Stx (Sym var) (Mark ctx mrk)) Σ S_spine S_branch)
   (resolve* (Stx (Sym var) ctx) 
             Σ S_spine S_branch)]
  [(resolve* (Stx (Sym var) (Rename ctx id_orig var_new σ)) Σ S_spine S_branch)
   var_new
   (where var_1 (resolve* id_orig Σ S_branch S_branch))
   (where var_2 (resolve* (Stx (Sym var) ctx) Σ (add-elem σ S_spine) S_branch))
   (side-condition (term (same? var_1 var_2)))
   (side-condition (term (same? (marksof id_orig) (marksof (Stx (Sym var) ctx)))))]
  [(resolve* (Stx (Sym var) (Rename ctx id_orig var_2 σ)) Σ S_spine S_branch) 
   (resolve* (Stx (Sym var) ctx) 
             Σ S_spine S_branch)]
  [(resolve* (Stx (Sym var) (Defs ctx σ)) Σ S_spine S_branch)
   (resolve* (Stx (Sym var) ctx) 
             Σ S_spine S_branch)
   (side-condition (term (is-in? σ S_spine)))]
  [(resolve* (Stx (Sym var) (Defs ctx σ)) Σ S_spine S_branch)
   (resolve* (Stx (Sym var) ctx_new) 
             Σ S_spine (add-elem σ S_branch))
   (where (store-val ((id var_new) ...)) (store-lookup Σ σ))
   (where ctx_new (renames σ ((id var_new) ...) ctx))])

(define-metafunction mini
  resolve : stx Σ -> var
  ;; Starts `resolve*' with empty skip sets
  [(resolve stx Σ) (resolve* stx Σ (emptyset) (emptyset))])
  
(define-metafunction mini
  rename : stx id var -> stx
  ;; Simply pushes `Rename's down through a syntax object
  [(rename (Stx atom ctx) id var) 
   (Stx atom (Rename ctx id var NULL))]
  [(rename (Stx (List stx ...) ctx) id var) 
   (Stx (List (rename stx id var) ...) 
        (Rename ctx id var NULL))])

(define-metafunction mini
  mark : stx mrk -> stx
  ;; Simply pushes `Mark's down through a syntax object
  [(mark (Stx atom ctx) mrk) 
   (Stx atom (Mark ctx mrk))]
  [(mark (Stx (List stx ...) ctx) mrk) 
   (Stx (List (mark stx mrk) ...) (Mark ctx mrk))])

(define-metafunction mini
  defs : stx σ -> stx
  ;; Simply pushes `Def's down through a syntax object
  [(defs (Stx atom ctx) σ) 
   (Stx atom (Defs ctx σ))]
  [(defs (Stx (List stx ...) ctx) σ) 
   (Stx (List (defs stx σ) ...) (Defs ctx σ))])

(define-metafunction mini
  strip : stx -> val
  ;; Recursively strips lexical context from a syntax object
  [(strip (Stx atom ctx))
   atom]
  [(strip (Stx (List stx ...) ctx)) 
   (List (strip stx) ...)])

;; ----------------------------------------
;; Simple parsing of already-expanded code
;;  (used for expand-time expressions, instead of
;;   modeling multiple phases):

(define-metafunction mini
  parse : stx Σ -> ast
  [(parse (Stx (List id_lambda id_arg stx_body) ctx) Σ)
   (Fun (resolve id_arg Σ) (parse stx_body Σ))
   (where lambda (resolve id_lambda Σ))]
  [(parse (Stx (List id_quote stx) ctx) Σ)
   (strip stx)
   (where quote (resolve id_quote Σ))]
  [(parse (Stx (List id_syntax stx) ctx) Σ)
   stx
   (where syntax (resolve id_syntax Σ))]
  [(parse (Stx (List stx_rator stx_rand ...) ctx) Σ)
   (App (parse stx_rator Σ) (parse stx_rand Σ) ...)]
  [(parse id Σ)
   (resolve id Σ)])

;; ----------------------------------------
;; Expand-time environment operations:

(define-metafunction mini
  lookup : env var -> transformer
  [(lookup ((var transformer) any_2 ...) var) transformer]
  [(lookup (any_1 any_2 ...) var) (lookup (any_2 ...) var)])

(define-metafunction mini
  extend : env var transformer -> env
  [(extend env var transformer) ((var transformer) . env)])

(define-metafunction mini
  extend* : env ((var transformer) ...) -> env
  [(extend* env ((var transformer) ...)) ((var transformer) ... . env)])

(define-metafunction mini
  nostops : env -> env
  [(nostops env)
   ,(filter (lambda (p)
              (not (eq? (cadr p) (term TStop))))
            (term env))])

;; ----------------------------------------
;; Fresh-variable helper for expander:

(define-metafunction mini
  [(fresh-variable (Stx (Sym var) ctx) gen)
   ,(string->symbol (format "~a~a"
                            (term var)
                            (apply
                             string-append
                             (for/list ([c (reverse (term gen))])
                               (format ":~a" c)))))])

(define-metafunction mini
  [(enumerate number) ()]
  [(enumerate number any any_2 ...)
   ,(cons (term number)
          (term (enumerate ,(add1 (term number)) any_2 ...)))])

;; ----------------------------------------
;; The expander:

(define-metafunction mini
  expand : stx env+gen Σ -> (St stx Σ)
  
  ;; lambda
  [(expand (Stx (List id_lam id_arg stx_body) ctx) [Fst env gen] Σ)
   [St (Stx (List id_lam id_new stx_newbody) ctx) Σ_1]
   (where TFun (lookup env (resolve id_lam Σ)))
   (where var_new (fresh-variable id_arg gen))
   (where id_new (rename id_arg id_arg var_new))
   (where stx_newbody (rename stx_body id_arg var_new))
   (where env_new (extend env var_new (TVar id_new)))
   (where [St stx_newbody Σ_1] (expand stx_newbody [Fst env_new (0 . gen)] Σ))]
  
  ;; quote & syntax
  [(expand (Stx (List id_quote stx) ctx) [Fst env gen] Σ)
   [St (Stx (List id_quote stx) ctx) Σ]
   (where TQuote (lookup env (resolve id_quote Σ)))]
  
  ;; macro binding
  [(expand (Stx (List id_ls id_mac stx_rhs stx_body) ctx) [Fst env gen] Σ)
   (expand stx_newbody [Fst (extend env var_new val) (1 . gen)] Σ_1)
   (where TLet-Syntax (lookup env (resolve id_ls Σ)))
   (where var_new (fresh-variable id_mac gen))
   (where [StE val env_1 Σ_1] (eval (parse stx_rhs Σ) env (Fst no-mrk (0 . gen)) Σ))
   (where stx_newbody (rename stx_body id_mac var_new))]

  ;; macro application
  [(expand stx_macapp [Fst env gen] Σ)
   (expand (mark stx_exp mrk_new) [Fst env (1 . gen)] Σ_1)
   (where (Stx (List id_mac stx_arg ...) ctx) stx_macapp)
   (where val (lookup env (resolve id_mac Σ)))
   (where mrk_new (fresh-variable (Stx (Sym mrk) •) gen))   
   (where [StE stx_exp env_1 Σ_1] (eval (App val (mark stx_macapp mrk_new)) env [Fst mrk_new (0 . gen)] Σ))]

  ;; stops
  [(expand (Stx (List id_stop stx ...) ctx) [Fst env gen] Σ)
   [St (Stx (List id_stop stx ...) ctx) Σ]
   (where TStop (lookup env (resolve id_stop Σ)))]

  ;; application
  [(expand (Stx (List stx_rtor stx_rnd ...) ctx) [Fst env gen] Σ)
   [St (Stx (List stx_exprtor stx_exprnd ...) ctx) Σ_1]
   (where [St (stx_exprtor stx_exprnd ...) Σ_1] (expand* () (stx_rtor stx_rnd ...) [Fst env (0 . gen)] Σ))]
  
  ;; reference
  [(expand id [Fst env gen] Σ)
   [St id_new Σ]
   (where (TVar id_new) (lookup env (resolve id Σ)))])

(define-metafunction mini
  expand* : (stx ...) (stx ...) [Fst env gen] Σ -> (St (stx ...) Σ)
  [(expand* (stx_done ...) () [Fst env gen] Σ) (St (stx_done ...) Σ)]
  [(expand* (stx_done ...) (stx_0 stx_1 ...) [Fst env (number_0 number ...)] Σ)
   (expand* (stx_done ... stx_done0) (stx_1 ...) [Fst env (number_1 number ...)] Σ_1)
   (where [St stx_done0 Σ_1] (expand stx_0 [Fst env (number_0 number ...)] Σ))
   (where/hidden number_1 ,(add1 (term number_0)))])

;; ----------------------------------------
;; Helpers for writing examples:

(define-metafunction mini
  preamble-env : -> env
  [(preamble-env) ((lambda TFun)
                   (let-syntax TLet-Syntax)
                   (quote TQuote)
                   (syntax TQuote))])

;; ----------------------------------------
;; Examples:

(define-metafunction mini
  [(parse/st [St stx Σ]) (parse stx Σ)])

(define-example-definer define-example
  mini 
  (lambda (t) (term (expand ,t (Fst (preamble-env) ()) ())))
  parse/st)

(define-example simple-macro-example
  (let-syntax x (lambda z (syntax (quote 2))) (x 1)))

(define-example reftrans-macro-example
  (lambda z (let-syntax x (lambda s (syntax z)) (lambda z (x)))))

(define-example hyg-macro-example
  (lambda z (let-syntax x (lambda s 
                            ('MKS
                             ('LIST (syntax lambda)
                                    (syntax z)
                                    ('CAR ('CDR ('SE s))))
                             (syntax here)))
              (x z))))

(define-example local-value-example
  (let-syntax a '8
    (let-syntax b '9
      (let-syntax x (lambda s 
                      ('MKS
                       ('LIST (syntax quote)
                              ('MKS ('LOCAL-VALUE ('CAR ('CDR ('SE s))))
                                    (syntax here)))
                       (syntax here)))
        (x a)))))

(define-example local-expand-example
  (let-syntax q (lambda s (syntax ('CAR '8)))
    (let-syntax x (lambda s 
                    ;; Used as (x (q)) => extracts '8 from ('CAR '8)
                    ('CAR ('CDR ('SE ('LOCAL-EXPAND ('CAR ('CDR ('SE s))) 
                                                    ('LIST) 
                                                    ('NEW-DEFS))))))
      (x (q)))))

(define-example local-expand-stop-example
  (let-syntax p (lambda s (quote 0))
    (let-syntax q (lambda s (syntax ('CAR '8)))
      (let-syntax x (lambda s 
                      ;; Used as (x (q)) => extracts '8 from ('CAR '8)
                      ('CAR ('CDR ('SE ('LOCAL-EXPAND ('CAR ('CDR ('SE s)))
                                                      ('LIST (syntax p))
                                                      ('NEW-DEFS))))))
        (x (q))))))

(define-example nested-local-expand-example
  (let-syntax z (lambda s (syntax '0))
    (let-syntax a (lambda s
                    ;; When `b' forces `a', then `a'
                    ;; drops `z' form the stop list, so it
                    ;; should expand to 0
                    ('LOCAL-EXPAND ('CAR ('CDR ('SE s)))
                                   ('LIST)
                                   ('NEW-DEFS)))
      (let-syntax b (lambda s
                      ('MKS
                       ('LIST
                        (syntax quote)
                        ('LOCAL-EXPAND ('CAR ('CDR ('SE s)))
                                       ('LIST (syntax z))
                                       ('NEW-DEFS)))
                       s))
        ('LIST (b (z)) (b (a (z))))))))

(define-example defs-shadow-example
  (let-syntax call (lambda s ('MKS ('LIST ('CAR ('CDR ('SE s))))
                                   (syntax here)))
    (let-syntax p (lambda s (syntax '0))
      (let-syntax q (lambda s
                      ((lambda ctx
                         ((lambda ignored
                            ('MKS
                             ('LIST
                              (syntax lambda)
                              ('CAR ('CDR
                                     ('SE
                                      ('LOCAL-EXPAND ('MKS
                                                      ('LIST (syntax syntax)
                                                             ('CAR ('CDR ('SE s))))
                                                      (syntax here))
                                                     ('LIST)
                                                     ctx))))
                              ('LOCAL-EXPAND ('CAR ('CDR ('CDR ('SE s))))
                                             ('LIST (syntax call))
                                             ctx))
                             (syntax here)))
                          ('DEF-BIND ctx ('CAR ('CDR ('SE s))))))
                       ('NEW-DEFS)))
        (q p (call p))))))

(define-example defs-local-macro-example
  (let-syntax call (lambda s ('MKS ('LIST ('CAR ('CDR ('SE s)))) 
                                   (syntax here)))
    (let-syntax p (lambda s (syntax '0))
      (let-syntax q (lambda s
                      ((lambda ctx
                         ((lambda ignored
                            ('MKS
                             ('LIST
                              (syntax lambda)
                              ('CAR ('CDR
                                     ('SE
                                      ('LOCAL-EXPAND ('MKS 
                                                      ('LIST (syntax syntax)
                                                             ('CAR ('CDR ('SE s))))
                                                      (syntax here))
                                                     ('LIST)
                                                     ctx))))
                              ('LOCAL-EXPAND ('CAR ('CDR ('CDR ('SE s))))
                                             ('LIST)
                                             ctx))
                             (syntax here)))
                          ('DEF-BIND ctx ('CAR ('CDR ('SE s)))
                                     ('MKS
                                      ('LIST (syntax lambda)
                                             (syntax s)
                                             ('CAR ('CDR ('CDR ('CDR ('SE s))))))
                                      (syntax here)))))
                       ('NEW-DEFS)))
        (q p (call p) (syntax '13))))))

;; ----------------------------------------
;; Typesetting:

(define (lang->pict)
  (with-rewrites
   (lambda ()
     (ht-append
      20
      (vl-append
       10
       (language->pict mini #:nts '(ast val atom sym prim all-tprim σ))
       (language->pict mini #:nts '(Σ env S)))
      (vl-append
       10
       (language->pict mini #:nts '(stx id ctx))
       (language->pict mini #:nts '(transformer))
       (language->pict mini #:nts '(var addr mrk)))))))

(define (delta->pict)
  (with-rewrites
   (lambda ()
     (vl-append (metafunction->pict δ/stx) (text "..." 'default (default-font-size))))))

(define (parse->pict)
  (with-rewrites
   (lambda ()
     (metafunction->pict parse))))

(define (resolve->pict)
  (with-rewrites
   (lambda ()
     (vl-append
      10
      (metafunction->pict resolve)
      (parameterize (#;[linebreaks '(#f #t #f #t #t #t)])
        (metafunction->pict resolve*))))))

(define (metas->pict)
  (with-rewrites
   (lambda ()
     (vl-append
      10
      (metafunction->pict renames)
      (metafunctions->pict mark rename defs)
      (metafunctions->pict marksof addremove)
      (metafunctions->pict strip)
      (metafunctions->pict nostops)))))

(define (eval->pict)
  (with-rewrites
   (lambda ()
     (vl-append
      10
     (metafunction->pict eval)
     (metafunction->pict eval*)))))

(define (expand->pict)
  (with-rewrites
   (lambda ()
     (vl-append
      10
      (metafunction->pict expand)
      (metafunction->pict expand*)))))

(define (tprim->pict)
  (with-rewrites
   (lambda ()
     (language->pict mini #:nts '(tprim)))))

(define (ctx->pict)
  (with-rewrites
   (lambda ()
     (vl-append
      10
      (language->pict mini #:nts '(pre-ctx pre-val))
      (language->pict mini #:nts '(σ Σ S))))))

(define (bad-resolve->pict)
  (with-rewrites
   (lambda ()
     (parameterize ([linebreaks '(#f)])
       (bad-resolve-partial-pict)))))

(define (renames->pict)
  (with-rewrites
   (lambda ()
     (parameterize ([linebreaks '(#f #f)])
       (metafunction->pict renames)))))

(define (resolve*->pict)
  (with-rewrites
   (lambda ()
     (vl-append
      10
      (metafunction->pict resolve)
      (vl-append
       (text "...." 'roman (default-font-size))
       (parameterize ([metafunction-cases '(0)]
                      [linebreaks '(#f)])
         (resolve*-partial-pict))
       (parameterize ([metafunction-cases '(1 2)]
                      [linebreaks '(#f #f)])
         (resolve*-partial-pict)))))))

(define (new-defs-eval->pict)
  (with-rewrites
   (lambda ()
     (parameterize ([metafunction-cases '(5)]
                    [linebreaks '(#f)])
       (metafunction->pict eval)))))

(define (def-var-eval->pict)
  (with-rewrites
   (lambda ()
     (parameterize ([metafunction-cases '(6)]
                    [linebreaks '(#f)])
       (metafunction->pict eval)))))

(define (def-exp-eval->pict)
  (with-rewrites
   (lambda ()
     (parameterize ([metafunction-cases '(7)]
                    [linebreaks '(#f)])
       (metafunction->pict eval)))))

(define (local-eval->pict)
  (with-rewrites
   (lambda ()
     (parameterize ([metafunction-cases '(4)]
                    [linebreaks '(#f)])
       (metafunction->pict eval)))))

(define (example-ids->pict)
  (with-rewrites
   (lambda ()
     (let-syntax ([ex (syntax-rules ()
                        [(_ e) (lw->pict mini (to-lw e))])])
       (vl-append
        10
        (vl-append
         (ex (Stx x (Defs (Defs • σ_1) σ_1)))
         (ex (Stx x (Defs (Defs (Defs (Defs • σ_1) σ_2) σ_2) σ_1))))
        (ex (Plain Σ = (Set (Bind σ_1 (Set (Bind (Stx x (Defs • σ_1)) (Comma x1))
                                           (Bind (Stx x (Defs (Defs (Defs (Defs • σ_1) σ_2) σ_2) σ_1)) x3)))
                            (Bind σ_2 (Set (Bind (Defs (Defs (Defs • σ_1) σ_2) σ_2)) x2))))))))))

(provide lang->pict
         delta->pict
         parse->pict
         resolve->pict
         metas->pict
         eval->pict
         expand->pict
         
         tprim->pict
         ctx->pict
         bad-resolve->pict
         renames->pict
         resolve*->pict
         new-defs-eval->pict
         def-var-eval->pict
         def-exp-eval->pict
         local-eval->pict
         example-ids->pict)
