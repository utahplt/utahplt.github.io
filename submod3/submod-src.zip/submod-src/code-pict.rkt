#lang racket/base
(require (rename-in slideshow/code-pict [code orig-code])
         "color.rkt")

(provide (all-from-out slideshow/code-pict)
         code)

(define-syntax-rule (code e ...)
  (parameterize ([code-colorize-enabled in-color?])
    (orig-code e ...)))
