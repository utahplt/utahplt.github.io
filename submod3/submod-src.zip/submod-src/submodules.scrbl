#lang scribble/sigplan
@(require "utils.rkt"
          (only-in (submod "model.rkt" test)))

@title{Submodules in Racket @subtitle{You Want it @emph{When}, Again?}}
@authorinfo["Matthew Flatt" "PLT and University of Utah" "mflatt@cs.utah.edu"]
@exclusive-license[]
@conferenceinfo[@elem{GPCE@hspace[1]'13}
                @elem{October 27--28, 2013, Indianapolis, Indiana, USA}]
@copyrightyear{2013}
@copyrightdata{978-1-4503-2373-4/13/10}
@doi{2517208.2517211} 

@abstract{

 In an extensible programming language, programmers write code that
 must run at different times---in particular, at compile time versus
 run time. The module system of the Racket programming language enables
 a programmer to reason about programs in the face of such
 extensibility, because the distinction between run-time and
 compile-time phases is built into the language
 model. @defterm{Submodules} extend
 Racket's module system to make the phase-separation facet of the
 language extensible. That is, submodules give programmers the
 capability to define new phases, such as ``test time'' or
 ``documentation time,'' with the same reasoning and code-management
 benefits as the built-in distinction between run time and compile
 time.

}

@category["D.3.3" "Programming Languages" "Language Constructs and Features"]
@keywords{Macros, modules, language tower}

@include-section["intro.scrbl"]
@include-section["macromod.scrbl"]
@include-section["testing.scrbl"]
@include-section["api.scrbl"]
@include-section["model.scrbl"]
@include-section["discuss.scrbl"]
@include-section["related.scrbl"]
@include-section["end.scrbl"]

@section[#:style '(hidden)]{}

@bold{Acknowledgements}@hspace[1] I would like to thank Matthias
Felleisen, Robby Findler, Ryan Culpepper, the Racket community, and anonymous
reviewers for feedback and suggestions on the design of submodules
and this presentation.

@generate-bibliography[]

@generate-footnotes[]
