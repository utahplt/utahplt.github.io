#lang racket
(require slideshow/pict
         slideshow/code-pict
         racket/draw
         "color.rkt")

(provide paper-scale
         runtime-color runtime-style
         runtime-only-color
         comptime-color comptime-style
         tmpltime-color tmpltime-style
         load-color load-style
         use-color
         new-color new-style
         hilite
         encloud
         adj
         style-width)

(define paper-scale 0.75)

(current-keyword-list (list* "define-objc-class"
                             "define-runtime-module-path-index"
                             "class"
                             "new"
                             "define-cstruct"
                             "use" "eval-when"
                             "groceries"
                             "defstx" "define-now-alias" 
                             "define-recently-alias" "define-about-then-alias"
                             (current-keyword-list)))

(current-code-font 'modern)

(define runtime-color (if in-color? "deepskyblue" "black")) ; was "dodgerblue"
(define runtime-only-color "deepskyblue")
(define comptime-color (if in-color? "mediumpurple" "black"))
(define tmpltime-color (if in-color? "lime" "black"))
(define load-color (if in-color? "forestgreen" "black"))
(define use-color "line")
(define new-color (if in-color? "orange" "black"))

(define runtime-style 'solid) ; (if in-color? 'solid 'dot))
(define comptime-style (if in-color? 'solid 'short-dash))
(define tmpltime-style (if in-color? 'solid 'dot))
(define load-style (if in-color? 'solid 'dot-dash))
(define new-style (if in-color? 'solid 'dot-dash))

(define (style-width style lw)
  (if in-color?
      1
      (* lw
         (case style
           [(dot solid) 0.5]
           [else 1]))))

(define (hilite p 
                #:color [color use-color]
                #:style [style 'rectangle])
  (refocus (cc-superimpose
            (colorize ((if (eq? style 'ellipse)
                           filled-ellipse
                           filled-rectangle)
                       (pict-width p)
                       (pict-height p)) 
                      color)
            p)
           p))

(define (encloud #:color [color runtime-color]
                 #:style [style runtime-style]
                 #:dh [dh 0]
                 p)
  (refocus (cc-superimpose (let ([p (inset p 1 0)])
                             (let ([w (pict-width p)]
                                   [h (+ dh (pict-height p))]
                                   [r 5])
                               (if in-color?
                                   (colorize
                                    (filled-rounded-rectangle w h r)
                                    color)
                                   (linestyle
                                    style
                                    (linewidth
                                     (style-width style 1)
                                     (rounded-rectangle w h r))))))
                           p)
           p))

(define (adj find dx dy)
  (lambda (a b)
    (define-values (x y) (find a b))
    (values (+ x dx) (+ y dy))))
