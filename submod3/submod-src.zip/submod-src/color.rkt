#lang racket/base

(provide in-color?)

(define in-color? #t)
