#lang scribble/sigplan
@(require "utils.rkt")

@title{Conclusion}

Lexical scope is a powerful organizing principle. In the context of
Racket, we believe that lexically scoped macros are the key to our
ability to define a rich ecosystem of language variants and tools,
from teaching dialects of Racket, to statically typed dialects of
Racket, to documentation languages. Phasing is a natural extension of
lexical scope that adds a new dimension to each identifier, allowing
the identifier to have different meanings in different phases while
relying on the surrounding context of an identifier to also determine
the phase in which the identifier is used. Submodules continue that
extension; they add new expressive power to Racket in line with the
principles of lexical scope, they solve a variety of practical
problems for Racket programmers, and they increase the ability of
macros to implement new language constructs.
