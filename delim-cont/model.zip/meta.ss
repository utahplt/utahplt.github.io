(module meta mzscheme
  (require (planet "reduction-semantics.ss" ("robby" "redex.plt" 3))
           "grammar.ss")
  
  ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
  ;; Substitution:

  (define-metafunction subst
    grammar
    [(x_1 x_1 e_1) ; shortcut
     e_1]
    [(x_1 e_1 (λ (x_2 ... x_1 x_3 ...) e_2))
     (λ (x_2 ... x_1 x_3 ...) e_2)]
    [(x_1 x_2 (λ (x_3 ...) e_1)) ; shortcut; x_1 != any x_3
     (λ (x_3 ...) (subst (x_1 x_2 e_1)))]
    [(x_1 e_1 (λ (x_2 ...) e_2)) ; x_1 != any x_2
     ,(term-let ([(x_new ...) (variables-not-in (term e_1) (term (x_2 ...)))])
        (term (λ (x_new ...) 
                (subst (x_1 e_1 (subst* ((x_2 ...) (x_new ...) e_2)))))))]
    [(x_1 e_1 x_1) e_1]
    [(x_1 e x_2) x_2] ; x_1 != x_2, since previous didn't match
    [(x_1 e_1 v_1) v_1] ; all other values are atomic
    [(x_1 e_1 (list v_1 ...)) (list (subst (x_1 e_1 v_1)) ...)]
    [(x_1 e_1 (e_2 ...))
     ((subst (x_1 e_1 e_2)) ...)]
    [(x_1 e_1 (if e_2 e_3 e_4))
     (if (subst (x_1 e_1 e_2)) 
         (subst (x_1 e_1 e_3))
         (subst (x_1 e_1 e_4)))]
    [(x_1 e_1 (begin e_2 e_3))
     (begin (subst (x_1 e_1 e_2)) 
            (subst (x_1 e_1 e_3)))]
    [(x_1 e_1 (set! x_2 e_2))
     (set! x_2 (subst (x_1 e_1 e_2)))]
    [(x_1 e_1 (% e_2 e_3 e_4))
     (% (subst (x_1 e_1 e_2)) 
        (subst (x_1 e_1 e_3)) 
        (subst (x_1 e_1 e_4)))]    
    [(x_1 e_1 (wcm ((v_1 v_2) ...) e_2))
     (wcm (((subst (x_1 e_1 v_1))
            (subst (x_1 e_1 v_2))) ...)
          (subst (x_1 e_1 e_2)))]
    [(x_1 e_1 (dw x_2 e_2 e_3 e_4))
     (dw x_2
         (subst (x_1 e_1 e_2)) 
         (subst (x_1 e_1 e_3)) 
         (subst (x_1 e_1 e_4)))])

  (define-metafunction subst*
    grammar
    [(() () e_1) e_1]
    [((x_1 x_2 ...) (e_1 e_2 ...) e_3)
     (subst* ((x_2 ...) (e_2 ...) (subst (x_1 e_1 e_3))))])
  
  ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
  ;; Other meta-functions:
  
  (define-metafunction noPrompt
    grammar
    [(v_1 (% v_1 E v)) #f]
    [(v_1 (% v_2 E_1 v)) (noPrompt (v_1 E_1))]
    [(v hole) #t]
    [(v_1 (v ... E_1 e ...)) (noPrompt (v_1 E_1))]
    [(v_1 (if E_1 e e)) (noPrompt (v_1 E_1))]
    [(v_1 (begin E_1 e)) (noPrompt (v_1 E_1))]
    [(v_1 (set! x E_1)) (noPrompt (v_1 E_1))]
    [(v_1 (wcm w E_1)) (noPrompt (v_1 E_1))]
    [(v_1 (dw x e E_1 e)) (noPrompt (v_1 E_1))])

  (define-metafunction get-marks-core
    grammar
    [((in-hole hole hole) v e_2) e_2]
    [((wcm (name w_1 ((v v) ... (v_1 v_3) (v v) ...)) E_1) v_1 e_2) (get-marks (E_1 v_1 (cons v_3 e_2)))]
    [((wcm w_1 E_1) v_1 e_2) (get-marks (E_1 v_1 e_2)) (side-condition (term (notInDom (v_1 w_1))))]
    [((v ... E_1 e ...) v_1 e_2) (get-marks (E_1 v_1 e_2))]
    [((begin E_1 e) v_1 e_2) (get-marks (E_1 v_1 e_2))]
    [((% v E_1 v) v_1 e_2) (get-marks (E_1 v_1 e_2))]
    [((dw x e E_1 e) v_1 e_2) (get-marks (E_1 v_1 e_2))])
  
  (define-metafunction get-marks
    grammar
    [((if E_1 e e) v_1 e_2) (get-marks (E_1 v_1 e_2))]
    [((set! x E_1) v_1 e_2) (get-marks (E_1 v_1 e_2))]
    [(E_1 v_1 e_2) (get-marks-core (E_1 v_1 e_2))])

  (define-metafunction expose-wcm
    grammar
    [(e_1) e_1 (side-condition (term (noMatchWCM (e_1 (wcm w e)))))]
    [((wcm () e_1)) e_1]
    [((wcm ((v_1 v_2) (v_3 v_4) ...) e_1))
     (call/cm v_1 v_2 (λ () (expose-wcm ((wcm ((v_3 v_4) ...) e_1)))))])

  (define-metafunction sameDWs
    grammar
    [(W_1 W_2) (True ())]
    [((in-hole W_1 (dw x_1 e_1 E_1 e_2)) 
      (in-hole W_2 (dw x_1 e_1 E_2 e_2)))
     (sameDWs (E_1 E_2))]
    [any (False ())])

  (define-metafunction noShared
    grammar
    [((in-hole W_1 (dw x_1 e_1 E_1 e_2))
      (in-hole W_2 (dw x_1 e_1 E_2 e_2)))
     (False ())]
    [any (True ())])

  (define-metafunction nonWCM
    grammar
    [(in-hole E (wcm w hole)) #f]
    [any #t])

  ;; The rest are helpers that are typeset specially in the paper
  
  (define-metafunction noMatch
    grammar
    [(E_1 any (% v_1 any any)) (noPrompt (v_1 E_1))]
    [(E_1 any (wcm any any)) (nonWCM E_1)])

  (define-metafunction noMatchWCM
    grammar
    [((wcm w e_1) any) #f]
    [any #t])
  
  (define-metafunction notIn
    grammar
    [(v_1 (v_2 ...)) ,(not (member (term v_1) (term (v_2 ...))))])

  (define-metafunction notInDom
    grammar
    [(v_1 ((v_2  v_3) ...)) (notIn (v_1 (v_2 ...)))])
  
  (define-metafunction True grammar [() #t])
  (define-metafunction False grammar [() #f])

  ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
  
  (provide subst subst*
           noPrompt
           get-marks get-marks-core
           expose-wcm
           sameDWs
           noShared
           nonWCM
           noMatch
           noMatchWCM
           notIn
           notInDom))
