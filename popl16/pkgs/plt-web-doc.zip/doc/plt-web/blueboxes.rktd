1062
((3) 0 () 1 ((q lib "plt-web/main.rkt")) () (h ! (equal) ((c def c (c (? . 0) q site?)) q (1036 . 3)) ((c def c (c (? . 0) q web-path)) q (5029 . 3)) ((c def c (c (? . 0) q page*)) q (1484 . 31)) ((c def c (c (? . 0) q site-favicon-path)) q (1208 . 3)) ((c def c (c (? . 0) q index-site?)) q (4369 . 3)) ((c def c (c (? . 0) q site-navbar-dynamic-js)) q (1336 . 3)) ((c def c (c (? . 0) q basename)) q (4969 . 3)) ((c def c (c (? . 0) q make-indexes)) q (3945 . 10)) ((c def c (c (? . 0) q call-with-registered-roots)) q (4890 . 3)) ((c def c (c (? . 0) q copyfile)) q (3656 . 5)) ((c def c (c (? . 0) q site-navbar)) q (1275 . 3)) ((c def c (c (? . 0) q site)) q (0 . 23)) ((c def c (c (? . 0) q plain*)) q (2974 . 17)) ((c def c (c (? . 0) q index-page)) q (4491 . 9)) ((c form c (c (? . 0) q page)) q (1408 . 4)) ((c def c (c (? . 0) q symlink)) q (3801 . 5)) ((c form c (c (? . 0) q plain)) q (2897 . 4)) ((c def c (c (? . 0) q site-css-path)) q (1145 . 3)) ((c def c (c (? . 0) q site-dir)) q (1087 . 3)) ((c def c (c (? . 0) q index-site)) q (4426 . 3))))
procedure
(site  dir                                   
      [#:url url                             
       #:always-abs-url? always-abs-url?     
       #:generate? generate?                 
       #:share-from share-from               
       #:page-style? page-style?             
       #:page-headers page-headers           
       #:meta? meta?                         
       #:robots robots                       
       #:htaccess htaccess                   
       #:navigation navigation])         -> site?
  dir : path-string?
  url : (or/c string? #f) = #f
  always-abs-url? : any/c = #t
  generate? : any/c = #t
  share-from : (or/c site? #f) = #f
  page-style? : any/c = #t
  page-headers : outputable/c = null
  meta? : any/c = page-style?
  robots : (or/c #f #t outputable/c) = #t
  htaccess : (or/c #f #t outputable/c) = #t
  navigation : (listof outputable/c) = null
procedure
(site? v) -> boolean?
  v : any/c
procedure
(site-dir s) -> path-string?
  s : site?
procedure
(site-css-path s) -> outputable/c
  s : site?
procedure
(site-favicon-path s) -> outputable/c
  s : site?
procedure
(site-navbar s) -> outputable/c
  s : site?
procedure
(site-navbar-dynamic-js s) -> outputable/c
  s : site?
syntax
(page keyword-arg ... form ...)
 
keyword-arg = keyword expr
procedure
(page*  #:site s                          
       [#:html-only html-only?            
        #:id id                           
        #:file file                       
        #:title title                     
        #:link-title link-title           
        #:window-title window-title       
        #:width width                     
        #:description description         
        #:extra-headers extra-headers     
        #:extra-body-attrs body-attrs     
        #:referrer referrer               
        #:part-of part-of]                
        content)                      -> outputable/c
  s : site?
  html-only? : any/c = #f
  id : path-string? = #f
  file : (or/c path-string? #f) = #f
  title : string? = (... id)
  link-title : outputable/c = title
  window-title : string? = (string-append "Racket: " label)
  width : (or/c #f 'full outputable/c) = #f
  description : string? = #f
  extra-headers : outputable/c = #f
  body-attrs : outputable/c = #f
  referrer : (string? outputable/c ... . -> . outputable/c)
           = (λ (url . content)
               (a href: url (if (null? content) linktitle content)))
  part-of : (or/c #f symbol?) = #f
  content : outputable/c
syntax
(plain keyword-arg ... form ...)
 
keyword-arg = keyword expr
procedure
(plain*  #:site s                
        [#:id id                 
         #:suffix suffix         
         #:file file             
         #:referrer referrer     
         #:newline newline?]     
         content)            -> outputable/c
  s : site?
  id : path-string? = #f
  suffix : (or/c #f string?) = #f
  file : (or/c path-string? #f) = #f
  referrer : (string? outputable/c ... . -> . outputable/c)
           = (λ (url . content)
               (a href: url (if (null? content) linktitle content)))
  newline? : any/c = #t
  content : outputable/c
procedure
(copyfile #:site s src [dest]) -> outputable/c
  s : site?
  src : path-string?
  dest : string? = (basename src)
procedure
(symlink #:site s src [dest]) -> outputable/c
  s : site?
  src : path-string?
  dest : string? = (basename src)
procedure
(make-indexes  s                         
               dir                       
              [#:depth depth             
               #:use-dir? use-dir?]) -> void?
  s : site?
  dir : (or/c 'same relative-path?)
  depth : (or/c #f exact-nonnegative-integer?) = #f
  use-dir? : ((or/c 'same relative-path?) . -> . any/c)
           = (lambda (dir) #t)
procedure
(index-site? v) -> boolean?
  v : any/c
procedure
(index-site site) -> index-site?
  site : site?
procedure
(index-page  isite                         
             path                          
             content                       
            [#:html-only? html-only?]) -> outputable/c
  isite : index-site?
  path : (or/c 'same relative-path?)
  content : (listof (cons/c path-string? (or/c exact-integer? 'dir)))
  html-only? : any/c = #f
procedure
(call-with-registered-roots thunk) -> any
  thunk : (-> any)
procedure
(basename p) -> string?
  p : path-string?
procedure
(web-path str ...) -> string?
  str : string?
