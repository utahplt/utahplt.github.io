590
((3) 0 () 1 ((q lib "racket/class/iop.rkt")) () (h ! (equal) ((c form c (c (? . 0) q init/i)) q (417 . 2)) ((c form c (c (? . 0) q init-field/i)) q (479 . 2)) ((c form c (c (? . 0) q send/apply/i)) q (286 . 2)) ((c form c (c (? . 0) q define-interface/dynamic)) q (74 . 2)) ((c form c (c (? . 0) q define-interface)) q (0 . 2)) ((c form c (c (? . 0) q send/i)) q (145 . 2)) ((c form c (c (? . 0) q init-private/i)) q (547 . 5)) ((c form c (c (? . 0) q define-interface-expander)) q (683 . 2)) ((c form c (c (? . 0) q send*/i)) q (211 . 2)) ((c form c (c (? . 0) q define/i)) q (374 . 2))))
syntax
(define-interface name-id (super-ifc-id ...) (method-id ...))
syntax
(define-interface/dynamic name-id ifc-expr (method-id ...))
syntax
(send/i obj-exp static-ifc-id method-id arg-expr ...)
syntax
(send*/i obj-expr static-ifc-id (method-id arg-expr ...) ...)
syntax
(send/apply/i obj-expr static-ifc-id method-id arg-expr ... list-arg-expr)
syntax
(define/i id static-ifc-id expr)
syntax
(init/i (id static-ifc-id maybe-default-expr) ...)
syntax
(init-field/i (id static-ifc-id maybe-default-expr) ...)
syntax
(init-private/i (id static-ifc-id maybe-default-expr) ...)
 
maybe-default-expr = ()
                   | default-expr
syntax
(define-interface-expander id transformer-expr)
