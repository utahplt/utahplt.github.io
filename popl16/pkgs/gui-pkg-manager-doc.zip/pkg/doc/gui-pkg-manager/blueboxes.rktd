244
((3) 0 () 1 ((q lib "pkg/gui.rkt")) () (h ! (equal) ((c def c (c (? . 0) q make-pkg-gui)) q (0 . 7)) ((c def c (c (? . 0) q make-pkg-installer)) q (347 . 9)) ((c def c (c (? . 0) q pkg-catalog-update-local/simple-status-dialog)) q (857 . 4))))
procedure
(make-pkg-gui [#:wrap-terminal-action wrap-terminal-action 
               #:initial-tab initial-tab])                 
 -> (is-a?/c top-level-window<%>)
  wrap-terminal-action : (-> (-> any) any) = (λ (t) (t))
  initial-tab : (or/c 'by-source 'installed 'from-list 'migrate)
              = 'by-source
procedure
(make-pkg-installer                                              
                    [#:parent parent                             
                     #:wrap-terminal-action wrap-terminal-action 
                     #:package-to-offer package-to-offer])       
 -> (is-a?/c top-level-window<%>)
  parent : (or/c #f (is-a?/c top-level-window<%>)) = #f
  wrap-terminal-action : (-> (-> any) any) = (λ (t) (t))
  package-to-offer : (or/c #f string?) = #f
procedure
(pkg-catalog-update-local/simple-status-dialog [#:parent parent])
 -> void?
  parent : (or/c (is-a?/c frame%) (is-a?/c dialog%) #f) = #f
