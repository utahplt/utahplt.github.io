1679
((3) 0 () 4 ((q lib "ppict/pict.rkt") (q lib "ppict/align.rkt") (q lib "ppict/tag.rkt") (q lib "ppict/slideshow.rkt")) () (h ! (equal) ((c form c (c (? . 0) q ppict-do-state)) q (477 . 2)) ((c def c (c (? . 0) q at-find-pict)) q (2366 . 13)) ((c def c (c (? . 2) q find-tag*)) q (3526 . 4)) ((c def c (c (? . 0) q placer?)) q (866 . 3)) ((c form c (c (? . 0) q ppict-do*)) q (53 . 14)) ((c def c (c (? . 1) q halign/c)) q (3705 . 2)) ((c def c (c (? . 1) q align/c)) q (3677 . 2)) ((c def c (c (? . 0) q ppict-go)) q (551 . 4)) ((c def c (c (? . 2) q find-tag)) q (3429 . 4)) ((c def c (c (? . 1) q align->frac)) q (3875 . 3)) ((c def c (c (? . 3) q pslide-base-pict)) q (3115 . 4)) ((c def c (c (? . 0) q coord)) q (981 . 13)) ((c def c (c (? . 0) q grid)) q (1464 . 17)) ((c def c (c (? . 0) q refpoint-placer?)) q (919 . 3)) ((c def c (c (? . 1) q align->v)) q (3819 . 3)) ((c def c (c (? . 1) q pin-over/align)) q (4088 . 8)) ((c def c (c (? . 0) q ppict?)) q (499 . 3)) ((c def c (c (? . 2) q tag-path?)) q (3622 . 3)) ((c def c (c (? . 1) q valign->hcompose)) q (4019 . 3)) ((c form c (c (? . 3) q pslide)) q (3075 . 2)) ((c def c (c (? . 0) q ppict-add)) q (626 . 4)) ((c def c (c (? . 0) q merge-refpoints)) q (2937 . 4)) ((c form c (c (? . 0) q ppict-do)) q (0 . 2)) ((c def c (c (? . 1) q valign/c)) q (3734 . 2)) ((c def c (c (? . 3) q pslide-default-placer)) q (3240 . 4)) ((c def c (c (? . 1) q halign->vcompose)) q (3950 . 3)) ((c def c (c (? . 0) q cascade)) q (2107 . 4)) ((c def c (c (? . 2) q tag-pict)) q (3353 . 4)) ((c def c (c (? . 0) q ppict-add*)) q (737 . 4)) ((c def c (c (? . 1) q align->h)) q (3763 . 3)) ((c def c (c (? . 0) q tile)) q (2250 . 4))))
syntax
(ppict-do base-expr ppict-do-fragment ...)
syntax
(ppict-do* base-expr ppic-do-fragment ...)
 
ppict-do-fragment = #:go placer-expr
                  | #:set pict-expr
                  | #:next
                  | #:alt (ppict-do-fragment ...)
                  | #:do [def-or-expr ...]
                  | elem-expr
 
  base-expr : pict?
  placer-expr : placer?
  pict-expr : pict?
  elem-expr : (or/c pict? real? #f)
syntax
ppict-do-state
procedure
(ppict? x) -> boolean?
  x : any/c
procedure
(ppict-go p pl) -> ppict?
  p : pict?
  pl : placer?
procedure
(ppict-add pp elem ...) -> pict?
  pp : ppict?
  elem : (or/c pict? real? #f 'next)
procedure
(ppict-add* pp elem ...) -> pict? (listof pict?)
  pp : ppict?
  elem : (or/c pict? real? #f 'next)
procedure
(placer? x) -> boolean?
  x : any/c
procedure
(refpoint-placer? x) -> boolean?
  x : any/c
procedure
(coord  rel-x                    
        rel-y                    
       [align                    
        #:abs-x abs-x            
        #:abs-y abs-y            
        #:compose composer]) -> refpoint-placer?
  rel-x : real?
  rel-y : real?
  align : (or/c 'lt 'ct 'rt 'lc 'cc 'rc 'lb 'cb 'rb) = 'cc
  abs-x : real? = 0
  abs-y : real? = 0
  composer : procedure? = computed from align
procedure
(grid  cols                     
       rows                     
       col                      
       row                      
      [align                    
       #:abs-x abs-x            
       #:abs-y abs-y            
       #:compose composer]) -> refpoint-placer?
  cols : exact-positive-integer?
  rows : exact-positive-integer?
  col : exact-integer?
  row : exact-integer?
  align : (or/c 'lt 'ct 'rt 'lc 'cc 'rc 'lb 'cb 'rb) = 'cc
  abs-x : real? = 0
  abs-y : real? = 0
  composer : procedure? = computed from align
procedure
(cascade [step-x step-y]) -> placer?
  step-x : (or/c real? 'auto) = 'auto
  step-y : (or/c real? 'auto) = 'auto
procedure
(tile cols rows) -> placer?
  cols : exact-positive-integer?
  rows : exact-positive-integer?
procedure
(at-find-pict  find-path                
              [finder                   
               align                    
               #:abs-x abs-x            
               #:abs-y abs-y            
               #:compose composer]) -> refpoint-placer?
  find-path : (or/c tag-path? pict-path?)
  finder : procedure? = cc-find
  align : (or/c 'lt 'ct 'rt 'lc 'cc 'rc 'lb 'cb 'rb) = 'cc
  abs-x : real? = 0
  abs-y : real? = 0
  composer : procedure? = computed from align
procedure
(merge-refpoints x-placer y-placer) -> refpoint-placer?
  x-placer : refpoint-placer?
  y-placer : refpoint-placer?
syntax
(pslide ppict-do-fragment ...)
parameter
(pslide-base-pict) -> (-> pict)
(pslide-base-pict make-base-pict) -> void?
  make-base-pict : (-> pict)
parameter
(pslide-default-placer) -> placer?
(pslide-default-placer placer) -> void?
  placer : placer?
procedure
(tag-pict p tag) -> pict?
  p : pict?
  tag : symbol?
procedure
(find-tag p find) -> (or/c pict-path? #f)
  p : pict?
  find : tag-path?
procedure
(find-tag* p find) -> (listof pict-path?)
  p : pict?
  find : tag-path?
procedure
(tag-path? x) -> boolean?
  x : any/c
value
align/c : contract?
value
halign/c : contract?
value
valign/c : contract?
procedure
(align->h a) -> halign/c
  a : align/c
procedure
(align->v a) -> valign/c
  a : align/c
procedure
(align->frac a) -> real?
  a : (or/c halign/c valign/c)
procedure
(halign->vcompose ha) -> procedure?
  ha : halign/c
procedure
(valign->hcompose va) -> procedure?
  va : valign/c
procedure
(pin-over/align scene x y halign valign pict) -> pict?
  scene : pict?
  x : real?
  y : real?
  halign : halign/c
  valign : valign/c
  pict : pict?
