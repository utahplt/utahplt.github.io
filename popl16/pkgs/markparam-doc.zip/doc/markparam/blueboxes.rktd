462
((3) 0 () 2 ((q lib "markparam/main.rkt") (q 0 . 2)) () (h ! (equal) ((c def c (c (? . 0) q mark-parameter?)) c (? . 1)) ((c def c (c (? . 0) q mark-parameter)) c (? . 1)) ((c def c (c (? . 0) q mark-parameters-all)) q (358 . 6)) ((c def c (c (? . 0) q mark-parameter-first)) q (34 . 5)) ((c def c (c (? . 0) q mark-parameter-all)) q (197 . 5)) ((c def c (c (? . 0) q struct:mark-parameter)) c (? . 1)) ((c form c (c (? . 0) q mark-parameterize)) q (579 . 2))))
struct
(struct mark-parameter ())
procedure
(mark-parameter-first mp [tag]) -> any/c
  mp : mark-parameter?
  tag : continuation-prompt-tag?
      = default-continuation-prompt-tag
procedure
(mark-parameter-all mp [tag]) -> list?
  mp : mark-parameter?
  tag : continuation-prompt-tag?
      = default-continuation-prompt-tag
procedure
(mark-parameters-all mps none-v [tag]) -> (listof vector?)
  mps : (listof mark-parameter?)
  none-v : [any/c #f]
  tag : continuation-prompt-tag?
      = default-continuation-prompt-tag
syntax
(mark-parameterize ([mp expr] ...) body-expr ...)
