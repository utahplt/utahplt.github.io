#lang info

(define collection 'multi)
(define deps '("typed-racket" "typed-racket-more" "unstable"))
(define build-deps '("base"
                     "compatibility-lib"
                     "rackunit-lib"
                     "compiler-lib"
                     "redex-lib"
                     "sandbox-lib"
                     "unstable-flonum-lib"
                     "unstable"))
