1763
((3) 0 () 2 ((q lib "unstable/gui/pict.rkt") (q lib "unstable/gui/slideshow.rkt")) () (h ! (equal) ((c def c (c (? . 0) q shade)) q (491 . 5)) ((c def c (c (? . 0) q cross-out)) q (9029 . 12)) ((c def c (c (? . 1) q columns)) q (10427 . 3)) ((c def c (c (? . 0) q draw-pict-centered)) q (8789 . 6)) ((c def c (c (? . 1) q tabular)) q (9608 . 17)) ((c form c (c (? . 0) q pict-match)) q (709 . 5)) ((c form c (c (? . 1) q items-slide)) q (10697 . 2)) ((c def c (c (? . 0) q pin-arrow-label-line)) q (4351 . 42)) ((c form c (c (? . 1) q reveal)) q (10626 . 2)) ((c def c (c (? . 0) q color)) q (0 . 4)) ((c form c (c (? . 1) q column)) q (10488 . 2)) ((c form c (c (? . 1) q revealing-slide)) q (10661 . 2)) ((c form c (c (? . 0) q pict-combine)) q (639 . 2)) ((c def c (c (? . 0) q rectangle/border)) q (1664 . 11)) ((q def ((lib "unstable/gui/scribble.rkt") codeblock->pict)) q (10742 . 3)) ((c def c (c (? . 0) q backdrop)) q (8920 . 4)) ((c def c (c (? . 0) q pin-label-line)) q (2775 . 35)) ((c form c (c (? . 1) q two-columns)) q (10332 . 2)) ((c def c (c (? . 0) q blur-bitmap!)) q (8337 . 5)) ((c def c (c (? . 0) q pin-arrows-label-line)) q (6334 . 42)) ((c def c (c (? . 0) q circle/border)) q (1291 . 9)) ((c def c (c (? . 0) q ellipse/border)) q (847 . 11)) ((c def c (c (? . 0) q rounded-rectangle/border)) q (2118 . 16)) ((c def c (c (? . 0) q fill)) q (69 . 5)) ((q def ((lib "unstable/gui/pict/plt-logo.rkt") make-plt-title-background)) q (9521 . 4)) ((c def c (c (? . 0) q strike)) q (394 . 4)) ((c def c (c (? . 0) q scale-to)) q (202 . 6)) ((c def c (c (? . 0) q arch)) q (8554 . 9)) ((c def c (c (? . 1) q mini-slide)) q (10363 . 3)) ((c form c (c (? . 0) q with-pict-combine)) q (659 . 2)) ((c def c (c (? . 1) q column-size)) q (10522 . 4))))
procedure
(color c p) -> pict?
  c : color/c
  p : pict?
procedure
(fill pict width height) -> pict?
  pict : pict?
  width : (or/c real? #f)
  height : (or/c real? #f)
procedure
(scale-to pict width height [#:mode mode]) -> pict?
  pict : pict?
  width : real?
  height : real?
  mode : (or/c 'preserve 'inset 'distort) = 'preserve
procedure
(strike pict [strike?]) -> pict?
  pict : pict?
  strike? : truth/c = #t
procedure
(shade pict [shade? #:ratio ratio]) -> pict?
  pict : pict?
  shade? : truth/c = #t
  ratio : (real-in 0 1) = 1/2
syntax
pict-combine
syntax
(with-pict-combine combine-id body ...)
syntax
(pict-match test-expr maybe-combine [pattern pict-expr] ...)
 
maybe-combine = 
              | #:combine combine-expr
procedure
(ellipse/border  w                                 
                 h                                 
                [#:color color                     
                 #:border-color border-color       
                 #:border-width border-width]) -> pict?
  w : real?
  h : real?
  color : color/c = "white"
  border-color : color/c = "black"
  border-width : real? = 2
procedure
(circle/border  diameter                          
               [#:color color                     
                #:border-color border-color       
                #:border-width border-width]) -> pict?
  diameter : real?
  color : color/c = "white"
  border-color : color/c = "black"
  border-width : real? = 2
procedure
(rectangle/border  w                                 
                   h                                 
                  [#:color color                     
                   #:border-color border-color       
                   #:border-width border-width]) -> pict?
  w : real?
  h : real?
  color : color/c = "white"
  border-color : color/c = "black"
  border-width : real? = 2
procedure
(rounded-rectangle/border  w                             
                           h                             
                          [#:color color                 
                           #:border-color border-color   
                           #:border-width border-width   
                           #:corner-radius corner-radius 
                           #:angle angle])               
 -> pict?
  w : real?
  h : real?
  color : color/c = "white"
  border-color : color/c = "black"
  border-width : real? = 2
  corner-radius : real? = -0.25
  angle : real? = 0
procedure
(pin-label-line  label                         
                 pict                          
                 src-pict                      
                 src-coord-fn                  
                 dest-pict                     
                 dest-coord-fn                 
                [#:start-angle start-angle     
                 #:end-angle end-angle         
                 #:start-pull start-pull       
                 #:end-pull end-pull           
                 #:line-width line-width       
                 #:color color                 
                 #:alpha alpha                 
                 #:style style                 
                 #:under? under?               
                 #:x-adjust x-adjust           
                 #:y-adjust y-adjust])     -> pict?
  label : pict?
  pict : pict?
  src-pict : pict-path?
  src-coord-fn : (-> pict-path? (values real? real?))
  dest-pict : pict-path?
  dest-coord-fn : (-> pict-path? (values real? real?))
  start-angle : (or/c real? #f) = #f
  end-angle : (or/c real? #f) = #f
  start-pull : real? = 1/4
  end-pull : real? = 1/4
  line-width : (or/c real? #f) = #f
  color : (or/c #f string? (is-a?/c color%)) = #f
  alpha : (real-in 0 1) = 1
  style : pen-style/c = 'solid
  under? : any/c = #f
  x-adjust : real? = 0
  y-adjust : real? = 0
procedure
(pin-arrow-label-line  label                             
                       arrow-size                        
                       pict                              
                       src-pict                          
                       src-coord-fn                      
                       dest-pict                         
                       dest-coord-fn                     
                      [#:start-angle start-angle         
                       #:end-angle end-angle             
                       #:start-pull start-pull           
                       #:end-pull end-pull               
                       #:line-width line-width           
                       #:color color                     
                       #:alpha alpha                     
                       #:style style                     
                       #:solid? solid?                   
                       #:under? under?                   
                       #:hide-arrowhead? hide-arrowhead? 
                       #:x-adjust x-adjust               
                       #:y-adjust y-adjust])             
 -> pict?
  label : pict?
  arrow-size : real?
  pict : pict?
  src-pict : pict-path?
  src-coord-fn : (-> pict-path? (values real? real?))
  dest-pict : pict-path?
  dest-coord-fn : (-> pict-path? (values real? real?))
  start-angle : (or/c real? #f) = #f
  end-angle : (or/c real? #f) = #f
  start-pull : real? = 1/4
  end-pull : real? = 1/4
  line-width : (or/c real? #f) = #f
  color : (or/c #f string? (is-a?/c color%)) = #f
  alpha : (real-in 0 1) = 1
  style : pen-style/c = 'solid
  solid? : boolean? = #t
  under? : any/c = #f
  hide-arrowhead? : any/c = #f
  x-adjust : real? = 0
  y-adjust : real? = 0
procedure
(pin-arrows-label-line  label                             
                        arrow-size                        
                        pict                              
                        src-pict                          
                        src-coord-fn                      
                        dest-pict                         
                        dest-coord-fn                     
                       [#:start-angle start-angle         
                        #:end-angle end-angle             
                        #:start-pull start-pull           
                        #:end-pull end-pull               
                        #:line-width line-width           
                        #:color color                     
                        #:alpha alpha                     
                        #:style style                     
                        #:solid? solid?                   
                        #:under? under?                   
                        #:hide-arrowhead? hide-arrowhead? 
                        #:x-adjust x-adjust               
                        #:y-adjust y-adjust])             
 -> pict?
  label : pict?
  arrow-size : real?
  pict : pict?
  src-pict : pict-path?
  src-coord-fn : (-> pict-path? (values real? real?))
  dest-pict : pict-path?
  dest-coord-fn : (-> pict-path? (values real? real?))
  start-angle : (or/c real? #f) = #f
  end-angle : (or/c real? #f) = #f
  start-pull : real? = 1/4
  end-pull : real? = 1/4
  line-width : (or/c real? #f) = #f
  color : (or/c #f string? (is-a?/c color%)) = #f
  alpha : (real-in 0 1) = 1
  style : pen-style/c = 'solid
  solid? : boolean? = #t
  under? : any/c = #f
  hide-arrowhead? : any/c = #f
  x-adjust : real? = 0
  y-adjust : real? = 0
procedure
(blur-bitmap! bitmap h-radius [v-radius]) -> void?
  bitmap : (is-a?/c bitmap%)
  h-radius : (and/c real? (not/c negative?))
  v-radius : (and/c real? (not/c negative?)) = h-radius
procedure
(arch outer-width      
      inner-width      
      solid-height     
      leg-height)  -> pict?
  outer-width : real?
  inner-width : real?
  solid-height : real?
  leg-height : real?
procedure
(draw-pict-centered p dc w h) -> void?
  p : pict?
  dc : (is-a?/c dc<%>)
  w : real?
  h : real?
procedure
(backdrop pict [#:color color]) -> pict?
  pict : pict?
  color : color/c = "white"
procedure
(cross-out  pict                
           [#:width width       
            #:style style       
            #:color color]) -> pict?
  pict : pict?
  width : real? = 1
  style : (or/c 'transparent 'solid 'xor            = 'solid
                'hilite 'dot 'long-dash 'short-dash
                'dot-dash 'xor-dot 'xor-long-dash
                'xor-short-dash 'xor-dot-dash)
  color : color/c = "black"
procedure
(make-plt-title-background w h) -> pict?
  w : real?
  h : real?
procedure
(tabular  row                   
          ...                   
         [#:gap gap             
          #:hgap hgap           
          #:vgap vgap           
          #:align align         
          #:halign halign       
          #:valign valign]) -> pict?
  row : (listof (or/c string? pict?))
  gap : natural-number/c = gap-size
  hgap : natural-number/c = gap
  vgap : natural-number/c = gap
  align : (->* [] [] #:rest (listof pict?) pict?)
        = lbl-superimpose
  halign : (->* [] [] #:rest (listof pict?) pict?) = align
  valign : (->* [] [] #:rest (listof pict?) pict?) = align
syntax
(two-columns one two)
procedure
(mini-slide pict ...) -> pict?
  pict : pict?
procedure
(columns pict ...) -> pict?
  pict : pict?
syntax
(column width body ...)
procedure
(column-size n [r]) -> real?
  n : exact-positive-integer?
  r : real? = (/ n)
syntax
(reveal number expr ...)
syntax
(revealing-slide expr ...)
syntax
(items-slide (name ...) expr ...)
procedure
(codeblock->pict block) -> pict?
  block : block?
