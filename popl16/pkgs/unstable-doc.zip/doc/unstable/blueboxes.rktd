4449
((3) 0 () 14 ((q lib "unstable/debug.rkt") (q lib "unstable/parameter-group.rkt") (q lib "unstable/error.rkt") (q lib "unstable/options.rkt") (q lib "unstable/match.rkt") (q lib "unstable/list.rkt") (q lib "unstable/syntax.rkt") (q lib "unstable/define.rkt") (q lib "unstable/pretty.rkt") (q lib "unstable/sequence.rkt") (q lib "unstable/logging.rkt") (q lib "unstable/contract.rkt") (q lib "unstable/bytes.rkt") (q lib "unstable/find.rkt")) () (h ! (equal) ((c form c (c (? . 1) q define-parameter-group)) q (8031 . 7)) ((c form c (c (? . 0) q letrec-values/debug)) q (1492 . 2)) ((c def c (c (? . 3) q option/c)) q (6520 . 15)) ((c form c (c (? . 0) q define/private/debug)) q (753 . 3)) ((c def c (c (? . 8) q pretty-format/print)) q (8900 . 5)) ((c form c (c (? . 0) q define/override/debug)) q (929 . 3)) ((c def c (c (? . 10) q stop-recording)) q (5862 . 7)) ((c def c (c (? . 5) q filter-multiple)) q (5243 . 4)) ((c form c (c (? . 0) q parameterize/debug)) q (1702 . 2)) ((c form c (c (? . 0) q define/debug)) q (680 . 3)) ((c form c (c (? . 1) q parameterize*/group)) q (8385 . 5)) ((c def c (c (? . 2) q exn:not-break?)) q (4092 . 3)) ((c def c (c (? . 2) q compose-error-message)) q (3225 . 13)) ((q form ((lib "unstable/struct.rkt") make)) q (9696 . 2)) ((c form c (c (? . 0) q let/debug)) q (1109 . 3)) ((c def c (c (? . 3) q invariant/c)) q (7513 . 11)) ((c form c (c (? . 4) q object)) q (6292 . 10)) ((c def c (c (? . 12) q write/bytes)) q (60 . 3)) ((c form c (c (? . 4) q match*?)) q (6241 . 2)) ((c def c (c (? . 0) q dprintf)) q (442 . 4)) ((c def c (c (? . 6) q explode-module-path-index)) q (9804 . 4)) ((c form c (c (? . 0) q with-syntax/debug)) q (1567 . 2)) ((q def ((lib "unstable/string.rkt") regexp-filter)) q (9467 . 5)) ((c def c (c (? . 3) q has-option-with-contract?)) q (7442 . 3)) ((c form c (c (? . 4) q as)) q (6192 . 2)) ((c def c (c (? . 5) q map2)) q (5603 . 4)) ((c def c (c (? . 11) q truth/c)) q (225 . 2)) ((c def c (c (? . 6) q format-unique-id)) q (9977 . 13)) ((c def c (c (? . 5) q map/values)) q (5426 . 5)) ((c form c (c (? . 0) q with-syntax*/debug)) q (1634 . 2)) ((c def c (c (? . 1) q parameter-group?)) q (7969 . 3)) ((c form c (c (? . 6) q phase-of-enclosing-module)) q (9942 . 2)) ((c def c (c (? . 6) q syntax-length)) q (10592 . 3)) ((c def c (c (? . 2) q error*)) q (1847 . 13)) ((c form c (c (? . 0) q debug)) q (339 . 5)) ((c form c (c (? . 1) q parameterize/group)) q (8225 . 5)) ((c form c (c (? . 0) q let*/debug)) q (1227 . 2)) ((q form ((lib "unstable/lazy-require.rkt") begin-on-demand)) q (5176 . 3)) ((c form c (c (? . 0) q let*-values/debug)) q (1419 . 2)) ((c def c (c (? . 6) q syntax-within?)) q (10509 . 4)) ((c form c (c (? . 7) q in-phase1)) q (1797 . 2)) ((c def c (c (? . 9) q sequence-lift)) q (9375 . 4)) ((c def c (c (? . 5) q extend)) q (5335 . 5)) ((c def c (c (? . 2) q compose-error-detail)) q (3924 . 5)) ((c form c (c (? . 7) q at-end)) q (1775 . 2)) ((c def c (c (? . 8) q break-lines)) q (9076 . 4)) ((c def c (c (? . 13) q find-first)) q (4678 . 11)) ((c def c (c (? . 3) q has-option?)) q (7385 . 3)) ((c form c (c (? . 0) q define/public/debug)) q (842 . 3)) ((c def c (c (? . 9) q in-sequence-forever)) q (9278 . 4)) ((c def c (c (? . 8) q pretty-format/display)) q (8722 . 5)) ((c def c (c (? . 8) q pretty-format/write)) q (8546 . 5)) ((c def c (c (? . 3) q waive-option)) q (7275 . 3)) ((c def c (c (? . 10) q start-recording)) q (5726 . 3)) ((c form c (c (? . 0) q begin/debug)) q (648 . 2)) ((c def c (c (? . 3) q exercise-option)) q (7186 . 3)) ((c def c (c (? . 3) q transfer/c)) q (7244 . 2)) ((c def c (c (? . 11) q maybe/c)) q (153 . 3)) ((q def ((lib "unstable/custom-write.rkt") prop:auto-custom-write)) q (9732 . 2)) ((c form c (c (? . 0) q define/augment/debug)) q (1020 . 3)) ((c form c (c (? . 7) q in-phase1/pass2)) q (1819 . 2)) ((c form c (c (? . 4) q match?)) q (6156 . 2)) ((c def c (c (? . 11) q path-piece?)) q (121 . 2)) ((c def c (c (? . 11) q treeof)) q (258 . 3)) ((c def c (c (? . 12) q read/bytes)) q (0 . 3)) ((c def c (c (? . 2) q error-display)) q (4152 . 3)) ((c form c (c (? . 0) q letrec/debug)) q (1286 . 2)) ((c def c (c (? . 13) q find)) q (4208 . 11)) ((c def c (c (? . 3) q tweak-option)) q (7330 . 3)) ((c form c (c (? . 0) q let-values/debug)) q (1347 . 2)) ((c def c (c (? . 9) q in-pairs)) q (9215 . 3)) ((c def c (c (? . 2) q raise-syntax-error*)) q (2440 . 15)) ((c form c (c (? . 0) q debugf)) q (526 . 5))))
procedure
(read/bytes b) -> printable/c
  b : bytes?
procedure
(write/bytes v) -> bytes?
  v : printable/c
value
path-piece? : contract?
procedure
(maybe/c contract) -> contract?
  contract : contract?
value
truth/c : flat-contract?
procedure
(treeof elem-contract) -> contract?
  elem-contract : contract?
syntax
(debug options ... expr)
 
options = #:name name-expr
        | #:source srcloc-expr
procedure
(dprintf fmt arg ...) -> void?
  fmt : string?
  arg : any/c
syntax
(debugf function-expr argument ...)
 
argument = argument-expr
         | argument-keyword argument-expr
syntax
(begin/debug expr ...)
syntax
(define/debug id expr)
(define/debug (head args) body ...+)
syntax
(define/private/debug id expr)
(define/private/debug (head args) body ...+)
syntax
(define/public/debug id expr)
(define/public/debug (head args) body ...+)
syntax
(define/override/debug id expr)
(define/override/debug (head args) body ...+)
syntax
(define/augment/debug id expr)
(define/augment/debug (head args) body ...+)
syntax
(let/debug ([lhs-id rhs-expr] ...) body ...+)
(let/debug loop-id ([lhs-id rhs-expr] ...) body ...+)
syntax
(let*/debug ([lhs-id rhs-expr] ...) body ...+)
syntax
(letrec/debug ([lhs-id rhs-expr] ...) body ...+)
syntax
(let-values/debug ([(lhs-id ...) rhs-expr] ...) body ...+)
syntax
(let*-values/debug ([(lhs-id ...) rhs-expr] ...) body ...+)
syntax
(letrec-values/debug ([(lhs-id ...) rhs-expr] ...) body ...+)
syntax
(with-syntax/debug ([pattern stx-expr] ...) body ...+)
syntax
(with-syntax*/debug ([pattern stx-expr] ...) body ...+)
syntax
(parameterize/debug ([param-expr value-expr] ...) body ...+)
syntax
(at-end expr)
syntax
(in-phase1 e)
syntax
(in-phase1/pass2 e)
procedure
(error*  name                                
         message                             
         field                               
         value ...                           
         ...                                 
        [#:continued continued-message]) -> any
  name : symbol?
  message : string?
  field : (let ([option/c (or/c 'value 'multi 'maybe)])
            (or/c string? (cons/c string? (listof option/c))))
  value : any/c
  continued-message : (or/c string? (listof string?)) = null
procedure
(raise-syntax-error*  message                             
                      expr                                
                      sub-expr                            
                      field                               
                      value ...                           
                      ...                                 
                     [#:continued continued-message]) -> any
  message : string?
  expr : (or/c syntax? #f)
  sub-expr : (or/c syntax? #f)
  field : (let ([option/c (or/c 'value 'multi 'maybe)])
            (or/c string? (cons/c string? (listof option/c))))
  value : any/c
  continued-message : (or/c string? (listof string?)) = null
procedure
(compose-error-message  name                                
                        message                             
                        field                               
                        value ...                           
                        ...                                 
                       [#:continued continued-message]) -> string?
  name : (or/c symbol? #f)
  message : string?
  field : (let ([option/c (or/c 'value 'multi 'maybe)])
            (or/c string? (cons/c string? (listof option/c))))
  value : any/c
  continued-message : (or/c string? (listof string?)) = null
procedure
(compose-error-detail field options value) -> string?
  field : string?
  options : (listof (or/c 'value 'multi 'maybe))
  value : any/c
procedure
(exn:not-break? x) -> boolean?
  x : any/c
procedure
(error-display x) -> void?
  x : any/c
procedure
(find  pred                                
       x                                   
      [#:stop-on-found? stop-on-found?     
       #:stop stop                         
       #:get-children get-children])   -> list?
  pred : (-> any/c any/c)
  x : any/c
  stop-on-found? : any/c = #f
  stop : (or/c #f (-> any/c any/c)) = #f
  get-children : (or/c #f (-> any/c (or/c #f list?))) = #f
procedure
(find-first  pred                            
             x                               
            [#:stop stop                     
             #:get-children get-children     
             #:default default])         -> any/c
  pred : (-> any/c any/c)
  x : any/c
  stop : (or/c #f (-> any/c any/c)) = #f
  get-children : (or/c #f (-> any/c (or/c #f list?))) = #f
  default : any/c = (lambda () (error ....))
syntax
(begin-on-demand #:export (fun-id ...)
   body ...+)
procedure
(filter-multiple l f ...) -> list? ...
  l : list?
  f : procedure?
procedure
(extend l1 l2 v) -> list?
  l1 : list?
  l2 : list?
  v : any/c
procedure
(map/values n f lst ...) -> (listof B_1) ... (listof B_n)
  n : natural-number/c
  f : (-> A ... (values B_1 ... B_n))
  lst : (listof A)
procedure
(map2 f lst ...) -> (listof B) (listof C)
  f : (-> A ... (values B C))
  lst : (listof A)
procedure
(start-recording log-spec ...) -> listener?
  log-spec : (or/c 'fatal 'error 'warning 'info 'debug symbol? #f)
procedure
(stop-recording listener)
 -> (listof (vector/c (or/c 'fatal 'error 'warning 'info 'debug)
                      string?
                      any/c
                      (or/c symbol? #f)))
  listener : listener?
syntax
(match? val-expr pat ...)
syntax
(as ([lhs-id rhs-expr] ...) pat ...)
syntax
(match*? (val-expr ...) (pat ...) ...)
syntax
(object maybe-class field-clause ...)
 
 maybe-class = 
             | class-expr
                
field-clause = (field field-id maybe-pat)
                
   maybe-pat = 
             | pat
procedure
(option/c  c                         
          [#:with-contract with      
           #:tester tester           
           #:invariant invariant     
           #:immutable immutable     
           #:flat? flat?             
           #:struct struct-id])  -> contract?
  c : contract?
  with : boolean? = #f
  tester : (or/c (-> any boolean?) 'dont-care) = 'dont-care
  invariant : (or/c (-> any boolean?) 'dont-care) = 'dont-care
  immutable : (or/c #t #f 'dont-care) = 'dont-care
  flat? : boolean? = #f
  struct-id : (or/c identifier? 'none) = 'none
procedure
(exercise-option x) -> any/c
  x : any/c
value
transfer/c : contract?
procedure
(waive-option x) -> any/c
  x : any/c
procedure
(tweak-option x) -> any/c
  x : any/c
procedure
(has-option? v) -> boolean?
  v : any/c
procedure
(has-option-with-contract? v) -> boolean?
  v : any/c
procedure
(invariant/c  c                         
              invariant                 
             [#:immutable immutable     
              #:flat? flat?             
              #:struct struct-id])  -> contract?
  c : contract?
  invariant : (-> any boolean?)
  immutable : (or/c #t #f 'dont-care) = 'dont-care
  flat? : boolean? = #f
  struct-id : (or/c identifier? 'none) = 'none
procedure
(parameter-group? v) -> boolean?
  v : any/c
syntax
(define-parameter-group name (param-or-group-expr ...) options)
 
options = 
        | #:struct struct-name
 
  param-or-group-expr : (or/c parameter? parameter-group?)
syntax
(parameterize/group ([param-or-group-expr  value-expr] ...)
  body-expr ...+)
 
  param-or-group-expr : (or/c parameter? parameter-group?)
syntax
(parameterize*/group ([param-or-group-expr  value-expr] ...)
  body-expr ...+)
 
  param-or-group-expr : (or/c parameter? parameter-group?)
procedure
(pretty-format/write x [columns]) -> string?
  x : any/c
  columns : (or/c exact-nonnegative-integer? 'infinity)
          = (pretty-print-columns)
procedure
(pretty-format/display x [columns]) -> string?
  x : any/c
  columns : (or/c exact-nonnegative-integer? 'infinity)
          = (pretty-print-columns)
procedure
(pretty-format/print x [columns]) -> string?
  x : any/c
  columns : (or/c exact-nonnegative-integer? 'infinity)
          = (pretty-print-columns)
procedure
(break-lines s [columns]) -> string?
  s : string?
  columns : exact-nonnegative-integer? = (pretty-print-columns)
procedure
(in-pairs seq) -> sequence?
  seq : sequence?
procedure
(in-sequence-forever seq val) -> sequence?
  seq : sequence?
  val : any/c
procedure
(sequence-lift f seq) -> sequence?
  f : procedure?
  seq : sequence?
procedure
(regexp-filter pattern lst)
 -> (listof (or/c string? bytes? path? input-port?))
  pattern : (or/c string? bytes? regexp? byte-regexp?)
  lst : (listof (or/c string? bytes? path? input-port?))
syntax
(make struct-id expr ...)
value
prop:auto-custom-write : (struct-type-property/c 'constructor)
procedure
(explode-module-path-index mpi)
 -> (listof (or/c module-path? resolved-module-path? #f))
  mpi : module-path-index?
syntax
(phase-of-enclosing-module)
procedure
(format-unique-id  lctx              
                   fmt               
                   v ...             
                  [#:source src      
                   #:props props     
                   #:cert cert]) -> identifier?
  lctx : (or/c syntax? #f)
  fmt : string?
  v : (or/c string? symbol? identifier? keyword? char? number?)
  src : (or/c syntax? #f) = #f
  props : (or/c syntax? #f) = #f
  cert : (or/c syntax? #f) = #f
procedure
(syntax-within? a b) -> boolean?
  a : syntax?
  b : syntax?
procedure
(syntax-length stx) -> exact-nonnegative-integer?
  stx : syntax?
