#lang racklog
true.
true?
