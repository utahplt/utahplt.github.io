539
((3) 0 () 1 ((q lib "slideshow/staged-slide.rkt")) () (h ! (equal) ((c form c (c (? . 0) q before)) q (139 . 2)) ((c form c (c (? . 0) q stage-name)) q (53 . 2)) ((c form c (c (? . 0) q before/after)) q (231 . 2)) ((c form c (c (? . 0) q before/at)) q (161 . 2)) ((c form c (c (? . 0) q after)) q (210 . 2)) ((c form c (c (? . 0) q at/after)) q (186 . 2)) ((c form c (c (? . 0) q slide/staged)) q (71 . 2)) ((c form c (c (? . 0) q stage)) q (40 . 2)) ((c form c (c (? . 0) q staged)) q (0 . 2)) ((c form c (c (? . 0) q at)) q (116 . 2))))
syntax
(staged [name ...] body ...)
syntax
stage
syntax
stage-name
syntax
(slide/staged [name ...] arg ...)
syntax
(at name ...)
syntax
(before name)
syntax
(before/at name)
syntax
(at/after name)
syntax
(after name)
syntax
(before/after name)
