2045
((3) 0 () 6 ((q lib "temp-c/monitor.rkt") (q 226 . 16) (q 708 . 18) (q 0 . 4) (q lib "temp-c/dsl.rkt") (q 78 . 6)) () (h ! (equal) ((c def c (c (? . 0) q monitor:return-proj-label)) c (? . 2)) ((c form c (c (? . 4) q label)) q (1513 . 2)) ((c def c (c (? . 0) q monitor:call-args)) c (? . 1)) ((c def c (c (? . 0) q struct:monitor:call)) c (? . 1)) ((c def c (c (? . 0) q monitor/c)) q (1264 . 5)) ((c def c (c (? . 0) q monitor:return?)) c (? . 2)) ((c def c (c (? . 0) q monitor:return-label)) c (? . 2)) ((c def c (c (? . 0) q monitor)) c (? . 3)) ((c def c (c (? . 0) q struct:monitor)) c (? . 3)) ((c def c (c (? . 0) q monitor:return)) c (? . 2)) ((c def c (c (? . 0) q monitor:call-proj-label)) c (? . 1)) ((c def c (c (? . 0) q monitor:call-f)) c (? . 1)) ((c def c (c (? . 0) q monitor:return-f)) c (? . 2)) ((c form c (c (? . 4) q with-monitor)) q (1468 . 2)) ((c form c (c (? . 4) q call)) q (1419 . 2)) ((c def c (c (? . 0) q monitor:call)) c (? . 1)) ((c def c (c (? . 0) q monitor:return-rets)) c (? . 2)) ((c def c (c (? . 0) q monitor:call?)) c (? . 1)) ((c def c (c (? . 0) q monitor:return-kw-args)) c (? . 2)) ((c def c (c (? . 0) q monitor:call-kw-args)) c (? . 1)) ((c def c (c (? . 0) q monitor:call-label)) c (? . 1)) ((c def c (c (? . 0) q monitor-label)) c (? . 3)) ((c def c (c (? . 0) q monitor:return-args)) c (? . 2)) ((c def c (c (? . 0) q struct:monitor:proj)) c (? . 5)) ((c def c (c (? . 0) q monitor:proj)) c (? . 5)) ((c def c (c (? . 0) q monitor:call-app-label)) c (? . 1)) ((c form c (c (? . 4) q ret)) q (1444 . 2)) ((c def c (c (? . 0) q monitor:proj-proj-label)) c (? . 5)) ((c def c (c (? . 0) q monitor:return-kws)) c (? . 2)) ((c def c (c (? . 0) q monitor:proj-v)) c (? . 5)) ((c def c (c (? . 0) q monitor:return-app-label)) c (? . 2)) ((c def c (c (? . 0) q struct:monitor:return)) c (? . 2)) ((c def c (c (? . 0) q monitor:call-kws)) c (? . 1)) ((c def c (c (? . 0) q monitor:proj-label)) c (? . 5)) ((c def c (c (? . 0) q monitor:proj?)) c (? . 5)) ((c def c (c (? . 0) q monitor?)) c (? . 3))))
struct
(struct monitor (label)
    #:transparent)
  label : symbol?
struct
(struct monitor:proj monitor (label proj-label v)
    #:transparent)
  label : symbol?
  proj-label : symbol?
  v : any/c
struct
(struct monitor:call monitor (label
                              proj-label
                              f
                              app-label
                              kws
                              kw-args
                              args)
    #:transparent)
  label : symbol?
  proj-label : symbol?
  f : procedure?
  app-label : symbol?
  kws : (listof keyword?)
  kw-args : list?
  args : list?
struct
(struct monitor:return monitor (label
                                proj-label
                                f
                                app-label
                                kws
                                kw-args
                                args
                                rets)
    #:transparent)
  label : symbol?
  proj-label : symbol?
  f : procedure?
  app-label : symbol?
  kws : (listof keyword?)
  kw-args : list?
  args : list?
  rets : list?
procedure
(monitor/c monitor-allows? label c) -> contract?
  monitor-allows? : (-> monitor? boolean?)
  label : symbol?
  c : contract?
syntax
(call n a ...)
syntax
(ret n a ...)
syntax
(with-monitor contract-expr re-pat)
syntax
(label id contract-expr)
