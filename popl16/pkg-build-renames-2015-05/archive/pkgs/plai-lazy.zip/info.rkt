#lang setup/infotab
(define collection (quote multi))
