#lang setup/infotab

(define collection "plai-lazy")
  
(define scribblings '(("scribblings/plai-lazy.scrbl" (multi-page) (language -11))))
