39129
((3) 0 () 90 ((q lib "compiler/zo-structs.rkt") (q 41445 . 24) (q lib "setup/getinfo.rkt") (q lib "setup/option-sig.rkt") (q 46948 . 19) (q lib "setup/dirs.rkt") (q 42807 . 8) (q 46812 . 5) (q lib "compiler/cm.rkt") (q 51736 . 6) (q 35735 . 5) (q 39140 . 42) (q 44789 . 6) (q 44999 . 7) (q 43308 . 9) (q 51958 . 7) (q 49024 . 17) (q 51567 . 5) (q 51460 . 4) (q 38684 . 5) (q lib "launcher/launcher.rkt") (q 44550 . 7) (q 38243 . 8) (q 30158 . 8) (q 49677 . 4) (q 51245 . 6) (q 35869 . 10) (q 48149 . 8) (q lib "setup/path-to-relative.rkt") (q lib "compiler/zo-marshal.rkt") (q 36545 . 5) (q 37382 . 4) (q 46351 . 7) (q 45230 . 7) (q 38541 . 6) (q 37923 . 9) (q 38825 . 5) (q 35420 . 8) (q 46212 . 5) (q 49961 . 13) (q 35176 . 7) (q 43805 . 6) (q 36248 . 6) (q 48425 . 17) (q 43085 . 7) (q 41002 . 10) (q 46669 . 5) (q 45804 . 7) (q lib "setup/main-doc.rkt") (q 38972 . 6) (q 43627 . 6) (q 42474 . 6) (q 36903 . 4) (q 50509 . 11) (q 43989 . 9) (q 49788 . 5) (q lib "compiler/embed.rkt") (q 37026 . 5) (q 42625 . 6) (q 36730 . 5) (q 37632 . 4) (q 45473 . 5) (q lib "setup/main-collects.rkt") (q lib "compiler/compiler.rkt") (q 37511 . 5) (q 46578 . 4) (q 46004 . 6) (q 47609 . 12) (q 36442 . 4) (q 44298 . 8) (q 35093 . 4) (q lib "setup/xref.rkt") (q 37205 . 5) (q lib "setup/plt-single-installer.rkt") (q lib "raco/command-name.rkt") (q 37723 . 6) (q lib "compiler/option.rkt") (q 51022 . 6) (q 45618 . 6) (q lib "setup/pack.rkt") (q lib "setup/collection-name.rkt") (q 41352 . 4) (q lib "setup/collects.rkt") (q lib "compiler/compilation-path.rkt") (q lib "setup/unpack.rkt") (q lib "compiler/bundle-dist.rkt") (q lib "compiler/cm-accomplice.rkt") (q lib "compiler/sig.rkt") (q lib "setup/matching-platform.rkt") (q lib "setup/parallel-build.rkt")) () (h ! (equal) ((c def c (c (? . 2) q find-relevant-directories)) q (29793 . 5)) ((c def c (c (? . 0) q lam-closure-types)) c (? . 1)) ((c sig-val c (c (? . 3) q setup-option^ verbose)) q (22933 . 4)) ((c def c (c (? . 0) q exported-module-binding)) c (? . 25)) ((c def c (c (? . 0) q struct:mark-barrier)) c (? . 7)) ((c def c (c (? . 0) q make-let-one)) c (? . 6)) ((c def c (c (? . 8) q trust-existing-zos)) q (1079 . 4)) ((c def c (c (? . 85) q bundle-put-file-extension+style+filters)) q (20978 . 5)) ((c def c (c (? . 0) q lam-name)) c (? . 1)) ((c def c (c (? . 73) q clean-planet-package)) q (27011 . 7)) ((c def c (c (? . 0) q module-rename-plus-kern?)) c (? . 43)) ((c def c (c (? . 0) q install-value?)) c (? . 14)) ((c def c (c (? . 0) q free-id-info-symbol1)) c (? . 4)) ((c def c (c (? . 5) q get-collects-search-dirs)) q (27389 . 2)) ((c def c (c (? . 2) q get-info)) q (29149 . 10)) ((c sig-val c (c (? . 3) q setup-option^ compile-mode)) q (23269 . 4)) ((c def c (c (? . 0) q free-id-info-phase1)) c (? . 4)) ((c def c (c (? . 5) q get-include-search-dirs)) q (28459 . 2)) ((c def c (c (? . 0) q struct:all-from-module)) c (? . 16)) ((c def c (c (? . 0) q struct:phased-nominal-path)) c (? . 15)) ((c def c (c (? . 0) q struct-type-shape)) c (? . 30)) ((c def c (c (? . 0) q struct:nominal-path)) c (? . 18)) ((c def c (c (? . 29) q zo-marshal)) q (35024 . 3)) ((c def c (c (? . 0) q let-one-body)) c (? . 6)) ((c def c (c (? . 0) q mod-requires)) c (? . 11)) ((c def c (c (? . 0) q splice-forms)) c (? . 36)) ((c def c (c (? . 0) q phased-module-binding-nominal-export-name)) c (? . 39)) ((c def c (c (? . 0) q struct-other-shape)) c (? . 31)) ((c def c (c (? . 0) q compilation-top-code)) c (? . 40)) ((c def c (c (? . 5) q find-user-pkgs-dir)) q (27784 . 3)) ((c def c (c (? . 0) q seq?)) c (? . 19)) ((c def c (c (? . 0) q struct:seq-for-syntax)) c (? . 22)) ((c def c (c (? . 0) q struct:form)) c (? . 60)) ((c def c (c (? . 0) q make-imported-nominal-path)) c (? . 9)) ((c def c (c (? . 5) q get-build-stamp)) q (29043 . 2)) ((c def c (c (? . 0) q predicate-shape?)) c (? . 52)) ((c def c (c (? . 0) q free-id-info-symbol0)) c (? . 4)) ((c def c (c (? . 0) q make-mark-barrier)) c (? . 7)) ((c def c (c (? . 8) q make-compilation-manager-load/use-compiled-handler)) q (0 . 7)) ((c def c (c (? . 0) q simple-nominal-path)) c (? . 17)) ((c def c (c (? . 0) q struct:imported-nominal-path)) c (? . 9)) ((c sig-val c (c (? . 3) q setup-option^ make-only)) q (25428 . 4)) ((c def c (c (? . 48) q path->main-doc-relative)) q (31504 . 4)) ((c def c (c (? . 0) q global-bucket?)) c (? . 10)) ((c def c (c (? . 0) q branch)) c (? . 13)) ((c def c (c (? . 0) q def-syntaxes-max-let-depth)) c (? . 35)) ((c def c (c (? . 8) q make-compilation-context-error-display-handler)) q (913 . 4)) ((c def c (c (? . 0) q application-rator)) c (? . 12)) ((c def c (c (? . 2) q reset-relevant-directories-state!)) q (30385 . 2)) ((c sig-val c (c (? . 3) q setup-option^ fail-fast)) q (24599 . 4)) ((c def c (c (? . 2) q directory-record)) c (? . 23)) ((c def c (c (? . 0) q case-lam)) c (? . 58)) ((c def c (c (? . 0) q make-global-bucket)) c (? . 10)) ((c def c (c (? . 0) q prefix)) c (? . 37)) ((c sig-val c (c (? . 3) q setup-option^ archive-implies-reindex)) q (25623 . 4)) ((c def c (c (? . 0) q free-id-info?)) c (? . 4)) ((c def c (c (? . 0) q mod-flags)) c (? . 11)) ((c def c (c (? . 5) q find-collects-dir)) q (27290 . 2)) ((c def c (c (? . 0) q application?)) c (? . 12)) ((q def ((lib "setup/link.rkt") links)) q (52228 . 28)) ((c def c (c (? . 0) q localref-clear?)) c (? . 54)) ((c def c (c (? . 5) q find-links-file)) q (27561 . 2)) ((c def c (c (? . 20) q build-aux-from-path)) q (19479 . 3)) ((c def c (c (? . 0) q make-branch)) c (? . 13)) ((c def c (c (? . 0) q simple-module-binding?)) c (? . 55)) ((c def c (c (? . 0) q make-with-cont-mark)) c (? . 33)) ((c sig-val c (c (? . 3) q setup-option^ avoid-main-installation)) q (23992 . 4)) ((c def c (c (? . 0) q make-module-variable)) c (? . 26)) ((c def c (c (? . 0) q install-value-count)) c (? . 14)) ((c def c (c (? . 0) q phased-nominal-path)) c (? . 15)) ((c def c (c (? . 0) q make-all-from-module)) c (? . 16)) ((c def c (c (? . 0) q make-install-value)) c (? . 14)) ((c def c (c (? . 0) q accessor-shape?)) c (? . 57)) ((c def c (c (? . 0) q assign-undef-ok?)) c (? . 47)) ((c def c (c (? . 0) q mod-body)) c (? . 11)) ((c def c (c (? . 0) q topsyntax?)) c (? . 21)) ((c def c (c (? . 0) q phase-shift-dest)) c (? . 27)) ((c def c (c (? . 5) q find-user-console-bin-dir)) q (28624 . 2)) ((c def c (c (? . 0) q simple-nominal-path?)) c (? . 17)) ((c def c (c (? . 0) q nominal-path?)) c (? . 18)) ((c def c (c (? . 0) q module-binding)) c (? . 24)) ((c def c (c (? . 0) q struct:def-values)) c (? . 75)) ((c def c (c (? . 0) q primval-id)) c (? . 38)) ((c def c (c (? . 0) q struct:seq)) c (? . 19)) ((c def c (c (? . 20) q mred-launcher-is-directory?)) q (17743 . 2)) ((c def c (c (? . 0) q lam-max-let-depth)) c (? . 1)) ((c def c (c (? . 0) q topsyntax-midpt)) c (? . 21)) ((c def c (c (? . 0) q struct:boxenv)) c (? . 41)) ((c def c (c (? . 0) q make-seq-for-syntax)) c (? . 22)) ((c def c (c (? . 0) q free-id-info)) c (? . 4)) ((c def c (c (? . 82) q path->collects-relative)) q (30442 . 8)) ((c def c (c (? . 0) q nominal-path)) c (? . 18)) ((c def c (c (? . 0) q struct:application)) c (? . 12)) ((c sig-val c (c (? . 3) q setup-option^ archives)) q (25510 . 4)) ((c def c (c (? . 0) q imported-nominal-path?)) c (? . 9)) ((c def c (c (? . 0) q let-one)) c (? . 6)) ((c def c (c (? . 0) q lam)) c (? . 1)) ((c def c (c (? . 2) q directory-record-maj)) c (? . 23)) ((c def c (c (? . 0) q all-from-module-prefix)) c (? . 16)) ((c def c (c (? . 0) q make-module-binding)) c (? . 24)) ((c def c (c (? . 20) q install-gracket-program-launcher)) q (14602 . 7)) ((c def c (c (? . 28) q make-path->relative-string)) q (32643 . 6)) ((c def c (c (? . 5) q find-user-apps-dir)) q (28767 . 2)) ((c def c (c (? . 5) q get-pkgs-search-dirs)) q (27883 . 2)) ((c def c (c (? . 0) q make-wrapped)) c (? . 32)) ((c form c (c (? . 3) q setup-option^)) q (22792 . 2)) ((c def c (c (? . 0) q struct:inline-variant)) c (? . 49)) ((c def c (c (? . 0) q struct:req)) c (? . 34)) ((c def c (c (? . 0) q make-struct-shape)) c (? . 68)) ((c def c (c (? . 0) q make-exported-module-binding)) c (? . 25)) ((c def c (c (? . 0) q module-variable?)) c (? . 26)) ((c def c (c (? . 0) q varref)) c (? . 78)) ((c def c (c (? . 0) q phase-shift-cancel-id)) c (? . 27)) ((c def c (c (? . 0) q let-void-body)) c (? . 44)) ((c def c (c (? . 28) q path->relative-string/setup)) q (32238 . 8)) ((c def c (c (? . 0) q exported-nominal-module-binding-path)) c (? . 53)) ((c def c (c (? . 29) q zo-marshal-to)) q (34923 . 4)) ((c def c (c (? . 0) q apply-values-args-expr)) c (? . 66)) ((c def c (c (? . 20) q make-gracket-program-launcher)) q (14117 . 7)) ((c def c (c (? . 0) q module-variable-pos)) c (? . 26)) ((c def c (c (? . 0) q struct-type-shape?)) c (? . 30)) ((c def c (c (? . 0) q struct:topsyntax)) c (? . 21)) ((c def c (c (? . 20) q gracket-launcher-put-file-extension+style+filters)) q (17198 . 5)) ((q def ((lib "compiler/decompile.rkt") decompile)) q (34759 . 3)) ((q def ((lib "setup/option-unit.rkt") setup:option@)) q (22762 . 2)) ((c def c (c (? . 0) q all-from-module-phase)) c (? . 16)) ((c def c (c (? . 8) q make-caching-managed-compile-zo)) q (1185 . 8)) ((c def c (c (? . 0) q phase-shift-src)) c (? . 27)) ((c def c (c (? . 0) q struct:zo)) c (? . 70)) ((c def c (c (? . 0) q make-struct-other-shape)) c (? . 31)) ((q def ((lib "compiler/zo-parse.rkt") zo-parse)) q (34826 . 3)) ((c def c (c (? . 0) q lexical-rename)) c (? . 67)) ((c def c (c (? . 0) q exported-module-binding-path)) c (? . 25)) ((c def c (c (? . 56) q embedding-executable-is-directory?)) q (12984 . 3)) ((c def c (c (? . 0) q wrapped?)) c (? . 32)) ((c def c (c (? . 0) q struct:function-shape)) c (? . 42)) ((c def c (c (? . 0) q with-cont-mark?)) c (? . 33)) ((c def c (c (? . 20) q make-racket-launcher)) q (13941 . 5)) ((c def c (c (? . 0) q make-req)) c (? . 34)) ((c def c (c (? . 0) q provided-protected?)) c (? . 45)) ((c def c (c (? . 0) q def-syntaxes?)) c (? . 35)) ((q form ((lib "launcher/launcher-sig.rkt") launcher^)) q (20331 . 2)) ((c def c (c (? . 20) q mred-launcher-add-suffix)) q (17860 . 3)) ((c def c (c (? . 0) q mod-name)) c (? . 11)) ((c def c (c (? . 0) q all-from-module-exceptions)) c (? . 16)) ((c def c (c (? . 0) q mod-srcname)) c (? . 11)) ((c def c (c (? . 0) q make-splice)) c (? . 36)) ((c def c (c (? . 76) q compile-subcollections)) q (62892 . 4)) ((c def c (c (? . 20) q make-mzscheme-launcher)) q (15743 . 5)) ((c def c (c (? . 5) q find-console-bin-dir)) q (28516 . 2)) ((c def c (c (? . 0) q prefix?)) c (? . 37)) ((c def c (c (? . 0) q wrapped-datum)) c (? . 32)) ((c def c (c (? . 0) q module-variable-sym)) c (? . 26)) ((c def c (c (? . 0) q make-primval)) c (? . 38)) ((c sig-val c (c (? . 3) q setup-option^ call-install)) q (24184 . 4)) ((c def c (c (? . 0) q phased-module-binding-nominal-path)) c (? . 39)) ((c def c (c (? . 20) q racket-launcher-add-suffix)) q (17108 . 3)) ((c def c (c (? . 0) q struct:lam)) c (? . 1)) ((c def c (c (? . 0) q struct:module-binding)) c (? . 24)) ((c def c (c (? . 0) q top-level-rename-flag)) c (? . 46)) ((c def c (c (? . 0) q compilation-top-prefix)) c (? . 40)) ((c def c (c (? . 0) q mod-post-submodules)) c (? . 11)) ((c def c (c (? . 0) q make-lam)) c (? . 1)) ((c def c (c (? . 5) q find-gui-bin-dir)) q (28572 . 2)) ((c def c (c (? . 0) q boxenv-body)) c (? . 41)) ((c def c (c (? . 0) q let-rec-body)) c (? . 50)) ((c def c (c (? . 2) q struct:directory-record)) c (? . 23)) ((c def c (c (? . 0) q simple-nominal-path-value)) c (? . 17)) ((c def c (c (? . 0) q struct:prefix)) c (? . 37)) ((c def c (c (? . 0) q function-shape?)) c (? . 42)) ((c def c (c (? . 0) q struct:struct-other-shape)) c (? . 31)) ((c def c (c (? . 5) q find-share-dir)) q (28269 . 2)) ((c def c (c (? . 80) q collection-name-element?)) q (32981 . 3)) ((c def c (c (? . 0) q module-rename?)) c (? . 43)) ((c def c (c (? . 0) q let-void-boxes?)) c (? . 44)) ((c def c (c (? . 0) q make-mod)) c (? . 11)) ((c def c (c (? . 0) q provided-src)) c (? . 45)) ((c def c (c (? . 0) q mod?)) c (? . 11)) ((c sig-val c (c (? . 3) q setup-option^ current-target-plt-directory-getter)) q (25886 . 9)) ((c def c (c (? . 0) q all-from-module-path)) c (? . 16)) ((c def c (c (? . 62) q main-collects-relative->path)) q (31319 . 5)) ((c def c (c (? . 2) q directory-record-min)) c (? . 23)) ((c def c (c (? . 0) q constructor-shape)) c (? . 59)) ((c def c (c (? . 0) q struct:top-level-rename)) c (? . 46)) ((c def c (c (? . 0) q let-void)) c (? . 44)) ((c def c (c (? . 0) q module-rename-phase)) c (? . 43)) ((c def c (c (? . 0) q make-assign)) c (? . 47)) ((c def c (c (? . 0) q closure)) c (? . 51)) ((c def c (c (? . 48) q main-doc-relative->path)) q (31652 . 5)) ((c def c (c (? . 0) q let-one-unused?)) c (? . 6)) ((c def c (c (? . 0) q inline-variant-direct)) c (? . 49)) ((c def c (c (? . 0) q lam-rest?)) c (? . 1)) ((c def c (c (? . 0) q install-value-pos)) c (? . 14)) ((c def c (c (? . 0) q module-binding?)) c (? . 24)) ((c def c (c (? . 0) q def-syntaxes-prefix)) c (? . 35)) ((c def c (c (? . 0) q let-rec-procs)) c (? . 50)) ((c def c (c (? . 0) q phased-module-binding-export-name)) c (? . 39)) ((q def ((lib "setup/materialize-user-docs.rkt") materialize-user-docs)) q (34628 . 3)) ((c def c (c (? . 0) q make-closure)) c (? . 51)) ((c sig-val c (c (? . 3) q setup-option^ make-info-domain)) q (23458 . 4)) ((c def c (c (? . 0) q predicate-shape)) c (? . 52)) ((c def c (c (? . 5) q get-main-collects-search-dirs)) q (27447 . 2)) ((c def c (c (? . 0) q exported-nominal-module-binding?)) c (? . 53)) ((c def c (c (? . 0) q boxenv)) c (? . 41)) ((q def ((lib "compiler/option-unit.rkt") compiler:option@)) q (63126 . 2)) ((c def c (c (? . 8) q make-compile-lock)) q (3637 . 2)) ((c def c (c (? . 0) q struct:mutator-shape)) c (? . 72)) ((c def c (c (? . 0) q compilation-top-max-let-depth)) c (? . 40)) ((c def c (c (? . 84) q unpack)) q (57962 . 20)) ((c sig-val c (c (? . 3) q setup-option^ clean)) q (23195 . 4)) ((c def c (c (? . 0) q inline-variant?)) c (? . 49)) ((c sig-val c (c (? . 3) q setup-option^ specific-collections)) q (24771 . 4)) ((q def ((lib "compiler/compiler-unit.rkt") compiler@)) q (63100 . 2)) ((c def c (c (? . 20) q available-mred-variants)) q (20209 . 2)) ((c def c (c (? . 0) q struct:localref)) c (? . 54)) ((c def c (c (? . 0) q struct:closure)) c (? . 51)) ((c sig-val c (c (? . 3) q setup-option^ compiler-verbose)) q (23099 . 4)) ((c def c (c (? . 0) q struct:wrap)) c (? . 65)) ((c def c (c (? . 8) q file-stamp-in-collection)) q (2110 . 4)) ((c def c (c (? . 0) q closure-code)) c (? . 51)) ((c def c (c (? . 0) q primval?)) c (? . 38)) ((c def c (c (? . 0) q make-simple-module-binding)) c (? . 55)) ((c def c (c (? . 0) q assign)) c (? . 47)) ((c def c (c (? . 56) q make-embedding-executable)) q (10773 . 29)) ((c def c (c (? . 8) q get-file-sha1)) q (2346 . 3)) ((c def c (c (? . 0) q struct:accessor-shape)) c (? . 57)) ((c def c (c (? . 0) q mod-prefix)) c (? . 11)) ((c def c (c (? . 0) q make-compilation-top)) c (? . 40)) ((c def c (c (? . 0) q let-rec?)) c (? . 50)) ((c def c (c (? . 0) q provided-name)) c (? . 45)) ((c def c (c (? . 79) q pack-plt)) q (55089 . 30)) ((c def c (c (? . 0) q make-simple-nominal-path)) c (? . 17)) ((c def c (c (? . 0) q case-lam?)) c (? . 58)) ((c def c (c (? . 63) q compile-zos)) q (60703 . 11)) ((c def c (c (? . 5) q find-config-dir)) q (27510 . 2)) ((c def c (c (? . 0) q localref-other-clears?)) c (? . 54)) ((c def c (c (? . 28) q path->relative-string/library)) q (31827 . 8)) ((c def c (c (? . 20) q mzscheme-launcher-put-file-extension+style+filters)) q (18529 . 5)) ((c def c (c (? . 0) q constructor-shape?)) c (? . 59)) ((c def c (c (? . 0) q struct:predicate-shape)) c (? . 52)) ((c def c (c (? . 0) q boxenv-pos)) c (? . 41)) ((c def c (c (? . 20) q installed-executable-path->desktop-path)) q (18717 . 6)) ((c def c (c (? . 0) q beg0-seq)) c (? . 61)) ((c def c (c (? . 0) q make-form)) c (? . 60)) ((c def c (c (? . 20) q racket-launcher-is-actually-directory?)) q (16952 . 2)) ((c def c (c (? . 0) q struct:primval)) c (? . 38)) ((c def c (c (? . 0) q make-topsyntax)) c (? . 21)) ((c def c (c (? . 0) q req-dummy)) c (? . 34)) ((c def c (c (? . 0) q stx-encoded)) c (? . 64)) ((c sig-val c (c (? . 3) q setup-option^ make-foreign-lib)) q (23646 . 4)) ((c def c (c (? . 0) q make-beg0)) c (? . 61)) ((c def c (c (? . 20) q racket-launcher-is-directory?)) q (16830 . 2)) ((c def c (c (? . 5) q get-lib-search-dirs)) q (28168 . 2)) ((c def c (c (? . 8) q manager-skip-file-handler)) q (1902 . 5)) ((c def c (c (? . 62) q path->main-collects-relative)) q (31161 . 4)) ((c def c (c (? . 0) q wrapped-tamper-status)) c (? . 32)) ((c def c (c (? . 0) q localref-pos)) c (? . 54)) ((c def c (c (? . 0) q phased-nominal-path-value)) c (? . 15)) ((c def c (c (? . 63) q compile-collection-zos)) q (61144 . 12)) ((c def c (c (? . 0) q make-phased-nominal-path)) c (? . 15)) ((c def c (c (? . 0) q function-shape-arity)) c (? . 42)) ((c def c (c (? . 0) q beg0)) c (? . 61)) ((c def c (c (? . 0) q make-def-syntaxes)) c (? . 35)) ((c def c (c (? . 0) q module-rename-set-id)) c (? . 43)) ((c def c (c (? . 0) q lam-param-types)) c (? . 1)) ((c def c (c (? . 0) q provided-src-name)) c (? . 45)) ((c def c (c (? . 20) q make-gracket-launcher)) q (13764 . 5)) ((c def c (c (? . 0) q prefix-toplevels)) c (? . 37)) ((c def c (c (? . 0) q assign-rhs)) c (? . 47)) ((c def c (c (? . 0) q provided)) c (? . 45)) ((c def c (c (? . 0) q stx)) c (? . 64)) ((c def c (c (? . 0) q toplevel)) c (? . 69)) ((c def c (c (? . 0) q make-wrap)) c (? . 65)) ((c def c (c (? . 0) q apply-values?)) c (? . 66)) ((c def c (c (? . 0) q case-lam-name)) c (? . 58)) ((c def c (c (? . 0) q make-phased-module-binding)) c (? . 39)) ((c def c (c (? . 71) q get-current-doc-state)) q (34437 . 2)) ((c def c (c (? . 74) q current-command-name)) q (63159 . 4)) ((c def c (c (? . 20) q mred-program-launcher-path)) q (17571 . 5)) ((c def c (c (? . 0) q lexical-rename-has-free-id-info?)) c (? . 67)) ((c sig-val c (c (? . 3) q setup-option^ make-user)) q (23824 . 4)) ((c def c (c (? . 0) q imported-nominal-path)) c (? . 9)) ((c def c (c (? . 20) q install-mred-program-launcher)) q (15504 . 7)) ((c def c (c (? . 0) q struct:with-cont-mark)) c (? . 33)) ((c def c (c (? . 0) q seq-for-syntax-prefix)) c (? . 22)) ((c def c (c (? . 0) q mod-max-let-depth)) c (? . 11)) ((c def c (c (? . 0) q nominal-module-binding-nominal-path)) c (? . 77)) ((q def ((lib "launcher/launcher-unit.rkt") launcher@)) q (20365 . 2)) ((c def c (c (? . 0) q exported-nominal-module-binding-nominal-path)) c (? . 53)) ((c def c (c (? . 0) q with-cont-mark-val)) c (? . 33)) ((c def c (c (? . 0) q struct:struct-shape)) c (? . 68)) ((c def c (c (? . 0) q module-variable-constantness)) c (? . 26)) ((c def c (c (? . 0) q splice)) c (? . 36)) ((c sig-val c (c (? . 3) q setup-option^ make-planet)) q (23906 . 4)) ((c def c (c (? . 0) q toplevel-const?)) c (? . 69)) ((c def c (c (? . 0) q phased-module-binding)) c (? . 39)) ((c sig-val c (c (? . 3) q setup-option^ call-post-install)) q (24272 . 4)) ((c def c (c (? . 0) q form?)) c (? . 60)) ((c def c (c (? . 56) q embedding-executable-is-actually-directory?)) q (13071 . 3)) ((c def c (c (? . 0) q mod-lang-info)) c (? . 11)) ((c def c (c (? . 0) q exported-nominal-module-binding-nominal-export-name)) c (? . 53)) ((c def c (c (? . 0) q make-apply-values)) c (? . 66)) ((c def c (c (? . 0) q form)) c (? . 60)) ((c def c (c (? . 8) q parallel-lock-client)) q (2637 . 15)) ((c def c (c (? . 0) q phase-shift)) c (? . 27)) ((q def ((lib "compiler/find-exe.rkt") find-exe)) q (13624 . 4)) ((c def c (c (? . 0) q lam?)) c (? . 1)) ((c def c (c (? . 0) q struct:lexical-rename)) c (? . 67)) ((c def c (c (? . 0) q install-value-boxes?)) c (? . 14)) ((c def c (c (? . 0) q seq-for-syntax?)) c (? . 22)) ((c def c (c (? . 20) q mred-launcher-is-actually-directory?)) q (17797 . 2)) ((c def c (c (? . 0) q zo?)) c (? . 70)) ((c form c (c (? . 87) q compiler^)) q (63025 . 2)) ((c def c (c (? . 0) q branch?)) c (? . 13)) ((c def c (c (? . 0) q exported-nominal-module-binding)) c (? . 53)) ((c def c (c (? . 0) q lexical-rename-alist)) c (? . 67)) ((c def c (c (? . 5) q find-include-dir)) q (28362 . 2)) ((c def c (c (? . 0) q def-syntaxes)) c (? . 35)) ((q def ((lib "compiler/compile-file.rkt") compile-file)) q (5482 . 8)) ((c def c (c (? . 0) q all-from-module?)) c (? . 16)) ((c def c (c (? . 20) q installed-desktop-path->icon-path)) q (18924 . 8)) ((c def c (c (? . 5) q get-doc-search-dirs)) q (28026 . 2)) ((c def c (c (? . 20) q install-mzscheme-program-launcher)) q (16168 . 7)) ((q form ((lib "compiler/embed-sig.rkt") compiler:embed^)) q (13552 . 2)) ((c def c (c (? . 0) q make-seq)) c (? . 19)) ((c def c (c (? . 20) q make-mzscheme-program-launcher)) q (15921 . 7)) ((c def c (c (? . 20) q mred-launcher-put-file-extension+style+filters)) q (17948 . 5)) ((c def c (c (? . 0) q struct:compilation-top)) c (? . 40)) ((c def c (c (? . 0) q module-variable-modidx)) c (? . 26)) ((c def c (c (? . 0) q req)) c (? . 34)) ((c def c (c (? . 0) q seq-for-syntax-max-let-depth)) c (? . 22)) ((c def c (c (? . 0) q closure?)) c (? . 51)) ((c sig-val c (c (? . 3) q setup-option^ setup-program-name)) q (22830 . 4)) ((c def c (c (? . 0) q expr?)) c (? . 81)) ((c def c (c (? . 0) q seq-for-syntax-forms)) c (? . 22)) ((c def c (c (? . 5) q get-doc-search-url)) q (28898 . 2)) ((c def c (c (? . 71) q load-collections-xref)) q (33519 . 3)) ((q def ((lib "compiler/distribute.rkt") assemble-distribution)) q (20391 . 9)) ((c sig-val c (c (? . 3) q setup-option^ specific-planet-dirs)) q (24930 . 11)) ((c def c (c (? . 0) q imported-nominal-path-import-phase)) c (? . 9)) ((c def c (c (? . 0) q mutator-shape-field-count)) c (? . 72)) ((c def c (c (? . 0) q global-bucket-name)) c (? . 10)) ((c def c (c (? . 73) q install-planet-package)) q (26648 . 8)) ((c def c (c (? . 20) q mzscheme-launcher-up-to-date?)) q (20069 . 4)) ((c def c (c (? . 0) q make-accessor-shape)) c (? . 57)) ((c def c (c (? . 0) q struct:global-bucket)) c (? . 10)) ((c def c (c (? . 0) q struct-other-shape?)) c (? . 31)) ((c def c (c (? . 0) q make-predicate-shape)) c (? . 52)) ((c def c (c (? . 0) q lam-num-params)) c (? . 1)) ((c def c (c (? . 0) q module-rename-kind)) c (? . 43)) ((c def c (c (? . 0) q seq)) c (? . 19)) ((c def c (c (? . 0) q make-phase-shift)) c (? . 27)) ((c def c (c (? . 0) q localref)) c (? . 54)) ((c def c (c (? . 0) q with-cont-mark)) c (? . 33)) ((c def c (c (? . 0) q mod-self-modidx)) c (? . 11)) ((c def c (c (? . 74) q program+command-name)) q (63342 . 2)) ((c def c (c (? . 5) q get-links-search-files)) q (27701 . 2)) ((c def c (c (? . 0) q def-values-rhs)) c (? . 75)) ((c def c (c (? . 0) q branch-else)) c (? . 13)) ((c def c (c (? . 0) q splice?)) c (? . 36)) ((c def c (c (? . 76) q verbose)) q (62814 . 4)) ((c def c (c (? . 56) q embedding-executable-put-file-extension+style+filters)) q (13168 . 6)) ((c def c (c (? . 0) q mutator-shape?)) c (? . 72)) ((c def c (c (? . 0) q struct:free-id-info)) c (? . 4)) ((c def c (c (? . 0) q closure-gen-id)) c (? . 51)) ((c def c (c (? . 2) q directory-record-spec)) c (? . 23)) ((c def c (c (? . 0) q make-zo)) c (? . 70)) ((c def c (c (? . 20) q make-mred-program-launcher)) q (15269 . 7)) ((c def c (c (? . 0) q zo)) c (? . 70)) ((c def c (c (? . 0) q make-def-values)) c (? . 75)) ((c def c (c (? . 56) q create-embedding-executable)) q (7085 . 59)) ((c def c (c (? . 0) q struct:struct-type-shape)) c (? . 30)) ((c sig-val c (c (? . 3) q setup-option^ current-target-directory-getter)) q (25733 . 4)) ((c def c (c (? . 0) q nominal-module-binding?)) c (? . 77)) ((c def c (c (? . 0) q top-level-rename)) c (? . 46)) ((c def c (c (? . 0) q let-one-rhs)) c (? . 6)) ((c def c (c (? . 0) q let-one-type)) c (? . 6)) ((c def c (c (? . 0) q struct:wrapped)) c (? . 32)) ((c def c (c (? . 0) q localref-type)) c (? . 54)) ((c def c (c (? . 0) q mod-dummy)) c (? . 11)) ((c def c (c (? . 0) q let-rec)) c (? . 50)) ((c def c (c (? . 86) q register-external-file)) q (5068 . 5)) ((q def ((lib "compiler/embed-unit.rkt") compiler:embed@)) q (13592 . 2)) ((c def c (c (? . 73) q run-single-installer)) q (26188 . 9)) ((c def c (c (? . 0) q simple-module-binding)) c (? . 55)) ((c def c (c (? . 56) q write-module-bundle)) q (12281 . 13)) ((c def c (c (? . 0) q module-variable)) c (? . 26)) ((c def c (c (? . 0) q boxenv?)) c (? . 41)) ((c def c (c (? . 8) q managed-compile-zo)) q (476 . 8)) ((c def c (c (? . 0) q exported-nominal-module-binding-export-name)) c (? . 53)) ((c def c (c (? . 5) q get-doc-open-url)) q (28942 . 2)) ((c def c (c (? . 0) q struct:toplevel)) c (? . 69)) ((c def c (c (? . 0) q wrapped)) c (? . 32)) ((c def c (c (? . 0) q mark-barrier)) c (? . 7)) ((c def c (c (? . 0) q struct:constructor-shape)) c (? . 59)) ((c def c (c (? . 5) q find-user-links-file)) q (27600 . 3)) ((c def c (c (? . 0) q assign?)) c (? . 47)) ((c def c (c (? . 20) q mzscheme-launcher-is-directory?)) q (18312 . 2)) ((c def c (c (? . 0) q make-lexical-rename)) c (? . 67)) ((c def c (c (? . 0) q varref-dummy)) c (? . 78)) ((c def c (c (? . 0) q free-id-info-path0)) c (? . 4)) ((c def c (c (? . 0) q simple-module-binding-path)) c (? . 55)) ((c def c (c (? . 0) q struct:let-one)) c (? . 6)) ((c def c (c (? . 0) q req?)) c (? . 34)) ((c def c (c (? . 20) q available-mzscheme-variants)) q (20268 . 2)) ((c def c (c (? . 0) q struct:stx)) c (? . 64)) ((c def c (c (? . 20) q mzscheme-launcher-add-suffix)) q (18437 . 3)) ((c def c (c (? . 0) q toplevel-pos)) c (? . 69)) ((c def c (c (? . 71) q get-rendered-doc-directories)) q (34268 . 5)) ((c def c (c (? . 0) q global-bucket)) c (? . 10)) ((c def c (c (? . 20) q gracket-launcher-add-suffix)) q (17017 . 3)) ((c def c (c (? . 8) q file-stamp-in-paths)) q (2212 . 5)) ((c def c (c (? . 0) q topsyntax-pos)) c (? . 21)) ((c def c (c (? . 5) q find-user-include-dir)) q (28414 . 2)) ((c def c (c (? . 74) q short-program+command-name)) q (63290 . 2)) ((c def c (c (? . 5) q find-user-man-dir)) q (28857 . 2)) ((c def c (c (? . 0) q prefix-stxs)) c (? . 37)) ((c def c (c (? . 0) q struct:module-variable)) c (? . 26)) ((c def c (c (? . 0) q struct:beg0)) c (? . 61)) ((c def c (c (? . 0) q assign-id)) c (? . 47)) ((c def c (c (? . 63) q compile-directory-zos)) q (61750 . 16)) ((c def c (c (? . 0) q provided-src-phase)) c (? . 45)) ((c def c (c (? . 5) q get-absolute-installation?)) q (29096 . 2)) ((c def c (c (? . 73) q reindex-user-documentation)) q (26961 . 2)) ((c def c (c (? . 79) q std-filter)) q (57507 . 3)) ((c def c (c (? . 0) q struct:module-rename)) c (? . 43)) ((c def c (c (? . 0) q constructor-shape-arity)) c (? . 59)) ((c sig-val c (c (? . 3) q setup-option^ make-verbose)) q (23011 . 4)) ((c def c (c (? . 5) q find-pkgs-dir)) q (27747 . 2)) ((c def c (c (? . 0) q struct:let-void)) c (? . 44)) ((c def c (c (? . 8) q get-compiled-file-sha1)) q (2416 . 3)) ((c def c (c (? . 0) q mark-barrier-value)) c (? . 7)) ((c def c (c (? . 0) q accessor-shape-field-count)) c (? . 57)) ((c def c (c (? . 80) q collection-name?)) q (32919 . 3)) ((c def c (c (? . 0) q module-rename-mark-renames)) c (? . 43)) ((c def c (c (? . 0) q mutator-shape)) c (? . 72)) ((c def c (c (? . 0) q phase-shift-amt)) c (? . 27)) ((c def c (c (? . 71) q make-collections-xref)) q (33628 . 13)) ((c def c (c (? . 0) q make-expr)) c (? . 81)) ((c def c (c (? . 20) q racket-program-launcher-path)) q (16597 . 5)) ((c def c (c (? . 0) q struct:exported-nominal-module-binding)) c (? . 53)) ((c def c (c (? . 0) q lexical-rename-bool2)) c (? . 67)) ((c def c (c (? . 0) q compilation-top)) c (? . 40)) ((c def c (c (? . 0) q struct:def-syntaxes)) c (? . 35)) ((c def c (c (? . 20) q gracket-launcher-up-to-date?)) q (19202 . 4)) ((c def c (c (? . 0) q free-id-info-path1)) c (? . 4)) ((c def c (c (? . 0) q free-id-info-phase0)) c (? . 4)) ((c def c (c (? . 0) q beg0?)) c (? . 61)) ((q def ((lib "setup/setup.rkt") setup)) q (21155 . 32)) ((c def c (c (? . 0) q nominal-module-binding)) c (? . 77)) ((c def c (c (? . 83) q get-compilation-bytecode-file)) q (6651 . 9)) ((c def c (c (? . 0) q make-exported-nominal-module-binding)) c (? . 53)) ((c def c (c (? . 0) q struct:assign)) c (? . 47)) ((c def c (c (? . 0) q make-application)) c (? . 12)) ((c def c (c (? . 0) q phased-nominal-path-import-phase)) c (? . 15)) ((c def c (c (? . 0) q struct:install-value)) c (? . 14)) ((c def c (c (? . 0) q phased-module-binding?)) c (? . 39)) ((c def c (c (? . 5) q find-user-doc-dir)) q (27985 . 2)) ((c def c (c (? . 8) q manager-compile-notify-handler)) q (1602 . 4)) ((c def c (c (? . 0) q struct:phase-shift)) c (? . 27)) ((c def c (c (? . 0) q module-rename-renames)) c (? . 43)) ((c def c (c (? . 82) q path->module-path)) q (30981 . 5)) ((c def c (c (? . 0) q free-id-info-phase2)) c (? . 4)) ((c def c (c (? . 20) q make-mred-launcher)) q (15095 . 5)) ((c def c (c (? . 0) q make-let-void)) c (? . 44)) ((c def c (c (? . 0) q function-shape)) c (? . 42)) ((c def c (c (? . 8) q managed-compiled-context-key)) q (868 . 2)) ((c def c (c (? . 0) q phased-module-binding-path)) c (? . 39)) ((c def c (c (? . 0) q application)) c (? . 12)) ((c def c (c (? . 0) q toplevel-ready?)) c (? . 69)) ((c def c (c (? . 0) q make-provided)) c (? . 45)) ((c def c (c (? . 0) q exported-module-binding-export-name)) c (? . 25)) ((c def c (c (? . 0) q make-toplevel)) c (? . 69)) ((c def c (c (? . 56) q embedding-executable-add-suffix)) q (13386 . 5)) ((c def c (c (? . 0) q lam-body)) c (? . 1)) ((c def c (c (? . 0) q struct:provided)) c (? . 45)) ((c def c (c (? . 8) q manager-trace-handler)) q (1759 . 4)) ((c def c (c (? . 20) q mred-launcher-up-to-date?)) q (19933 . 4)) ((c def c (c (? . 0) q def-values?)) c (? . 75)) ((c def c (c (? . 0) q provided-nom-src)) c (? . 45)) ((c def c (c (? . 0) q def-syntaxes-ids)) c (? . 35)) ((c def c (c (? . 0) q make-nominal-module-binding)) c (? . 77)) ((c def c (c (? . 0) q free-id-info-use-current-inspector?)) c (? . 4)) ((c def c (c (? . 2) q make-directory-record)) c (? . 23)) ((c def c (c (? . 20) q mzscheme-program-launcher-path)) q (18132 . 5)) ((c def c (c (? . 0) q mod-pre-submodules)) c (? . 11)) ((c def c (c (? . 0) q primval)) c (? . 38)) ((c def c (c (? . 5) q find-doc-dir)) q (27937 . 2)) ((c def c (c (? . 5) q find-lib-dir)) q (28079 . 2)) ((c def c (c (? . 83) q get-compilation-dir)) q (6247 . 9)) ((c sig-val c (c (? . 3) q setup-option^ force-unpacks)) q (24681 . 4)) ((c def c (c (? . 0) q struct:nominal-module-binding)) c (? . 77)) ((c def c (c (? . 0) q mod-provides)) c (? . 11)) ((c def c (c (? . 0) q provided?)) c (? . 45)) ((c def c (c (? . 0) q install-value-body)) c (? . 14)) ((c def c (c (? . 0) q nominal-module-binding-path)) c (? . 77)) ((c def c (c (? . 0) q def-syntaxes-dummy)) c (? . 35)) ((c def c (c (? . 0) q mod)) c (? . 11)) ((c def c (c (? . 0) q mod-unexported)) c (? . 11)) ((c def c (c (? . 0) q lam-flags)) c (? . 1)) ((c def c (c (? . 0) q module-rename)) c (? . 43)) ((c sig-val c (c (? . 3) q setup-option^ make-tidy)) q (24102 . 4)) ((c def c (c (? . 20) q current-launcher-variant)) q (19689 . 4)) ((c def c (c (? . 0) q toplevel-depth)) c (? . 69)) ((c def c (c (? . 0) q make-inline-variant)) c (? . 49)) ((c sig-val c (c (? . 3) q setup-option^ make-launchers)) q (23554 . 4)) ((c def c (c (? . 20) q make-racket-program-launcher)) q (14361 . 7)) ((c def c (c (? . 0) q topsyntax)) c (? . 21)) ((c def c (c (? . 0) q def-syntaxes-rhs)) c (? . 35)) ((c def c (c (? . 5) q find-apps-dir)) q (28718 . 2)) ((c sig-val c (c (? . 3) q setup-option^ make-zo)) q (23380 . 4)) ((c def c (c (? . 0) q prefix-num-lifts)) c (? . 37)) ((c def c (c (? . 0) q let-one?)) c (? . 6)) ((c def c (c (? . 20) q mzscheme-launcher-is-actually-directory?)) q (18370 . 2)) ((c def c (c (? . 0) q struct:simple-nominal-path)) c (? . 17)) ((c def c (c (? . 0) q function-shape-preserves-marks?)) c (? . 42)) ((c def c (c (? . 0) q expr)) c (? . 81)) ((c def c (c (? . 0) q install-value)) c (? . 14)) ((c def c (c (? . 0) q make-varref)) c (? . 78)) ((c def c (c (? . 0) q inline-variant-inline)) c (? . 49)) ((c def c (c (? . 0) q toplevel?)) c (? . 69)) ((c def c (c (? . 88) q matching-platform?)) q (33111 . 9)) ((c def c (c (? . 5) q get-installation-name)) q (28996 . 2)) ((c def c (c (? . 89) q parallel-compile-files)) q (3687 . 14)) ((q def ((lib "setup/setup-unit.rkt") setup@)) q (22739 . 2)) ((c def c (c (? . 2) q directory-record-path)) c (? . 23)) ((c def c (c (? . 0) q struct-type-shape-field-count)) c (? . 30)) ((c def c (c (? . 8) q with-compile-output)) q (2495 . 4)) ((c def c (c (? . 0) q struct-shape?)) c (? . 68)) ((c def c (c (? . 2) q get-info/full)) q (29470 . 9)) ((c def c (c (? . 5) q find-dll-dir)) q (28221 . 2)) ((c def c (c (? . 0) q module-variable-phase)) c (? . 26)) ((c def c (c (? . 0) q struct:varref)) c (? . 78)) ((q def ((lib "compiler/xform.rkt") xform)) q (60290 . 11)) ((c def c (c (? . 0) q application-rands)) c (? . 12)) ((c def c (c (? . 0) q case-lam-clauses)) c (? . 58)) ((c def c (c (? . 0) q let-void?)) c (? . 44)) ((c def c (c (? . 20) q extract-aux-from-path)) q (19583 . 3)) ((c def c (c (? . 0) q wrap)) c (? . 65)) ((c def c (c (? . 0) q def-values-ids)) c (? . 75)) ((c def c (c (? . 0) q make-case-lam)) c (? . 58)) ((c def c (c (? . 0) q struct-shape)) c (? . 68)) ((c def c (c (? . 5) q find-man-dir)) q (28809 . 2)) ((c def c (c (? . 5) q find-user-gui-bin-dir)) q (28673 . 2)) ((c def c (c (? . 0) q phase-shift?)) c (? . 27)) ((c def c (c (? . 0) q struct:mod)) c (? . 11)) ((c def c (c (? . 0) q with-cont-mark-body)) c (? . 33)) ((c def c (c (? . 0) q lexical-rename?)) c (? . 67)) ((c def c (c (? . 0) q make-boxenv)) c (? . 41)) ((c def c (c (? . 5) q find-user-collects-dir)) q (27343 . 2)) ((c def c (c (? . 0) q localref?)) c (? . 54)) ((c def c (c (? . 82) q collects-relative->path)) q (30768 . 5)) ((c def c (c (? . 0) q mod-syntax-bodies)) c (? . 11)) ((c def c (c (? . 0) q exported-module-binding?)) c (? . 25)) ((c def c (c (? . 83) q get-compilation-dir+name)) q (5821 . 9)) ((c def c (c (? . 0) q lam-toplevel-map)) c (? . 1)) ((c sig-val c (c (? . 3) q setup-option^ make-docs)) q (23742 . 4)) ((c def c (c (? . 2) q directory-record-syms)) c (? . 23)) ((c def c (c (? . 0) q let-void-count)) c (? . 44)) ((c def c (c (? . 0) q wrap?)) c (? . 65)) ((c def c (c (? . 0) q struct:splice)) c (? . 36)) ((c def c (c (? . 2) q directory-record?)) c (? . 23)) ((c def c (c (? . 0) q install-value-rhs)) c (? . 14)) ((c def c (c (? . 0) q seq-forms)) c (? . 19)) ((c sig-val c (c (? . 3) q setup-option^ parallel-workers)) q (24464 . 4)) ((c def c (c (? . 0) q phased-nominal-path-phase)) c (? . 15)) ((c def c (c (? . 0) q module-rename-unmarshals)) c (? . 43)) ((c def c (c (? . 84) q fold-plt-archive)) q (58916 . 29)) ((c def c (c (? . 0) q accessor-shape)) c (? . 57)) ((c def c (c (? . 20) q available-racket-variants)) q (19872 . 2)) ((c def c (c (? . 85) q bundle-directory)) q (20828 . 5)) ((c def c (c (? . 0) q wrapped-wraps)) c (? . 32)) ((c def c (c (? . 0) q make-function-shape)) c (? . 42)) ((c def c (c (? . 0) q make-let-rec)) c (? . 50)) ((c def c (c (? . 79) q pack-collections)) q (54419 . 15)) ((c def c (c (? . 0) q struct:let-rec)) c (? . 50)) ((c def c (c (? . 0) q make-top-level-rename)) c (? . 46)) ((c def c (c (? . 86) q register-external-module)) q (5273 . 5)) ((c def c (c (? . 0) q lam-closure-map)) c (? . 1)) ((c def c (c (? . 71) q doc-state-changed?)) q (34487 . 3)) ((c def c (c (? . 0) q top-level-rename?)) c (? . 46)) ((c form c (c (? . 87) q compiler:option^)) q (63059 . 2)) ((c def c (c (? . 0) q seq-for-syntax)) c (? . 22)) ((c def c (c (? . 0) q mark-barrier?)) c (? . 7)) ((c def c (c (? . 0) q with-cont-mark-key)) c (? . 33)) ((c def c (c (? . 0) q struct:simple-module-binding)) c (? . 55)) ((c def c (c (? . 0) q make-module-rename)) c (? . 43)) ((c def c (c (? . 0) q req-reqs)) c (? . 34)) ((c def c (c (? . 20) q available-gracket-variants)) q (19810 . 2)) ((c def c (c (? . 0) q inline-variant)) c (? . 49)) ((c def c (c (? . 0) q struct:phased-module-binding)) c (? . 39)) ((c def c (c (? . 0) q struct:expr)) c (? . 81)) ((c def c (c (? . 0) q make-mutator-shape)) c (? . 72)) ((c def c (c (? . 20) q gracket-launcher-is-directory?)) q (16773 . 2)) ((c def c (c (? . 0) q all-from-module-context)) c (? . 16)) ((c def c (c (? . 0) q make-stx)) c (? . 64)) ((c def c (c (? . 71) q doc-state?)) q (34572 . 3)) ((c def c (c (? . 0) q varref-toplevel)) c (? . 78)) ((c def c (c (? . 20) q racket-launcher-up-to-date?)) q (19341 . 4)) ((c def c (c (? . 63) q current-compiler-dynamic-require-wrapper)) q (62536 . 5)) ((c def c (c (? . 0) q topsyntax-depth)) c (? . 21)) ((c def c (c (? . 0) q make-localref)) c (? . 54)) ((c def c (c (? . 76) q somewhat-verbose)) q (62718 . 4)) ((c def c (c (? . 0) q struct:exported-module-binding)) c (? . 25)) ((c def c (c (? . 0) q branch-then)) c (? . 13)) ((c def c (c (? . 20) q install-racket-program-launcher)) q (14850 . 7)) ((c def c (c (? . 0) q make-free-id-info)) c (? . 4)) ((c def c (c (? . 0) q branch-test)) c (? . 13)) ((c def c (c (? . 0) q compilation-top?)) c (? . 40)) ((c def c (c (? . 20) q gracket-launcher-is-actually-directory?)) q (16886 . 2)) ((c def c (c (? . 0) q struct:apply-values)) c (? . 66)) ((c def c (c (? . 79) q pack-collections-plt)) q (53453 . 19)) ((c def c (c (? . 20) q racket-launcher-put-file-extension+style+filters)) q (17385 . 5)) ((c def c (c (? . 5) q find-user-lib-dir)) q (28127 . 2)) ((c def c (c (? . 5) q find-user-share-dir)) q (28319 . 2)) ((c def c (c (? . 0) q make-constructor-shape)) c (? . 59)) ((c def c (c (? . 0) q all-from-module-src-phase)) c (? . 16)) ((c def c (c (? . 0) q make-struct-type-shape)) c (? . 30)) ((c def c (c (? . 0) q def-values)) c (? . 75)) ((c def c (c (? . 0) q apply-values)) c (? . 66)) ((c def c (c (? . 0) q all-from-module)) c (? . 16)) ((c sig-val c (c (? . 3) q setup-option^ pause-on-errors)) q (24370 . 4)) ((c def c (c (? . 0) q imported-nominal-path-value)) c (? . 9)) ((c def c (c (? . 0) q seq-for-syntax-dummy)) c (? . 22)) ((c def c (c (? . 0) q phased-nominal-path?)) c (? . 15)) ((c def c (c (? . 20) q gracket-program-launcher-path)) q (16419 . 5)) ((c def c (c (? . 0) q make-prefix)) c (? . 37)) ((c def c (c (? . 88) q platform-spec?)) q (33051 . 3)) ((c def c (c (? . 79) q mztar)) q (57570 . 11)) ((c def c (c (? . 0) q stx?)) c (? . 64)) ((c def c (c (? . 0) q phased-module-binding-phase)) c (? . 39)) ((c def c (c (? . 2) q find-relevant-directory-records)) q (29991 . 5)) ((c def c (c (? . 89) q parallel-compile)) q (4305 . 17)) ((c def c (c (? . 0) q apply-values-proc)) c (? . 66)) ((c def c (c (? . 0) q varref?)) c (? . 78)) ((c def c (c (? . 8) q compile-lock->parallel-lock-client)) q (3410 . 6)) ((c def c (c (? . 0) q struct:branch)) c (? . 13)) ((c def c (c (? . 0) q struct:case-lam)) c (? . 58)) ((c def c (c (? . 0) q localref-unbox?)) c (? . 54)) ((c def c (c (? . 0) q make-nominal-path)) c (? . 18)) ((c def c (c (? . 79) q pack)) q (56558 . 26)) ((c def c (c (? . 0) q mod-internal-context)) c (? . 11))))
procedure
(make-compilation-manager-load/use-compiled-handler                                           
                                                    [delete-zos-when-rkt-file-does-not-exist? 
                                                     #:security-guard security-guard])        
 -> (path? (or/c symbol? false/c) . -> . any)
  delete-zos-when-rkt-file-does-not-exist? : any/c = #f
  security-guard : (or/c security-guard? #f) = #f
procedure
(managed-compile-zo  file                                  
                    [read-src-syntax                       
                     #:security-guard security-guard]) -> void?
  file : path-string?
  read-src-syntax : (any/c input-port? . -> . syntax?)
                  = read-syntax
  security-guard : (or/c security-guard? #f) = #f
value
managed-compiled-context-key : any/c
procedure
(make-compilation-context-error-display-handler orig-handlers)
 -> (string? any/c . -> . void?)
  orig-handlers : (string? any/c . -> . void?)
parameter
(trust-existing-zos) -> boolean?
(trust-existing-zos trust?) -> void?
  trust? : any/c
procedure
(make-caching-managed-compile-zo                                    
                                 [read-src-syntax                   
                                  #:security-guard security-guard]) 
 -> (path-string? . -> . void?)
  read-src-syntax : (any/c input-port? . -> . syntax?)
                  = read-syntax
  security-guard : (or/c security-guard? #f) = #f
parameter
(manager-compile-notify-handler) -> (path? . -> . any)
(manager-compile-notify-handler notify) -> void?
  notify : (path? . -> . any)
parameter
(manager-trace-handler) -> (string? . -> . any)
(manager-trace-handler notify) -> void?
  notify : (string? . -> . any)
parameter
(manager-skip-file-handler)
 -> (-> path? (or/c (cons/c number? promise?) #f))
(manager-skip-file-handler proc) -> void?
  proc : (-> path? (or/c (cons/c number? promise?) #f))
procedure
(file-stamp-in-collection p)
 -> (or/c (cons/c number? promise?) #f)
  p : path?
procedure
(file-stamp-in-paths p paths)
 -> (or/c (cons/c number? promise?) #f)
  p : path?
  paths : (listof path?)
procedure
(get-file-sha1 p) -> (or/c string? #f)
  p : path?
procedure
(get-compiled-file-sha1 p) -> (or/c string? #f)
  p : path?
procedure
(with-compile-output p proc) -> any
  p : path-string?
  proc : ([port input-port?] [tmp-path path?]  . -> . any)
parameter
(parallel-lock-client)
 -> (or/c #f
          (->i ([command (or/c 'lock 'unlock)]
                [file bytes?])
               [res (command) (if (eq? command 'lock)
                                  boolean?
                                  void?)]))
(parallel-lock-client proc) -> void?
  proc : (or/c #f
               (->i ([command (or/c 'lock 'unlock)]
                     [file bytes?])
                    [res (command) (if (eq? command 'lock)
                                       boolean?
                                       void?)]))
procedure
(compile-lock->parallel-lock-client  pc     
                                    [cust]) 
 -> (-> (or/c 'lock 'unlock) bytes? boolean?)
  pc : place-channel?
  cust : (or/c #f custodian?) = #f
procedure
(make-compile-lock) -> place-channel?
procedure
(parallel-compile-files  list-of-files               
                        [#:worker-count worker-count 
                         #:handler handler])         
 -> (or/c void? #f)
  list-of-files : (listof path-string?)
  worker-count : exact-positive-integer? = (processor-count)
  handler : (->i ([worker-id exact-integer?] = void
                  [handler-type symbol?]
                  [path path-string?]
                  [msg string?]
                  [out string?]
                  [err string?])
                 void?)
procedure
(parallel-compile worker-count       
                  setup-fprintf      
                  append-error       
                  collects-tree) -> (void)
  worker-count : non-negative-integer?
  setup-fprintf : (->i ([stage string?] [format string?])
                       ()
                       #:rest (listof any/c) void)
  append-error : (->i ([cc cc?]
                       [prefix string?]
                       [exn (or/c exn? (cons/c string? string?) #f)]
                       [out string?]
                       [err srtring?]
                       [message string?])
                      void?)
  collects-tree : (listof any/c)
procedure
(register-external-file  file                        
                        [#:indirect? indirect?]) -> void?
  file : (and path? complete-path?)
  indirect? : any/c = #f
procedure
(register-external-module  file                        
                          [#:indirect? indirect?]) -> void?
  file : (and path? complete-path?)
  indirect? : any/c = #f
procedure
(compile-file src [dest filter]) -> path?
  src : path-string?
  dest : path-string?
       = (let-values ([(base name dir?) (split-path src)])
           (build-path base "compiled"
                       (path-add-suffix name #".zo")))
  filter : (any/c . -> . any/c) = values
procedure
(get-compilation-dir+name  path                
                          [#:modes modes       
                           #:roots roots]) -> path? path?
  path : path-string?
  modes : (non-empty-listof (and/c path-string? relative-path?))
        = (use-compiled-file-paths)
  roots : (non-empty-listof (or/c path-string? 'same))
        = (current-compiled-file-roots)
procedure
(get-compilation-dir  path                
                     [#:modes modes       
                      #:roots roots]) -> path?
  path : path-string?
  modes : (non-empty-listof (and/c path-string? relative-path?))
        = (use-compiled-file-paths)
  roots : (non-empty-listof (or/c path-string? 'same))
        = (current-compiled-file-roots)
procedure
(get-compilation-bytecode-file  path                
                               [#:modes modes       
                                #:roots roots]) -> path?
  path : path-string?
  modes : (non-empty-listof (and/c path-string? relative-path?))
        = (use-compiled-file-paths)
  roots : (non-empty-listof (or/c path-string? 'same))
        = (current-compiled-file-roots)
procedure
(create-embedding-executable                                                  
                              dest                                            
                              #:modules mod-list                              
                             [#:early-literal-expressions early-literal-sexps 
                              #:configure-via-first-module? config-via-first? 
                              #:literal-files literal-files                   
                              #:literal-expression literal-sexp               
                              #:literal-expressions literal-sexps             
                              #:cmdline cmdline                               
                              #:gracket? gracket?                             
                              #:mred? mred?                                   
                              #:variant variant                               
                              #:aux aux                                       
                              #:collects-path collects-path                   
                              #:collects-dest collects-dest                   
                              #:launcher? launcher?                           
                              #:verbose? verbose?                             
                              #:expand-namespace expand-namespace             
                              #:compiler compile-proc                         
                              #:src-filter src-filter                         
                              #:on-extension ext-proc                         
                              #:get-extra-imports extras-proc])               
 -> void?
  dest : path-string?
  mod-list : (listof (or/c (list/c (or/c symbol? (one-of/c #t #f))
                                   (or/c module-path? path?))
                           (list/c (or/c symbol? (one-of/c #t #f))
                                   (or/c module-path? path?)
                                   (listof symbol?))))
  early-literal-sexps : list? = null
  config-via-first? : any/c = #f
  literal-files : (listof path-string?) = null
  literal-sexp : any/c = #f
  literal-sexps : list? = (if literal-sexp
                              (list literal-sexp)
                              null)
  cmdline : (listof string?) = null
  gracket? : any/c = #f
  mred? : any/c = #f
  variant : (or/c 'cgc '3m) = (system-type 'gc)
  aux : (listof (cons/c symbol? any/c)) = null
  collects-path : (or/c #f                     = #f
                        path-string?
                        (listof path-string?))
  collects-dest : (or/c #f path-string?) = #f
  launcher? : any/c = #f
  verbose? : any/c = #f
  expand-namespace : namespace? = (current-namespace)
  compile-proc : (any/c . -> . compiled-expression?)
               = (lambda (e)
                   (parameterize ([current-namespace
                                   expand-namespace])
                     (compile e)))
  src-filter : (path? . -> . any) = (lambda (p) #t)
  ext-proc : (or/c #f (path-string? boolean? . -> . any)) = #f
  extras-proc : (path? compiled-module-expression?
                 . -> . (listof module-path?))
              = (lambda (p m) null)
procedure
(make-embedding-executable  dest                
                            mred?               
                            verbose?            
                            mod-list            
                            literal-files       
                            literal-sexp        
                            cmdline             
                           [aux                 
                            launcher?           
                            variant             
                            collects-path]) -> void?
  dest : path-string?
  mred? : any/c
  verbose? : any/c
  mod-list : (listof (or/c (list/c (or/c symbol? (one-of/c #t #f))
                                   (or/c module-path? path?))
                           (list/c (or/c symbol? (one-of/c #t #f))
                                   (or/c module-path? path?)
                                   (listof symbol?))))
  literal-files : (listof path-string?)
  literal-sexp : any/c
  cmdline : (listof string?)
  aux : (listof (cons/c symbol? any/c)) = null
  launcher? : any/c = #f
  variant : (one-of/c 'cgc '3m) = (system-type 'gc)
  collects-path : (or/c #f                     = #f
                        path-string?
                        (listof path-string?))
procedure
(write-module-bundle verbose?          
                     mod-list          
                     literal-files     
                     literal-sexp) -> void?
  verbose? : any/c
  mod-list : (listof (or/c (list/c (or/c symbol? (one-of/c #t #f))
                                   (or/c module-path? path?))
                           (list/c (or/c symbol? (one-of/c #t #f))
                                   (or/c module-path? path?)
                                   (listof symbol?))))
  literal-files : (listof path-string?)
  literal-sexp : any/c
procedure
(embedding-executable-is-directory? mred?) -> boolean
  mred? : any/c
procedure
(embedding-executable-is-actually-directory? mred?) -> boolean?
  mred? : any/c
procedure
(embedding-executable-put-file-extension+style+filters mred?)
 -> (or/c string? false/c)
    (listof (one-of/c 'packages 'enter-packages))
    (listof (list/c string? string?))
  mred? : any/c
procedure
(embedding-executable-add-suffix path       
                                 mred?) -> path-string?
  path : path-string?
  mred? : any/c
signature
compiler:embed^ : signature
value
compiler:embed@ : unit?
procedure
(find-exe [gracket? variant]) -> path?
  gracket? : any/c = #f
  variant : (or/c 'cgc '3m) = (system-type 'gc)
procedure
(make-gracket-launcher args dest [aux]) -> void?
  args : (listof string?)
  dest : path-string?
  aux : (listof (cons/c symbol? any/c)) = null
procedure
(make-racket-launcher args dest [aux]) -> void?
  args : (listof string?)
  dest : path-string?
  aux : (listof (cons/c symbol? any/c)) = null
procedure
(make-gracket-program-launcher file           
                               collection     
                               dest)      -> void?
  file : string?
  collection : string?
  dest : path-string?
procedure
(make-racket-program-launcher file           
                              collection     
                              dest)      -> void?
  file : string?
  collection : string?
  dest : path-string?
procedure
(install-gracket-program-launcher file           
                                  collection     
                                  name)      -> void?
  file : string?
  collection : string?
  name : string?
procedure
(install-racket-program-launcher file           
                                 collection     
                                 name)      -> void?
  file : string?
  collection : string?
  name : string?
procedure
(make-mred-launcher args dest [aux]) -> void?
  args : (listof string?)
  dest : path-string?
  aux : (listof (cons/c symbol? any/c)) = null
procedure
(make-mred-program-launcher file           
                            collection     
                            dest)      -> void?
  file : string?
  collection : string?
  dest : path-string?
procedure
(install-mred-program-launcher file           
                               collection     
                               name)      -> void?
  file : string?
  collection : string?
  name : string?
procedure
(make-mzscheme-launcher args dest [aux]) -> void?
  args : (listof string?)
  dest : path-string?
  aux : (listof (cons/c symbol? any/c)) = null
procedure
(make-mzscheme-program-launcher file           
                                collection     
                                dest)      -> void?
  file : string?
  collection : string?
  dest : path-string?
procedure
(install-mzscheme-program-launcher file           
                                   collection     
                                   name)      -> void?
  file : string?
  collection : string?
  name : string?
procedure
(gracket-program-launcher-path  name                
                               [#:user? user?]) -> path?
  name : string?
  user? : any/c = #f
procedure
(racket-program-launcher-path  name                
                              [#:user? user?]) -> path?
  name : string?
  user? : any/c = #f
procedure
(gracket-launcher-is-directory?) -> boolean?
procedure
(racket-launcher-is-directory?) -> boolean?
procedure
(gracket-launcher-is-actually-directory?) -> boolean?
procedure
(racket-launcher-is-actually-directory?) -> boolean?
procedure
(gracket-launcher-add-suffix path-string?) -> path?
  path-string? : path
procedure
(racket-launcher-add-suffix path-string?) -> path?
  path-string? : path
procedure
(gracket-launcher-put-file-extension+style+filters)
 -> (or/c string? false/c)
    (listof (one-of/c 'packages 'enter-packages))
    (listof (list/c string? string?))
procedure
(racket-launcher-put-file-extension+style+filters)
 -> (or/c string? false/c)
    (listof (one-of/c 'packages 'enter-packages))
    (listof (list/c string? string?))
procedure
(mred-program-launcher-path  name                
                            [#:user? user?]) -> path?
  name : string?
  user? : any/c = #f
procedure
(mred-launcher-is-directory?) -> boolean?
procedure
(mred-launcher-is-actually-directory?) -> boolean?
procedure
(mred-launcher-add-suffix path-string?) -> path?
  path-string? : path
procedure
(mred-launcher-put-file-extension+style+filters)
 -> (or/c string? false/c)
    (listof (one-of/c 'packages 'enter-packages))
    (listof (list/c string? string?))
procedure
(mzscheme-program-launcher-path  name                
                                [#:user? user?]) -> path?
  name : string?
  user? : any/c = #f
procedure
(mzscheme-launcher-is-directory?) -> boolean?
procedure
(mzscheme-launcher-is-actually-directory?) -> boolean?
procedure
(mzscheme-launcher-add-suffix path-string?) -> path?
  path-string? : path
procedure
(mzscheme-launcher-put-file-extension+style+filters)
 -> (or/c string? false/c)
    (listof (one-of/c 'packages 'enter-packages))
    (listof (list/c string? string?))
procedure
(installed-executable-path->desktop-path exec-path 
                                         user?)    
 -> (and/c path? complete-path?)
  exec-path : path-string?
  user? : any/c
procedure
(installed-desktop-path->icon-path desktop-path 
                                   user?        
                                   suffix)      
 -> (and/c path? complete-path?)
  desktop-path : path-string?
  user? : any/c
  suffix : bytes?
procedure
(gracket-launcher-up-to-date? dest aux) -> boolean?
  dest : path-string?
  aux : (listof (cons/c symbol? any/c))
procedure
(racket-launcher-up-to-date? dest aux) -> boolean?
  dest : path-string?
  aux : (listof (cons/c symbol? any/c))
procedure
(build-aux-from-path path) -> (listof (cons/c symbol? any/c))
  path : path-string?
procedure
(extract-aux-from-path path) -> (listof (cons/c symbol? any/c))
  path : path-string?
parameter
(current-launcher-variant) -> symbol?
(current-launcher-variant variant) -> void?
  variant : symbol?
procedure
(available-gracket-variants) -> (listof symbol?)
procedure
(available-racket-variants) -> (listof symbol?)
procedure
(mred-launcher-up-to-date? dest aux) -> boolean?
  dest : path-string?
  aux : (listof (cons/c symbol? any/c))
procedure
(mzscheme-launcher-up-to-date? dest aux) -> boolean?
  dest : path-string?
  aux : (listof (cons/c symbol? any/c))
procedure
(available-mred-variants) -> (listof symbol?)
procedure
(available-mzscheme-variants) -> (listof symbol?)
signature
launcher^ : signature
value
launcher@ : unit?
procedure
(assemble-distribution  dest-dir                   
                        exec-files                 
                       [#:collects-path path       
                        #:copy-collects dirs]) -> void?
  dest-dir : path-string?
  exec-files : (listof path-string?)
  path : (or/c false/c (and/c path-string? relative-path?)) = #f
  dirs : (listof path-string?) = null
procedure
(bundle-directory dist-file dir [for-exe?]) -> void?
  dist-file : file-path?
  dir : file-path?
  for-exe? : any/c = #f
procedure
(bundle-put-file-extension+style+filters)
 -> (or/c string? false/c)
    (listof (one-of/c 'packages 'enter-packages))
    (listof (list/c string? string?))
procedure
(setup [#:file file                             
        #:collections collections               
        #:planet-specs planet-specs             
        #:make-user? make-user?                 
        #:avoid-main? avoid-main?               
        #:make-docs? make-docs?                 
        #:make-doc-index? make-doc-index?       
        #:force-user-docs? force-user-docs?     
        #:clean? clean?                         
        #:tidy? tidy?                           
        #:jobs jobs                             
        #:fail-fast? fail-fast?                 
        #:get-target-dir get-target-dir])   -> boolean?
  file : (or/c #f path-string?) = #f
  collections : (or/c #f (listof (listof path-string?))) = #f
  planet-specs : (or/c #f
                       (listof (list/c string?
                                       string?
                                       exact-nonnegative-integer?
                                       exact-nonnegative-integer?)))
               = #f
  make-user? : any/c = #t
  avoid-main? : any/c = #f
  make-docs? : any/c = #t
  make-doc-index? : any/c = #f
  force-user-docs? : any/c = #f
  clean? : any/c = #f
  tidy? : any/c = #f
  jobs : exact-nonnegative-integer? = #f
  fail-fast? : any/c = #f
  get-target-dir : (or/c #f (-> path-string?)) = #f
value
setup@ : unit?
value
setup:option@ : unit?
signature
setup-option^ : signature
parameter
(setup-program-name) -> string?
(setup-program-name name) -> void?
  name : string?
parameter
(verbose) -> boolean?
(verbose on?) -> void?
  on? : any/c
parameter
(make-verbose) -> boolean?
(make-verbose on?) -> void?
  on? : any/c
parameter
(compiler-verbose) -> boolean?
(compiler-verbose on?) -> void?
  on? : any/c
parameter
(clean) -> boolean?
(clean on?) -> void?
  on? : any/c
parameter
(compile-mode) -> (or/c path? #f)
(compile-mode path) -> void?
  path : (or/c path? #f)
parameter
(make-zo) -> boolean?
(make-zo on?) -> void?
  on? : any/c
parameter
(make-info-domain) -> boolean?
(make-info-domain on?) -> void?
  on? : any/c
parameter
(make-launchers) -> boolean?
(make-launchers on?) -> void?
  on? : any/c
parameter
(make-foreign-lib) -> boolean?
(make-foreign-lib on?) -> void?
  on? : any/c
parameter
(make-docs) -> boolean?
(make-docs on?) -> void?
  on? : any/c
parameter
(make-user) -> boolean?
(make-user on?) -> void?
  on? : any/c
parameter
(make-planet) -> boolean?
(make-planet on?) -> void?
  on? : any/c
parameter
(avoid-main-installation) -> boolean?
(avoid-main-installation on?) -> void?
  on? : any/c
parameter
(make-tidy) -> boolean?
(make-tidy on?) -> void?
  on? : any/c
parameter
(call-install) -> boolean?
(call-install on?) -> void?
  on? : any/c
parameter
(call-post-install) -> boolean?
(call-post-install on?) -> void?
  on? : any/c
parameter
(pause-on-errors) -> boolean?
(pause-on-errors on?) -> void?
  on? : any/c
parameter
(parallel-workers) -> exact-nonnegative-integer?
(parallel-workers num) -> void?
  num : exact-nonnegative-integer?
parameter
(fail-fast) -> boolean?
(fail-fast on?) -> void?
  on? : any/c
parameter
(force-unpacks) -> boolean?
(force-unpacks on?) -> void?
  on? : any/c
parameter
(specific-collections) -> (listof (listof path-string?))
(specific-collections colls) -> void?
  colls : (listof (listof path-string?))
parameter
(specific-planet-dirs)
 -> (listof (list/c string?
                    string?
                    exact-nonnegative-integer?
                    exact-nonnegative-integer?))
(specific-planet-dirs dir) -> void?
  dir : (listof (list/c string?
                        string?
                        exact-nonnegative-integer?
                        exact-nonnegative-integer?))
parameter
(make-only) -> boolean?
(make-only on?) -> void?
  on? : any/c
parameter
(archives) -> (listof path-string?)
(archives arch) -> void?
  arch : (listof path-string?)
parameter
(archive-implies-reindex) -> boolean?
(archive-implies-reindex on?) -> void?
  on? : any/c
parameter
(current-target-directory-getter) -> (-> path-string?)
(current-target-directory-getter thunk) -> void?
  thunk : (-> path-string?)
parameter
(current-target-plt-directory-getter)
 -> (path-string?
     path-string?
     (listof path-string?) . -> . path-string?)
(current-target-plt-directory-getter proc) -> void?
  proc : (path-string?
          path-string?
          (listof path-string?) . -> . path-string?)
procedure
(run-single-installer                                                      
                       file                                                
                       get-dir-proc                                        
                      [#:show-beginning-of-file? show-beginning-of-file?]) 
 -> void?
  file : path-string?
  get-dir-proc : (-> (or/c path-string? #f))
  show-beginning-of-file? : any/c = #f
procedure
(install-planet-package file directory spec) -> void?
  file : path-string?
  directory : path-string?
  spec : (list/c string? string?
                 (listof string?)
                 exact-nonnegative-integer?
                 exact-nonnegative-integer?)
procedure
(reindex-user-documentation) -> void?
procedure
(clean-planet-package directory spec) -> void?
  directory : path-string?
  spec : (list/c string? string?
                 (listof string?)
                 exact-nonnegative-integer?
                 exact-nonnegative-integer?)
procedure
(find-collects-dir) -> (or/c path? #f)
procedure
(find-user-collects-dir) -> path?
procedure
(get-collects-search-dirs) -> (listof path?)
procedure
(get-main-collects-search-dirs) -> (listof path?)
procedure
(find-config-dir) -> (or/c path? #f)
procedure
(find-links-file) -> path?
procedure
(find-user-links-file [vers]) -> path?
  vers : string? = (get-installation-name)
procedure
(get-links-search-files) -> path?
procedure
(find-pkgs-dir) -> path?
procedure
(find-user-pkgs-dir [vers]) -> path?
  vers : string? = (get-installation-name)
procedure
(get-pkgs-search-dirs) -> (listof path?)
procedure
(find-doc-dir) -> (or/c path? #f)
procedure
(find-user-doc-dir) -> path?
procedure
(get-doc-search-dirs) -> (listof path?)
procedure
(find-lib-dir) -> (or/c path? #f)
procedure
(find-user-lib-dir) -> path?
procedure
(get-lib-search-dirs) -> (listof path?)
procedure
(find-dll-dir) -> (or/c path? #f)
procedure
(find-share-dir) -> (or/c path? #f)
procedure
(find-user-share-dir) -> path?
procedure
(find-include-dir) -> (or/c path? #f)
procedure
(find-user-include-dir) -> path?
procedure
(get-include-search-dirs) -> (listof path?)
procedure
(find-console-bin-dir) -> (or/c path? #f)
procedure
(find-gui-bin-dir) -> (or/c path? #f)
procedure
(find-user-console-bin-dir) -> path?
procedure
(find-user-gui-bin-dir) -> path?
procedure
(find-apps-dir) -> (or/c path? #f)
procedure
(find-user-apps-dir) -> path?
procedure
(find-man-dir) -> (or/c path? #f)
procedure
(find-user-man-dir) -> path?
procedure
(get-doc-search-url) -> string?
procedure
(get-doc-open-url) -> (or/c string? #f)
procedure
(get-installation-name) -> string?
procedure
(get-build-stamp) -> (or/c #f string?)
procedure
(get-absolute-installation?) -> boolean?
procedure
(get-info  collection-names          
          [#:namespace namespace     
           #:bootstrap? bootstrap?]) 
 -> (or/c
     (symbol? [(-> any)] . -> . any)
     #f)
  collection-names : (listof string?)
  namespace : (or/c namespace? #f) = #f
  bootstrap? : any/c = #f
procedure
(get-info/full  path                      
               [#:namespace namespace     
                #:bootstrap? bootstrap?]) 
 -> (or/c (->* (symbol?) ((-> any)) any)
          #f)
  path : path-string?
  namespace : (or/c namespace? #f) = #f
  bootstrap? : any/c = #f
procedure
(find-relevant-directories syms [mode]) -> (listof path?)
  syms : (listof symbol?)
  mode : (or/c 'preferred 'all-available 'no-planet 'no-user)
       = 'preferred
procedure
(find-relevant-directory-records syms key)
 -> (listof directory-record?)
  syms : (listof symbol?)
  key : (or/c 'preferred 'all-available)
struct
(struct directory-record (maj min spec path syms)
    #:extra-constructor-name make-directory-record)
  maj : integer?
  min : integer?
  spec : any/c
  path : path?
  syms : (listof symbol?)
procedure
(reset-relevant-directories-state!) -> void?
procedure
(path->collects-relative path           
                         #:cache cache) 
 -> (or/c path-string?
          (cons/c 'collects
                  (cons/c bytes? (non-empty-listof bytes?))))
  path : path-string?
  cache : (or/c #f (and/c hash? (not/c immutable?)))
procedure
(collects-relative->path rel) -> path-string?
  rel : (or/c path-string?
              (cons/c 'collects
                      (cons/c bytes? (non-empty-listof bytes?))))
procedure
(path->module-path path #:cache cache)
 -> (or/c path-string? module-path?)
  path : path-string?
  cache : (or/c #f (and/c hash? (not/c imutable?)))
procedure
(path->main-collects-relative path)
 -> (or/c path? (cons/c 'collects (non-empty-listof bytes?)))
  path : (or/c bytes? path-string?)
procedure
(main-collects-relative->path rel) -> path>
  rel : (or/c bytes?
              path-string?
              (cons/c 'collects (non-empty-listof bytes?)))
procedure
(path->main-doc-relative path)
 -> (or/c path? (cons/c 'doc (non-empty-listof bytes?)))
  path : (or/c bytes? path-string?)
procedure
(main-doc-relative->path rel) -> path>
  rel : (or/c bytes?
              path-string?
              (cons/c 'doc (non-empty-listof bytes?)))
procedure
(path->relative-string/library  path                
                               [default             
                                #:cache cache]) -> any/c
  path : path-string?
  default : (or/c (-> path-string? any/c) any/c)
          = (lambda (x) (if (path? x) (path->string x) x))
  cache : (or/c #f (and/c hash? (not/c immutable?))) = #f
procedure
(path->relative-string/setup  path                
                             [default             
                              #:cache cache]) -> any/c
  path : path-string?
  default : (or/c (-> path-string? any/c) any/c)
          = (lambda (x) (if (path? x) (path->string x) x))
  cache : (or/c #f (and/c hash? (not/c immutable?))) = #f
procedure
(make-path->relative-string dirs [default])
 -> (path-string? any/c . -> . any)
  dirs : (listof (cons (-> path?) string?))
  default : (or/c (-> path-string? any/c) any/c)
          = (lambda (x) (if (path? x) (path->string x) x))
procedure
(collection-name? v) -> boolean?
  v : any/c
procedure
(collection-name-element? v) -> boolean?
  v : any/c
procedure
(platform-spec? v) -> boolean?
  v : any/c
procedure
(matching-platform?  spec                                       
                    [#:system-type sys-type                     
                     #:system-library-subpath sys-lib-subpath]) 
 -> boolean?
  spec : platform-spec?
  sys-type : (or/c #f symbol?) = (system-type)
  sys-lib-subpath : (or/c #f path?)
                  = (system-library-subpath #f)
procedure
(load-collections-xref [on-load]) -> xref?
  on-load : (-> any/c) = (lambda () (void))
procedure
(make-collections-xref                                            
                       [#:no-user? no-user?                       
                        #:no-main? no-main?                       
                        #:doc-db db-path                          
                        #:quiet-fail? quiet-fail?                 
                        #:register-shutdown! register-shutdown!]) 
 -> xref?
  no-user? : any/c = #f
  no-main? : any/c = #f
  db-path : (or/c #f path?) = #f
  quiet-fail? : any/c = #f
  register-shutdown! : ((-> any) . -> . any) = void
procedure
(get-rendered-doc-directories no-user?      
                              no-main?) -> (listof path?)
  no-user? : any/c
  no-main? : any/c
procedure
(get-current-doc-state) -> doc-state?
procedure
(doc-state-changed? doc-state) -> boolean?
  doc-state : doc-state?
procedure
(doc-state? v) -> boolean?
  v : any/c
procedure
(materialize-user-docs [on-setup]) -> void?
  on-setup : ((-> boolean?) -> any) = (lambda (setup) (setup))
procedure
(decompile top) -> any/c
  top : compilation-top?
procedure
(zo-parse [in]) -> compilation-top?
  in : input-port? = (current-input-port)
procedure
(zo-marshal-to top out) -> void?
  top : compilation-top?
  out : output-port?
procedure
(zo-marshal top) -> bytes?
  top : compilation-top?
struct
(struct zo ()
    #:extra-constructor-name make-zo
    #:prefab)
struct
(struct compilation-top zo (max-let-depth prefix code)
    #:extra-constructor-name make-compilation-top
    #:prefab)
  max-let-depth : exact-nonnegative-integer?
  prefix : prefix?
  code : (or/c form? any/c)
struct
(struct prefix zo (num-lifts toplevels stxs)
    #:extra-constructor-name make-prefix
    #:prefab)
  num-lifts : exact-nonnegative-integer?
  toplevels : (listof (or/c #f symbol? global-bucket?
                            module-variable?))
  stxs : (listof stx?)
struct
(struct global-bucket zo (name)
    #:extra-constructor-name make-global-bucket
    #:prefab)
  name : symbol?
struct
(struct module-variable zo (modidx sym pos phase constantness)
    #:extra-constructor-name make-module-variable
    #:prefab)
  modidx : module-path-index?
  sym : symbol?
  pos : exact-integer?
  phase : exact-nonnegative-integer?
  constantness : (or/c #f 'constant 'fixed
                       function-shape? struct-shape?)
struct
(struct function-shape (arity preserves-marks?)
    #:extra-constructor-name make-function-shape
    #:prefab)
  arity : procedure-arity?
  preserves-marks? : boolean?
struct
(struct struct-shape ()
    #:extra-constructor-name make-struct-shape
    #:prefab)
struct
(struct struct-type-shape struct-shape (field-count)
    #:extra-constructor-name make-struct-type-shape
    #:prefab)
  field-count : exact-nonnegative-integer?
struct
(struct constructor-shape struct-shape (arity)
    #:extra-constructor-name make-constructor-shape
    #:prefab)
  arity : exact-nonnegative-integer?
struct
(struct predicate-shape struct-shape ()
    #:extra-constructor-name make-predicate-shape
    #:prefab)
struct
(struct accessor-shape struct-shape (field-count)
    #:extra-constructor-name make-accessor-shape
    #:prefab)
  field-count : exact-nonnegative-integer?
struct
(struct mutator-shape struct-shape (field-count)
    #:extra-constructor-name make-mutator-shape
    #:prefab)
  field-count : exact-nonnegative-integer?
struct
(struct struct-other-shape struct-shape ()
    #:extra-constructor-name make-struct-other-shape
    #:prefab)
struct
(struct stx zo (encoded)
    #:extra-constructor-name make-stx
    #:prefab)
  encoded : wrapped?
struct
(struct form zo ()
    #:extra-constructor-name make-form
    #:prefab)
struct
(struct def-values form (ids rhs)
    #:extra-constructor-name make-def-values
    #:prefab)
  ids : (listof toplevel?)
  rhs : (or/c expr? seq? inline-variant? any/c)
struct
(struct def-syntaxes form (ids rhs prefix max-let-depth dummy)
    #:extra-constructor-name make-def-syntaxes
    #:prefab)
  ids : (listof symbol?)
  rhs : (or/c expr? seq? any/c)
  prefix : prefix?
  max-let-depth : exact-nonnegative-integer?
  dummy : (or/c toplevel? #f)
struct
(struct seq-for-syntax form (forms prefix max-let-depth dummy)
    #:extra-constructor-name make-seq-for-syntax
    #:prefab)
  forms : (listof (or/c form? any/c))
  prefix : prefix?
  max-let-depth : exact-nonnegative-integer?
  dummy : (or/c toplevel? #f)
struct
(struct req form (reqs dummy)
    #:extra-constructor-name make-req
    #:prefab)
  reqs : stx?
  dummy : toplevel?
struct
(struct seq form (forms)
    #:extra-constructor-name make-seq
    #:prefab)
  forms : (listof (or/c form? any/c))
struct
(struct splice form (forms)
    #:extra-constructor-name make-splice
    #:prefab)
  forms : (listof (or/c form? any/c))
struct
(struct inline-variant form (direct inline)
    #:extra-constructor-name make-inline-variant
    #:prefab)
  direct : expr?
  inline : expr?
struct
(struct mod form (name
                  srcname
                  self-modidx
                  prefix
                  provides
                  requires
                  body
                  syntax-bodies
                  unexported
                  max-let-depth
                  dummy
                  lang-info
                  internal-context
                  flags
                  pre-submodules
                  post-submodules)
    #:extra-constructor-name make-mod
    #:prefab)
  name : (or/c symbol? (listof symbol?))
  srcname : symbol?
  self-modidx : module-path-index?
  prefix : prefix?
  provides : (listof (list/c (or/c exact-integer? #f)
                             (listof provided?)
                             (listof provided?)))
  requires : (listof (cons/c (or/c exact-integer? #f)
                             (listof module-path-index?)))
  body : (listof (or/c form? any/c))
  syntax-bodies : (listof (cons/c exact-positive-integer?
                                  (listof (or/c def-syntaxes?
                                                seq-for-syntax?))))
  unexported : (listof (list/c exact-nonnegative-integer?
                               (listof symbol?)
                               (listof symbol?)))
  max-let-depth : exact-nonnegative-integer?
  dummy : toplevel?
  lang-info : (or/c #f (vector/c module-path? symbol? any/c))
  internal-context : (or/c #f #t stx? (vectorof stx?))
  flags : (listof (or/c 'cross-phase))
  pre-submodules : (listof mod?)
  post-submodules : (listof mod?)
struct
(struct provided (name src src-name nom-src src-phase protected?)
    #:extra-constructor-name make-provided
    #:prefab)
  name : symbol?
  src : (or/c module-path-index? #f)
  src-name : symbol?
  nom-src : (or/c module-path-index? #f)
  src-phase : exact-nonnegative-integer?
  protected? : boolean?
struct
(struct expr form ()
    #:extra-constructor-name make-expr
    #:prefab)
struct
(struct lam expr (name
                  flags
                  num-params
                  param-types
                  rest?
                  closure-map
                  closure-types
                  toplevel-map
                  max-let-depth
                  body)
    #:extra-constructor-name make-lam
    #:prefab)
  name : (or/c symbol? vector?)
  flags : (listof (or/c 'preserves-marks 'is-method 'single-result
                        'only-rest-arg-not-used 'sfs-clear-rest-args))
  num-params : exact-nonnegative-integer?
  param-types : (listof (or/c 'val 'ref 'flonum 'fixnum 'extflonum))
  rest? : boolean?
  closure-map : (vectorof exact-nonnegative-integer?)
  closure-types : (listof (or/c 'val/ref 'flonum 'fixnum 'extflonum))
  toplevel-map : (or/c #f (set/c exact-nonnegative-integer?))
  max-let-depth : exact-nonnegative-integer?
  body : (or/c expr? seq? any/c)
struct
(struct closure expr (code gen-id)
    #:extra-constructor-name make-closure
    #:prefab)
  code : lam?
  gen-id : symbol?
struct
(struct case-lam expr (name clauses)
    #:extra-constructor-name make-case-lam
    #:prefab)
  name : (or/c symbol? vector?)
  clauses : (listof lam?)
struct
(struct let-one expr (rhs body type unused?)
    #:extra-constructor-name make-let-one
    #:prefab)
  rhs : (or/c expr? seq? any/c)
  body : (or/c expr? seq? any/c)
  type : (or/c #f 'flonum 'fixnum 'extflonum)
  unused? : boolean?
struct
(struct let-void expr (count boxes? body)
    #:extra-constructor-name make-let-void
    #:prefab)
  count : exact-nonnegative-integer?
  boxes? : boolean?
  body : (or/c expr? seq? any/c)
struct
(struct install-value expr (count pos boxes? rhs body)
    #:extra-constructor-name make-install-value
    #:prefab)
  count : exact-nonnegative-integer?
  pos : exact-nonnegative-integer?
  boxes? : boolean?
  rhs : (or/c expr? seq? any/c)
  body : (or/c expr? seq? any/c)
struct
(struct let-rec expr (procs body)
    #:extra-constructor-name make-let-rec
    #:prefab)
  procs : (listof lam?)
  body : (or/c expr? seq? any/c)
struct
(struct boxenv expr (pos body)
    #:extra-constructor-name make-boxenv
    #:prefab)
  pos : exact-nonnegative-integer?
  body : (or/c expr? seq? any/c)
struct
(struct localref expr (unbox? pos clear? other-clears? type)
    #:extra-constructor-name make-localref
    #:prefab)
  unbox? : boolean?
  pos : exact-nonnegative-integer?
  clear? : boolean?
  other-clears? : boolean?
  type : (or/c #f 'flonum 'fixnum 'extflonum)
struct
(struct toplevel expr (depth pos const? ready?)
    #:extra-constructor-name make-toplevel
    #:prefab)
  depth : exact-nonnegative-integer?
  pos : exact-nonnegative-integer?
  const? : boolean?
  ready? : boolean?
struct
(struct topsyntax expr (depth pos midpt)
    #:extra-constructor-name make-topsyntax
    #:prefab)
  depth : exact-nonnegative-integer?
  pos : exact-nonnegative-integer?
  midpt : exact-nonnegative-integer?
struct
(struct application expr (rator rands)
    #:extra-constructor-name make-application
    #:prefab)
  rator : (or/c expr? seq? any/c)
  rands : (listof (or/c expr? seq? any/c))
struct
(struct branch expr (test then else)
    #:extra-constructor-name make-branch
    #:prefab)
  test : (or/c expr? seq? any/c)
  then : (or/c expr? seq? any/c)
  else : (or/c expr? seq? any/c)
struct
(struct with-cont-mark expr (key val body)
    #:extra-constructor-name make-with-cont-mark
    #:prefab)
  key : (or/c expr? seq? any/c)
  val : (or/c expr? seq? any/c)
  body : (or/c expr? seq? any/c)
struct
(struct beg0 expr (seq)
    #:extra-constructor-name make-beg0
    #:prefab)
  seq : (listof (or/c expr? seq? any/c))
struct
(struct varref expr (toplevel dummy)
    #:extra-constructor-name make-varref
    #:prefab)
  toplevel : (or/c toplevel? #t)
  dummy : (or/c toplevel? #f)
struct
(struct assign expr (id rhs undef-ok?)
    #:extra-constructor-name make-assign
    #:prefab)
  id : toplevel?
  rhs : (or/c expr? seq? any/c)
  undef-ok? : boolean?
struct
(struct apply-values expr (proc args-expr)
    #:extra-constructor-name make-apply-values
    #:prefab)
  proc : (or/c expr? seq? any/c)
  args-expr : (or/c expr? seq? any/c)
struct
(struct primval expr (id)
    #:extra-constructor-name make-primval
    #:prefab)
  id : exact-nonnegative-integer?
struct
(struct wrapped zo (datum wraps tamper-status)
    #:extra-constructor-name make-wrapped
    #:prefab)
  datum : any/c
  wraps : (listof wrap?)
  tamper-status : (or/c 'clean 'armed 'tainted)
struct
(struct wrap zo ()
    #:extra-constructor-name make-wrap
    #:prefab)
struct
(struct top-level-rename wrap (flag)
    #:extra-constructor-name make-top-level-rename
    #:prefab)
  flag : boolean?
struct
(struct mark-barrier wrap (value)
    #:extra-constructor-name make-mark-barrier
    #:prefab)
  value : symbol?
struct
(struct free-id-info zo (path0
                         symbol0
                         path1
                         symbol1
                         phase0
                         phase1
                         phase2
                         use-current-inspector?)
    #:extra-constructor-name make-free-id-info
    #:prefab)
  path0 : module-path-index?
  symbol0 : symbol?
  path1 : module-path-index?
  symbol1 : symbol?
  phase0 : (or/c exact-integer? #f)
  phase1 : (or/c exact-integer? #f)
  phase2 : (or/c exact-integer? #f)
  use-current-inspector? : boolean?
struct
(struct lexical-rename wrap (has-free-id-info? bool2 alist)
    #:extra-constructor-name make-lexical-rename
    #:prefab)
  has-free-id-info? : boolean?
  bool2 : boolean?
  alist : (listof
           (cons/c symbol?
                   (or/c symbol?
                         (cons/c symbol?
                                 (or/c (cons/c symbol? (or/c symbol? #f))
                                       free-id-info?)))))
struct
(struct phase-shift wrap (amt src dest cancel-id)
    #:extra-constructor-name make-phase-shift
    #:prefab)
  amt : (or/c exact-integer? #f)
  src : module-path-index?
  dest : module-path-index?
  cancel-id : (or/c exact-integer? #f)
struct
(struct module-rename wrap (phase
                            kind
                            set-id
                            unmarshals
                            renames
                            mark-renames
                            plus-kern?)
    #:extra-constructor-name make-module-rename
    #:prefab)
  phase : exact-integer?
  kind : (or/c 'marked 'normal)
  set-id : any/c
  unmarshals : (listof make-all-from-module?)
  renames : (listof module-binding?)
  mark-renames : any/c
  plus-kern? : boolean?
struct
(struct all-from-module zo (path
                            phase
                            src-phase
                            exceptions
                            prefix
                            context)
    #:extra-constructor-name make-all-from-module
    #:prefab)
  path : module-path-index?
  phase : (or/c exact-integer? #f)
  src-phase : (or/c exact-integer? #f)
  exceptions : (listof symbol?)
  prefix : (or/c symbol? #f)
  context : (or/c (listof exact-integer?)
                  (vector/c (listof exact-integer?) any/c)
                  #f)
struct
(struct module-binding zo ()
    #:extra-constructor-name make-module-binding
    #:prefab)
struct
(struct simple-module-binding module-binding (path)
    #:extra-constructor-name make-simple-module-binding
    #:prefab)
  path : module-path-index?
struct
(struct phased-module-binding module-binding (path
                                              phase
                                              export-name
                                              nominal-path
                                              nominal-export-name)
    #:extra-constructor-name make-phased-module-binding
    #:prefab)
  path : module-path-index?
  phase : exact-integer?
  export-name : any/c
  nominal-path : nominal-path?
  nominal-export-name : any/c
struct
(struct exported-nominal-module-binding module-binding (path
                                                        export-name
                                                        nominal-path
                                                        nominal-export-name)
    #:extra-constructor-name make-exported-nominal-module-binding
    #:prefab)
  path : module-path-index?
  export-name : any/c
  nominal-path : nominal-path?
  nominal-export-name : any/c
struct
(struct nominal-module-binding module-binding (path nominal-path)
    #:extra-constructor-name make-nominal-module-binding
    #:prefab)
  path : module-path-index?
  nominal-path : nominal-path?
struct
(struct exported-module-binding module-binding (path export-name)
    #:extra-constructor-name make-exported-module-binding
    #:prefab)
  path : module-path-index?
  export-name : any/c
struct
(struct nominal-path zo ()
    #:extra-constructor-name make-nominal-path
    #:prefab)
struct
(struct simple-nominal-path nominal-path (value)
    #:extra-constructor-name make-simple-nominal-path
    #:prefab)
  value : module-path-index?
struct
(struct imported-nominal-path nominal-path (value import-phase)
    #:extra-constructor-name make-imported-nominal-path
    #:prefab)
  value : module-path-index?
  import-phase : exact-integer?
struct
(struct phased-nominal-path nominal-path (value import-phase phase)
    #:extra-constructor-name make-phased-nominal-path
    #:prefab)
  value : module-path-index?
  import-phase : (or/c false/c exact-integer?)
  phase : exact-integer?
procedure
(links  dir                                 
        ...                                 
       [#:user? user?                       
        #:user-version user-version         
        #:file file                         
        #:name name                         
        #:root? root?                       
        #:static-root? static-root?         
        #:version-regexp version-regexp     
        #:error error-proc                  
        #:remove? remove?                   
        #:show? show?                       
        #:repair? repair?                   
        #:with-path? with-path?])       -> list?
  dir : path?
  user? : any/c = #t
  user-version : string? = (get-installation-name)
  file : (or/c path-string? #f) = #f
  name : (or/c string? #f) = #f
  root? : any/c = #f
  static-root? : any/c = #f
  version-regexp : (or/c regexp? #f) = #f
  error-proc : (symbol? string? any/c ... . -> . any) = error
  remove? : any/c = #f
  show? : any/c = #f
  repair? : any/c = #f
  with-path? : any/c = #f
procedure
(pack-collections-plt                                            
                       dest                                      
                       name                                      
                       collections                               
                      [#:replace? replace?                       
                       #:at-plt-home? at-home?                   
                       #:test-plt-collects? test?                
                       #:extra-setup-collections collection-list 
                       #:file-filter filter-proc])               
 -> void?
  dest : path-string?
  name : string?
  collections : (listof (listof path-string?))
  replace? : boolean? = #f
  at-home? : boolean? = #f
  test? : boolean? = #t
  collection-list : (listof path-string?) = null
  filter-proc : (path-string? . -> . boolean?) = std-filter
procedure
(pack-collections  dest                        
                   name                        
                   collections                 
                   replace?                    
                   extra-setup-collections     
                  [filter                      
                   at-plt-home?])          -> void?
  dest : path-string?
  name : string?
  collections : (listof (listof path-string?))
  replace? : boolean?
  extra-setup-collections : (listof path-string?)
  filter : (path-string? . -> . boolean?) = std-filter
  at-plt-home? : boolean? = #f
procedure
(pack-plt  dest                                
           name                                
           paths                               
          [#:as-paths as-paths                 
           #:file-filter filter-proc           
           #:encode? encode?                   
           #:file-mode file-mode-sym           
           #:unpack-unit unpack-spec           
           #:collections collection-list       
           #:plt-relative? plt-relative?       
           #:at-plt-home? at-plt-home?         
           #:test-plt-dirs dirs                
           #:requires mod-and-version-list     
           #:conflicts mod-list])          -> void?
  dest : path-string?
  name : string?
  paths : (listof path-string?)
  as-paths : (listof path-string?) = paths
  filter-proc : (path-string? . -> . boolean?) = std-filter
  encode? : boolean? = #t
  file-mode-sym : symbol? = 'file
  unpack-spec : any/c = #f
  collection-list : (listof path-string?) = null
  plt-relative? : any/c = #f
  at-plt-home? : any/c = #f
  dirs : (or/c (listof path-string?) false/c) = #f
  mod-and-version-list : (listof (listof path-string?)    = null
                                 (listof exact-integer?))
  mod-list : (listof (listof path-string?)) = null
procedure
(pack  dest               
       name               
       paths              
       collections        
      [filter             
       encode?            
       file-mode          
       unpack-unit        
       plt-relative?      
       requires           
       conflicts          
       at-plt-home?]) -> void?
  dest : path-string?
  name : string?
  paths : (listof path-string?)
  collections : (listof path-string?)
  filter : (path-string? . -> . boolean?) = std-filter
  encode? : boolean? = #t
  file-mode : symbol? = 'file
  unpack-unit : any/c = #f
  plt-relative? : boolean? = #t
  requires : (listof (listof path-string?)    = null
                     (listof exact-integer?))
  conflicts : (listof (listof path-string?)) = null
  at-plt-home? : boolean? = #f
procedure
(std-filter p) -> boolean?
  p : path-string?
procedure
(mztar  path                   
       [#:as-path as-path]     
        output                 
        filter                 
        file-mode)         -> void?
  path : path-string?
  as-path : path-string? = path
  output : output-port?
  filter : (path-string? . -> . boolean?)
  file-mode : (symbols 'file 'file-replace)
procedure
(unpack  archive                        
        [main-collects-parent-dir       
         print-status                   
         get-target-directory           
         force?                         
         get-target-plt-directory]) -> void?
  archive : path-string?
  main-collects-parent-dir : path-string? = (current-directory)
  print-status : (string? . -> . any)
               = (lambda (x) (printf "~a\n" x))
  get-target-directory : (-> path-string?)
                       = (lambda () (current-directory))
  force? : any/c = #f
  get-target-plt-directory : (path-string?
                              path-string?
                              (listof path-string?)
                              . -> . path-string?)
                           = (lambda (preferred-dir main-dir options)
                               preferred-dir)
procedure
(fold-plt-archive archive            
                  on-config-fn       
                  on-setup-unit      
                  on-directory       
                  on-file            
                  initial-value) -> any/c
  archive : path-string?
  on-config-fn : (any/c any/c . -> . any/c)
  on-setup-unit : (any/c input-port? any/c . -> . any/c)
  on-directory : ((or/c path-string?
                        (list/c (or/c 'collects 'doc 'lib 'include)
                                path-string?))
                  any/c
                  . -> . any/c)
  on-file : (or/c ((or/c path-string?
                         (list/c (or/c 'collects 'doc 'lib 'include)
                                 path-string?))
                   input-port?
                   any/c
                   . -> . any/c)
                  ((or/c path-string?
                         (list/c (or/c 'collects 'doc 'lib 'include)
                                 path-string?))
                   input-port?
                   (one-of/c 'file 'file-replace)
                   any/c
                   . -> . any/c))
  initial-value : any/c
procedure
(xform  quiet?                          
        input-file                      
        output-file                     
        include-dirs                    
       [#:keep-lines? keep-lines?]) -> any/c
  quiet? : any/c
  input-file : path-string?
  output-file : path-string?
  include-dirs : (listof path-string?)
  keep-lines? : boolean? = #f
procedure
((compile-zos  expr                      
              [#:module? module?         
               #:verbose? verbose?])     
               racket-files              
               dest-dir)             -> void?
  expr : any/c
  module? : any/c = #f
  verbose? : any/c = #f
  racket-files : (listof path-string?)
  dest-dir : (or/c path-string? false/c (one-of/c 'auto))
procedure
(compile-collection-zos                                            
                         collection ...+                           
                        [#:skip-path skip-path                     
                         #:skip-doc-sources? skip-docs?            
                         #:managed-compile-zo managed-compile-zo]) 
 -> void?
  collection : string?
  skip-path : (or/c path-string? #f) = #f
  skip-docs? : any/c = #f
  managed-compile-zo : (path-string? . -> . void?)
                     = (make-caching-managed-compile-zo)
procedure
(compile-directory-zos                                            
                        path                                      
                        info                                      
                       [#:verbose verbose?                        
                        #:skip-path skip-path                     
                        #:skip-doc-sources? skip-docs?            
                        #:managed-compile-zo managed-compile-zo]) 
 -> void?
  path : path-string?
  info : ()
  verbose? : any/c = #f
  skip-path : (or/c path-string? #f) = #f
  skip-docs? : any/c = #f
  managed-compile-zo : (path-string? . -> . void?)
                     = (make-caching-managed-compile-zo)
parameter
(current-compiler-dynamic-require-wrapper)
 -> ((-> any) . -> . any)
(current-compiler-dynamic-require-wrapper proc) -> void?
  proc : ((-> any) . -> . any)
parameter
(somewhat-verbose) -> boolean?
(somewhat-verbose on?) -> void?
  on? : any/c
parameter
(verbose) -> boolean?
(verbose on?) -> void?
  on? : any/c
parameter
(compile-subcollections) -> (one-of/c #t #f)
(compile-subcollections cols) -> void?
  cols : (one-of/c #t #f)
signature
compiler^ : signature
signature
compiler:option^ : signature
value
compiler@ : unit?
value
compiler:option@ : unit?
parameter
(current-command-name) -> (or/c string? #f)
(current-command-name name) -> void?
  name : (or/c string? #f)
procedure
(short-program+command-name) -> string?
procedure
(program+command-name) -> string?
