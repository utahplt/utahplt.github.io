163746
((3) 0 () 129 ((q quote #%kernel) (q lib "racket/private/class-internal.rkt") (q lib "racket/private/base.rkt") (q lib "racket/udp.rkt") (q lib "racket/unsafe/ops.rkt") (q lib "racket/dict.rkt") (q lib "racket/sandbox.rkt") (q lib "racket/flonum.rkt") (q 206549 . 9) (q lib "racket/require-transform.rkt") (q lib "racket/port.rkt") (q lib "racket/private/misc.rkt") (q lib "racket/contract/private/misc.rkt") (q lib "racket/set.rkt") (q lib "racket/provide-transform.rkt") (q lib "racket/contract/private/guts.rkt") (q lib "racket/tcp.rkt") (q lib "racket/unit.rkt") (q lib "racket/contract/private/prop.rkt") (q lib "racket/private/more-scheme.rkt") (q lib "racket/extflonum.rkt") (q lib "racket/format.rkt") (q lib "racket/private/list.rkt") (q lib "racket/contract/private/base.rkt") (q lib "racket/contract.rkt") (q 204006 . 4) (q lib "racket/contract/private/blame.rkt") (q 182524 . 4) (q lib "racket/class.rkt") (q lib "racket/future.rkt") (q lib "racket/fixnum.rkt") (q 243475 . 19) (q 384782 . 23) (q lib "racket/private/stxcase-scheme.rkt") (q lib "racket/contract/base.rkt") (q lib "racket/vector.rkt") (q lib "racket/match.rkt") (q lib "racket/runtime-path.rkt") (q lib "racket/private/letstx-scheme.rkt") (q lib "racket/require.rkt") (q lib "racket/generator.rkt") (q lib "racket/control.rkt") (q lib "racket/list.rkt") (q lib "racket/splicing.rkt") (q 203654 . 5) (q 204282 . 4) (q lib "racket/function.rkt") (q lib "racket/place.rkt") (q 206074 . 4) (q lib "racket/file.rkt") (q lib "racket/syntax.rkt") (q lib "racket/sequence.rkt") (q lib "racket/include.rkt") (q lib "racket/path.rkt") (q lib "racket/private/map.rkt") (q 205800 . 4) (q lib "racket/pretty.rkt") (q lib "racket/math.rkt") (q 385442 . 5) (q 202504 . 4) (q lib "racket/trait.rkt") (q lib "racket/system.rkt") (q 204961 . 7) (q 246376 . 8) (q 244169 . 7) (q lib "racket/stream.rkt") (q lib "racket/trace.rkt") (q 202271 . 4) (q 205920 . 5) (q lib "racket/async-channel.rkt") (q lib "racket/promise.rkt") (q lib "racket/struct-info.rkt") (q 337559 . 29) (q 277389 . 29) (q lib "racket/string.rkt") (q lib "racket/stxparam-exptime.rkt") (q 203170 . 5) (q 204414 . 4) (q lib "racket/unsafe/undefined.rkt") (q lib "racket/private/serialize.rkt") (q 206203 . 4) (q lib "racket/contract/private/struct-dc.rkt") (q 204139 . 4) (q 202376 . 4) (q 205180 . 4) (q lib "racket/contract/private/ds.rkt") (q lib "racket/engine.rkt") (q lib "racket/serialize.rkt") (q 347272 . 6) (q 155342 . 3) (q 129763 . 4) (q 205666 . 4) (q 345700 . 5) (q lib "racket/generic.rkt") (q 136756 . 3) (q 205306 . 5) (q lib "racket/bool.rkt") (q 203845 . 5) (q 202827 . 5) (q 203007 . 4) (q lib "racket/contract/private/vector.rkt") (q lib "racket/date.rkt") (q 202081 . 6) (q lib "racket/unit-exptime.rkt") (q lib "racket/private/qqstx.rkt") (q lib "racket/contract/parametric.rkt") (q lib "racket/provide.rkt") (q 202653 . 5) (q 203346 . 5) (q 346066 . 6) (q lib "racket/keyword-transform.rkt") (q lib "racket/contract/private/opt.rkt") (q lib "racket/contract/private/provide.rkt") (q lib "racket/contract/private/hash.rkt") (q 204571 . 4) (q 204730 . 5) (q lib "racket/contract/region.rkt") (q lib "racket/bytes.rkt") (q 205528 . 4) (q lib "racket/cmdline.rkt") (q lib "racket/stxparam.rkt") (q lib "racket/fasl.rkt") (q lib "racket/provide-syntax.rkt") (q lib "racket/performance-hint.rkt") (q lib "racket/require-syntax.rkt") (q lib "racket/contract/private/box.rkt") (q 203507 . 4) (q 339180 . 5) (q lib "racket/enter.rkt")) () (h ! (equal) ((c def c (c (? . 0) q current-load)) q (310883 . 15)) ((c def c (c (? . 1) q equal<%>)) q (153034 . 2)) ((c def c (c (? . 0) q bytes?)) q (55326 . 3)) ((c def c (c (? . 4) q unsafe-struct-set!)) q (402287 . 5)) ((c def c (c (? . 53) q normalize-path)) q (352095 . 5)) ((c def c (c (? . 0) q free-identifier=?)) q (232544 . 10)) ((c def c (c (? . 0) q round)) q (20781 . 3)) ((c def c (c (? . 0) q print-as-expression)) q (295693 . 4)) ((c def c (c (? . 2) q make-exn:fail:out-of-memory)) c (? . 118)) ((c def c (c (? . 0) q sin)) q (22058 . 3)) ((c def c (c (? . 0) q current-reader-guard)) q (292859 . 4)) ((c def c (c (? . 65) q stream-tail)) q (110171 . 4)) ((c def c (c (? . 0) q make-reader-graph)) q (93279 . 3)) ((c def c (c (? . 12) q continuation-mark-key/c)) q (168035 . 3)) ((c def c (c (? . 0) q symbol?)) q (64996 . 3)) ((q form ((lib "racket/private/define.rkt") define-values-for-syntax)) q (12448 . 2)) ((c def c (c (? . 24) q contract-proc)) q (193510 . 6)) ((c def c (c (? . 51) q sequence-length)) q (108114 . 3)) ((c def c (c (? . 18) q contract-property?)) q (190336 . 3)) ((c def c (c (? . 0) q namespace-base-phase)) q (306180 . 3)) ((c def c (c (? . 10) q port->list)) q (264695 . 4)) ((c form c (c (? . 60) q trait-alias)) q (148296 . 2)) ((c form c (c (? . 19) q log-warning)) q (384074 . 3)) ((c def c (c (? . 0) q srcloc-column)) c (? . 8)) ((c form c (c (? . 1) q inspect)) q (142312 . 2)) ((c def c (c (? . 6) q sandbox-coverage-enabled)) q (341027 . 4)) ((c def c (c (? . 50) q format-id)) q (249874 . 13)) ((c def c (c (? . 13) q set-eqv?)) q (119696 . 3)) ((c def c (c (? . 0) q hash-remove!)) q (102190 . 4)) ((c def c (c (? . 2) q hash-empty?)) q (103213 . 3)) ((c def c (c (? . 3) q udp-multicast-leave-group!)) q (374296 . 7)) ((c def c (c (? . 0) q custodian-shutdown-all)) q (334332 . 3)) ((c def c (c (? . 5) q dict-remove!)) q (112689 . 4)) ((c form c (c (? . 2) q relative-in)) q (4446 . 2)) ((c def c (c (? . 3) q udp-send)) q (369012 . 6)) ((c def c (c (? . 0) q read-accept-compiled)) q (291701 . 4)) ((c def c (c (? . 16) q tcp-listener?)) q (367193 . 3)) ((c form c (c (? . 1) q define/override-final)) q (143902 . 3)) ((c def c (c (? . 0) q set-mcdr!)) q (94269 . 4)) ((c def c (c (? . 9) q make-require-transformer)) q (243113 . 5)) ((c def c (c (? . 4) q unsafe-fxabs)) q (394799 . 3)) ((c def c (c (? . 5) q dict-key-contract)) q (115432 . 3)) ((c def c (c (? . 26) q exn:fail:contract:blame-object)) c (? . 27)) ((c def c (c (? . 14) q provide-pre-transformer?)) q (246306 . 3)) ((c form c (c (? . 37) q define-runtime-module-path-index)) q (356793 . 2)) ((c form c (c (? . 2) q struct-out)) q (6102 . 2)) ((c def c (c (? . 0) q filesystem-root-list)) q (356243 . 2)) ((c form c (c (? . 33) q syntax-id-rules)) q (229320 . 3)) ((c def c (c (? . 0) q char-upper-case?)) q (63876 . 3)) ((c form c (c (? . 0) q case-lambda)) q (10325 . 6)) ((c form c (c (? . 23) q invariant-assertion)) q (176414 . 2)) ((c def c (c (? . 2) q exn:fail:filesystem)) c (? . 45)) ((c def c (c (? . 0) q string-titlecase)) q (42941 . 3)) ((c def c (c (? . 4) q unsafe-vector*-set!)) q (400174 . 5)) ((c def c (c (? . 2) q syntax-recertify)) q (232072 . 9)) ((c def c (c (? . 7) q fllog)) q (29699 . 3)) ((c def c (c (? . 0) q current-namespace)) q (305996 . 4)) ((c def c (c (? . 6) q exn:fail:sandbox-terminated?)) c (? . 127)) ((c def c (c (? . 0) q nack-guard-evt)) q (217585 . 3)) ((c def c (c (? . 11) q path-string?)) q (347493 . 3)) ((c def c (c (? . 2) q raise-arity-error)) q (199912 . 9)) ((c def c (c (? . 28) q make-mixin-contract)) q (152688 . 3)) ((c form c (c (? . 2) q for*/fold/derived)) q (15692 . 4)) ((c form c (c (? . 38) q or)) q (11758 . 2)) ((c def c (c (? . 29) q future?)) q (223416 . 3)) ((c def c (c (? . 7) q flabs)) q (28603 . 3)) ((c def c (c (? . 0) q char-ready?)) q (286897 . 3)) ((c form c (c (? . 85) q define-contract-struct)) q (174585 . 2)) ((c def c (c (? . 46) q arity=?)) q (131543 . 4)) ((c def c (c (? . 0) q syntax-local-module-required-identifiers)) q (242553 . 7)) ((c def c (c (? . 0) q current-module-declare-source)) q (316355 . 5)) ((c def c (c (? . 0) q make-resolved-module-path)) q (314839 . 7)) ((c def c (c (? . 7) q fl>)) q (28799 . 4)) ((c def c (c (? . 0) q srcloc-position)) c (? . 8)) ((c def c (c (? . 15) q has-contract?)) q (191549 . 3)) ((c def c (c (? . 2) q chaperone-procedure)) q (326863 . 11)) ((c def c (c (? . 0) q syntax-local-lift-require)) q (240568 . 5)) ((c def c (c (? . 0) q caaaar)) q (87611 . 3)) ((c form c (c (? . 17) q tag)) q (157744 . 3)) ((c def c (c (? . 9) q import-orig-stx)) c (? . 31)) ((c def c (c (? . 57) q order-of-magnitude)) q (28113 . 3)) ((c def c (c (? . 0) q make-pipe)) q (259379 . 6)) ((c def c (c (? . 0) q current-input-port)) q (252432 . 4)) ((c def c (c (? . 9) q import-source)) c (? . 64)) ((c def c (c (? . 10) q make-input-port/read-to-peek)) q (266692 . 50)) ((c form c (c (? . 1) q rename-super)) q (143049 . 2)) ((c def c (c (? . 11) q println)) q (294169 . 5)) ((c def c (c (? . 12) q make-none/c)) q (191829 . 3)) ((c def c (c (? . 2) q in-sequences)) q (106669 . 3)) ((c def c (c (? . 0) q even?)) q (19268 . 3)) ((c def c (c (? . 5) q dict-keys)) q (114946 . 3)) ((c def c (c (? . 5) q dict-values)) q (115004 . 3)) ((c def c (c (? . 0) q parameterization?)) q (223147 . 3)) ((c def c (c (? . 13) q set->stream)) q (123964 . 3)) ((c def c (c (? . 5) q dict-mutable?)) q (111971 . 3)) ((c def c (c (? . 14) q export-local-id)) c (? . 63)) ((c def c (c (? . 0) q cddddr)) q (89111 . 3)) ((c form c (c (? . 36) q define/match)) q (194956 . 18)) ((c def c (c (? . 2) q make-srcloc)) c (? . 8)) ((c def c (c (? . 21) q ~.s)) q (54172 . 23)) ((c def c (c (? . 0) q absolute-path?)) q (349369 . 3)) ((c def c (c (? . 69) q async-channel-put-evt)) q (220487 . 4)) ((c def c (c (? . 0) q random)) q (23654 . 8)) ((c form c (c (? . 15) q define/subexpression-pos-prop)) q (190679 . 6)) ((c def c (c (? . 0) q syntax-rearm)) q (248907 . 5)) ((c def c (c (? . 0) q >)) q (21548 . 4)) ((c def c (c (? . 30) q fx-)) q (32354 . 4)) ((c def c (c (? . 0) q bitwise-bit-set?)) q (23141 . 4)) ((c def c (c (? . 0) q get-output-bytes)) q (258934 . 9)) ((c def c (c (? . 0) q make-struct-field-mutator)) q (134878 . 8)) ((c def c (c (? . 2) q in-input-port-bytes)) q (105356 . 3)) ((c def c (c (? . 0) q read-on-demand-source)) q (292992 . 5)) ((c def c (c (? . 0) q filesystem-change-evt-cancel)) q (356571 . 3)) ((c def c (c (? . 20) q extflacos)) q (36905 . 3)) ((c def c (c (? . 0) q module-provide-protected?)) q (309166 . 5)) ((c def c (c (? . 16) q tcp-addresses)) q (367407 . 7)) ((c def c (c (? . 13) q mutable-seteqv)) q (120323 . 4)) ((c def c (c (? . 56) q pretty-print-handler)) q (297978 . 3)) ((c def c (c (? . 0) q struct-mutator-procedure?)) q (138113 . 3)) ((c form c (c (? . 1) q new)) q (145173 . 2)) ((c form c (c (? . 17) q provide-signature-elements)) q (161246 . 2)) ((c def c (c (? . 0) q simplify-path)) q (350279 . 4)) ((c def c (c (? . 4) q unsafe-fxmodulo)) q (394716 . 4)) ((c def c (c (? . 0) q integer-length)) q (23579 . 3)) ((c def c (c (? . 0) q peek-bytes-avail!/enable-break)) q (284525 . 14)) ((c def c (c (? . 70) q force)) q (207333 . 3)) ((c def c (c (? . 18) q prop:contract)) q (182846 . 2)) ((c def c (c (? . 0) q struct:exn:break:hang-up)) c (? . 48)) ((c def c (c (? . 2) q hash-copy-clear)) q (102620 . 3)) ((c def c (c (? . 16) q tcp-connect)) q (366058 . 9)) ((c def c (c (? . 0) q exn:fail:syntax:missing-module?)) c (? . 44)) ((c def c (c (? . 0) q hash-for-each)) q (103024 . 4)) ((c form c (c (? . 41) q reset-at)) q (211362 . 2)) ((c form c (c (? . 13) q for*/weak-set)) q (122519 . 2)) ((c def c (c (? . 0) q equal-hash-code)) q (103940 . 3)) ((c def c (c (? . 0) q syntax-transforming-module-expression?)) q (241735 . 2)) ((c def c (c (? . 0) q variable-reference->empty-namespace)) q (309537 . 3)) ((c def c (c (? . 3) q udp-send-ready-evt)) q (372441 . 3)) ((c form c (c (? . 0) q quote)) q (9510 . 2)) ((c form c (c (? . 6) q with-deep-time-limit)) q (347220 . 2)) ((c def c (c (? . 7) q flround)) q (29163 . 3)) ((c form c (c (? . 19) q with-handlers)) q (200942 . 3)) ((c def c (c (? . 0) q hash-iterate-key)) q (103521 . 4)) ((c def c (c (? . 20) q ->extfl)) q (37299 . 3)) ((c form c (c (? . 1) q augride*)) q (143379 . 2)) ((c def c (c (? . 0) q exn:fail:user?)) c (? . 55)) ((c def c (c (? . 0) q module-compiled-cross-phase-persistent?)) q (319464 . 4)) ((c def c (c (? . 0) q remainder)) q (20153 . 4)) ((c def c (c (? . 0) q struct-accessor-procedure?)) q (138041 . 3)) ((c def c (c (? . 20) q extflvector-length)) q (37914 . 3)) ((c form c (c (? . 17) q export)) q (157673 . 2)) ((c def c (c (? . 21) q ~a)) q (46089 . 23)) ((c def c (c (? . 22) q assv)) q (86422 . 4)) ((c form c (c (? . 81) q struct/c)) q (165861 . 2)) ((c def c (c (? . 6) q sandbox-output)) q (340069 . 14)) ((c def c (c (? . 0) q split-path)) q (350573 . 5)) ((c def c (c (? . 22) q build-list)) q (83623 . 4)) ((c def c (c (? . 0) q string-foldcase)) q (43014 . 3)) ((c form c (c (? . 39) q matching-identifiers-in)) q (9071 . 2)) ((c form c (c (? . 0) q #%variable-reference)) q (9617 . 4)) ((c def c (c (? . 0) q vector-set!)) q (94874 . 5)) ((c def c (c (? . 0) q string-length)) q (40356 . 3)) ((c form c (c (? . 2) q struct-copy)) q (137552 . 5)) ((c def c (c (? . 7) q flasin)) q (29540 . 3)) ((c form c (c (? . 2) q rename-out)) q (5957 . 2)) ((c def c (c (? . 11) q port?)) q (252116 . 3)) ((c def c (c (? . 20) q extflonum-available?)) q (35386 . 2)) ((c def c (c (? . 34) q predicate/c)) q (174065 . 2)) ((c def c (c (? . 0) q make-derived-parameter)) q (222498 . 7)) ((c form c (c (? . 23) q contract)) q (176770 . 6)) ((c def c (c (? . 24) q raise-contract-error)) q (193135 . 13)) ((c def c (c (? . 0) q current-plumber)) q (337031 . 4)) ((c def c (c (? . 0) q syntax->datum)) q (230450 . 3)) ((c form c (c (? . 17) q prefix)) q (157605 . 2)) ((c def c (c (? . 49) q user-read-bit)) q (365428 . 2)) ((c def c (c (? . 2) q exn:fail:read:eof)) c (? . 25)) ((c def c (c (? . 0) q relative-path?)) q (349473 . 3)) ((c form c (c (? . 52) q include)) q (249569 . 6)) ((c form c (c (? . 17) q import)) q (157635 . 2)) ((c def c (c (? . 5) q in-dict-keys)) q (115183 . 3)) ((c def c (c (? . 12) q contract-projection)) q (191736 . 3)) ((c def c (c (? . 1) q struct:exn:fail:object)) c (? . 89)) ((c form c (c (? . 0) q quote-syntax)) q (16733 . 2)) ((c def c (c (? . 0) q exn:fail:read:eof?)) c (? . 25)) ((c def c (c (? . 47) q place-kill)) q (225526 . 3)) ((c def c (c (? . 2) q open-input-file)) q (254522 . 7)) ((c def c (c (? . 42) q argmin)) q (93065 . 4)) ((c def c (c (? . 0) q current-readtable)) q (292623 . 4)) ((c def c (c (? . 13) q list->weak-set)) q (121403 . 4)) ((c def c (c (? . 0) q flush-output)) q (252981 . 3)) ((c def c (c (? . 0) q print-struct)) q (295099 . 4)) ((c def c (c (? . 13) q set-clear!)) q (124279 . 3)) ((c def c (c (? . 26) q struct:exn:fail:contract:blame)) c (? . 27)) ((c def c (c (? . 11) q rationalize)) q (21238 . 4)) ((c form c (c (? . 17) q unit)) q (155781 . 22)) ((c def c (c (? . 24) q contract-random-generate-fail)) q (194094 . 2)) ((c def c (c (? . 6) q sandbox-make-code-inspector)) q (344390 . 4)) ((c def c (c (? . 28) q implementation?/c)) q (152872 . 3)) ((c def c (c (? . 0) q make-syntax-delta-introducer)) q (241940 . 9)) ((c form c (c (? . 2) q except-in)) q (4263 . 2)) ((c def c (c (? . 10) q reencode-input-port)) q (270546 . 16)) ((c form c (c (? . 1) q inherit-field)) q (142443 . 2)) ((c def c (c (? . 0) q namespace-attach-module)) q (307937 . 7)) ((c def c (c (? . 6) q call-with-trusted-sandbox-configuration)) q (339350 . 3)) ((c def c (c (? . 0) q call-with-current-continuation)) q (208763 . 6)) ((c def c (c (? . 66) q current-trace-notify)) q (409265 . 4)) ((c def c (c (? . 20) q extfl->exact)) q (37499 . 3)) ((c def c (c (? . 0) q hash?)) q (98753 . 3)) ((c form c (c (? . 5) q gen:dict)) q (112167 . 2)) ((c def c (c (? . 0) q syntax-disarm)) q (248791 . 4)) ((c def c (c (? . 29) q fsemaphore-count)) q (223970 . 3)) ((c def c (c (? . 0) q prop:arity-string)) q (130122 . 2)) ((c def c (c (? . 12) q flat-contract?)) q (191300 . 3)) ((c def c (c (? . 1) q make-generic)) q (147029 . 4)) ((c def c (c (? . 5) q make-immutable-custom-hash)) q (118889 . 14)) ((c def c (c (? . 0) q print-boolean-long-form)) q (295467 . 4)) ((c def c (c (? . 0) q progress-evt?)) q (286989 . 6)) ((c def c (c (? . 30) q fx>=)) q (33493 . 4)) ((c def c (c (? . 40) q generator?)) q (111246 . 3)) ((c def c (c (? . 0) q path<?)) q (348348 . 4)) ((c form c (c (? . 28) q class/c)) q (148439 . 28)) ((c def c (c (? . 9) q struct:import)) c (? . 31)) ((c form c (c (? . 1) q class)) q (142236 . 2)) ((c def c (c (? . 10) q peeking-input-port)) q (270111 . 9)) ((c def c (c (? . 2) q regexp-match*)) q (67294 . 20)) ((c def c (c (? . 2) q make-date)) c (? . 32)) ((c form c (c (? . 43) q splicing-letrec-syntaxes+values)) q (247935 . 2)) ((c def c (c (? . 12) q promise/c)) q (168364 . 3)) ((c form c (c (? . 17) q extends)) q (157830 . 2)) ((c def c (c (? . 15) q value-contract)) q (191480 . 3)) ((c def c (c (? . 30) q fxior)) q (32854 . 4)) ((c def c (c (? . 61) q system*/exit-code)) q (378562 . 15)) ((c def c (c (? . 0) q chaperone-of?)) q (321355 . 4)) ((c form c (c (? . 17) q except)) q (157529 . 2)) ((c def c (c (? . 0) q file-or-directory-identity)) q (354944 . 5)) ((c def c (c (? . 0) q date-year)) c (? . 32)) ((c def c (c (? . 0) q mcdr)) q (94149 . 3)) ((c def c (c (? . 0) q namespace-attach-module-declaration)) q (308230 . 7)) ((c def c (c (? . 0) q semaphore-wait/enable-break)) q (219136 . 3)) ((c def c (c (? . 0) q path->bytes)) q (347882 . 3)) ((c def c (c (? . 0) q caaadr)) q (87711 . 3)) ((c def c (c (? . 0) q use-compiled-file-paths)) q (312824 . 5)) ((c def c (c (? . 0) q open-input-string)) q (258579 . 4)) ((c def c (c (? . 35) q vector-split-at-right)) q (97143 . 4)) ((c def c (c (? . 2) q in-producer)) q (106352 . 7)) ((c def c (c (? . 12) q impersonator-contract?)) q (191232 . 3)) ((c def c (c (? . 12) q list*of)) q (165275 . 3)) ((c def c (c (? . 10) q call-with-output-string)) q (265804 . 3)) ((c def c (c (? . 2) q date)) c (? . 32)) ((c def c (c (? . 0) q make-pseudo-random-generator)) q (24102 . 2)) ((c form c (c (? . 33) q with-syntax)) q (228067 . 3)) ((c form c (c (? . 2) q for*/hash)) q (14895 . 2)) ((c def c (c (? . 0) q exn:fail:filesystem:missing-module?)) c (? . 62)) ((c def c (c (? . 0) q exn:break:terminate?)) c (? . 80)) ((c form c (c (? . 34) q ->d)) q (171434 . 34)) ((c def c (c (? . 0) q arity-at-least?)) c (? . 90)) ((c def c (c (? . 35) q vector-copy)) q (97268 . 5)) ((c form c (c (? . 1) q send-generic)) q (146907 . 3)) ((c form c (c (? . 2) q :do-in)) q (16075 . 9)) ((c def c (c (? . 0) q date-day)) c (? . 32)) ((c def c (c (? . 36) q match-equality-test)) q (196572 . 4)) ((c form c (c (? . 37) q define-runtime-path-list)) q (356749 . 2)) ((c def c (c (? . 0) q read-accept-quasiquote)) q (292319 . 4)) ((c def c (c (? . 0) q bytes-convert)) q (60724 . 21)) ((c form c (c (? . 2) q for*/list)) q (14675 . 2)) ((c form c (c (? . 38) q unless)) q (13007 . 2)) ((c def c (c (? . 0) q symbol-interned?)) q (65049 . 3)) ((c def c (c (? . 6) q break-evaluator)) q (345166 . 3)) ((c form c (c (? . 39) q path-up)) q (9229 . 2)) ((c def c (c (? . 11) q getenv)) q (389201 . 3)) ((c form c (c (? . 0) q #%expression)) q (9558 . 2)) ((c def c (c (? . 10) q dup-output-port)) q (272016 . 4)) ((c def c (c (? . 13) q set-map)) q (125555 . 4)) ((c def c (c (? . 33) q syntax-protect)) q (248726 . 3)) ((c def c (c (? . 0) q call-with-immediate-continuation-mark)) q (213889 . 7)) ((c def c (c (? . 4) q unsafe-extflmax)) q (403576 . 4)) ((c form c (c (? . 17) q struct/ctc)) q (160890 . 10)) ((c def c (c (? . 0) q cadaar)) q (88011 . 3)) ((c def c (c (? . 0) q log-all-levels)) q (383668 . 6)) ((c def c (c (? . 4) q unsafe-vector-set!)) q (399849 . 5)) ((c def c (c (? . 16) q tcp-close)) q (367119 . 3)) ((c form c (c (? . 2) q define-struct)) q (132934 . 6)) ((c def c (c (? . 4) q unsafe-flasin)) q (397234 . 3)) ((c def c (c (? . 33) q check-duplicate-identifier)) q (233306 . 3)) ((c def c (c (? . 0) q error-escape-handler)) q (201087 . 4)) ((c form c (c (? . 2) q module+)) q (1769 . 2)) ((c def c (c (? . 30) q fx<=)) q (33420 . 4)) ((c def c (c (? . 3) q udp?)) q (372241 . 3)) ((c def c (c (? . 0) q list->bytes)) q (56921 . 3)) ((c form c (c (? . 87) q serializable-struct/versions)) q (304017 . 7)) ((c form c (c (? . 2) q require)) q (2018 . 51)) ((c form c (c (? . 2) q for*/last)) q (15412 . 2)) ((c def c (c (? . 40) q sequence->generator)) q (111599 . 3)) ((c def c (c (? . 0) q syntax-local-submodules)) q (241387 . 2)) ((c form c (c (? . 41) q cupto)) q (212100 . 2)) ((c def c (c (? . 26) q blame-add-context)) q (181190 . 9)) ((c def c (c (? . 0) q collect-garbage)) q (393815 . 2)) ((c def c (c (? . 0) q cddar)) q (87447 . 3)) ((c def c (c (? . 0) q thread-resume-evt)) q (216253 . 3)) ((c def c (c (? . 6) q call-in-sandbox-context)) q (346571 . 7)) ((c def c (c (? . 41) q new-prompt)) q (212030 . 2)) ((c def c (c (? . 0) q modulo)) q (20332 . 4)) ((c def c (c (? . 0) q exn:fail:contract:arity?)) c (? . 59)) ((c def c (c (? . 0) q raise-user-error)) q (197418 . 10)) ((c def c (c (? . 18) q make-contract)) q (177043 . 23)) ((c def c (c (? . 0) q write-special-avail*)) q (289326 . 4)) ((c def c (c (? . 4) q unsafe-flrandom)) q (398409 . 3)) ((c def c (c (? . 0) q replace-evt)) q (217777 . 4)) ((c form c (c (? . 112) q provide/contract)) q (175422 . 2)) ((c def c (c (? . 0) q prop:input-port)) q (259682 . 2)) ((c def c (c (? . 42) q ninth)) q (89794 . 3)) ((c form c (c (? . 123) q define-inline)) q (16920 . 14)) ((c def c (c (? . 2) q exn:fail:contract:variable)) c (? . 76)) ((c def c (c (? . 2) q make-exn:fail:filesystem:errno)) c (? . 115)) ((c def c (c (? . 0) q port-provides-progress-evts?)) q (286518 . 3)) ((c def c (c (? . 0) q variable-reference->module-source)) q (310011 . 4)) ((c def c (c (? . 12) q listof)) q (165141 . 3)) ((c form c (c (? . 38) q else)) q (11712 . 2)) ((c def c (c (? . 0) q hash-equal?)) q (98804 . 3)) ((c form c (c (? . 43) q splicing-letrec-syntaxes)) q (247903 . 2)) ((c def c (c (? . 0) q delete-file)) q (353546 . 3)) ((c def c (c (? . 0) q make-hasheq)) q (99615 . 3)) ((c def c (c (? . 2) q make-base-empty-namespace)) q (305614 . 2)) ((c def c (c (? . 24) q contract-random-generate/choose)) q (193956 . 4)) ((c def c (c (? . 0) q cdaadr)) q (88511 . 3)) ((c def c (c (? . 0) q continuation-prompt-tag?)) q (210073 . 3)) ((c def c (c (? . 20) q extfl>=)) q (36151 . 4)) ((c form c (c (? . 13) q for/mutable-seteqv)) q (122120 . 2)) ((c def c (c (? . 41) q call/prompt)) q (210350 . 7)) ((c def c (c (? . 4) q unsafe-fx>=)) q (395640 . 4)) ((c def c (c (? . 0) q port-progress-evt)) q (286369 . 4)) ((c def c (c (? . 0) q struct-predicate-procedure?)) q (137968 . 3)) ((c form c (c (? . 13) q for/weak-seteqv)) q (122463 . 2)) ((c def c (c (? . 54) q ormap)) q (84383 . 4)) ((c def c (c (? . 5) q dict-ref!)) q (113639 . 5)) ((c def c (c (? . 0) q exn:fail:syntax:missing-module-path)) c (? . 44)) ((c def c (c (? . 0) q current-pseudo-random-generator)) q (24243 . 4)) ((c form c (c (? . 0) q #%top)) q (9596 . 2)) ((c def c (c (? . 30) q fxvector-ref)) q (34138 . 4)) ((c form c (c (? . 39) q multi-in)) q (9263 . 8)) ((c def c (c (? . 0) q string->keyword)) q (82976 . 3)) ((c def c (c (? . 110) q syntax-procedure-converted-arguments-property)) q (247094 . 8)) ((c def c (c (? . 7) q fl->exact-integer)) q (29988 . 3)) ((c def c (c (? . 2) q make-exn:fail:filesystem)) c (? . 45)) ((c def c (c (? . 71) q struct-auto-info-lists)) q (139085 . 4)) ((c def c (c (? . 0) q random-seed)) q (24015 . 3)) ((c def c (c (? . 13) q set)) q (119966 . 3)) ((c def c (c (? . 0) q primitive-closure?)) q (130685 . 3)) ((c def c (c (? . 46) q normalize-arity)) q (131408 . 4)) ((c def c (c (? . 0) q thread-cell-ref)) q (221777 . 3)) ((c def c (c (? . 0) q filesystem-change-evt?)) q (356297 . 3)) ((c def c (c (? . 0) q read-case-sensitive)) q (291271 . 4)) ((c def c (c (? . 0) q write-bytes-avail*)) q (288405 . 10)) ((c def c (c (? . 0) q semaphore-peek-evt)) q (219217 . 3)) ((c form c (c (? . 2) q struct)) q (131868 . 31)) ((c def c (c (? . 0) q current-thread-group)) q (335623 . 4)) ((c def c (c (? . 42) q take)) q (90087 . 4)) ((c def c (c (? . 42) q filter-map)) q (92245 . 4)) ((c def c (c (? . 0) q internal-definition-context-seal)) q (239138 . 3)) ((c def c (c (? . 0) q environment-variables-copy)) q (389094 . 3)) ((c def c (c (? . 47) q place-break)) q (225580 . 4)) ((c def c (c (? . 12) q =/c)) q (163269 . 3)) ((c form c (c (? . 1) q define/pubment)) q (143568 . 3)) ((c def c (c (? . 2) q exn:break:hang-up)) c (? . 48)) ((c def c (c (? . 0) q cddr)) q (86891 . 3)) ((c def c (c (? . 0) q number->string)) q (24954 . 4)) ((c def c (c (? . 2) q date*)) c (? . 58)) ((c def c (c (? . 0) q read-byte)) q (279208 . 3)) ((c def c (c (? . 49) q call-with-atomic-output-file)) q (361898 . 8)) ((c def c (c (? . 0) q thread-resume)) q (215627 . 4)) ((c form c (c (? . 2) q for-meta)) q (6372 . 2)) ((c def c (c (? . 0) q *)) q (19908 . 3)) ((c form c (c (? . 43) q splicing-let-syntax)) q (247817 . 2)) ((c def c (c (? . 3) q udp-multicast-set-loopback!)) q (374822 . 5)) ((c def c (c (? . 9) q import?)) c (? . 31)) ((c def c (c (? . 0) q char-numeric?)) q (64012 . 3)) ((c def c (c (? . 0) q prop:exn:srclocs)) q (206336 . 2)) ((c def c (c (? . 19) q current-break-parameterization)) q (214556 . 2)) ((c form c (c (? . 1) q instantiate)) q (145223 . 2)) ((c def c (c (? . 4) q unsafe-extfl+)) q (402614 . 4)) ((c form c (c (? . 17) q unit/c)) q (161297 . 5)) ((c def c (c (? . 29) q fsemaphore-wait)) q (223818 . 3)) ((c def c (c (? . 0) q vector-fill!)) q (95245 . 4)) ((c def c (c (? . 0) q exn:fail:syntax?)) c (? . 108)) ((c def c (c (? . 35) q vector-filter)) q (97453 . 4)) ((c def c (c (? . 0) q module->language-info)) q (320367 . 6)) ((c def c (c (? . 1) q writable<%>)) q (153410 . 2)) ((c def c (c (? . 18) q make-flat-contract)) q (179186 . 23)) ((c def c (c (? . 1) q object-or-false=?)) q (153735 . 4)) ((c form c (c (? . 1) q send*)) q (146114 . 5)) ((c def c (c (? . 2) q hash-keys)) q (102800 . 3)) ((c def c (c (? . 0) q vector-ref)) q (94771 . 4)) ((c def c (c (? . 0) q srcloc-line)) c (? . 8)) ((c def c (c (? . 22) q filter)) q (84786 . 4)) ((c def c (c (? . 20) q pi.t)) q (37630 . 2)) ((c def c (c (? . 10) q peek-bytes-evt)) c (? . 73)) ((c def c (c (? . 0) q struct:exn:fail:unsupported)) c (? . 91)) ((c def c (c (? . 20) q extflvector)) q (37714 . 3)) ((c def c (c (? . 0) q syntax-local-lift-module-end-declaration)) q (240479 . 3)) ((c form c (c (? . 105) q parametric->/c)) q (174203 . 2)) ((c def c (c (? . 49) q display-to-file)) q (358339 . 11)) ((c form c (c (? . 36) q match-letrec-values)) q (195920 . 2)) ((c form c (c (? . 50) q with-disappeared-uses)) q (251071 . 4)) ((c def c (c (? . 42) q range)) q (92540 . 7)) ((c def c (c (? . 0) q flonum?)) q (18932 . 3)) ((c def c (c (? . 0) q placeholder?)) q (93339 . 3)) ((c def c (c (? . 0) q exn:fail:contract:divide-by-zero?)) c (? . 107)) ((c def c (c (? . 15) q contract-first-order-passes?)) q (190918 . 4)) ((c def c (c (? . 0) q make-immutable-hasheqv)) q (100213 . 4)) ((c form c (c (? . 12) q any)) q (168353 . 2)) ((c def c (c (? . 1) q dynamic-get-field)) q (146452 . 4)) ((c def c (c (? . 0) q make-continuation-prompt-tag)) q (208532 . 4)) ((c form c (c (? . 28) q object/c)) q (149771 . 11)) ((c form c (c (? . 36) q match)) q (194552 . 6)) ((c def c (c (? . 2) q in-hash-keys)) q (105946 . 3)) ((c form c (c (? . 33) q syntax)) q (228131 . 23)) ((c def c (c (? . 0) q equal?/recur)) q (17674 . 5)) ((c def c (c (? . 4) q unsafe-struct-ref)) q (402206 . 4)) ((c def c (c (? . 26) q make-exn:fail:contract:blame)) c (? . 27)) ((c def c (c (? . 42) q last)) q (89894 . 3)) ((c def c (c (? . 4) q unsafe-fllog)) q (397414 . 3)) ((c def c (c (? . 29) q futures-enabled?)) q (223321 . 2)) ((c form c (c (? . 2) q λ)) q (9907 . 11)) ((c def c (c (? . 13) q mutable-seteq)) q (120426 . 4)) ((c def c (c (? . 0) q prop:equal+hash)) q (17899 . 2)) ((c def c (c (? . 0) q special-comment?)) q (302747 . 3)) ((c def c (c (? . 0) q caar)) q (86699 . 3)) ((c def c (c (? . 51) q sequence-fold)) q (108864 . 5)) ((c def c (c (? . 0) q syntax-local-context)) q (240891 . 3)) ((c form c (c (? . 52) q include/reader)) q (249746 . 2)) ((c def c (c (? . 20) q extfl*)) q (35599 . 4)) ((c def c (c (? . 0) q make-impersonator-property)) q (332881 . 5)) ((c def c (c (? . 6) q make-module-evaluator)) c (? . 72)) ((c form c (c (? . 1) q interface)) q (139216 . 5)) ((c form c (c (? . 33) q quote-syntax/prune)) q (229210 . 2)) ((c def c (c (? . 0) q newline)) q (287370 . 3)) ((c def c (c (? . 0) q string-locale-ci>?)) q (43912 . 4)) ((c form c (c (? . 13) q for*/set)) q (121854 . 2)) ((c def c (c (? . 0) q bytes-open-converter)) q (60496 . 5)) ((c def c (c (? . 6) q call-with-killing-threads)) c (? . 92)) ((c def c (c (? . 0) q vector-copy!)) q (95355 . 11)) ((c form c (c (? . 34) q contract-out)) q (174737 . 20)) ((c def c (c (? . 3) q udp-multicast-join-group!)) q (374034 . 7)) ((c def c (c (? . 0) q cdr)) q (83375 . 3)) ((c form c (c (? . 1) q abstract)) q (142899 . 2)) ((c def c (c (? . 2) q memv)) q (85922 . 4)) ((c def c (c (? . 12) q chaperone-contract?)) q (191167 . 3)) ((c def c (c (? . 0) q regexp-match-peek-positions)) q (72488 . 19)) ((c def c (c (? . 2) q in-range)) q (104125 . 7)) ((c def c (c (? . 53) q shrink-path-wrt)) q (352738 . 4)) ((c def c (c (? . 0) q object-name)) q (336721 . 3)) ((c def c (c (? . 30) q fx<)) q (33276 . 4)) ((c form c (c (? . 1) q define-local-member-name)) q (144626 . 2)) ((c def c (c (? . 0) q char=?)) q (62791 . 4)) ((c def c (c (? . 10) q merge-input)) q (269787 . 5)) ((c def c (c (? . 0) q exact-integer?)) q (18619 . 3)) ((c form c (c (? . 34) q case->)) q (172657 . 9)) ((c def c (c (? . 0) q port-commit-peeked)) q (286599 . 6)) ((c def c (c (? . 0) q terminal-port?)) q (252832 . 3)) ((c def c (c (? . 54) q andmap)) q (84296 . 4)) ((c def c (c (? . 0) q find-system-path)) q (352859 . 3)) ((c def c (c (? . 0) q impersonate-prompt-tag)) q (325474 . 18)) ((c def c (c (? . 0) q current-command-line-arguments)) q (390000 . 4)) ((c def c (c (? . 0) q read-curly-brace-as-paren)) q (291493 . 4)) ((c def c (c (? . 1) q class?)) q (153496 . 3)) ((c def c (c (? . 15) q coerce-flat-contract)) q (180722 . 4)) ((c def c (c (? . 0) q current-evt-pseudo-random-generator)) q (218145 . 5)) ((c def c (c (? . 5) q dict-ref)) q (112225 . 6)) ((c def c (c (? . 0) q impersonator-of?)) q (321270 . 4)) ((c def c (c (? . 0) q struct:exn:fail:user)) c (? . 55)) ((c def c (c (? . 2) q for-clause-syntax-protect)) q (16365 . 3)) ((c def c (c (? . 0) q thread?)) q (215263 . 3)) ((c def c (c (? . 56) q pretty-print-style-table?)) q (298926 . 3)) ((c def c (c (? . 56) q pretty-print-exact-as-decimal)) q (298388 . 4)) ((c def c (c (? . 51) q empty-sequence)) q (108018 . 2)) ((c def c (c (? . 49) q file->string)) q (356984 . 4)) ((c def c (c (? . 47) q place-channel)) q (225696 . 2)) ((c form c (c (? . 19) q case)) q (11781 . 5)) ((c def c (c (? . 1) q externalizable<%>)) q (153333 . 2)) ((c def c (c (? . 30) q fxvector-length)) q (34051 . 3)) ((c def c (c (? . 0) q continuation-mark-set-first)) q (213467 . 10)) ((c def c (c (? . 22) q compose)) q (127632 . 3)) ((c def c (c (? . 57) q pi)) q (27318 . 2)) ((c def c (c (? . 57) q sgn)) q (27537 . 3)) ((c form c (c (? . 6) q with-limits)) q (347045 . 2)) ((c def c (c (? . 13) q in-set)) q (125770 . 3)) ((c def c (c (? . 26) q current-blame-format)) q (182679 . 4)) ((c def c (c (? . 0) q impersonate-continuation-mark-key)) q (326291 . 13)) ((c form c (c (? . 19) q log-info)) q (384150 . 3)) ((c def c (c (? . 101) q current-date)) q (386111 . 2)) ((c form c (c (? . 0) q unquote-splicing)) q (16709 . 2)) ((c def c (c (? . 30) q fxvector-set!)) q (34247 . 5)) ((c def c (c (? . 0) q bitwise-and)) q (22915 . 3)) ((c form c (c (? . 1) q define/augment)) q (143996 . 3)) ((c def c (c (? . 4) q unsafe-fl<)) q (396330 . 4)) ((c def c (c (? . 0) q read-square-bracket-as-paren)) q (291373 . 4)) ((q form ((lib "racket/surrogate.rkt") surrogate)) q (155444 . 10)) ((c def c (c (? . 10) q read-string-evt)) q (276871 . 4)) ((c def c (c (? . 12) q list/c)) q (165725 . 3)) ((c def c (c (? . 74) q string-replace)) q (45183 . 6)) ((c def c (c (? . 36) q legacy-match-expander?)) q (196425 . 3)) ((c def c (c (? . 0) q date-month)) c (? . 32)) ((c form c (c (? . 43) q splicing-letrec-syntax)) q (247844 . 2)) ((c form c (c (? . 12) q flat-murec-contract)) q (168274 . 2)) ((c def c (c (? . 0) q make-log-receiver)) q (384351 . 5)) ((c form c (c (? . 47) q place*)) q (225214 . 9)) ((c def c (c (? . 0) q substring)) q (40693 . 5)) ((c form c (c (? . 1) q init)) q (142345 . 2)) ((c def c (c (? . 4) q unsafe-flimag-part)) q (398092 . 5)) ((c def c (c (? . 0) q make-hash)) q (99404 . 3)) ((c form c (c (? . 23) q current-contract-region)) q (176465 . 2)) ((c def c (c (? . 0) q regexp?)) q (65653 . 3)) ((c def c (c (? . 42) q drop)) q (90182 . 4)) ((c def c (c (? . 1) q interface-extension?)) q (154374 . 4)) ((c def c (c (? . 2) q make-date*)) c (? . 58)) ((c def c (c (? . 24) q contract-random-generate)) q (193688 . 5)) ((c def c (c (? . 0) q custom-write?)) q (302967 . 3)) ((c def c (c (? . 2) q exn:fail:syntax:missing-module)) c (? . 44)) ((c def c (c (? . 4) q unsafe-set-mcdr!)) q (398824 . 4)) ((c def c (c (? . 6) q exn:fail:resource?)) c (? . 88)) ((c def c (c (? . 49) q file->value)) q (357270 . 4)) ((c def c (c (? . 5) q dict-set*!)) q (113346 . 5)) ((c form c (c (? . 36) q struct*)) q (196899 . 2)) ((c def c (c (? . 0) q regexp-replace)) q (80846 . 15)) ((c def c (c (? . 0) q exn:srclocs?)) q (206385 . 3)) ((c def c (c (? . 0) q string-port?)) q (258387 . 3)) ((c def c (c (? . 5) q dict-iterate-value)) q (113170 . 4)) ((c def c (c (? . 0) q plumber-flush-handle?)) q (337211 . 3)) ((c def c (c (? . 0) q primitive-result-arity)) q (130748 . 3)) ((c def c (c (? . 16) q tcp-accept/enable-break)) q (366926 . 3)) ((c def c (c (? . 0) q bytes->list)) q (56850 . 3)) ((c def c (c (? . 12) q and/c)) q (163104 . 3)) ((c form c (c (? . 2) q #%printing-module-begin)) q (1836 . 2)) ((c def c (c (? . 13) q list->mutable-seteqv)) q (121189 . 4)) ((c def c (c (? . 2) q exn:fail)) c (? . 67)) ((c def c (c (? . 86) q engine)) q (226233 . 3)) ((c def c (c (? . 0) q call-with-continuation-barrier)) q (209719 . 3)) ((c def c (c (? . 0) q shell-execute)) q (377257 . 11)) ((c def c (c (? . 0) q lcm)) q (20722 . 3)) ((c form c (c (? . 50) q with-syntax*)) q (251785 . 5)) ((c def c (c (? . 46) q curryr)) q (131197 . 6)) ((c def c (c (? . 0) q compile)) q (313943 . 3)) ((c def c (c (? . 0) q cdaaar)) q (88411 . 3)) ((c def c (c (? . 42) q second)) q (89439 . 3)) ((c def c (c (? . 0) q port-file-identity)) q (258290 . 3)) ((c def c (c (? . 42) q cons?)) q (89233 . 3)) ((c def c (c (? . 16) q tcp-abandon-port)) q (367330 . 3)) ((c def c (c (? . 4) q unsafe-extfl>=)) q (403395 . 4)) ((c def c (c (? . 2) q exn:fail:network:errno)) c (? . 95)) ((c def c (c (? . 51) q sequence-tail)) q (108294 . 4)) ((c def c (c (? . 10) q eof-evt)) q (276401 . 3)) ((c def c (c (? . 0) q vector-set-performance-stats!)) q (390337 . 5)) ((c def c (c (? . 0) q current-module-path-for-load)) q (316567 . 11)) ((c def c (c (? . 2) q memq)) q (86004 . 4)) ((c def c (c (? . 0) q /)) q (19961 . 6)) ((c def c (c (? . 0) q free-label-identifier=?)) q (233194 . 4)) ((c def c (c (? . 0) q raise-argument-error)) q (197666 . 13)) ((c def c (c (? . 0) q syntax-column)) q (229798 . 3)) ((c def c (c (? . 22) q remv*)) q (85327 . 4)) ((c def c (c (? . 0) q chaperone-prompt-tag)) q (331595 . 18)) ((c def c (c (? . 0) q single-flonum?)) q (19045 . 3)) ((c def c (c (? . 6) q kill-evaluator)) q (345078 . 3)) ((c def c (c (? . 0) q cons)) q (83263 . 4)) ((c def c (c (? . 0) q custodian-require-memory)) q (334688 . 7)) ((c def c (c (? . 0) q struct:exn:fail:contract:arity)) c (? . 59)) ((c form c (c (? . 17) q invoke-unit/infer)) q (159715 . 5)) ((c form c (c (? . 0) q #%provide)) q (8103 . 23)) ((c def c (c (? . 4) q unsafe-fx->extfl)) q (404662 . 3)) ((c def c (c (? . 0) q syntax-local-value/immediate)) q (239862 . 8)) ((c form c (c (? . 60) q trait-rename)) q (148341 . 2)) ((c def c (c (? . 61) q process)) q (379242 . 9)) ((c def c (c (? . 1) q method-in-interface?)) q (154470 . 4)) ((c def c (c (? . 0) q exn:fail:filesystem:missing-module-path)) c (? . 62)) ((c def c (c (? . 0) q integer-bytes->integer)) q (25328 . 11)) ((c def c (c (? . 7) q flatan)) q (29646 . 3)) ((c def c (c (? . 6) q sandbox-reader)) q (339549 . 4)) ((c def c (c (? . 26) q exn:fail:contract:blame)) c (? . 27)) ((c def c (c (? . 0) q atan)) q (22310 . 6)) ((c def c (c (? . 9) q current-require-module-path)) q (244467 . 4)) ((c def c (c (? . 14) q export-mode)) c (? . 63)) ((c def c (c (? . 18) q flat-contract-property?)) q (190474 . 3)) ((c form c (c (? . 36) q define-match-expander)) q (196157 . 3)) ((c def c (c (? . 0) q call-with-continuation-prompt)) q (207970 . 10)) ((c def c (c (? . 0) q exn:fail:filesystem:exists?)) c (? . 77)) ((c def c (c (? . 0) q make-immutable-hasheq)) q (100342 . 4)) ((c def c (c (? . 2) q exn:fail:syntax:unbound)) c (? . 126)) ((c def c (c (? . 9) q make-import-source)) c (? . 64)) ((c def c (c (? . 10) q filter-read-input-port)) q (274710 . 27)) ((c def c (c (? . 2) q regexp-quote)) q (66137 . 7)) ((c def c (c (? . 0) q symbol<?)) q (65555 . 4)) ((c def c (c (? . 0) q date-second)) c (? . 32)) ((c form c (c (? . 17) q define-unit/s)) q (160649 . 6)) ((c def c (c (? . 0) q set-phantom-bytes!)) q (394170 . 4)) ((c def c (c (? . 11) q call-with-default-reading-parameterization)) q (292764 . 3)) ((c form c (c (? . 38) q let-syntaxes)) q (11006 . 2)) ((c def c (c (? . 20) q extflsqrt)) q (37151 . 3)) ((c def c (c (? . 2) q in-hash)) q (105886 . 3)) ((c form c (c (? . 2) q prefix-in)) q (4305 . 2)) ((c def c (c (? . 13) q list->seteq)) q (120993 . 3)) ((c def c (c (? . 0) q exn:fail:read-srclocs)) c (? . 97)) ((c def c (c (? . 0) q dynamic-require)) q (319610 . 7)) ((c def c (c (? . 13) q set->list)) q (125494 . 3)) ((c def c (c (? . 34) q the-unsupplied-arg)) q (174097 . 2)) ((c def c (c (? . 19) q call-with-parameterization)) q (222959 . 5)) ((c def c (c (? . 10) q with-input-from-bytes)) q (266472 . 4)) ((c def c (c (? . 0) q subprocess-group-enabled)) q (377145 . 4)) ((c def c (c (? . 4) q unsafe-extfl-)) q (402704 . 4)) ((c def c (c (? . 36) q match-expander?)) q (196364 . 3)) ((c def c (c (? . 5) q dict-iter-contract)) q (115562 . 3)) ((c def c (c (? . 65) q stream-ormap)) q (110516 . 4)) ((c def c (c (? . 1) q class->interface)) q (153958 . 3)) ((c def c (c (? . 117) q bytes-append*)) q (62206 . 4)) ((c def c (c (? . 0) q string-downcase)) q (42869 . 3)) ((c def c (c (? . 47) q place-channel-put/get)) q (225956 . 4)) ((c def c (c (? . 49) q find-files)) q (360412 . 7)) ((c form c (c (? . 1) q define/override)) q (143738 . 3)) ((c def c (c (? . 2) q exn:break)) c (? . 68)) ((c def c (c (? . 0) q make-string)) q (40084 . 4)) ((c def c (c (? . 7) q ->fl)) q (29930 . 3)) ((c def c (c (? . 0) q car)) q (83329 . 3)) ((c def c (c (? . 6) q sandbox-make-inspector)) q (344261 . 4)) ((c def c (c (? . 0) q struct:exn:fail:filesystem:missing-module)) c (? . 62)) ((c def c (c (? . 42) q permutations)) q (92940 . 3)) ((c form c (c (? . 66) q trace-define-syntax)) q (409048 . 3)) ((c def c (c (? . 29) q future)) q (223210 . 3)) ((c def c (c (? . 78) q check-not-unsafe-undefined/assign)) q (405263 . 5)) ((c def c (c (? . 0) q dump-memory-stats)) q (393956 . 3)) ((c def c (c (? . 29) q current-future)) q (223364 . 2)) ((c def c (c (? . 0) q custodian-managed-list)) q (334515 . 4)) ((c def c (c (? . 46) q identity)) q (130835 . 3)) ((c def c (c (? . 2) q make-exn:fail)) c (? . 67)) ((c form c (c (? . 0) q with-continuation-mark)) q (16602 . 2)) ((c def c (c (? . 0) q integer?)) q (18565 . 3)) ((c def c (c (? . 0) q eqv?)) q (17529 . 4)) ((c form c (c (? . 1) q interface*)) q (139341 . 7)) ((c def c (c (? . 0) q thread-suspend-evt)) q (216318 . 3)) ((c def c (c (? . 0) q make-channel)) q (218381 . 2)) ((c def c (c (? . 16) q tcp-accept-evt)) q (367252 . 3)) ((c def c (c (? . 16) q tcp-connect/enable-break)) q (366431 . 10)) ((c def c (c (? . 0) q tan)) q (22158 . 3)) ((c def c (c (? . 0) q struct:date*)) c (? . 58)) ((c def c (c (? . 2) q call-with-output-file)) q (256011 . 11)) ((c def c (c (? . 0) q current-gc-milliseconds)) q (385822 . 2)) ((c def c (c (? . 0) q numerator)) q (21118 . 3)) ((c def c (c (? . 56) q pretty-format)) q (297839 . 4)) ((c form c (c (? . 2) q for)) q (13108 . 16)) ((c def c (c (? . 30) q fxnot)) q (33000 . 3)) ((c def c (c (? . 1) q object?)) q (153443 . 3)) ((c def c (c (? . 0) q exn:break?)) c (? . 68)) ((c form c (c (? . 33) q syntax-case*)) q (227983 . 3)) ((c def c (c (? . 4) q unsafe-extfl<=)) q (403306 . 4)) ((c def c (c (? . 69) q chaperone-async-channel)) q (221135 . 13)) ((c def c (c (? . 53) q string->some-system-path)) q (352606 . 4)) ((c def c (c (? . 70) q promise?)) q (207226 . 3)) ((c def c (c (? . 4) q unsafe-fxand)) q (394858 . 4)) ((c def c (c (? . 0) q current-output-port)) q (252539 . 4)) ((c def c (c (? . 0) q vector-length)) q (94688 . 3)) ((c def c (c (? . 2) q make-exn)) c (? . 102)) ((c def c (c (? . 4) q unsafe-extfltan)) q (404089 . 3)) ((c def c (c (? . 56) q pretty-print-show-inexactness)) q (298658 . 4)) ((c def c (c (? . 4) q unsafe-f64vector-ref)) q (401506 . 4)) ((c def c (c (? . 0) q read-char)) q (279100 . 3)) ((c def c (c (? . 10) q read-bytes-avail!-evt)) q (276744 . 4)) ((c def c (c (? . 3) q udp-send-to)) q (368559 . 13)) ((c def c (c (? . 29) q fsemaphore-try-wait?)) q (223890 . 3)) ((c def c (c (? . 11) q find-executable-path)) q (353139 . 7)) ((c form c (c (? . 12) q cons/dc)) q (165429 . 8)) ((c def c (c (? . 0) q bytes-utf-8-index)) q (60045 . 11)) ((c def c (c (? . 4) q unsafe-fltruncate)) q (396993 . 3)) ((c def c (c (? . 0) q make-prefab-struct)) q (138265 . 4)) ((c def c (c (? . 0) q raise-arguments-error)) q (198448 . 10)) ((c def c (c (? . 2) q exn:fail:contract:arity)) c (? . 59)) ((c def c (c (? . 61) q bytes-no-nuls?)) q (382015 . 3)) ((c form c (c (? . 36) q match/derived)) q (196727 . 2)) ((c def c (c (? . 6) q sandbox-eval-limits)) q (343422 . 8)) ((c def c (c (? . 0) q pipe-content-length)) q (259583 . 3)) ((c def c (c (? . 2) q make-do-sequence)) q (107238 . 8)) ((c def c (c (? . 0) q call-with-composable-continuation)) q (209213 . 6)) ((c def c (c (? . 0) q eof)) q (252898 . 2)) ((c def c (c (? . 22) q remq)) q (84984 . 4)) ((c def c (c (? . 49) q get-preference)) q (362279 . 18)) ((c def c (c (? . 50) q syntax-local-eval)) q (251640 . 4)) ((c def c (c (? . 71) q struct-auto-info?)) q (139022 . 3)) ((c def c (c (? . 0) q free-template-identifier=?)) q (233079 . 4)) ((c def c (c (? . 42) q rest)) q (89388 . 3)) ((c def c (c (? . 0) q cadadr)) q (88111 . 3)) ((c def c (c (? . 6) q make-evaluator)) c (? . 72)) ((c def c (c (? . 0) q caadr)) q (87037 . 3)) ((c def c (c (? . 10) q port->bytes-lines)) q (265253 . 6)) ((c def c (c (? . 19) q call-with-exception-handler)) q (200689 . 4)) ((c form c (c (? . 43) q splicing-syntax-parameterize)) q (247996 . 2)) ((c def c (c (? . 49) q call-with-file-lock/timeout)) q (364424 . 15)) ((c def c (c (? . 4) q unsafe-unbox)) q (399252 . 3)) ((c form c (c (? . 2) q #%module-begin)) q (1801 . 2)) ((c def c (c (? . 0) q exact-nonnegative-integer?)) q (18679 . 3)) ((c def c (c (? . 0) q format)) q (294612 . 4)) ((c def c (c (? . 54) q map)) q (84210 . 4)) ((c def c (c (? . 2) q hash-set*!)) q (100599 . 5)) ((c def c (c (? . 79) q serializable?)) q (303323 . 3)) ((c form c (c (? . 17) q unit-from-context)) q (160052 . 2)) ((c def c (c (? . 0) q quotient)) q (20074 . 4)) ((c def c (c (? . 0) q string->number)) q (25066 . 4)) ((c def c (c (? . 0) q make-weak-hash)) q (99719 . 3)) ((c def c (c (? . 0) q exp)) q (21958 . 3)) ((c def c (c (? . 15) q build-compound-type-name)) q (180224 . 3)) ((c def c (c (? . 14) q provide-transformer?)) q (246240 . 3)) ((c def c (c (? . 10) q peek-bytes!-evt)) c (? . 73)) ((c def c (c (? . 0) q prop:liberal-define-context)) q (242884 . 2)) ((c def c (c (? . 0) q string-upcase)) q (42805 . 3)) ((c def c (c (? . 0) q port-closed-evt)) q (252369 . 3)) ((c def c (c (? . 0) q list-ref)) q (83832 . 4)) ((c def c (c (? . 0) q string-locale-ci<?)) q (43807 . 4)) ((c def c (c (? . 57) q exact-floor)) q (27907 . 3)) ((c def c (c (? . 2) q in-port)) q (105216 . 4)) ((c def c (c (? . 0) q exn:fail:contract?)) c (? . 83)) ((c def c (c (? . 4) q unsafe-extfl->fx)) q (404728 . 3)) ((c def c (c (? . 56) q pretty-print-current-style-table)) q (298997 . 4)) ((c def c (c (? . 2) q in-value)) q (106549 . 3)) ((c def c (c (? . 4) q unsafe-fxnot)) q (395098 . 3)) ((c def c (c (? . 14) q export?)) c (? . 63)) ((c def c (c (? . 0) q hash-count)) q (103133 . 3)) ((c def c (c (? . 0) q resolve-path)) q (350024 . 3)) ((c def c (c (? . 0) q error-print-width)) q (201351 . 4)) ((c def c (c (? . 56) q pretty-write)) q (297607 . 4)) ((c def c (c (? . 0) q struct:exn:fail:read:non-char)) c (? . 82)) ((c form c (c (? . 0) q define-values)) q (12208 . 2)) ((c def c (c (? . 0) q complete-path?)) q (349577 . 3)) ((c def c (c (? . 0) q wrap-evt)) q (217297 . 4)) ((c def c (c (? . 0) q copy-file)) q (355173 . 5)) ((c def c (c (? . 0) q mpair?)) q (93981 . 3)) ((c form c (c (? . 1) q inherit/super)) q (142963 . 2)) ((c def c (c (? . 74) q string-append*)) q (44173 . 4)) ((c def c (c (? . 0) q module-compiled-language-info)) q (319284 . 4)) ((c def c (c (? . 4) q unsafe-extflfloor)) q (403738 . 3)) ((c def c (c (? . 4) q unsafe-extflabs)) q (402974 . 3)) ((c def c (c (? . 0) q shared-bytes)) q (57099 . 3)) ((c def c (c (? . 0) q eval-jit-enabled)) q (314568 . 4)) ((c form c (c (? . 2) q struct-field-index)) q (132896 . 2)) ((c def c (c (? . 2) q in-parallel)) q (106809 . 3)) ((c form c (c (? . 1) q override-final)) q (142712 . 2)) ((c def c (c (? . 113) q hash/c)) q (167181 . 9)) ((c def c (c (? . 0) q break-enabled)) q (214412 . 4)) ((c def c (c (? . 36) q exn:misc:match?)) q (196074 . 3)) ((c def c (c (? . 0) q string->uninterned-symbol)) q (65317 . 3)) ((c def c (c (? . 9) q syntax-local-require-certifier)) q (245096 . 4)) ((c def c (c (? . 66) q current-trace-print-args)) q (409531 . 14)) ((c form c (c (? . 0) q module)) q (1651 . 2)) ((c def c (c (? . 7) q flvector?)) q (30767 . 3)) ((c form c (c (? . 13) q for/mutable-set)) q (122006 . 2)) ((c def c (c (? . 0) q thread-receive)) q (216578 . 2)) ((c def c (c (? . 65) q stream-count)) q (110830 . 4)) ((c def c (c (? . 0) q struct-type-make-constructor)) q (336511 . 4)) ((c def c (c (? . 0) q procedure-closure-contents-eq?)) q (127953 . 5)) ((c def c (c (? . 1) q member-name-key=?)) q (144864 . 4)) ((c def c (c (? . 0) q current-inspector)) q (336026 . 4)) ((c form c (c (? . 36) q match-let)) q (195632 . 2)) ((c def c (c (? . 0) q string->symbol)) q (65252 . 3)) ((c def c (c (? . 75) q make-parameter-rename-transformer)) q (247631 . 3)) ((c def c (c (? . 75) q syntax-parameter-value)) q (247556 . 3)) ((c form c (c (? . 0) q begin-for-syntax)) q (12933 . 2)) ((c def c (c (? . 0) q print-box)) q (295187 . 4)) ((c def c (c (? . 0) q expand-once)) q (249253 . 3)) ((c def c (c (? . 0) q read-string!)) q (280057 . 7)) ((c form c (c (? . 1) q this%)) q (142299 . 2)) ((c def c (c (? . 0) q cdddar)) q (89011 . 3)) ((c form c (c (? . 1) q super-make-object)) q (145301 . 2)) ((c def c (c (? . 0) q namespace-mapped-symbols)) q (307365 . 3)) ((c def c (c (? . 0) q eq?)) q (17602 . 4)) ((c def c (c (? . 0) q logger-name)) q (382616 . 3)) ((c def c (c (? . 0) q char?)) q (62404 . 3)) ((c form c (c (? . 19) q parameterize-break)) q (214502 . 2)) ((c def c (c (? . 26) q blame-source)) q (181777 . 3)) ((c def c (c (? . 0) q custodian-box-value)) q (335380 . 3)) ((c def c (c (? . 1) q interface->method-names)) q (154572 . 3)) ((c def c (c (? . 33) q generate-temporaries)) q (231654 . 3)) ((c def c (c (? . 0) q current-print)) q (313654 . 4)) ((c def c (c (? . 0) q datum-intern-literal)) q (231468 . 3)) ((c def c (c (? . 66) q current-prefix-out)) q (410630 . 4)) ((c form c (c (? . 38) q =>)) q (11724 . 2)) ((c def c (c (? . 2) q gen:custom-write)) q (302884 . 2)) ((c form c (c (? . 34) q unconstrained-domain->)) q (174016 . 2)) ((c def c (c (? . 2) q in-hash-values)) q (106011 . 3)) ((c def c (c (? . 35) q vector-count)) q (97645 . 4)) ((c def c (c (? . 4) q unsafe-vector-ref)) q (399766 . 4)) ((c def c (c (? . 2) q make-exn:fail:contract:variable)) c (? . 76)) ((c def c (c (? . 0) q bytes-utf-8-ref)) q (59751 . 7)) ((c def c (c (? . 0) q dynamic-require-for-syntax)) q (319906 . 7)) ((c def c (c (? . 4) q unsafe-fx<)) q (395402 . 4)) ((c def c (c (? . 10) q call-with-input-string)) q (266144 . 4)) ((c def c (c (? . 0) q impersonate-vector)) q (323016 . 13)) ((c def c (c (? . 0) q equal?)) q (17454 . 4)) ((c def c (c (? . 3) q udp-send-to*)) q (369246 . 13)) ((c def c (c (? . 0) q make-immutable-hash)) q (100085 . 4)) ((c def c (c (? . 6) q sandbox-gui-available)) q (341727 . 4)) ((c def c (c (? . 0) q sync/timeout)) q (216870 . 4)) ((c form c (c (? . 19) q log-debug)) q (384220 . 3)) ((c def c (c (? . 0) q regexp-match-peek-positions-immediate)) q (74138 . 19)) ((c def c (c (? . 10) q copy-port)) q (279004 . 4)) ((c def c (c (? . 12) q >=/c)) q (163490 . 3)) ((c def c (c (? . 0) q syntax-local-introduce)) q (241800 . 3)) ((c def c (c (? . 0) q identifier-binding)) q (233413 . 14)) ((c def c (c (? . 57) q cosh)) q (27738 . 3)) ((c def c (c (? . 3) q udp-receive!-evt)) q (373396 . 9)) ((c form c (c (? . 106) q matching-identifiers-out)) q (9407 . 2)) ((c def c (c (? . 5) q make-weak-custom-hash)) q (118158 . 14)) ((c def c (c (? . 50) q current-syntax-context)) q (250606 . 4)) ((c def c (c (? . 4) q unsafe-fl+)) q (395880 . 4)) ((c def c (c (? . 0) q current-memory-use)) q (393854 . 3)) ((c def c (c (? . 0) q current-code-inspector)) q (336822 . 4)) ((c def c (c (? . 4) q unsafe-fl/)) q (396114 . 4)) ((c def c (c (? . 69) q async-channel-get)) q (220245 . 3)) ((c def c (c (? . 0) q pseudo-random-generator->vector)) q (24414 . 4)) ((c def c (c (? . 0) q set!-transformer-procedure)) q (235799 . 4)) ((c form c (c (? . 41) q reset0)) q (211497 . 2)) ((c def c (c (? . 0) q delete-directory)) q (356019 . 3)) ((c def c (c (? . 0) q output-port?)) q (252058 . 3)) ((c form c (c (? . 39) q subtract-in)) q (9126 . 2)) ((c def c (c (? . 2) q in-indexed)) q (106604 . 3)) ((c def c (c (? . 4) q unsafe-fl<=)) q (396488 . 4)) ((c def c (c (? . 0) q raise)) q (197115 . 4)) ((c form c (c (? . 2) q #%app)) q (9741 . 2)) ((c def c (c (? . 7) q flmin)) q (29017 . 4)) ((c def c (c (? . 0) q syntax-property-symbol-keys)) q (248215 . 3)) ((c def c (c (? . 7) q flreal-part)) q (30274 . 5)) ((c def c (c (? . 0) q error)) q (197203 . 10)) ((c def c (c (? . 2) q in-values*-sequence)) q (106953 . 3)) ((c def c (c (? . 0) q path->complete-path)) q (349681 . 5)) ((c def c (c (? . 0) q make-thread-cell)) q (221665 . 4)) ((c def c (c (? . 0) q default-continuation-prompt-tag)) q (208689 . 2)) ((c def c (c (? . 0) q pregexp?)) q (65706 . 3)) ((c def c (c (? . 11) q find-library-collection-links)) q (405791 . 3)) ((c def c (c (? . 0) q hasheq)) q (99168 . 4)) ((c def c (c (? . 6) q sandbox-make-logger)) q (344529 . 4)) ((c def c (c (? . 4) q unsafe-flatan)) q (397354 . 3)) ((c def c (c (? . 5) q dict-implements/c)) q (111891 . 3)) ((c def c (c (? . 5) q dict?)) q (111748 . 3)) ((c def c (c (? . 5) q dict-set*)) q (113487 . 5)) ((c def c (c (? . 0) q semaphore-post)) q (218924 . 3)) ((c def c (c (? . 0) q struct:exn:fail:filesystem:exists)) c (? . 77)) ((c def c (c (? . 0) q make-hasheqv)) q (99509 . 3)) ((c def c (c (? . 0) q current-library-collection-paths)) q (406983 . 5)) ((q def ((lib "racket/undefined.rkt") undefined)) q (131842 . 2)) ((c form c (c (? . 2) q except-out)) q (6004 . 2)) ((c def c (c (? . 0) q will-register)) q (393530 . 5)) ((c def c (c (? . 41) q abort/cc)) q (210607 . 4)) ((c def c (c (? . 0) q local-expand)) q (236465 . 13)) ((c def c (c (? . 50) q format-symbol)) q (250385 . 4)) ((c form c (c (? . 128) q enter!)) q (408198 . 9)) ((c def c (c (? . 0) q make-parameter)) q (222187 . 4)) ((c def c (c (? . 0) q continuation-mark-set->list)) q (212547 . 8)) ((c def c (c (? . 71) q struct-info?)) q (138558 . 3)) ((c def c (c (? . 0) q cdadar)) q (88611 . 3)) ((c def c (c (? . 0) q raise-range-error)) q (198751 . 17)) ((c form c (c (? . 1) q define/public-final)) q (143648 . 3)) ((c def c (c (? . 0) q list)) q (83493 . 3)) ((c def c (c (? . 0) q current-continuation-marks)) q (212368 . 5)) ((c def c (c (? . 13) q set-member?)) q (123210 . 4)) ((c def c (c (? . 0) q char>?)) q (63071 . 4)) ((c form c (c (? . 2) q for/sum)) q (14190 . 2)) ((c def c (c (? . 5) q dict-iterate-next)) q (112995 . 4)) ((c def c (c (? . 78) q check-not-unsafe-undefined)) q (405120 . 5)) ((c def c (c (? . 0) q odd?)) q (19322 . 3)) ((c def c (c (? . 0) q struct-type-make-predicate)) q (336634 . 3)) ((c def c (c (? . 79) q deserialize-module-guard)) q (303573 . 5)) ((c def c (c (? . 0) q identifier-label-binding)) q (234926 . 12)) ((c def c (c (? . 4) q unsafe-fx=)) q (395323 . 4)) ((c form c (c (? . 2) q define-namespace-anchor)) q (305716 . 2)) ((c def c (c (? . 0) q read-accept-graph)) q (291911 . 4)) ((c def c (c (? . 4) q unsafe-car)) q (398529 . 3)) ((c def c (c (? . 103) q signature-members)) q (162055 . 8)) ((c def c (c (? . 0) q namespace-require/expansion-time)) q (307817 . 4)) ((c def c (c (? . 0) q raise-mismatch-error)) q (199677 . 8)) ((c def c (c (? . 0) q evt?)) q (216767 . 3)) ((c def c (c (? . 13) q weak-seteqv)) q (120622 . 3)) ((c def c (c (? . 42) q make-list)) q (89995 . 4)) ((c def c (c (? . 93) q struct:exn:fail:support)) c (? . 94)) ((c def c (c (? . 4) q unsafe-make-flrectangular)) q (397673 . 7)) ((c def c (c (? . 19) q call-with-break-parameterization)) q (214628 . 5)) ((c def c (c (? . 15) q value-blame)) q (191608 . 3)) ((c def c (c (? . 2) q exn:fail:network)) c (? . 84)) ((c def c (c (? . 4) q unsafe-fl>=)) q (396568 . 4)) ((c def c (c (? . 12) q not/c)) q (163179 . 3)) ((c def c (c (? . 0) q chaperone-channel)) q (331089 . 12)) ((c def c (c (? . 2) q make-exn:break:terminate)) c (? . 80)) ((c def c (c (? . 0) q string-ci<=?)) q (42509 . 4)) ((c def c (c (? . 41) q fcontrol)) q (211021 . 4)) ((c form c (c (? . 81) q struct/dc)) q (165910 . 27)) ((c def c (c (? . 0) q call-in-nested-thread)) q (215434 . 4)) ((c def c (c (? . 13) q weak-seteq)) q (120718 . 3)) ((c def c (c (? . 22) q findf)) q (86179 . 4)) ((c def c (c (? . 0) q prop:object-name)) q (336773 . 2)) ((c def c (c (? . 69) q async-channel/c)) q (220582 . 3)) ((c def c (c (? . 0) q port-closed?)) q (252305 . 3)) ((c def c (c (? . 6) q get-output)) c (? . 109)) ((c def c (c (? . 4) q unsafe-fxxor)) q (395018 . 4)) ((c form c (c (? . 15) q define/final-prop)) q (190543 . 6)) ((c def c (c (? . 0) q string-normalize-nfkd)) q (43163 . 3)) ((c def c (c (? . 7) q flvector-ref)) q (31089 . 4)) ((c def c (c (? . 0) q read-bytes-avail!*)) q (280987 . 10)) ((c def c (c (? . 4) q unsafe-fl-)) q (395958 . 4)) ((c form c (c (? . 38) q let/ec)) q (209688 . 2)) ((c def c (c (? . 18) q build-contract-property)) q (188024 . 42)) ((c def c (c (? . 0) q continuation-mark-set->context)) q (214308 . 3)) ((c def c (c (? . 2) q with-input-from-file)) q (257326 . 7)) ((c def c (c (? . 2) q exn:fail:read:non-char)) c (? . 82)) ((c def c (c (? . 2) q in-string)) q (104744 . 6)) ((c def c (c (? . 20) q extfl->inexact)) q (37571 . 3)) ((c def c (c (? . 0) q free-transformer-identifier=?)) q (232961 . 4)) ((c def c (c (? . 0) q string->unreadable-symbol)) q (65393 . 3)) ((c def c (c (? . 46) q const)) q (130886 . 3)) ((c def c (c (? . 121) q s-exp->fasl)) q (305309 . 4)) ((c form c (c (? . 1) q public-final)) q (142594 . 2)) ((c def c (c (? . 6) q sandbox-run-submodules)) q (344116 . 4)) ((c def c (c (? . 0) q make-thread-group)) q (335451 . 3)) ((c def c (c (? . 0) q path-convention-type)) q (348444 . 3)) ((c form c (c (? . 1) q overment)) q (142674 . 2)) ((c def c (c (? . 0) q placeholder-set!)) q (93463 . 4)) ((c def c (c (? . 0) q print-hash-table)) q (295371 . 4)) ((c def c (c (? . 13) q set-copy)) q (124029 . 3)) ((c def c (c (? . 13) q set-union!)) q (124444 . 4)) ((c def c (c (? . 74) q string-normalize-spaces)) q (44726 . 11)) ((c def c (c (? . 0) q identifier-template-binding)) q (234456 . 12)) ((c def c (c (? . 2) q exn:fail:filesystem:missing-module)) c (? . 62)) ((c def c (c (? . 2) q make-exn:fail:filesystem:missing-module)) c (? . 62)) ((c def c (c (? . 2) q exn:fail:filesystem:version)) c (? . 114)) ((c def c (c (? . 11) q channel-try-get)) q (218477 . 3)) ((c def c (c (? . 2) q exn:fail:contract)) c (? . 83)) ((c def c (c (? . 0) q set!-transformer?)) q (235633 . 3)) ((c def c (c (? . 0) q exn:fail:network?)) c (? . 84)) ((c def c (c (? . 0) q bytes)) q (55480 . 3)) ((c def c (c (? . 0) q subprocess-status)) q (376550 . 4)) ((c def c (c (? . 20) q extflasin)) q (36843 . 3)) ((c form c (c (? . 104) q unsyntax-splicing)) q (229092 . 2)) ((c def c (c (? . 2) q keyword-apply)) q (128117 . 13)) ((c def c (c (? . 49) q make-directory*)) q (361421 . 3)) ((c def c (c (? . 6) q sandbox-memory-limit)) q (343285 . 4)) ((c form c (c (? . 17) q open)) q (157380 . 2)) ((c def c (c (? . 65) q stream-fold)) q (110711 . 5)) ((c def c (c (? . 0) q set-port-next-location!)) q (254040 . 9)) ((c form c (c (? . 85) q contract-struct)) q (174410 . 2)) ((c form c (c (? . 19) q let/cc)) q (209657 . 2)) ((c form c (c (? . 17) q define-values/invoke-unit/infer)) q (159819 . 8)) ((c def c (c (? . 2) q collection-path)) q (406683 . 8)) ((c def c (c (? . 0) q make-custodian)) q (334233 . 3)) ((c def c (c (? . 0) q struct:exn:fail:contract:variable)) c (? . 76)) ((c def c (c (? . 13) q set-intersect)) q (124548 . 4)) ((c def c (c (? . 86) q engine-run)) q (226372 . 4)) ((c def c (c (? . 0) q hash-clear!)) q (102429 . 3)) ((c def c (c (? . 1) q member-name-key?)) q (144802 . 3)) ((c def c (c (? . 15) q contract-first-order)) q (191029 . 3)) ((c form c (c (? . 1) q override)) q (142636 . 2)) ((c def c (c (? . 22) q reverse)) q (84156 . 3)) ((c def c (c (? . 0) q exn:fail:read:non-char?)) c (? . 82)) ((c form c (c (? . 36) q match/values)) q (194907 . 2)) ((c def c (c (? . 0) q cleanse-path)) q (350092 . 3)) ((c def c (c (? . 0) q syntax-local-lift-provide)) q (240742 . 3)) ((c form c (c (? . 2) q for*/and)) q (15092 . 2)) ((c def c (c (? . 0) q struct:exn:fail)) c (? . 67)) ((c def c (c (? . 47) q place?)) q (224105 . 3)) ((c def c (c (? . 56) q pretty-display)) q (297722 . 4)) ((c def c (c (? . 4) q unsafe-flceiling)) q (396930 . 3)) ((c def c (c (? . 0) q thread-dead?)) q (216071 . 3)) ((c def c (c (? . 4) q unsafe-extflceiling)) q (403808 . 3)) ((c def c (c (? . 2) q prop:procedure)) q (129899 . 2)) ((c def c (c (? . 22) q remq*)) q (85248 . 4)) ((c def c (c (? . 3) q udp-receive!*)) q (371296 . 12)) ((c def c (c (? . 0) q char-ci>=?)) q (63643 . 4)) ((c def c (c (? . 2) q in-hash-pairs)) q (106078 . 3)) ((c def c (c (? . 0) q vector->immutable-vector)) q (95149 . 3)) ((c def c (c (? . 0) q date*?)) c (? . 58)) ((c def c (c (? . 15) q prop:contracted)) q (182999 . 2)) ((c form c (c (? . 41) q reset)) q (211304 . 2)) ((c form c (c (? . 2) q for/vector)) q (13624 . 8)) ((c def c (c (? . 0) q hash-set!)) q (100469 . 5)) ((c form c (c (? . 87) q serializable-struct)) q (303753 . 3)) ((c def c (c (? . 6) q exn:fail:resource-resource)) c (? . 88)) ((c def c (c (? . 5) q dict-implements?)) q (111799 . 4)) ((c def c (c (? . 0) q struct:exn:fail:syntax:missing-module)) c (? . 44)) ((c def c (c (? . 0) q write-bytes-avail/enable-break)) q (288789 . 10)) ((c def c (c (? . 0) q log-message)) q (382822 . 13)) ((c def c (c (? . 0) q peek-string)) q (281836 . 5)) ((c def c (c (? . 0) q expand-syntax-to-top-form)) q (249493 . 3)) ((c def c (c (? . 10) q call-with-output-bytes)) q (265900 . 3)) ((c def c (c (? . 35) q vector-drop)) q (96806 . 4)) ((c def c (c (? . 61) q process/ports)) q (380235 . 11)) ((c form c (c (? . 33) q syntax-case)) q (226613 . 28)) ((c def c (c (? . 0) q char-iso-control?)) q (64408 . 3)) ((c def c (c (? . 11) q load-relative)) q (311520 . 3)) ((c def c (c (? . 0) q current-directory)) q (355560 . 4)) ((c def c (c (? . 0) q ephemeron?)) q (393363 . 3)) ((c def c (c (? . 4) q unsafe-string-ref)) q (400386 . 5)) ((c def c (c (? . 0) q plumber?)) q (336939 . 3)) ((c def c (c (? . 0) q integer-sqrt)) q (21744 . 3)) ((c def c (c (? . 9) q expand-import)) q (243013 . 3)) ((c def c (c (? . 0) q list*)) q (83545 . 4)) ((c def c (c (? . 122) q syntax-local-provide-introduce)) q (12778 . 3)) ((c form c (c (? . 2) q prefix-out)) q (6057 . 2)) ((c def c (c (? . 13) q list->weak-seteqv)) q (121504 . 4)) ((c form c (c (? . 0) q define-syntaxes)) q (12323 . 2)) ((c def c (c (? . 42) q add-between)) q (91229 . 13)) ((c form c (c (? . 2) q define)) q (11915 . 14)) ((c def c (c (? . 1) q is-a?)) q (154107 . 4)) ((c def c (c (? . 51) q sequence->list)) q (108053 . 3)) ((c def c (c (? . 28) q dynamic-object/c)) q (150151 . 9)) ((c def c (c (? . 5) q dict-update!)) q (113747 . 10)) ((c form c (c (? . 36) q match*/derived)) q (196789 . 2)) ((c form c (c (? . 41) q shift)) q (211331 . 2)) ((c def c (c (? . 20) q extflabs)) q (35765 . 3)) ((c def c (c (? . 4) q unsafe-s16vector-ref)) q (401716 . 4)) ((c def c (c (? . 11) q writeln)) q (293935 . 4)) ((c def c (c (? . 0) q pseudo-random-generator-vector?)) q (24877 . 3)) ((c def c (c (? . 2) q in-values-sequence)) q (106880 . 3)) ((c def c (c (? . 35) q vector-memq)) q (98169 . 4)) ((c def c (c (? . 0) q char-upcase)) q (64749 . 3)) ((c def c (c (? . 1) q exn:fail:object?)) c (? . 89)) ((c def c (c (? . 0) q byte-pregexp?)) q (65818 . 3)) ((c def c (c (? . 26) q blame?)) q (181138 . 3)) ((c def c (c (? . 14) q export-out-sym)) c (? . 63)) ((c def c (c (? . 65) q in-stream)) q (109853 . 3)) ((c def c (c (? . 0) q build-path)) q (348616 . 6)) ((c def c (c (? . 4) q unsafe-extflcos)) q (404021 . 3)) ((c def c (c (? . 0) q identifier-remove-from-definition-context)) q (239254 . 7)) ((c def c (c (? . 0) q struct:exn:fail:contract:non-fixnum-result)) c (? . 98)) ((c def c (c (? . 0) q custodian?)) q (334177 . 3)) ((c form c (c (? . 1) q init-field)) q (142375 . 2)) ((c def c (c (? . 49) q make-parent-directory*)) q (361492 . 3)) ((c def c (c (? . 0) q string-ci<?)) q (42411 . 4)) ((c form c (c (? . 0) q #%datum)) q (9532 . 2)) ((c def c (c (? . 0) q resolved-module-path-name)) q (315183 . 8)) ((c form c (c (? . 1) q private)) q (142873 . 2)) ((c def c (c (? . 42) q fifth)) q (89591 . 3)) ((c form c (c (? . 40) q infinite-generator)) q (111393 . 2)) ((c def c (c (? . 13) q set-symmetric-difference!)) q (125094 . 4)) ((c def c (c (? . 6) q call-with-deep-time-limit)) q (347096 . 4)) ((c def c (c (? . 7) q flfloor)) q (29217 . 3)) ((c def c (c (? . 0) q regexp)) q (65877 . 3)) ((c def c (c (? . 57) q degrees->radians)) q (27369 . 3)) ((c def c (c (? . 26) q blame-swap)) q (181835 . 3)) ((c def c (c (? . 10) q regexp-match-evt)) q (278586 . 4)) ((c def c (c (? . 12) q cons/c)) q (165333 . 4)) ((c def c (c (? . 2) q srcloc)) c (? . 8)) ((c def c (c (? . 0) q bitwise-not)) q (23069 . 3)) ((c def c (c (? . 0) q make-rename-transformer)) q (236041 . 6)) ((c def c (c (? . 33) q syntax-pattern-variable?)) q (229468 . 3)) ((c def c (c (? . 0) q string->bytes/utf-8)) q (58416 . 6)) ((c def c (c (? . 57) q exact-round)) q (27840 . 3)) ((c def c (c (? . 0) q print-unreadable)) q (294917 . 4)) ((c def c (c (? . 0) q parameter?)) q (222747 . 3)) ((c def c (c (? . 2) q prop:sequence)) q (107683 . 2)) ((c def c (c (? . 12) q any/c)) q (162967 . 2)) ((c form c (c (? . 1) q member-name-key)) q (144711 . 2)) ((c def c (c (? . 20) q make-shared-extflvector)) q (39052 . 4)) ((c def c (c (? . 0) q regexp-match?)) q (71129 . 13)) ((c def c (c (? . 13) q list->mutable-seteq)) q (121297 . 4)) ((c def c (c (? . 0) q string-ref)) q (40439 . 4)) ((c def c (c (? . 4) q unsafe-fx+)) q (394311 . 4)) ((c def c (c (? . 0) q box-cas!)) q (98596 . 5)) ((c form c (c (? . 1) q class-field-mutator)) q (146810 . 2)) ((c def c (c (? . 0) q struct:arity-at-least)) c (? . 90)) ((c def c (c (? . 4) q unsafe-mcar)) q (398635 . 3)) ((c def c (c (? . 0) q system-library-subpath)) q (389781 . 3)) ((c def c (c (? . 2) q sequence-generate)) q (107798 . 3)) ((c def c (c (? . 0) q string=?)) q (41836 . 4)) ((c def c (c (? . 0) q read)) q (290100 . 3)) ((c def c (c (? . 0) q make-struct-field-accessor)) q (134499 . 8)) ((c def c (c (? . 0) q prefab-key->struct-type)) q (138362 . 4)) ((c def c (c (? . 10) q read-bytes!-evt)) q (276562 . 5)) ((c def c (c (? . 22) q build-string)) q (41695 . 4)) ((c def c (c (? . 0) q exit-handler)) q (214942 . 4)) ((c def c (c (? . 47) q place-wait)) q (225406 . 3)) ((c def c (c (? . 0) q eprintf)) q (294530 . 4)) ((c def c (c (? . 56) q make-tentative-pretty-print-output-port)) q (301250 . 8)) ((c def c (c (? . 20) q extflceiling)) q (36529 . 3)) ((c def c (c (? . 2) q make-exn:fail:unsupported)) c (? . 91)) ((c def c (c (? . 79) q make-serialize-info)) q (304836 . 12)) ((c form c (c (? . 0) q unquote)) q (16694 . 2)) ((c def c (c (? . 0) q eqv-hash-code)) q (103882 . 3)) ((c form c (c (? . 17) q compound-unit/infer)) q (158563 . 18)) ((c def c (c (? . 51) q sequence-ormap)) q (108661 . 4)) ((c def c (c (? . 0) q string-normalize-nfd)) q (43086 . 3)) ((c form c (c (? . 41) q prompt-at)) q (211203 . 2)) ((c def c (c (? . 5) q dict-clear!)) q (114886 . 3)) ((c def c (c (? . 4) q unsafe-flabs)) q (396192 . 3)) ((c def c (c (? . 21) q ~e)) q (49514 . 23)) ((c def c (c (? . 1) q class-info)) q (155071 . 10)) ((c form c (c (? . 2) q only-in)) q (4209 . 2)) ((c def c (c (? . 10) q reencode-output-port)) q (271230 . 16)) ((c form c (c (? . 2) q only-meta-in)) q (4499 . 2)) ((c def c (c (? . 0) q make-output-port)) q (261957 . 59)) ((c def c (c (? . 46) q curry)) q (131059 . 6)) ((c def c (c (? . 0) q make-special-comment)) q (302673 . 3)) ((c def c (c (? . 0) q struct:exn:break)) c (? . 68)) ((c def c (c (? . 19) q current-parameterization)) q (222899 . 2)) ((c def c (c (? . 0) q identifier-prune-lexical-context)) q (231762 . 5)) ((c def c (c (? . 13) q list->weak-seteq)) q (121606 . 3)) ((c form c (c (? . 1) q with-method)) q (146347 . 3)) ((c def c (c (? . 7) q flvector-copy)) q (31329 . 5)) ((c def c (c (? . 125) q box/c)) q (164825 . 7)) ((c def c (c (? . 4) q unsafe-set-box*!)) q (399474 . 4)) ((c def c (c (? . 46) q normalized-arity?)) q (131337 . 3)) ((c form c (c (? . 1) q override-final*)) q (143302 . 2)) ((c def c (c (? . 0) q add1)) q (20409 . 3)) ((c def c (c (? . 6) q call-with-custodian-shutdown)) c (? . 92)) ((c def c (c (? . 41) q splitter)) q (211876 . 5)) ((c def c (c (? . 0) q positive?)) q (19158 . 3)) ((c def c (c (? . 0) q read-syntax)) q (290180 . 4)) ((c def c (c (? . 0) q subprocess)) q (375251 . 31)) ((c def c (c (? . 0) q namespace-module-identifier)) q (306299 . 4)) ((c form c (c (? . 17) q define-values-for-export)) q (157404 . 2)) ((c def c (c (? . 41) q abort)) q (210888 . 3)) ((c def c (c (? . 7) q flexpt)) q (29856 . 4)) ((c def c (c (? . 22) q build-vector)) q (95989 . 4)) ((c def c (c (? . 0) q path-element->string)) q (348192 . 3)) ((c def c (c (? . 5) q dict-remove)) q (112803 . 4)) ((c def c (c (? . 4) q unsafe-vector*-length)) q (399956 . 3)) ((c def c (c (? . 12) q none/c)) q (162998 . 2)) ((c def c (c (? . 12) q real-in)) q (163626 . 4)) ((c def c (c (? . 0) q peek-byte-or-special)) q (286040 . 8)) ((c form c (c (? . 38) q letrec)) q (10648 . 2)) ((c def c (c (? . 0) q port-writes-atomic?)) q (289947 . 3)) ((c def c (c (? . 0) q rename-transformer-target)) q (236301 . 3)) ((c form c (c (? . 2) q for*/lists)) q (14739 . 2)) ((c def c (c (? . 20) q extflround)) q (36403 . 3)) ((c def c (c (? . 0) q read-accept-box)) q (291607 . 4)) ((c def c (c (? . 0) q bytes->immutable-bytes)) q (55534 . 3)) ((c def c (c (? . 10) q relocate-input-port)) q (272130 . 13)) ((c form c (c (? . 28) q ->dm)) q (149613 . 6)) ((c def c (c (? . 86) q engine-result)) q (226481 . 3)) ((c def c (c (? . 4) q unsafe-flsin)) q (397057 . 3)) ((c form c (c (? . 120) q syntax-parameterize)) q (247491 . 2)) ((c def c (c (? . 47) q dynamic-place)) q (224217 . 9)) ((c def c (c (? . 0) q floor)) q (20864 . 3)) ((c def c (c (? . 86) q engine?)) q (226324 . 3)) ((c def c (c (? . 93) q exn:fail:support?)) c (? . 94)) ((c def c (c (? . 4) q unsafe-flvector-set!)) q (401397 . 5)) ((c def c (c (? . 0) q bytes-convert-end)) q (61566 . 13)) ((c form c (c (? . 0) q begin0)) q (12905 . 2)) ((c form c (c (? . 17) q rename)) q (157564 . 2)) ((c def c (c (? . 0) q +)) q (19742 . 3)) ((c def c (c (? . 56) q pretty-print-extend-style-table)) q (299178 . 8)) ((c def c (c (? . 6) q sandbox-make-environment-variables)) q (344807 . 5)) ((c form c (c (? . 33) q syntax/loc)) q (229125 . 2)) ((c def c (c (? . 0) q current-compile)) q (313765 . 5)) ((c def c (c (? . 30) q fxquotient)) q (32496 . 4)) ((c def c (c (? . 0) q sync/timeout/enable-break)) q (217080 . 4)) ((c def c (c (? . 4) q unsafe-extfl>)) q (403218 . 4)) ((c def c (c (? . 4) q unsafe-cdr)) q (398582 . 3)) ((c def c (c (? . 0) q hash-placeholder?)) q (93625 . 3)) ((c def c (c (? . 0) q exact?)) q (19375 . 3)) ((c form c (c (? . 7) q for/flvector)) q (31760 . 2)) ((c def c (c (? . 13) q set-remove!)) q (123547 . 4)) ((c def c (c (? . 26) q exn:fail:contract:blame?)) c (? . 27)) ((c def c (c (? . 0) q weak-box-value)) q (392993 . 4)) ((c def c (c (? . 13) q proper-subset?)) q (125395 . 4)) ((c def c (c (? . 0) q load)) q (311462 . 3)) ((c form c (c (? . 41) q prompt0-at)) q (211591 . 2)) ((c def c (c (? . 13) q set-rest)) q (123867 . 3)) ((c def c (c (? . 0) q cos)) q (22108 . 3)) ((c def c (c (? . 2) q regexp-match-positions*)) q (70092 . 17)) ((c def c (c (? . 47) q place-channel-put)) q (225758 . 4)) ((c def c (c (? . 0) q char-punctuation?)) q (64143 . 3)) ((c def c (c (? . 20) q extflexp)) q (37090 . 3)) ((c def c (c (? . 0) q inexact-real?)) q (18820 . 3)) ((c def c (c (? . 49) q user-execute-bit)) q (365489 . 2)) ((c form c (c (? . 2) q define-syntax)) q (12248 . 3)) ((c def c (c (? . 57) q infinite?)) q (28264 . 3)) ((c def c (c (? . 36) q prop:match-expander)) q (196253 . 2)) ((c def c (c (? . 4) q unsafe-extflatan)) q (404295 . 3)) ((c def c (c (? . 0) q vector->pseudo-random-generator)) q (24548 . 4)) ((c def c (c (? . 71) q make-struct-info)) q (138682 . 3)) ((q def ((lib "racket/private/stx.rkt") identifier?)) q (229591 . 3)) ((c def c (c (? . 0) q current-security-guard)) q (334048 . 4)) ((c def c (c (? . 0) q directory-exists?)) q (355873 . 3)) ((c def c (c (? . 0) q parameter-procedure=?)) q (222803 . 4)) ((c def c (c (? . 13) q set-subtract!)) q (124869 . 4)) ((c def c (c (? . 0) q prop:evt)) q (218104 . 2)) ((c def c (c (? . 0) q string-normalize-nfkc)) q (43318 . 3)) ((c def c (c (? . 2) q call-with-input-file*)) q (256521 . 7)) ((c form c (c (? . 38) q let-syntax)) q (10889 . 2)) ((c def c (c (? . 0) q inspector?)) q (335744 . 3)) ((c def c (c (? . 0) q char-ci=?)) q (63258 . 4)) ((c def c (c (? . 0) q rename-transformer?)) q (235976 . 3)) ((c def c (c (? . 9) q import-orig-mode)) c (? . 31)) ((c def c (c (? . 4) q unsafe-flexp)) q (397473 . 3)) ((c def c (c (? . 0) q cadar)) q (87119 . 3)) ((c def c (c (? . 0) q peek-string!)) q (282278 . 12)) ((c def c (c (? . 1) q object-info)) q (154982 . 3)) ((c form c (c (? . 70) q lazy)) q (207307 . 2)) ((c form c (c (? . 41) q control-at)) q (211251 . 2)) ((c def c (c (? . 42) q flatten)) q (91893 . 3)) ((c def c (c (? . 29) q fsemaphore?)) q (223689 . 3)) ((c def c (c (? . 0) q module-declared?)) q (320188 . 5)) ((c def c (c (? . 14) q make-provide-transformer)) q (245478 . 10)) ((c def c (c (? . 4) q unsafe-extflexpt)) q (404569 . 4)) ((c def c (c (? . 0) q peek-bytes!)) q (282775 . 12)) ((c form c (c (? . 2) q combine-out)) q (6126 . 2)) ((c def c (c (? . 0) q file-truncate)) q (253580 . 4)) ((c def c (c (? . 0) q environment-variables?)) q (387864 . 3)) ((c def c (c (? . 42) q fourth)) q (89540 . 3)) ((c def c (c (? . 7) q fltruncate)) q (29327 . 3)) ((c form c (c (? . 37) q define-runtime-paths)) q (356702 . 2)) ((c def c (c (? . 42) q append-map)) q (92694 . 4)) ((c form c (c (? . 19) q with-handlers*)) q (201014 . 3)) ((c def c (c (? . 20) q extflexpt)) q (37213 . 4)) ((c def c (c (? . 51) q sequence-map)) q (108469 . 4)) ((c def c (c (? . 2) q apply)) q (127486 . 6)) ((c form c (c (? . 1) q overment*)) q (143266 . 2)) ((c def c (c (? . 0) q exn:fail:network:errno-errno)) c (? . 95)) ((c def c (c (? . 10) q transplant-output-port)) q (273941 . 19)) ((c def c (c (? . 56) q pretty-print-remap-stylable)) q (299511 . 5)) ((c form c (c (? . 28) q object-contract)) q (150516 . 51)) ((c def c (c (? . 13) q set-first)) q (123776 . 3)) ((c def c (c (? . 0) q mcar)) q (94101 . 3)) ((c def c (c (? . 30) q fxmodulo)) q (32653 . 4)) ((c def c (c (? . 0) q port-counts-lines?)) q (253789 . 3)) ((c def c (c (? . 0) q chaperone-hash)) q (329332 . 20)) ((c form c (c (? . 2) q all-defined-out)) q (5892 . 2)) ((c def c (c (? . 0) q bound-identifier=?)) q (232336 . 6)) ((c def c (c (? . 0) q kill-thread)) q (215761 . 3)) ((c def c (c (? . 2) q make-exn:fail:read:eof)) c (? . 25)) ((c def c (c (? . 10) q with-input-from-string)) q (266374 . 4)) ((c def c (c (? . 0) q struct:exn:fail:network)) c (? . 84)) ((c def c (c (? . 0) q symbol->string)) q (65187 . 3)) ((c def c (c (? . 4) q unsafe-f64vector-set!)) q (401601 . 5)) ((c def c (c (? . 0) q module-compiled-name)) q (317805 . 9)) ((c def c (c (? . 0) q date-year-day)) c (? . 32)) ((c def c (c (? . 2) q make-exn:fail:contract)) c (? . 83)) ((c def c (c (? . 0) q caddar)) q (88211 . 3)) ((c def c (c (? . 3) q udp-close)) q (372172 . 3)) ((c def c (c (? . 11) q channel-get)) q (218420 . 3)) ((c def c (c (? . 26) q blame-contract)) q (181664 . 3)) ((c form c (c (? . 70) q delay)) q (207280 . 2)) ((c def c (c (? . 2) q member)) q (85770 . 5)) ((c def c (c (? . 18) q chaperone-contract-property?)) q (190400 . 3)) ((c def c (c (? . 96) q boolean=?)) q (18073 . 4)) ((c def c (c (? . 13) q set-clear)) q (124190 . 3)) ((c form c (c (? . 52) q include-at/relative-to/reader)) q (249794 . 2)) ((c def c (c (? . 0) q locale-string-encoding)) q (62162 . 2)) ((c def c (c (? . 20) q real->extfl)) q (37440 . 3)) ((c def c (c (? . 0) q truncate)) q (21032 . 3)) ((c def c (c (? . 0) q subprocess?)) q (376910 . 3)) ((c def c (c (? . 0) q date*-time-zone-name)) c (? . 58)) ((c def c (c (? . 0) q struct?)) q (137787 . 3)) ((c def c (c (? . 2) q sequence->stream)) q (107729 . 3)) ((c def c (c (? . 0) q namespace-symbol->identifier)) q (306097 . 3)) ((c form c (c (? . 70) q delay/sync)) q (207598 . 2)) ((c def c (c (? . 57) q sinh)) q (27687 . 3)) ((c def c (c (? . 0) q regexp-match-positions/end)) q (77150 . 16)) ((c def c (c (? . 12) q flat-named-contract)) q (162681 . 7)) ((c def c (c (? . 0) q module-path-index-split)) q (317201 . 5)) ((c def c (c (? . 0) q caaddr)) q (87911 . 3)) ((c def c (c (? . 0) q thread-group?)) q (335564 . 3)) ((c form c (c (? . 13) q for*/seteqv)) q (121954 . 2)) ((c def c (c (? . 5) q dict-copy)) q (114769 . 3)) ((c def c (c (? . 2) q open-output-file)) q (254824 . 10)) ((c def c (c (? . 0) q regexp-max-lookbehind)) q (66365 . 3)) ((c def c (c (? . 0) q string-ci>?)) q (42608 . 4)) ((c def c (c (? . 0) q port-try-file-lock?)) q (258083 . 4)) ((c form c (c (? . 13) q for/weak-seteq)) q (122408 . 2)) ((c def c (c (? . 71) q prop:struct-auto-info)) q (138968 . 2)) ((c def c (c (? . 4) q unsafe-extfllog)) q (404364 . 3)) ((c def c (c (? . 1) q generic?)) q (153604 . 3)) ((c def c (c (? . 9) q import-src-sym)) c (? . 31)) ((c def c (c (? . 0) q struct->vector)) q (137684 . 4)) ((c def c (c (? . 3) q udp-send-evt)) q (373075 . 9)) ((c def c (c (? . 0) q special-comment-value)) q (302809 . 3)) ((c def c (c (? . 0) q current-load-extension)) q (311648 . 5)) ((c def c (c (? . 0) q module-path-index-join)) q (317484 . 5)) ((c def c (c (? . 2) q make-exn:fail:contract:continuation)) c (? . 99)) ((c def c (c (? . 4) q unsafe-box*-cas!)) q (399588 . 5)) ((c form c (c (? . 19) q log-fatal)) q (383930 . 3)) ((c form c (c (? . 1) q public*)) q (143121 . 2)) ((c def c (c (? . 0) q identifier-transformer-binding)) q (233983 . 12)) ((c form c (c (? . 43) q splicing-let-values)) q (247760 . 2)) ((c def c (c (? . 79) q make-deserialize-info)) q (304660 . 4)) ((c def c (c (? . 0) q bytes-utf-8-length)) q (59484 . 7)) ((c def c (c (? . 0) q negative?)) q (19213 . 3)) ((c form c (c (? . 1) q super-instantiate)) q (145326 . 2)) ((c def c (c (? . 24) q contract-random-generate-get-current-environment)) q (194455 . 3)) ((c form c (c (? . 41) q prompt)) q (211142 . 2)) ((c form c (c (? . 33) q ...)) q (229448 . 2)) ((c def c (c (? . 0) q continuation-marks)) q (212144 . 5)) ((c def c (c (? . 0) q string->path-element)) q (347959 . 3)) ((c def c (c (? . 0) q channel?)) q (218327 . 3)) ((c def c (c (? . 0) q char-whitespace?)) q (64277 . 3)) ((c form c (c (? . 38) q letrec-syntaxes)) q (11072 . 2)) ((c def c (c (? . 0) q syntax-local-make-definition-context)) q (238690 . 4)) ((c def c (c (? . 40) q generator-state)) q (111534 . 3)) ((c def c (c (? . 0) q compile-enforce-module-constants)) q (314178 . 4)) ((c def c (c (? . 0) q custodian-limit-memory)) q (334946 . 7)) ((c def c (c (? . 79) q deserialize)) q (303440 . 3)) ((c def c (c (? . 0) q error-print-context-length)) q (201508 . 4)) ((q form ((lib "racket/shared.rkt") shared)) q (11355 . 2)) ((c def c (c (? . 6) q call-with-limits)) q (346864 . 5)) ((c def c (c (? . 1) q object->vector)) q (153845 . 4)) ((c form c (c (? . 2) q define-sequence-syntax)) q (15812 . 8)) ((c def c (c (? . 0) q call/ec)) q (209580 . 3)) ((c def c (c (? . 0) q exn:missing-module-accessor)) q (207110 . 4)) ((c def c (c (? . 6) q gui?)) q (346840 . 2)) ((c def c (c (? . 0) q sub1)) q (20460 . 3)) ((c def c (c (? . 0) q hash-eqv?)) q (98867 . 3)) ((c def c (c (? . 0) q current-module-declare-name)) q (316181 . 5)) ((c def c (c (? . 0) q port-next-location)) q (253859 . 6)) ((c def c (c (? . 0) q fixnum?)) q (18879 . 3)) ((c def c (c (? . 12) q contract?)) q (191112 . 3)) ((c def c (c (? . 15) q coerce-contract/f)) q (180933 . 3)) ((c form c (c (? . 2) q for-label)) q (6502 . 2)) ((c def c (c (? . 51) q sequence/c)) q (109289 . 5)) ((c def c (c (? . 16) q tcp-accept-ready?)) q (367034 . 3)) ((c def c (c (? . 16) q tcp-listen)) q (365716 . 9)) ((c form c (c (? . 2) q for-syntax)) q (6422 . 2)) ((c def c (c (? . 22) q assf)) q (86606 . 4)) ((c def c (c (? . 0) q module-path-index-resolve)) q (317100 . 3)) ((c def c (c (? . 0) q subprocess-wait)) q (376474 . 3)) ((c def c (c (? . 0) q write-bytes-avail)) q (288019 . 9)) ((c def c (c (? . 0) q syntax->list)) q (230377 . 3)) ((c form c (c (? . 13) q for/seteqv)) q (121803 . 2)) ((c def c (c (? . 0) q struct:exn:fail:contract)) c (? . 83)) ((c def c (c (? . 0) q environment-variables-set!)) q (388509 . 10)) ((c form c (c (? . 96) q implies)) q (18254 . 2)) ((c def c (c (? . 2) q impersonate-procedure)) q (321507 . 11)) ((c def c (c (? . 0) q read-bytes)) q (279903 . 4)) ((c def c (c (? . 0) q inexact?)) q (19429 . 3)) ((c def c (c (? . 0) q struct:exn:fail:read)) c (? . 97)) ((c def c (c (? . 0) q impersonator-property-accessor-procedure?)) q (333164 . 3)) ((c def c (c (? . 0) q prop:output-port)) q (259730 . 2)) ((c def c (c (? . 2) q make-exn:fail:user)) c (? . 55)) ((c def c (c (? . 0) q hash)) q (99050 . 4)) ((c def c (c (? . 0) q read-bytes-line)) q (279529 . 5)) ((c def c (c (? . 0) q bytes=?)) q (57160 . 4)) ((c def c (c (? . 0) q bytes-fill!)) q (56672 . 4)) ((c def c (c (? . 0) q current-force-delete-permissions)) q (355425 . 4)) ((c def c (c (? . 14) q prop:provide-transformer)) q (246122 . 2)) ((c def c (c (? . 11) q load/use-compiled)) q (312539 . 3)) ((c def c (c (? . 9) q import-local-id)) c (? . 31)) ((c def c (c (? . 49) q delete-directory/files)) q (360227 . 5)) ((c def c (c (? . 0) q set-mcar!)) q (94197 . 4)) ((c def c (c (? . 10) q peek-string-evt)) c (? . 73)) ((c def c (c (? . 2) q make-exn:fail:contract:arity)) c (? . 59)) ((c def c (c (? . 4) q unsafe-extfltruncate)) q (403880 . 3)) ((c def c (c (? . 0) q eof-object?)) q (252924 . 3)) ((c def c (c (? . 5) q prop:dict/contract)) q (115381 . 2)) ((c def c (c (? . 35) q vector-map)) q (96294 . 4)) ((c def c (c (? . 0) q syntax-local-lift-context)) q (240430 . 2)) ((c def c (c (? . 0) q string>=?)) q (42217 . 4)) ((c def c (c (? . 0) q identifier-prune-to-source-module)) q (231974 . 3)) ((c form c (c (? . 96) q nand)) q (18205 . 2)) ((c def c (c (? . 0) q datum->syntax)) q (230510 . 18)) ((c def c (c (? . 6) q sandbox-path-permissions)) q (342196 . 9)) ((c form c (c (? . 1) q send)) q (145487 . 3)) ((c form c (c (? . 2) q for/list)) q (13561 . 2)) ((c def c (c (? . 2) q exn:fail:contract:non-fixnum-result)) c (? . 98)) ((c def c (c (? . 6) q get-user-custodian)) q (345255 . 3)) ((c def c (c (? . 12) q false/c)) q (163913 . 2)) ((c def c (c (? . 0) q display)) q (293653 . 4)) ((c def c (c (? . 47) q place-channel?)) q (224157 . 3)) ((c def c (c (? . 61) q process*)) q (379618 . 15)) ((c def c (c (? . 40) q sequence->repeated-generator)) q (111669 . 3)) ((c def c (c (? . 0) q pair?)) q (83161 . 3)) ((c def c (c (? . 49) q copy-directory/files)) q (359839 . 9)) ((c form c (c (? . 1) q augment-final*)) q (143414 . 2)) ((c def c (c (? . 0) q date-dst?)) c (? . 32)) ((c def c (c (? . 26) q blame-update)) q (182103 . 5)) ((c form c (c (? . 2) q for*/or)) q (15155 . 2)) ((c def c (c (? . 65) q stream-add-between)) q (111032 . 4)) ((c def c (c (? . 0) q date-hour)) c (? . 32)) ((c def c (c (? . 10) q open-output-nowhere)) q (269975 . 4)) ((c def c (c (? . 0) q string-normalize-nfc)) q (43241 . 3)) ((c def c (c (? . 13) q subset?)) q (125303 . 4)) ((c form c (c (? . 17) q define-signature-form)) q (160785 . 3)) ((c def c (c (? . 0) q not)) q (17405 . 3)) ((c def c (c (? . 0) q length)) q (83758 . 3)) ((q form ((lib "racket/block.rkt") block)) q (16797 . 2)) ((c form c (c (? . 43) q splicing-let)) q (247717 . 2)) ((c def c (c (? . 15) q prop:blame)) q (183109 . 2)) ((c def c (c (? . 12) q integer-in)) q (163704 . 4)) ((c def c (c (? . 4) q unsafe-extflsin)) q (403953 . 3)) ((c def c (c (? . 56) q pretty-print-pre-print-hook)) q (300798 . 5)) ((c form c (c (? . 40) q in-generator)) q (111433 . 5)) ((c def c (c (? . 11) q displayln)) q (294051 . 4)) ((c def c (c (? . 3) q udp-send*)) q (369709 . 6)) ((c def c (c (? . 13) q set-implements/c)) q (122844 . 3)) ((c def c (c (? . 9) q import-src-mod-path)) c (? . 31)) ((c def c (c (? . 1) q object-interface)) q (154031 . 3)) ((c def c (c (? . 20) q extflonum?)) q (35330 . 3)) ((c def c (c (? . 0) q date*-nanosecond)) c (? . 58)) ((c def c (c (? . 0) q hash-map)) q (102684 . 4)) ((c def c (c (? . 4) q unsafe-string-length)) q (400315 . 3)) ((c def c (c (? . 0) q namespace-syntax-introduce)) q (309089 . 3)) ((c def c (c (? . 0) q subprocess-kill)) q (376709 . 4)) ((c def c (c (? . 0) q regexp-match-positions)) q (69089 . 19)) ((c def c (c (? . 0) q bytes-copy)) q (56187 . 3)) ((c def c (c (? . 2) q exn:break:terminate)) c (? . 80)) ((c def c (c (? . 0) q prop:impersonator-of)) q (326810 . 2)) ((c form c (c (? . 1) q define/overment)) q (143820 . 3)) ((c form c (c (? . 34) q ->)) q (168606 . 9)) ((c def c (c (? . 119) q parse-command-line)) q (392211 . 15)) ((c def c (c (? . 20) q extfl>)) q (35988 . 4)) ((c def c (c (? . 2) q impersonate-procedure*)) q (321883 . 11)) ((c def c (c (? . 0) q exn:break-continuation)) c (? . 68)) ((c def c (c (? . 20) q extfl+)) q (35433 . 4)) ((c def c (c (? . 22) q assoc)) q (86261 . 5)) ((c def c (c (? . 0) q current-read-interaction)) q (313495 . 4)) ((c def c (c (? . 0) q will-execute)) q (393668 . 3)) ((c def c (c (? . 11) q putenv)) q (389306 . 4)) ((c def c (c (? . 0) q exn:fail:contract:variable-id)) c (? . 76)) ((c def c (c (? . 26) q blame-value)) q (181722 . 3)) ((c def c (c (? . 0) q current-module-name-resolver)) q (315580 . 19)) ((c def c (c (? . 0) q compiled-expression?)) q (314112 . 3)) ((c def c (c (? . 5) q dict-has-key?)) q (113258 . 4)) ((c def c (c (? . 5) q prop:dict)) q (112183 . 2)) ((c def c (c (? . 0) q syntax?)) q (229538 . 3)) ((c def c (c (? . 30) q make-shared-fxvector)) q (35207 . 4)) ((c def c (c (? . 0) q close-output-port)) q (252234 . 3)) ((c def c (c (? . 42) q append*)) q (91725 . 7)) ((c def c (c (? . 0) q srcloc?)) c (? . 8)) ((c def c (c (? . 15) q list-contract?)) q (191360 . 3)) ((c form c (c (? . 30) q for/fxvector)) q (34809 . 2)) ((c def c (c (? . 47) q place-enabled?)) q (224064 . 2)) ((c def c (c (? . 12) q contract-name)) q (191420 . 3)) ((c def c (c (? . 0) q module-compiled-imports)) q (318818 . 5)) ((c def c (c (? . 60) q trait-sum)) q (148150 . 3)) ((c def c (c (? . 5) q dict-empty?)) q (114626 . 3)) ((c def c (c (? . 0) q read-bytes-avail!)) q (280675 . 7)) ((c form c (c (? . 36) q match*)) q (194711 . 6)) ((c def c (c (? . 1) q interface?)) q (153548 . 3)) ((c form c (c (? . 66) q trace)) q (408951 . 2)) ((c def c (c (? . 0) q continuation?)) q (210014 . 3)) ((c def c (c (? . 0) q make-rectangular)) q (22419 . 4)) ((c form c (c (? . 13) q define-custom-set-types)) q (125832 . 12)) ((c def c (c (? . 0) q struct:exn:fail:contract:continuation)) c (? . 99)) ((c def c (c (? . 4) q unsafe-extfl=)) q (403042 . 4)) ((c form c (c (? . 17) q define-compound-unit/infer)) q (159417 . 5)) ((c def c (c (? . 15) q coerce-contracts)) q (180383 . 4)) ((c def c (c (? . 35) q vector-map!)) q (96391 . 4)) ((c def c (c (? . 0) q file-position*)) q (253484 . 3)) ((c def c (c (? . 2) q gen:equal+hash)) q (17868 . 2)) ((c def c (c (? . 1) q field-names)) q (154904 . 3)) ((c def c (c (? . 24) q contract-random-generate-stash)) q (194316 . 5)) ((c form c (c (? . 2) q for/or)) q (14129 . 2)) ((c def c (c (? . 35) q vector-argmax)) q (97863 . 4)) ((c def c (c (? . 0) q max)) q (20559 . 3)) ((c def c (c (? . 22) q remv)) q (85054 . 4)) ((c def c (c (? . 0) q cadr)) q (86763 . 3)) ((c def c (c (? . 4) q unsafe-flreal-part)) q (397895 . 5)) ((c def c (c (? . 34) q unsupplied-arg?)) q (174142 . 3)) ((c def c (c (? . 24) q contract-random-generate-fail?)) q (194165 . 3)) ((c def c (c (? . 0) q prefab-struct-key)) q (138184 . 3)) ((c form c (c (? . 0) q letrec-syntaxes+values)) q (11141 . 4)) ((c def c (c (? . 3) q udp-addresses)) q (373761 . 7)) ((c def c (c (? . 42) q first)) q (89336 . 3)) ((c form c (c (? . 12) q prompt-tag/c)) q (167838 . 8)) ((c def c (c (? . 65) q stream-length)) q (109999 . 3)) ((c form c (c (? . 2) q for/and)) q (14067 . 2)) ((c def c (c (? . 0) q char<?)) q (62884 . 4)) ((c def c (c (? . 0) q thread/suspend-to-kill)) q (215355 . 3)) ((c def c (c (? . 0) q peek-bytes)) q (282058 . 5)) ((c def c (c (? . 0) q bytes->string/latin-1)) q (58054 . 9)) ((c def c (c (? . 13) q list->seteqv)) q (120902 . 3)) ((c def c (c (? . 0) q chaperone-continuation-mark-key)) q (332373 . 13)) ((c def c (c (? . 0) q imag-part)) q (22651 . 3)) ((c def c (c (? . 100) q vector/c)) q (164448 . 8)) ((c def c (c (? . 0) q string<=?)) q (42026 . 4)) ((c def c (c (? . 13) q set-weak?)) q (119911 . 3)) ((c def c (c (? . 0) q make-placeholder)) q (93397 . 3)) ((c def c (c (? . 0) q string->immutable-string)) q (40260 . 3)) ((c form c (c (? . 1) q class*)) q (139552 . 59)) ((c def c (c (? . 0) q peek-bytes-avail!)) q (283267 . 14)) ((c def c (c (? . 0) q hash-ref)) q (101033 . 7)) ((c def c (c (? . 5) q dict-map)) q (114401 . 4)) ((c def c (c (? . 30) q fxxor)) q (32927 . 4)) ((c def c (c (? . 10) q read-bytes-evt)) q (276458 . 4)) ((c def c (c (? . 100) q vector-immutableof)) q (164379 . 3)) ((c def c (c (? . 35) q vector-split-at)) q (97024 . 4)) ((c form c (c (? . 17) q define-unit/contract)) q (161448 . 10)) ((c def c (c (? . 65) q stream/c)) q (111187 . 3)) ((c def c (c (? . 46) q negate)) q (130994 . 3)) ((c def c (c (? . 0) q banner)) q (389947 . 2)) ((c def c (c (? . 0) q impersonator-property?)) q (333096 . 3)) ((c def c (c (? . 0) q make-sibling-inspector)) q (335909 . 3)) ((c def c (c (? . 0) q poll-guard-evt)) q (217679 . 3)) ((c def c (c (? . 0) q ephemeron-value)) q (393246 . 4)) ((c form c (c (? . 1) q generic)) q (146861 . 2)) ((c def c (c (? . 0) q current-subprocess-custodian-mode)) q (376967 . 5)) ((c def c (c (? . 0) q call-with-semaphore/enable-break)) q (219692 . 9)) ((c def c (c (? . 5) q dict-set!)) q (112418 . 5)) ((c def c (c (? . 4) q unsafe-flexpt)) q (397592 . 4)) ((c def c (c (? . 0) q asin)) q (22208 . 3)) ((c form c (c (? . 33) q _)) q (229459 . 2)) ((c def c (c (? . 49) q file->bytes-lines)) q (357969 . 8)) ((c def c (c (? . 53) q path-only)) q (352319 . 3)) ((c form c (c (? . 2) q local-require)) q (5060 . 2)) ((c def c (c (? . 0) q current-write-relative-directory)) q (295991 . 11)) ((c def c (c (? . 70) q promise-forced?)) q (207379 . 3)) ((c def c (c (? . 10) q dup-input-port)) q (271907 . 4)) ((c def c (c (? . 0) q version)) q (389893 . 2)) ((c def c (c (? . 0) q peek-char)) q (285481 . 4)) ((c def c (c (? . 14) q make-provide-pre-transformer)) q (245944 . 5)) ((c def c (c (? . 0) q read-decimal-as-inexact)) q (292009 . 4)) ((c def c (c (? . 24) q struct-type-property/c)) q (174638 . 3)) ((c def c (c (? . 0) q thread-suspend)) q (215564 . 3)) ((c def c (c (? . 42) q sixth)) q (89641 . 3)) ((c def c (c (? . 2) q double-flonum?)) q (18985 . 3)) ((c def c (c (? . 101) q date*->seconds)) q (387033 . 4)) ((c def c (c (? . 56) q pretty-print-depth)) q (298221 . 4)) ((c def c (c (? . 0) q variable-reference->module-base-phase)) q (310271 . 3)) ((c def c (c (? . 0) q srcloc-source)) c (? . 8)) ((c def c (c (? . 0) q port-count-lines!)) q (253723 . 3)) ((c def c (c (? . 18) q prop:chaperone-contract)) q (182892 . 2)) ((c def c (c (? . 0) q local-transformer-expand)) q (237106 . 9)) ((c form c (c (? . 2) q #%plain-lambda)) q (10455 . 2)) ((c def c (c (? . 0) q read-accept-infix-dot)) q (292213 . 4)) ((c def c (c (? . 0) q port-read-handler)) q (293180 . 10)) ((c def c (c (? . 13) q set-count)) q (123694 . 3)) ((c def c (c (? . 2) q make-keyword-procedure)) q (129106 . 5)) ((c def c (c (? . 74) q string-split)) q (45357 . 9)) ((c form c (c (? . 28) q ->m)) q (149462 . 2)) ((c form c (c (? . 1) q mixin)) q (147155 . 3)) ((c def c (c (? . 0) q variable-reference->resolved-module-path)) q (309745 . 4)) ((c def c (c (? . 4) q unsafe-string-set!)) q (400534 . 5)) ((c def c (c (? . 0) q primitive?)) q (130629 . 3)) ((c form c (c (? . 40) q generator)) q (111302 . 2)) ((c def c (c (? . 0) q current-process-milliseconds)) q (385696 . 3)) ((c def c (c (? . 6) q set-eval-limits)) q (345347 . 5)) ((c def c (c (? . 10) q transplant-input-port)) q (273181 . 19)) ((c def c (c (? . 0) q impersonate-channel)) q (324985 . 13)) ((c def c (c (? . 13) q make-custom-set-types)) q (126319 . 25)) ((c form c (c (? . 2) q protect-out)) q (6166 . 2)) ((c def c (c (? . 65) q stream-first)) q (109603 . 3)) ((c def c (c (? . 4) q unsafe-extfl<)) q (403130 . 4)) ((c def c (c (? . 0) q module->imports)) q (320596 . 6)) ((c form c (c (? . 2) q for-template)) q (6461 . 2)) ((c def c (c (? . 2) q make-exn:fail:syntax:missing-module)) c (? . 44)) ((c def c (c (? . 2) q regexp-match-exact?)) q (71717 . 4)) ((c def c (c (? . 0) q current-get-interaction-input-port)) q (313340 . 4)) ((c form c (c (? . 17) q define-signature)) q (156462 . 25)) ((c def c (c (? . 11) q channel-put)) q (218538 . 4)) ((c def c (c (? . 56) q pretty-print-post-print-hook)) q (300976 . 5)) ((c def c (c (? . 13) q seteqv)) q (120051 . 3)) ((c def c (c (? . 66) q trace-call)) q (409402 . 5)) ((c def c (c (? . 30) q make-fxvector)) q (33935 . 4)) ((c def c (c (? . 0) q bytes-set!)) q (55861 . 5)) ((c def c (c (? . 13) q set/c)) q (122923 . 6)) ((c def c (c (? . 0) q raise-syntax-error)) q (200278 . 11)) ((c def c (c (? . 47) q place-location?)) q (226172 . 3)) ((c def c (c (? . 41) q spawn)) q (211794 . 3)) ((c def c (c (? . 5) q dict-update)) q (114133 . 8)) ((c def c (c (? . 0) q plumber-flush-all)) q (337136 . 3)) ((c form c (c (? . 17) q link)) q (157711 . 2)) ((c def c (c (? . 0) q regexp-match/end)) q (76222 . 20)) ((c def c (c (? . 7) q fl=)) q (28655 . 4)) ((c def c (c (? . 0) q make-struct-type)) q (133199 . 31)) ((c def c (c (? . 34) q symbols)) q (164049 . 3)) ((c def c (c (? . 2) q in-bytes)) q (104980 . 6)) ((c form c (c (? . 96) q nor)) q (18230 . 2)) ((c def c (c (? . 10) q relocate-output-port)) q (272651 . 13)) ((c def c (c (? . 0) q input-port?)) q (252001 . 3)) ((c def c (c (? . 12) q procedure-arity-includes/c)) q (167082 . 3)) ((c def c (c (? . 30) q in-fxvector)) q (34569 . 6)) ((c def c (c (? . 0) q struct:exn)) c (? . 102)) ((c form c (c (? . 1) q define/augride)) q (144076 . 3)) ((c def c (c (? . 2) q chaperone-procedure*)) q (327226 . 11)) ((c def c (c (? . 4) q unsafe-fxior)) q (394938 . 4)) ((c def c (c (? . 3) q udp-multicast-interface)) q (374561 . 3)) ((c def c (c (? . 12) q printable/c)) q (163946 . 2)) ((c def c (c (? . 0) q syntax-local-lift-expression)) q (240206 . 3)) ((c def c (c (? . 35) q vector-filter-not)) q (97547 . 4)) ((c form c (c (? . 38) q and)) q (11734 . 2)) ((c form c (c (? . 11) q define-syntax-rule)) q (229393 . 2)) ((c def c (c (? . 0) q current-inexact-milliseconds)) q (384615 . 2)) ((c def c (c (? . 0) q printf)) q (294449 . 4)) ((c def c (c (? . 9) q import)) c (? . 31)) ((c def c (c (? . 0) q exn:fail:contract:variable?)) c (? . 76)) ((c def c (c (? . 3) q udp-multicast-set-interface!)) q (374646 . 5)) ((c def c (c (? . 0) q null?)) q (83212 . 3)) ((c def c (c (? . 0) q make-bytes)) q (55378 . 4)) ((c def c (c (? . 2) q namespace-anchor?)) q (305753 . 3)) ((c def c (c (? . 30) q fx+)) q (32283 . 4)) ((c def c (c (? . 12) q syntax/c)) q (165792 . 3)) ((c def c (c (? . 0) q syntax-local-name)) q (240850 . 2)) ((c def c (c (? . 34) q or/c)) q (163030 . 3)) ((c def c (c (? . 12) q string-len/c)) q (163845 . 3)) ((c def c (c (? . 71) q prop:struct-info)) q (138919 . 2)) ((c def c (c (? . 1) q object=?)) q (153658 . 4)) ((c def c (c (? . 2) q exn:fail:contract:continuation)) c (? . 99)) ((c def c (c (? . 0) q keyword<?)) q (83043 . 4)) ((c def c (c (? . 0) q chaperone-box)) q (328898 . 12)) ((c def c (c (? . 0) q byte?)) q (55628 . 3)) ((c def c (c (? . 30) q shared-fxvector)) q (35138 . 3)) ((c def c (c (? . 26) q blame-negative)) q (181606 . 3)) ((c def c (c (? . 15) q impersonator-prop:blame)) q (183152 . 2)) ((c form c (c (? . 41) q reset0-at)) q (211640 . 2)) ((c def c (c (? . 0) q bytes-ref)) q (55762 . 4)) ((c def c (c (? . 21) q ~.v)) q (53018 . 23)) ((c def c (c (? . 0) q regexp-match)) q (66486 . 17)) ((c def c (c (? . 13) q set?)) q (119803 . 3)) ((c form c (c (? . 19) q parameterize)) q (222312 . 5)) ((c def c (c (? . 0) q read-accept-bar-quote)) q (291805 . 4)) ((c def c (c (? . 20) q extfl/)) q (35682 . 4)) ((c def c (c (? . 4) q unsafe-set-box!)) q (399308 . 4)) ((c def c (c (? . 4) q unsafe-fx-)) q (394389 . 4)) ((c form c (c (? . 2) q for*/hasheq)) q (14959 . 2)) ((c def c (c (? . 0) q boolean?)) q (17351 . 3)) ((c def c (c (? . 0) q read-bytes!)) q (280381 . 7)) ((c def c (c (? . 0) q min)) q (20611 . 3)) ((c def c (c (? . 11) q path-list-string->path-list)) q (352926 . 6)) ((c def c (c (? . 0) q string-locale-downcase)) q (44094 . 3)) ((c def c (c (? . 0) q internal-definition-context?)) q (238616 . 3)) ((c def c (c (? . 42) q split-at)) q (90277 . 4)) ((c def c (c (? . 18) q build-flat-contract-property)) q (183209 . 43)) ((c def c (c (? . 0) q call/cc)) q (209025 . 5)) ((c def c (c (? . 0) q current-prompt-read)) q (313231 . 4)) ((c def c (c (? . 42) q third)) q (89490 . 3)) ((c def c (c (? . 13) q list->mutable-set)) q (121082 . 4)) ((c form c (c (? . 13) q for*/weak-seteq)) q (122573 . 2)) ((c def c (c (? . 20) q extfl-)) q (35516 . 4)) ((c def c (c (? . 7) q flexp)) q (29751 . 3)) ((c def c (c (? . 26) q blame-positive)) q (181548 . 3)) ((c def c (c (? . 0) q close-input-port)) q (252167 . 3)) ((c def c (c (? . 0) q module-predefined?)) q (321049 . 3)) ((c def c (c (? . 23) q contract-random-generate-env?)) q (194241 . 3)) ((c def c (c (? . 0) q struct:exn:fail:read:eof)) c (? . 25)) ((c def c (c (? . 0) q make-weak-box)) q (392933 . 3)) ((c def c (c (? . 2) q in-cycle)) q (106741 . 3)) ((c def c (c (? . 19) q hash-has-key?)) q (101365 . 4)) ((c def c (c (? . 10) q port->string)) q (264844 . 3)) ((c def c (c (? . 18) q make-chaperone-contract)) q (178041 . 24)) ((c def c (c (? . 30) q fx>)) q (33348 . 4)) ((c def c (c (? . 0) q -)) q (19795 . 6)) ((c def c (c (? . 0) q current-eval)) q (310505 . 4)) ((c def c (c (? . 0) q error-value->string-handler)) q (201663 . 9)) ((c form c (c (? . 2) q planet)) q (4801 . 5)) ((c form c (c (? . 2) q define-for-syntax)) q (12365 . 3)) ((c def c (c (? . 0) q continuation-mark-key?)) q (214172 . 3)) ((c def c (c (? . 103) q unit-static-init-dependencies)) q (162413 . 7)) ((c def c (c (? . 0) q equal-secondary-hash-code)) q (104000 . 3)) ((c def c (c (? . 0) q char-symbolic?)) q (64077 . 3)) ((c def c (c (? . 2) q make-exn:fail:network)) c (? . 84)) ((c def c (c (? . 5) q make-custom-hash)) q (117447 . 14)) ((c def c (c (? . 0) q bitwise-ior)) q (22838 . 3)) ((c def c (c (? . 0) q placeholder-get)) q (93558 . 3)) ((c def c (c (? . 4) q unsafe-fl=)) q (396251 . 4)) ((c form c (c (? . 2) q #%top-interaction)) q (16762 . 2)) ((c def c (c (? . 0) q struct-info)) q (336133 . 3)) ((c def c (c (? . 1) q make-object)) q (145074 . 4)) ((c def c (c (? . 93) q raise-support-error)) q (136666 . 4)) ((c def c (c (? . 3) q udp-multicast-ttl)) q (375174 . 3)) ((c def c (c (? . 2) q call-with-output-file*)) q (256812 . 11)) ((c def c (c (? . 12) q get/build-val-first-projection)) q (181009 . 4)) ((c def c (c (? . 65) q prop:stream)) q (111143 . 2)) ((c def c (c (? . 7) q flsqrt)) q (29803 . 3)) ((c def c (c (? . 0) q string-fill!)) q (41366 . 4)) ((c form c (c (? . 2) q combine-in)) q (4407 . 2)) ((c def c (c (? . 36) q syntax-local-match-introduce)) q (196493 . 3)) ((c def c (c (? . 0) q link-exists?)) q (353475 . 3)) ((c def c (c (? . 10) q peek-string!-evt)) c (? . 73)) ((c def c (c (? . 56) q tentative-pretty-print-port-transfer)) q (301560 . 5)) ((c def c (c (? . 0) q make-hasheqv-placeholder)) q (93882 . 3)) ((c def c (c (? . 20) q extflvector-set!)) q (38125 . 5)) ((c def c (c (? . 0) q phantom-bytes?)) q (394019 . 3)) ((c def c (c (? . 0) q environment-variables-names)) q (388944 . 4)) ((c def c (c (? . 0) q real->single-flonum)) q (19607 . 3)) ((c def c (c (? . 56) q pretty-print-abbreviate-read-macros)) q (298784 . 4)) ((c form c (c (? . 2) q all-from-out)) q (5917 . 2)) ((c form c (c (? . 20) q for*/extflvector)) q (38783 . 9)) ((c def c (c (? . 0) q integer-sqrt/remainder)) q (21805 . 3)) ((c def c (c (? . 15) q contract-continuation-mark-key)) q (192239 . 2)) ((c def c (c (? . 26) q blame-replace-negative)) q (182013 . 4)) ((c def c (c (? . 0) q peek-bytes-avail!*)) q (283893 . 14)) ((c def c (c (? . 86) q engine-kill)) q (226547 . 3)) ((c def c (c (? . 0) q will-try-execute)) q (393744 . 3)) ((c def c (c (? . 0) q bitwise-bit-field)) q (23252 . 6)) ((c form c (c (? . 1) q augment)) q (142756 . 2)) ((c def c (c (? . 5) q dict-set)) q (112548 . 5)) ((c def c (c (? . 0) q path->string)) q (347819 . 3)) ((c def c (c (? . 18) q build-chaperone-contract-property)) q (185589 . 43)) ((c def c (c (? . 6) q sandbox-init-hook)) q (339442 . 4)) ((c def c (c (? . 2) q directory-list)) q (356091 . 4)) ((c form c (c (? . 2) q for/fold/derived)) q (15573 . 4)) ((c form c (c (? . 104) q quasisyntax)) q (229037 . 2)) ((c def c (c (? . 0) q print-pair-curly-braces)) q (294695 . 4)) ((c def c (c (? . 0) q syntax-span)) q (229987 . 3)) ((c def c (c (? . 0) q procedure-arity?)) q (128618 . 3)) ((c def c (c (? . 15) q coerce-chaperone-contracts)) q (180596 . 4)) ((c def c (c (? . 0) q keyword?)) q (82847 . 3)) ((c form c (c (? . 2) q #%plain-module-begin)) q (1880 . 2)) ((c def c (c (? . 47) q place-dead-evt)) q (225469 . 3)) ((c def c (c (? . 10) q convert-stream)) q (278723 . 9)) ((c def c (c (? . 0) q custom-print-quotable?)) q (303205 . 2)) ((c form c (c (? . 87) q define-serializable-struct/versions)) q (304384 . 4)) ((c def c (c (? . 6) q sandbox-network-guard)) q (342738 . 13)) ((c form c (c (? . 1) q define-member-name)) q (144669 . 2)) ((c def c (c (? . 56) q pretty-print-columns)) q (298041 . 5)) ((c def c (c (? . 0) q gcd)) q (20663 . 3)) ((c form c (c (? . 1) q field)) q (142411 . 2)) ((c form c (c (? . 17) q unit/new-import-export)) q (160151 . 6)) ((c def c (c (? . 14) q expand-export)) q (245220 . 4)) ((c def c (c (? . 0) q void?)) q (131739 . 3)) ((c def c (c (? . 0) q real?)) q (18459 . 3)) ((c def c (c (? . 2) q regexp-replace-quote)) q (82715 . 5)) ((c def c (c (? . 0) q path->directory-path)) q (349901 . 3)) ((c def c (c (? . 29) q would-be-future)) q (223469 . 3)) ((c def c (c (? . 50) q generate-temporary)) q (251353 . 3)) ((c def c (c (? . 0) q cadddr)) q (88311 . 3)) ((c def c (c (? . 0) q char->integer)) q (62455 . 3)) ((c def c (c (? . 20) q extfl->floating-point-bytes)) q (39598 . 10)) ((c form c (c (? . 1) q private*)) q (143455 . 2)) ((c def c (c (? . 0) q exit)) q (214888 . 3)) ((c form c (c (? . 36) q match-lambda*)) q (195558 . 2)) ((c form c (c (? . 66) q untrace)) q (409239 . 2)) ((c def c (c (? . 65) q gen:stream)) q (111116 . 2)) ((c def c (c (? . 0) q abort-current-continuation)) q (208381 . 5)) ((c def c (c (? . 0) q syntax-taint)) q (249049 . 3)) ((c form c (c (? . 1) q augment*)) q (143344 . 2)) ((c def c (c (? . 12) q flat-contract-predicate)) q (168518 . 3)) ((c def c (c (? . 0) q current-environment-variables)) q (387932 . 4)) ((c def c (c (? . 0) q current-load-relative-directory)) q (312610 . 5)) ((c def c (c (? . 3) q udp-send-to/enable-break)) q (369948 . 13)) ((c def c (c (? . 0) q string-locale>?)) q (43600 . 4)) ((c def c (c (? . 0) q custodian-box?)) q (335320 . 3)) ((c def c (c (? . 6) q sandbox-propagate-exceptions)) q (341275 . 4)) ((c form c (c (? . 70) q delay/strict)) q (207564 . 2)) ((c form c (c (? . 43) q splicing-let-syntaxes)) q (247874 . 2)) ((c def c (c (? . 2) q procedure-rename)) q (127775 . 4)) ((c def c (c (? . 19) q hash-ref!)) q (101257 . 5)) ((c def c (c (? . 0) q exn:fail?)) c (? . 67)) ((c def c (c (? . 0) q struct-type-info)) q (336216 . 11)) ((c form c (c (? . 13) q gen:set)) q (123195 . 2)) ((c def c (c (? . 57) q nan?)) q (28214 . 3)) ((c def c (c (? . 10) q input-port-append)) q (266570 . 4)) ((c def c (c (? . 20) q extfltan)) q (36782 . 3)) ((c form c (c (? . 37) q runtime-paths)) q (356948 . 2)) ((c def c (c (? . 0) q log-level-evt)) q (383863 . 3)) ((c def c (c (? . 0) q raise-type-error)) q (199392 . 10)) ((c def c (c (? . 49) q make-temporary-file)) q (361570 . 7)) ((c def c (c (? . 0) q hasheqv)) q (99285 . 4)) ((c def c (c (? . 53) q some-system-path->string)) q (352515 . 3)) ((c def c (c (? . 0) q peek-char-or-special)) q (285841 . 5)) ((c form c (c (? . 34) q flat-rec-contract)) q (168218 . 2)) ((c def c (c (? . 105) q new-∃/c)) q (174325 . 3)) ((c form c (c (? . 17) q define-unit-from-context)) q (160096 . 2)) ((c def c (c (? . 20) q in-extflvector)) q (38468 . 6)) ((c def c (c (? . 7) q in-flvector)) q (31520 . 6)) ((c form c (c (? . 13) q for*/weak-seteqv)) q (122629 . 2)) ((c def c (c (? . 0) q thread-receive-evt)) q (216658 . 2)) ((c form c (c (? . 38) q let)) q (10500 . 3)) ((c def c (c (? . 0) q hash-eq?)) q (98928 . 3)) ((c def c (c (? . 66) q current-trace-print-results)) q (410107 . 10)) ((c def c (c (? . 2) q in-input-port-chars)) q (105430 . 3)) ((c def c (c (? . 0) q local-expand/capture-lifts)) q (237518 . 11)) ((c def c (c (? . 0) q string-copy!)) q (40934 . 11)) ((c def c (c (? . 47) q prop:place-location)) q (226120 . 2)) ((c form c (c (? . 36) q match-define-values)) q (196021 . 2)) ((c def c (c (? . 0) q file-size)) q (355087 . 3)) ((c def c (c (? . 0) q byte-regexp?)) q (65760 . 3)) ((c def c (c (? . 0) q <)) q (21403 . 4)) ((c form c (c (? . 2) q provide)) q (5102 . 20)) ((c def c (c (? . 6) q sandbox-error-output)) q (340527 . 14)) ((c form c (c (? . 60) q trait-exclude-field)) q (148251 . 2)) ((c form c (c (? . 1) q pubment*)) q (143155 . 2)) ((c form c (c (? . 37) q define-runtime-path)) q (356663 . 2)) ((c form c (c (? . 17) q define-unit/new-import-export)) q (160332 . 6)) ((c def c (c (? . 7) q fl*)) q (28461 . 4)) ((c def c (c (? . 36) q prop:legacy-match-expander)) q (196305 . 2)) ((c def c (c (? . 2) q real->decimal-string)) q (25189 . 4)) ((c def c (c (? . 0) q port-file-unlock)) q (258213 . 3)) ((c def c (c (? . 0) q make-phantom-bytes)) q (394079 . 3)) ((c def c (c (? . 4) q unsafe-bytes-length)) q (400673 . 3)) ((c def c (c (? . 53) q simple-form-path)) q (352443 . 3)) ((c def c (c (? . 10) q port->lines)) q (265026 . 5)) ((c def c (c (? . 28) q is-a?/c)) q (152786 . 3)) ((c def c (c (? . 30) q fxabs)) q (32729 . 3)) ((c def c (c (? . 100) q vector-immutable/c)) q (164751 . 3)) ((c def c (c (? . 10) q port->bytes)) q (264936 . 3)) ((c def c (c (? . 7) q fltan)) q (29488 . 3)) ((c def c (c (? . 0) q hash-iterate-value)) q (103628 . 4)) ((c def c (c (? . 42) q count)) q (92338 . 4)) ((c def c (c (? . 71) q struct:struct-info)) q (138877 . 2)) ((c def c (c (? . 42) q in-permutations)) q (92999 . 3)) ((c def c (c (? . 4) q unsafe-fx>)) q (395481 . 4)) ((c def c (c (? . 2) q regexp-replace*)) q (81482 . 15)) ((c def c (c (? . 0) q open-output-string)) q (258823 . 3)) ((c def c (c (? . 0) q bytes->string/utf-8)) q (57448 . 6)) ((c def c (c (? . 9) q import-mode)) c (? . 31)) ((c def c (c (? . 13) q set-copy-clear)) q (124096 . 3)) ((c def c (c (? . 0) q port-count-lines-enabled)) q (254410 . 4)) ((c def c (c (? . 4) q unsafe-bytes-set!)) q (400831 . 5)) ((c form c (c (? . 1) q augride)) q (142793 . 2)) ((c def c (c (? . 4) q unsafe-set-mcar!)) q (398745 . 4)) ((c def c (c (? . 0) q date-week-day)) c (? . 32)) ((c def c (c (? . 13) q set-union)) q (124341 . 4)) ((c form c (c (? . 43) q splicing-letrec-values)) q (247787 . 2)) ((c def c (c (? . 7) q fl>=)) q (28944 . 4)) ((c def c (c (? . 0) q procedure-arity-includes?)) q (128680 . 5)) ((c def c (c (? . 0) q continuation-mark-set?)) q (214240 . 3)) ((c def c (c (? . 0) q arithmetic-shift)) q (23474 . 4)) ((c def c (c (? . 0) q eval-syntax)) q (310759 . 4)) ((c def c (c (? . 0) q char-graphic?)) q (64212 . 3)) ((c def c (c (? . 0) q syntax-local-value)) q (239548 . 8)) ((c def c (c (? . 0) q struct:exn:break:terminate)) c (? . 80)) ((c def c (c (? . 5) q dict-count)) q (114689 . 3)) ((c def c (c (? . 12) q >/c)) q (163379 . 3)) ((c def c (c (? . 13) q weak-set)) q (120527 . 3)) ((c def c (c (? . 0) q syntax-line)) q (229708 . 3)) ((c def c (c (? . 0) q print-syntax-width)) q (295795 . 5)) ((c def c (c (? . 0) q exn?)) c (? . 102)) ((c form c (c (? . 1) q define-serializable-class)) q (153249 . 3)) ((c form c (c (? . 2) q for*/product)) q (15280 . 2)) ((c def c (c (? . 35) q vector-take)) q (96588 . 4)) ((c def c (c (? . 0) q hash-iterate-first)) q (103276 . 4)) ((c def c (c (? . 0) q semaphore-try-wait?)) q (219060 . 3)) ((c def c (c (? . 35) q vector-drop-right)) q (96912 . 4)) ((c def c (c (? . 12) q <=/c)) q (163434 . 3)) ((c def c (c (? . 4) q unsafe-fx*)) q (394467 . 4)) ((c def c (c (? . 0) q box-immutable)) q (98366 . 3)) ((c def c (c (? . 24) q contract-exercise)) q (193886 . 3)) ((c form c (c (? . 2) q for/first)) q (14393 . 2)) ((c def c (c (? . 0) q namespace?)) q (305509 . 3)) ((c form c (c (? . 28) q case->m)) q (149562 . 2)) ((c def c (c (? . 0) q caddr)) q (87201 . 3)) ((c def c (c (? . 0) q alarm-evt)) q (217985 . 3)) ((c def c (c (? . 49) q make-lock-file-name)) q (365199 . 6)) ((c def c (c (? . 0) q open-output-bytes)) q (258713 . 3)) ((c def c (c (? . 0) q string)) q (40198 . 3)) ((c def c (c (? . 0) q make-custodian-box)) q (335220 . 4)) ((c def c (c (? . 15) q contract-stronger?)) q (190827 . 4)) ((c form c (c (? . 20) q for/extflvector)) q (38714 . 2)) ((c def c (c (? . 0) q date-minute)) c (? . 32)) ((c def c (c (? . 13) q set-equal?)) q (119640 . 3)) ((c def c (c (? . 0) q char-utf-8-length)) q (62712 . 3)) ((c def c (c (? . 42) q takef-right)) q (90954 . 4)) ((c def c (c (? . 0) q bytes-length)) q (55679 . 3)) ((c def c (c (? . 4) q unsafe-flfloor)) q (396869 . 3)) ((c def c (c (? . 10) q make-pipe-with-specials)) q (269499 . 7)) ((c def c (c (? . 60) q trait?)) q (148021 . 3)) ((c form c (c (? . 111) q define-opt/c)) q (192196 . 2)) ((c def c (c (? . 0) q make-directory)) q (355949 . 3)) ((c def c (c (? . 42) q seventh)) q (89691 . 3)) ((c def c (c (? . 51) q sequence-andmap)) q (108556 . 4)) ((c def c (c (? . 6) q evaluator-alive?)) q (344985 . 3)) ((c def c (c (? . 13) q set-eq?)) q (119750 . 3)) ((c def c (c (? . 0) q impersonate-box)) q (323547 . 12)) ((c def c (c (? . 0) q make-semaphore)) q (218827 . 3)) ((c form c (c (? . 34) q ->i)) q (169540 . 49)) ((c form c (c (? . 38) q when)) q (12970 . 2)) ((c form c (c (? . 106) q filtered-out)) q (9463 . 2)) ((c def c (c (? . 0) q call-with-values)) q (197000 . 4)) ((c def c (c (? . 0) q impersonate-struct)) q (322264 . 17)) ((c def c (c (? . 0) q thread-send)) q (216384 . 6)) ((c def c (c (? . 0) q string>?)) q (42122 . 4)) ((c def c (c (? . 0) q namespace-module-registry)) q (308837 . 3)) ((c def c (c (? . 0) q unbox)) q (98442 . 3)) ((c form c (c (? . 1) q set-field!)) q (146557 . 2)) ((c def c (c (? . 0) q vector-immutable)) q (94560 . 4)) ((c def c (c (? . 4) q unsafe-cons-list)) q (398903 . 4)) ((c def c (c (? . 4) q unsafe-fxmax)) q (395800 . 4)) ((c def c (c (? . 30) q fxvector-copy)) q (34378 . 5)) ((c def c (c (? . 9) q import-source?)) c (? . 64)) ((c def c (c (? . 0) q get-output-string)) q (259283 . 3)) ((c def c (c (? . 65) q stream-empty?)) q (109542 . 3)) ((c def c (c (? . 0) q struct:exn:fail:filesystem)) c (? . 45)) ((c def c (c (? . 0) q syntax-tainted?)) q (248495 . 3)) ((c def c (c (? . 42) q split-at-right)) q (90842 . 4)) ((c def c (c (? . 0) q list-tail)) q (83931 . 4)) ((c def c (c (? . 65) q stream-for-each)) q (110616 . 4)) ((c form c (c (? . 116) q with-contract)) q (175463 . 12)) ((c def c (c (? . 0) q char-title-case?)) q (63944 . 3)) ((c def c (c (? . 51) q sequence-ref)) q (108197 . 4)) ((c def c (c (? . 7) q flsin)) q (29384 . 3)) ((c form c (c (? . 0) q #%require)) q (6540 . 33)) ((c def c (c (? . 6) q sandbox-make-namespace)) q (341676 . 2)) ((c def c (c (? . 0) q symbol-unreadable?)) q (65117 . 3)) ((c form c (c (? . 1) q inherit)) q (142926 . 2)) ((c def c (c (? . 0) q string->list)) q (41553 . 3)) ((c def c (c (? . 1) q exn:fail:object)) c (? . 89)) ((c def c (c (? . 19) q break-parameterization?)) q (214819 . 3)) ((c def c (c (? . 2) q in-lines)) q (105504 . 5)) ((c form c (c (? . 41) q control0-at)) q (211688 . 2)) ((c def c (c (? . 6) q set-eval-handler)) q (345548 . 4)) ((c def c (c (? . 26) q blame-original?)) q (181890 . 3)) ((c def c (c (? . 30) q fxmin)) q (33566 . 4)) ((c form c (c (? . 2) q for*/sum)) q (15217 . 2)) ((c def c (c (? . 42) q last-pair)) q (89943 . 3)) ((c def c (c (? . 0) q rational?)) q (18510 . 3)) ((c def c (c (? . 15) q contract-custom-write-property-proc)) q (192303 . 7)) ((c def c (c (? . 0) q exn:fail:unsupported?)) c (? . 91)) ((c def c (c (? . 10) q with-output-to-string)) q (265994 . 3)) ((c def c (c (? . 0) q procedure-extract-target)) q (130027 . 3)) ((c def c (c (? . 4) q unsafe-fxvector-ref)) q (401039 . 4)) ((c def c (c (? . 29) q processor-count)) q (223541 . 2)) ((c def c (c (? . 96) q symbol=?)) q (17996 . 4)) ((c def c (c (? . 50) q wrong-syntax)) q (250749 . 5)) ((c def c (c (? . 56) q pretty-print)) q (297440 . 5)) ((c def c (c (? . 0) q identifier-binding-symbol)) q (235393 . 6)) ((c def c (c (? . 0) q exn:break:hang-up?)) c (? . 48)) ((c def c (c (? . 0) q executable-yield-handler)) q (215059 . 4)) ((c form c (c (? . 46) q thunk*)) q (130966 . 2)) ((c form c (c (? . 38) q quasiquote)) q (16667 . 2)) ((c def c (c (? . 0) q syntax-local-get-shadower)) q (241446 . 3)) ((c def c (c (? . 49) q group-write-bit)) q (365553 . 2)) ((c def c (c (? . 4) q unsafe-extflvector-set!)) q (404969 . 5)) ((c form c (c (? . 13) q for/set)) q (121705 . 2)) ((c def c (c (? . 35) q vector-argmin)) q (97763 . 4)) ((c def c (c (? . 4) q unsafe-fxlshift)) q (395157 . 4)) ((c def c (c (? . 61) q system)) q (377584 . 4)) ((c form c (c (? . 1) q super-new)) q (145398 . 2)) ((c def c (c (? . 4) q unsafe-fxrshift)) q (395240 . 4)) ((c def c (c (? . 0) q chaperone-evt)) q (330852 . 7)) ((c form c (c (? . 65) q stream-cons)) q (109782 . 2)) ((c form c (c (? . 66) q trace-let)) q (409183 . 2)) ((c def c (c (? . 49) q write-to-file)) q (358802 . 11)) ((c form c (c (? . 17) q init-depend)) q (157789 . 2)) ((c def c (c (? . 0) q denominator)) q (21177 . 3)) ((c def c (c (? . 0) q string-utf-8-length)) q (59270 . 5)) ((c def c (c (? . 11) q find-library-collection-paths)) q (405553 . 5)) ((c def c (c (? . 0) q cdadr)) q (87365 . 3)) ((c form c (c (? . 2) q for/fold)) q (14520 . 3)) ((c def c (c (? . 22) q sort)) q (85406 . 9)) ((c def c (c (? . 12) q natural-number/c)) q (163803 . 2)) ((c def c (c (? . 2) q exn:fail:read)) c (? . 97)) ((c def c (c (? . 17) q unit?)) q (161195 . 3)) ((c def c (c (? . 0) q byte-pregexp)) q (66067 . 3)) ((c def c (c (? . 65) q stream->list)) q (109942 . 3)) ((c def c (c (? . 0) q string-locale<?)) q (43498 . 4)) ((c def c (c (? . 14) q syntax-local-provide-certifier)) q (246630 . 4)) ((c def c (c (? . 0) q namespace-require)) q (307491 . 3)) ((c def c (c (? . 0) q struct:exn:fail:contract:divide-by-zero)) c (? . 107)) ((c form c (c (? . 0) q let-values)) q (10699 . 2)) ((c def c (c (? . 11) q normal-case-path)) q (350454 . 3)) ((c def c (c (? . 56) q pretty-print-size-hook)) q (300320 . 9)) ((c def c (c (? . 28) q instanceof/c)) q (150062 . 3)) ((c def c (c (? . 54) q for-each)) q (84469 . 4)) ((c def c (c (? . 0) q hash-weak?)) q (98988 . 3)) ((c def c (c (? . 0) q load-on-demand-enabled)) q (314664 . 4)) ((c def c (c (? . 61) q string-no-nuls?)) q (381954 . 3)) ((c def c (c (? . 0) q make-environment-variables)) q (388163 . 5)) ((c def c (c (? . 105) q new-∀/c)) q (174240 . 3)) ((c def c (c (? . 42) q partition)) q (92447 . 4)) ((c def c (c (? . 13) q list->set)) q (120812 . 3)) ((c def c (c (? . 1) q object%)) q (139527 . 2)) ((c def c (c (? . 0) q filesystem-change-evt)) q (356365 . 6)) ((c def c (c (? . 4) q unsafe-extflacos)) q (404226 . 3)) ((c def c (c (? . 0) q cdar)) q (86827 . 3)) ((c def c (c (? . 0) q semaphore-peek-evt?)) q (219303 . 3)) ((c def c (c (? . 13) q set=?)) q (125213 . 4)) ((c def c (c (? . 29) q fsemaphore-post)) q (223746 . 3)) ((c def c (c (? . 7) q fl-)) q (28390 . 4)) ((c def c (c (? . 4) q unsafe-struct*-ref)) q (402392 . 4)) ((c def c (c (? . 0) q raise-result-error)) q (198062 . 13)) ((c form c (c (? . 36) q match-lambda)) q (195523 . 2)) ((c def c (c (? . 0) q exn:fail:syntax-exprs)) c (? . 108)) ((c def c (c (? . 0) q current-seconds)) q (384567 . 2)) ((c def c (c (? . 20) q extflmin)) q (36233 . 4)) ((c form c (c (? . 19) q log-error)) q (384002 . 3)) ((c def c (c (? . 4) q unsafe-fxvector-set!)) q (401128 . 5)) ((c def c (c (? . 46) q arity-includes?)) q (131637 . 4)) ((c def c (c (? . 41) q call/comp)) q (210698 . 5)) ((c def c (c (? . 0) q sleep)) q (215943 . 3)) ((c def c (c (? . 6) q get-error-output)) c (? . 109)) ((c def c (c (? . 4) q unsafe-list-tail)) q (399127 . 4)) ((c def c (c (? . 4) q unsafe-vector*-ref)) q (400057 . 4)) ((c def c (c (? . 0) q read-language)) q (291073 . 5)) ((c def c (c (? . 2) q procedure-arity)) q (128537 . 3)) ((c def c (c (? . 2) q namespace-anchor->namespace)) q (305909 . 3)) ((c def c (c (? . 4) q unsafe-mcdr)) q (398690 . 3)) ((c def c (c (? . 3) q udp-connected?)) q (372364 . 3)) ((c def c (c (? . 0) q print-mpair-curly-braces)) q (294805 . 4)) ((c form c (c (? . 38) q let*)) q (10599 . 2)) ((c form c (c (? . 19) q set!-values)) q (13070 . 2)) ((c def c (c (? . 28) q subclass?/c)) q (152962 . 3)) ((c def c (c (? . 10) q special-filter-input-port)) q (275950 . 8)) ((c def c (c (? . 110) q syntax-procedure-alias-property)) q (246754 . 8)) ((c form c (c (? . 43) q splicing-local)) q (247974 . 2)) ((c def c (c (? . 42) q dropf-right)) q (91042 . 4)) ((c form c (c (? . 1) q class/derived)) q (144328 . 5)) ((c def c (c (? . 0) q subprocess-pid)) q (376814 . 3)) ((c def c (c (? . 14) q export-orig-stx)) c (? . 63)) ((c def c (c (? . 2) q regexp-try-match)) q (68311 . 17)) ((c def c (c (? . 49) q pathlist-closure)) q (360716 . 6)) ((c def c (c (? . 0) q thread-try-receive)) q (216616 . 2)) ((c def c (c (? . 0) q system-type)) q (389508 . 5)) ((c def c (c (? . 10) q peek-bytes-avail!-evt)) c (? . 73)) ((c def c (c (? . 5) q dict-iterate-first)) q (112928 . 3)) ((c def c (c (? . 0) q make-known-char-range-list)) q (64549 . 5)) ((c def c (c (? . 3) q udp-multicast-set-ttl!)) q (375069 . 4)) ((c def c (c (? . 24) q make-proj-contract)) q (192553 . 15)) ((c def c (c (? . 0) q box?)) q (98271 . 3)) ((c def c (c (? . 96) q true)) q (17947 . 2)) ((c def c (c (? . 2) q make-exn:break:hang-up)) c (? . 48)) ((c def c (c (? . 0) q liberal-define-context?)) q (242944 . 3)) ((c def c (c (? . 2) q hash-values)) q (102868 . 3)) ((c def c (c (? . 0) q read-char-or-special)) q (285229 . 3)) ((c form c (c (? . 111) q opt/c)) q (192102 . 5)) ((c def c (c (? . 0) q exn:fail:network:errno?)) c (? . 95)) ((c def c (c (? . 35) q vector-take-right)) q (96694 . 4)) ((c def c (c (? . 2) q stop-before)) q (107027 . 4)) ((c form c (c (? . 1) q this)) q (142287 . 2)) ((c def c (c (? . 0) q procedure-struct-type?)) q (129946 . 3)) ((c form c (c (? . 36) q match-let*)) q (195683 . 2)) ((c def c (c (? . 2) q exn)) c (? . 102)) ((c def c (c (? . 4) q unsafe-flround)) q (396808 . 3)) ((c def c (c (? . 0) q box)) q (98321 . 3)) ((c def c (c (? . 4) q unsafe-fxremainder)) q (394630 . 4)) ((c def c (c (? . 53) q find-relative-path)) q (351721 . 8)) ((c form c (c (? . 60) q trait-exclude)) q (148212 . 2)) ((c def c (c (? . 49) q group-execute-bit)) q (365585 . 2)) ((c def c (c (? . 9) q make-import)) c (? . 31)) ((c def c (c (? . 16) q tcp-accept)) q (366831 . 3)) ((c def c (c (? . 2) q make-exn:fail:contract:non-fixnum-result)) c (? . 98)) ((c def c (c (? . 0) q current-locale)) q (251878 . 4)) ((c def c (c (? . 0) q thread)) q (215200 . 3)) ((c def c (c (? . 0) q file-stream-port?)) q (252763 . 3)) ((c form c (c (? . 70) q delay/idle)) q (207739 . 8)) ((c def c (c (? . 0) q file-position)) q (253284 . 6)) ((c def c (c (? . 0) q module-path-index?)) q (317036 . 3)) ((c def c (c (? . 0) q set-box!)) q (98493 . 4)) ((c def c (c (? . 5) q dict->list)) q (115064 . 3)) ((c def c (c (? . 42) q takef)) q (90383 . 4)) ((c form c (c (? . 2) q rename-in)) q (4349 . 2)) ((c def c (c (? . 0) q string-locale=?)) q (43396 . 4)) ((c def c (c (? . 5) q dict-for-each)) q (114517 . 4)) ((c form c (c (? . 93) q define-generics)) q (135927 . 21)) ((c form c (c (? . 1) q field-bound?)) q (146722 . 2)) ((c def c (c (? . 15) q coerce-flat-contracts)) q (180817 . 4)) ((c form c (c (? . 13) q for*/mutable-set)) q (122179 . 2)) ((c form c (c (? . 17) q contracted)) q (157455 . 2)) ((c def c (c (? . 56) q pretty-print-newline)) q (299691 . 4)) ((c def c (c (? . 0) q <=)) q (21475 . 4)) ((c def c (c (? . 14) q prop:provide-pre-transformer)) q (246179 . 2)) ((c def c (c (? . 0) q use-user-specific-search-paths)) q (407856 . 4)) ((c def c (c (? . 2) q in-directory)) q (106144 . 5)) ((c def c (c (? . 0) q make-security-guard)) q (333380 . 16)) ((c def c (c (? . 7) q fl<=)) q (28871 . 4)) ((c def c (c (? . 7) q fl/)) q (28532 . 4)) ((c def c (c (? . 4) q unsafe-extflexp)) q (404432 . 3)) ((c form c (c (? . 2) q for/last)) q (14457 . 2)) ((c def c (c (? . 0) q handle-evt)) q (217395 . 4)) ((c def c (c (? . 0) q make-readtable)) q (301926 . 13)) ((c def c (c (? . 0) q current-milliseconds)) q (385643 . 2)) ((c def c (c (? . 28) q mixin-contract)) q (152653 . 2)) ((c form c (c (? . 2) q #%plain-app)) q (9806 . 3)) ((c form c (c (? . 36) q ==)) q (196860 . 3)) ((c def c (c (? . 0) q exn-continuation-marks)) c (? . 102)) ((c def c (c (? . 9) q struct:import-source)) c (? . 64)) ((c def c (c (? . 11) q read-eval-print-loop)) q (313189 . 2)) ((c def c (c (? . 0) q thread-running?)) q (216009 . 3)) ((c def c (c (? . 0) q make-shared-bytes)) q (56990 . 4)) ((c def c (c (? . 30) q fxmax)) q (33639 . 4)) ((c def c (c (? . 12) q flat-contract)) q (168424 . 3)) ((c def c (c (? . 2) q stop-after)) q (107133 . 4)) ((c def c (c (? . 42) q tenth)) q (89844 . 3)) ((c form c (c (? . 112) q define-module-boundary-contract)) q (176496 . 12)) ((c def c (c (? . 42) q drop-right)) q (90741 . 4)) ((c def c (c (? . 19) q hash-update)) q (101870 . 9)) ((c def c (c (? . 11) q string-environment-variable-name?)) q (389429 . 3)) ((c form c (c (? . 1) q rename-inner)) q (143085 . 2)) ((c def c (c (? . 0) q continuation-mark-set->list*)) q (213026 . 10)) ((c def c (c (? . 57) q exact-ceiling)) q (27974 . 3)) ((c form c (c (? . 46) q thunk)) q (130937 . 2)) ((c def c (c (? . 0) q compiled-module-expression?)) q (317732 . 3)) ((c def c (c (? . 0) q impersonator-prop:application-mark)) q (333251 . 2)) ((c def c (c (? . 50) q internal-definition-context-apply)) q (251445 . 5)) ((c def c (c (? . 0) q bytes-append)) q (56782 . 3)) ((c def c (c (? . 0) q log-receiver?)) q (384292 . 3)) ((c def c (c (? . 0) q syntax-property)) q (248032 . 8)) ((c def c (c (? . 0) q system-idle-evt)) q (217947 . 2)) ((c def c (c (? . 0) q pregexp)) q (65934 . 3)) ((c def c (c (? . 49) q preferences-lock-file-mode)) q (363585 . 2)) ((c def c (c (? . 2) q make-exn:fail:read)) c (? . 97)) ((c def c (c (? . 0) q syntax-local-lift-values-expression)) q (240289 . 5)) ((c form c (c (? . 41) q shift-at)) q (211409 . 2)) ((c def c (c (? . 0) q chaperone-struct)) q (327594 . 18)) ((c def c (c (? . 0) q bytes->string/locale)) q (57696 . 9)) ((c def c (c (? . 2) q call-with-input-file)) q (255723 . 7)) ((c form c (c (? . 2) q for*/vector)) q (14815 . 2)) ((c def c (c (? . 0) q struct-type?)) q (137835 . 3)) ((c def c (c (? . 0) q make-ephemeron)) q (393161 . 4)) ((c def c (c (? . 40) q yield)) q (111342 . 3)) ((c def c (c (? . 2) q procedure-reduce-keyword-arity)) q (129350 . 10)) ((c def c (c (? . 0) q syntax-track-origin)) q (248291 . 7)) ((c form c (c (? . 1) q send/keyword-apply)) q (145653 . 4)) ((c def c (c (? . 93) q exn:fail:support)) c (? . 94)) ((c form c (c (? . 113) q hash/dc)) q (167510 . 7)) ((c def c (c (? . 0) q system-language+country)) q (389732 . 2)) ((c def c (c (? . 0) q vector->values)) q (95787 . 5)) ((c def c (c (? . 14) q export)) c (? . 63)) ((c def c (c (? . 0) q byte-ready?)) q (286805 . 3)) ((c def c (c (? . 0) q read/recursive)) q (290353 . 6)) ((c def c (c (? . 10) q call-with-input-bytes)) q (266259 . 4)) ((c def c (c (? . 2) q procedure-keywords)) q (128961 . 4)) ((c def c (c (? . 0) q gensym)) q (65469 . 3)) ((c form c (c (? . 66) q trace-lambda)) q (409135 . 2)) ((c def c (c (? . 1) q dynamic-set-field!)) q (146597 . 5)) ((c form c (c (? . 104) q quasisyntax/loc)) q (229165 . 2)) ((c def c (c (? . 30) q fx->fl)) q (33712 . 3)) ((c def c (c (? . 53) q filename-extension)) q (351603 . 3)) ((c form c (c (? . 19) q time)) q (386085 . 2)) ((c def c (c (? . 0) q exn:fail:filesystem:version?)) c (? . 114)) ((c def c (c (? . 7) q flcos)) q (29436 . 3)) ((c def c (c (? . 14) q pre-expand-export)) q (245352 . 4)) ((c def c (c (? . 0) q syntax-original?)) q (230080 . 3)) ((c def c (c (? . 0) q write)) q (293539 . 4)) ((c def c (c (? . 51) q sequence-filter)) q (109093 . 4)) ((c def c (c (? . 20) q floating-point-bytes->extfl)) q (39188 . 9)) ((c def c (c (? . 0) q bytes>?)) q (57352 . 4)) ((c def c (c (? . 42) q remove-duplicates)) q (91943 . 7)) ((c form c (c (? . 66) q trace-define)) q (408975 . 3)) ((c def c (c (? . 7) q fl+)) q (28319 . 4)) ((c def c (c (? . 21) q ~s)) q (48371 . 23)) ((c def c (c (? . 0) q exn:fail:contract:non-fixnum-result?)) c (? . 98)) ((c def c (c (? . 0) q make-inspector)) q (335800 . 3)) ((c def c (c (? . 69) q impersonate-async-channel)) q (220648 . 13)) ((c def c (c (? . 0) q syntax-arm)) q (248562 . 5)) ((c def c (c (? . 51) q sequence-count)) q (108987 . 4)) ((c def c (c (? . 2) q exn:fail:filesystem:errno)) c (? . 115)) ((c def c (c (? . 0) q exn:fail:contract:continuation?)) c (? . 99)) ((c def c (c (? . 0) q bytes->path)) q (347679 . 4)) ((c def c (c (? . 0) q struct:exn:fail:syntax)) c (? . 108)) ((c def c (c (? . 4) q unsafe-fl>)) q (396409 . 4)) ((c def c (c (? . 2) q exn:fail:unsupported)) c (? . 91)) ((c def c (c (? . 0) q file-or-directory-permissions)) q (354558 . 11)) ((c def c (c (? . 20) q extflvector?)) q (37656 . 3)) ((c def c (c (? . 49) q fold-files)) q (360920 . 12)) ((c form c (c (? . 0) q begin)) q (12859 . 3)) ((c def c (c (? . 0) q uncaught-exception-handler)) q (200803 . 4)) ((c form c (c (? . 1) q public-final*)) q (143190 . 2)) ((c def c (c (? . 47) q place-channel-get)) q (225866 . 3)) ((c def c (c (? . 0) q regexp-match-peek-positions-immediate/end)) q (79013 . 22)) ((c form c (c (? . 30) q for*/fxvector)) q (34875 . 9)) ((c def c (c (? . 0) q syntax-local-expand-expression)) q (237016 . 3)) ((c form c (c (? . 1) q pubment)) q (142557 . 2)) ((c def c (c (? . 7) q flrandom)) q (30654 . 3)) ((c def c (c (? . 0) q use-collection-link-paths)) q (407980 . 4)) ((c def c (c (? . 13) q mutable-set)) q (120221 . 4)) ((c def c (c (? . 56) q pretty-print-print-hook)) q (300606 . 5)) ((c def c (c (? . 20) q make-extflvector)) q (37785 . 4)) ((c def c (c (? . 56) q pretty-print-print-line)) q (299815 . 15)) ((c def c (c (? . 4) q unsafe-fxmin)) q (395720 . 4)) ((c def c (c (? . 0) q real->double-flonum)) q (19678 . 3)) ((c def c (c (? . 0) q make-hash-placeholder)) q (93688 . 3)) ((c form c (c (? . 13) q for*/mutable-seteq)) q (122236 . 2)) ((c def c (c (? . 5) q make-custom-hash-types)) q (116120 . 24)) ((c def c (c (? . 0) q prop:set!-transformer)) q (235922 . 2)) ((c def c (c (? . 4) q unsafe-flvector-length)) q (401237 . 3)) ((c def c (c (? . 0) q compile-context-preservation-enabled)) q (314432 . 4)) ((c def c (c (? . 0) q syntax-local-make-delta-introducer)) q (242284 . 4)) ((c def c (c (? . 2) q sequence?)) q (104070 . 3)) ((c def c (c (? . 65) q stream?)) q (109489 . 3)) ((c def c (c (? . 5) q dict-can-remove-keys?)) q (112030 . 3)) ((c def c (c (? . 0) q exn:fail:filesystem:errno?)) c (? . 115)) ((c form c (c (? . 2) q define-struct/derived)) q (133096 . 3)) ((c form c (c (? . 2) q for/hasheqv)) q (14001 . 2)) ((c form c (c (? . 13) q for*/mutable-seteqv)) q (122295 . 2)) ((c def c (c (? . 0) q cdaddr)) q (88711 . 3)) ((c def c (c (? . 0) q chaperone-vector)) q (328380 . 12)) ((c def c (c (? . 0) q read-string)) q (279747 . 4)) ((c form c (c (? . 2) q for*/hasheqv)) q (15025 . 2)) ((c def c (c (? . 101) q date->string)) q (386148 . 4)) ((c form c (c (? . 39) q filtered-in)) q (9183 . 2)) ((c form c (c (? . 116) q define-struct/contract)) q (176073 . 6)) ((c def c (c (? . 2) q with-output-to-file)) q (257598 . 11)) ((c def c (c (? . 7) q flacos)) q (29593 . 3)) ((c def c (c (? . 0) q namespace-undefine-variable!)) q (307173 . 5)) ((c def c (c (? . 124) q syntax-local-require-introduce)) q (12598 . 3)) ((c def c (c (? . 65) q stream-andmap)) q (110415 . 4)) ((c form c (c (? . 1) q send/apply)) q (145587 . 2)) ((c def c (c (? . 0) q port-print-handler)) q (296937 . 7)) ((c form c (c (? . 0) q #%stratified-body)) q (16831 . 2)) ((c def c (c (? . 57) q exact-truncate)) q (28043 . 3)) ((c def c (c (? . 3) q udp-bind!)) q (367981 . 9)) ((c def c (c (? . 71) q extract-struct-info)) q (138785 . 3)) ((c def c (c (? . 13) q set-add!)) q (123380 . 4)) ((c def c (c (? . 20) q extfl<)) q (35907 . 4)) ((c def c (c (? . 0) q impersonator?)) q (321155 . 3)) ((c def c (c (? . 13) q set-subtract)) q (124763 . 4)) ((c def c (c (? . 0) q char-titlecase)) q (64871 . 3)) ((c def c (c (? . 71) q checked-struct-info?)) q (138616 . 3)) ((q form ((lib "racket/help.rkt") help)) q (408094 . 6)) ((c def c (c (? . 0) q exn:fail:filesystem:errno-errno)) c (? . 115)) ((c def c (c (? . 65) q empty-stream)) q (109911 . 2)) ((c def c (c (? . 0) q expand-syntax)) q (249189 . 3)) ((c def c (c (? . 9) q import-source-mode)) c (? . 64)) ((c def c (c (? . 0) q sqrt)) q (21693 . 3)) ((c form c (c (? . 2) q for*)) q (14616 . 2)) ((c def c (c (? . 0) q file-exists?)) q (353404 . 3)) ((c def c (c (? . 0) q thread-wait)) q (216130 . 3)) ((c def c (c (? . 0) q make-vector)) q (94394 . 4)) ((c def c (c (? . 9) q convert-relative-module-path)) q (244648 . 10)) ((c def c (c (? . 0) q expand-to-top-form)) q (249404 . 3)) ((c def c (c (? . 4) q unsafe-u16vector-ref)) q (401966 . 4)) ((c def c (c (? . 0) q call-with-escape-continuation)) q (209481 . 3)) ((c def c (c (? . 0) q checked-procedure-check-and-extract)) q (130227 . 11)) ((c form c (c (? . 93) q chaperone-generics)) q (137331 . 4)) ((c def c (c (? . 0) q exact->inexact)) q (19545 . 3)) ((c def c (c (? . 42) q take-right)) q (90640 . 4)) ((c def c (c (? . 0) q thread-cell-values?)) q (222122 . 3)) ((c def c (c (? . 0) q >=)) q (21620 . 4)) ((c def c (c (? . 0) q char-alphabetic?)) q (63740 . 3)) ((c def c (c (? . 49) q make-handle-get-preference-locked)) q (363657 . 16)) ((c form c (c (? . 2) q for*/fold)) q (15476 . 3)) ((c def c (c (? . 101) q date-display-format)) q (386247 . 18)) ((c def c (c (? . 49) q other-read-bit)) q (365619 . 2)) ((c def c (c (? . 30) q fxrshift)) q (33128 . 4)) ((c def c (c (? . 0) q rename-file-or-directory)) q (353613 . 7)) ((c def c (c (? . 12) q </c)) q (163324 . 3)) ((c def c (c (? . 15) q impersonator-prop:contracted)) q (183047 . 2)) ((c form c (c (? . 1) q class-field-accessor)) q (146758 . 2)) ((c def c (c (? . 1) q generate-member-key)) q (144748 . 2)) ((c def c (c (? . 4) q unsafe-flmax)) q (396728 . 4)) ((c def c (c (? . 4) q unsafe-extflsqrt)) q (404500 . 3)) ((c def c (c (? . 4) q unsafe-flsqrt)) q (397532 . 3)) ((c def c (c (? . 35) q vector-memv)) q (98067 . 4)) ((c def c (c (? . 2) q exn:fail:syntax)) c (? . 108)) ((c def c (c (? . 4) q unsafe-fxquotient)) q (394545 . 4)) ((c def c (c (? . 19) q hash-update!)) q (101453 . 11)) ((c def c (c (? . 0) q prop:checked-procedure)) q (130172 . 2)) ((c def c (c (? . 0) q module->namespace)) q (308924 . 5)) ((c def c (c (? . 35) q vector-set*!)) q (96130 . 5)) ((c def c (c (? . 0) q continuation-prompt-available?)) q (209802 . 5)) ((c def c (c (? . 6) q get-uncovered-expressions)) q (346301 . 7)) ((c def c (c (? . 0) q logger?)) q (382075 . 3)) ((c def c (c (? . 0) q hash-clear)) q (102519 . 3)) ((c def c (c (? . 0) q current-thread-initial-stack-size)) q (390172 . 4)) ((c def c (c (? . 3) q udp-receive!/enable-break)) q (371728 . 12)) ((c def c (c (? . 96) q false)) q (17971 . 2)) ((c def c (c (? . 0) q struct:exn:fail:filesystem:version)) c (? . 114)) ((c def c (c (? . 6) q sandbox-make-plumber)) q (344646 . 4)) ((c def c (c (? . 2) q open-input-output-file)) q (255285 . 10)) ((c def c (c (? . 13) q seteq)) q (120137 . 3)) ((c form c (c (? . 0) q #%declare)) q (1921 . 4)) ((c form c (c (? . 50) q define/with-syntax)) q (250531 . 4)) ((c def c (c (? . 0) q real-part)) q (22597 . 3)) ((c def c (c (? . 70) q promise-running?)) q (207455 . 3)) ((c form c (c (? . 41) q shift0-at)) q (211742 . 2)) ((c form c (c (? . 36) q match-lambda**)) q (195594 . 2)) ((c def c (c (? . 0) q current-directory-for-user)) q (355689 . 4)) ((c def c (c (? . 0) q subbytes)) q (56010 . 5)) ((c def c (c (? . 0) q prop:custom-write)) q (302917 . 2)) ((c form c (c (? . 13) q for/weak-set)) q (122355 . 2)) ((c form c (c (? . 1) q define/private)) q (144248 . 3)) ((c form c (c (? . 17) q compound-unit)) q (158050 . 12)) ((c def c (c (? . 20) q extflcos)) q (36721 . 3)) ((c def c (c (? . 26) q raise-blame-error)) q (182206 . 9)) ((c def c (c (? . 7) q flceiling)) q (29271 . 3)) ((c def c (c (? . 0) q pseudo-random-generator?)) q (24173 . 3)) ((c def c (c (? . 12) q evt/c)) q (168123 . 3)) ((c form c (c (? . 2) q for/hash)) q (13873 . 2)) ((c form c (c (? . 41) q set)) q (212062 . 2)) ((c form c (c (? . 38) q cond)) q (11447 . 7)) ((c def c (c (? . 0) q current-drive)) q (355836 . 2)) ((c def c (c (? . 0) q read-accept-lang)) q (292527 . 4)) ((c def c (c (? . 0) q null)) q (83421 . 2)) ((c def c (c (? . 0) q namespace-require/constant)) q (307704 . 3)) ((c def c (c (? . 0) q namespace-require/copy)) q (307595 . 3)) ((c form c (c (? . 0) q letrec-values)) q (10824 . 2)) ((c def c (c (? . 11) q guard-evt)) q (217506 . 3)) ((c def c (c (? . 0) q print-reader-abbreviations)) q (295577 . 4)) ((c def c (c (? . 0) q explode-path)) q (350802 . 4)) ((c def c (c (? . 2) q regexp-split)) q (80205 . 15)) ((c def c (c (? . 6) q sandbox-propagate-breaks)) q (341149 . 4)) ((c def c (c (? . 0) q bytes-close-converter)) q (60634 . 3)) ((c def c (c (? . 0) q environment-variables-ref)) q (388325 . 5)) ((c def c (c (? . 2) q procedure-reduce-arity)) q (128842 . 4)) ((c form c (c (? . 93) q generic-instance/c)) q (136933 . 4)) ((c def c (c (? . 0) q variable-reference->phase)) q (310158 . 3)) ((c def c (c (? . 0) q char-ci>?)) q (63547 . 4)) ((c def c (c (? . 22) q memf)) q (86086 . 4)) ((c def c (c (? . 11) q load-relative-extension)) q (311896 . 3)) ((c def c (c (? . 117) q bytes-join)) q (62309 . 4)) ((c def c (c (? . 0) q keyword->string)) q (82901 . 3)) ((c def c (c (? . 4) q unsafe-extflasin)) q (404157 . 3)) ((c def c (c (? . 0) q make-syntax-introducer)) q (241873 . 2)) ((c def c (c (? . 2) q exn:fail:out-of-memory)) c (? . 118)) ((c def c (c (? . 3) q udp-receive!)) q (370836 . 11)) ((c def c (c (? . 20) q extfllog)) q (37029 . 3)) ((c def c (c (? . 101) q date->seconds)) q (386914 . 4)) ((c def c (c (? . 0) q exn:fail:filesystem?)) c (? . 45)) ((c form c (c (? . 17) q define-values/invoke-unit)) q (157934 . 4)) ((c def c (c (? . 0) q caaar)) q (86955 . 3)) ((c def c (c (? . 49) q put-preferences)) q (363250 . 9)) ((c def c (c (? . 42) q argmax)) q (93172 . 4)) ((c def c (c (? . 0) q exn:fail:read?)) c (? . 97)) ((c def c (c (? . 3) q udp-send/enable-break)) q (370479 . 9)) ((c def c (c (? . 0) q =)) q (21327 . 4)) ((c def c (c (? . 0) q hash-remove)) q (102304 . 4)) ((c def c (c (? . 0) q variable-reference?)) q (309374 . 3)) ((c def c (c (? . 0) q exn-message)) c (? . 102)) ((c def c (c (? . 12) q between/c)) q (163546 . 4)) ((c form c (c (? . 1) q inherit/inner)) q (143006 . 2)) ((c def c (c (? . 1) q make-exn:fail:object)) c (? . 89)) ((c def c (c (? . 3) q udp-connect!)) q (368283 . 8)) ((c def c (c (? . 14) q export-protect?)) c (? . 63)) ((c form c (c (? . 1) q define-serializable-class*)) q (153068 . 4)) ((c def c (c (? . 0) q bytes-converter?)) q (62100 . 3)) ((c def c (c (? . 0) q char-ci<=?)) q (63450 . 4)) ((c def c (c (? . 5) q dict-can-functional-set?)) q (112097 . 3)) ((c def c (c (? . 0) q seconds->date)) q (384667 . 4)) ((c def c (c (? . 4) q unsafe-bytes-ref)) q (400744 . 4)) ((c def c (c (? . 0) q exn:fail:out-of-memory?)) c (? . 118)) ((c def c (c (? . 0) q thread-cell-set!)) q (221846 . 4)) ((c def c (c (? . 5) q dict-iterate-key)) q (113084 . 4)) ((c def c (c (? . 49) q other-write-bit)) q (365650 . 2)) ((c def c (c (? . 34) q one-of/c)) q (163983 . 3)) ((c form c (c (? . 34) q ->*)) q (168774 . 26)) ((c def c (c (? . 21) q ~r)) q (50657 . 25)) ((c def c (c (? . 0) q syntax-local-transforming-module-provides?)) q (242399 . 2)) ((c def c (c (? . 13) q set-add)) q (123295 . 4)) ((c def c (c (? . 57) q sqr)) q (27487 . 3)) ((c def c (c (? . 0) q syntax-transforming?)) q (241688 . 2)) ((c def c (c (? . 0) q choice-evt)) q (217237 . 3)) ((c def c (c (? . 0) q make-hasheq-placeholder)) q (93784 . 3)) ((c def c (c (? . 16) q tcp-port?)) q (367708 . 3)) ((c def c (c (? . 4) q unsafe-fl->fx)) q (398349 . 3)) ((c def c (c (? . 0) q weak-box?)) q (393106 . 3)) ((c def c (c (? . 42) q shuffle)) q (92886 . 3)) ((c def c (c (? . 20) q extflatan)) q (36967 . 3)) ((c def c (c (? . 2) q sequence-generate*)) q (107886 . 5)) ((c def c (c (? . 0) q srcloc->string)) q (206906 . 3)) ((c def c (c (? . 0) q string?)) q (40031 . 3)) ((c def c (c (? . 0) q log)) q (22008 . 3)) ((c def c (c (? . 57) q conjugate)) q (27631 . 3)) ((c def c (c (? . 0) q variable-reference->namespace)) q (309644 . 3)) ((c def c (c (? . 0) q custodian-memory-accounting-available?)) q (334623 . 2)) ((c def c (c (? . 79) q prop:serializable)) q (304798 . 2)) ((c def c (c (? . 0) q cddadr)) q (88911 . 3)) ((c def c (c (? . 78) q prop:chaperone-unsafe-undefined)) q (405489 . 2)) ((c def c (c (? . 7) q shared-flvector)) q (32089 . 3)) ((c def c (c (? . 0) q cdddr)) q (87529 . 3)) ((q def ((lib "racket/rerequire.rkt") dynamic-rerequire)) q (408727 . 5)) ((c def c (c (? . 5) q dict-clear)) q (114827 . 3)) ((c def c (c (? . 0) q regexp-match-peek-positions/end)) q (77891 . 22)) ((c def c (c (? . 0) q acos)) q (22259 . 3)) ((c form c (c (? . 19) q do)) q (16441 . 7)) ((c form c (c (? . 13) q for*/seteq)) q (121903 . 2)) ((c def c (c (? . 0) q hash-copy)) q (103737 . 3)) ((c def c (c (? . 49) q file->bytes)) q (357128 . 4)) ((c def c (c (? . 0) q readtable-mapping)) q (302410 . 9)) ((c def c (c (? . 5) q in-dict-values)) q (115248 . 3)) ((c def c (c (? . 13) q set-symmetric-difference)) q (124976 . 4)) ((c def c (c (? . 7) q make-flvector)) q (30884 . 4)) ((c def c (c (? . 4) q unsafe-u16vector-set!)) q (402076 . 5)) ((c form c (c (? . 119) q command-line)) q (390524 . 43)) ((c def c (c (? . 0) q module-path?)) q (315522 . 3)) ((c def c (c (? . 0) q current-preserved-thread-cell-values)) q (221935 . 4)) ((c def c (c (? . 0) q variable-reference-constant?)) q (309439 . 3)) ((c def c (c (? . 0) q zero?)) q (19105 . 3)) ((c def c (c (? . 53) q path-element?)) q (352254 . 3)) ((c def c (c (? . 30) q fx*)) q (32425 . 4)) ((c form c (c (? . 1) q send+)) q (146231 . 5)) ((c def c (c (? . 22) q foldr)) q (84673 . 5)) ((c def c (c (? . 4) q unsafe-vector-length)) q (399699 . 3)) ((c def c (c (? . 7) q flvector-set!)) q (31198 . 5)) ((c def c (c (? . 3) q udp-send-to-evt)) q (372598 . 13)) ((c def c (c (? . 4) q unsafe-flmin)) q (396648 . 4)) ((c form c (c (? . 93) q define/generic)) q (136826 . 5)) ((c def c (c (? . 0) q hash-iterate-next)) q (103377 . 5)) ((c def c (c (? . 14) q struct:export)) c (? . 63)) ((c def c (c (? . 101) q date->julian/scalinger)) q (387686 . 3)) ((c def c (c (? . 10) q make-limited-input-port)) q (269232 . 7)) ((c def c (c (? . 0) q will-executor?)) q (393470 . 3)) ((c def c (c (? . 0) q semaphore?)) q (218771 . 3)) ((c def c (c (? . 2) q make-exn:break)) c (? . 68)) ((c def c (c (? . 0) q values)) q (196948 . 3)) ((c def c (c (? . 2) q make-exn:fail:contract:divide-by-zero)) c (? . 107)) ((c def c (c (? . 42) q eighth)) q (89743 . 3)) ((c def c (c (? . 0) q security-guard?)) q (333319 . 3)) ((c def c (c (? . 0) q inexact->exact)) q (19485 . 3)) ((c def c (c (? . 42) q splitf-at)) q (90547 . 4)) ((c form c (c (? . 120) q define-syntax-parameter)) q (247448 . 2)) ((c def c (c (? . 30) q fxlshift)) q (33052 . 4)) ((c def c (c (? . 6) q sandbox-override-collection-paths)) q (341839 . 4)) ((c def c (c (? . 0) q date-time-zone-offset)) c (? . 32)) ((c def c (c (? . 4) q unsafe-fltan)) q (397175 . 3)) ((c def c (c (? . 0) q path?)) q (347442 . 3)) ((c def c (c (? . 53) q file-name-from-path)) q (351469 . 3)) ((c def c (c (? . 101) q julian/scalinger->string)) q (387766 . 3)) ((c def c (c (? . 42) q splitf-at-right)) q (91130 . 4)) ((c def c (c (? . 0) q read-bytes-avail!/enable-break)) q (281389 . 10)) ((c def c (c (? . 2) q in-list)) q (104390 . 3)) ((c def c (c (? . 100) q vectorof)) q (164120 . 7)) ((c def c (c (? . 0) q compile-allow-set!-undefined)) q (314306 . 4)) ((c def c (c (? . 9) q import-req-mode)) c (? . 31)) ((c def c (c (? . 0) q vector)) q (94504 . 3)) ((c def c (c (? . 0) q impersonator-ephemeron)) q (321437 . 3)) ((c def c (c (? . 0) q make-file-or-directory-link)) q (355314 . 4)) ((c def c (c (? . 0) q module-compiled-submodules)) q (318248 . 13)) ((c def c (c (? . 0) q string-ci=?)) q (42313 . 4)) ((c form c (c (? . 0) q let*-values)) q (10761 . 2)) ((c form c (c (? . 1) q define/public)) q (143490 . 3)) ((c def c (c (? . 0) q variable-reference->module-declaration-inspector)) q (310384 . 4)) ((c def c (c (? . 10) q read-bytes-line-evt)) q (277240 . 4)) ((c def c (c (? . 7) q flimag-part)) q (30464 . 5)) ((c form c (c (? . 17) q unit/s)) q (160529 . 6)) ((c def c (c (? . 0) q read-syntax/recursive)) q (290601 . 11)) ((c def c (c (? . 0) q resolved-module-path?)) q (314772 . 3)) ((c def c (c (? . 3) q udp-receive-ready-evt)) q (372518 . 3)) ((c def c (c (? . 96) q false?)) q (18153 . 3)) ((c def c (c (? . 2) q procedure->method)) q (127877 . 3)) ((c form c (c (? . 17) q define-compound-unit)) q (159287 . 5)) ((c def c (c (? . 6) q sandbox-eval-handlers)) q (343797 . 7)) ((c def c (c (? . 74) q string-trim)) q (45693 . 11)) ((c def c (c (? . 0) q void)) q (131790 . 3)) ((c def c (c (? . 4) q unsafe-fx<=)) q (395560 . 4)) ((c def c (c (? . 49) q display-lines-to-file)) q (359257 . 13)) ((c def c (c (? . 11) q bytes-environment-variable-name?)) q (388085 . 3)) ((c form c (c (? . 2) q submod)) q (4924 . 4)) ((c form c (c (? . 36) q match-letrec)) q (195866 . 2)) ((c def c (c (? . 0) q date?)) c (? . 32)) ((c def c (c (? . 69) q make-async-channel)) q (220128 . 3)) ((c def c (c (? . 0) q sync)) q (216817 . 3)) ((c def c (c (? . 61) q system/exit-code)) q (378322 . 5)) ((c def c (c (? . 0) q make-plumber)) q (336993 . 2)) ((c def c (c (? . 11) q path-replace-suffix)) q (350948 . 4)) ((c def c (c (? . 2) q collection-file-path)) q (405892 . 16)) ((c form c (c (? . 38) q letrec-syntax)) q (10946 . 2)) ((c def c (c (? . 4) q unsafe-flvector-ref)) q (401308 . 4)) ((c def c (c (? . 13) q set-mutable?)) q (119853 . 3)) ((c def c (c (? . 13) q set-empty?)) q (123629 . 3)) ((c def c (c (? . 12) q non-empty-listof)) q (165203 . 3)) ((c form c (c (? . 93) q impersonate-generics)) q (137031 . 10)) ((c def c (c (? . 96) q xor)) q (18285 . 4)) ((c def c (c (? . 121) q fasl->s-exp)) q (305431 . 3)) ((c def c (c (? . 0) q list->string)) q (41624 . 3)) ((c def c (c (? . 5) q in-dict-pairs)) q (115315 . 3)) ((c def c (c (? . 51) q sequence-for-each)) q (108765 . 4)) ((c def c (c (? . 0) q make-input-port)) q (259779 . 49)) ((c form c (c (? . 1) q inner)) q (144530 . 3)) ((c form c (c (? . 52) q include-at/relative-to)) q (249686 . 2)) ((c def c (c (? . 0) q call-with-semaphore)) q (219368 . 9)) ((c def c (c (? . 4) q unsafe-list-ref)) q (399003 . 4)) ((c def c (c (? . 0) q channel-put-evt)) q (218616 . 4)) ((c def c (c (? . 0) q char>=?)) q (63164 . 4)) ((c def c (c (? . 3) q udp-bound?)) q (372291 . 3)) ((c def c (c (? . 2) q make-base-namespace)) q (305668 . 2)) ((c def c (c (? . 0) q exn:srclocs-accessor)) q (206443 . 4)) ((c def c (c (? . 6) q sandbox-exit-handler)) q (343146 . 4)) ((c form c (c (? . 41) q control0)) q (211525 . 2)) ((c def c (c (? . 0) q string-append)) q (41484 . 3)) ((c def c (c (? . 0) q quotient/remainder)) q (20233 . 4)) ((c def c (c (? . 0) q integer->integer-bytes)) q (25792 . 14)) ((c def c (c (? . 0) q thread-cell?)) q (221607 . 3)) ((c form c (c (? . 47) q place)) q (225183 . 2)) ((c def c (c (? . 15) q has-blame?)) q (191680 . 3)) ((c def c (c (? . 2) q arity-at-least)) c (? . 90)) ((c def c (c (? . 51) q sequence-append)) q (108398 . 3)) ((c def c (c (? . 7) q fl<)) q (28727 . 4)) ((c def c (c (? . 29) q make-fsemaphore)) q (223598 . 3)) ((c def c (c (? . 56) q pretty-printing)) q (301156 . 4)) ((c def c (c (? . 29) q touch)) q (223273 . 3)) ((c def c (c (? . 20) q extfltruncate)) q (36594 . 3)) ((c def c (c (? . 0) q build-path/convention-type)) q (348921 . 9)) ((c form c (c (? . 122) q define-provide-syntax)) q (12679 . 3)) ((c def c (c (? . 0) q syntax-position)) q (229893 . 3)) ((c def c (c (? . 0) q vector?)) q (94341 . 3)) ((c def c (c (? . 0) q port-write-handler)) q (296499 . 6)) ((c def c (c (? . 0) q system-path-convention-type)) q (348547 . 2)) ((c def c (c (? . 0) q current-load/use-compiled)) q (311973 . 13)) ((c def c (c (? . 1) q printable<%>)) q (153376 . 2)) ((c def c (c (? . 0) q write-char)) q (287136 . 4)) ((c def c (c (? . 0) q prop:custom-print-quotable)) q (303146 . 2)) ((c def c (c (? . 9) q require-transformer?)) q (243409 . 3)) ((c def c (c (? . 0) q custom-print-quotable-accessor)) q (303260 . 2)) ((c def c (c (? . 65) q stream-append)) q (110269 . 3)) ((c form c (c (? . 1) q super)) q (144462 . 3)) ((c def c (c (? . 50) q syntax-local-value/record)) q (251140 . 4)) ((c def c (c (? . 1) q object-method-arity-includes?)) q (154661 . 7)) ((c def c (c (? . 0) q vector->pseudo-random-generator!)) q (24672 . 5)) ((c def c (c (? . 0) q break-thread)) q (215821 . 4)) ((c form c (c (? . 2) q file)) q (4779 . 2)) ((c def c (c (? . 69) q async-channel-put)) q (220395 . 4)) ((c def c (c (? . 13) q set-remove)) q (123459 . 4)) ((c def c (c (? . 0) q channel-put-evt?)) q (218709 . 3)) ((c def c (c (? . 2) q regexp-match-peek-positions*)) q (75187 . 17)) ((c def c (c (? . 0) q struct-type-property-accessor-procedure?)) q (135841 . 3)) ((c def c (c (? . 30) q fxvector?)) q (33818 . 3)) ((c def c (c (? . 4) q unsafe-flcos)) q (397116 . 3)) ((c def c (c (? . 49) q other-execute-bit)) q (365682 . 2)) ((c def c (c (? . 78) q chaperone-struct-unsafe-undefined)) q (405413 . 3)) ((c def c (c (? . 0) q ceiling)) q (20947 . 3)) ((c def c (c (? . 0) q compile-syntax)) q (314034 . 3)) ((c def c (c (? . 0) q syntax-shift-phase-level)) q (231531 . 4)) ((c def c (c (? . 1) q dynamic-send)) q (145841 . 9)) ((c def c (c (? . 11) q path-add-suffix)) q (351117 . 4)) ((c form c (c (? . 1) q override*)) q (143230 . 2)) ((c form c (c (? . 70) q delay/thread)) q (207630 . 5)) ((c def c (c (? . 0) q char-downcase)) q (64809 . 3)) ((c def c (c (? . 4) q unsafe-flacos)) q (397294 . 3)) ((c form c (c (? . 17) q define-unit-binding)) q (159569 . 6)) ((c def c (c (? . 30) q fxand)) q (32781 . 4)) ((c def c (c (? . 0) q peek-byte)) q (285661 . 4)) ((c def c (c (? . 49) q file->lines)) q (357616 . 8)) ((c def c (c (? . 0) q module-path-index-submodule)) q (317362 . 4)) ((c form c (c (? . 93) q redirect-generics)) q (137437 . 4)) ((c def c (c (? . 57) q radians->degrees)) q (27428 . 3)) ((c def c (c (? . 0) q mcons)) q (94033 . 4)) ((c def c (c (? . 1) q implementation?)) q (154283 . 4)) ((c def c (c (? . 0) q syntax-local-module-defined-identifiers)) q (242468 . 3)) ((c def c (c (? . 0) q write-string)) q (287459 . 7)) ((c form c (c (? . 60) q trait-rename-field)) q (148387 . 2)) ((c def c (c (? . 0) q regexp-match-peek)) q (71887 . 15)) ((c def c (c (? . 20) q extflmax)) q (36318 . 4)) ((c def c (c (? . 0) q make-will-executor)) q (393419 . 2)) ((c def c (c (? . 0) q handle-evt?)) q (218044 . 3)) ((c def c (c (? . 42) q filter-not)) q (92787 . 4)) ((c def c (c (? . 2) q make-exn:fail:syntax)) c (? . 108)) ((c form c (c (? . 116) q define/contract)) q (175923 . 3)) ((c def c (c (? . 0) q read-accept-dot)) q (292119 . 4)) ((c def c (c (? . 2) q in-naturals)) q (104297 . 3)) ((c def c (c (? . 4) q unsafe-s16vector-set!)) q (401831 . 5)) ((c def c (c (? . 0) q impersonate-hash)) q (324026 . 20)) ((c def c (c (? . 1) q member-name-key-hash-code)) q (144984 . 3)) ((c def c (c (? . 0) q current-error-port)) q (252652 . 4)) ((c def c (c (? . 0) q number?)) q (18352 . 3)) ((c form c (c (? . 34) q recontract-out)) q (175389 . 2)) ((c def c (c (? . 11) q load/cd)) q (311587 . 3)) ((c def c (c (? . 42) q empty?)) q (89284 . 3)) ((c def c (c (? . 2) q syntax-local-certifier)) q (241536 . 5)) ((c def c (c (? . 0) q write-special-evt)) q (289830 . 4)) ((c def c (c (? . 0) q write-bytes)) q (287739 . 7)) ((c def c (c (? . 2) q in-vector)) q (104508 . 6)) ((c def c (c (? . 0) q current-custodian)) q (334408 . 4)) ((c def c (c (? . 20) q extflvector-copy)) q (38268 . 5)) ((c def c (c (? . 0) q immutable?)) q (17812 . 3)) ((c def c (c (? . 0) q syntax-local-module-exports)) q (241050 . 7)) ((c form c (c (? . 87) q define-serializable-struct)) q (303874 . 3)) ((c def c (c (? . 0) q eq-hash-code)) q (103825 . 3)) ((c def c (c (? . 20) q extflvector-ref)) q (38007 . 4)) ((c form c (c (? . 2) q for/lists)) q (14318 . 2)) ((c def c (c (? . 47) q dynamic-place*)) q (224557 . 14)) ((c def c (c (? . 0) q global-port-print-handler)) q (297174 . 6)) ((c def c (c (? . 0) q namespace-unprotect-module)) q (308559 . 7)) ((c def c (c (? . 4) q unsafe-extflvector-length)) q (404794 . 3)) ((c def c (c (? . 0) q log-max-level)) q (383503 . 5)) ((c def c (c (? . 2) q namespace-anchor->empty-namespace)) q (305816 . 3)) ((c def c (c (? . 0) q string-copy)) q (40872 . 3)) ((c def c (c (? . 0) q syntax-source)) q (229648 . 3)) ((c def c (c (? . 4) q unsafe-extfl*)) q (402794 . 4)) ((c def c (c (? . 50) q record-disappeared-uses)) q (251267 . 3)) ((c def c (c (? . 0) q char-general-category)) q (64477 . 3)) ((c form c (c (? . 36) q match-let*-values)) q (195800 . 2)) ((c def c (c (? . 0) q time-apply)) q (385878 . 7)) ((c form c (c (? . 37) q runtime-require)) q (356857 . 2)) ((c def c (c (? . 56) q pretty-print-.-symbol-without-bars)) q (298526 . 4)) ((c form c (c (? . 123) q begin-encourage-inline)) q (16877 . 2)) ((c def c (c (? . 22) q remove*)) q (85124 . 5)) ((c def c (c (? . 0) q struct:srcloc)) c (? . 8)) ((c def c (c (? . 10) q read-string!-evt)) q (276976 . 4)) ((c def c (c (? . 0) q struct-type-property?)) q (135774 . 3)) ((c def c (c (? . 0) q file-stream-buffer-mode)) q (253075 . 6)) ((c form c (c (? . 17) q invoke-unit)) q (157845 . 3)) ((c def c (c (? . 6) q put-input)) q (345849 . 6)) ((c form c (c (? . 124) q define-require-syntax)) q (12499 . 3)) ((c form c (c (? . 1) q absent)) q (149428 . 2)) ((c def c (c (? . 0) q prefab-key?)) q (138501 . 3)) ((c def c (c (? . 0) q custom-write-accessor)) q (303026 . 4)) ((c def c (c (? . 49) q user-write-bit)) q (365458 . 2)) ((c def c (c (? . 0) q procedure?)) q (127430 . 3)) ((c def c (c (? . 5) q in-dict)) q (115123 . 3)) ((c form c (c (? . 13) q for/mutable-seteq)) q (122062 . 2)) ((c def c (c (? . 20) q extflfloor)) q (36466 . 3)) ((c def c (c (? . 6) q sandbox-security-guard)) q (342004 . 5)) ((c def c (c (? . 0) q fprintf)) q (294337 . 5)) ((c def c (c (? . 4) q unsafe-extflround)) q (403668 . 3)) ((c def c (c (? . 9) q import-source-mod-path-stx)) c (? . 64)) ((c def c (c (? . 0) q plumber-add-flush!)) q (337278 . 5)) ((c def c (c (? . 22) q remove)) q (84869 . 5)) ((c def c (c (? . 65) q stream-filter)) q (110932 . 4)) ((c def c (c (? . 20) q extfl->exact-integer)) q (37363 . 3)) ((c def c (c (? . 0) q sync/enable-break)) q (217014 . 3)) ((c def c (c (? . 61) q process*/ports)) q (380747 . 27)) ((c form c (c (? . 1) q get-field)) q (146419 . 2)) ((c def c (c (? . 0) q current-logger)) q (382696 . 4)) ((c def c (c (? . 0) q make-weak-hasheq)) q (99964 . 3)) ((c def c (c (? . 0) q load-extension)) q (311828 . 3)) ((c def c (c (? . 0) q caadar)) q (87811 . 3)) ((c def c (c (? . 0) q print-graph)) q (295013 . 4)) ((c def c (c (? . 47) q place-message-allowed?)) q (226052 . 3)) ((c def c (c (? . 0) q plumber-flush-handle-remove!)) q (337462 . 3)) ((c form c (c (? . 41) q prompt0)) q (211468 . 2)) ((c def c (c (? . 65) q stream-rest)) q (109691 . 3)) ((c def c (c (? . 20) q extfl<=)) q (36069 . 4)) ((c def c (c (? . 125) q box-immutable/c)) q (165075 . 3)) ((c def c (c (? . 0) q angle)) q (22788 . 3)) ((c def c (c (? . 0) q struct-constructor-procedure?)) q (137893 . 3)) ((c def c (c (? . 69) q async-channel-try-get)) q (220318 . 3)) ((c def c (c (? . 69) q async-channel?)) q (220068 . 3)) ((c form c (c (? . 41) q %)) q (210939 . 4)) ((c def c (c (? . 13) q set-implements?)) q (122744 . 4)) ((c def c (c (? . 0) q read-accept-reader)) q (292427 . 4)) ((c def c (c (? . 0) q integer->char)) q (62526 . 5)) ((c def c (c (? . 0) q print)) q (293769 . 5)) ((c def c (c (? . 0) q error-print-source-location)) q (201953 . 4)) ((c def c (c (? . 0) q make-continuation-mark-key)) q (212877 . 4)) ((c form c (c (? . 1) q init-rest)) q (142486 . 3)) ((c def c (c (? . 0) q syntax-local-phase-level)) q (240993 . 2)) ((c def c (c (? . 0) q real->floating-point-bytes)) q (26765 . 12)) ((c def c (c (? . 0) q write-bytes-avail-evt)) q (289450 . 9)) ((c def c (c (? . 0) q print-vector-length)) q (295269 . 4)) ((c form c (c (? . 37) q define-runtime-module-path)) q (356895 . 2)) ((c def c (c (? . 2) q make-exn:fail:network:errno)) c (? . 95)) ((c form c (c (? . 2) q lambda)) q (9867 . 2)) ((c def c (c (? . 13) q generic-set?)) q (122686 . 3)) ((c form c (c (? . 17) q only)) q (157496 . 2)) ((c form c (c (? . 60) q trait)) q (147238 . 18)) ((c def c (c (? . 4) q unsafe-fxvector-length)) q (400968 . 3)) ((c def c (c (? . 2) q make-arity-at-least)) c (? . 90)) ((c form c (c (? . 2) q for/hasheq)) q (13936 . 2)) ((c def c (c (? . 0) q floating-point-bytes->real)) q (26362 . 9)) ((c def c (c (? . 10) q with-output-to-bytes)) q (266070 . 3)) ((c def c (c (? . 0) q write-byte)) q (287253 . 4)) ((c def c (c (? . 12) q parameter/c)) q (166982 . 4)) ((c def c (c (? . 0) q list->vector)) q (95088 . 3)) ((c def c (c (? . 0) q path-element->bytes)) q (348271 . 3)) ((q form ((lib "racket/local.rkt") local)) q (11309 . 2)) ((c def c (c (? . 30) q fxvector)) q (33873 . 3)) ((c def c (c (? . 3) q udp-open-socket)) q (367763 . 5)) ((c def c (c (? . 0) q complex?)) q (18405 . 3)) ((c form c (c (? . 1) q augment-final)) q (142830 . 2)) ((c def c (c (? . 12) q channel/c)) q (167774 . 3)) ((c def c (c (? . 0) q exact-positive-integer?)) q (18751 . 3)) ((c def c (c (? . 21) q ~v)) q (47228 . 23)) ((c def c (c (? . 61) q system*)) q (377774 . 13)) ((c def c (c (? . 0) q string->bytes/locale)) q (58662 . 6)) ((c def c (c (? . 6) q sandbox-input)) q (339670 . 12)) ((c def c (c (? . 4) q unsafe-extflvector-ref)) q (404871 . 4)) ((c def c (c (? . 0) q current-thread)) q (215315 . 2)) ((c def c (c (? . 0) q bitwise-xor)) q (22992 . 3)) ((c def c (c (? . 0) q string->path)) q (347618 . 3)) ((c def c (c (? . 0) q abs)) q (20511 . 3)) ((c def c (c (? . 0) q write-special)) q (289209 . 4)) ((c def c (c (? . 0) q bytes-copy!)) q (56248 . 11)) ((c def c (c (? . 10) q read-line-evt)) q (277097 . 4)) ((c form c (c (? . 0) q module*)) q (1695 . 3)) ((c form c (c (? . 2) q for/product)) q (14252 . 2)) ((c def c (c (? . 22) q foldl)) q (84560 . 5)) ((c def c (c (? . 0) q local-transformer-expand/capture-lifts)) q (238049 . 11)) ((c def c (c (? . 0) q module-compiled-exports)) q (319051 . 5)) ((c def c (c (? . 2) q hash-set*)) q (100881 . 5)) ((c form c (c (? . 65) q stream)) q (109826 . 2)) ((c def c (c (? . 0) q byte-regexp)) q (65999 . 3)) ((c def c (c (? . 4) q unsafe-extflmin)) q (403484 . 4)) ((c def c (c (? . 0) q file-or-directory-modify-seconds)) q (353859 . 16)) ((c def c (c (? . 79) q serialize)) q (303382 . 3)) ((c def c (c (? . 0) q append)) q (84031 . 6)) ((c def c (c (? . 0) q eval)) q (310622 . 4)) ((c def c (c (? . 0) q expt)) q (21886 . 4)) ((c def c (c (? . 49) q group-read-bit)) q (365522 . 2)) ((c def c (c (? . 0) q string-locale-ci=?)) q (43702 . 4)) ((c def c (c (? . 7) q make-shared-flvector)) q (32158 . 4)) ((c def c (c (? . 20) q extfl=)) q (35826 . 4)) ((c def c (c (? . 0) q path-for-some-system?)) q (347551 . 3)) ((c def c (c (? . 0) q make-empty-namespace)) q (305565 . 2)) ((c def c (c (? . 21) q ~.a)) q (51868 . 23)) ((c def c (c (? . 0) q bytes<?)) q (57256 . 4)) ((c def c (c (? . 0) q make-set!-transformer)) q (235696 . 3)) ((c def c (c (? . 0) q dynamic-wind)) q (210143 . 7)) ((c def c (c (? . 0) q exn:fail:syntax:unbound?)) c (? . 126)) ((c form c (c (? . 23) q recursive-contract)) q (191903 . 5)) ((c def c (c (? . 30) q fl->fx)) q (33765 . 3)) ((c def c (c (? . 0) q expand-syntax-once)) q (249335 . 3)) ((c def c (c (? . 0) q exn:missing-module?)) q (207045 . 3)) ((c def c (c (? . 5) q dict-value-contract)) q (115496 . 3)) ((c def c (c (? . 2) q regexp-replaces)) q (82229 . 8)) ((c def c (c (? . 15) q coerce-contract)) q (180298 . 4)) ((c def c (c (? . 0) q prop:rename-transformer)) q (236409 . 2)) ((c def c (c (? . 34) q dynamic->*)) q (172843 . 19)) ((c form c (c (? . 33) q syntax-rules)) q (229242 . 3)) ((c def c (c (? . 51) q sequence-add-between)) q (109199 . 4)) ((c def c (c (? . 1) q subclass?)) q (154204 . 4)) ((c def c (c (? . 0) q log-level?)) q (383316 . 5)) ((c def c (c (? . 0) q current-library-collection-links)) q (407190 . 11)) ((c def c (c (? . 0) q struct:exn:fail:out-of-memory)) c (? . 118)) ((c def c (c (? . 0) q error-display-handler)) q (201198 . 4)) ((c form c (c (? . 1) q define/augment-final)) q (144156 . 3)) ((c def c (c (? . 2) q in-mlist)) q (104446 . 3)) ((c def c (c (? . 0) q make-polar)) q (22499 . 4)) ((c def c (c (? . 0) q make-struct-type-property)) q (135249 . 13)) ((c form c (c (? . 36) q match-let-values)) q (195735 . 2)) ((c def c (c (? . 79) q serialized=?)) q (303492 . 4)) ((c def c (c (? . 0) q make-logger)) q (382128 . 11)) ((c def c (c (? . 0) q string-set!)) q (40538 . 5)) ((c def c (c (? . 78) q unsafe-undefined)) q (405087 . 2)) ((c def c (c (? . 2) q make-exn:fail:syntax:unbound)) c (? . 126)) ((c form c (c (? . 7) q for*/flvector)) q (31826 . 9)) ((c def c (c (? . 7) q flvector-length)) q (31002 . 3)) ((c def c (c (? . 0) q open-input-bytes)) q (258445 . 4)) ((c def c (c (? . 0) q cdaar)) q (87283 . 3)) ((c form c (c (? . 19) q parameterize*)) q (222423 . 3)) ((c def c (c (? . 0) q struct:exn:fail:filesystem:errno)) c (? . 115)) ((c def c (c (? . 0) q struct:exn:fail:syntax:unbound)) c (? . 126)) ((c def c (c (? . 0) q char-blank?)) q (64345 . 3)) ((c form c (c (? . 28) q ->*m)) q (149492 . 2)) ((c def c (c (? . 103) q unit-static-signatures)) q (161709 . 9)) ((c def c (c (? . 0) q regexp-match-peek-immediate)) q (73477 . 15)) ((c def c (c (? . 2) q in-bytes-lines)) q (105692 . 5)) ((c def c (c (? . 0) q bytes->path-element)) q (348028 . 4)) ((c def c (c (? . 13) q set-for-each)) q (125666 . 4)) ((c form c (c (? . 36) q match-define)) q (195988 . 2)) ((c def c (c (? . 30) q fx=)) q (33204 . 4)) ((c def c (c (? . 11) q reroot-path)) q (351282 . 4)) ((c def c (c (? . 42) q empty)) q (89211 . 2)) ((c def c (c (? . 0) q struct:date)) c (? . 32)) ((c form c (c (? . 2) q lib)) q (4744 . 2)) ((c form c (c (? . 43) q splicing-letrec)) q (247737 . 2)) ((c form c (c (? . 41) q shift0)) q (211559 . 2)) ((c form c (c (? . 17) q define-unit)) q (158406 . 7)) ((c def c (c (? . 9) q prop:require-transformer)) q (243352 . 2)) ((c def c (c (? . 13) q set-intersect!)) q (124655 . 4)) ((c def c (c (? . 0) q expand)) q (249112 . 3)) ((c def c (c (? . 0) q struct:exn:fail:network:errno)) c (? . 95)) ((c form c (c (? . 5) q define-custom-hash-types)) q (115627 . 12)) ((c def c (c (? . 7) q flvector)) q (30822 . 3)) ((c form c (c (? . 41) q control)) q (211170 . 2)) ((c def c (c (? . 0) q string->bytes/latin-1)) q (58909 . 9)) ((c form c (c (? . 104) q unsyntax)) q (229068 . 2)) ((c def c (c (? . 0) q read-line)) q (279316 . 5)) ((c def c (c (? . 4) q unsafe-extfl/)) q (402884 . 4)) ((c def c (c (? . 57) q tanh)) q (27789 . 3)) ((c def c (c (? . 0) q syntax-source-module)) q (230148 . 5)) ((c def c (c (? . 0) q current-compiled-file-roots)) q (313013 . 4)) ((c def c (c (? . 7) q make-flrectangular)) q (30059 . 7)) ((c form c (c (? . 0) q if)) q (11402 . 2)) ((c def c (c (? . 26) q blame-swapped?)) q (181952 . 3)) ((c def c (c (? . 0) q semaphore-wait)) q (218992 . 3)) ((c def c (c (? . 0) q always-evt)) q (217896 . 2)) ((c def c (c (? . 0) q chaperone?)) q (321214 . 3)) ((c def c (c (? . 0) q thread-rewind-receive)) q (216699 . 3)) ((c def c (c (? . 4) q unsafe-fl*)) q (396036 . 4)) ((c def c (c (? . 0) q readtable?)) q (301870 . 3)) ((c def c (c (? . 0) q port-display-handler)) q (296716 . 6)) ((c def c (c (? . 2) q exn:fail:user)) c (? . 55)) ((c def c (c (? . 0) q never-evt)) q (217922 . 2)) ((c form c (c (? . 36) q failure-cont)) q (196135 . 2)) ((c def c (c (? . 60) q trait->mixin)) q (148073 . 3)) ((c def c (c (? . 2) q exn:fail:filesystem:exists)) c (? . 77)) ((c def c (c (? . 6) q sandbox-namespace-specs)) q (341409 . 6)) ((c def c (c (? . 6) q exn:fail:sandbox-terminated-reason)) c (? . 127)) ((c def c (c (? . 0) q arity-at-least-value)) c (? . 90)) ((c def c (c (? . 0) q chaperone-struct-type)) q (330240 . 15)) ((c form c (c (? . 13) q for/seteq)) q (121753 . 2)) ((c def c (c (? . 0) q make-weak-hasheqv)) q (99841 . 3)) ((c def c (c (? . 0) q system-big-endian?)) q (27273 . 2)) ((c def c (c (? . 0) q syntax-local-bind-syntaxes)) q (238855 . 7)) ((c def c (c (? . 22) q assq)) q (86514 . 4)) ((c def c (c (? . 0) q char<=?)) q (62977 . 4)) ((c def c (c (? . 0) q magnitude)) q (22705 . 3)) ((c form c (c (? . 1) q public)) q (142521 . 2)) ((q form ((lib "racket/lazy-require.rkt") lazy-require)) q (17227 . 5)) ((c def c (c (? . 2) q exn:fail:contract:divide-by-zero)) c (? . 107)) ((c def c (c (? . 0) q hash-set)) q (100740 . 5)) ((c def c (c (? . 0) q char-ci<?)) q (63354 . 4)) ((c def c (c (? . 10) q display-lines)) q (265536 . 7)) ((c def c (c (? . 30) q fxremainder)) q (32574 . 4)) ((c form c (c (? . 0) q set!)) q (13046 . 2)) ((c def c (c (? . 56) q tentative-pretty-print-port-cancel)) q (301762 . 3)) ((c def c (c (? . 20) q extflsin)) q (36660 . 3)) ((c def c (c (? . 0) q string<?)) q (41931 . 4)) ((c def c (c (? . 0) q cddaar)) q (88811 . 3)) ((c def c (c (? . 3) q udp-multicast-loopback?)) q (374983 . 3)) ((c def c (c (? . 0) q syntax-e)) q (230322 . 3)) ((c def c (c (? . 42) q dropf)) q (90465 . 4)) ((c def c (c (? . 2) q make-exn:fail:filesystem:version)) c (? . 114)) ((c def c (c (? . 49) q file->list)) q (357409 . 5)) ((c def c (c (? . 101) q find-seconds)) q (387144 . 15)) ((c def c (c (? . 0) q char-foldcase)) q (64934 . 3)) ((c form c (c (? . 70) q delay/name)) q (207532 . 2)) ((c def c (c (? . 66) q current-prefix-in)) q (410525 . 4)) ((c def c (c (? . 0) q list?)) q (83442 . 3)) ((c def c (c (? . 22) q compose1)) q (127703 . 3)) ((c def c (c (? . 57) q pi.f)) q (27339 . 2)) ((c def c (c (? . 35) q vector-member)) q (97963 . 4)) ((c def c (c (? . 2) q hash->list)) q (102938 . 3)) ((c def c (c (? . 0) q module->exports)) q (320842 . 5)) ((c def c (c (? . 4) q unsafe-struct*-set!)) q (402491 . 5)) ((c def c (c (? . 0) q string-ci>=?)) q (42706 . 4)) ((c def c (c (? . 0) q char-lower-case?)) q (63808 . 3)) ((c def c (c (? . 0) q string-locale-upcase)) q (44017 . 3)) ((c def c (c (? . 65) q stream-ref)) q (110078 . 4)) ((c def c (c (? . 15) q coerce-chaperone-contract)) q (180491 . 4)) ((c def c (c (? . 14) q make-export)) c (? . 63)) ((c def c (c (? . 0) q vector->list)) q (95027 . 3)) ((c form c (c (? . 2) q for*/first)) q (15347 . 2)) ((c def c (c (? . 0) q thread-dead-evt)) q (216190 . 3)) ((c def c (c (? . 35) q vector-append)) q (96519 . 3)) ((c def c (c (? . 2) q make-exn:fail:read:non-char)) c (? . 82)) ((c form c (c (? . 19) q define-logger)) q (382795 . 2)) ((c def c (c (? . 0) q namespace-variable-value)) q (306452 . 9)) ((c def c (c (? . 128) q dynamic-enter!)) q (408375 . 7)) ((c def c (c (? . 2) q make-exn:fail:filesystem:exists)) c (? . 77)) ((c def c (c (? . 0) q port-writes-special?)) q (290023 . 3)) ((c def c (c (? . 18) q prop:flat-contract)) q (182948 . 2)) ((c def c (c (? . 50) q current-recorded-disappeared-uses)) q (250877 . 5)) ((c def c (c (? . 7) q flmax)) q (29090 . 4)) ((c def c (c (? . 0) q namespace-set-variable-value!)) q (306827 . 9)) ((c def c (c (? . 0) q srcloc-span)) c (? . 8)) ((c def c (c (? . 0) q prop:exn:missing-module)) q (206989 . 2)) ((c def c (c (? . 4) q unsafe-fx->fl)) q (398289 . 3)) ((c def c (c (? . 65) q stream-map)) q (110334 . 4)) ((c def c (c (? . 4) q unsafe-unbox*)) q (399386 . 3)) ((c def c (c (? . 74) q string-join)) q (44280 . 11)) ((c def c (c (? . 0) q variable-reference->module-path-index)) q (309881 . 4)) ((c def c (c (? . 0) q expand-user-path)) q (350207 . 3)) ((c def c (c (? . 0) q read-byte-or-special)) q (285355 . 3))))
syntax
(if test-expr then-expr else-expr)
syntax
(lambda formals body ...+)
 
formals = id
        | (id ...)
        | (id ...+ . rest-id)
syntax
(init-rest id)
(init-rest)
syntax
(parameterize ([parameter-expr value-expr] ...)
  body ...+)
 
  parameter-expr : parameter?
procedure
(char->integer char) -> exact-integer?
  char : char?
procedure
(argmax proc lst) -> any
  proc : (-> any/c real?)
  lst : (and/c pair? list?)
procedure
(read [in]) -> any
  in : input-port? = (current-input-port)
procedure
(sort  lst                             
       less-than?                      
      [#:key extract-key               
       #:cache-keys? cache-keys?]) -> list?
  lst : list?
  less-than? : (any/c any/c . -> . any/c)
  extract-key : (any/c . -> . any/c) = (lambda (x) x)
  cache-keys? : boolean? = #f
struct
(struct color (red green blue alpha))
  red : (and/c natural-number/c (<=/c 255))
  green : (and/c natural-number/c (<=/c 255))
  blue : (and/c natural-number/c (<=/c 255))
  alpha : (and/c natural-number/c (<=/c 255))
struct
(struct data-source (connector args extensions)
    #:mutable)
  connector : (or/c 'postgresql 'mysql 'sqlite3 'odbc)
  args : list?
  extensions : (listof (list/c symbol? any/c))
parameter
(current-command-line-arguments) -> (vectorof string?)
(current-command-line-arguments argv) -> void?
  argv : (vectorof (and/c string? immutable?))
value
object% : class?

(something id thing-expr ...)
 
  thing-expr : number?
syntax
(module id module-path form ...)
syntax
(module* id module-path form ...)
(module* id #f form ...)
syntax
(module+ id form ...)
syntax
(#%module-begin form ...)
syntax
(#%printing-module-begin form ...)
syntax
(#%plain-module-begin form ...)
syntax
(#%declare declaration-keyword ...)
 
declaration-keyword = #:cross-phase-persistent
syntax
(require require-spec ...)
 
       require-spec = module-path
                    | (only-in require-spec id-maybe-renamed ...)
                    | (except-in require-spec id ...)
                    | (prefix-in prefix-id require-spec)
                    | (rename-in require-spec [orig-id bind-id] ...)
                    | (combine-in require-spec ...)
                    | (relative-in module-path require-spec ...)
                    | (only-meta-in phase-level require-spec ...)
                    | (for-syntax require-spec ...)
                    | (for-template require-spec ...)
                    | (for-label require-spec ...)
                    | (for-meta phase-level require-spec ...)
                    | derived-require-spec
                       
        module-path = root-module-path
                    | (submod root-module-path submod-path-element ...)
                    | (submod "." submod-path-element ...)
                    | (submod ".." submod-path-element ...)
                       
   root-module-path = (quote id)
                    | rel-string
                    | (lib rel-string ...+)
                    | id
                    | (file string)
                    | (planet id)
                    | (planet string)
                    | (planet rel-string
                              (user-string pkg-string vers)
                              rel-string ...)
                       
submod-path-element = id
                    | ".."
                       
   id-maybe-renamed = id
                    | [orig-id bind-id]
                       
        phase-level = exact-integer
                    | #f
                       
               vers = 
                    | nat
                    | nat minor-vers
                       
         minor-vers = nat
                    | (nat nat)
                    | (= nat)
                    | (+ nat)
                    | (- nat)

module-path
syntax
(only-in require-spec id-maybe-renamed ...)
syntax
(except-in require-spec id ...)
syntax
(prefix-in prefix-id require-spec)
syntax
(rename-in require-spec [orig-id bind-id] ...)
syntax
(combine-in require-spec ...)
syntax
(relative-in module-path require-spec ...)
syntax
(only-meta-in phase-level require-spec ...)

(for-meta phase-level require-spec ...)

(for-syntax require-spec ...)

(for-template require-spec ...)

(for-label require-spec ...)

derived-require-spec

(quote id)

rel-string
syntax
(lib rel-string ...+)

id
syntax
(file string)
syntax
(planet id)
(planet string)
(planet rel-string (user-string pkg-string vers)
        rel-string ...)
syntax
(submod root-module submod-path-element ...)
(submod "." submod-path-element ...)
(submod ".." submod-path-element ...)
syntax
(local-require require-spec ...)
syntax
(provide provide-spec ...)
 
provide-spec = id
             | (all-defined-out)
             | (all-from-out module-path ...)
             | (rename-out [orig-id export-id] ...)
             | (except-out provide-spec provide-spec ...)
             | (prefix-out prefix-id provide-spec)
             | (struct-out id)
             | (combine-out provide-spec ...)
             | (protect-out provide-spec ...)
             | (for-meta phase-level provide-spec ...)
             | (for-syntax provide-spec ...)
             | (for-template provide-spec ...)
             | (for-label provide-spec ...)
             | derived-provide-spec
                
 phase-level = exact-integer
             | #f

id
syntax
(all-defined-out)
syntax
(all-from-out module-path ...)
syntax
(rename-out [orig-id export-id] ...)
syntax
(except-out provide-spec provide-spec ...)
syntax
(prefix-out prefix-id provide-spec)
syntax
(struct-out id)
syntax
(combine-out provide-spec ...)
syntax
(protect-out provide-spec ...)

(for-meta phase-level provide-spec ...)

(for-syntax provide-spec ...)

(for-template provide-spec ...)

(for-label provide-spec ...)

derived-provide-spec
syntax
(for-meta phase-level require-spec ...)
syntax
(for-syntax require-spec ...)
syntax
(for-template require-spec ...)
syntax
(for-label require-spec ...)
syntax
(#%require raw-require-spec ...)
 
    raw-require-spec = phaseless-spec
                     | (for-meta phase-level phaseless-spec ...)
                     | (for-syntax phaseless-spec ...)
                     | (for-template phaseless-spec ...)
                     | (for-label phaseless-spec ...)
                     | (just-meta phase-level raw-require-spec ...)
                        
         phase-level = exact-integer
                     | #f
                        
      phaseless-spec = raw-module-path
                     | (only raw-module-path id ...)
                     | (prefix prefix-id raw-module-path)
                     | (all-except raw-module-path id ...)
                     | (prefix-all-except prefix-id
                                          raw-module-path id ...)
                     | (rename raw-module-path local-id exported-id)
                        
     raw-module-path = raw-root-module-path
                     | (submod raw-root-module-path id ...+)
                     | (submod "." id ...+)
                        
raw-root-module-path = (quote id)
                     | rel-string
                     | (lib rel-string ...)
                     | id
                     | (file string)
                     | (planet rel-string
                               (user-string pkg-string vers ...))
                     | literal-path
syntax
(#%provide raw-provide-spec ...)
 
raw-provide-spec = phaseless-spec
                 | (for-meta phase-level phaseless-spec)
                 | (for-syntax phaseless-spec)
                 | (for-label phaseless-spec)
                 | (protect raw-provide-spec)
                    
     phase-level = exact-integer
                 | #f
                    
  phaseless-spec = id
                 | (rename local-id export-id)
                 | (struct struct-id (field-id ...))
                 | (all-from raw-module-path)
                 | (all-from-except raw-module-path id ...)
                 | (all-defined)
                 | (all-defined-except id ...)
                 | (prefix-all-defined prefix-id)
                 | (prefix-all-defined-except prefix-id id ...)
                 | (protect phaseless-spec ...)
                 | (expand (id . datum))
syntax
(matching-identifiers-in regexp require-spec)
syntax
(subtract-in require-spec subtracted-spec ...)
syntax
(filtered-in proc-expr require-spec)
syntax
(path-up rel-string ...)
syntax
(multi-in subs ...+)
 
    subs = sub-path
         | (sub-path ...)
            
sub-path = rel-string
         | id
syntax
(matching-identifiers-out regexp provide-spec)
syntax
(filtered-out proc-expr provide-spec)
syntax
(quote datum)
syntax
(#%datum . datum)
syntax
(#%expression expr)
syntax
id
syntax
(#%top . id)
syntax
(#%variable-reference id)
(#%variable-reference (#%top . id))
(#%variable-reference)
syntax
(proc-expr arg ...)
syntax
(#%app proc-expr arg ...)

arg-expr

keyword arg-expr
syntax
(#%plain-app proc-expr arg-expr ...)
(#%plain-app)
syntax
(lambda kw-formals body ...+)
syntax
(λ kw-formals body ...+)
 
kw-formals = (arg ...)
           | (arg ...+ . rest-id)
           | rest-id
              
       arg = id
           | [id default-expr]
           | keyword id
           | keyword [id default-expr]

(id ...)

(id ...+ . rest-id)

rest-id

(arg ...)

id

[id default-expr]

keyword id

keyword [id default-expr]

(arg ...+ . rest-id)
syntax
(case-lambda [formals body ...+] ...)
 
formals = (id ...)
        | (id ...+ . rest-id)
        | rest-id
syntax
(#%plain-lambda formals body ...+)
syntax
(let ([id val-expr] ...) body ...+)
(let proc-id ([id init-expr] ...) body ...+)
syntax
(let* ([id val-expr] ...) body ...+)
syntax
(letrec ([id val-expr] ...) body ...+)
syntax
(let-values ([(id ...) val-expr] ...) body ...+)
syntax
(let*-values ([(id ...) val-expr] ...) body ...+)
syntax
(letrec-values ([(id ...) val-expr] ...) body ...+)
syntax
(let-syntax ([id trans-expr] ...) body ...+)
syntax
(letrec-syntax ([id trans-expr] ...) body ...+)
syntax
(let-syntaxes ([(id ...) trans-expr] ...) body ...+)
syntax
(letrec-syntaxes ([(id ...) trans-expr] ...) body ...+)
syntax
(letrec-syntaxes+values ([(trans-id ...) trans-expr] ...)
                        ([(val-id ...) val-expr] ...)
   body ...+)
syntax
(local [definition ...] body ...+)
syntax
(shared ([id expr] ...) body ...+)
syntax
(if test-expr then-expr else-expr)
syntax
(cond cond-clause ...)
 
cond-clause = [test-expr then-body ...+]
            | [else then-body ...+]
            | [test-expr => proc-expr]
            | [test-expr]

[test-expr then-body ...+]

[test-expr => proc-expr]

[test-expr]
syntax
else
syntax
=>
syntax
(and expr ...)
syntax
(or expr ...)
syntax
(case val-expr case-clause ...)
 
case-clause = [(datum ...) then-body ...+]
            | [else then-body ...+]
syntax
(define id expr)
(define (head args) body ...+)
 
head = id
     | (head args)
        
args = arg ...
     | arg ... . rest-id
        
 arg = arg-id
     | [arg-id default-expr]
     | keyword arg-id
     | keyword [arg-id default-expr]
syntax
(define-values (id ...) expr)
syntax
(define-syntax id expr)
(define-syntax (head args) body ...+)
syntax
(define-syntaxes (id ...) expr)
syntax
(define-for-syntax id expr)
(define-for-syntax (head args) body ...+)
syntax
(define-values-for-syntax (id ...) expr)
syntax
(define-require-syntax id proc-expr)
(define-require-syntax (id args ...) body ...+)
procedure
(syntax-local-require-introduce stx) -> syntax?
  stx : syntax?
syntax
(define-provide-syntax id proc-expr)
(define-provide-syntax (id args ...) body ...+)
procedure
(syntax-local-provide-introduce stx) -> syntax?
  stx : syntax?
syntax
(begin form ...)
(begin expr ...+)
syntax
(begin0 expr ...+)
syntax
(begin-for-syntax form ...)
syntax
(when test-expr body ...+)
syntax
(unless test-expr body ...+)
syntax
(set! id expr)
syntax
(set!-values (id ...) expr)
syntax
(for (for-clause ...) body-or-break ... body)
 
   for-clause = [id seq-expr]
              | [(id ...) seq-expr]
              | #:when guard-expr
              | #:unless guard-expr
              | break-clause
                 
 break-clause = #:break guard-expr
              | #:final guard-expr
                 
body-or-break = body
              | break-clause
 
  seq-expr : sequence?
syntax
(for/list (for-clause ...) body-or-break ... body)
syntax
(for/vector maybe-length (for-clause ...) body-or-break ... body)
 
maybe-length = 
             | #:length length-expr
             | #:length length-expr #:fill fill-expr
 
  length-expr : exact-nonnegative-integer?
syntax
(for/hash (for-clause ...) body-or-break ... body)
syntax
(for/hasheq (for-clause ...) body-or-break ... body)
syntax
(for/hasheqv (for-clause ...) body-or-break ... body)
syntax
(for/and (for-clause ...) body-or-break ... body)
syntax
(for/or (for-clause ...) body-or-break ... body)
syntax
(for/sum (for-clause ...) body-or-break ... body)
syntax
(for/product (for-clause ...) body-or-break ... body)
syntax
(for/lists (id ...) (for-clause ...) body-or-break ... body)
syntax
(for/first (for-clause ...) body-or-break ... body)
syntax
(for/last (for-clause ...) body-or-break ... body)
syntax
(for/fold ([accum-id init-expr] ...) (for-clause ...)
  body-or-break ... body)
syntax
(for* (for-clause ...) body-or-break ... body)
syntax
(for*/list (for-clause ...) body-or-break ... body)
syntax
(for*/lists (id ...) (for-clause ...) body-or-break ... body)
syntax
(for*/vector maybe-length (for-clause ...) body-or-break ... body)
syntax
(for*/hash (for-clause ...) body-or-break ... body)
syntax
(for*/hasheq (for-clause ...) body-or-break ... body)
syntax
(for*/hasheqv (for-clause ...) body-or-break ... body)
syntax
(for*/and (for-clause ...) body-or-break ... body)
syntax
(for*/or (for-clause ...) body-or-break ... body)
syntax
(for*/sum (for-clause ...) body-or-break ... body)
syntax
(for*/product (for-clause ...) body-or-break ... body)
syntax
(for*/first (for-clause ...) body-or-break ... body)
syntax
(for*/last (for-clause ...) body-or-break ... body)
syntax
(for*/fold ([accum-id init-expr] ...) (for-clause ...)
  body-or-break ... body)
syntax
(for/fold/derived orig-datum
  ([accum-id init-expr] ...) (for-clause ...)
  body-or-break ... body)
syntax
(for*/fold/derived orig-datum
  ([accum-id init-expr] ...) (for-clause ...)
  body-or-break ... body)
syntax
(define-sequence-syntax id
  expr-transform-expr
  clause-transform-expr)
 
  expr-transform-expr : (or/c (-> identifier?)
                              (syntax? . -> . syntax?))
  clause-transform-expr : (syntax? . -> . syntax?)
syntax
(:do-in ([(outer-id ...) outer-expr] ...)
        outer-check
        ([loop-id loop-expr] ...)
        pos-guard
        ([(inner-id ...) inner-expr] ...)
        pre-guard
        post-guard
        (loop-arg ...))
procedure
(for-clause-syntax-protect stx) -> syntax?
  stx : syntax?
syntax
(do ([id init-expr step-expr-maybe] ...)
    (stop?-expr finish-expr ...)
  expr ...)
 
step-expr-maybe = 
                | step-expr
syntax
(with-continuation-mark key-expr val-expr result-expr)
syntax
(quasiquote datum)
syntax
unquote
syntax
unquote-splicing
syntax
(quote-syntax datum)
syntax
(#%top-interaction . form)
syntax
(block defn-or-expr ...)
syntax
(#%stratified-body defn-or-expr ...)
syntax
(begin-encourage-inline form ...)
syntax
(define-inline id expr)
(define-inline (head args) body ...+)
 
head = id
     | (head args)
        
args = arg ...
     | arg ... . rest-id
        
 arg = arg-id
     | [arg-id default-expr]
     | keyword arg-id
     | keyword [arg-id default-expr]
syntax
(lazy-require [module-path (fun-import ...)] ...)
 
fun-import = fun-id
           | (orig-fun-id fun-id)
procedure
(boolean? v) -> boolean?
  v : any/c
procedure
(not v) -> boolean?
  v : any/c
procedure
(equal? v1 v2) -> boolean?
  v1 : any/c
  v2 : any/c
procedure
(eqv? v1 v2) -> boolean?
  v1 : any/c
  v2 : any/c
procedure
(eq? v1 v2) -> boolean?
  v1 : any/c
  v2 : any/c
procedure
(equal?/recur v1 v2 recur-proc) -> boolean?
  v1 : any/c
  v2 : any/c
  recur-proc : (any/c any/c -> any/c)
procedure
(immutable? v) -> boolean?
  v : any/c
value
gen:equal+hash : any/c
value
prop:equal+hash : struct-type-property?
value
true : boolean?
value
false : boolean?
procedure
(symbol=? a b) -> boolean?
  a : symbol?
  b : symbol?
procedure
(boolean=? a b) -> boolean?
  a : boolean?
  b : boolean?
procedure
(false? v) -> boolean?
  v : any/c
syntax
(nand expr ...)
syntax
(nor expr ...)
syntax
(implies expr1 expr2)
procedure
(xor b1 b2) -> any
  b1 : any/c
  b2 : any/c
procedure
(number? v) -> boolean?
  v : any/c
procedure
(complex? v) -> boolean?
  v : any/c
procedure
(real? v) -> boolean?
  v : any/c
procedure
(rational? v) -> boolean?
  v : any/c
procedure
(integer? v) -> boolean?
  v : any/c
procedure
(exact-integer? v) -> boolean?
  v : any/c
procedure
(exact-nonnegative-integer? v) -> boolean?
  v : any/c
procedure
(exact-positive-integer? v) -> boolean?
  v : any/c
procedure
(inexact-real? v) -> boolean?
  v : any/c
procedure
(fixnum? v) -> boolean?
  v : any/c
procedure
(flonum? v) -> boolean?
  v : any/c
procedure
(double-flonum? v) -> boolean?
  v : any/c
procedure
(single-flonum? v) -> boolean?
  v : any/c
procedure
(zero? z) -> boolean?
  z : number?
procedure
(positive? x) -> boolean?
  x : real?
procedure
(negative? x) -> boolean?
  x : real?
procedure
(even? n) -> boolean?
  n : integer?
procedure
(odd? n) -> boolean?
  n : integer?
procedure
(exact? z) -> boolean?
  z : number?
procedure
(inexact? z) -> boolean?
  z : number?
procedure
(inexact->exact z) -> exact?
  z : number?
procedure
(exact->inexact z) -> inexact?
  z : number?
procedure
(real->single-flonum x) -> single-flonum?
  x : real?
procedure
(real->double-flonum x) -> flonum?
  x : real?
procedure
(+ z ...) -> number?
  z : number?
procedure
(- z) -> number?
  z : number?
(- z w ...+) -> number?
  z : number?
  w : number?
procedure
(* z ...) -> number?
  z : number?
procedure
(/ z) -> number?
  z : number?
(/ z w ...+) -> number?
  z : number?
  w : number?
procedure
(quotient n m) -> integer?
  n : integer?
  m : integer?
procedure
(remainder n m) -> integer?
  n : integer?
  m : integer?
procedure
(quotient/remainder n m) -> integer? integer?
  n : integer?
  m : integer?
procedure
(modulo n m) -> integer?
  n : integer?
  m : integer?
procedure
(add1 z) -> number?
  z : number?
procedure
(sub1 z) -> number?
  z : number?
procedure
(abs x) -> number?
  x : real?
procedure
(max x ...+) -> real?
  x : real?
procedure
(min x ...+) -> real?
  x : real?
procedure
(gcd n ...) -> rational?
  n : rational?
procedure
(lcm n ...) -> rational?
  n : rational?
procedure
(round x) -> (or/c integer? +inf.0 -inf.0 +nan.0)
  x : real?
procedure
(floor x) -> (or/c integer? +inf.0 -inf.0 +nan.0)
  x : real?
procedure
(ceiling x) -> (or/c integer? +inf.0 -inf.0 +nan.0)
  x : real?
procedure
(truncate x) -> (or/c integer? +inf.0 -inf.0 +nan.0)
  x : real?
procedure
(numerator q) -> integer?
  q : rational?
procedure
(denominator q) -> integer?
  q : rational?
procedure
(rationalize x tolerance) -> real?
  x : real?
  tolerance : real?
procedure
(= z w ...+) -> boolean?
  z : number?
  w : number?
procedure
(< x y ...+) -> boolean?
  x : real?
  y : real?
procedure
(<= x y ...+) -> boolean?
  x : real?
  y : real?
procedure
(> x y ...+) -> boolean?
  x : real?
  y : real?
procedure
(>= x y ...+) -> boolean?
  x : real?
  y : real?
procedure
(sqrt z) -> number?
  z : number?
procedure
(integer-sqrt n) -> complex?
  n : integer?
procedure
(integer-sqrt/remainder n) -> complex? integer?
  n : integer?
procedure
(expt z w) -> number?
  z : number?
  w : number?
procedure
(exp z) -> number?
  z : number?
procedure
(log z) -> number?
  z : number?
procedure
(sin z) -> number?
  z : number?
procedure
(cos z) -> number?
  z : number?
procedure
(tan z) -> number?
  z : number?
procedure
(asin z) -> number?
  z : number?
procedure
(acos z) -> number?
  z : number?
procedure
(atan z) -> number?
  z : number?
(atan y x) -> number?
  y : real?
  x : real?
procedure
(make-rectangular x y) -> number?
  x : real?
  y : real?
procedure
(make-polar magnitude angle) -> number?
  magnitude : real?
  angle : real?
procedure
(real-part z) -> real?
  z : number?
procedure
(imag-part z) -> real?
  z : number?
procedure
(magnitude z) -> (and/c real? (not/c negative?))
  z : number?
procedure
(angle z) -> real?
  z : number?
procedure
(bitwise-ior n ...) -> exact-integer?
  n : exact-integer?
procedure
(bitwise-and n ...) -> exact-integer?
  n : exact-integer?
procedure
(bitwise-xor n ...) -> exact-integer?
  n : exact-integer?
procedure
(bitwise-not n) -> exact-integer?
  n : exact-integer?
procedure
(bitwise-bit-set? n m) -> boolean?
  n : exact-integer?
  m : exact-nonnegative-integer?
procedure
(bitwise-bit-field n start end) -> exact-integer?
  n : exact-integer?
  start : exact-nonnegative-integer?
  end : (and/c exact-nonnegative-integer?
               (start . <= . end))
procedure
(arithmetic-shift n m) -> exact-integer?
  n : exact-integer?
  m : exact-integer?
procedure
(integer-length n) -> exact-integer?
  n : exact-integer?
procedure
(random k [rand-gen]) -> exact-nonnegative-integer?
  k : (integer-in 1 4294967087)
  rand-gen : pseudo-random-generator?
           = (current-pseudo-random-generator)
(random [rand-gen]) -> (and/c real? inexact? (>/c 0) (</c 1))
  rand-gen : pseudo-random-generator?
           = (current-pseudo-random-generator)
procedure
(random-seed k) -> void?
  k : (integer-in 1 (sub1 (expt 2 31)))
procedure
(make-pseudo-random-generator) -> pseudo-random-generator?
procedure
(pseudo-random-generator? v) -> boolean?
  v : any/c
parameter
(current-pseudo-random-generator) -> pseudo-random-generator?
(current-pseudo-random-generator rand-gen) -> void?
  rand-gen : pseudo-random-generator?
procedure
(pseudo-random-generator->vector rand-gen)
 -> pseudo-random-generator-vector?
  rand-gen : pseudo-random-generator?
procedure
(vector->pseudo-random-generator vec)
 -> pseudo-random-generator?
  vec : pseudo-random-generator-vector?
procedure
(vector->pseudo-random-generator! rand-gen     
                                  vec)     -> void?
  rand-gen : pseudo-random-generator?
  vec : pseudo-random-generator-vector?
procedure
(pseudo-random-generator-vector? v) -> boolean?
  v : any/c
procedure
(number->string z [radix]) -> string?
  z : number?
  radix : (or/c 2 8 10 16) = 10
procedure
(string->number s [radix]) -> (or/c number? #f)
  s : string?
  radix : (integer-in 2 16) = 10
procedure
(real->decimal-string n [decimal-digits]) -> string?
  n : real?
  decimal-digits : exact-nonnegative-integer? = 2
procedure
(integer-bytes->integer  bstr            
                         signed?         
                        [big-endian?     
                         start           
                         end])       -> exact-integer?
  bstr : bytes?
  signed? : any/c
  big-endian? : any/c = (system-big-endian?)
  start : exact-nonnegative-integer? = 0
  end : exact-nonnegative-integer? = (bytes-length bstr)
procedure
(integer->integer-bytes  n               
                         size-n          
                         signed?         
                        [big-endian?     
                         dest-bstr       
                         start])     -> bytes?
  n : exact-integer?
  size-n : (or/c 2 4 8)
  signed? : any/c
  big-endian? : any/c = (system-big-endian?)
  dest-bstr : (and/c bytes? (not/c immutable?))
            = (make-bytes size-n)
  start : exact-nonnegative-integer? = 0
procedure
(floating-point-bytes->real  bstr            
                            [big-endian?     
                             start           
                             end])       -> flonum?
  bstr : bytes?
  big-endian? : any/c = (system-big-endian?)
  start : exact-nonnegative-integer? = 0
  end : exact-nonnegative-integer? = (bytes-length bstr)
procedure
(real->floating-point-bytes  x               
                             size-n          
                            [big-endian?     
                             dest-bstr       
                             start])     -> bytes?
  x : real?
  size-n : (or/c 4 8)
  big-endian? : any/c = (system-big-endian?)
  dest-bstr : (and/c bytes? (not/c immutable?))
            = (make-bytes size-n)
  start : exact-nonnegative-integer? = 0
procedure
(system-big-endian?) -> boolean?
value
pi : flonum?
value
pi.f : single-flonum?
procedure
(degrees->radians x) -> real?
  x : real?
procedure
(radians->degrees x) -> real?
  x : real?
procedure
(sqr z) -> number?
  z : number?
procedure
(sgn x) -> (or/c (=/c -1) (=/c 0) (=/c 1) +nan.0 +nan.f)
  x : real?
procedure
(conjugate z) -> number?
  z : number?
procedure
(sinh z) -> number?
  z : number?
procedure
(cosh z) -> number?
  z : number?
procedure
(tanh z) -> number?
  z : number?
procedure
(exact-round x) -> exact-integer?
  x : rational?
procedure
(exact-floor x) -> exact-integer?
  x : rational?
procedure
(exact-ceiling x) -> exact-integer?
  x : rational?
procedure
(exact-truncate x) -> exact-integer?
  x : rational?
procedure
(order-of-magnitude r) -> (and/c exact? integer?)
  r : (and/c real? positive?)
procedure
(nan? x) -> boolean?
  x : real?
procedure
(infinite? x) -> boolean?
  x : real?
procedure
(fl+ a b) -> flonum?
  a : flonum?
  b : flonum?
procedure
(fl- a b) -> flonum?
  a : flonum?
  b : flonum?
procedure
(fl* a b) -> flonum?
  a : flonum?
  b : flonum?
procedure
(fl/ a b) -> flonum?
  a : flonum?
  b : flonum?
procedure
(flabs a) -> flonum?
  a : flonum?
procedure
(fl= a b) -> boolean?
  a : flonum?
  b : flonum?
procedure
(fl< a b) -> boolean?
  a : flonum?
  b : flonum?
procedure
(fl> a b) -> boolean?
  a : flonum?
  b : flonum?
procedure
(fl<= a b) -> boolean?
  a : flonum?
  b : flonum?
procedure
(fl>= a b) -> boolean?
  a : flonum?
  b : flonum?
procedure
(flmin a b) -> flonum?
  a : flonum?
  b : flonum?
procedure
(flmax a b) -> flonum?
  a : flonum?
  b : flonum?
procedure
(flround a) -> flonum?
  a : flonum?
procedure
(flfloor a) -> flonum?
  a : flonum?
procedure
(flceiling a) -> flonum?
  a : flonum?
procedure
(fltruncate a) -> flonum?
  a : flonum?
procedure
(flsin a) -> flonum?
  a : flonum?
procedure
(flcos a) -> flonum?
  a : flonum?
procedure
(fltan a) -> flonum?
  a : flonum?
procedure
(flasin a) -> flonum?
  a : flonum?
procedure
(flacos a) -> flonum?
  a : flonum?
procedure
(flatan a) -> flonum?
  a : flonum?
procedure
(fllog a) -> flonum?
  a : flonum?
procedure
(flexp a) -> flonum?
  a : flonum?
procedure
(flsqrt a) -> flonum?
  a : flonum?
procedure
(flexpt a b) -> flonum?
  a : flonum?
  b : flonum?
procedure
(->fl a) -> flonum?
  a : exact-integer?
procedure
(fl->exact-integer a) -> exact-integer?
  a : flonum?
procedure
(make-flrectangular a b)
 -> (and/c complex?
           (lambda (c) (flonum? (real-part c)))
           (lambda (c) (flonum? (imag-part c))))
  a : flonum?
  b : flonum?
procedure
(flreal-part a) -> flonum?
  a : (and/c complex?
             (lambda (c) (flonum? (real-part c)))
             (lambda (c) (flonum? (imag-part c))))
procedure
(flimag-part a) -> flonum?
  a : (and/c complex?
             (lambda (c) (flonum? (real-part c)))
             (lambda (c) (flonum? (imag-part c))))
procedure
(flrandom rand-gen) -> (and flonum? (>/c 0) (</c 1))
  rand-gen : pseudo-random-generator?
procedure
(flvector? v) -> boolean?
  v : any/c
procedure
(flvector x ...) -> flvector?
  x : flonum?
procedure
(make-flvector size [x]) -> flvector?
  size : exact-nonnegative-integer?
  x : flonum? = 0.0
procedure
(flvector-length vec) -> exact-nonnegative-integer?
  vec : flvector?
procedure
(flvector-ref vec pos) -> flonum?
  vec : flvector?
  pos : exact-nonnegative-integer?
procedure
(flvector-set! vec pos x) -> flonum?
  vec : flvector?
  pos : exact-nonnegative-integer?
  x : flonum?
procedure
(flvector-copy vec [start end]) -> flvector?
  vec : flvector?
  start : exact-nonnegative-integer? = 0
  end : exact-nonnegative-integer? = (vector-length v)
procedure
(in-flvector vec [start stop step]) -> sequence?
  vec : flvector?
  start : exact-nonnegative-integer? = 0
  stop : (or/c exact-integer? #f) = #f
  step : (and/c exact-integer? (not/c zero?)) = 1
syntax
(for/flvector maybe-length (for-clause ...) body ...)
syntax
(for*/flvector maybe-length (for-clause ...) body ...)
 
maybe-length = 
             | #:length length-expr
             | #:length length-expr #:fill fill-expr
 
  length-expr : exact-nonnegative-integer?
  fill-expr : flonum?
procedure
(shared-flvector x ...) -> flvector?
  x : flonum?
procedure
(make-shared-flvector size [x]) -> flvector?
  size : exact-nonnegative-integer?
  x : flonum? = 0.0
procedure
(fx+ a b) -> fixnum?
  a : fixnum?
  b : fixnum?
procedure
(fx- a b) -> fixnum?
  a : fixnum?
  b : fixnum?
procedure
(fx* a b) -> fixnum?
  a : fixnum?
  b : fixnum?
procedure
(fxquotient a b) -> fixnum?
  a : fixnum?
  b : fixnum?
procedure
(fxremainder a b) -> fixnum?
  a : fixnum?
  b : fixnum?
procedure
(fxmodulo a b) -> fixnum?
  a : fixnum?
  b : fixnum?
procedure
(fxabs a) -> fixnum?
  a : fixnum?
procedure
(fxand a b) -> fixnum?
  a : fixnum?
  b : fixnum?
procedure
(fxior a b) -> fixnum?
  a : fixnum?
  b : fixnum?
procedure
(fxxor a b) -> fixnum?
  a : fixnum?
  b : fixnum?
procedure
(fxnot a) -> fixnum?
  a : fixnum?
procedure
(fxlshift a b) -> fixnum?
  a : fixnum?
  b : fixnum?
procedure
(fxrshift a b) -> fixnum?
  a : fixnum?
  b : fixnum?
procedure
(fx= a b) -> boolean?
  a : fixnum?
  b : fixnum?
procedure
(fx< a b) -> boolean?
  a : fixnum?
  b : fixnum?
procedure
(fx> a b) -> boolean?
  a : fixnum?
  b : fixnum?
procedure
(fx<= a b) -> boolean?
  a : fixnum?
  b : fixnum?
procedure
(fx>= a b) -> boolean?
  a : fixnum?
  b : fixnum?
procedure
(fxmin a b) -> fixnum?
  a : fixnum?
  b : fixnum?
procedure
(fxmax a b) -> fixnum?
  a : fixnum?
  b : fixnum?
procedure
(fx->fl a) -> flonum?
  a : fixnum?
procedure
(fl->fx a) -> fixnum?
  a : flonum?
procedure
(fxvector? v) -> boolean?
  v : any/c
procedure
(fxvector x ...) -> fxvector?
  x : fixnum?
procedure
(make-fxvector size [x]) -> fxvector?
  size : exact-nonnegative-integer?
  x : fixnum? = 0
procedure
(fxvector-length vec) -> exact-nonnegative-integer?
  vec : fxvector?
procedure
(fxvector-ref vec pos) -> fixnum?
  vec : fxvector?
  pos : exact-nonnegative-integer?
procedure
(fxvector-set! vec pos x) -> fixnum?
  vec : fxvector?
  pos : exact-nonnegative-integer?
  x : fixnum?
procedure
(fxvector-copy vec [start end]) -> fxvector?
  vec : fxvector?
  start : exact-nonnegative-integer? = 0
  end : exact-nonnegative-integer? = (vector-length v)
procedure
(in-fxvector vec [start stop step]) -> sequence?
  vec : fxvector?
  start : exact-nonnegative-integer? = 0
  stop : (or/c exact-integer? #f) = #f
  step : (and/c exact-integer? (not/c zero?)) = 1
syntax
(for/fxvector maybe-length (for-clause ...) body ...)
syntax
(for*/fxvector maybe-length (for-clause ...) body ...)
 
maybe-length = 
             | #:length length-expr
             | #:length length-expr #:fill fill-expr
 
  length-expr : exact-nonnegative-integer?
  fill-expr : fixnum?
procedure
(shared-fxvector x ...) -> fxvector?
  x : fixnum?
procedure
(make-shared-fxvector size [x]) -> fxvector?
  size : exact-nonnegative-integer?
  x : fixnum? = 0
procedure
(extflonum? v) -> boolean?
  v : any/c
procedure
(extflonum-available?) -> boolean?
procedure
(extfl+ a b) -> extflonum?
  a : extflonum?
  b : extflonum?
procedure
(extfl- a b) -> extflonum?
  a : extflonum?
  b : extflonum?
procedure
(extfl* a b) -> extflonum?
  a : extflonum?
  b : extflonum?
procedure
(extfl/ a b) -> extflonum?
  a : extflonum?
  b : extflonum?
procedure
(extflabs a) -> extflonum?
  a : extflonum?
procedure
(extfl= a b) -> boolean?
  a : extflonum?
  b : extflonum?
procedure
(extfl< a b) -> boolean?
  a : extflonum?
  b : extflonum?
procedure
(extfl> a b) -> boolean?
  a : extflonum?
  b : extflonum?
procedure
(extfl<= a b) -> boolean?
  a : extflonum?
  b : extflonum?
procedure
(extfl>= a b) -> boolean?
  a : extflonum?
  b : extflonum?
procedure
(extflmin a b) -> extflonum?
  a : extflonum?
  b : extflonum?
procedure
(extflmax a b) -> extflonum?
  a : extflonum?
  b : extflonum?
procedure
(extflround a) -> extflonum?
  a : extflonum?
procedure
(extflfloor a) -> extflonum?
  a : extflonum?
procedure
(extflceiling a) -> extflonum?
  a : extflonum?
procedure
(extfltruncate a) -> extflonum?
  a : extflonum?
procedure
(extflsin a) -> extflonum?
  a : extflonum?
procedure
(extflcos a) -> extflonum?
  a : extflonum?
procedure
(extfltan a) -> extflonum?
  a : extflonum?
procedure
(extflasin a) -> extflonum?
  a : extflonum?
procedure
(extflacos a) -> extflonum?
  a : extflonum?
procedure
(extflatan a) -> extflonum?
  a : extflonum?
procedure
(extfllog a) -> extflonum?
  a : extflonum?
procedure
(extflexp a) -> extflonum?
  a : extflonum?
procedure
(extflsqrt a) -> extflonum?
  a : extflonum?
procedure
(extflexpt a b) -> extflonum?
  a : extflonum?
  b : extflonum?
procedure
(->extfl a) -> extflonum?
  a : exact-integer?
procedure
(extfl->exact-integer a) -> exact-integer?
  a : extflonum?
procedure
(real->extfl a) -> extflonum?
  a : real?
procedure
(extfl->exact a) -> (and/c real? exact?)
  a : real?
procedure
(extfl->inexact a) -> flonum?
  a : real?
value
pi.t : extflonum?
procedure
(extflvector? v) -> boolean?
  v : any/c
procedure
(extflvector x ...) -> extflvector?
  x : extflonum?
procedure
(make-extflvector size [x]) -> extflvector?
  size : exact-nonnegative-integer?
  x : extflonum? = #i0.0
procedure
(extflvector-length vec) -> exact-nonnegative-integer?
  vec : extflvector?
procedure
(extflvector-ref vec pos) -> extflonum?
  vec : extflvector?
  pos : exact-nonnegative-integer?
procedure
(extflvector-set! vec pos x) -> extflonum?
  vec : extflvector?
  pos : exact-nonnegative-integer?
  x : extflonum?
procedure
(extflvector-copy vec [start end]) -> extflvector?
  vec : extflvector?
  start : exact-nonnegative-integer? = 0
  end : exact-nonnegative-integer? = (vector-length v)
procedure
(in-extflvector vec [start stop step]) -> sequence?
  vec : extflvector?
  start : exact-nonnegative-integer? = 0
  stop : (or/c exact-integer? #f) = #f
  step : (and/c exact-integer? (not/c zero?)) = 1
syntax
(for/extflvector maybe-length (for-clause ...) body ...)
syntax
(for*/extflvector maybe-length (for-clause ...) body ...)
 
maybe-length = 
             | #:length length-expr
             | #:length length-expr #:fill fill-expr
 
  length-expr : exact-nonnegative-integer?
  fill-expr : extflonum?
procedure
(make-shared-extflvector size [x]) -> extflvector?
  size : exact-nonnegative-integer?
  x : extflonum? = #i0.0
procedure
(floating-point-bytes->extfl  bstr            
                             [big-endian?     
                              start           
                              end])       -> extflonum?
  bstr : bytes?
  big-endian? : any/c = (system-big-endian?)
  start : exact-nonnegative-integer? = 0
  end : exact-nonnegative-integer? = (bytes-length bstr)
procedure
(extfl->floating-point-bytes  x               
                             [big-endian?     
                              dest-bstr       
                              start])     -> bytes?
  x : extflonum?
  big-endian? : any/c = (system-big-endian?)
  dest-bstr : (and/c bytes? (not/c immutable?))
            = (make-bytes 10)
  start : exact-nonnegative-integer? = 0
procedure
(string? v) -> boolean?
  v : any/c
procedure
(make-string k [char]) -> string?
  k : exact-nonnegative-integer?
  char : char? = #\nul
procedure
(string char ...) -> string?
  char : char?
procedure
(string->immutable-string str) -> (and/c string? immutable?)
  str : string?
procedure
(string-length str) -> exact-nonnegative-integer?
  str : string?
procedure
(string-ref str k) -> char?
  str : string?
  k : exact-nonnegative-integer?
procedure
(string-set! str k char) -> void?
  str : (and/c string? (not/c immutable?))
  k : exact-nonnegative-integer?
  char : char?
procedure
(substring str start [end]) -> string?
  str : string?
  start : exact-nonnegative-integer?
  end : exact-nonnegative-integer? = (string-length str)
procedure
(string-copy str) -> string?
  str : string?
procedure
(string-copy!  dest           
               dest-start     
               src            
              [src-start      
               src-end])  -> void?
  dest : (and/c string? (not/c immutable?))
  dest-start : exact-nonnegative-integer?
  src : string?
  src-start : exact-nonnegative-integer? = 0
  src-end : exact-nonnegative-integer? = (string-length src)
procedure
(string-fill! dest char) -> void?
  dest : (and/c string? (not/c immutable?))
  char : char?
procedure
(string-append str ...) -> string?
  str : string?
procedure
(string->list str) -> (listof char?)
  str : string?
procedure
(list->string lst) -> string?
  lst : (listof char?)
procedure
(build-string n proc) -> string?
  n : exact-nonnegative-integer?
  proc : (exact-nonnegative-integer? . -> . char?)
procedure
(string=? str1 str2 ...+) -> boolean?
  str1 : string?
  str2 : string?
procedure
(string<? str1 str2 ...+) -> boolean?
  str1 : string?
  str2 : string?
procedure
(string<=? str1 str2 ...+) -> boolean?
  str1 : string?
  str2 : string?
procedure
(string>? str1 str2 ...+) -> boolean?
  str1 : string?
  str2 : string?
procedure
(string>=? str1 str2 ...+) -> boolean?
  str1 : string?
  str2 : string?
procedure
(string-ci=? str1 str2 ...+) -> boolean?
  str1 : string?
  str2 : string?
procedure
(string-ci<? str1 str2 ...+) -> boolean?
  str1 : string?
  str2 : string?
procedure
(string-ci<=? str1 str2 ...+) -> boolean?
  str1 : string?
  str2 : string?
procedure
(string-ci>? str1 str2 ...+) -> boolean?
  str1 : string?
  str2 : string?
procedure
(string-ci>=? str1 str2 ...+) -> boolean?
  str1 : string?
  str2 : string?
procedure
(string-upcase str) -> string?
  str : string?
procedure
(string-downcase string) -> string?
  string : string?
procedure
(string-titlecase string) -> string?
  string : string?
procedure
(string-foldcase string) -> string?
  string : string?
procedure
(string-normalize-nfd string) -> string?
  string : string?
procedure
(string-normalize-nfkd string) -> string?
  string : string?
procedure
(string-normalize-nfc string) -> string?
  string : string?
procedure
(string-normalize-nfkc string) -> string?
  string : string?
procedure
(string-locale=? str1 str2 ...+) -> boolean?
  str1 : string?
  str2 : string?
procedure
(string-locale<? str1 str2 ...+) -> boolean?
  str1 : string?
  str2 : string?
procedure
(string-locale>? str1 str2 ...+) -> boolean?
  str1 : string?
  str2 : string?
procedure
(string-locale-ci=? str1 str2 ...+) -> boolean?
  str1 : string?
  str2 : string?
procedure
(string-locale-ci<? str1 str2 ...+) -> boolean?
  str1 : string?
  str2 : string?
procedure
(string-locale-ci>? str1 str2 ...+) -> boolean?
  str1 : string?
  str2 : string?
procedure
(string-locale-upcase string) -> string?
  string : string?
procedure
(string-locale-downcase string) -> string?
  string : string?
procedure
(string-append* str ... strs) -> string?
  str : string?
  strs : (listof string?)
procedure
(string-join  strs                            
             [sep                             
              #:before-first before-first     
              #:before-last before-last       
              #:after-last after-last])   -> string?
  strs : (listof string?)
  sep : string? = " "
  before-first : string? = ""
  before-last : string? = sep
  after-last : string? = ""
procedure
(string-normalize-spaces  str                     
                         [sep                     
                          space                   
                          #:trim? trim?           
                          #:repeat? repeat?]) -> string?
  str : string?
  sep : (or/c string? regexp?) = #px"\\s+"
  space : string? = " "
  trim? : any/c = #t
  repeat? : any/c = #f
procedure
(string-replace str from to [#:all? all?]) -> string?
  str : string?
  from : (or/c string? regexp?)
  to : string?
  all? : any/c = #t
procedure
(string-split  str                     
              [sep                     
               #:trim? trim?           
               #:repeat? repeat?]) -> (listof string?)
  str : string?
  sep : (or/c string? regexp?) = #px"\\s+"
  trim? : any/c = #t
  repeat? : any/c = #f
procedure
(string-trim  str                     
             [sep                     
              #:left? left?           
              #:right? right?         
              #:repeat? repeat?]) -> string?
  str : string?
  sep : (or/c string? regexp?) = #px"\\s+"
  left? : any/c = #t
  right? : any/c = #t
  repeat? : any/c = #f
procedure
(~a  v                                         
     ...                                       
    [#:separator separator                     
     #:width width                             
     #:max-width max-width                     
     #:min-width min-width                     
     #:limit-marker limit-marker               
     #:align align                             
     #:pad-string pad-string                   
     #:left-pad-string left-pad-string         
     #:right-pad-string right-pad-string]) -> string?
  v : any/c
  separator : string? = ""
  width : (or/c exact-nonnegative-integer? #f) = #f
  max-width : (or/c exact-nonnegative-integer? +inf.0)
            = (or width +inf.0)
  min-width : exact-nonnegative-integer? = (or width 0)
  limit-marker : string? = ""
  align : (or/c 'left 'center 'right) = 'left
  pad-string : non-empty-string? = " "
  left-pad-string : non-empty-string? = pad-string
  right-pad-string : non-empty-string? = pad-string
procedure
(~v  v                                         
     ...                                       
    [#:separator separator                     
     #:width width                             
     #:max-width max-width                     
     #:min-width min-width                     
     #:limit-marker limit-marker               
     #:align align                             
     #:pad-string pad-string                   
     #:left-pad-string left-pad-string         
     #:right-pad-string right-pad-string]) -> string?
  v : any/c
  separator : string? = " "
  width : (or/c exact-nonnegative-integer? #f) = #f
  max-width : (or/c exact-nonnegative-integer? +inf.0)
            = (or width +inf.0)
  min-width : exact-nonnegative-integer? = (or width 0)
  limit-marker : string? = "..."
  align : (or/c 'left 'center 'right) = 'left
  pad-string : non-empty-string? = " "
  left-pad-string : non-empty-string? = pad-string
  right-pad-string : non-empty-string? = pad-string
procedure
(~s  v                                         
     ...                                       
    [#:separator separator                     
     #:width width                             
     #:max-width max-width                     
     #:min-width min-width                     
     #:limit-marker limit-marker               
     #:align align                             
     #:pad-string pad-string                   
     #:left-pad-string left-pad-string         
     #:right-pad-string right-pad-string]) -> string?
  v : any/c
  separator : string? = " "
  width : (or/c exact-nonnegative-integer? #f) = #f
  max-width : (or/c exact-nonnegative-integer? +inf.0)
            = (or width +inf.0)
  min-width : exact-nonnegative-integer? = (or width 0)
  limit-marker : string? = "..."
  align : (or/c 'left 'center 'right) = 'left
  pad-string : non-empty-string? = " "
  left-pad-string : non-empty-string? = pad-string
  right-pad-string : non-empty-string? = pad-string
procedure
(~e  v                                         
     ...                                       
    [#:separator separator                     
     #:width width                             
     #:max-width max-width                     
     #:min-width min-width                     
     #:limit-marker limit-marker               
     #:align align                             
     #:pad-string pad-string                   
     #:left-pad-string left-pad-string         
     #:right-pad-string right-pad-string]) -> string?
  v : any/c
  separator : string? = " "
  width : (or/c exact-nonnegative-integer? #f) = #f
  max-width : (or/c exact-nonnegative-integer? +inf.0)
            = (or width +inf.0)
  min-width : exact-nonnegative-integer? = (or width 0)
  limit-marker : string? = "..."
  align : (or/c 'left 'center 'right) = 'left
  pad-string : non-empty-string? = " "
  left-pad-string : non-empty-string? = pad-string
  right-pad-string : non-empty-string? = pad-string
procedure
(~r  x                                     
    [#:sign sign                           
     #:base base                           
     #:precision precision                 
     #:notation notation                   
     #:format-exponent format-exponent     
     #:min-width min-width                 
     #:pad-string pad-string])         -> string?
  x : rational?
  sign : (or/c #f '+ '++ 'parens
               (let ([ind (or/c string? (list/c string? string?))])
                 (list/c ind ind ind)))
       = #f
  base : (or/c (integer-in 2 36) (list/c 'up (integer-in 2 36)))
       = 10
  precision : (or/c exact-nonnegative-integer?              = 6
                    (list/c '= exact-nonnegative-integer?))
  notation : (or/c 'positional 'exponential
                   (-> rational? (or/c 'positional 'exponential)))
           = 'positional
  format-exponent : (or/c #f string? (-> exact-integer? string?))
                  = #f
  min-width : exact-positive-integer? = 1
  pad-string : non-empty-string? = " "
procedure
(~.a  v                                         
      ...                                       
     [#:separator separator                     
      #:width width                             
      #:max-width max-width                     
      #:min-width min-width                     
      #:limit-marker limit-marker               
      #:align align                             
      #:pad-string pad-string                   
      #:left-pad-string left-pad-string         
      #:right-pad-string right-pad-string]) -> string?
  v : any/c
  separator : string? = ""
  width : (or/c exact-nonnegative-integer? #f) = #f
  max-width : (or/c exact-nonnegative-integer? +inf.0)
            = (or width +inf.0)
  min-width : exact-nonnegative-integer? = (or width 0)
  limit-marker : string? = ""
  align : (or/c 'left 'center 'right) = 'left
  pad-string : non-empty-string? = " "
  left-pad-string : non-empty-string? = pad-string
  right-pad-string : non-empty-string? = pad-string
procedure
(~.v  v                                         
      ...                                       
     [#:separator separator                     
      #:width width                             
      #:max-width max-width                     
      #:min-width min-width                     
      #:limit-marker limit-marker               
      #:align align                             
      #:pad-string pad-string                   
      #:left-pad-string left-pad-string         
      #:right-pad-string right-pad-string]) -> string?
  v : any/c
  separator : string? = " "
  width : (or/c exact-nonnegative-integer? #f) = #f
  max-width : (or/c exact-nonnegative-integer? +inf.0)
            = (or width +inf.0)
  min-width : exact-nonnegative-integer? = (or width 0)
  limit-marker : string? = "..."
  align : (or/c 'left 'center 'right) = 'left
  pad-string : non-empty-string? = " "
  left-pad-string : non-empty-string? = pad-string
  right-pad-string : non-empty-string? = pad-string
procedure
(~.s  v                                         
      ...                                       
     [#:separator separator                     
      #:width width                             
      #:max-width max-width                     
      #:min-width min-width                     
      #:limit-marker limit-marker               
      #:align align                             
      #:pad-string pad-string                   
      #:left-pad-string left-pad-string         
      #:right-pad-string right-pad-string]) -> string?
  v : any/c
  separator : string? = " "
  width : (or/c exact-nonnegative-integer? #f) = #f
  max-width : (or/c exact-nonnegative-integer? +inf.0)
            = (or width +inf.0)
  min-width : exact-nonnegative-integer? = (or width 0)
  limit-marker : string? = "..."
  align : (or/c 'left 'center 'right) = 'left
  pad-string : non-empty-string? = " "
  left-pad-string : non-empty-string? = pad-string
  right-pad-string : non-empty-string? = pad-string
procedure
(bytes? v) -> boolean?
  v : any/c
procedure
(make-bytes k [b]) -> bytes?
  k : exact-nonnegative-integer?
  b : byte? = 0
procedure
(bytes b ...) -> bytes?
  b : byte?
procedure
(bytes->immutable-bytes bstr) -> (and/c bytes? immutable?)
  bstr : bytes?
procedure
(byte? v) -> boolean?
  v : any/c
procedure
(bytes-length bstr) -> exact-nonnegative-integer?
  bstr : bytes?
procedure
(bytes-ref bstr k) -> byte?
  bstr : bytes?
  k : exact-nonnegative-integer?
procedure
(bytes-set! bstr k b) -> void?
  bstr : (and/c bytes? (not/c immutable?))
  k : exact-nonnegative-integer?
  b : byte?
procedure
(subbytes bstr start [end]) -> bytes?
  bstr : bytes?
  start : exact-nonnegative-integer?
  end : exact-nonnegative-integer? = (bytes-length str)
procedure
(bytes-copy bstr) -> bytes?
  bstr : bytes?
procedure
(bytes-copy!  dest           
              dest-start     
              src            
             [src-start      
              src-end])  -> void?
  dest : (and/c bytes? (not/c immutable?))
  dest-start : exact-nonnegative-integer?
  src : bytes?
  src-start : exact-nonnegative-integer? = 0
  src-end : exact-nonnegative-integer? = (bytes-length src)
procedure
(bytes-fill! dest b) -> void?
  dest : (and/c bytes? (not/c immutable?))
  b : byte?
procedure
(bytes-append bstr ...) -> bytes?
  bstr : bytes?
procedure
(bytes->list bstr) -> (listof byte?)
  bstr : bytes?
procedure
(list->bytes lst) -> bytes?
  lst : (listof byte?)
procedure
(make-shared-bytes k [b]) -> bytes?
  k : exact-nonnegative-integer?
  b : byte? = 0
procedure
(shared-bytes b ...) -> bytes?
  b : byte?
procedure
(bytes=? bstr1 bstr2 ...+) -> boolean?
  bstr1 : bytes?
  bstr2 : bytes?
procedure
(bytes<? bstr1 bstr2 ...+) -> boolean?
  bstr1 : bytes?
  bstr2 : bytes?
procedure
(bytes>? bstr1 bstr2 ...+) -> boolean?
  bstr1 : bytes?
  bstr2 : bytes?
procedure
(bytes->string/utf-8 bstr [err-char start end]) -> string?
  bstr : bytes?
  err-char : (or/c #f char?) = #f
  start : exact-nonnegative-integer? = 0
  end : exact-nonnegative-integer? = (bytes-length bstr)
procedure
(bytes->string/locale  bstr         
                      [err-char     
                       start        
                       end])    -> string?
  bstr : bytes?
  err-char : (or/c #f char?) = #f
  start : exact-nonnegative-integer? = 0
  end : exact-nonnegative-integer? = (bytes-length bstr)
procedure
(bytes->string/latin-1  bstr         
                       [err-char     
                        start        
                        end])    -> string?
  bstr : bytes?
  err-char : (or/c #f char?) = #f
  start : exact-nonnegative-integer? = 0
  end : exact-nonnegative-integer? = (bytes-length bstr)
procedure
(string->bytes/utf-8 str [err-byte start end]) -> bytes?
  str : string?
  err-byte : (or/c #f byte?) = #f
  start : exact-nonnegative-integer? = 0
  end : exact-nonnegative-integer? = (string-length str)
procedure
(string->bytes/locale str [err-byte start end]) -> bytes?
  str : string?
  err-byte : (or/c #f byte?) = #f
  start : exact-nonnegative-integer? = 0
  end : exact-nonnegative-integer? = (string-length str)
procedure
(string->bytes/latin-1  str          
                       [err-byte     
                        start        
                        end])    -> bytes?
  str : string?
  err-byte : (or/c #f byte?) = #f
  start : exact-nonnegative-integer? = 0
  end : exact-nonnegative-integer? = (string-length str)
procedure
(string-utf-8-length str [start end]) -> exact-nonnegative-integer?
  str : string?
  start : exact-nonnegative-integer? = 0
  end : exact-nonnegative-integer? = (string-length str)
procedure
(bytes-utf-8-length bstr [err-char start end])
 -> exact-nonnegative-integer?
  bstr : bytes?
  err-char : (or/c #f char?) = #f
  start : exact-nonnegative-integer? = 0
  end : exact-nonnegative-integer? = (bytes-length bstr)
procedure
(bytes-utf-8-ref bstr [skip err-char start end]) -> char?
  bstr : bytes?
  skip : exact-nonnegative-integer? = 0
  err-char : (or/c #f char?) = #f
  start : exact-nonnegative-integer? = 0
  end : exact-nonnegative-integer? = (bytes-length bstr)
procedure
(bytes-utf-8-index  bstr         
                   [skip         
                    err-char     
                    start        
                    end])    -> exact-nonnegative-integer?
  bstr : bytes?
  skip : exact-nonnegative-integer? = 0
  err-char : (or/c #f char?) = #f
  start : exact-nonnegative-integer? = 0
  end : exact-nonnegative-integer? = (bytes-length bstr)
procedure
(bytes-open-converter from-name to-name)
 -> (or/c bytes-converter? #f)
  from-name : string?
  to-name : string?
procedure
(bytes-close-converter converter) -> void
  converter : bytes-converter?
procedure
(bytes-convert  converter      
                src-bstr       
               [src-start-pos  
                src-end-pos    
                dest-bstr      
                dest-start-pos 
                dest-end-pos]) 
 -> (or/c bytes? exact-nonnegative-integer?)
    exact-nonnegative-integer?
    (or/c 'complete 'continues 'aborts 'error)
  converter : bytes-converter?
  src-bstr : bytes?
  src-start-pos : exact-nonnegative-integer? = 0
  src-end-pos : exact-nonnegative-integer?
              = (bytes-length src-bstr)
  dest-bstr : (or/c bytes? #f) = #f
  dest-start-pos : exact-nonnegative-integer? = 0
  dest-end-pos : (or/c exact-nonnegative-integer? #f)
               = (and dest-bstr
                      (bytes-length dest-bstr))
procedure
(bytes-convert-end  converter      
                   [dest-bstr      
                    dest-start-pos 
                    dest-end-pos]) 
 -> (or/c bytes? exact-nonnegative-integer?)
    (or/c 'complete 'continues)
  converter : bytes-converter?
  dest-bstr : (or/c bytes? #f) = #f
  dest-start-pos : exact-nonnegative-integer? = 0
  dest-end-pos : (or/c exact-nonnegative-integer? #f)
               = (and dest-bstr
                      (bytes-length dest-bstr))
procedure
(bytes-converter? v) -> boolean?
  v : any/c
procedure
(locale-string-encoding) -> any
procedure
(bytes-append* str ... strs) -> bytes?
  str : bytes?
  strs : (listof bytes?)
procedure
(bytes-join strs sep) -> bytes?
  strs : (listof bytes?)
  sep : bytes?
procedure
(char? v) -> boolean?
  v : any/c
procedure
(char->integer char) -> exact-integer?
  char : char?
procedure
(integer->char k) -> char?
  k : (and/c exact-integer?
             (or/c (integer-in 0 55295)
                   (integer-in 57344 1114111)))
procedure
(char-utf-8-length char) -> (integer-in 1 6)
  char : char?
procedure
(char=? char1 char2 ...+) -> boolean?
  char1 : char?
  char2 : char?
procedure
(char<? char1 char2 ...+) -> boolean?
  char1 : char?
  char2 : char?
procedure
(char<=? char1 char2 ...+) -> boolean?
  char1 : char?
  char2 : char?
procedure
(char>? char1 char2 ...+) -> boolean?
  char1 : char?
  char2 : char?
procedure
(char>=? char1 char2 ...+) -> boolean?
  char1 : char?
  char2 : char?
procedure
(char-ci=? char1 char2 ...+) -> boolean?
  char1 : char?
  char2 : char?
procedure
(char-ci<? char1 char2 ...+) -> boolean?
  char1 : char?
  char2 : char?
procedure
(char-ci<=? char1 char2 ...+) -> boolean?
  char1 : char?
  char2 : char?
procedure
(char-ci>? char1 char2 ...+) -> boolean?
  char1 : char?
  char2 : char?
procedure
(char-ci>=? char1 char2 ...+) -> boolean?
  char1 : char?
  char2 : char?
procedure
(char-alphabetic? char) -> boolean?
  char : char?
procedure
(char-lower-case? char) -> boolean?
  char : char?
procedure
(char-upper-case? char) -> boolean?
  char : char?
procedure
(char-title-case? char) -> boolean?
  char : char?
procedure
(char-numeric? char) -> boolean?
  char : char?
procedure
(char-symbolic? char) -> boolean?
  char : char?
procedure
(char-punctuation? char) -> boolean?
  char : char?
procedure
(char-graphic? char) -> boolean?
  char : char?
procedure
(char-whitespace? char) -> boolean?
  char : char?
procedure
(char-blank? char) -> boolean?
  char : char?
procedure
(char-iso-control? char) -> boolean?
  char : char?
procedure
(char-general-category char) -> symbol?
  char : char?
procedure
(make-known-char-range-list)
 -> (listof (list/c exact-nonnegative-integer?
                    exact-nonnegative-integer?
                    boolean?))
procedure
(char-upcase char) -> char?
  char : char?
procedure
(char-downcase char) -> char?
  char : char?
procedure
(char-titlecase char) -> char?
  char : char?
procedure
(char-foldcase char) -> char?
  char : char?
procedure
(symbol? v) -> boolean?
  v : any/c
procedure
(symbol-interned? sym) -> boolean?
  sym : symbol?
procedure
(symbol-unreadable? sym) -> boolean?
  sym : symbol?
procedure
(symbol->string sym) -> string?
  sym : symbol?
procedure
(string->symbol str) -> symbol?
  str : string?
procedure
(string->uninterned-symbol str) -> symbol?
  str : string?
procedure
(string->unreadable-symbol str) -> symbol?
  str : string?
procedure
(gensym [base]) -> symbol?
  base : (or/c string? symbol?) = "g"
procedure
(symbol<? a-sym b-sym ...) -> boolean?
  a-sym : symbol?
  b-sym : symbol?
procedure
(regexp? v) -> boolean?
  v : any/c
procedure
(pregexp? v) -> boolean?
  v : any/c
procedure
(byte-regexp? v) -> boolean?
  v : any/c
procedure
(byte-pregexp? v) -> boolean?
  v : any/c
procedure
(regexp str) -> regexp?
  str : string?
procedure
(pregexp string) -> pregexp?
  string : string?
procedure
(byte-regexp bstr) -> byte-regexp?
  bstr : bytes?
procedure
(byte-pregexp bstr) -> byte-pregexp?
  bstr : bytes?
procedure
(regexp-quote str [case-sensitive?]) -> string?
  str : string?
  case-sensitive? : any/c = #t
(regexp-quote bstr [case-sensitive?]) -> bytes?
  bstr : bytes?
  case-sensitive? : any/c = #t
procedure
(regexp-max-lookbehind pattern) -> exact-nonnegative-integer?
  pattern : (or/c regexp? byte-regexp?)
procedure
(regexp-match  pattern        
               input          
              [start-pos      
               end-pos        
               output-port    
               input-prefix]) 
 -> (if (and (or (string? pattern) (regexp? pattern))
             (or (string? input) (path? input)))
        (or/c #f (cons/c string? (listof (or/c string? #f))))
        (or/c #f (cons/c bytes?  (listof (or/c bytes?  #f)))))
  pattern : (or/c string? bytes? regexp? byte-regexp?)
  input : (or/c string? bytes? path? input-port?)
  start-pos : exact-nonnegative-integer? = 0
  end-pos : (or/c exact-nonnegative-integer? #f) = #f
  output-port : (or/c output-port? #f) = #f
  input-prefix : bytes? = #""
procedure
(regexp-match*  pattern                     
                input                       
               [start-pos                   
                end-pos                     
                input-prefix                
                #:match-select match-select 
                #:gap-select? gap-select])  
 -> (if (and (or (string? pattern) (regexp? pattern))
             (or (string? input) (path? input)))
        (listof (or/c string? (listof (or/c #f string?))))
        (listof (or/c bytes? (listof (or/c #f bytes?)))))
  pattern : (or/c string? bytes? regexp? byte-regexp?)
  input : (or/c string? bytes? path? input-port?)
  start-pos : exact-nonnegative-integer? = 0
  end-pos : (or/c exact-nonnegative-integer? #f) = #f
  input-prefix : bytes? = #""
  match-select : (or/c (list? . -> . (or/c any/c list?)) = car
                       #f)
  gap-select : any/c = #f
procedure
(regexp-try-match  pattern        
                   input          
                  [start-pos      
                   end-pos        
                   output-port    
                   input-prefix]) 
 -> (if (and (or (string? pattern) (regexp? pattern))
             (string? input))
        (or/c #f (cons/c string? (listof (or/c string? #f))))
        (or/c #f (cons/c bytes?  (listof (or/c bytes?  #f)))))
  pattern : (or/c string? bytes? regexp? byte-regexp?)
  input : input-port?
  start-pos : exact-nonnegative-integer? = 0
  end-pos : (or/c exact-nonnegative-integer? #f) = #f
  output-port : (or/c output-port? #f) = #f
  input-prefix : bytes? = #""
procedure
(regexp-match-positions  pattern        
                         input          
                        [start-pos      
                         end-pos        
                         output-port    
                         input-prefix]) 
 -> (or/c (cons/c (cons/c exact-nonnegative-integer?
                          exact-nonnegative-integer?)
                  (listof (or/c (cons/c exact-nonnegative-integer?
                                        exact-nonnegative-integer?)
                                #f)))
          #f)
  pattern : (or/c string? bytes? regexp? byte-regexp?)
  input : (or/c string? bytes? path? input-port?)
  start-pos : exact-nonnegative-integer? = 0
  end-pos : (or/c exact-nonnegative-integer? #f) = #f
  output-port : (or/c output-port? #f) = #f
  input-prefix : bytes? = #""
procedure
(regexp-match-positions*  pattern                       
                          input                         
                         [start-pos                     
                          end-pos                       
                          input-prefix                  
                          #:match-select match-select]) 
 -> (or/c (listof (cons/c exact-nonnegative-integer?
                          exact-nonnegative-integer?))
          (listof (listof (or/c #f (cons/c exact-nonnegative-integer?
                                           exact-nonnegative-integer?)))))
  pattern : (or/c string? bytes? regexp? byte-regexp?)
  input : (or/c string? bytes? path? input-port?)
  start-pos : exact-nonnegative-integer? = 0
  end-pos : (or/c exact-nonnegative-integer? #f) = #f
  input-prefix : bytes? = #""
  match-select : (list? . -> . (or/c any/c list?)) = car
procedure
(regexp-match?  pattern            
                input              
               [start-pos          
                end-pos            
                output-port        
                input-prefix]) -> boolean?
  pattern : (or/c string? bytes? regexp? byte-regexp?)
  input : (or/c string? bytes? path? input-port?)
  start-pos : exact-nonnegative-integer? = 0
  end-pos : (or/c exact-nonnegative-integer? #f) = #f
  output-port : (or/c output-port? #f) = #f
  input-prefix : bytes? = #""
procedure
(regexp-match-exact? pattern input) -> boolean?
  pattern : (or/c string? bytes? regexp? byte-regexp?)
  input : (or/c string? bytes? path?)
procedure
(regexp-match-peek  pattern        
                    input          
                   [start-pos      
                    end-pos        
                    progress       
                    input-prefix]) 
 -> (or/c (cons/c bytes? (listof (or/c bytes? #f)))
          #f)
  pattern : (or/c string? bytes? regexp? byte-regexp?)
  input : input-port?
  start-pos : exact-nonnegative-integer? = 0
  end-pos : (or/c exact-nonnegative-integer? #f) = #f
  progress : (or/c evt #f) = #f
  input-prefix : bytes? = #""
procedure
(regexp-match-peek-positions  pattern        
                              input          
                             [start-pos      
                              end-pos        
                              progress       
                              input-prefix]) 
 -> (or/c (cons/c (cons/c exact-nonnegative-integer?
                          exact-nonnegative-integer?)
                  (listof (or/c (cons/c exact-nonnegative-integer?
                                        exact-nonnegative-integer?)
                                #f)))
          #f)
  pattern : (or/c string? bytes? regexp? byte-regexp?)
  input : input-port?
  start-pos : exact-nonnegative-integer? = 0
  end-pos : (or/c exact-nonnegative-integer? #f) = #f
  progress : (or/c evt #f) = #f
  input-prefix : bytes? = #""
procedure
(regexp-match-peek-immediate  pattern        
                              input          
                             [start-pos      
                              end-pos        
                              progress       
                              input-prefix]) 
 -> (or/c (cons/c bytes? (listof (or/c bytes? #f)))
          #f)
  pattern : (or/c string? bytes? regexp? byte-regexp?)
  input : input-port?
  start-pos : exact-nonnegative-integer? = 0
  end-pos : (or/c exact-nonnegative-integer? #f) = #f
  progress : (or/c evt #f) = #f
  input-prefix : bytes? = #""
procedure
(regexp-match-peek-positions-immediate  pattern        
                                        input          
                                       [start-pos      
                                        end-pos        
                                        progress       
                                        input-prefix]) 
 -> (or/c (cons/c (cons/c exact-nonnegative-integer?
                          exact-nonnegative-integer?)
                  (listof (or/c (cons/c exact-nonnegative-integer?
                                        exact-nonnegative-integer?)
                                #f)))
          #f)
  pattern : (or/c string? bytes? regexp? byte-regexp?)
  input : input-port?
  start-pos : exact-nonnegative-integer? = 0
  end-pos : (or/c exact-nonnegative-integer? #f) = #f
  progress : (or/c evt #f) = #f
  input-prefix : bytes? = #""
procedure
(regexp-match-peek-positions*  pattern                       
                               input                         
                              [start-pos                     
                               end-pos                       
                               input-prefix                  
                               #:match-select match-select]) 
 -> (or/c (listof (cons/c exact-nonnegative-integer?
                          exact-nonnegative-integer?))
          (listof (listof (or/c #f (cons/c exact-nonnegative-integer?
                                           exact-nonnegative-integer?)))))
  pattern : (or/c string? bytes? regexp? byte-regexp?)
  input : input-port?
  start-pos : exact-nonnegative-integer? = 0
  end-pos : (or/c exact-nonnegative-integer? #f) = #f
  input-prefix : bytes? = #""
  match-select : (list? . -> . (or/c any/c list?)) = car
procedure
(regexp-match/end  pattern      
                   input        
                  [start-pos    
                   end-pos      
                   output-port  
                   input-prefix 
                   count])      
 -> (if (and (or (string? pattern) (regexp? pattern))
             (or/c (string? input) (path? input)))
        (or/c #f (cons/c string? (listof (or/c string? #f))))
        (or/c #f (cons/c bytes?  (listof (or/c bytes?  #f)))))
    (or/c #f bytes?)
  pattern : (or/c string? bytes? regexp? byte-regexp?)
  input : (or/c string? bytes? path? input-port?)
  start-pos : exact-nonnegative-integer? = 0
  end-pos : (or/c exact-nonnegative-integer? #f) = #f
  output-port : (or/c output-port? #f) = #f
  input-prefix : bytes? = #""
  count : nonnegative-exact-integer? = 1
procedure
(regexp-match-positions/end  pattern      
                             input        
                            [start-pos    
                             end-pos      
                             input-prefix 
                             count])      
 -> (listof (cons/c exact-nonnegative-integer?
                    exact-nonnegative-integer?))
    (or/c #f bytes?)
  pattern : (or/c string? bytes? regexp? byte-regexp?)
  input : (or/c string? bytes? path? input-port?)
  start-pos : exact-nonnegative-integer? = 0
  end-pos : (or/c exact-nonnegative-integer? #f) = #f
  input-prefix : bytes? = #""
  count : exact-nonnegative-integer? = 1
procedure
(regexp-match-peek-positions/end  pattern      
                                  input        
                                 [start-pos    
                                  end-pos      
                                  progress     
                                  input-prefix 
                                  count])      
 -> (or/c (cons/c (cons/c exact-nonnegative-integer?
                          exact-nonnegative-integer?)
                  (listof (or/c (cons/c exact-nonnegative-integer?
                                        exact-nonnegative-integer?)
                                #f)))
          #f)
    (or/c #f bytes?)
  pattern : (or/c string? bytes? regexp? byte-regexp?)
  input : input-port?
  start-pos : exact-nonnegative-integer? = 0
  end-pos : (or/c exact-nonnegative-integer? #f) = #f
  progress : (or/c evt #f) = #f
  input-prefix : bytes? = #""
  count : exact-nonnegative-integer? = 1
procedure
(regexp-match-peek-positions-immediate/end  pattern      
                                            input        
                                           [start-pos    
                                            end-pos      
                                            progress     
                                            input-prefix 
                                            count])      
 -> (or/c (cons/c (cons/c exact-nonnegative-integer?
                          exact-nonnegative-integer?)
                  (listof (or/c (cons/c exact-nonnegative-integer?
                                        exact-nonnegative-integer?)
                                #f)))
          #f)
    (or/c #f bytes?)
  pattern : (or/c string? bytes? regexp? byte-regexp?)
  input : input-port?
  start-pos : exact-nonnegative-integer? = 0
  end-pos : (or/c exact-nonnegative-integer? #f) = #f
  progress : (or/c evt #f) = #f
  input-prefix : bytes? = #""
  count : exact-nonnegative-integer? = 1
procedure
(regexp-split  pattern        
               input          
              [start-pos      
               end-pos        
               input-prefix]) 
 -> (if (and (or (string? pattern) (regexp? pattern))
             (string? input))
        (cons/c string? (listof string?))
        (cons/c bytes? (listof bytes?)))
  pattern : (or/c string? bytes? regexp? byte-regexp?)
  input : (or/c string? bytes? input-port?)
  start-pos : exact-nonnegative-integer? = 0
  end-pos : (or/c exact-nonnegative-integer? #f) = #f
  input-prefix : bytes? = #""
procedure
(regexp-replace  pattern        
                 input          
                 insert         
                [input-prefix]) 
 -> (if (and (or (string? pattern) (regexp? pattern))
             (string? input))
        string?
        bytes?)
  pattern : (or/c string? bytes? regexp? byte-regexp?)
  input : (or/c string? bytes?)
  insert : (or/c string? bytes?
                 ((string?) () #:rest (listof string?) . ->* . string?)
                 ((bytes?) () #:rest (listof bytes?) . ->* . bytes?))
  input-prefix : bytes? = #""
procedure
(regexp-replace*  pattern            
                  input              
                  insert             
                 [start-pos          
                  end-pos            
                  input-prefix]) -> (or/c string? bytes?)
  pattern : (or/c string? bytes? regexp? byte-regexp?)
  input : (or/c string? bytes?)
  insert : (or/c string? bytes?
                 ((string?) () #:rest (listof string?) . ->* . string?)
                 ((bytes?) () #:rest (listof bytes?) . ->* . bytes?))
  start-pos : exact-nonnegative-integer? = 0
  end-pos : (or/c exact-nonnegative-integer? #f) = #f
  input-prefix : bytes? = #""
procedure
(regexp-replaces input replacements) -> (or/c string? bytes?)
  input : (or/c string? bytes?)
  replacements : (listof
                  (list/c (or/c string? bytes? regexp? byte-regexp?)
                          (or/c string? bytes?
                              ((string?) () #:rest (listof string?) . ->* . string?)
                              ((bytes?) () #:rest (listof bytes?) . ->* . bytes?))))
procedure
(regexp-replace-quote str) -> string?
  str : string?
(regexp-replace-quote bstr) -> bytes?
  bstr : bytes?
procedure
(keyword? v) -> boolean?
  v : any/c
procedure
(keyword->string keyword) -> string?
  keyword : keyword?
procedure
(string->keyword str) -> keyword?
  str : string?
procedure
(keyword<? a-keyword b-keyword ...+) -> boolean?
  a-keyword : keyword?
  b-keyword : keyword?
procedure
(pair? v) -> boolean?
  v : any/c
procedure
(null? v) -> boolean?
  v : any/c
procedure
(cons a d) -> pair?
  a : any/c
  d : any/c
procedure
(car p) -> any/c
  p : pair?
procedure
(cdr p) -> any/c
  p : pair?
value
null : null?
procedure
(list? v) -> boolean?
  v : any/c
procedure
(list v ...) -> list?
  v : any/c
procedure
(list* v ... tail) -> any/c
  v : any/c
  tail : any/c
procedure
(build-list n proc) -> list?
  n : exact-nonnegative-integer?
  proc : (exact-nonnegative-integer? . -> . any)
procedure
(length lst) -> exact-nonnegative-integer?
  lst : list?
procedure
(list-ref lst pos) -> any/c
  lst : pair?
  pos : exact-nonnegative-integer?
procedure
(list-tail lst pos) -> any/c
  lst : any/c
  pos : exact-nonnegative-integer?
procedure
(append lst ...) -> list?
  lst : list?
(append lst ... v) -> any/c
  lst : list?
  v : any/c
procedure
(reverse lst) -> list?
  lst : list?
procedure
(map proc lst ...+) -> list?
  proc : procedure?
  lst : list?
procedure
(andmap proc lst ...+) -> any
  proc : procedure?
  lst : list?
procedure
(ormap proc lst ...+) -> any
  proc : procedure?
  lst : list?
procedure
(for-each proc lst ...+) -> void?
  proc : procedure?
  lst : list?
procedure
(foldl proc init lst ...+) -> any/c
  proc : procedure?
  init : any/c
  lst : list?
procedure
(foldr proc init lst ...+) -> any/c
  proc : procedure?
  init : any/c
  lst : list?
procedure
(filter pred lst) -> list?
  pred : procedure?
  lst : list?
procedure
(remove v lst [proc]) -> list?
  v : any/c
  lst : list?
  proc : procedure? = equal?
procedure
(remq v lst) -> list?
  v : any/c
  lst : list?
procedure
(remv v lst) -> list?
  v : any/c
  lst : list?
procedure
(remove* v-lst lst [proc]) -> list?
  v-lst : list?
  lst : list?
  proc : procedure? = equal?
procedure
(remq* v-lst lst) -> list?
  v-lst : list?
  lst : list?
procedure
(remv* v-lst lst) -> list?
  v-lst : list?
  lst : list?
procedure
(sort  lst                             
       less-than?                      
      [#:key extract-key               
       #:cache-keys? cache-keys?]) -> list?
  lst : list?
  less-than? : (any/c any/c . -> . any/c)
  extract-key : (any/c . -> . any/c) = (lambda (x) x)
  cache-keys? : boolean? = #f
procedure
(member v lst [is-equal?]) -> (or/c list? #f)
  v : any/c
  lst : list?
  is-equal? : (any/c any/c -> any/c) = equal?
procedure
(memv v lst) -> (or/c list? #f)
  v : any/c
  lst : list?
procedure
(memq v lst) -> (or/c list? #f)
  v : any/c
  lst : list?
procedure
(memf proc lst) -> (or/c list? #f)
  proc : procedure?
  lst : list?
procedure
(findf proc lst) -> any/c
  proc : procedure?
  lst : list?
procedure
(assoc v lst [is-equal?]) -> (or/c pair? #f)
  v : any/c
  lst : (listof pair?)
  is-equal? : (any/c any/c -> any/c) = equal?
procedure
(assv v lst) -> (or/c pair? #f)
  v : any/c
  lst : (listof pair?)
procedure
(assq v lst) -> (or/c pair? #f)
  v : any/c
  lst : (listof pair?)
procedure
(assf proc lst) -> (or/c list? #f)
  proc : procedure?
  lst : list?
procedure
(caar v) -> any/c
  v : (cons/c pair? any/c)
procedure
(cadr v) -> any/c
  v : (cons/c any/c pair?)
procedure
(cdar v) -> any/c
  v : (cons/c pair? any/c)
procedure
(cddr v) -> any/c
  v : (cons/c any/c pair?)
procedure
(caaar v) -> any/c
  v : (cons/c (cons/c pair? any/c) any/c)
procedure
(caadr v) -> any/c
  v : (cons/c any/c (cons/c pair? any/c))
procedure
(cadar v) -> any/c
  v : (cons/c (cons/c any/c pair?) any/c)
procedure
(caddr v) -> any/c
  v : (cons/c any/c (cons/c any/c pair?))
procedure
(cdaar v) -> any/c
  v : (cons/c (cons/c pair? any/c) any/c)
procedure
(cdadr v) -> any/c
  v : (cons/c any/c (cons/c pair? any/c))
procedure
(cddar v) -> any/c
  v : (cons/c (cons/c any/c pair?) any/c)
procedure
(cdddr v) -> any/c
  v : (cons/c any/c (cons/c any/c pair?))
procedure
(caaaar v) -> any/c
  v : (cons/c (cons/c (cons/c pair? any/c) any/c) any/c)
procedure
(caaadr v) -> any/c
  v : (cons/c any/c (cons/c (cons/c pair? any/c) any/c))
procedure
(caadar v) -> any/c
  v : (cons/c (cons/c any/c (cons/c pair? any/c)) any/c)
procedure
(caaddr v) -> any/c
  v : (cons/c any/c (cons/c any/c (cons/c pair? any/c)))
procedure
(cadaar v) -> any/c
  v : (cons/c (cons/c (cons/c any/c pair?) any/c) any/c)
procedure
(cadadr v) -> any/c
  v : (cons/c any/c (cons/c (cons/c any/c pair?) any/c))
procedure
(caddar v) -> any/c
  v : (cons/c (cons/c any/c (cons/c any/c pair?)) any/c)
procedure
(cadddr v) -> any/c
  v : (cons/c any/c (cons/c any/c (cons/c any/c pair?)))
procedure
(cdaaar v) -> any/c
  v : (cons/c (cons/c (cons/c pair? any/c) any/c) any/c)
procedure
(cdaadr v) -> any/c
  v : (cons/c any/c (cons/c (cons/c pair? any/c) any/c))
procedure
(cdadar v) -> any/c
  v : (cons/c (cons/c any/c (cons/c pair? any/c)) any/c)
procedure
(cdaddr v) -> any/c
  v : (cons/c any/c (cons/c any/c (cons/c pair? any/c)))
procedure
(cddaar v) -> any/c
  v : (cons/c (cons/c (cons/c any/c pair?) any/c) any/c)
procedure
(cddadr v) -> any/c
  v : (cons/c any/c (cons/c (cons/c any/c pair?) any/c))
procedure
(cdddar v) -> any/c
  v : (cons/c (cons/c any/c (cons/c any/c pair?)) any/c)
procedure
(cddddr v) -> any/c
  v : (cons/c any/c (cons/c any/c (cons/c any/c pair?)))
value
empty : null?
procedure
(cons? v) -> boolean?
  v : any/c
procedure
(empty? v) -> boolean?
  v : any/c
procedure
(first lst) -> any/c
  lst : list?
procedure
(rest lst) -> list?
  lst : list?
procedure
(second lst) -> any
  lst : list?
procedure
(third lst) -> any
  lst : list?
procedure
(fourth lst) -> any
  lst : list?
procedure
(fifth lst) -> any
  lst : list?
procedure
(sixth lst) -> any
  lst : list?
procedure
(seventh lst) -> any
  lst : list?
procedure
(eighth lst) -> any
  lst : list?
procedure
(ninth lst) -> any
  lst : list?
procedure
(tenth lst) -> any
  lst : list?
procedure
(last lst) -> any
  lst : list?
procedure
(last-pair p) -> pair?
  p : pair?
procedure
(make-list k v) -> list?
  k : exact-nonnegative-integer?
  v : any/c
procedure
(take lst pos) -> list?
  lst : any/c
  pos : exact-nonnegative-integer?
procedure
(drop lst pos) -> any/c
  lst : any/c
  pos : exact-nonnegative-integer?
procedure
(split-at lst pos) -> list? any/c
  lst : any/c
  pos : exact-nonnegative-integer?
procedure
(takef lst pred) -> list?
  lst : any/c
  pred : procedure?
procedure
(dropf lst pred) -> any/c
  lst : any/c
  pred : procedure?
procedure
(splitf-at lst pred) -> list? any/c
  lst : any/c
  pred : procedure?
procedure
(take-right lst pos) -> any/c
  lst : any/c
  pos : exact-nonnegative-integer?
procedure
(drop-right lst pos) -> list?
  lst : any/c
  pos : exact-nonnegative-integer?
procedure
(split-at-right lst pos) -> list? any/c
  lst : any/c
  pos : exact-nonnegative-integer?
procedure
(takef-right lst pred) -> list?
  lst : any/c
  pred : procedure?
procedure
(dropf-right lst pred) -> any/c
  lst : any/c
  pred : procedure?
procedure
(splitf-at-right lst pred) -> list? any/c
  lst : any/c
  pred : procedure?
procedure
(add-between  lst                             
              v                               
             [#:before-first before-first     
              #:before-last before-last       
              #:after-last after-last         
              #:splice? splice?])         -> list?
  lst : list?
  v : any/c
  before-first : list? = '()
  before-last : any/c = v
  after-last : list? = '()
  splice? : any/c = #f
procedure
(append* lst ... lsts) -> list?
  lst : list?
  lsts : (listof list?)
(append* lst ... lsts) -> any/c
  lst : list?
  lsts : list?
procedure
(flatten v) -> list?
  v : any/c
procedure
(remove-duplicates  lst                     
                   [same?                   
                    #:key extract-key]) -> list?
  lst : list?
  same? : (any/c any/c . -> . any/c) = equal?
  extract-key : (any/c . -> . any/c) = (lambda (x) x)
procedure
(filter-map proc lst ...+) -> list?
  proc : procedure?
  lst : list?
procedure
(count proc lst ...+) -> exact-nonnegative-integer?
  proc : procedure?
  lst : list?
procedure
(partition pred lst) -> list? list?
  pred : procedure?
  lst : list?
procedure
(range end) -> list?
  end : real?
(range start end [step]) -> list?
  start : real?
  end : real?
  step : real? = 1
procedure
(append-map proc lst ...+) -> list?
  proc : procedure?
  lst : list?
procedure
(filter-not pred lst) -> list?
  pred : (any/c . -> . any/c)
  lst : list?
procedure
(shuffle lst) -> list?
  lst : list?
procedure
(permutations lst) -> list?
  lst : list?
procedure
(in-permutations lst) -> sequence?
  lst : list?
procedure
(argmin proc lst) -> any/c
  proc : (-> any/c real?)
  lst : (and/c pair? list?)
procedure
(argmax proc lst) -> any/c
  proc : (-> any/c real?)
  lst : (and/c pair? list?)
procedure
(make-reader-graph v) -> any/c
  v : any/c
procedure
(placeholder? v) -> boolean?
  v : any/c
procedure
(make-placeholder v) -> placeholder?
  v : any/c
procedure
(placeholder-set! ph datum) -> void?
  ph : placeholder?
  datum : any/c
procedure
(placeholder-get ph) -> any/c
  ph : placeholder?
procedure
(hash-placeholder? v) -> boolean?
  v : any/c
procedure
(make-hash-placeholder assocs) -> hash-placeholder?
  assocs : (listof pair?)
procedure
(make-hasheq-placeholder assocs) -> hash-placeholder?
  assocs : (listof pair?)
procedure
(make-hasheqv-placeholder assocs) -> hash-placeholder?
  assocs : (listof pair?)
procedure
(mpair? v) -> boolean?
  v : any/c
procedure
(mcons a d) -> mpair?
  a : any/c
  d : any/c
procedure
(mcar p) -> any/c
  p : mpair?
procedure
(mcdr p) -> any/c
  p : mpair?
procedure
(set-mcar! p v) -> void?
  p : mpair?
  v : any/v
procedure
(set-mcdr! p v) -> void?
  p : mpair?
  v : any/v
procedure
(vector? v) -> boolean?
  v : any/c
procedure
(make-vector size [v]) -> vector?
  size : exact-nonnegative-integer?
  v : any/c = 0
procedure
(vector v ...) -> vector?
  v : any/c
procedure
(vector-immutable v ...) -> (and/c vector?
                                   immutable?)
  v : any/c
procedure
(vector-length vec) -> exact-nonnegative-integer?
  vec : vector?
procedure
(vector-ref vec pos) -> any/c
  vec : vector?
  pos : exact-nonnegative-integer?
procedure
(vector-set! vec pos v) -> void?
  vec : (and/c vector? (not/c immutable?))
  pos : exact-nonnegative-integer?
  v : any/c
procedure
(vector->list vec) -> list?
  vec : vector?
procedure
(list->vector lst) -> vector?
  lst : list?
procedure
(vector->immutable-vector vec) -> (and/c vector? immutable?)
  vec : vector?
procedure
(vector-fill! vec v) -> void?
  vec : (and/c vector? (not/c immutable?))
  v : any/c
procedure
(vector-copy!  dest           
               dest-start     
               src            
              [src-start      
               src-end])  -> void?
  dest : (and/c vector? (not/c immutable?))
  dest-start : exact-nonnegative-integer?
  src : vector?
  src-start : exact-nonnegative-integer? = 0
  src-end : exact-nonnegative-integer? = (vector-length src)
procedure
(vector->values vec [start-pos end-pos]) -> any
  vec : vector?
  start-pos : exact-nonnegative-integer? = 0
  end-pos : exact-nonnegative-integer? = (vector-length vec)
procedure
(build-vector n proc) -> vector?
  n : exact-nonnegative-integer?
  proc : (exact-nonnegative-integer? . -> . any/c)
procedure
(vector-set*! vec pos v ... ...) -> void?
  vec : (and/c vector? (not/c immutable?))
  pos : exact-nonnegative-integer?
  v : any/c
procedure
(vector-map proc vec ...+) -> vector?
  proc : procedure?
  vec : vector?
procedure
(vector-map! proc vec ...+) -> vector?
  proc : procedure?
  vec : (and/c vector? (not/c immutable?))
procedure
(vector-append vec ...) -> vector?
  vec : vector?
procedure
(vector-take vec pos) -> vector?
  vec : vector?
  pos : exact-nonnegative-integer?
procedure
(vector-take-right vec pos) -> vector?
  vec : vector?
  pos : exact-nonnegative-integer?
procedure
(vector-drop vec pos) -> vector?
  vec : vector?
  pos : exact-nonnegative-integer?
procedure
(vector-drop-right vec pos) -> vector?
  vec : vector?
  pos : exact-nonnegative-integer?
procedure
(vector-split-at vec pos) -> vector? vector?
  vec : vector?
  pos : exact-nonnegative-integer?
procedure
(vector-split-at-right vec pos) -> vector? vector?
  vec : vector?
  pos : exact-nonnegative-integer?
procedure
(vector-copy vec [start end]) -> vector?
  vec : vector?
  start : exact-nonnegative-integer? = 0
  end : exact-nonnegative-integer? = (vector-length v)
procedure
(vector-filter pred vec) -> vector?
  pred : procedure?
  vec : vector?
procedure
(vector-filter-not pred vec) -> vector?
  pred : procedure?
  vec : vector?
procedure
(vector-count proc vec ...+) -> exact-nonnegative-integer?
  proc : procedure?
  vec : vector?
procedure
(vector-argmin proc vec) -> any/c
  proc : (-> any/c real?)
  vec : vector?
procedure
(vector-argmax proc vec) -> any/c
  proc : (-> any/c real?)
  vec : vector?
procedure
(vector-member v lst) -> (or/c natural-number/c #f)
  v : any/c
  lst : vector?
procedure
(vector-memv v vec) -> (or/c natural-number/c #f)
  v : any/c
  vec : vector?
procedure
(vector-memq v vec) -> (or/c natural-number/c #f)
  v : any/c
  vec : vector?
procedure
(box? v) -> boolean?
  v : any/c
procedure
(box v) -> box?
  v : any/c
procedure
(box-immutable v) -> (and/c box? immutable?)
  v : any/c
procedure
(unbox box) -> any/c
  box : box?
procedure
(set-box! box v) -> void?
  box : (and/c box? (not/c immutable?))
  v : any/c
procedure
(box-cas! box old new) -> boolean?
  box : (and/c box? (not/c immutable?) (not/c impersonator?))
  old : any/c
  new : any/c
procedure
(hash? v) -> boolean?
  v : any/c
procedure
(hash-equal? hash) -> boolean?
  hash : hash?
procedure
(hash-eqv? hash) -> boolean?
  hash : hash?
procedure
(hash-eq? hash) -> boolean?
  hash : hash?
procedure
(hash-weak? hash) -> boolean?
  hash : hash?
procedure
(hash key val ... ...) -> (and/c hash? hash-equal? immutable?)
  key : any/c
  val : any/c
procedure
(hasheq key val ... ...) -> (and/c hash? hash-eq? immutable?)
  key : any/c
  val : any/c
procedure
(hasheqv key val ... ...) -> (and/c hash? hash-eqv? immutable?)
  key : any/c
  val : any/c
procedure
(make-hash [assocs]) -> (and/c hash? hash-equal?)
  assocs : (listof pair?) = null
procedure
(make-hasheqv [assocs]) -> (and/c hash? hash-eqv?)
  assocs : (listof pair?) = null
procedure
(make-hasheq [assocs]) -> (and/c hash? hash-eq?)
  assocs : (listof pair?) = null
procedure
(make-weak-hash [assocs]) -> (and/c hash? hash-equal? hash-weak?)
  assocs : (listof pair?) = null
procedure
(make-weak-hasheqv [assocs]) -> (and/c hash? hash-eqv? hash-weak?)
  assocs : (listof pair?) = null
procedure
(make-weak-hasheq [assocs]) -> (and/c hash? hash-eq? hash-weak?)
  assocs : (listof pair?) = null
procedure
(make-immutable-hash [assocs])
 -> (and/c hash? hash-equal? immutable?)
  assocs : (listof pair?) = null
procedure
(make-immutable-hasheqv [assocs])
 -> (and/c hash? hash-eqv? immutable?)
  assocs : (listof pair?) = null
procedure
(make-immutable-hasheq [assocs])
 -> (and/c hash? hash-eq? immutable?)
  assocs : (listof pair?) = null
procedure
(hash-set! hash key v) -> void?
  hash : (and/c hash? (not/c immutable?))
  key : any/c
  v : any/c
procedure
(hash-set*! hash key v ... ...) -> void?
  hash : (and/c hash? (not/c immutable?))
  key : any/c
  v : any/c
procedure
(hash-set hash key v) -> (and/c hash? immutable?)
  hash : (and/c hash? immutable?)
  key : any/c
  v : any/c
procedure
(hash-set* hash key v ... ...) -> (and/c hash? immutable?)
  hash : (and/c hash? immutable?)
  key : any/c
  v : any/c
procedure
(hash-ref hash key [failure-result]) -> any
  hash : hash?
  key : any/c
  failure-result : any/c
                 = (lambda ()
                     (raise (make-exn:fail:contract ....)))
procedure
(hash-ref! hash key to-set) -> any
  hash : hash?
  key : any/c
  to-set : any/c
procedure
(hash-has-key? hash key) -> boolean?
  hash : hash?
  key : any/c
procedure
(hash-update!  hash                 
               key                  
               updater              
              [failure-result]) -> void?
  hash : (and/c hash? (not/c immutable?))
  key : any/c
  updater : (any/c . -> . any/c)
  failure-result : any/c
                 = (lambda ()
                     (raise (make-exn:fail:contract ....)))
procedure
(hash-update hash key updater [failure-result])
 -> (and/c hash? immutable?)
  hash : (and/c hash? immutable?)
  key : any/c
  updater : (any/c . -> . any/c)
  failure-result : any/c
                 = (lambda ()
                     (raise (make-exn:fail:contract ....)))
procedure
(hash-remove! hash key) -> void?
  hash : (and/c hash? (not/c immutable?))
  key : any/c
procedure
(hash-remove hash key) -> (and/c hash? immutable?)
  hash : (and/c hash? immutable?)
  key : any/c
procedure
(hash-clear! hash) -> void?
  hash : (and/c hash? (not/c immutable?))
procedure
(hash-clear hash) -> (and/c hash? immutable?)
  hash : (and/c hash? immutable?)
procedure
(hash-copy-clear hash) -> hash?
  hash : hash?
procedure
(hash-map hash proc) -> (listof any/c)
  hash : hash?
  proc : (any/c any/c . -> . any/c)
procedure
(hash-keys hash) -> (listof any/c)
  hash : hash?
procedure
(hash-values hash) -> (listof any/c)
  hash : hash?
procedure
(hash->list hash) -> (listof (cons/c any/c any/c))
  hash : hash?
procedure
(hash-for-each hash proc) -> void?
  hash : hash?
  proc : (any/c any/c . -> . any)
procedure
(hash-count hash) -> exact-nonnegative-integer?
  hash : hash?
procedure
(hash-empty? hash) -> boolean?
  hash : hash?
procedure
(hash-iterate-first hash)
 -> (or/c #f exact-nonnegative-integer?)
  hash : hash?
procedure
(hash-iterate-next hash pos)
 -> (or/c #f exact-nonnegative-integer?)
  hash : hash?
  pos : exact-nonnegative-integer?
procedure
(hash-iterate-key hash pos) -> any
  hash : hash?
  pos : exact-nonnegative-integer?
procedure
(hash-iterate-value hash pos) -> any
  hash : hash?
  pos : exact-nonnegative-integer?
procedure
(hash-copy hash) -> (and/c hash? (not/c immutable?))
  hash : hash?
procedure
(eq-hash-code v) -> fixnum?
  v : any/c
procedure
(eqv-hash-code v) -> fixnum?
  v : any/c
procedure
(equal-hash-code v) -> fixnum?
  v : any/c
procedure
(equal-secondary-hash-code v) -> fixnum?
  v : any/c
procedure
(sequence? v) -> boolean?
  v : any/c
procedure
(in-range end) -> stream?
  end : number?
(in-range start end [step]) -> stream?
  start : number?
  end : number?
  step : number? = 1
procedure
(in-naturals [start]) -> stream?
  start : exact-nonnegative-integer? = 0
procedure
(in-list lst) -> stream?
  lst : list?
procedure
(in-mlist mlst) -> sequence?
  mlst : mlist?
procedure
(in-vector vec [start stop step]) -> sequence?
  vec : vector?
  start : exact-nonnegative-integer? = 0
  stop : (or/c exact-integer? #f) = #f
  step : (and/c exact-integer? (not/c zero?)) = 1
procedure
(in-string str [start stop step]) -> sequence?
  str : string?
  start : exact-nonnegative-integer? = 0
  stop : (or/c exact-integer? #f) = #f
  step : (and/c exact-integer? (not/c zero?)) = 1
procedure
(in-bytes bstr [start stop step]) -> sequence?
  bstr : bytes?
  start : exact-nonnegative-integer? = 0
  stop : (or/c exact-integer? #f) = #f
  step : (and/c exact-integer? (not/c zero?)) = 1
procedure
(in-port [r in]) -> sequence?
  r : (input-port? . -> . any/c) = read
  in : input-port? = (current-input-port)
procedure
(in-input-port-bytes in) -> sequence?
  in : input-port?
procedure
(in-input-port-chars in) -> sequence?
  in : input-port?
procedure
(in-lines [in mode]) -> sequence?
  in : input-port? = (current-input-port)
  mode : (or/c 'linefeed 'return 'return-linefeed 'any 'any-one)
       = 'any
procedure
(in-bytes-lines [in mode]) -> sequence?
  in : input-port? = (current-input-port)
  mode : (or/c 'linefeed 'return 'return-linefeed 'any 'any-one)
       = 'any
procedure
(in-hash hash) -> sequence?
  hash : hash?
procedure
(in-hash-keys hash) -> sequence?
  hash : hash?
procedure
(in-hash-values hash) -> sequence?
  hash : hash?
procedure
(in-hash-pairs hash) -> sequence?
  hash : hash?
procedure
(in-directory [dir use-dir?]) -> sequence?
  dir : (or/c #f path-string?) = #f
  use-dir? : ((and/c path? complete-path?) . -> . any/c)
           = (lambda (dir-path) #t)
procedure
(in-producer producer) -> sequence?
  producer : procedure?
(in-producer producer stop arg ...) -> sequence?
  producer : procedure?
  stop : any/c
  arg : any/c
procedure
(in-value v) -> sequence?
  v : any/c
procedure
(in-indexed seq) -> sequence?
  seq : sequence?
procedure
(in-sequences seq ...) -> sequence?
  seq : sequence?
procedure
(in-cycle seq ...) -> sequence?
  seq : sequence?
procedure
(in-parallel seq ...) -> sequence?
  seq : sequence?
procedure
(in-values-sequence seq) -> sequence?
  seq : sequence?
procedure
(in-values*-sequence seq) -> sequence?
  seq : sequence?
procedure
(stop-before seq pred) -> sequence?
  seq : sequence?
  pred : (any/c . -> . any)
procedure
(stop-after seq pred) -> sequence?
  seq : sequence?
  pred : (any/c . -> . any)
procedure
(make-do-sequence thunk) -> sequence?
  thunk : (-> (values (any/c . -> . any)
                      (any/c . -> . any/c)
                      any/c
                      (or/c (any/c . -> . any/c) #f)
                      (or/c (() () #:rest list? . ->* . any/c) #f)
                      (or/c ((any/c) () #:rest list? . ->* . any/c) #f)))
value
prop:sequence : struct-type-property?
procedure
(sequence->stream seq) -> stream?
  seq : sequence?
procedure
(sequence-generate seq) -> (-> boolean?) (-> any)
  seq : sequence?
procedure
(sequence-generate* seq)
 -> (or/c list? #f)
    (-> (values (or/c list? #f) procedure?))
  seq : sequence?
value
empty-sequence : sequence?
procedure
(sequence->list s) -> list?
  s : sequence?
procedure
(sequence-length s) -> exact-nonnegative-integer?
  s : sequence?
procedure
(sequence-ref s i) -> any
  s : sequence?
  i : exact-nonnegative-integer?
procedure
(sequence-tail s i) -> sequence?
  s : sequence?
  i : exact-nonnegative-integer?
procedure
(sequence-append s ...) -> sequence?
  s : sequence?
procedure
(sequence-map f s) -> sequence?
  f : procedure?
  s : sequence?
procedure
(sequence-andmap f s) -> boolean?
  f : (-> any/c ... boolean?)
  s : sequence?
procedure
(sequence-ormap f s) -> boolean?
  f : (-> any/c ... boolean?)
  s : sequence?
procedure
(sequence-for-each f s) -> void?
  f : (-> any/c ... any)
  s : sequence?
procedure
(sequence-fold f i s) -> any/c
  f : (-> any/c any/c ... any/c)
  i : any/c
  s : sequence?
procedure
(sequence-count f s) -> exact-nonnegative-integer?
  f : procedure?
  s : sequence?
procedure
(sequence-filter f s) -> sequence?
  f : (-> any/c ... boolean?)
  s : sequence?
procedure
(sequence-add-between s e) -> sequence?
  s : sequence?
  e : any/c
procedure
(sequence/c [#:min-count min-count]     
             elem/c ...)            -> contract?
  min-count : (or/c #f exact-nonnegative-integer?) = #f
  elem/c : contract?
procedure
(stream? v) -> boolean?
  v : any/c
procedure
(stream-empty? s) -> boolean?
  s : stream?
procedure
(stream-first s) -> any
  s : (and/c stream? (not/c stream-empty?))
procedure
(stream-rest s) -> stream?
  s : (and/c stream? (not/c stream-empty?))
syntax
(stream-cons first-expr rest-expr)
syntax
(stream expr ...)
procedure
(in-stream s) -> sequence?
  s : stream?
value
empty-stream : stream?
procedure
(stream->list s) -> list?
  s : stream?
procedure
(stream-length s) -> exact-nonnegative-integer?
  s : stream?
procedure
(stream-ref s i) -> any
  s : stream?
  i : exact-nonnegative-integer?
procedure
(stream-tail s i) -> stream?
  s : stream?
  i : exact-nonnegative-integer?
procedure
(stream-append s ...) -> stream?
  s : stream?
procedure
(stream-map f s) -> stream?
  f : procedure?
  s : stream?
procedure
(stream-andmap f s) -> boolean?
  f : (-> any/c ... boolean?)
  s : stream?
procedure
(stream-ormap f s) -> boolean?
  f : (-> any/c ... boolean?)
  s : stream?
procedure
(stream-for-each f s) -> void?
  f : (-> any/c ... any)
  s : stream?
procedure
(stream-fold f i s) -> any/c
  f : (-> any/c any/c ... any/c)
  i : any/c
  s : stream?
procedure
(stream-count f s) -> exact-nonnegative-integer?
  f : procedure?
  s : stream?
procedure
(stream-filter f s) -> stream?
  f : (-> any/c ... boolean?)
  s : stream?
procedure
(stream-add-between s e) -> stream?
  s : stream?
  e : any/c
value
gen:stream : any/c
value
prop:stream : struct-type-property?
procedure
(stream/c c) -> contract?
  c : contract?
procedure
(generator? v) -> boolean?
  v : any/c
syntax
(generator formals body ...+)
procedure
(yield v ...) -> any
  v : any/c
syntax
(infinite-generator body ...+)
syntax
(in-generator maybe-arity body ...+)
 
maybe-arity = 
            | #:arity arity-k
procedure
(generator-state g) -> symbol?
  g : generator?
procedure
(sequence->generator s) -> (-> any)
  s : sequence?
procedure
(sequence->repeated-generator s) -> (-> any)
  s : sequence?
procedure
(dict? v) -> boolean?
  v : any/c
procedure
(dict-implements? d sym ...) -> boolean?
  d : dict?
  sym : symbol?
procedure
(dict-implements/c sym ...) -> flat-contract?
  sym : symbol?
procedure
(dict-mutable? d) -> boolean?
  d : dict?
procedure
(dict-can-remove-keys? d) -> boolean?
  d : dict?
procedure
(dict-can-functional-set? d) -> boolean?
  d : dict?
syntax
gen:dict
value
prop:dict : struct-type-property?
procedure
(dict-ref dict key [failure-result]) -> any
  dict : dict?
  key : any/c
  failure-result : any/c
                 = (lambda () (raise (make-exn:fail ....)))
procedure
(dict-set! dict key v) -> void?
  dict : (and/c dict? (not/c immutable?))
  key : any/c
  v : any/c
procedure
(dict-set dict key v) -> (and/c dict? immutable?)
  dict : (and/c dict? immutable?)
  key : any/c
  v : any/c
procedure
(dict-remove! dict key) -> void?
  dict : (and/c dict? (not/c immutable?))
  key : any/c
procedure
(dict-remove dict key) -> (and/c dict? immutable?)
  dict : (and/c dict? immutable?)
  key : any/c
procedure
(dict-iterate-first dict) -> any/c
  dict : dict?
procedure
(dict-iterate-next dict pos) -> any/c
  dict : dict?
  pos : any/c
procedure
(dict-iterate-key dict pos) -> any
  dict : dict?
  pos : any/c
procedure
(dict-iterate-value dict pos) -> any
  dict : dict?
  pos : any/c
procedure
(dict-has-key? dict key) -> boolean?
  dict : dict?
  key : any/c
procedure
(dict-set*! dict key v ... ...) -> void?
  dict : (and/c dict? (not/c immutable?))
  key : any/c
  v : any/c
procedure
(dict-set* dict key v ... ...) -> (and/c dict? immutable?)
  dict : (and/c dict? immutable?)
  key : any/c
  v : any/c
procedure
(dict-ref! dict key to-set) -> any
  dict : dict?
  key : any/c
  to-set : any/c
procedure
(dict-update!  dict                 
               key                  
               updater              
              [failure-result]) -> void?
  dict : (and/c dict? (not/c immutable?))
  key : any/c
  updater : (any/c . -> . any/c)
  failure-result : any/c
                 = (lambda () (raise (make-exn:fail ....)))
procedure
(dict-update dict key updater [failure-result])
 -> (and/c dict? immutable?)
  dict : dict?
  key : any/c
  updater : (any/c . -> . any/c)
  failure-result : any/c
                 = (lambda () (raise (make-exn:fail ....)))
procedure
(dict-map dict proc) -> (listof any/c)
  dict : dict?
  proc : (any/c any/c . -> . any/c)
procedure
(dict-for-each dict proc) -> void?
  dict : dict?
  proc : (any/c any/c . -> . any)
procedure
(dict-empty? dict) -> boolean?
  dict : dict?
procedure
(dict-count dict) -> exact-nonnegative-integer?
  dict : dict?
procedure
(dict-copy dict) -> dict?
  dict : dict?
procedure
(dict-clear dict) -> dict?
  dict : dict?
procedure
(dict-clear! dict) -> dict?
  dict : dict?
procedure
(dict-keys dict) -> list?
  dict : dict?
procedure
(dict-values dict) -> list?
  dict : dict?
procedure
(dict->list dict) -> list?
  dict : dict?
procedure
(in-dict dict) -> sequence?
  dict : dict?
procedure
(in-dict-keys dict) -> sequence?
  dict : dict?
procedure
(in-dict-values dict) -> sequence?
  dict : dict?
procedure
(in-dict-pairs dict) -> sequence?
  dict : dict?
value
prop:dict/contract : struct-type-property?
procedure
(dict-key-contract d) -> contract?
  d : dict?
procedure
(dict-value-contract d) -> contract?
  d : dict?
procedure
(dict-iter-contract d) -> contract?
  d : dict?
syntax
(define-custom-hash-types name
                          optional-predicate
                          comparison-expr
                          optional-hash-functions)
 
     optional-predicate = 
                        | #:key? predicate-expr
                           
optional-hash-functions = 
                        | hash1-expr
                        | hash1-expr hash2-expr
procedure
(make-custom-hash-types  eql?            
                        [hash1           
                         hash2           
                         #:key? key?     
                         #:name name     
                         #:for who]) -> (any/c . -> . boolean?)
                                        (any/c . -> . boolean?)
                                        (any/c . -> . boolean?)
                                        (any/c . -> . boolean?)
                                        (->* [] [dict?] dict?)
                                        (->* [] [dict?] dict?)
                                        (->* [] [dict?] dict?)
  eql? : (or/c (any/c any/c . -> . any/c)
               (any/c any/c (any/c any/c . -> . any/c) . -> . any/c))
  hash1 : (or/c (any/c . -> . exact-integer?)
                (any/c (any/c . -> . exact-integer?) . -> . exact-integer?))
        = (const 1)
  hash2 : (or/c (any/c . -> . exact-integer?)
                (any/c (any/c . -> . exact-integer?) . -> . exact-integer?))
        = (const 1)
  key? : (any/c . -> . boolean?) = (const #true)
  name : symbol? = 'custom-hash
  who : symbol? = 'make-custom-hash-types
procedure
(make-custom-hash  eql?              
                  [hash1             
                   hash2             
                   #:key? key?]) -> dict?
  eql? : (or/c (any/c any/c . -> . any/c)
               (any/c any/c (any/c any/c . -> . any/c) . -> . any/c))
  hash1 : (or/c (any/c . -> . exact-integer?)
                (any/c (any/c . -> . exact-integer?) . -> . exact-integer?))
        = (const 1)
  hash2 : (or/c (any/c . -> . exact-integer?)
                (any/c (any/c . -> . exact-integer?) . -> . exact-integer?))
        = (const 1)
  key? : (any/c . -> . boolean?) = (const #true)
procedure
(make-weak-custom-hash  eql?              
                       [hash1             
                        hash2             
                        #:key? key?]) -> dict?
  eql? : (or/c (any/c any/c . -> . any/c)
               (any/c any/c (any/c any/c . -> . any/c) . -> . any/c))
  hash1 : (or/c (any/c . -> . exact-integer?)
                (any/c (any/c . -> . exact-integer?) . -> . exact-integer?))
        = (const 1)
  hash2 : (or/c (any/c . -> . exact-integer?)
                (any/c (any/c . -> . exact-integer?) . -> . exact-integer?))
        = (const 1)
  key? : (any/c . -> . boolean?) = (const #true)
procedure
(make-immutable-custom-hash  eql?              
                            [hash1             
                             hash2             
                             #:key? key?]) -> dict?
  eql? : (or/c (any/c any/c . -> . any/c)
               (any/c any/c (any/c any/c . -> . any/c) . -> . any/c))
  hash1 : (or/c (any/c . -> . exact-integer?)
                (any/c (any/c . -> . exact-integer?) . -> . exact-integer?))
        = (const 1)
  hash2 : (or/c (any/c . -> . exact-integer?)
                (any/c (any/c . -> . exact-integer?) . -> . exact-integer?))
        = (const 1)
  key? : (any/c . -> . boolean?) = (const #true)
procedure
(set-equal? x) -> boolean?
  x : any/c
procedure
(set-eqv? x) -> boolean?
  x : any/c
procedure
(set-eq? x) -> boolean?
  x : any/c
procedure
(set? x) -> boolean?
  x : any/c
procedure
(set-mutable? x) -> boolean?
  x : any/c
procedure
(set-weak? x) -> boolean?
  x : any/c
procedure
(set v ...) -> (and/c generic-set? set-equal? set?)
  v : any/c
procedure
(seteqv v ...) -> (and/c generic-set? set-eqv? set?)
  v : any/c
procedure
(seteq v ...) -> (and/c generic-set? set-eq? set?)
  v : any/c
procedure
(mutable-set v ...)
 -> (and/c generic-set? set-equal? set-mutable?)
  v : any/c
procedure
(mutable-seteqv v ...)
 -> (and/c generic-set? set-eqv? set-mutable?)
  v : any/c
procedure
(mutable-seteq v ...)
 -> (and/c generic-set? set-eq? set-mutable?)
  v : any/c
procedure
(weak-set v ...) -> (and/c generic-set? set-equal? set-weak?)
  v : any/c
procedure
(weak-seteqv v ...) -> (and/c generic-set? set-eqv? set-weak?)
  v : any/c
procedure
(weak-seteq v ...) -> (and/c generic-set? set-eq? set-weak?)
  v : any/c
procedure
(list->set lst) -> (and/c generic-set? set-equal? set?)
  lst : list?
procedure
(list->seteqv lst) -> (and/c generic-set? set-eqv? set?)
  lst : list?
procedure
(list->seteq lst) -> (and/c generic-set? set-eq? set?)
  lst : list?
procedure
(list->mutable-set lst)
 -> (and/c generic-set? set-equal? set-mutable?)
  lst : list?
procedure
(list->mutable-seteqv lst)
 -> (and/c generic-set? set-eqv? set-mutable?)
  lst : list?
procedure
(list->mutable-seteq lst)
 -> (and/c generic-set? set-eq? set-mutable?)
  lst : list?
procedure
(list->weak-set lst)
 -> (and/c generic-set? set-equal? set-weak?)
  lst : list?
procedure
(list->weak-seteqv lst)
 -> (and/c generic-set? set-eqv? set-weak?)
  lst : list?
procedure
(list->weak-seteq lst) -> (and/c generic-set? set-eq? set-weak?)
  lst : list?
syntax
(for/set (for-clause ...) body ...+)
syntax
(for/seteq (for-clause ...) body ...+)
syntax
(for/seteqv (for-clause ...) body ...+)
syntax
(for*/set (for-clause ...) body ...+)
syntax
(for*/seteq (for-clause ...) body ...+)
syntax
(for*/seteqv (for-clause ...) body ...+)
syntax
(for/mutable-set (for-clause ...) body ...+)
syntax
(for/mutable-seteq (for-clause ...) body ...+)
syntax
(for/mutable-seteqv (for-clause ...) body ...+)
syntax
(for*/mutable-set (for-clause ...) body ...+)
syntax
(for*/mutable-seteq (for-clause ...) body ...+)
syntax
(for*/mutable-seteqv (for-clause ...) body ...+)
syntax
(for/weak-set (for-clause ...) body ...+)
syntax
(for/weak-seteq (for-clause ...) body ...+)
syntax
(for/weak-seteqv (for-clause ...) body ...+)
syntax
(for*/weak-set (for-clause ...) body ...+)
syntax
(for*/weak-seteq (for-clause ...) body ...+)
syntax
(for*/weak-seteqv (for-clause ...) body ...+)
procedure
(generic-set? v) -> boolean?
  v : any/c
procedure
(set-implements? st sym ...) -> boolean?
  st : generic-set?
  sym : symbol?
procedure
(set-implements/c sym ...) -> flat-contract?
  sym : symbol?
procedure
(set/c elem/c [#:cmp cmp #:kind kind]) -> contract?
  elem/c : chaperone-contract?
  cmp : (or/c 'dont-care 'equal 'eqv 'eq) = 'dont-care
  kind : (or/c 'dont-care 'immutable 'mutable 'weak 'mutable-or-weak)
       = 'immutable
syntax
gen:set
procedure
(set-member? st v) -> boolean?
  st : generic-set?
  v : any/c
procedure
(set-add st v) -> generic-set?
  st : generic-set?
  v : any/c
procedure
(set-add! st v) -> void?
  st : generic-set?
  v : any/c
procedure
(set-remove st v) -> generic-set?
  st : generic-set?
  v : any/c
procedure
(set-remove! st v) -> void?
  st : generic-set?
  v : any/c
procedure
(set-empty? st) -> boolean?
  st : generic-set?
procedure
(set-count st) -> exact-nonnegative-integer?
  st : generic-set?
procedure
(set-first st) -> any/c
  st : (and/c generic-set? (not/c set-empty?))
procedure
(set-rest st) -> generic-set?
  st : (and/c generic-set? (not/c set-empty?))
procedure
(set->stream st) -> stream?
  st : generic-set?
procedure
(set-copy st) -> generic-set?
  st : generic-set?
procedure
(set-copy-clear st) -> (and/c generic-set? set-empty?)
  st : generic-set?
procedure
(set-clear st) -> (and/c generic-set? set-empty?)
  st : generic-set?
procedure
(set-clear! st) -> void?
  st : generic-set?
procedure
(set-union st0 st ...) -> generic-set?
  st0 : generic-set?
  st : generic-set?
procedure
(set-union! st0 st ...) -> generic-set?
  st0 : generic-set?
  st : generic-set?
procedure
(set-intersect st0 st ...) -> generic-set?
  st0 : generic-set?
  st : generic-set?
procedure
(set-intersect! st0 st ...) -> generic-set?
  st0 : generic-set?
  st : generic-set?
procedure
(set-subtract st0 st ...) -> generic-set?
  st0 : generic-set?
  st : generic-set?
procedure
(set-subtract! st0 st ...) -> generic-set?
  st0 : generic-set?
  st : generic-set?
procedure
(set-symmetric-difference st0 st ...) -> generic-set?
  st0 : generic-set?
  st : generic-set?
procedure
(set-symmetric-difference! st0 st ...) -> generic-set?
  st0 : generic-set?
  st : generic-set?
procedure
(set=? st st2) -> boolean?
  st : generic-set?
  st2 : generic-set?
procedure
(subset? st st2) -> boolean?
  st : generic-set?
  st2 : generic-set?
procedure
(proper-subset? st st2) -> boolean?
  st : generic-set?
  st2 : generic-set?
procedure
(set->list st) -> list?
  st : generic-set?
procedure
(set-map st proc) -> (listof any/c)
  st : generic-set?
  proc : (any/c . -> . any/c)
procedure
(set-for-each st proc) -> void?
  st : generic-set?
  proc : (any/c . -> . any)
procedure
(in-set st) -> sequence?
  st : generic-set?
syntax
(define-custom-set-types name
                         optional-predicate
                         comparison-expr
                         optional-hash-functions)
 
     optional-predicate = 
                        | #:elem? predicate-expr
                           
optional-hash-functions = 
                        | hash1-expr
                        | hash1-expr hash2-expr
procedure
(make-custom-set-types  eql?          
                       [hash1         
                        hash2         
                        #:elem? elem? 
                        #:name name   
                        #:for who])   
 -> (any/c . -> . boolean?)
    (any/c . -> . boolean?)
    (any/c . -> . boolean?)
    (any/c . -> . boolean?)
    (->* [] [stream?] generic-set?)
    (->* [] [stream?] generic-set?)
    (->* [] [stream?] generic-set?)
  eql? : (or/c (any/c any/c . -> . any/c)
               (any/c any/c (any/c any/c . -> . any/c) . -> . any/c))
  hash1 : (or/c (any/c . -> . exact-integer?)
                (any/c (any/c . -> . exact-integer?) . -> . exact-integer?))
        = (const 1)
  hash2 : (or/c (any/c . -> . exact-integer?)
                (any/c (any/c . -> . exact-integer?) . -> . exact-integer?))
        = (const 1)
  elem? : (any/c . -> . boolean?) = (const #true)
  name : symbol? = 'custom-set
  who : symbol? = 'make-custom-set-types
procedure
(procedure? v) -> boolean?
  v : any/c
procedure
(apply proc v ... lst #:<kw> kw-arg ...) -> any
  proc : procedure?
  v : any/c
  lst : list?
  kw-arg : any/c
procedure
(compose proc ...) -> procedure?
  proc : procedure?
procedure
(compose1 proc ...) -> procedure?
  proc : procedure?
procedure
(procedure-rename proc name) -> procedure?
  proc : procedure?
  name : symbol?
procedure
(procedure->method proc) -> procedure?
  proc : procedure?
procedure
(procedure-closure-contents-eq? proc1      
                                proc2) -> boolean?
  proc1 : procedure?
  proc2 : procedure?
procedure
(keyword-apply proc                   
               kw-lst                 
               kw-val-lst             
               v ...                  
               lst                    
               #:<kw> kw-arg ...) -> any
  proc : procedure?
  kw-lst : (listof keyword?)
  kw-val-lst : list?
  v : any/c
  lst : list?
  kw-arg : any/c
procedure
(procedure-arity proc) -> normalized-arity?
  proc : procedure?
procedure
(procedure-arity? v) -> boolean?
  v : any/c
procedure
(procedure-arity-includes? proc k [kws-ok?]) -> boolean?
  proc : procedure?
  k : exact-nonnegative-integer?
  kws-ok? : any/c = #f
procedure
(procedure-reduce-arity proc arity) -> procedure?
  proc : procedure?
  arity : procedure-arity?
procedure
(procedure-keywords proc) -> (listof keyword?)
                             (or/c (listof keyword?) #f)
  proc : procedure?
procedure
(make-keyword-procedure proc [plain-proc]) -> procedure?
  proc : (((listof keyword?) list?) () #:rest list? . ->* . any)
  plain-proc : procedure?
             = (lambda args (apply proc null null args))
procedure
(procedure-reduce-keyword-arity proc             
                                arity            
                                required-kws     
                                allowed-kws) -> procedure?
  proc : procedure?
  arity : procedure-arity?
  required-kws : (listof keyword?)
  allowed-kws : (or/c (listof keyword?)
                      #f)
struct
(struct arity-at-least (value)
    #:extra-constructor-name make-arity-at-least)
  value : exact-nonnegative-integer?
value
prop:procedure : struct-type-property?
procedure
(procedure-struct-type? type) -> boolean?
  type : struct-type?
procedure
(procedure-extract-target proc) -> (or/c #f procedure?)
  proc : procedure?
value
prop:arity-string : struct-type-property?
value
prop:checked-procedure : struct-type-property?
procedure
(checked-procedure-check-and-extract type     
                                     v        
                                     proc     
                                     v1       
                                     v2)  -> any/c
  type : struct-type?
  v : any/c
  proc : (any/c any/c any/c . -> . any/c)
  v1 : any/c
  v2 : any/c
procedure
(primitive? v) -> boolean?
  v : any/c
procedure
(primitive-closure? v) -> boolean
  v : any/c
procedure
(primitive-result-arity prim) -> procedure-arity?
  prim : primitive?
procedure
(identity v) -> any/c
  v : any/c
procedure
(const v) -> procedure?
  v : any
syntax
(thunk  body ...+)
syntax
(thunk* body ...+)
procedure
(negate proc) -> procedure?
  proc : procedure?
procedure
(curry proc) -> procedure?
  proc : procedure?
(curry proc v ...+) -> any/c
  proc : procedure?
  v : any/c
procedure
(curryr proc) -> procedure?
  proc : procedure?
(curryr proc v ...+) -> any/c
  proc : procedure?
  v : any/c
procedure
(normalized-arity? arity) -> boolean?
  arity : any/c
procedure
(normalize-arity arity)
 -> (and/c normalized-arity? (lambda (x) (arity=? x arity)))
  arity : procedure-arity?
procedure
(arity=? a b) -> boolean?
  a : procedure-arity?
  b : procedure-arity?
procedure
(arity-includes? a b) -> boolean?
  a : procedure-arity?
  b : procedure-arity?
procedure
(void? v) -> boolean?
  v : any/c
procedure
(void v ...) -> void?
  v : any/c
value
undefined : any/c
syntax
(struct id maybe-super (field ...)
        struct-option ...)
 
  maybe-super = 
              | super-id
                 
        field = field-id
              | [field-id field-option ...]
                 
struct-option = #:mutable
              | #:super super-expr
              | #:inspector inspector-expr
              | #:auto-value auto-expr
              | #:guard guard-expr
              | #:property prop-expr val-expr
              | #:transparent
              | #:prefab
              | #:constructor-name constructor-id
              | #:extra-constructor-name constructor-id
              | #:reflection-name symbol-expr
              | #:methods gen:name method-defs
              | #:omit-define-syntaxes
              | #:omit-define-values
                 
 field-option = #:mutable
              | #:auto
                 
  method-defs = (definition ...)
 
  gen:name : identifier?
syntax
(struct-field-index field-id)
syntax
(define-struct id-maybe-super (field ...)
               struct-option ...)
 
id-maybe-super = id
               | (id super-id)
syntax
(define-struct/derived (id . rest-form)
  id-maybe-super (field ...) struct-option ...)
procedure
(make-struct-type  name               
                   super-type         
                   init-field-cnt     
                   auto-field-cnt     
                  [auto-v             
                   props              
                   inspector          
                   proc-spec          
                   immutables         
                   guard              
                   constructor-name]) 
 -> struct-type?
    struct-constructor-procedure?
    struct-predicate-procedure?
    struct-accessor-procedure?
    struct-mutator-procedure?
  name : symbol?
  super-type : (or/c struct-type? #f)
  init-field-cnt : exact-nonnegative-integer?
  auto-field-cnt : exact-nonnegative-integer?
  auto-v : any/c = #f
  props : (listof (cons/c struct-type-property? = null
                          any/c))
  inspector : (or/c inspector? #f 'prefab) = (current-inspector)
  proc-spec : (or/c procedure?                 = #f
                    exact-nonnegative-integer?
                    #f)
  immutables : (listof exact-nonnegative-integer?) = null
  guard : (or/c procedure? #f) = #f
  constructor-name : (or/c symbol? #f) = #f
procedure
(make-struct-field-accessor  accessor-proc     
                             field-pos         
                            [field-name])  -> procedure?
  accessor-proc : struct-accessor-procedure?
  field-pos : exact-nonnegative-integer?
  field-name : (or/c symbol? #f)
             = (symbol->string (format "field~a" field-pos))
procedure
(make-struct-field-mutator  mutator-proc     
                            field-pos        
                           [field-name]) -> procedure?
  mutator-proc : struct-mutator-procedure?
  field-pos : exact-nonnegative-integer?
  field-name : (or/c symbol? #f)
             = (symbol->string (format "field~a" field-pos))
procedure
(make-struct-type-property  name               
                           [guard              
                            supers             
                            can-impersonate?]) 
 -> struct-type-property?
    procedure?
    procedure?
  name : symbol?
  guard : (or/c procedure? #f 'can-impersonate) = #f
  supers : (listof (cons/c struct-type-property?  = null
                           (any/c . -> . any/c)))
  can-impersonate? : any/c = #f
procedure
(struct-type-property? v) -> boolean?
  v : any/c
procedure
(struct-type-property-accessor-procedure? v) -> boolean?
  v : any/c
syntax
(define-generics id
  generics-opt ...
  [method-id . kw-formals*] ...
  generics-opt ...)
 
generics-opt = #:defaults ([default-pred? default-impl ...] ...)
             | #:fast-defaults ([fast-pred? fast-impl ...] ...)
             | #:fallbacks [fallback-impl ...]
             | #:defined-predicate defined-pred-id
             | #:defined-table defined-table-id
             | #:derive-property prop-expr prop-value-expr
                
 kw-formals* = (arg* ...)
             | (arg* ...+ . rest-id)
             | rest-id
                
        arg* = arg-id
             | [arg-id]
             | keyword arg-id
             | keyword [arg-id]
procedure
(raise-support-error name v) -> none/c
  name : symbol?
  v : any/c
struct
(struct exn:fail:support exn:fail ()
    #:transparent)
syntax
(define/generic local-id method-id)
 
  local-id : identifier?
  method-id : identifier?
syntax
(generic-instance/c gen-id [method-id method-ctc] ...)
 
  method-ctc : contract?
syntax
(impersonate-generics gen-id val-expr
  [method-id method-proc-expr] ...
  maybe-properties)
 
maybe-properties = 
                 | #:properties props-expr
 
  method-proc-expr : (any/c . -> . any/c)
  props-expr : (list/c impersonator-property? any/c ... ...)
syntax
(chaperone-generics gen-id val-expr
  [method-id method-proc-expr] ...
  maybe-properties)
syntax
(redirect-generics mode gen-id val-expr
   [method-id method-proc-expr] ...
   maybe-properties)
syntax
(struct-copy id struct-expr fld-id ...)
 
fld-id = [field-id expr]
       | [field-id #:parent parent-id expr]
procedure
(struct->vector v [opaque-v]) -> vector?
  v : any/c
  opaque-v : any/c = '...
procedure
(struct? v) -> any
  v : any/c
procedure
(struct-type? v) -> boolean?
  v : any/c
procedure
(struct-constructor-procedure? v) -> boolean?
  v : any/c
procedure
(struct-predicate-procedure? v) -> boolean?
  v : any/c
procedure
(struct-accessor-procedure? v) -> boolean?
  v : any/c
procedure
(struct-mutator-procedure? v) -> boolean?
  v : any/c
procedure
(prefab-struct-key v) -> (or/c #f symbol? list?)
  v : any/c
procedure
(make-prefab-struct key v ...) -> struct?
  key : prefab-key?
  v : any/c
procedure
(prefab-key->struct-type key field-count) -> struct-type?
  key : prefab-key?
  field-count : (integer-in 0 32768)
procedure
(prefab-key? v) -> boolean?
  v : any/c
procedure
(struct-info? v) -> boolean?
  v : any/c
procedure
(checked-struct-info? v) -> boolean?
  v : any/c
procedure
(make-struct-info thunk) -> struct-info?
  thunk : (-> (and/c struct-info? list?))
procedure
(extract-struct-info v) -> (and/c struct-info? list?)
  v : struct-info?
value
struct:struct-info : struct-type?
value
prop:struct-info : struct-type-property?
value
prop:struct-auto-info : struct-type-property?
procedure
(struct-auto-info? v) -> boolean?
  v : any/c
procedure
(struct-auto-info-lists sai)
 -> (list/c (listof identifier?) (listof identifier?))
  sai : struct-auto-info?
syntax
(interface (super-interface-expr ...) name-clause ...)
 
name-clause = id
            | (id contract-expr)
syntax
(interface* (super-interface-expr ...)
            ([property-expr val-expr] ...)
  name-clause ...)
 
name-clause = id
            | (id contract-expr)
value
object% : class?
syntax
(class* superclass-expr (interface-expr ...)
  class-clause
  ...)
 
     class-clause = (inspect inspector-expr)
                  | (init init-decl ...)
                  | (init-field init-decl ...)
                  | (field field-decl ...)
                  | (inherit-field maybe-renamed ...)
                  | (init-rest id)
                  | (init-rest)
                  | (public maybe-renamed ...)
                  | (pubment maybe-renamed ...)
                  | (public-final maybe-renamed ...)
                  | (override maybe-renamed ...)
                  | (overment maybe-renamed ...)
                  | (override-final maybe-renamed ...)
                  | (augment maybe-renamed ...)
                  | (augride maybe-renamed ...)
                  | (augment-final maybe-renamed ...)
                  | (private id ...)
                  | (abstract id ...)
                  | (inherit maybe-renamed ...)
                  | (inherit/super maybe-renamed ...)
                  | (inherit/inner maybe-renamed ...)
                  | (rename-super renamed ...)
                  | (rename-inner renamed ...)
                  | method-definition
                  | definition
                  | expr
                  | (begin class-clause ...)
                     
        init-decl = id
                  | (renamed)
                  | (maybe-renamed default-value-expr)
                     
       field-decl = (maybe-renamed default-value-expr)
                     
    maybe-renamed = id
                  | renamed
                     
          renamed = (internal-id external-id)
                     
method-definition = (define-values (id) method-procedure)
                     
 method-procedure = (lambda kw-formals expr ...+)
                  | (case-lambda (formals expr ...+) ...)
                  | (#%plain-lambda formals expr ...+)
                  | (let-values ([(id) method-procedure] ...)
                      method-procedure)
                  | (letrec-values ([(id) method-procedure] ...)
                      method-procedure)
                  | (let-values ([(id) method-procedure] ...+)
                      id)
                  | (letrec-values ([(id) method-procedure] ...+)
                      id)
                  | (chaperone-procedure method-procedure wrapper-proc
                                         other-arg-expr ...)
syntax
(class superclass-expr class-clause ...)
syntax
this
syntax
this%
syntax
(inspect inspector-expr)
syntax
(init init-decl ...)
syntax
(init-field init-decl ...)
syntax
(field field-decl ...)
syntax
(inherit-field maybe-renamed ...)
syntax
(init-rest id)
(init-rest)
syntax
(public maybe-renamed ...)
syntax
(pubment maybe-renamed ...)
syntax
(public-final maybe-renamed ...)
syntax
(override maybe-renamed ...)
syntax
(overment maybe-renamed ...)
syntax
(override-final maybe-renamed ...)
syntax
(augment maybe-renamed ...)
syntax
(augride maybe-renamed ...)
syntax
(augment-final maybe-renamed ...)
syntax
(private id ...)
syntax
(abstract id ...)
syntax
(inherit maybe-renamed ...)
syntax
(inherit/super maybe-renamed ...)
syntax
(inherit/inner maybe-renamed ...)
syntax
(rename-super renamed ...)
syntax
(rename-inner renamed ...)
syntax
(public* (id expr) ...)
syntax
(pubment* (id expr) ...)
syntax
(public-final* (id expr) ...)
syntax
(override* (id expr) ...)
syntax
(overment* (id expr) ...)
syntax
(override-final* (id expr) ...)
syntax
(augment* (id expr) ...)
syntax
(augride* (id expr) ...)
syntax
(augment-final* (id expr) ...)
syntax
(private* (id expr) ...)
syntax
(define/public id expr)
(define/public (id . formals) body ...+)
syntax
(define/pubment id expr)
(define/pubment (id . formals) body ...+)
syntax
(define/public-final id expr)
(define/public-final (id . formals) body ...+)
syntax
(define/override id expr)
(define/override (id . formals) body ...+)
syntax
(define/overment id expr)
(define/overment (id . formals) body ...+)
syntax
(define/override-final id expr)
(define/override-final (id . formals) body ...+)
syntax
(define/augment id expr)
(define/augment (id . formals) body ...+)
syntax
(define/augride id expr)
(define/augride (id . formals) body ...+)
syntax
(define/augment-final id expr)
(define/augment-final (id . formals) body ...+)
syntax
(define/private id expr)
(define/private (id . formals) body ...+)
syntax
(class/derived original-datum
  (name-id super-expr (interface-expr ...) deserialize-id-expr)
  class-clause
  ...)
syntax
(super id arg ...)
(super id arg ... . arg-list-expr)
syntax
(inner default-expr id arg ...)
(inner default-expr id arg ... . arg-list-expr)
syntax
(define-local-member-name id ...)
syntax
(define-member-name id key-expr)
syntax
(member-name-key identifier)
procedure
(generate-member-key) -> member-name-key?
procedure
(member-name-key? v) -> boolean?
  v : any/c
procedure
(member-name-key=? a-key b-key) -> boolean?
  a-key : member-name-key?
  b-key : member-name-key?
procedure
(member-name-key-hash-code a-key) -> integer?
  a-key : member-name-key?
procedure
(make-object class init-v ...) -> object?
  class : class?
  init-v : any/c
syntax
(new class-expr (id by-name-expr) ...)
syntax
(instantiate class-expr (by-pos-expr ...) (id by-name-expr) ...)
syntax
super-make-object
syntax
(super-instantiate (by-pos-expr ...) (id by-expr ...) ...)
syntax
(super-new (id by-name-expr ...) ...)

(method-id arg ... . arg-list-expr)
syntax
(send obj-expr method-id arg ...)
(send obj-expr method-id arg ... . arg-list-expr)
syntax
(send/apply obj-expr method-id arg ... arg-list-expr)
syntax
(send/keyword-apply obj-expr method-id
                    keyword-list-expr value-list-expr
                    arg ... arg-list-expr)
procedure
(dynamic-send obj                    
              method-name            
              v ...                  
              #:<kw> kw-arg ...) -> any
  obj : object?
  method-name : symbol?
  v : any/c
  kw-arg : any/c
syntax
(send* obj-expr msg ...+)
 
msg = (method-id arg ...)
    | (method-id arg ... . arg-list-expr)
syntax
(send+ obj-expr msg ...)
 
msg = (method-id arg ...)
    | (method-id arg ... . arg-list-expr)
syntax
(with-method ((id (obj-expr method-id)) ...)
  body ...+)
syntax
(get-field id obj-expr)
procedure
(dynamic-get-field field-name obj) -> any/c
  field-name : symbol?
  obj : object?
syntax
(set-field! id obj-expr expr)
procedure
(dynamic-set-field! field-name obj v) -> void?
  field-name : symbol?
  obj : object?
  v : any/c
syntax
(field-bound? id obj-expr)
syntax
(class-field-accessor class-expr field-id)
syntax
(class-field-mutator class-expr field-id)
syntax
(generic class-or-interface-expr id)
syntax
(send-generic obj-expr generic-expr arg ...)
(send-generic obj-expr generic-expr arg ... . arg-list-expr)
procedure
(make-generic type method-name) -> generic?
  type : (or/c class? interface?)
  method-name : symbol?
syntax
(mixin (interface-expr ...) (interface-expr ...)
  class-clause ...)
syntax
(trait trait-clause ...)
 
trait-clause = (public maybe-renamed ...)
             | (pubment maybe-renamed ...)
             | (public-final maybe-renamed ...)
             | (override maybe-renamed ...)
             | (overment maybe-renamed ...)
             | (override-final maybe-renamed ...)
             | (augment maybe-renamed ...)
             | (augride maybe-renamed ...)
             | (augment-final maybe-renamed ...)
             | (inherit maybe-renamed ...)
             | (inherit/super maybe-renamed ...)
             | (inherit/inner maybe-renamed ...)
             | method-definition
             | (field field-declaration ...)
             | (inherit-field maybe-renamed ...)
procedure
(trait? v) -> boolean?
  v : any/c
procedure
(trait->mixin tr) -> (class? . -> . class?)
  tr : trait?
procedure
(trait-sum tr ...+) -> trait?
  tr : trait?
syntax
(trait-exclude trait-expr id)
syntax
(trait-exclude-field trait-expr id)
syntax
(trait-alias trait-expr id new-id)
syntax
(trait-rename trait-expr id new-id)
syntax
(trait-rename-field trait-expr id new-id)
syntax
(class/c maybe-opaque member-spec ...)
 
maybe-opaque = 
             | #:opaque
             | #:opaque #:ignore-local-member-names
                
 member-spec = method-spec
             | (field field-spec ...)
             | (init field-spec ...)
             | (init-field field-spec ...)
             | (inherit method-spec ...)
             | (inherit-field field-spec ...)
             | (super method-spec ...)
             | (inner method-spec ...)
             | (override method-spec ...)
             | (augment method-spec ...)
             | (augride method-spec ...)
             | (absent absent-spec ...)
                
 method-spec = method-id
             | (method-id method-contract-expr)
                
  field-spec = field-id
             | (field-id contract-expr)
                
 absent-spec = method-id
             | (field field-id ...)
syntax
(absent absent-spec ...)
syntax
(->m dom ... range)
syntax
(->*m (mandatory-dom ...) (optional-dom ...) rest range)
syntax
(case->m (-> dom ... rest range) ...)
syntax
(->dm (mandatory-dependent-dom ...)
      (optional-dependent-dom ...)
      dependent-rest
      pre-cond
      dep-range)
syntax
(object/c member-spec ...)
 
member-spec = method-spec
            | (field field-spec ...)
               
method-spec = method-id
            | (method-id method-contract)
               
 field-spec = field-id
            | (field-id contract-expr)
procedure
(instanceof/c class-contract) -> contract?
  class-contract : contract?
procedure
(dynamic-object/c method-names         
                  method-contracts     
                  field-names          
                  field-contracts) -> contract?
  method-names : (listof symbol?)
  method-contracts : (listof contract?)
  field-names : (listof symbol?)
  field-contracts : (listof contract?)
syntax
(object-contract member-spec ...)
 
            member-spec = (method-id method-contract)
                        | (field field-id contract-expr)
                           
        method-contract = (-> dom ... range)
                        | (->* (mandatory-dom ...)
                               (optional-dom ...)
                               rest
                               range)
                        | (->d (mandatory-dependent-dom ...)
                               (optional-dependent-dom ...)
                               dependent-rest
                               pre-cond
                               dep-range)
                           
                    dom = dom-expr
                        | keyword dom-expr
                           
                  range = range-expr
                        | (values range-expr ...)
                        | any
                           
          mandatory-dom = dom-expr
                        | keyword dom-expr
                           
           optional-dom = dom-expr
                        | keyword dom-expr
                           
                   rest = 
                        | #:rest rest-expr
                           
mandatory-dependent-dom = [id dom-expr]
                        | keyword [id dom-expr]
                           
 optional-dependent-dom = [id dom-expr]
                        | keyword [id dom-expr]
                           
         dependent-rest = 
                        | #:rest id rest-expr
                           
               pre-cond = 
                        | #:pre-cond boolean-expr
                           
              dep-range = any
                        | [id range-expr] post-cond
                        | (values [id range-expr] ...) post-cond
                           
              post-cond = 
                        | #:post-cond boolean-expr
value
mixin-contract : contract?
procedure
(make-mixin-contract type ...) -> contract?
  type : (or/c class? interface?)
procedure
(is-a?/c type) -> flat-contract?
  type : (or/c class? interface?)
procedure
(implementation?/c interface) -> flat-contract?
  interface : interface?
procedure
(subclass?/c class) -> flat-contract?
  class : class?
interface
equal<%> : interface?
syntax
(define-serializable-class* class-id superclass-expr
                                     (interface-expr ...)
  class-clause ...)
syntax
(define-serializable-class class-id superclass-expr
  class-clause ...)
interface
externalizable<%> : interface?
value
printable<%> : interface?
value
writable<%> : interface?
procedure
(object? v) -> boolean?
  v : any/c
procedure
(class? v) -> boolean?
  v : any/c
procedure
(interface? v) -> boolean?
  v : any/c
procedure
(generic? v) -> boolean?
  v : any/c
procedure
(object=? a b) -> boolean?
  a : object?
  b : object?
procedure
(object-or-false=? a b) -> boolean?
  a : (or/c object? #f)
  b : (or/c object? #f)
procedure
(object->vector object [opaque-v]) -> vector?
  object : object?
  opaque-v : any/c = #f
procedure
(class->interface class) -> interface?
  class : class?
procedure
(object-interface object) -> interface?
  object : object?
procedure
(is-a? v type) -> boolean?
  v : any/c
  type : (or/c interface? class?)
procedure
(subclass? v cls) -> boolean?
  v : any/c
  cls : class?
procedure
(implementation? v intf) -> boolean?
  v : any/c
  intf : interface?
procedure
(interface-extension? v intf) -> boolean?
  v : any/c
  intf : interface?
procedure
(method-in-interface? sym intf) -> boolean?
  sym : symbol?
  intf : interface?
procedure
(interface->method-names intf) -> (listof symbol?)
  intf : interface?
procedure
(object-method-arity-includes? object     
                               sym        
                               cnt)   -> boolean?
  object : object?
  sym : symbol?
  cnt : exact-nonnegative-integer?
procedure
(field-names object) -> (listof symbol?)
  object : object?
procedure
(object-info object) -> (or/c class? #f) boolean?
  object : object?
procedure
(class-info class)
 -> symbol?
    exact-nonnegative-integer?
    (listof symbol?)
    (any/c exact-nonnegative-integer? . -> . any/c)
    (any/c exact-nonnegative-integer? any/c . -> . any/c)
    (or/c class? #f)
    boolean?
  class : class?
struct
(struct exn:fail:object exn:fail ()
    #:extra-constructor-name make-exn:fail:object)
syntax
(surrogate method-spec ...)
 
method-spec = (method-id arg-spec ...)
            | (override method-id arg-spec ...)
            | (override-final method-id (lambda () default-expr)
                              arg-spec ...)
               
   arg-spec = (id ...)
            | id
syntax
(unit
  (import tagged-sig-spec ...)
  (export tagged-sig-spec ...)
  init-depends-decl
  unit-body-expr-or-defn
  ...)
 
  tagged-sig-spec = sig-spec
                  | (tag id sig-spec)
                     
         sig-spec = sig-id
                  | (prefix id sig-spec)
                  | (rename sig-spec (id id) ...)
                  | (only sig-spec id ...)
                  | (except sig-spec id ...)
                     
init-depends-decl = 
                  | (init-depend tagged-sig-id ...)
                     
    tagged-sig-id = sig-id
                  | (tag id sig-id)
syntax
(define-signature id extension-decl
  (sig-elem ...))
 
extension-decl = 
               | extends sig-id
                  
      sig-elem = id
               | (define-syntaxes (id ...) expr)
               | (define-values (id ...) expr)
               | (define-values-for-export (id ...) expr)
               | (contracted [id contract] ...)
               | (open sig-spec)
               | (struct id (field ...) struct-option ...)
               | (sig-form-id . datum)
                  
         field = id
               | [id #:mutable]
                  
 struct-option = #:mutable
               | #:constructor-name constructor-id
               | #:extra-constructor-name constructor-id
               | #:omit-constructor
               | #:omit-define-syntaxes
               | #:omit-define-values
syntax
(open sig-spec)
syntax
(define-values-for-export (id ...) expr)
syntax
(contracted [id contract] ...)
syntax
(only sig-spec id ...)
syntax
(except sig-spec id ...)
syntax
(rename sig-spec (id id) ...)
syntax
(prefix id sig-spec)
syntax
(import tagged-sig-spec ...)
syntax
(export tagged-sig-spec ...)
syntax
(link linkage-decl ...)
syntax
(tag id sig-spec)
(tag id sig-id)
syntax
(init-depend tagged-sig-id ...)
syntax
extends
syntax
(invoke-unit unit-expr)
(invoke-unit unit-expr (import tagged-sig-spec ...))
syntax
(define-values/invoke-unit unit-expr
  (import tagged-sig-spec ...)
  (export tagged-sig-spec ...))
syntax
(compound-unit
  (import link-binding ...)
  (export tagged-link-id ...)
  (link linkage-decl ...))
 
  link-binding = (link-id : tagged-sig-id)
                  
tagged-link-id = (tag id link-id)
               | link-id
                  
  linkage-decl = ((link-binding ...) unit-expr tagged-link-id ...)
syntax
(define-unit unit-id
  (import tagged-sig-spec ...)
  (export tagged-sig-spec ...)
  init-depends-decl
  unit-body-expr-or-defn
  ...)
syntax
(compound-unit/infer
  (import tagged-infer-link-import ...)
  (export tagged-infer-link-export ...)
  (link infer-linkage-decl ...))
 
tagged-infer-link-import = tagged-sig-id
                         | (link-id : tagged-sig-id)
                            
tagged-infer-link-export = (tag id infer-link-export)
                         | infer-link-export
                            
       infer-link-export = link-id
                         | sig-id
                            
      infer-linkage-decl = ((link-binding ...) unit-id
                                               tagged-link-id ...)
                         | unit-id
syntax
(define-compound-unit id
  (import link-binding ...)
  (export tagged-link-id ...)
  (link linkage-decl ...))
syntax
(define-compound-unit/infer id
  (import link-binding ...)
  (export tagged-infer-link-export ...)
  (link infer-linkage-decl ...))
syntax
(define-unit-binding unit-id
  unit-expr
  (import tagged-sig-spec ...+)
  (export tagged-sig-spec ...+)
  init-depends-decl)
syntax
(invoke-unit/infer unit-spec)
 
unit-spec = unit-id
          | (link link-unit-id ...)
syntax
(define-values/invoke-unit/infer maybe-exports unit-spec)
 
maybe-exports = 
              | (export tagged-sig-spec ...)
                 
    unit-spec = unit-id
              | (link link-unit-id ...)
syntax
(unit-from-context tagged-sig-spec)
syntax
(define-unit-from-context id tagged-sig-spec)
syntax
(unit/new-import-export
  (import tagged-sig-spec ...)
  (export tagged-sig-spec ...)
  init-depends-decl
  ((tagged-sig-spec ...) unit-expr tagged-sig-spec))
syntax
(define-unit/new-import-export unit-id
  (import tagged-sig-spec ...)
  (export tagged-sig-spec ...)
  init-depends-decl
  ((tagged-sig-spec ...) unit-expr tagged-sig-spec))
syntax
(unit/s
  (import tagged-sig-spec ...)
  (export tagged-sig-spec ...)
  init-depends-decl
  unit-id)
syntax
(define-unit/s name-id
  (import tagged-sig-spec ...)
  (export tagged-sig-spec ...)
  init-depends-decl
  unit-id)
syntax
(define-signature-form sig-form-id expr)
(define-signature-form (sig-form-id id) body ...+)
syntax
(struct/ctc id ([field contract-expr] ...) struct-option ...)
 
        field = id
              | [id #:mutable]
                 
struct-option = #:mutable
              | #:omit-constructor
              | #:omit-define-syntaxes
              | #:omit-define-values
procedure
(unit? v) -> boolean?
  v : any/c
syntax
(provide-signature-elements sig-spec ...)
syntax
(unit/c (import sig-block ...) (export sig-block ...))
 
sig-block = (tagged-sig-id [id contract] ...)
          | tagged-sig-id
syntax
(define-unit/contract unit-id
  (import sig-spec-block ...)
  (export sig-spec-block ...)
  init-depends-decl
  unit-body-expr-or-defn
  ...)
 
sig-spec-block = (tagged-sig-spec [id contract] ...)
               | tagged-sig-spec
procedure
(unit-static-signatures unit-identifier 
                        err-syntax)     
 -> (list/c (cons/c (or/c symbol? #f)
                    identifier?))
    (list/c (cons/c (or/c symbol? #f)
                    identifier?))
  unit-identifier : identifier?
  err-syntax : syntax?
procedure
(signature-members sig-identifier     
                   err-syntax)    -> (or/c identifier? #f)
                                     (listof identifier?)
                                     (listof identifier?)
                                     (listof identifier?)
  sig-identifier : identifier?
  err-syntax : syntax?
procedure
(unit-static-init-dependencies unit-identifier 
                               err-syntax)     
 -> (list/c (cons/c (or/c symbol? #f)
                    identifier?))
  unit-identifier : identifier?
  err-syntax : syntax?
procedure
(flat-named-contract  name              
                      flat-contract     
                     [generator])   -> flat-contract?
  name : any/c
  flat-contract : flat-contract?
  generator : (or/c #f (-> contract (-> int? any))) = #f
value
any/c : flat-contract?
value
none/c : flat-contract?
procedure
(or/c contract ...) -> contract?
  contract : contract?
procedure
(and/c contract ...) -> contract?
  contract : contract?
procedure
(not/c flat-contract) -> flat-contract?
  flat-contract : flat-contract?
procedure
(=/c z) -> flat-contract?
  z : real?
procedure
(</c n) -> flat-contract?
  n : real?
procedure
(>/c n) -> flat-contract?
  n : real?
procedure
(<=/c n) -> flat-contract?
  n : real?
procedure
(>=/c n) -> flat-contract?
  n : real?
procedure
(between/c n m) -> flat-contract?
  n : real?
  m : real?
procedure
(real-in n m) -> flat-contract?
  n : real?
  m : real?
procedure
(integer-in j k) -> flat-contract?
  j : exact-integer?
  k : exact-integer?
value
natural-number/c : flat-contract?
procedure
(string-len/c len) -> flat-contract?
  len : real?
value
false/c : flat-contract?
value
printable/c : flat-contract?
procedure
(one-of/c v ...+) -> flat-contract?
  v : any/c
procedure
(symbols sym ...+) -> flat-contract?
  sym : symbol?
procedure
(vectorof  c                         
          [#:immutable immutable     
           #:flat? flat?])       -> contract?
  c : contract?
  immutable : (or/c #t #f 'dont-care) = 'dont-care
  flat? : boolean? = #f
procedure
(vector-immutableof c) -> contract?
  c : contract?
procedure
(vector/c  c                         
           ...                       
          [#:immutable immutable     
           #:flat? flat?])       -> contract?
  c : contract?
  immutable : (or/c #t #f 'dont-care) = 'dont-care
  flat? : boolean? = #f
procedure
(vector-immutable/c c ...) -> contract?
  c : contract?
procedure
(box/c  c                         
       [#:immutable immutable     
        #:flat? flat?])       -> contract?
  c : contract?
  immutable : (or/c #t #f 'dont-care) = 'dont-care
  flat? : boolean? = #f
procedure
(box-immutable/c c) -> contract?
  c : contract?
procedure
(listof c) -> list-contract?
  c : contract?
procedure
(non-empty-listof c) -> list-contract?
  c : contract?
procedure
(list*of c) -> contract?
  c : contract?
procedure
(cons/c car-c cdr-c) -> contract?
  car-c : contract?
  cdr-c : contract?
syntax
(cons/dc [car-id contract-expr] [cdr-id (car-id) contract-expr] cons/dc-option)
(cons/dc [car-id (cdr-id) contract-expr] [cdr-id contract-expr] cons/dc-option)
 
cons/dc-option = 
               | #:flat
               | #:chaperone
               | #:impersonator
procedure
(list/c c ...) -> list-contract?
  c : contract?
procedure
(syntax/c c) -> flat-contract?
  c : flat-contract?
syntax
(struct/c struct-id contract-expr ...)
syntax
(struct/dc struct-id field-spec ... maybe-inv)
 
         field-spec = [field-name maybe-lazy contract-expr]
                    | [field-name (dep-field-name ...)
                                  maybe-lazy
                                  maybe-contract-type
                                  maybe-dep-state
                                  contract-expr]
                       
         field-name = field-id
                    | (#:selector selector-id)
                    | (field-id #:parent struct-id)
                       
         maybe-lazy = 
                    | #:lazy
                       
maybe-contract-type = 
                    | #:flat
                    | #:chaperone
                    | #:impersonator
                       
    maybe-dep-state = 
                    | #:depends-on-state
                       
          maybe-inv = 
                    | #:inv (dep-field-name ...) invariant-expr
procedure
(parameter/c in [out]) -> contract?
  in : contract?
  out : contract? = in
procedure
(procedure-arity-includes/c n) -> flat-contract?
  n : exact-nonnegative-integer?
procedure
(hash/c  key                       
         val                       
        [#:immutable immutable     
         #:flat? flat?])       -> contract?
  key : chaperone-contract?
  val : contract?
  immutable : (or/c #t #f 'dont-care) = 'dont-care
  flat? : boolean? = #f
syntax
(hash/dc [key-id key-contract-expr] [value-id (key-id) value-contract-expr]
         hash/dc-option)
 
hash/dc-option = 
               | #:immutable immutable?-expr hash/dc-option
               | #:kind kind-expr hash/dc-option
procedure
(channel/c val) -> contract?
  val : contract?
syntax
(prompt-tag/c contract ... maybe-call/cc)
 
maybe-call/cc = 
              | #:call/cc contract
              | #:call/cc (values contract ...)
 
  contract : contract?
procedure
(continuation-mark-key/c contract) -> contract?
  contract : contract?
procedure
(evt/c contract ...) -> chaperone-contract?
  contract : chaperone-contract?
syntax
(flat-rec-contract id flat-contract-expr ...)
syntax
(flat-murec-contract ([id flat-contract-expr ...] ...) body ...+)
syntax
any
procedure
(promise/c c) -> contract?
  c : contract?
procedure
(flat-contract predicate) -> flat-contract?
  predicate : (-> any/c any/c)
procedure
(flat-contract-predicate v) -> (-> any/c any/c)
  v : flat-contract?
syntax
(-> dom ... range)
 
  dom = dom-expr
      | keyword dom-expr
         
range = range-expr
      | (values range-expr ...)
      | any
syntax
(->* (mandatory-dom ...) optional-doms rest pre range post)
 
mandatory-dom = dom-expr
              | keyword dom-expr
                 
optional-doms = 
              | (optional-dom ...)
                 
 optional-dom = dom-expr
              | keyword dom-expr
                 
         rest = 
              | #:rest rest-expr
                 
          pre = 
              | #:pre pre-cond-expr
              | #:pre/desc pre-cond-expr
                 
        range = range-expr
              | (values range-expr ...)
              | any
                 
         post = 
              | #:post post-cond-expr
              | #:post/desc post-cond-expr
syntax
(->i (mandatory-dependent-dom ...)
     dependent-rest
     pre-condition
     dependent-range
     post-condition)
(->i (mandatory-dependent-dom ...)
     (optional-dependent-dom ...)
     dependent-rest
     pre-condition
     dependent-range
     post-condition)
 
mandatory-dependent-dom = id+ctc
                        | keyword id+ctc
                           
 optional-dependent-dom = id+ctc
                        | keyword id+ctc
                           
         dependent-rest = 
                        | #:rest id+ctc
                           
          pre-condition = 
                        | #:pre (id ...)
                          boolean-expr pre-condition
                        | #:pre/desc (id ...)
                          expr pre-condition
                        | #:pre/name (id ...)
                          string boolean-expr pre-condition
                           
        dependent-range = any
                        | id+ctc
                        | un+ctc
                        | (values id+ctc ...)
                        | (values un+ctc ...)
                           
         post-condition = 
                        | #:post (id ...)
                          boolean-expr post-condition
                        | #:post/desc (id ...)
                          expr post-condition
                        | #:post/name (id ...)
                          string boolean-expr post-condition
                           
                 id+ctc = [id contract-expr]
                        | [id (id ...) contract-expr]
                           
                 un+ctc = [_ contract-expr]
                        | [_ (id ...) contract-expr]
syntax
(->d (mandatory-dependent-dom ...)
     dependent-rest
     pre-condition
     dependent-range
     post-condition)
(->d (mandatory-dependent-dom ...)
     (optional-dependent-dom ...)
     dependent-rest
     pre-condition
     dependent-range
     post-condition)
 
mandatory-dependent-dom = [id dom-expr]
                        | keyword [id dom-expr]
                           
 optional-dependent-dom = [id dom-expr]
                        | keyword [id dom-expr]
                           
         dependent-rest = 
                        | #:rest id rest-expr
                           
          pre-condition = 
                        | #:pre boolean-expr
                        | #:pre-cond boolean-expr
                           
        dependent-range = any
                        | [_ range-expr]
                        | (values [_ range-expr] ...)
                        | [id range-expr]
                        | (values [id range-expr] ...)
                           
         post-condition = 
                        | #:post-cond boolean-expr
syntax
(case-> (-> dom-expr ... rest range) ...)
 
 rest = 
      | #:rest rest-expr
         
range = range-expr
      | (values range-expr ...)
      | any
procedure
(dynamic->*                                                            
            [#:mandatory-domain-contracts mandatory-domain-contracts   
             #:optional-domain-contracts optional-domain-contracts     
             #:mandatory-keywords mandatory-keywords                   
             #:mandatory-keyword-contracts mandatory-keyword-contracts 
             #:optional-keywords optional-keywords                     
             #:optional-keyword-contracts optional-keyword-contracts   
             #:rest-contract rest-contract]                            
             #:range-contracts range-contracts)                        
 -> contract?
  mandatory-domain-contracts : (listof contract?) = '()
  optional-domain-contracts : (listof contract?) = '()
  mandatory-keywords : (listof keyword?) = '()
  mandatory-keyword-contracts : (listof contract?) = '()
  optional-keywords : (listof keyword?) = '()
  optional-keyword-contracts : (listof contract?) = '()
  rest-contract : (or/c #f contract?) = #f
  range-contracts : (or/c #f (listof contract?))
syntax
(unconstrained-domain-> range-expr ...)
value
predicate/c : contract?
value
the-unsupplied-arg : unsupplied-arg?
procedure
(unsupplied-arg? v) -> boolean?
  v : any/c
syntax
(parametric->/c (x ...) c)
procedure
(new-∀/c [name]) -> contract?
  name : (or/c symbol? #f) = #f
procedure
(new-∃/c [name]) -> contract?
  name : (or/c symbol? #f) = #f
syntax
(contract-struct id (field-id ...))

(id/dc field-spec ...)
 
field-spec = [field-id contract-expr]
           | [field-id (field-id ...) contract-expr]
syntax
(define-contract-struct id (field-id ...))
procedure
(struct-type-property/c value-contract) -> contract?
  value-contract : contract?
syntax
(contract-out p/c-item ...)
 
      p/c-item = (struct id/super ((id contract-expr) ...)
                   struct-option)
               | (rename orig-id id contract-expr)
               | (id contract-expr)
               | #:∃ poly-variables
               | #:exists poly-variables
               | #:∀ poly-variables
               | #:forall poly-variables
                  
poly-variables = id
               | (id ...)
                  
      id/super = id
               | (id super-id)
                  
 struct-option = 
               | #:omit-constructor
syntax
(recontract-out id ...)
syntax
(provide/contract p/c-item ...)
syntax
(with-contract blame-id (wc-export ...) free-var-list ... body ...+)
(with-contract blame-id results-spec free-var-list ... body ...+)
 
    wc-export = (id contract-expr)
                 
  result-spec = #:result contract-expr
              | #:results (contract-expr ...)
                 
free-var-list = 
              | #:freevar id contract-expr
              | #:freevars ([id contract-expr] ...)
syntax
(define/contract id contract-expr free-var-list init-value-expr)
(define/contract (head args) contract-expr free-var-list body ...+)
syntax
(define-struct/contract struct-id ([field contract-expr] ...)
                        struct-option ...)
(define-struct/contract (struct-id super-struct-id)
                        ([field contract-expr] ...)
                        struct-option ...)
syntax
(invariant-assertion invariant-expr expr)
syntax
current-contract-region
syntax
(define-module-boundary-contract id
  orig-id
  contract-expr
  pos-blame-party
  source-loc)
 
pos-blame-party = 
                | #:pos-source pos-source-expr
                   
     source-loc = 
                | #:srcloc srcloc-expr
syntax
(contract contract-expr to-protect-expr
          positive-blame-expr negative-blame-expr)
(contract contract-expr to-protect-expr
          positive-blame-expr negative-blame-expr
          value-name-expr source-location-expr)
procedure
(make-contract [#:name name                           
                #:first-order test                    
                #:val-first-projection val-first-proj 
                #:projection proj                     
                #:stronger stronger                   
                #:list-contract? is-list-contract?])  
 -> contract?
  name : any/c = 'anonymous-contract
  test : (-> any/c any/c) = (λ (x) #t)
  val-first-proj : (or/c #f (-> blame? (-> any/c (-> any/c any/c))))
                 = #f
  proj : (-> blame? (-> any/c any/c))
       = (λ (b)
           (λ (x)
             (if (test x)
               x
               (raise-blame-error
                b x
                '(expected: "~a" given: "~e")
                name x))))
  stronger : (or/c #f (-> contract? contract? boolean?)) = #f
  is-list-contract? : boolean? = #f
procedure
(make-chaperone-contract                                        
                         [#:name name                           
                          #:first-order test                    
                          #:val-first-projection val-first-proj 
                          #:projection proj                     
                          #:stronger stronger                   
                          #:list-contract? is-list-contract?])  
 -> chaperone-contract?
  name : any/c = 'anonymous-chaperone-contract
  test : (-> any/c any/c) = (λ (x) #t)
  val-first-proj : (or/c #f (-> blame? (-> any/c (-> any/c any/c))))
                 = #f
  proj : (-> blame? (-> any/c any/c))
       = (λ (b)
           (λ (x)
             (if (test x)
               x
               (raise-blame-error
                b x
                '(expected: "~a" given: "~e")
                name x))))
  stronger : (or/c #f (-> contract? contract? boolean?)) = #f
  is-list-contract? : boolean? = #f
procedure
(make-flat-contract [#:name name                           
                     #:first-order test                    
                     #:val-first-projection val-first-proj 
                     #:projection proj                     
                     #:stronger stronger                   
                     #:list-contract? is-list-contract?])  
 -> flat-contract?
  name : any/c = 'anonymous-flat-contract
  test : (-> any/c any/c) = (λ (x) #t)
  val-first-proj : (or/c #f (-> blame? (-> any/c (-> any/c any/c))))
                 = #f
  proj : (-> blame? (-> any/c any/c))
       = (λ (b)
           (λ (x)
             (if (test x)
               x
               (raise-blame-error
                b x
                '(expected: "~a" given: "~e")
                name x))))
  stronger : (or/c #f (-> contract? contract? boolean?)) = #f
  is-list-contract? : boolean? = #f
procedure
(build-compound-type-name c/s ...) -> any
  c/s : any/c
procedure
(coerce-contract id x) -> contract?
  id : symbol?
  x : any/c
procedure
(coerce-contracts id xs) -> (listof contract?)
  id : symbol?
  xs : (listof any/c)
procedure
(coerce-chaperone-contract id x) -> chaperone-contract?
  id : symbol?
  x : any/c
procedure
(coerce-chaperone-contracts id x) -> (listof chaperone-contract?)
  id : symbol?
  x : (listof any/c)
procedure
(coerce-flat-contract id x) -> flat-contract?
  id : symbol?
  x : any/c
procedure
(coerce-flat-contracts id x) -> (listof flat-contract?)
  id : symbol?
  x : (listof any/c)
procedure
(coerce-contract/f x) -> (or/c contract? #f)
  x : any/c
procedure
(get/build-val-first-projection c)
 -> (-> contract? blame? (-> any/c (-> any/c any/c)))
  c : contract?
procedure
(blame? x) -> boolean?
  x : any/c
procedure
(blame-add-context  blame                     
                    context                   
                   [#:important important     
                    #:swap? swap?])       -> blame?
  blame : blame?
  context : (or/c string? #f)
  important : (or/c string? #f) = #f
  swap? : boolean? = #f
procedure
(blame-positive b) -> any/c
  b : blame?
procedure
(blame-negative b) -> any/c
  b : blame?
procedure
(blame-contract b) -> any/c
  b : blame?
procedure
(blame-value b) -> any/c
  b : blame?
procedure
(blame-source b) -> srcloc?
  b : blame?
procedure
(blame-swap b) -> blame?
  b : blame?
procedure
(blame-original? b) -> boolean?
  b : blame?
procedure
(blame-swapped? b) -> boolean?
  b : blame?
procedure
(blame-replace-negative b neg) -> blame?
  b : blame?
  neg : any/c
procedure
(blame-update b pos neg) -> blame?
  b : blame?
  pos : any/c
  neg : any/c
procedure
(raise-blame-error b x fmt v ...) -> none/c
  b : blame?
  x : any/c
  fmt : (or/c string?
              (listof (or/c string?
                            'given 'given:
                            'expected 'expected:)))
  v : any/c
struct
(struct exn:fail:contract:blame exn:fail:contract (object)
    #:extra-constructor-name make-exn:fail:contract:blame)
  object : blame?
parameter
(current-blame-format) -> (-> blame? any/c string? string?)
(current-blame-format proc) -> void?
  proc : (-> blame? any/c string? string?)
value
prop:contract : struct-type-property?
value
prop:chaperone-contract : struct-type-property?
value
prop:flat-contract : struct-type-property?
value
prop:contracted : struct-type-property?
value
impersonator-prop:contracted : impersonator-property?
value
prop:blame : struct-type-property?
value
impersonator-prop:blame : impersonator-property?
procedure
(build-flat-contract-property                                        
                              [#:name get-name                       
                               #:first-order get-first-order         
                               #:val-first-projection val-first-proj 
                               #:projection get-projection           
                               #:stronger stronger                   
                               #:generate generate                   
                               #:exercise exercise                   
                               #:list-contract? is-list-contract?])  
 -> flat-contract-property?
  get-name : (-> contract? any/c)
           = (λ (c) 'anonymous-flat-contract)
  get-first-order : (-> contract? (-> any/c boolean?))
                  = (λ (c) (λ (x) #t))
  val-first-proj : (or/c #f (-> contract? blame? (-> any/c (-> any/c any/c))))
                 = #f
  get-projection : (-> contract? (-> blame? (-> any/c any/c)))
                 = (λ (c)
                     (λ (b)
                       (λ (x)
                         (if ((get-first-order c) x)
                             x
                             (raise-blame-error
                              b x '(expected: "~a" given: "~e")
                              (get-name c) x)))))
  stronger : (or/c (-> contract? contract? boolean?) #f) = #f
  generate : (->i ([c contract?])
                  ([generator
                    (c)
                    (-> (and/c positive? real?)
                        (or/c (-> (or/c contract-random-generate-fail? c))
                              #f))]))
           = (λ (c) (λ (fuel) #f))
  exercise : (->i ([c contract?])
                  ([result
                    (c)
                    (-> (and/c positive? real?)
                        (values
                         (-> c void?)
                         (listof contract?)))]))
           = (λ (c) (λ (fuel) (values void '())))
  is-list-contract? : (-> contract? boolean?) = (λ (c) #f)
procedure
(build-chaperone-contract-property                                        
                                   [#:name get-name                       
                                    #:first-order get-first-order         
                                    #:val-first-projection val-first-proj 
                                    #:projection get-projection           
                                    #:stronger stronger                   
                                    #:generate generate                   
                                    #:exercise exercise                   
                                    #:list-contract? is-list-contract?])  
 -> chaperone-contract-property?
  get-name : (-> contract? any/c)
           = (λ (c) 'anonymous-chaperone-contract)
  get-first-order : (-> contract? (-> any/c boolean?))
                  = (λ (c) (λ (x) #t))
  val-first-proj : (or/c #f (-> contract? blame? (-> any/c (-> any/c any/c))))
                 = #f
  get-projection : (-> contract? (-> blame? (-> any/c any/c)))
                 = (λ (c)
                     (λ (b)
                       (λ (x)
                         (if ((get-first-order c) x)
                             x
                             (raise-blame-error
                              b x '(expected: "~a" given: "~e")
                              (get-name c) x)))))
  stronger : (or/c (-> contract? contract? boolean?) #f) = #f
  generate : (->i ([c contract?])
                  ([generator
                    (c)
                    (-> (and/c positive? real?)
                        (or/c (-> (or/c contract-random-generate-fail? c))
                              #f))]))
           = (λ (c) (λ (fuel) #f))
  exercise : (->i ([c contract?])
                  ([result
                    (c)
                    (-> (and/c positive? real?)
                        (values
                         (-> c void?)
                         (listof contract?)))]))
           = (λ (c) (λ (fuel) (values void '())))
  is-list-contract? : (-> contract? boolean?) = (λ (c) #f)
procedure
(build-contract-property                                        
                         [#:name get-name                       
                          #:first-order get-first-order         
                          #:val-first-projection val-first-proj 
                          #:projection get-projection           
                          #:stronger stronger                   
                          #:generate generate                   
                          #:exercise exercise                   
                          #:list-contract? is-list-contract?])  
 -> contract-property?
  get-name : (-> contract? any/c) = (λ (c) 'anonymous-contract)
  get-first-order : (-> contract? (-> any/c boolean?))
                  = (λ (c) (λ (x) #t))
  val-first-proj : (or/c #f (-> contract? blame? (-> any/c (-> any/c any/c))))
                 = #f
  get-projection : (-> contract? (-> blame? (-> any/c any/c)))
                 = (λ (c)
                     (λ (b)
                       (λ (x)
                         (if ((get-first-order c) x)
                             x
                             (raise-blame-error
                              b x '(expected: "~a" given: "~e")
                              (get-name c) x)))))
  stronger : (or/c (-> contract? contract? boolean?) #f) = #f
  generate : (->i ([c contract?])
                  ([generator
                    (c)
                    (-> (and/c positive? real?)
                        (or/c (-> (or/c contract-random-generate-fail? c))
                              #f))]))
           = (λ (c) (λ (fuel) #f))
  exercise : (->i ([c contract?])
                  ([result
                    (c)
                    (-> (and/c positive? real?)
                        (values
                         (-> c void?)
                         (listof contract?)))]))
           = (λ (c) (λ (fuel) (values void '())))
  is-list-contract? : (-> contract? boolean?) = (λ (c) #f)
procedure
(contract-property? x) -> boolean?
  x : any/c
procedure
(chaperone-contract-property? x) -> boolean?
  x : any/c
procedure
(flat-contract-property? x) -> boolean?
  x : any/c
syntax
(define/final-prop header body ...)
 
header = main-id
       | (main-id id ...)
       | (main-id id ... . id)
syntax
(define/subexpression-pos-prop header body ...)
 
header = main-id
       | (main-id id ...)
       | (main-id id ... . id)
procedure
(contract-stronger? x y) -> boolean?
  x : contract?
  y : contract?
procedure
(contract-first-order-passes? contract v) -> boolean?
  contract : contract?
  v : any/c
procedure
(contract-first-order c) -> (-> any/c boolean?)
  c : contract?
procedure
(contract? v) -> boolean?
  v : any/c
procedure
(chaperone-contract? v) -> boolean?
  v : any/c
procedure
(impersonator-contract? v) -> boolean?
  v : any/c
procedure
(flat-contract? v) -> boolean?
  v : any/c
procedure
(list-contract? v) -> boolean?
  v : any/c
procedure
(contract-name c) -> any/c
  c : contract?
procedure
(value-contract v) -> contract?
  v : has-contract?
procedure
(has-contract? v) -> boolean?
  v : any/c
procedure
(value-blame v) -> (or/c blame? #f)
  v : has-blame?
procedure
(has-blame? v) -> boolean?
  v : any/c
procedure
(contract-projection c) -> (-> blame? (-> any/c any/c))
  c : contract?
procedure
(make-none/c sexp-name) -> contract?
  sexp-name : any/c
syntax
(recursive-contract contract-expr)
(recursive-contract contract-expr #:list-contract?)
(recursive-contract contract-expr type)
(recursive-contract contract-expr type #:list-contract?)
syntax
(opt/c contract-expr maybe-name)
 
maybe-name = 
           | #:error-name id
syntax
(define-opt/c (id id ...) expr)
value
contract-continuation-mark-key : continuation-mark-key?
procedure
(contract-custom-write-property-proc c         
                                     p         
                                     mode) -> void?
  c : contract?
  p : output-port?
  mode : (or/c #f #t 0 1)
procedure
(make-proj-contract name proj first-order) -> contract?
  name : any/c
  proj : (or/c (-> any/c
                   any/c
                   (list/c any/c any/c)
                   contact?
                   (-> any/c any/c))
               (-> any/c
                   any/c
                   (list/c any/c any/c)
                   contact?
                   boolean?
                   (-> any/c any/c)))
  first-order : (-> any/c boolean?)
procedure
(raise-contract-error val          
                      src          
                      pos          
                      name         
                      fmt          
                      arg ...) -> any/c
  val : any/c
  src : any/c
  pos : any/c
  name : any/c
  fmt : string?
  arg : any/c
procedure
(contract-proc c)
 -> (->* (symbol? symbol? (or/c syntax? (list/c any/c any/c)))
         (boolean?)
         (-> any/c any))
  c : contract?
procedure
(contract-random-generate ctc [fuel fail]) -> any/c
  ctc : contract?
  fuel : 5 = exact-nonnegative-integer?
  fail : (or/c #f (-> any) (-> boolean? any)) = #f
procedure
(contract-exercise val ...+) -> void?
  val : any/c
procedure
(contract-random-generate/choose c fuel) -> (or/c #f (-> c))
  c : contract?
  fuel : exact-nonnegative-integer?
value
contract-random-generate-fail : contract-random-generate-fail?
procedure
(contract-random-generate-fail? v) -> boolean?
  v : any/c
procedure
(contract-random-generate-env? v) -> boolean?
  v : any/c
procedure
(contract-random-generate-stash env c v) -> void?
  env : contract-random-generate-env?
  c : contract?
  v : c
procedure
(contract-random-generate-get-current-environment)
 -> contract-random-generate-env?
syntax
(match val-expr clause ...)
 
clause = [pat body ...+]
       | [pat (=> id) body ...+]
       | [pat #:when cond-expr body ...+]
syntax
(match* (val-expr ...+) clause* ...)
 
clause* = [(pat ...+) body ...+]
        | [(pat ...+) (=> id) body ...+]
        | [(pat ...+) #:when cond-expr body ...+]
syntax
(match/values expr clause clause ...)
syntax
(define/match (head args)
  match*-clause ...)
 
         head = id
              | (head args)
                 
         args = arg ...
              | arg ... . rest-id
                 
          arg = arg-id
              | [arg-id default-expr]
              | keyword arg-id
              | keyword [arg-id default-expr]
                 
match*-clause = [(pat ...+) body ...+]
              | [(pat ...+) (=> id) body ...+]
              | [(pat ...+) #:when cond-expr body ...+]
syntax
(match-lambda clause ...)
syntax
(match-lambda* clause ...)
syntax
(match-lambda** clause* ...)
syntax
(match-let ([pat expr] ...) body ...+)
syntax
(match-let* ([pat expr] ...) body ...+)
syntax
(match-let-values ([(pat ...) expr] ...) body ...+)
syntax
(match-let*-values ([(pat ...) expr] ...) body ...+)
syntax
(match-letrec ([pat expr] ...) body ...+)
syntax
(match-letrec-values ([(pat ...) expr] ...) body ...+)
syntax
(match-define pat expr)
syntax
(match-define-values (pat pats ...) expr)
procedure
(exn:misc:match? v) -> boolean?
  v : any/c
syntax
(failure-cont)
syntax
(define-match-expander id proc-expr)
(define-match-expander id proc-expr proc-expr)
value
prop:match-expander : struct-type-property?
value
prop:legacy-match-expander : struct-type-property?
procedure
(match-expander? v) -> boolean?
  v : any/c
procedure
(legacy-match-expander? v) -> boolean?
  v : any/c
procedure
(syntax-local-match-introduce stx) -> syntax?
  stx : syntax?
parameter
(match-equality-test) -> (any/c any/c . -> . any)
(match-equality-test comp-proc) -> void?
  comp-proc : (any/c any/c . -> . any)
syntax
(match/derived val-expr original-datum clause ...)
syntax
(match*/derived (val-expr ...) original-datum clause* ...)
syntax
(== val comparator)
(== val)
syntax
(struct* struct-id ([field pat] ...))
procedure
(values v ...) -> any
  v : any/c
procedure
(call-with-values generator receiver) -> any
  generator : (-> any)
  receiver : procedure?
procedure
(raise v [barrier?]) -> any
  v : any/c
  barrier? : any/c = #t
procedure
(error sym) -> any
  sym : symbol?
(error msg v ...) -> any
  msg : string?
  v : any/c
(error src format v ...) -> any
  src : symbol?
  format : string?
  v : any/c
procedure
(raise-user-error sym) -> any
  sym : symbol?
(raise-user-error msg v ...) -> any
  msg : string?
  v : any/c
(raise-user-error src format v ...) -> any
  src : symbol?
  format : string?
  v : any/c
procedure
(raise-argument-error name expected v) -> any
  name : symbol?
  expected : string?
  v : any/c
(raise-argument-error name         
                      expected     
                      bad-pos      
                      v ...)   -> any
  name : symbol?
  expected : string?
  bad-pos : exact-nonnegative-integer?
  v : any/c
procedure
(raise-result-error name expected v) -> any
  name : symbol?
  expected : string?
  v : any/c
(raise-result-error name         
                    expected     
                    bad-pos      
                    v ...)   -> any
  name : symbol?
  expected : string?
  bad-pos : exact-nonnegative-integer?
  v : any/c
procedure
(raise-arguments-error name        
                       message     
                       field       
                       v ...       
                       ...)    -> any
  name : symbol?
  message : string?
  field : string?
  v : any/c
procedure
(raise-range-error name                 
                   type-description     
                   index-prefix         
                   index                
                   in-value             
                   lower-bound          
                   upper-bound          
                   alt-lower-bound) -> any
  name : symbol?
  type-description : string?
  index-prefix : string?
  index : exact-integer?
  in-value : any/c
  lower-bound : exact-integer?
  upper-bound : exact-integer?
  alt-lower-bound : (or/c #f exact-integer?)
procedure
(raise-type-error name expected v) -> any
  name : symbol?
  expected : string?
  v : any/c
(raise-type-error name expected bad-pos v ...) -> any
  name : symbol?
  expected : string?
  bad-pos : exact-nonnegative-integer?
  v : any/c
procedure
(raise-mismatch-error name        
                      message     
                      v ...+      
                      ...+)   -> any
  name : symbol?
  message : string?
  v : any/c
procedure
(raise-arity-error name arity-v arg-v ...) -> any
  name : (or/c symbol? procedure?)
  arity-v : (or/c exact-nonnegative-integer?
                  arity-at-least?
                  (listof
                   (or/c exact-nonnegative-integer?
                         arity-at-least?)))
  arg-v : any/c
procedure
(raise-syntax-error  name                
                     message             
                    [expr                
                     sub-expr            
                     extra-sources]) -> any
  name : (or/c symbol? #f)
  message : string?
  expr : any/c = #f
  sub-expr : any/c = #f
  extra-sources : (listof syntax?) = null
procedure
(call-with-exception-handler f thunk) -> any
  f : (any/c . -> . any)
  thunk : (-> any)
parameter
(uncaught-exception-handler) -> (any/c . -> . any)
(uncaught-exception-handler f) -> void?
  f : (any/c . -> . any)
syntax
(with-handlers ([pred-expr handler-expr] ...)
  body ...+)
syntax
(with-handlers* ([pred-expr handler-expr] ...)
  body ...+)
parameter
(error-escape-handler) -> (-> any)
(error-escape-handler proc) -> void?
  proc : (-> any)
parameter
(error-display-handler) -> (string? any/c . -> . any)
(error-display-handler proc) -> void?
  proc : (string? any/c . -> . any)
parameter
(error-print-width) -> (and/c exact-integer? (>=/c 3))
(error-print-width width) -> void?
  width : (and/c exact-integer? (>=/c 3))
parameter
(error-print-context-length) -> exact-nonnegative-integer?
(error-print-context-length cnt) -> void?
  cnt : exact-nonnegative-integer?
parameter
(error-value->string-handler)
 -> (any/c exact-nonnegative-integer?
           . -> .
           string?)
(error-value->string-handler proc) -> void?
  proc : (any/c exact-nonnegative-integer?
                . -> .
                string?)
parameter
(error-print-source-location) -> boolean?
(error-print-source-location include?) -> void?
  include? : any/c
struct
(struct exn (message continuation-marks)
    #:extra-constructor-name make-exn
    #:transparent)
  message : string?
  continuation-marks : continuation-mark-set?
struct
(struct exn:fail exn ()
    #:extra-constructor-name make-exn:fail
    #:transparent)
struct
(struct exn:fail:contract exn:fail ()
    #:extra-constructor-name make-exn:fail:contract
    #:transparent)
struct
(struct exn:fail:contract:arity exn:fail:contract ()
    #:extra-constructor-name make-exn:fail:contract:arity
    #:transparent)
struct
(struct exn:fail:contract:divide-by-zero exn:fail:contract ()
    #:extra-constructor-name
    make-exn:fail:contract:divide-by-zero
    #:transparent)
struct
(struct exn:fail:contract:non-fixnum-result exn:fail:contract ()
    #:extra-constructor-name
    make-exn:fail:contract:non-fixnum-result
    #:transparent)
struct
(struct exn:fail:contract:continuation exn:fail:contract ()
    #:extra-constructor-name make-exn:fail:contract:continuation
    #:transparent)
struct
(struct exn:fail:contract:variable exn:fail:contract (id)
    #:extra-constructor-name make-exn:fail:contract:variable
    #:transparent)
  id : symbol?
struct
(struct exn:fail:syntax exn:fail (exprs)
    #:extra-constructor-name make-exn:fail:syntax
    #:transparent)
  exprs : (listof syntax?)
struct
(struct exn:fail:syntax:unbound exn:fail:syntax ()
    #:extra-constructor-name make-exn:fail:syntax:unbound
    #:transparent)
struct
(struct exn:fail:syntax:missing-module exn:fail:syntax (path)
    #:extra-constructor-name make-exn:fail:syntax:missing-module
    #:transparent)
  path : module-path?
struct
(struct exn:fail:read exn:fail (srclocs)
    #:extra-constructor-name make-exn:fail:read
    #:transparent)
  srclocs : (listof srcloc?)
struct
(struct exn:fail:read:eof exn:fail:read ()
    #:extra-constructor-name make-exn:fail:read:eof
    #:transparent)
struct
(struct exn:fail:read:non-char exn:fail:read ()
    #:extra-constructor-name make-exn:fail:read:non-char
    #:transparent)
struct
(struct exn:fail:filesystem exn:fail ()
    #:extra-constructor-name make-exn:fail:filesystem
    #:transparent)
struct
(struct exn:fail:filesystem:exists exn:fail:filesystem ()
    #:extra-constructor-name make-exn:fail:filesystem:exists
    #:transparent)
struct
(struct exn:fail:filesystem:version exn:fail:filesystem ()
    #:extra-constructor-name make-exn:fail:filesystem:version
    #:transparent)
struct
(struct exn:fail:filesystem:errno exn:fail:filesystem (errno)
    #:extra-constructor-name make-exn:fail:filesystem:errno
    #:transparent)
  errno : (cons/c exact-integer? (or/c 'posix 'windows 'gai))
struct
(struct exn:fail:filesystem:missing-module exn:fail:filesystem
        (path)
    #:extra-constructor-name
    make-exn:fail:filesystem:missing-module
    #:transparent)
  path : module-path?
struct
(struct exn:fail:network exn:fail ()
    #:extra-constructor-name make-exn:fail:network
    #:transparent)
struct
(struct exn:fail:network:errno exn:fail:network (errno)
    #:extra-constructor-name make-exn:fail:network:errno
    #:transparent)
  errno : (cons/c exact-integer? (or/c 'posix 'windows 'gai))
struct
(struct exn:fail:out-of-memory exn:fail ()
    #:extra-constructor-name make-exn:fail:out-of-memory
    #:transparent)
struct
(struct exn:fail:unsupported exn:fail ()
    #:extra-constructor-name make-exn:fail:unsupported
    #:transparent)
struct
(struct exn:fail:user exn:fail ()
    #:extra-constructor-name make-exn:fail:user
    #:transparent)
struct
(struct exn:break exn (continuation)
    #:extra-constructor-name make-exn:break
    #:transparent)
  continuation : continuation?
struct
(struct exn:break:hang-up exn:break ()
    #:extra-constructor-name make-exn:break:hang-up
    #:transparent)
struct
(struct exn:break:terminate exn:break ()
    #:extra-constructor-name make-exn:break:terminate
    #:transparent)
value
prop:exn:srclocs : struct-type-property?
procedure
(exn:srclocs? v) -> boolean?
  v : any/c
procedure
(exn:srclocs-accessor v)
 -> (exn:srclocs? . -> . (listof srcloc))
  v : exn:srclocs?
struct
(struct srcloc (source line column position span)
    #:extra-constructor-name make-srcloc
    #:transparent)
  source : any/c
  line : (or/c exact-positive-integer? #f)
  column : (or/c exact-nonnegative-integer? #f)
  position : (or/c exact-positive-integer? #f)
  span : (or/c exact-nonnegative-integer? #f)
procedure
(srcloc->string srcloc) -> (or/c string? #f)
  srcloc : srcloc?
value
prop:exn:missing-module : struct-type-property?
procedure
(exn:missing-module? v) -> boolean?
  v : any/c
procedure
(exn:missing-module-accessor v)
 -> (exn:missing-module? . -> . module-path?)
  v : exn:srclocs?
procedure
(promise? v) -> boolean?
  v : any/c
syntax
(delay body ...+)
syntax
(lazy body ...+)
procedure
(force v) -> any
  v : any/c
procedure
(promise-forced? promise) -> boolean?
  promise : promise?
procedure
(promise-running? promise) -> boolean?
  promise : promise?
syntax
(delay/name body ...+)
syntax
(delay/strict body ...+)
syntax
(delay/sync body ...+)
syntax
(delay/thread body/option ...+)
 
body/option = body
            | #:group thread-group-expr
syntax
(delay/idle body/option ...+)
 
body/option = body
            | #:wait-for wait-evt-expr
            | #:work-while while-evt-expr
            | #:tick tick-secs-expr
            | #:use use-ratio-expr
procedure
(call-with-continuation-prompt  proc           
                               [prompt-tag     
                                handler]       
                                arg ...)   -> any
  proc : procedure?
  prompt-tag : continuation-prompt-tag?
             = (default-continuation-prompt-tag)
  handler : (or/c procedure? #f) = #f
  arg : any/c
procedure
(abort-current-continuation prompt-tag     
                            v ...)     -> any
  prompt-tag : any/c
  v : any/c
procedure
(make-continuation-prompt-tag) -> continuation-prompt-tag?
(make-continuation-prompt-tag sym) -> continuation-prompt-tag?
  sym : symbol?
procedure
(default-continuation-prompt-tag) -> continuation-prompt-tag?
procedure
(call-with-current-continuation  proc             
                                [prompt-tag]) -> any
  proc : (continuation? . -> . any)
  prompt-tag : continuation-prompt-tag?
             = (default-continuation-prompt-tag)
procedure
(call/cc proc [prompt-tag]) -> any
  proc : (continuation? . -> . any)
  prompt-tag : continuation-prompt-tag?
             = (default-continuation-prompt-tag)
procedure
(call-with-composable-continuation  proc             
                                   [prompt-tag]) -> any
  proc : (continuation? . -> . any)
  prompt-tag : continuation-prompt-tag?
             = (default-continuation-prompt-tag)
procedure
(call-with-escape-continuation proc) -> any
  proc : (continuation? . -> . any)
procedure
(call/ec proc) -> any
  proc : (continuation? . -> . any)
syntax
(let/cc k body ...+)
syntax
(let/ec k body ...+)
procedure
(call-with-continuation-barrier thunk) -> any
  thunk : (-> any)
procedure
(continuation-prompt-available?  prompt-tag     
                                [cont])     -> any
  prompt-tag : continuation-prompt-tag?
  cont : continuation? = (call/cc values)
procedure
(continuation? v) -> boolean?
  v : any/c
procedure
(continuation-prompt-tag? v) -> boolean?
  v : any/c
procedure
(dynamic-wind pre-thunk       
              value-thunk     
              post-thunk) -> any
  pre-thunk : (-> any)
  value-thunk : (-> any)
  post-thunk : (-> any)
procedure
(call/prompt proc [prompt-tag handler] arg ...) -> any
  proc : procedure?
  prompt-tag : continuation-prompt-tag?
             = (default-continuation-prompt-tag)
  handler : (or/c procedure? #f) = #f
  arg : any/c
procedure
(abort/cc prompt-tag v ...) -> any
  prompt-tag : any/c
  v : any/c
procedure
(call/comp proc [prompt-tag]) -> any
  proc : (continuation? . -> . any)
  prompt-tag : continuation-prompt-tag?
             = (default-continuation-prompt-tag)
procedure
(abort v ...) -> any
  v : any/c
syntax
(% expr)
(% expr handler-expr)
(% expr handler-expr #:tag tag-expr)
procedure
(fcontrol v #:tag prompt-tag) -> any
  v : any/c
  prompt-tag : (default-continuation-prompt-tag)
syntax
(prompt expr ...+)
syntax
(control id expr ...+)
syntax
(prompt-at prompt-tag-expr expr ...+)
syntax
(control-at prompt-tag-expr id expr ...+)
syntax
(reset expr ...+)
syntax
(shift id expr ...+)
syntax
(reset-at prompt-tag-expr expr ...+)
syntax
(shift-at prompt-tag-expr identifier expr ...+)
syntax
(prompt0 expr ...+)
syntax
(reset0 expr ...+)
syntax
(control0 id expr ...+)
syntax
(shift0 id expr ...+)
syntax
(prompt0-at prompt-tag-expr expr ...+)
syntax
(reset0-at prompt-tag-expr expr ...+)
syntax
(control0-at prompt-tag-expr id expr ...+)
syntax
(shift0-at prompt-tag-expr id expr ...+)
procedure
(spawn proc) -> any
  proc : ((any/c . -> . any) . -> . any)
procedure
(splitter proc) -> any
  proc : (((-> any) . -> . any)
          ((continuation? . -> . any) . -> . any)
          . -> . any)
procedure
(new-prompt) -> any
syntax
(set prompt-expr expr ...+)
syntax
(cupto prompt-expr id expr ...+)
procedure
(continuation-marks cont [prompt-tag]) -> continuation-mark-set?
  cont : (or/c continuation? thread? #f)
  prompt-tag : continuation-prompt-tag?
             = (default-continuation-prompt-tag)
procedure
(current-continuation-marks [prompt-tag])
 -> continuation-mark-set?
  prompt-tag : continuation-prompt-tag?
             = (default-continuation-prompt-tag)
procedure
(continuation-mark-set->list  mark-set         
                              key-v            
                             [prompt-tag]) -> list?
  mark-set : continuation-mark-set?
  key-v : any/c
  prompt-tag : continuation-prompt-tag?
             = (default-continuation-prompt-tag)
procedure
(make-continuation-mark-key) -> continuation-mark-key?
(make-continuation-mark-key sym) -> continuation-mark-key?
  sym : symbol?
procedure
(continuation-mark-set->list*  mark-set         
                               key-list         
                              [none-v           
                               prompt-tag]) -> (listof vector?)
  mark-set : continuation-mark-set?
  key-list : (listof any/c)
  none-v : any/c = #f
  prompt-tag : continuation-prompt-tag?
             = (default-continuation-prompt-tag)
procedure
(continuation-mark-set-first  mark-set         
                              key-v            
                             [none-v           
                              prompt-tag]) -> any
  mark-set : (or/c continuation-mark-set? #f)
  key-v : any/c
  none-v : any/c = #f
  prompt-tag : continuation-prompt-tag?
             = (default-continuation-prompt-tag)
procedure
(call-with-immediate-continuation-mark  key-v           
                                        proc            
                                       [default-v]) -> any
  key-v : any/c
  proc : (any/c . -> . any)
  default-v : any/c = #f
procedure
(continuation-mark-key? v) -> boolean?
  v : any/c
procedure
(continuation-mark-set? v) -> boolean?
  v : any/c
procedure
(continuation-mark-set->context mark-set) -> list?
  mark-set : continuation-mark-set?
procedure
(break-enabled) -> boolean?
(break-enabled on?) -> void?
  on? : any/c
syntax
(parameterize-break boolean-expr body ...+)
procedure
(current-break-parameterization) -> break-parameterization?
procedure
(call-with-break-parameterization break-param     
                                  thunk)      -> any
  break-param : break-parameterization?
  thunk : (-> any)
procedure
(break-parameterization? v) -> boolean?
  v : any/c
procedure
(exit [v]) -> any
  v : any/c = #t
parameter
(exit-handler) -> (any/c . -> . any)
(exit-handler proc) -> void?
  proc : (any/c . -> . any)
parameter
(executable-yield-handler) -> (byte? . -> . any)
(executable-yield-handler proc) -> void?
  proc : (byte? . -> . any)
procedure
(thread thunk) -> thread?
  thunk : (-> any)
procedure
(thread? v) -> thread?
  v : any/c
procedure
(current-thread) -> thread?
procedure
(thread/suspend-to-kill thunk) -> thread?
  thunk : (-> any)
procedure
(call-in-nested-thread thunk [cust]) -> any
  thunk : (-> any)
  cust : custodian? = (current-custodian)
procedure
(thread-suspend thd) -> void?
  thd : thread?
procedure
(thread-resume thd [benefactor]) -> void?
  thd : thread?
  benefactor : (or/c thread? custodian? #f) = #f
procedure
(kill-thread thd) -> void?
  thd : thread?
procedure
(break-thread thd [kind]) -> void?
  thd : thread?
  kind : (or/c #f 'hang-up 'terminate) = #f
procedure
(sleep [secs]) -> void?
  secs : (>=/c 0) = 0
procedure
(thread-running? thd) -> any
  thd : thread?
procedure
(thread-dead? thd) -> any
  thd : thread?
procedure
(thread-wait thd) -> void?
  thd : thread?
procedure
(thread-dead-evt thd) -> evt?
  thd : thread?
procedure
(thread-resume-evt thd) -> evt?
  thd : thread?
procedure
(thread-suspend-evt thd) -> evt?
  thd : thread?
procedure
(thread-send thd v [fail-thunk]) -> any
  thd : thread?
  v : any/c
  fail-thunk : (or/c (-> any) #f)
             = (lambda () (raise-mismatch-error ....))
procedure
(thread-receive) -> any/c
procedure
(thread-try-receive) -> any/c
procedure
(thread-receive-evt) -> evt?
procedure
(thread-rewind-receive lst) -> void?
  lst : list?
procedure
(evt? v) -> boolean?
  v : any/c
procedure
(sync evt ...) -> any
  evt : evt?
procedure
(sync/timeout timeout evt ...) -> any
  timeout : (or/c #f (and/c real? (not/c negative?)) (-> any))
  evt : evt?
procedure
(sync/enable-break evt ...) -> any
  evt : evt?
procedure
(sync/timeout/enable-break timeout evt ...) -> any
  timeout : (or/c #f (and/c real? (not/c negative?)) (-> any))
  evt : evt?
procedure
(choice-evt evt ...) -> evt?
  evt : evt?
procedure
(wrap-evt evt wrap) -> evt?
  evt : evt?
  wrap : (any/c ... . -> . any)
procedure
(handle-evt evt handle) -> handle-evt?
  evt : evt?
  handle : (any/c ... . -> . any)
procedure
(guard-evt maker) -> evt?
  maker : (-> (or/c evt? any/c))
procedure
(nack-guard-evt maker) -> evt?
  maker : (evt? . -> . (or/c evt? any/c))
procedure
(poll-guard-evt maker) -> evt?
  maker : (boolean? . -> . (or/c evt? any/c))
procedure
(replace-evt evt maker) -> evt?
  evt : evt?
  maker : (any/c ... . -> . (or/c evt? any/c))
value
always-evt : evt?
value
never-evt : evt?
procedure
(system-idle-evt) -> evt?
procedure
(alarm-evt msecs) -> evt?
  msecs : real?
procedure
(handle-evt? evt) -> boolean?
  evt : evt?
value
prop:evt : struct-type-property?
parameter
(current-evt-pseudo-random-generator)
 -> pseudo-random-generator?
(current-evt-pseudo-random-generator generator) -> void?
  generator : pseudo-random-generator?
procedure
(channel? v) -> boolean?
  v : any/c
procedure
(make-channel) -> channel?
procedure
(channel-get ch) -> any
  ch : channel?
procedure
(channel-try-get ch) -> any
  ch : channel?
procedure
(channel-put ch v) -> void?
  ch : channel?
  v : any/c
procedure
(channel-put-evt ch v) -> channel-put-evt?
  ch : channel?
  v : any/c
procedure
(channel-put-evt? v) -> boolean?
  v : any/c
procedure
(semaphore? v) -> boolean?
  v : any/c
procedure
(make-semaphore [init]) -> semaphore?
  init : exact-nonnegative-integer? = 0
procedure
(semaphore-post sema) -> void?
  sema : semaphore?
procedure
(semaphore-wait sema) -> void?
  sema : semaphore?
procedure
(semaphore-try-wait? sema) -> boolean?
  sema : semaphore?
procedure
(semaphore-wait/enable-break sema) -> void?
  sema : semaphore?
procedure
(semaphore-peek-evt sema) -> semaphore-peek-evt?
  sema : semaphore?
procedure
(semaphore-peek-evt? v) -> boolean?
  v : any/c
procedure
(call-with-semaphore  sema                
                      proc                
                     [try-fail-thunk]     
                      arg ...)        -> any
  sema : semaphore?
  proc : procedure?
  try-fail-thunk : (or/c (-> any) #f) = #f
  arg : any/c
procedure
(call-with-semaphore/enable-break  sema                
                                   proc                
                                  [try-fail-thunk]     
                                   arg ...)        -> any
  sema : semaphore?
  proc : procedure?
  try-fail-thunk : (or/c (-> any) #f) = #f
  arg : any/c
procedure
(async-channel? v) -> boolean?
  v : any/c
procedure
(make-async-channel [limit]) -> async-channel?
  limit : (or/c exact-positive-integer? #f) = #f
procedure
(async-channel-get ach) -> any/c
  ach : async-channel?
procedure
(async-channel-try-get ach) -> any/c
  ach : async-channel?
procedure
(async-channel-put ach v) -> void?
  ach : async-channel?
  v : any/c
procedure
(async-channel-put-evt ach v) -> evt?
  ach : async-channel?
  v : any/c
procedure
(async-channel/c c) -> contract?
  c : contract?
procedure
(impersonate-async-channel channel      
                           get-proc     
                           put-proc     
                           prop         
                           prop-val ... 
                           ...)         
 -> (and/c async-channel? impersonator?)
  channel : async-channel?
  get-proc : (any/c . -> . any/c)
  put-proc : (any/c . -> . any/c)
  prop : impersonator-property?
  prop-val : any
procedure
(chaperone-async-channel channel      
                         get-proc     
                         put-proc     
                         prop         
                         prop-val ... 
                         ...)         
 -> (and/c async-channel? chaperone?)
  channel : async-channel?
  get-proc : (any/c . -> . any/c)
  put-proc : (any/c . -> . any/c)
  prop : impersonator-property?
  prop-val : any
procedure
(thread-cell? v) -> boolean?
  v : any/c
procedure
(make-thread-cell v [preserved?]) -> thread-cell?
  v : any/c
  preserved? : any/c = #f
procedure
(thread-cell-ref cell) -> any
  cell : thread-cell?
procedure
(thread-cell-set! cell v) -> any
  cell : thread-cell?
  v : any/c
procedure
(current-preserved-thread-cell-values) -> thread-cell-values?
(current-preserved-thread-cell-values thread-cell-vals) -> void?
  thread-cell-vals : thread-cell-values?
procedure
(thread-cell-values? v) -> boolean?
  v : any/c
procedure
(make-parameter v [guard]) -> parameter?
  v : any/c
  guard : (or/c (any/c . -> . any) #f) = #f
syntax
(parameterize ([parameter-expr value-expr] ...)
  body ...+)
 
  parameter-expr : parameter?
syntax
(parameterize* ((parameter-expr value-expr) ...)
  body ...+)
procedure
(make-derived-parameter parameter     
                        guard         
                        wrap)     -> parameter?
  parameter : parameter?
  guard : (any/c . -> . any)
  wrap : (any/c . -> . any)
procedure
(parameter? v) -> boolean?
  v : any/c
procedure
(parameter-procedure=? a b) -> boolean?
  a : parameter?
  b : parameter?
procedure
(current-parameterization) -> parameterization?
procedure
(call-with-parameterization parameterization     
                            thunk)           -> any
  parameterization : parameterization?
  thunk : (-> any)
procedure
(parameterization? v) -> boolean?
  v : any/c
procedure
(future thunk) -> future?
  thunk : (-> any)
procedure
(touch f) -> any
  f : future?
procedure
(futures-enabled?) -> boolean?
procedure
(current-future) -> (or/c #f future?)
procedure
(future? v) -> boolean?
  v : any/c
procedure
(would-be-future thunk) -> future?
  thunk : (-> any)
procedure
(processor-count) -> exact-positive-integer?
procedure
(make-fsemaphore init) -> fsemaphore?
  init : exact-nonnegative-integer?
procedure
(fsemaphore? v) -> boolean?
  v : any/c
procedure
(fsemaphore-post fsema) -> void?
  fsema : fsemaphore?
procedure
(fsemaphore-wait fsema) -> void?
  fsema : fsemaphore?
procedure
(fsemaphore-try-wait? fsema) -> boolean?
  fsema : fsemaphore?
procedure
(fsemaphore-count fsema) -> exact-nonnegative-integer?
  fsema : fsemaphore?
procedure
(place-enabled?) -> boolean?
procedure
(place? v) -> boolean?
  v : any/c
procedure
(place-channel? v) -> boolean?
  v : any/c
procedure
(dynamic-place  module-path         
                start-name          
               [#:at location       
                #:named named]) -> place?
  module-path : (or/c module-path? path?)
  start-name : symbol?
  location : (or/c #f place-location?) = #f
  named : any/c = #f
procedure
(dynamic-place*  module-path     
                 start-name      
                [#:in in         
                 #:out out       
                 #:err err]) -> place?
                                (or/c output-port? #f)
                                (or/c input-port? #f)
                                (or/c input-port? #f)
  module-path : (or/c module-path? path?)
  start-name : symbol?
  in : (or/c input-port? #f) = #f
  out : (or/c output-port? #f) = (current-output-port)
  err : (or/c output-port? #f) = (current-error-port)
syntax
(place id body ...+)
syntax
(place* maybe-port ...
        id
        body ...+)
 
maybe-port = 
           | #:in in-expr
           | #:out out-expr
           | #:err err-expr
procedure
(place-wait p) -> exact-integer?
  p : place?
procedure
(place-dead-evt p) -> evt?
  p : place?
procedure
(place-kill p) -> void?
  p : place?
procedure
(place-break p [kind]) -> void?
  p : place?
  kind : (or/c #f 'hang-up 'terminate) = #f
procedure
(place-channel) -> place-channel? place-channel?
procedure
(place-channel-put pch v) -> void
  pch : place-channel?
  v : place-message-allowed?
procedure
(place-channel-get pch) -> place-message-allowed?
  pch : place-channel?
procedure
(place-channel-put/get pch v) -> any/c
  pch : place-channel?
  v : any/c
procedure
(place-message-allowed? v) -> boolean?
  v : any/c
value
prop:place-location : struct-type-property?
procedure
(place-location? v) -> boolean?
  v : any/c
procedure
(engine proc) -> engine?
  proc : ((any/c . -> . void?) . -> . any/c)
procedure
(engine? v) -> any
  v : any/c
procedure
(engine-run until engine) -> boolean?
  until : (or/c evt? real?)
  engine : engine?
procedure
(engine-result engine) -> any
  engine : engine?
procedure
(engine-kill engine) -> void?
  engine : engine?
syntax
(syntax-case stx-expr (literal-id ...)
  clause ...)
 
      clause = [pattern result-expr]
             | [pattern fender-expr result-expr]
                
     pattern = _
             | id
             | (pattern ...)
             | (pattern ...+ . pattern)
             | (pattern ... pattern ellipsis pattern ...)
             | (pattern ... pattern ellipsis pattern ... . pattern)
             | #(pattern ...)
             | #(pattern ... pattern ellipsis pattern ...)
             | #&pattern
             | #s(key-datum pattern ...)
             | #s(key-datum pattern ... pattern ellipsis pattern ...)
             | (ellipsis stat-pattern)
             | const
                
stat-pattern = id
             | (stat-pattern ...)
             | (stat-pattern ...+ . stat-pattern)
             | #(stat-pattern ...)
             | const
                
    ellipsis = ...

_

id

(pattern ...)

(pattern ...+ . pattern)

(pattern ... pattern ellipsis pattern ...)

(pattern ... pattern ellipsis pattern ... . pattern)

#(pattern ...)

#(pattern ... pattern ellipsis pattern ...)

#&pattern

#s(key-datum pattern ...)

#s(key-datum pattern ... pattern ellipsis pattern ...)

(ellipsis stat-pattern)

const
syntax
(syntax-case* stx-expr (literal-id ...) id-compare-expr
  clause ...)
syntax
(with-syntax ([pattern stx-expr] ...)
  body ...+)
syntax
(syntax template)
 
     template = id
              | (template-elem ...)
              | (template-elem ...+ . template)
              | #(template-elem ...)
              | #&template
              | #s(key-datum template-elem ...)
              | (ellipsis stat-template)
              | const
                 
template-elem = template ellipsis ...
                 
stat-template = id
              | (stat-template ...)
              | (stat-template ... . stat-template)
              | #(stat-template ...)
              | #&stat-template
              | #s(key-datum stat-template ...)
              | const
                 
     ellipsis = ...

id

(template-elem ...)

(template-elem ... . template)

#(template-elem ...)

#&template

#s(key-datum template-elem ...)

(ellipsis stat-template)

const
syntax
(quasisyntax template)
syntax
(unsyntax expr)
syntax
(unsyntax-splicing expr)
syntax
(syntax/loc stx-expr template)
syntax
(quasisyntax/loc stx-expr template)
syntax
(quote-syntax/prune id)
syntax
(syntax-rules (literal-id ...)
  [(id . pattern) template] ...)
syntax
(syntax-id-rules (literal-id ...)
  [pattern template] ...)
syntax
(define-syntax-rule (id . pattern) template)
syntax
...
syntax
_
procedure
(syntax-pattern-variable? v) -> boolean?
  v : any/c
procedure
(syntax? v) -> boolean?
  v : any/c
procedure
(identifier? v) -> boolean?
  v : any/c
procedure
(syntax-source stx) -> any
  stx : syntax?
procedure
(syntax-line stx) -> (or/c exact-positive-integer? #f)
  stx : syntax?
procedure
(syntax-column stx) -> (or/c exact-nonnegative-integer? #f)
  stx : syntax?
procedure
(syntax-position stx) -> (or/c exact-positive-integer? #f)
  stx : syntax?
procedure
(syntax-span stx) -> (or/c exact-nonnegative-integer? #f)
  stx : syntax?
procedure
(syntax-original? stx) -> boolean?
  stx : syntax?
procedure
(syntax-source-module stx [source?])
 -> (or/c module-path-index? symbol? path? resolved-module-path? #f)
  stx : syntax?
  source? : any/c = #f
procedure
(syntax-e stx) -> any
  stx : syntax?
procedure
(syntax->list stx) -> (or/c list? #f)
  stx : syntax?
procedure
(syntax->datum stx) -> any
  stx : syntax?
procedure
(datum->syntax ctxt v [srcloc prop ignored]) -> syntax?
  ctxt : (or/c syntax? #f)
  v : any/c
  srcloc : (or/c syntax? #f
                 (list/c any/c
                         (or/c exact-positive-integer? #f)
                         (or/c exact-nonnegative-integer? #f)
                         (or/c exact-positive-integer? #f)
                         (or/c exact-nonnegative-integer? #f))
                 (vector/c any/c
                          (or/c exact-positive-integer? #f)
                          (or/c exact-nonnegative-integer? #f)
                          (or/c exact-positive-integer? #f)
                          (or/c exact-nonnegative-integer? #f)))
         = #f
  prop : (or/c syntax? #f) = #f
  ignored : (or/c syntax? #f) = #f
procedure
(datum-intern-literal v) -> any/c
  v : any/c
procedure
(syntax-shift-phase-level stx shift) -> syntax?
  stx : syntax?
  shift : (or/c exact-integer? #f)
procedure
(generate-temporaries stx-pair) -> (listof identifier?)
  stx-pair : (or syntax? list?)
procedure
(identifier-prune-lexical-context  id-stx     
                                  [syms]) -> identifier?
  id-stx : identifier?
  syms : (listof symbol?) = (list (syntax-e id-stx))
procedure
(identifier-prune-to-source-module id-stx) -> identifier?
  id-stx : identifier?
procedure
(syntax-recertify new-stx       
                  old-stx       
                  inspector     
                  key)      -> syntax?
  new-stx : syntax?
  old-stx : syntax?
  inspector : inspector?
  key : any/c
procedure
(bound-identifier=? a-id b-id [phase-level]) -> boolean?
  a-id : syntax?
  b-id : syntax?
  phase-level : (or/c exact-integer? #f)
              = (syntax-local-phase-level)
procedure
(free-identifier=?  a-id                
                    b-id                
                   [a-phase-level       
                    b-phase-level]) -> boolean?
  a-id : identifier?
  b-id : identifier?
  a-phase-level : (or/c exact-integer? #f)
                = (syntax-local-phase-level)
  b-phase-level : (or/c exact-integer? #f) = a-phase-level
procedure
(free-transformer-identifier=? a-id b-id) -> boolean?
  a-id : identifier?
  b-id : identifier?
procedure
(free-template-identifier=? a-id b-id) -> boolean?
  a-id : identifier?
  b-id : identifier?
procedure
(free-label-identifier=? a-id b-id) -> boolean?
  a-id : identifier?
  b-id : identifier?
procedure
(check-duplicate-identifier ids) -> (or/c identifier? #f)
  ids : (listof identifier?)
procedure
(identifier-binding id-stx [phase-level])
 -> (or/c 'lexical
          #f
          (listof module-path-index?
                  symbol?
                  module-path-index?
                  symbol?
                  exact-nonnegative-integer?
                  (or/c exact-integer? #f)
                  (or/c exact-integer? #f)))
  id-stx : identifier?
  phase-level : (or/c exact-integer? #f)
              = (syntax-local-phase-level)
procedure
(identifier-transformer-binding id-stx)
 -> (or/c 'lexical
          #f
          (listof module-path-index?
                  symbol?
                  module-path-index?
                  symbol?
                  exact-nonnegative-integer?
                  (or/c exact-integer? #f)
                  (or/c exact-integer? #f)))
  id-stx : identifier?
procedure
(identifier-template-binding id-stx)
 -> (or/c 'lexical
          #f
          (listof module-path-index?
                  symbol?
                  module-path-index?
                  symbol?
                  exact-nonnegative-integer?
                  (or/c exact-integer? #f)
                  (or/c exact-integer? #f)))
  id-stx : identifier?
procedure
(identifier-label-binding id-stx)
 -> (or/c 'lexical
          #f
          (listof module-path-index?
                  symbol?
                  module-path-index?
                  symbol?
                  exact-nonnegative-integer?
                  (or/c exact-integer? #f)
                  (or/c exact-integer? #f)))
  id-stx : identifier?
procedure
(identifier-binding-symbol  id-stx            
                           [phase-level]) -> symbol?
  id-stx : identifier?
  phase-level : (or/c exact-integer? #f)
              = (syntax-local-phase-level)
procedure
(set!-transformer? v) -> boolean?
  v : any/c
procedure
(make-set!-transformer proc) -> set!-transformer?
  proc : (syntax? . -> . syntax?)
procedure
(set!-transformer-procedure transformer)
 -> (syntax? . -> . syntax?)
  transformer : set!-transformer?
value
prop:set!-transformer : struct-type-property?
procedure
(rename-transformer? v) -> boolean?
  v : any/c
procedure
(make-rename-transformer  id-stx                
                         [delta-introduce]) -> rename-transformer?
  id-stx : syntax?
  delta-introduce : (identifier? . -> . identifier?)
                  = (lambda (id) id)
procedure
(rename-transformer-target transformer) -> identifier?
  transformer : rename-transformer?
value
prop:rename-transformer : struct-type-property?
procedure
(local-expand  stx              
               context-v        
               stop-ids         
              [intdef-ctx]) -> syntax?
  stx : syntax?
  context-v : (or/c 'expression 'top-level 'module 'module-begin list?)
  stop-ids : (or/c (listof identifier?) #f)
  intdef-ctx : (or/c internal-definition-context?
                     (and/c pair?
                            (listof internal-definition-context?))
                     #f)
             = #f
procedure
(syntax-local-expand-expression stx) -> syntax? syntax?
  stx : syntax?
procedure
(local-transformer-expand  stx              
                           context-v        
                           stop-ids         
                          [intdef-ctx]) -> syntax?
  stx : syntax?
  context-v : (or/c 'expression 'top-level list?)
  stop-ids : (or/c (listof identifier?) #f)
  intdef-ctx : (or/c internal-definition-context? #f) = #f
procedure
(local-expand/capture-lifts  stx            
                             context-v      
                             stop-ids       
                            [intdef-ctx     
                             lift-ctx]) -> syntax?
  stx : syntax?
  context-v : (or/c 'expression 'top-level 'module 'module-begin list?)
  stop-ids : (or/c (listof identifier?) #f)
  intdef-ctx : (or/c internal-definition-context? #f) = #f
  lift-ctx : any/c = (gensym 'lifts)
procedure
(local-transformer-expand/capture-lifts  stx            
                                         context-v      
                                         stop-ids       
                                        [intdef-ctx     
                                         lift-ctx]) -> syntax?
  stx : syntax?
  context-v : (or/c 'expression 'top-level list?)
  stop-ids : (or/c (listof identifier?) #f)
  intdef-ctx : (or/c internal-definition-context? #f) = #f
  lift-ctx : any/c = (gensym 'lifts)
procedure
(internal-definition-context? v) -> boolean?
  v : any/c
procedure
(syntax-local-make-definition-context [intdef-ctx])
 -> internal-definition-context?
  intdef-ctx : (or/c internal-definition-context? #f) = #f
procedure
(syntax-local-bind-syntaxes id-list         
                            expr            
                            intdef-ctx) -> void?
  id-list : (listof identifier?)
  expr : (or/c syntax? #f)
  intdef-ctx : internal-definition-context?
procedure
(internal-definition-context-seal intdef-ctx) -> void?
  intdef-ctx : internal-definition-context?
procedure
(identifier-remove-from-definition-context id-stx      
                                           intdef-ctx) 
 -> identifier?
  id-stx : identifier?
  intdef-ctx : (or/c internal-definition-context?
                     (listof internal-definition-context?))
procedure
(syntax-local-value  id-stx            
                    [failure-thunk     
                     intdef-ctx])  -> any
  id-stx : syntax?
  failure-thunk : (or/c (-> any) #f) = #f
  intdef-ctx : (or/c internal-definition-context? = #f
                     #f)
procedure
(syntax-local-value/immediate  id-stx            
                              [failure-thunk     
                               intdef-ctx])  -> any
  id-stx : syntax?
  failure-thunk : (or/c (-> any) #f) = #f
  intdef-ctx : (or/c internal-definition-context? = #f
                     #f)
procedure
(syntax-local-lift-expression stx) -> identifier?
  stx : syntax?
procedure
(syntax-local-lift-values-expression n stx)
 -> (listof identifier?)
  n : exact-nonnegative-integer?
  stx : syntax?
procedure
(syntax-local-lift-context) -> any/c
procedure
(syntax-local-lift-module-end-declaration stx) -> void?
  stx : syntax?
procedure
(syntax-local-lift-require raw-require-spec     
                           stx)             -> syntax?
  raw-require-spec : any/c
  stx : syntax?
procedure
(syntax-local-lift-provide raw-provide-spec-stx) -> void?
  raw-provide-spec-stx : syntax?
procedure
(syntax-local-name) -> any/c
procedure
(syntax-local-context)
 -> (or/c 'expression 'top-level 'module 'module-begin list?)
procedure
(syntax-local-phase-level) -> exact-integer?
procedure
(syntax-local-module-exports mod-path)
 -> (listof (cons/c (or/c exact-integer? #f) (listof symbol?)))
  mod-path : (or/c module-path?
                   (and/c syntax?
                          (lambda (stx)
                            (module-path? (syntax->datum stx)))))
procedure
(syntax-local-submodules) -> (listof symbol?)
procedure
(syntax-local-get-shadower id-stx) -> identifier?
  id-stx : identifier?
procedure
(syntax-local-certifier [active?])
 -> ((syntax?) (any/c (or/c procedure? #f))
     . ->* . syntax?)
  active? : boolean? = #f
procedure
(syntax-transforming?) -> boolean?
procedure
(syntax-transforming-module-expression?) -> boolean?
procedure
(syntax-local-introduce stx) -> syntax?
  stx : syntax?
procedure
(make-syntax-introducer) -> (syntax? . -> . syntax?)
procedure
(make-syntax-delta-introducer  ext-stx       
                               base-stx      
                              [phase-level]) 
 -> (syntax? . -> . syntax?)
  ext-stx : syntax?
  base-stx : (or/c syntax? #f)
  phase-level : (or/c #f exact-integer?)
              = (syntax-local-phase-level)
procedure
(syntax-local-make-delta-introducer id)
 -> (identifier? . -> . identifier?)
  id : identifier?
procedure
(syntax-local-transforming-module-provides?) -> boolean?
procedure
(syntax-local-module-defined-identifiers)
 -> (and/c hash? immutable?)
procedure
(syntax-local-module-required-identifiers mod-path     
                                          phase-level) 
 -> (listof (cons/c (or/c exact-integer? #f)
                    (listof identifier?)))
  mod-path : (or/c module-path? #f)
  phase-level : (or/c exact-integer? #f #t)
value
prop:liberal-define-context : struct-type-property?
procedure
(liberal-define-context? v) -> boolean?
  v : any/c
procedure
(expand-import stx) -> (listof import?) (listof import-source?)
  stx : syntax?
procedure
(make-require-transformer proc) -> require-transformer?
  proc : (syntax? . -> . (values
                          (listof import?)
                          (listof import-source?)))
value
prop:require-transformer : struct-type-property?
procedure
(require-transformer? v) -> boolean?
  v : any/c
struct
(struct import (local-id
                src-sym
                src-mod-path
                mode
                req-mode
                orig-mode
                orig-stx)
    #:extra-constructor-name make-import)
  local-id : identifier?
  src-sym : symbol?
  src-mod-path : (or/c module-path?
                       (and/c syntax?
                              (lambda (stx)
                                (module-path? (syntax->datum stx)))))
  mode : (or/c exact-integer? #f)
  req-mode : (or/c exact-integer? #f)
  orig-mode : (or/c exact-integer? #f)
  orig-stx : syntax?
struct
(struct import-source (mod-path-stx mode)
    #:extra-constructor-name make-import-source)
  mod-path-stx : (and/c syntax?
                        (lambda (x)
                          (module-path? (syntax->datum x))))
  mode : (or/c exact-integer? #f)
parameter
(current-require-module-path) -> (or/c #f module-path-index?)
(current-require-module-path module-path) -> void?
  module-path : (or/c #f module-path-index?)
procedure
(convert-relative-module-path module-path)
 -> (or/c module-path?
          (and/c syntax?
                 (lambda (stx)
                   (module-path? (syntax-e stx)))))
  module-path : (or/c module-path?
                      (and/c syntax?
                             (lambda (stx)
                               (module-path? (syntax-e stx)))))
procedure
(syntax-local-require-certifier)
 -> ((syntax?) (or/c #f (syntax? . -> . syntax?))
     . ->* . syntax?)
procedure
(expand-export stx modes) -> (listof export?)
  stx : syntax?
  modes : (listof (or/c exact-integer? #f))
procedure
(pre-expand-export stx modes) -> syntax?
  stx : syntax?
  modes : (listof (or/c exact-integer? #f))
procedure
(make-provide-transformer proc) -> provide-transformer?
  proc : (syntax? (listof (or/c exact-integer? #f))
          . -> . (listof export?))
(make-provide-transformer proc pre-proc)
 -> (and/c provide-transformer? provide-pre-transformer?)
  proc : (syntax? (listof (or/c exact-integer? #f))
          . -> . (listof export?))
  pre-proc : (syntax? (listof (or/c exact-integer? #f))
              . -> . syntax?)
procedure
(make-provide-pre-transformer pre-proc)
 -> provide-pre-transformer?
  pre-proc : (syntax? (listof (or/c exact-integer? #f))
              . -> . syntax?)
value
prop:provide-transformer : struct-type-property?
value
prop:provide-pre-transformer : struct-type-property?
procedure
(provide-transformer? v) -> boolean?
  v : any/c
procedure
(provide-pre-transformer? v) -> boolean?
  v : any/c
struct
(struct export (local-id out-sym mode protect? orig-stx)
    #:extra-constructor-name make-export)
  local-id : identifier?
  out-sym : symbol?
  mode : (or/c exact-integer? #f)
  protect? : any/c
  orig-stx : syntax?
procedure
(syntax-local-provide-certifier)
 -> ((syntax?) (or/c #f (syntax? . -> . syntax?))
     . ->* . syntax?)
procedure
(syntax-procedure-alias-property stx)
 -> (or/c #f
          (letrec ([val? (recursive-contract
                          (or/c (cons/c identifier? identifier?)
                                (cons/c val? val?)))])
            val?))
  stx : syntax?
procedure
(syntax-procedure-converted-arguments-property stx)
 -> (or/c #f
          (letrec ([val? (recursive-contract
                          (or/c (cons/c identifier? identifier?)
                                (cons/c val? val?)))])
            val?))
  stx : syntax?
syntax
(define-syntax-parameter id expr)
syntax
(syntax-parameterize ([id expr] ...) body-expr ...+)
procedure
(syntax-parameter-value id-stx) -> any
  id-stx : syntax?
procedure
(make-parameter-rename-transformer id-stx) -> any
  id-stx : syntax?
syntax
splicing-let
syntax
splicing-letrec
syntax
splicing-let-values
syntax
splicing-letrec-values
syntax
splicing-let-syntax
syntax
splicing-letrec-syntax
syntax
splicing-let-syntaxes
syntax
splicing-letrec-syntaxes
syntax
splicing-letrec-syntaxes+values
syntax
splicing-local
syntax
splicing-syntax-parameterize
procedure
(syntax-property stx key v) -> syntax?
  stx : syntax?
  key : any/c
  v : any/c
(syntax-property stx key) -> any
  stx : syntax?
  key : any/c
procedure
(syntax-property-symbol-keys stx) -> list?
  stx : syntax?
procedure
(syntax-track-origin new-stx      
                     orig-stx     
                     id-stx)  -> any
  new-stx : syntax?
  orig-stx : syntax?
  id-stx : syntax?
procedure
(syntax-tainted? stx) -> boolean?
  stx : syntax?
procedure
(syntax-arm stx [inspector use-mode?]) -> syntax?
  stx : syntax?
  inspector : (or/c inspector? #f) = #f
  use-mode? : any/c = #f
procedure
(syntax-protect stx) -> syntax?
  stx : syntax?
procedure
(syntax-disarm stx inspector) -> syntax?
  stx : syntax?
  inspector : (or/c inspector? #f)
procedure
(syntax-rearm stx from-stx [use-mode?]) -> syntax?
  stx : syntax?
  from-stx : syntax?
  use-mode? : any/c = #f
procedure
(syntax-taint stx) -> syntax?
  stx : syntax?
procedure
(expand top-level-form) -> syntax?
  top-level-form : any/c
procedure
(expand-syntax stx) -> syntax?
  stx : syntax?
procedure
(expand-once top-level-form) -> syntax?
  top-level-form : any/c
procedure
(expand-syntax-once stx) -> syntax?
  stx : syntax?
procedure
(expand-to-top-form top-level-form) -> syntax?
  top-level-form : any/c
procedure
(expand-syntax-to-top-form stx) -> syntax?
  stx : syntax?
syntax
(include path-spec)
 
path-spec = string
          | (file string)
          | (lib string ...+)
syntax
(include-at/relative-to context source path-spec)
syntax
(include/reader path-spec reader-expr)
syntax
(include-at/relative-to/reader context source path-spec reader-expr)
procedure
(format-id  lctx                 
            fmt                  
            v ...                
           [#:source src         
            #:props props        
            #:cert ignored]) -> identifier?
  lctx : (or/c syntax? #f)
  fmt : string?
  v : (or/c string? symbol? identifier? keyword? char? number?)
  src : (or/c syntax? #f) = #f
  props : (or/c syntax? #f) = #f
  ignored : (or/c syntax? #f) = #f
procedure
(format-symbol fmt v ...) -> symbol?
  fmt : string?
  v : (or/c string? symbol? identifier? keyword? char? number?)
syntax
(define/with-syntax pattern stx-expr)
 
  stx-expr : syntax?
parameter
(current-syntax-context) -> (or/c syntax? false/c)
(current-syntax-context stx) -> void?
  stx : (or/c syntax? false/c)
procedure
(wrong-syntax stx format-string v ...) -> any
  stx : syntax?
  format-string : string?
  v : any/c
parameter
(current-recorded-disappeared-uses)
 -> (or/c (listof identifier?) false/c)
(current-recorded-disappeared-uses ids) -> void?
  ids : (or/c (listof identifier?) false/c)
syntax
(with-disappeared-uses stx-expr)
 
  stx-expr : syntax?
procedure
(syntax-local-value/record id predicate) -> any/c
  id : identifier?
  predicate : (-> any/c boolean?)
procedure
(record-disappeared-uses ids) -> void?
  ids : (listof identifier?)
procedure
(generate-temporary [name-base]) -> identifier?
  name-base : any/c = 'g
procedure
(internal-definition-context-apply intdef-ctx     
                                   stx)       -> syntax?
  intdef-ctx : internal-definition-context?
  stx : syntax?
procedure
(syntax-local-eval stx [intdef-ctx]) -> any
  stx : syntax?
  intdef-ctx : (or/c internal-definition-context? #f) = #f
syntax
(with-syntax* ([pattern stx-expr] ...)
  body ...+)
 
  stx-expr : syntax?
parameter
(current-locale) -> (or/c string? #f)
(current-locale locale) -> void?
  locale : (or/c string? #f)
procedure
(input-port? v) -> boolean?
  v : any/c
procedure
(output-port? v) -> boolean?
  v : any/c
procedure
(port? v) -> boolean?
  v : any/c
procedure
(close-input-port in) -> void?
  in : input-port?
procedure
(close-output-port out) -> void?
  out : output-port?
procedure
(port-closed? port) -> boolean?
  port : port?
procedure
(port-closed-evt port) -> evt?
  port : port?
parameter
(current-input-port) -> input-port?
(current-input-port in) -> void?
  in : input-port?
parameter
(current-output-port) -> output-port?
(current-output-port out) -> void?
  out : output-port?
parameter
(current-error-port) -> output-port?
(current-error-port out) -> void?
  out : output-port?
procedure
(file-stream-port? port) -> boolean?
  port : port?
procedure
(terminal-port? port) -> boolean?
  port : port?
value
eof : eof-object?
procedure
(eof-object? a) -> boolean?
  a : any/c
procedure
(flush-output [out]) -> void?
  out : output-port? = (current-output-port)
procedure
(file-stream-buffer-mode port) -> (or/c 'none 'line 'block #f)
  port : port?
(file-stream-buffer-mode port mode) -> void?
  port : port?
  mode : (or/c 'none 'line 'block)
procedure
(file-position port) -> exact-nonnegative-integer?
  port : port?
(file-position port pos) -> void?
  port : port?
  pos : (or/c exact-nonnegative-integer? eof-object?)
procedure
(file-position* port) -> (or/c exact-nonnegative-integer? #f)
  port : port?
procedure
(file-truncate port size) -> void?
  port : (and/c output-port? file-stream-port?)
  size : exact-nonnegative-integer?
procedure
(port-count-lines! port) -> void?
  port : port?
procedure
(port-counts-lines? port) -> boolean?
  port : port?
procedure
(port-next-location port)
 -> (or/c exact-positive-integer? #f)
    (or/c exact-nonnegative-integer? #f)
    (or/c exact-positive-integer? #f)
  port : port?
procedure
(set-port-next-location! port          
                         line          
                         column        
                         position) -> void?
  port : port?
  line : (or/c exact-positive-integer? #f)
  column : (or/c exact-nonnegative-integer? #f)
  position : (or/c exact-positive-integer? #f)
parameter
(port-count-lines-enabled) -> boolean?
(port-count-lines-enabled on?) -> void?
  on? : any/c
procedure
(open-input-file  path                            
                 [#:mode mode-flag                
                  #:for-module? for-module?]) -> input-port?
  path : path-string?
  mode-flag : (or/c 'binary 'text) = 'binary
  for-module? : any/c = #f
procedure
(open-output-file  path                       
                  [#:mode mode-flag           
                   #:exists exists-flag]) -> output-port?
  path : path-string?
  mode-flag : (or/c 'binary 'text) = 'binary
  exists-flag : (or/c 'error 'append 'update 'can-update
                      'replace 'truncate
                      'must-truncate 'truncate/replace)
              = 'error
procedure
(open-input-output-file  path                   
                        [#:mode mode-flag       
                         #:exists exists-flag]) 
 -> input-port? output-port?
  path : path-string?
  mode-flag : (or/c 'binary 'text) = 'binary
  exists-flag : (or/c 'error 'append 'update 'can-update
                      'replace 'truncate 'truncate/replace)
              = 'error
procedure
(call-with-input-file  path                   
                       proc                   
                      [#:mode mode-flag]) -> any
  path : path-string?
  proc : (input-port? . -> . any)
  mode-flag : (or/c 'binary 'text) = 'binary
procedure
(call-with-output-file  path                       
                        proc                       
                       [#:mode mode-flag           
                        #:exists exists-flag]) -> any
  path : path-string?
  proc : (output-port? . -> . any)
  mode-flag : (or/c 'binary 'text) = 'binary
  exists-flag : (or/c 'error 'append 'update
                      'replace 'truncate 'truncate/replace)
              = 'error
procedure
(call-with-input-file*  path                   
                        proc                   
                       [#:mode mode-flag]) -> any
  path : path-string?
  proc : (input-port? . -> . any)
  mode-flag : (or/c 'binary 'text) = 'binary
procedure
(call-with-output-file*  path                       
                         proc                       
                        [#:mode mode-flag           
                         #:exists exists-flag]) -> any
  path : path-string?
  proc : (output-port? . -> . any)
  mode-flag : (or/c 'binary 'text) = 'binary
  exists-flag : (or/c 'error 'append 'update
                      'replace 'truncate 'truncate/replace)
              = 'error
procedure
(with-input-from-file  path                   
                       thunk                  
                      [#:mode mode-flag]) -> any
  path : path-string?
  thunk : (-> any)
  mode-flag : (or/c 'binary 'text) = 'binary
procedure
(with-output-to-file  path                       
                      thunk                      
                     [#:mode mode-flag           
                      #:exists exists-flag]) -> any
  path : path-string?
  thunk : (-> any)
  mode-flag : (or/c 'binary 'text) = 'binary
  exists-flag : (or/c 'error 'append 'update
                      'replace 'truncate 'truncate/replace)
              = 'error
procedure
(port-try-file-lock? port mode) -> boolean?
  port : file-stream-port?
  mode : (or/c 'shared 'exclusive)
procedure
(port-file-unlock port) -> void?
  port : file-stream-port?
procedure
(port-file-identity port) -> exact-positive-integer?
  port : file-stream-port?
procedure
(string-port? p) -> boolean?
  p : port?
procedure
(open-input-bytes bstr [name]) -> (and/c input-port? string-port?)
  bstr : bytes?
  name : any/c = 'string
procedure
(open-input-string str [name]) -> (and/c input-port? string-port?)
  str : string?
  name : any/c = 'string
procedure
(open-output-bytes [name]) -> (and/c output-port? string-port?)
  name : any/c = 'string
procedure
(open-output-string [name]) -> (and/c output-port? string-port?)
  name : any/c = 'string
procedure
(get-output-bytes  out           
                  [reset?        
                   start-pos     
                   end-pos]) -> bytes?
  out : (and/c output-port? string-port?)
  reset? : any/c = #f
  start-pos : exact-nonnegative-integer? = 0
  end-pos : exact-nonnegative-integer? = #f
procedure
(get-output-string out) -> string?
  out : (and/c output-port? string-port?)
procedure
(make-pipe [limit input-name output-name])
 -> input-port? output-port?
  limit : exact-positive-integer? = #f
  input-name : any/c = 'pipe
  output-name : any/c = 'pipe
procedure
(pipe-content-length pipe-port) -> exact-nonnegative-integer?
  pipe-port : port?
value
prop:input-port : struct-type-property?
value
prop:output-port : struct-type-property?
procedure
(make-input-port  name                 
                  read-in              
                  peek                 
                  close                
                 [get-progress-evt     
                  commit               
                  get-location         
                  count-lines!         
                  init-position        
                  buffer-mode])    -> input-port?
  name : any/c
  read-in : (or/c
             (bytes?
              . -> . (or/c exact-nonnegative-integer?
                           eof-object?
                           procedure?
                           evt?))
             input-port?)
  peek : (or/c
          (bytes? exact-nonnegative-integer? (or/c evt? #f)
                  . -> . (or/c exact-nonnegative-integer?
                               eof-object?
                               procedure?
                               evt?
                               #f))
          input-port?)
  close : (-> any)
  get-progress-evt : (or/c (-> evt?) #f) = #f
  commit : (or/c (exact-positive-integer? evt? evt? . -> . any)
                 #f)
         = #f
  get-location : (or/c
                  (->
                   (values (or/c exact-positive-integer? #f)
                           (or/c exact-nonnegative-integer? #f)
                           (or/c exact-positive-integer? #f)))
                  #f)
               = #f
  count-lines! : (-> any) = void
  init-position : (or/c exact-positive-integer?
                        port?
                        #f
                        (-> (or/c exact-positive-integer? #f)))
                = 1
  buffer-mode : (or/c (case-> ((or/c 'block 'none) . -> . any)
                              (-> (or/c 'block 'none #f)))
                      #f)
              = #f
procedure
(make-output-port  name                      
                   evt                       
                   write-out                 
                   close                     
                  [write-out-special         
                   get-write-evt             
                   get-write-special-evt     
                   get-location              
                   count-lines!              
                   init-position             
                   buffer-mode])         -> output-port?
  name : any/c
  evt : evt?
  write-out : (or/c
               (bytes? exact-nonnegative-integer?
                       exact-nonnegative-integer?
                       boolean?
                       boolean?
                       . -> .
                       (or/c exact-nonnegative-integer?
                             #f
                             evt?))
               output-port?)
  close : (-> any)
  write-out-special : (or/c (any/c boolean? boolean? = #f
                                   . -> .
                                   (or/c any/c
                                         #f
                                         evt?))
                            output-port?
                            #f)
  get-write-evt : (or/c                               = #f
                   (bytes? exact-nonnegative-integer?
                           exact-nonnegative-integer?
                           . -> .
                           evt?)
                   #f)
  get-write-special-evt : (or/c                = #f
                           (any/c . -> . evt?)
                           #f)
  get-location : (or/c
                  (->
                   (values (or/c exact-positive-integer? #f)
                           (or/c exact-nonnegative-integer? #f)
                           (or/c exact-positive-integer? #f)))
                  #f)
               = #f
  count-lines! : (-> any) = void
  init-position : (or/c exact-positive-integer?
                        port?
                        #f
                        (-> (or/c exact-positive-integer? #f)))
                = 1
  buffer-mode : (or/c (case->
                       ((or/c 'block 'line 'none) . -> . any)
                       (-> (or/c 'block 'line 'none #f)))
                      #f)
              = #f
procedure
(port->list [r in]) -> (listof any/c)
  r : (input-port? . -> . any/c) = read
  in : input-port? = (current-input-port)
procedure
(port->string [in]) -> string?
  in : input-port? = (current-input-port)
procedure
(port->bytes [in]) -> bytes?
  in : input-port? = (current-input-port)
procedure
(port->lines [in #:line-mode line-mode]) -> (listof string?)
  in : input-port? = (current-input-port)
  line-mode : (or/c 'linefeed 'return 'return-linefeed 'any 'any-one)
            = 'any
procedure
(port->bytes-lines [in                          
                    #:line-mode line-mode]) -> (listof bytes?)
  in : input-port? = (current-input-port)
  line-mode : (or/c 'linefeed 'return 'return-linefeed 'any 'any-one)
            = 'any
procedure
(display-lines  lst                         
               [out                         
                #:separator separator]) -> void?
  lst : list?
  out : output-port? = (current-output-port)
  separator : any/c = #"\n"
procedure
(call-with-output-string proc) -> string?
  proc : (output-port? . -> . any)
procedure
(call-with-output-bytes proc) -> bytes?
  proc : (output-port? . -> . any)
procedure
(with-output-to-string proc) -> string?
  proc : (-> any)
procedure
(with-output-to-bytes proc) -> bytes?
  proc : (-> any)
procedure
(call-with-input-string str proc) -> any
  str : string?
  proc : (input-port? . -> . any)
procedure
(call-with-input-bytes bstr proc) -> any
  bstr : bytes?
  proc : (input-port? . -> . any)
procedure
(with-input-from-string str proc) -> any
  str : string?
  proc : (-> any)
procedure
(with-input-from-bytes bstr proc) -> any
  bstr : bytes?
  proc : (-> any)
procedure
(input-port-append close-at-eof? in ...) -> input-port?
  close-at-eof? : any/c
  in : input-port?
procedure
(make-input-port/read-to-peek  name              
                               read-in           
                               fast-peek         
                               close             
                              [get-location      
                               count-lines!      
                               init-position     
                               buffer-mode       
                               buffering?        
                               on-consumed]) -> input-port?
  name : any/c
  read-in : (bytes?
             . -> . (or/c exact-nonnegative-integer?
                          eof-object?
                          procedure?
                          evt?))
  fast-peek : (or/c #f
                    (bytes? exact-nonnegative-integer?
                     (bytes? exact-nonnegative-integer?
                      . -> . (or/c exact-nonnegative-integer?
                                   eof-object?
                                   procedure?
                                   evt?
                                   #f))
                     . -> . (or/c exact-nonnegative-integer?
                                  eof-object?
                                  procedure?
                                  evt?
                                  #f)))
  close : (-> any)
  get-location : (or/c                                   = #f
                  (->
                   (values
                    (or/c exact-positive-integer? #f)
                    (or/c exact-nonnegative-integer? #f)
                    (or/c exact-positive-integer? #f)))
                  #f)
  count-lines! : (-> any) = void
  init-position : exact-positive-integer? = 1
  buffer-mode : (or/c (case-> ((or/c 'block 'none) . -> . any)
                              (-> (or/c 'block 'none #f)))
                      #f)
              = #f
  buffering? : any/c = #f
  on-consumed : (or/c ((or/c exact-nonnegative-integer? eof-object?
                             procedure? evt?)
                       . -> . any)
                      #f)
              = #f
procedure
(make-limited-input-port  in                
                          limit             
                         [close-orig?]) -> input-port?
  in : input-port?
  limit : exact-nonnegative-integer?
  close-orig? : any/c = #t
procedure
(make-pipe-with-specials [limit          
                          in-name        
                          out-name]) -> input-port? output-port?
  limit : exact-nonnegative-integer? = #f
  in-name : any/c = 'pipe
  out-name : any/c = 'pipe
procedure
(merge-input a-in b-in [buffer-limit]) -> input-port?
  a-in : input-port?
  b-in : input-port?
  buffer-limit : (or/c exact-nonnegative-integer? #f) = 4096
procedure
(open-output-nowhere [name special-ok?]) -> output-port?
  name : any/c = 'nowhere
  special-ok? : any/c = #t
procedure
(peeking-input-port  in                                  
                    [name                                
                     skip                                
                     #:init-position init-position]) -> input-port
  in : input-port?
  name : any/c = (object-name in)
  skip : exact-nonnegative-integer? = 0
  init-position : exact-positive-integer? = 1
procedure
(reencode-input-port  in                    
                      encoding              
                     [error-bytes           
                      close?                
                      name                  
                      convert-newlines?     
                      enc-error])       -> input-port?
  in : input-port?
  encoding : string?
  error-bytes : (or/c #f bytes?) = #f
  close? : any/c = #f
  name : any/c = (object-name in)
  convert-newlines? : any/c = #f
  enc-error : (string? input-port? . -> . any)
            = (lambda (msg port) (error ...))
procedure
(reencode-output-port  out               
                       encoding          
                      [error-bytes       
                       close?            
                       name              
                       newline-bytes     
                       enc-error])   -> output-port?
  out : output-port?
  encoding : string?
  error-bytes : (or/c #f bytes?) = #f
  close? : any/c = #f
  name : any/c = (object-name out)
  newline-bytes : (or/c #f bytes?) = #f
  enc-error : (string? output-port? . -> . any)
            = (lambda (msg port) (error ...))
procedure
(dup-input-port in [close?]) -> input-port?
  in : input-port?
  close? : any/c = #f
procedure
(dup-output-port out [close?]) -> output-port?
  out : output-port?
  close? : any/c = #f
procedure
(relocate-input-port  in               
                      line             
                      column           
                      position         
                     [close?]          
                      #:name name) -> input-port?
  in : input-port?
  line : (or/c exact-positive-integer? #f)
  column : (or/c exact-nonnegative-integer? #f)
  position : exact-positive-integer?
  close? : any/c = #t
  name : (object-name out)
procedure
(relocate-output-port  out              
                       line             
                       column           
                       position         
                      [close?]          
                       #:name name) -> output-port?
  out : output-port?
  line : (or/c exact-positive-integer? #f)
  column : (or/c exact-nonnegative-integer? #f)
  position : exact-positive-integer?
  close? : any/c = #t
  name : (object-name out)
procedure
(transplant-input-port  in                
                        get-location      
                        init-pos          
                       [close?            
                        count-lines!]     
                        #:name name)  -> input-port?
  in : input-port?
  get-location : (or/c
                  (->
                   (values
                    (or/c exact-positive-integer? #f)
                    (or/c exact-nonnegative-integer? #f)
                    (or/c exact-positive-integer? #f)))
                  #f)
  init-pos : exact-positive-integer?
  close? : any/c = #t
  count-lines! : (-> any) = void
  name : (object-name out)
procedure
(transplant-output-port  out               
                         get-location      
                         init-pos          
                        [close?            
                         count-lines!]     
                         #:name name)  -> output-port?
  out : output-port?
  get-location : (or/c
                  (->
                   (values
                    (or/c exact-positive-integer? #f)
                    (or/c exact-nonnegative-integer? #f)
                    (or/c exact-positive-integer? #f)))
                  #f)
  init-pos : exact-positive-integer?
  close? : any/c = #t
  count-lines! : (-> any) = void
  name : (object-name out)
procedure
(filter-read-input-port  in            
                         read-wrap     
                         peek-wrap     
                        [close?])  -> input-port?
  in : input-port?
  read-wrap : (bytes? (or/c exact-nonnegative-integer?
                            eof-object?
                            procedure?
                            evt?)
                      . -> .
                      (or/c exact-nonnegative-integer?
                            eof-object?
                            procedure?
                            evt?))
  peek-wrap : (bytes? exact-nonnegative-integer? (or/c evt? #f)
                      (or/c exact-nonnegative-integer?
                       eof-object?
                       procedure?
                       evt?
                       #f)
               . -> . (or/c exact-nonnegative-integer?
                       eof-object?
                       procedure?
                       evt?
                       #f))
  close? : any/c = #t
procedure
(special-filter-input-port in proc [close?]) -> input-port?
  in : input-port?
  proc : (procedure? bytes? . -> . (or/c exact-nonnegative-integer?
                                         eof-object?
                                         procedure?
                                         evt?))
  close? : any/c = #t
procedure
(eof-evt in) -> evt?
  in : input-port?
procedure
(read-bytes-evt k in) -> evt?
  k : exact-nonnegative-integer?
  in : input-port?
procedure
(read-bytes!-evt bstr in progress-evt) -> evt?
  bstr : (and/c bytes? (not/c immutable?))
  in : input-port?
  progress-evt : (or/c progress-evt? #f)
procedure
(read-bytes-avail!-evt bstr in) -> evt?
  bstr : (and/c bytes? (not/c immutable?))
  in : input-port?
procedure
(read-string-evt k in) -> evt?
  k : exact-nonnegative-integer?
  in : input-port?
procedure
(read-string!-evt str in) -> evt?
  str : (and/c string? (not/c immutable?))
  in : input-port?
procedure
(read-line-evt in mode) -> evt?
  in : input-port?
  mode : (or/c 'linefeed 'return 'return-linefeed 'any 'any-one)
procedure
(read-bytes-line-evt in mode) -> evt?
  in : input-port?
  mode : (or/c 'linefeed 'return 'return-linefeed 'any 'any-one)
procedure
(peek-bytes-evt k skip progress-evt in) -> evt?
  k : exact-nonnegative-integer?
  skip : exact-nonnegative-integer?
  progress-evt : (or/c progress-evt? #f)
  in : input-port?
(peek-bytes!-evt bstr skip progress-evt in) -> evt?
  bstr : (and/c bytes? (not/c immutable?))
  skip : exact-nonnegative-integer?
  progress-evt : (or/c progress-evt? #f)
  in : input-port?
(peek-bytes-avail!-evt bstr             
                       skip             
                       progress-evt     
                       in)          -> evt?
  bstr : (and/c bytes? (not/c immutable?))
  skip : exact-nonnegative-integer?
  progress-evt : (or/c progress-evt? #f)
  in : input-port?
(peek-string-evt k skip progress-evt in) -> evt?
  k : exact-nonnegative-integer?
  skip : exact-nonnegative-integer?
  progress-evt : (or/c progress-evt? #f)
  in : input-port?
(peek-string!-evt str skip progress-evt in) -> evt?
  str : (and/c string? (not/c immutable?))
  skip : exact-nonnegative-integer?
  progress-evt : (or/c progress-evt? #f)
  in : input-port?
procedure
(regexp-match-evt pattern in) -> any
  pattern : (or/c string? bytes? regexp? byte-regexp?)
  in : input-port?
procedure
(convert-stream from-encoding     
                in                
                to-encoding       
                out)          -> void?
  from-encoding : string?
  in : input-port?
  to-encoding : string?
  out : output-port?
procedure
(copy-port in out ...+) -> void?
  in : input-port?
  out : output-port?
procedure
(read-char [in]) -> (or/c char? eof-object?)
  in : input-port? = (current-input-port)
procedure
(read-byte [in]) -> (or/c byte? eof-object?)
  in : input-port? = (current-input-port)
procedure
(read-line [in mode]) -> (or/c string? eof-object?)
  in : input-port? = (current-input-port)
  mode : (or/c 'linefeed 'return 'return-linefeed 'any 'any-one)
       = 'linefeed
procedure
(read-bytes-line [in mode]) -> (or/c bytes? eof-object?)
  in : input-port? = (current-input-port)
  mode : (or/c 'linefeed 'return 'return-linefeed 'any 'any-one)
       = 'linefeed
procedure
(read-string amt [in]) -> (or/c string? eof-object?)
  amt : exact-nonnegative-integer?
  in : input-port? = (current-input-port)
procedure
(read-bytes amt [in]) -> (or/c bytes? eof-object?)
  amt : exact-nonnegative-integer?
  in : input-port? = (current-input-port)
procedure
(read-string! str [in start-pos end-pos])
 -> (or/c exact-positive-integer? eof-object?)
  str : (and/c string? (not/c immutable?))
  in : input-port? = (current-input-port)
  start-pos : exact-nonnegative-integer? = 0
  end-pos : exact-nonnegative-integer? = (string-length str)
procedure
(read-bytes! bstr [in start-pos end-pos])
 -> (or/c exact-positive-integer? eof-object?)
  bstr : bytes?
  in : input-port? = (current-input-port)
  start-pos : exact-nonnegative-integer? = 0
  end-pos : exact-nonnegative-integer? = (bytes-length bstr)
procedure
(read-bytes-avail! bstr [in start-pos end-pos])
 -> (or/c exact-positive-integer? eof-object? procedure?)
  bstr : bytes?
  in : input-port? = (current-input-port)
  start-pos : exact-nonnegative-integer? = 0
  end-pos : exact-nonnegative-integer? = (bytes-length bstr)
procedure
(read-bytes-avail!*  bstr      
                    [in        
                     start-pos 
                     end-pos]) 
 -> (or/c exact-nonnegative-integer? eof-object? procedure?)
  bstr : bytes?
  in : input-port? = (current-input-port)
  start-pos : exact-nonnegative-integer? = 0
  end-pos : exact-nonnegative-integer? = (bytes-length bstr)
procedure
(read-bytes-avail!/enable-break  bstr      
                                [in        
                                 start-pos 
                                 end-pos]) 
 -> (or/c exact-positive-integer? eof-object? procedure?)
  bstr : bytes?
  in : input-port? = (current-input-port)
  start-pos : exact-nonnegative-integer? = 0
  end-pos : exact-nonnegative-integer? = (bytes-length bstr)
procedure
(peek-string amt skip-bytes-amt [in]) -> (or/c string? eof-object?)
  amt : exact-nonnegative-integer?
  skip-bytes-amt : exact-nonnegative-integer?
  in : input-port? = (current-input-port)
procedure
(peek-bytes amt skip-bytes-amt [in]) -> (or/c bytes? eof-object?)
  amt : exact-nonnegative-integer?
  skip-bytes-amt : exact-nonnegative-integer?
  in : input-port? = (current-input-port)
procedure
(peek-string!  str            
               skip-bytes-amt 
              [in             
               start-pos      
               end-pos])      
 -> (or/c exact-positive-integer? eof-object?)
  str : (and/c string? (not/c immutable?))
  skip-bytes-amt : exact-nonnegative-integer?
  in : input-port? = (current-input-port)
  start-pos : exact-nonnegative-integer? = 0
  end-pos : exact-nonnegative-integer? = (string-length str)
procedure
(peek-bytes!  bstr           
              skip-bytes-amt 
             [in             
              start-pos      
              end-pos])      
 -> (or/c exact-positive-integer? eof-object?)
  bstr : (and/c bytes? (not/c immutable?))
  skip-bytes-amt : exact-nonnegative-integer?
  in : input-port? = (current-input-port)
  start-pos : exact-nonnegative-integer? = 0
  end-pos : exact-nonnegative-integer? = (bytes-length bstr)
procedure
(peek-bytes-avail!  bstr           
                    skip-bytes-amt 
                   [progress       
                    in             
                    start-pos      
                    end-pos])      
 -> (or/c exact-nonnegative-integer? eof-object? procedure?)
  bstr : (and/c bytes? (not/c immutable?))
  skip-bytes-amt : exact-nonnegative-integer?
  progress : (or/c progress-evt? #f) = #f
  in : input-port? = (current-input-port)
  start-pos : exact-nonnegative-integer? = 0
  end-pos : exact-nonnegative-integer? = (bytes-length bstr)
procedure
(peek-bytes-avail!*  bstr           
                     skip-bytes-amt 
                    [progress       
                     in             
                     start-pos      
                     end-pos])      
 -> (or/c exact-nonnegative-integer? eof-object? procedure?)
  bstr : (and/c bytes? (not/c immutable?))
  skip-bytes-amt : exact-nonnegative-integer?
  progress : (or/c progress-evt? #f) = #f
  in : input-port? = (current-input-port)
  start-pos : exact-nonnegative-integer? = 0
  end-pos : exact-nonnegative-integer? = (bytes-length bstr)
procedure
(peek-bytes-avail!/enable-break  bstr           
                                 skip-bytes-amt 
                                [progress       
                                 in             
                                 start-pos      
                                 end-pos])      
 -> (or/c exact-nonnegative-integer? eof-object? procedure?)
  bstr : (and/c bytes? (not/c immutable?))
  skip-bytes-amt : exact-nonnegative-integer?
  progress : (or/c progress-evt? #f) = #f
  in : input-port? = (current-input-port)
  start-pos : exact-nonnegative-integer? = 0
  end-pos : exact-nonnegative-integer? = (bytes-length bstr)
procedure
(read-char-or-special [in]) -> (or/c char? eof-object? any/c)
  in : input-port? = (current-input-port)
procedure
(read-byte-or-special [in]) -> (or/c byte? eof-object? any/c)
  in : input-port? = (current-input-port)
procedure
(peek-char [in skip-bytes-amt]) -> (or/c char? eof-object?)
  in : input-port? = (current-input-port)
  skip-bytes-amt : exact-nonnegative-integer? = 0
procedure
(peek-byte [in skip-bytes-amt]) -> (or/c byte? eof-object?)
  in : input-port? = (current-input-port)
  skip-bytes-amt : exact-nonnegative-integer? = 0
procedure
(peek-char-or-special [in skip-bytes-amt])
 -> (or/c char? eof-object? any/c)
  in : input-port? = (current-input-port)
  skip-bytes-amt : exact-nonnegative-integer? = 0
procedure
(peek-byte-or-special [in             
                       skip-bytes-amt 
                       progress])     
 -> (or/c byte? eof-object? any/c)
  in : input-port? = (current-input-port)
  skip-bytes-amt : exact-nonnegative-integer? = 0
  progress : (or/c progress-evt? #f) = #f
procedure
(port-progress-evt [in]) -> progress-evt?
  in : (and/c input-port? port-provides-progress-evts?)
     = (current-input-port)
procedure
(port-provides-progress-evts? in) -> boolean
  in : input-port?
procedure
(port-commit-peeked amt progress evt [in]) -> boolean?
  amt : exact-nonnegative-integer?
  progress : progress-evt?
  evt : evt?
  in : input-port? = (current-input-port)
procedure
(byte-ready? [in]) -> boolean?
  in : input-port? = (current-input-port)
procedure
(char-ready? [in]) -> boolean?
  in : input-port? = (current-input-port)
procedure
(progress-evt? v) -> boolean?
  v : any/c
(progress-evt? evt in) -> boolean?
  evt : progress-evt?
  in : input-port?
procedure
(write-char char [out]) -> void?
  char : char?
  out : output-port? = (current-output-port)
procedure
(write-byte byte [out]) -> void?
  byte : byte?
  out : output-port? = (current-output-port)
procedure
(newline [out]) -> void?
  out : output-port? = (current-output-port)
procedure
(write-string str [out start-pos end-pos])
 -> exact-nonnegative-integer?
  str : string?
  out : output-port? = (current-output-port)
  start-pos : exact-nonnegative-integer? = 0
  end-pos : exact-nonnegative-integer? = (string-length str)
procedure
(write-bytes bstr [out start-pos end-pos])
 -> exact-nonnegative-integer?
  bstr : bytes?
  out : output-port? = (current-output-port)
  start-pos : exact-nonnegative-integer? = 0
  end-pos : exact-nonnegative-integer? = (bytes-length bstr)
procedure
(write-bytes-avail  bstr          
                   [out           
                    start-pos     
                    end-pos]) -> exact-nonnegative-integer?
  bstr : bytes?
  out : output-port? = (current-output-port)
  start-pos : exact-nonnegative-integer? = 0
  end-pos : exact-nonnegative-integer? = (bytes-length bstr)
procedure
(write-bytes-avail*  bstr      
                    [out       
                     start-pos 
                     end-pos]) 
 -> (or/c exact-nonnegative-integer? #f)
  bstr : bytes?
  out : output-port? = (current-output-port)
  start-pos : exact-nonnegative-integer? = 0
  end-pos : exact-nonnegative-integer? = (bytes-length bstr)
procedure
(write-bytes-avail/enable-break  bstr      
                                [out       
                                 start-pos 
                                 end-pos]) 
 -> exact-nonnegative-integer?
  bstr : bytes?
  out : output-port? = (current-output-port)
  start-pos : exact-nonnegative-integer? = 0
  end-pos : exact-nonnegative-integer? = (bytes-length bstr)
procedure
(write-special v [out]) -> boolean?
  v : any/c
  out : output-port? = (current-output-port)
procedure
(write-special-avail* v [out]) -> boolean?
  v : any/c
  out : output-port? = (current-output-port)
procedure
(write-bytes-avail-evt  bstr          
                       [out           
                        start-pos     
                        end-pos]) -> evt?
  bstr : bytes?
  out : output-port? = (current-output-port)
  start-pos : exact-nonnegative-integer? = 0
  end-pos : exact-nonnegative-integer? = (bytes-length bstr)
procedure
(write-special-evt v [out]) -> evt?
  v : any/c
  out : output-port? = (current-output-port)
procedure
(port-writes-atomic? out) -> boolean?
  out : output-port?
procedure
(port-writes-special? out) -> boolean?
  out : output-port?
procedure
(read [in]) -> any
  in : input-port? = (current-input-port)
procedure
(read-syntax [source-name in]) -> (or/c syntax? eof-object?)
  source-name : any/c = (object-name in)
  in : input-port? = (current-input-port)
procedure
(read/recursive [in start readtable graph?]) -> any
  in : input-port? = (current-input-port)
  start : (or/c char? #f) = #f
  readtable : (or/c readtable? #f) = (current-readtable)
  graph? : any/c = #t
procedure
(read-syntax/recursive [source-name     
                        in              
                        start           
                        readtable       
                        graph?])    -> any
  source-name : any/c = (object-name in)
  in : input-port? = (current-input-port)
  start : (or/c char? #f) = #f
  readtable : (or/c readtable? #f) = (current-readtable)
  graph? : any/c = #t
procedure
(read-language [in fail-thunk])
 -> (or/c (any/c any/c . -> . any) #f)
  in : input-port? = (current-input-port)
  fail-thunk : (-> any) = (lambda () (error ...))
parameter
(read-case-sensitive) -> boolean?
(read-case-sensitive on?) -> void?
  on? : any/c
parameter
(read-square-bracket-as-paren) -> boolean?
(read-square-bracket-as-paren on?) -> void?
  on? : any/c
parameter
(read-curly-brace-as-paren) -> boolean?
(read-curly-brace-as-paren on?) -> void?
  on? : any/c
parameter
(read-accept-box) -> boolean?
(read-accept-box on?) -> void?
  on? : any/c
parameter
(read-accept-compiled) -> boolean?
(read-accept-compiled on?) -> void?
  on? : any/c
parameter
(read-accept-bar-quote) -> boolean?
(read-accept-bar-quote on?) -> void?
  on? : any/c
parameter
(read-accept-graph) -> boolean?
(read-accept-graph on?) -> void?
  on? : any/c
parameter
(read-decimal-as-inexact) -> boolean?
(read-decimal-as-inexact on?) -> void?
  on? : any/c
parameter
(read-accept-dot) -> boolean?
(read-accept-dot on?) -> void?
  on? : any/c
parameter
(read-accept-infix-dot) -> boolean?
(read-accept-infix-dot on?) -> void?
  on? : any/c
parameter
(read-accept-quasiquote) -> boolean?
(read-accept-quasiquote on?) -> void?
  on? : any/c
parameter
(read-accept-reader) -> boolean?
(read-accept-reader on?) -> void?
  on? : any/c
parameter
(read-accept-lang) -> boolean?
(read-accept-lang on?) -> void?
  on? : any/c
parameter
(current-readtable) -> (or/c readtable? #f)
(current-readtable readtable) -> void?
  readtable : (or/c readtable? #f)
procedure
(call-with-default-reading-parameterization thunk) -> any
  thunk : (-> any)
parameter
(current-reader-guard) -> (any/c . -> . any)
(current-reader-guard proc) -> void?
  proc : (any/c . -> . any)
parameter
(read-on-demand-source)
 -> (or/c #f #t (and/c path? complete-path?))
(read-on-demand-source mode) -> void?
  mode : (or/c #f #t (and/c path? complete-path?))
procedure
(port-read-handler in) -> (case->
                           (input-port? . -> . any)
                           (input-port?  any/c . -> . any))
  in : input-port?
(port-read-handler in proc) -> void?
  in : input-port?
  proc : (case->
          (input-port? . -> . any)
          (input-port? any/c . -> . any))
procedure
(write datum [out]) -> void?
  datum : any/c
  out : output-port? = (current-output-port)
procedure
(display datum [out]) -> void?
  datum : any/c
  out : output-port? = (current-output-port)
procedure
(print datum [out quote-depth]) -> void?
  datum : any/c
  out : output-port? = (current-output-port)
  quote-depth : (or/c 0 1) = 0
procedure
(writeln datum [out]) -> void?
  datum : any/c
  out : output-port? = (current-output-port)
procedure
(displayln datum [out]) -> void?
  datum : any/c
  out : output-port? = (current-output-port)
procedure
(println datum [out quote-depth]) -> void?
  datum : any/c
  out : output-port? = (current-output-port)
  quote-depth : (or/c 0 1) = 0
procedure
(fprintf out form v ...) -> void?
  out : output-port?
  form : string?
  v : any/c
procedure
(printf form v ...) -> void?
  form : string?
  v : any/c
procedure
(eprintf form v ...) -> void?
  form : string?
  v : any/c
procedure
(format form v ...) -> string?
  form : string?
  v : any/c
parameter
(print-pair-curly-braces) -> boolean?
(print-pair-curly-braces on?) -> void?
  on? : any/c
parameter
(print-mpair-curly-braces) -> boolean?
(print-mpair-curly-braces on?) -> void?
  on? : any/c
parameter
(print-unreadable) -> boolean?
(print-unreadable on?) -> void?
  on? : any/c
parameter
(print-graph) -> boolean?
(print-graph on?) -> void?
  on? : any/c
parameter
(print-struct) -> boolean?
(print-struct on?) -> void?
  on? : any/c
parameter
(print-box) -> boolean?
(print-box on?) -> void?
  on? : any/c
parameter
(print-vector-length) -> boolean?
(print-vector-length on?) -> void?
  on? : any/c
parameter
(print-hash-table) -> boolean?
(print-hash-table on?) -> void?
  on? : any/c
parameter
(print-boolean-long-form) -> boolean?
(print-boolean-long-form on?) -> void?
  on? : any/c
parameter
(print-reader-abbreviations) -> boolean?
(print-reader-abbreviations on?) -> void?
  on? : any/c
parameter
(print-as-expression) -> boolean?
(print-as-expression on?) -> void?
  on? : any/c
parameter
(print-syntax-width)
 -> (or/c +inf.0 0 (and/c exact-integer? (>/c 3)))
(print-syntax-width width) -> void?
  width : (or/c +inf.0 0 (and/c exact-integer? (>/c 3)))
parameter
(current-write-relative-directory)
 -> (or/c (and/c path? complete-path?)
          (cons/c (and/c path? complete-path?)
                  (and/c path? complete-path?))
          #f)
(current-write-relative-directory path) -> void?
  path : (or/c (and/c path-string? complete-path?)
               (cons/c (and/c path-string? complete-path?)
                       (and/c path-string? complete-path?))
               #f)
procedure
(port-write-handler out) -> (any/c output-port? . -> . any)
  out : output-port?
(port-write-handler out proc) -> void?
  out : output-port?
  proc : (any/c output-port? . -> . any)
procedure
(port-display-handler out) -> (any/c output-port? . -> . any)
  out : output-port?
(port-display-handler out proc) -> void?
  out : output-port?
  proc : (any/c output-port? . -> . any)
procedure
(port-print-handler out)
 -> ((any/c output-port?) ((or/c 0 1)) . ->* . any)
  out : output-port?
(port-print-handler out proc) -> void?
  out : output-port?
  proc : (any/c output-port? . -> . any)
procedure
(global-port-print-handler)
 -> (->* (any/c output-port?) ((or/c 0 1)) any)
(global-port-print-handler proc) -> void?
  proc : (or/c (->* (any/c output-port?) ((or/c 0 1)) any)
               (any/c output-port? . -> . any))
procedure
(pretty-print v [port quote-depth]) -> void?
  v : any/c
  port : output-port? = (current-output-port)
  quote-depth : (or/c 0 1) = 0
procedure
(pretty-write v [port]) -> void?
  v : any/c
  port : output-port? = (current-output-port)
procedure
(pretty-display v [port]) -> void?
  v : any/c
  port : output-port? = (current-output-port)
procedure
(pretty-format v [columns]) -> string?
  v : any/c
  columns : exact-nonnegative-integer? = (pretty-print-columns)
procedure
(pretty-print-handler v) -> void?
  v : any/c
parameter
(pretty-print-columns)
 -> (or/c exact-positive-integer? 'infinity)
(pretty-print-columns width) -> void?
  width : (or/c exact-positive-integer? 'infinity)
parameter
(pretty-print-depth) -> (or/c exact-nonnegative-integer? #f)
(pretty-print-depth depth) -> void?
  depth : (or/c exact-nonnegative-integer? #f)
parameter
(pretty-print-exact-as-decimal) -> boolean?
(pretty-print-exact-as-decimal as-decimal?) -> void?
  as-decimal? : any/c
parameter
(pretty-print-.-symbol-without-bars) -> boolean?
(pretty-print-.-symbol-without-bars on?) -> void?
  on? : any/c
parameter
(pretty-print-show-inexactness) -> boolean?
(pretty-print-show-inexactness show?) -> void?
  show? : any/c
parameter
(pretty-print-abbreviate-read-macros) -> boolean?
(pretty-print-abbreviate-read-macros abbrev?) -> void?
  abbrev? : any/c
procedure
(pretty-print-style-table? v) -> boolean?
  v : any/c
parameter
(pretty-print-current-style-table) -> pretty-print-style-table?
(pretty-print-current-style-table style-table) -> void?
  style-table : pretty-print-style-table?
procedure
(pretty-print-extend-style-table style-table       
                                 symbol-list       
                                 like-symbol-list) 
 -> pretty-print-style-table?
  style-table : pretty-print-style-table?
  symbol-list : (listof symbol?)
  like-symbol-list : (listof symbol?)
parameter
(pretty-print-remap-stylable)
 -> (any/c . -> . (or/c symbol? #f))
(pretty-print-remap-stylable proc) -> void?
  proc : (any/c . -> . (or/c symbol? #f))
procedure
(pretty-print-newline port width) -> void?
  port : output-port?
  width : exact-nonnegative-integer?
parameter
(pretty-print-print-line)
 -> ((or/c exact-nonnegative-integer? #f)
     output-port?
     exact-nonnegative-integer?
     (or/c exact-nonnegative-integer? 'infinity)
     . -> .
     exact-nonnegative-integer?)
(pretty-print-print-line proc) -> void?
  proc : ((or/c exact-nonnegative-integer? #f)
          output-port?
          exact-nonnegative-integer?
          (or/c exact-nonnegative-integer? 'infinity)
          . -> .
          exact-nonnegative-integer?)
parameter
(pretty-print-size-hook)
 -> (any/c boolean? output-port?
     . -> .
     (or/c #f exact-nonnegative-integer?))
(pretty-print-size-hook proc) -> void?
  proc : (any/c boolean? output-port?
          . -> .
          (or/c #f exact-nonnegative-integer?))
parameter
(pretty-print-print-hook)
 -> (any/c boolean? output-port? . -> . void?)
(pretty-print-print-hook proc) -> void?
  proc : (any/c boolean? output-port? . -> . void?)
parameter
(pretty-print-pre-print-hook)
 -> (any/c output-port? . -> . void)
(pretty-print-pre-print-hook proc) -> void?
  proc : (any/c output-port? . -> . void)
parameter
(pretty-print-post-print-hook)
 -> (any/c output-port? . -> . void)
(pretty-print-post-print-hook proc) -> void?
  proc : (any/c output-port? . -> . void)
parameter
(pretty-printing) -> boolean?
(pretty-printing on?) -> void?
  on? : any/c
procedure
(make-tentative-pretty-print-output-port out             
                                         width           
                                         overflow-thunk) 
 -> output-port?
  out : output-port?
  width : exact-nonnegative-integer?
  overflow-thunk : (-> any)
procedure
(tentative-pretty-print-port-transfer tentative-out     
                                      orig-out)     -> void?
  tentative-out : output-port?
  orig-out : output-port?
procedure
(tentative-pretty-print-port-cancel tentative-out) -> void?
  tentative-out : output-port?
procedure
(readtable? v) -> boolean?
  v : any/c
procedure
(make-readtable readtable        
                key              
                mode             
                action ...+) -> readtable?
  readtable : readtable?
  key : (or/c char? #f)
  mode : (or/c (or/c 'terminating-macro
                     'non-terminating-macro
                     'dispatch-macro)
               char?)
  action : (or/c procedure?
                 readtable?)
procedure
(readtable-mapping readtable char)
 -> (or/c char?
          (or/c 'terminating-macro
                'non-terminating-macro))
    (or/c #f procedure?)
    (or/c #f procedure?)
  readtable : readtable?
  char : char?
procedure
(make-special-comment v) -> special-comment?
  v : any/c
procedure
(special-comment? v) -> boolean?
  v : any/c
procedure
(special-comment-value sc) -> any
  sc : special-comment?
value
gen:custom-write : any/c
value
prop:custom-write : struct-type-property?
procedure
(custom-write? v) -> boolean?
  v : any/c
procedure
(custom-write-accessor v)
 -> (custom-write? output-port? boolean? . -> . any)
  v : custom-write?
value
prop:custom-print-quotable : struct-type-property?
value
custom-print-quotable? : struct-type-property?
value
custom-print-quotable-accessor : struct-type-property?
procedure
(serializable? v) -> boolean?
  v : any/c
procedure
(serialize v) -> any
  v : serializable?
procedure
(deserialize v) -> any
  v : any/c
procedure
(serialized=? v1 v2) -> boolean?
  v1 : any/c
  v2 : any/c
parameter
(deserialize-module-guard)
 -> (module-path? symbol? . -> . void?)
(deserialize-module-guard guard) -> void?
  guard : (module-path? symbol? . -> . void?)
syntax
(serializable-struct id maybe-super (field ...)
                     struct-option ...)
syntax
(define-serializable-struct id-maybe-super (field ...)
                             struct-option ...)
syntax
(serializable-struct/versions id maybe-super vers (field ...)
                              (other-version-clause ...)
                              struct-option ...)
 
other-version-clause = (other-vers make-proc-expr
                                   cycle-make-proc-expr)
syntax
(define-serializable-struct/versions id-maybe-super vers (field ...)
                                     (other-version-clause ...)
                                     struct-option ...)
procedure
(make-deserialize-info make cycle-make) -> any
  make : procedure?
  cycle-make : (-> (values any/c procedure?))
value
prop:serializable : property?
procedure
(make-serialize-info to-vector          
                     deserialize-id     
                     can-cycle?         
                     dir)           -> any
  to-vector : (any/c . -> . vector?)
  deserialize-id : (or identifier?
                       symbol?
                       (cons/c symbol?
                               module-path-index?))
  can-cycle? : any/c
  dir : path-string?
procedure
(s-exp->fasl v [out]) -> (or/c (void) bytes?)
  v : any/c
  out : (or/c output-port? #f) = #f
procedure
(fasl->s-exp in) -> any/c
  in : (or/c input-port? bytes?)
procedure
(namespace? v) -> boolean?
  v : any/c
procedure
(make-empty-namespace) -> namespace?
procedure
(make-base-empty-namespace) -> namespace?
procedure
(make-base-namespace) -> namespace?
syntax
(define-namespace-anchor id)
procedure
(namespace-anchor? v) -> boolean?
  v : any/c
procedure
(namespace-anchor->empty-namespace a) -> namespace?
  a : namespace-anchor?
procedure
(namespace-anchor->namespace a) -> namespace?
  a : namespace-anchor?
parameter
(current-namespace) -> namespace?
(current-namespace n) -> void?
  n : namespace?
procedure
(namespace-symbol->identifier sym) -> identifier?
  sym : symbol?
procedure
(namespace-base-phase [namespace]) -> exact-integer?
  namespace : namespace? = (current-namespace)
procedure
(namespace-module-identifier [where]) -> identifier?
  where : (or/c namespace? exact-integer? #f)
        = (current-namespace)
procedure
(namespace-variable-value  sym               
                          [use-mapping?      
                           failure-thunk     
                           namespace])   -> any
  sym : symbol?
  use-mapping? : any/c = #t
  failure-thunk : (or/c (-> any) #f) = #f
  namespace : namespace? = (current-namespace)
procedure
(namespace-set-variable-value!  sym             
                                v               
                               [map?            
                                namespace]) -> void?
  sym : symbol?
  v : any/c
  map? : any/c = #f
  namespace : namespace? = (current-namespace)
procedure
(namespace-undefine-variable!  sym             
                              [namespace]) -> void?
  sym : symbol?
  namespace : namespace? = (current-namespace)
procedure
(namespace-mapped-symbols [namespace]) -> (listof symbol?)
  namespace : namespace? = (current-namespace)
procedure
(namespace-require quoted-raw-require-spec) -> void?
  quoted-raw-require-spec : any/c
procedure
(namespace-require/copy quoted-raw-require-spec) -> void?
  quoted-raw-require-spec : any/c
procedure
(namespace-require/constant quoted-raw-require-spec) -> void?
  quoted-raw-require-spec : any/c
procedure
(namespace-require/expansion-time quoted-raw-require-spec)
 -> void?
  quoted-raw-require-spec : any/c
procedure
(namespace-attach-module  src-namespace        
                          modname              
                         [dest-namespace]) -> void?
  src-namespace : namespace?
  modname : module-path?
  dest-namespace : namespace? = (current-namespace)
procedure
(namespace-attach-module-declaration  src-namespace        
                                      modname              
                                     [dest-namespace]) -> void?
  src-namespace : namespace?
  modname : module-path?
  dest-namespace : namespace? = (current-namespace)
procedure
(namespace-unprotect-module  inspector       
                             modname         
                            [namespace]) -> void?
  inspector : inspector?
  modname : module-path?
  namespace : namespace? = (current-namespace)
procedure
(namespace-module-registry namespace) -> any
  namespace : namespace?
procedure
(module->namespace mod) -> namespace?
  mod : (or/c module-path?
              resolved-module-path?
              module-path-index?)
procedure
(namespace-syntax-introduce stx) -> syntax?
  stx : syntax?
procedure
(module-provide-protected? module-path-index     
                           sym)              -> boolean?
  module-path-index : (or/c symbol? module-path-index?)
  sym : symbol?
procedure
(variable-reference? v) -> boolean?
  v : any/c
procedure
(variable-reference-constant? varref) -> boolean?
  varref : variable-reference?
procedure
(variable-reference->empty-namespace varref) -> namespace?
  varref : variable-reference?
procedure
(variable-reference->namespace varref) -> namespace?
  varref : variable-reference?
procedure
(variable-reference->resolved-module-path varref)
 -> (or/c resolved-module-path? #f)
  varref : variable-reference?
procedure
(variable-reference->module-path-index varref)
 -> (or/c module-path-index? #f)
  varref : variable-reference?
procedure
(variable-reference->module-source varref)
 -> (or/c symbol? (and/c path? complete-path?) #f)
  varref : variable-reference?
procedure
(variable-reference->phase varref) -> exact-nonnegative-integer?
  varref : variable-reference?
procedure
(variable-reference->module-base-phase varref) -> exact-integer?
  varref : variable-reference?
procedure
(variable-reference->module-declaration-inspector varref)
 -> inspector?
  varref : variable-reference?
parameter
(current-eval) -> (any/c . -> . any)
(current-eval proc) -> void?
  proc : (any/c . -> . any)
procedure
(eval top-level-form [namespace]) -> any
  top-level-form : any/c
  namespace : namespace? = (current-namespace)
procedure
(eval-syntax stx [namespace]) -> any
  stx : syntax?
  namespace : namespace? = (current-namespace)
parameter
(current-load)
 -> (path? (or/c #f
                 symbol?
                 (cons/c (or/c #f symbol?)
                         (non-empty-listof symbol?)))
           . -> .
           any)
(current-load proc) -> void?
  proc : (path? (or/c #f
                      symbol?
                      (cons/c (or/c #f symbol?)
                              (non-empty-listof symbol?)))
                . -> .
                any)
procedure
(load file) -> any
  file : path-string?
procedure
(load-relative file) -> any
  file : path-string?
procedure
(load/cd file) -> any
  file : path-string?
parameter
(current-load-extension)
 -> (path? (or/c symbol? #f) . -> . any)
(current-load-extension proc) -> void?
  proc : (path? (or/c symbol? #f) . -> . any)
procedure
(load-extension file) -> any
  file : path-string?
procedure
(load-relative-extension file) -> any
  file : path-string?
parameter
(current-load/use-compiled)
 -> (path? (or/c #f
                 symbol?
                 (cons/c (or/c #f symbol?)
                         (non-empty-listof symbol?)))
           . -> . any)
(current-load/use-compiled proc) -> void?
  proc : (path? (or/c #f
                      symbol?
                      (cons/c (or/c #f symbol?)
                              (non-empty-listof symbol?)))
                . -> . any)
procedure
(load/use-compiled file) -> any
  file : path-string?
parameter
(current-load-relative-directory)
 -> (or/c (and/c path-string? complete-path?) #f)
(current-load-relative-directory path) -> void?
  path : (or/c (and/c path-string? complete-path?) #f)
parameter
(use-compiled-file-paths)
 -> (listof (and/c path? relative-path?))
(use-compiled-file-paths paths) -> void?
  paths : (listof (and/c path-string? relative-path?))
parameter
(current-compiled-file-roots) -> (listof (or/c path? 'same))
(current-compiled-file-roots paths) -> void?
  paths : (listof (or/c path-string? 'same))
procedure
(read-eval-print-loop) -> any
parameter
(current-prompt-read) -> (-> any)
(current-prompt-read proc) -> void?
  proc : (-> any)
parameter
(current-get-interaction-input-port) -> (-> input-port?)
(current-get-interaction-input-port proc) -> void?
  proc : (-> input-port?)
parameter
(current-read-interaction) -> (any/c input-port? -> any)
(current-read-interaction proc) -> void?
  proc : (any/c input-port? -> any)
parameter
(current-print) -> (any/c -> any)
(current-print proc) -> void?
  proc : (any/c -> any)
parameter
(current-compile)
 -> (any/c boolean? . -> . compiled-expression?)
(current-compile proc) -> void?
  proc : (any/c boolean? . -> . compiled-expression?)
procedure
(compile top-level-form) -> compiled-expression?
  top-level-form : any/c
procedure
(compile-syntax stx) -> compiled-expression?
  stx : syntax?
procedure
(compiled-expression? v) -> boolean?
  v : any/c
parameter
(compile-enforce-module-constants) -> boolean?
(compile-enforce-module-constants on?) -> void?
  on? : any/c
parameter
(compile-allow-set!-undefined) -> boolean?
(compile-allow-set!-undefined allow?) -> void?
  allow? : any/c
parameter
(compile-context-preservation-enabled) -> boolean?
(compile-context-preservation-enabled on?) -> void?
  on? : any/c
parameter
(eval-jit-enabled) -> boolean?
(eval-jit-enabled on?) -> void?
  on? : any/c
parameter
(load-on-demand-enabled) -> boolean?
(load-on-demand-enabled on?) -> void?
  on? : any/c
procedure
(resolved-module-path? v) -> boolean?
  v : any/c
procedure
(make-resolved-module-path path) -> resolved-module-path?
  path : (or/c symbol?
               (and/c path? complete-path?)
               (cons/c (or/c symbol?
                             (and/c path? complete-path?))
                       (non-empty-listof symbol?)))
procedure
(resolved-module-path-name module-path)
 -> (or/c symbol?
          (and/c path? complete-path?)
          (cons/c (or/c symbol?
                        (and/c path? complete-path?))
                  (non-empty-listof symbol?)))
  module-path : resolved-module-path?
procedure
(module-path? v) -> boolean?
  v : any/c
parameter
(current-module-name-resolver)
 -> (case->
     (resolved-module-path? (or/c #f namespace?) . -> . any)
     (module-path?
      (or/c #f resolved-module-path?)
      (or/c #f syntax?)
      boolean?
      . -> .
      resolved-module-path?))
(current-module-name-resolver proc) -> void?
  proc : (case->
          (resolved-module-path? (or/c #f namespace?) . -> . any)
          (module-path?
           (or/c #f resolved-module-path?)
           (or/c #f syntax?)
           boolean?
           . -> .
           resolved-module-path?))
parameter
(current-module-declare-name)
 -> (or/c resolved-module-path? #f)
(current-module-declare-name name) -> void?
  name : (or/c resolved-module-path? #f)
parameter
(current-module-declare-source)
 -> (or/c symbol? (and/c path? complete-path?) #f)
(current-module-declare-source src) -> void?
  src : (or/c symbol? (and/c path? complete-path?) #f)
parameter
(current-module-path-for-load)
 -> (or/c #f module-path?
          (and/c syntax?
                 (lambda (stx)
                   (module-path? (syntax->datum s)))))
(current-module-path-for-load path) -> void?
  path : (or/c #f module-path?
               (and/c syntax?
                      (lambda (stx)
                        (module-path? (syntax->datum s)))))
procedure
(module-path-index? v) -> boolean?
  v : any/c
procedure
(module-path-index-resolve mpi) -> resolved-module-path?
  mpi : module-path-index?
procedure
(module-path-index-split mpi)
 -> (or/c module-path? #f)
    (or/c module-path-index? resolved-module-path? #f)
  mpi : module-path-index?
procedure
(module-path-index-submodule mpi)
 -> (or/c #f (non-empty-listof symbol?))
  mpi : module-path-index?
procedure
(module-path-index-join path base [submod]) -> module-path-index?
  path : (or/c module-path? #f)
  base : (or/c module-path-index? resolved-module-path? #f)
  submod : (or/c #f (non-empty-listof symbol?)) = #f
procedure
(compiled-module-expression? v) -> boolean?
  v : any/c
procedure
(module-compiled-name compiled-module-code)
 -> (or/c symbol? (cons/c symbol? (non-empty-listof symbol?)))
  compiled-module-code : compiled-module-expression?
(module-compiled-name compiled-module-code 
                      name)                
 -> compiled-module-expression?
  compiled-module-code : compiled-module-expression?
  name : (or/c symbol? (cons/c symbol? (non-empty-listof symbol?)))
procedure
(module-compiled-submodules compiled-module-code 
                            non-star?)           
 -> (listof compiled-module-expression?)
  compiled-module-code : compiled-module-expression?
  non-star? : any/c
(module-compiled-submodules compiled-module-code 
                            non-star?            
                            submodules)          
 -> compiled-module-expression?
  compiled-module-code : compiled-module-expression?
  non-star? : any/c
  submodules : (listof compiled-module-expression?)
procedure
(module-compiled-imports compiled-module-code)
 -> (listof (cons/c (or/c exact-integer? #f)
                    (listof module-path-index?)))
  compiled-module-code : compiled-module-expression?
procedure
(module-compiled-exports compiled-module-code)
 -> (listof (cons/c (or/c exact-integer? #f) list?))
    (listof (cons/c (or/c exact-integer? #f) list?))
  compiled-module-code : compiled-module-expression?
procedure
(module-compiled-language-info compiled-module-code)
 -> (or/c #f (vector/c module-path? symbol? any/c))
  compiled-module-code : compiled-module-expression?
procedure
(module-compiled-cross-phase-persistent? compiled-module-code)
 -> boolean?
  compiled-module-code : compiled-module-expression?
procedure
(dynamic-require mod provided [fail-thunk]) -> (or/c void? any/c)
  mod : (or/c module-path?
              resolved-module-path?
              module-path-index?)
  provided : (or/c symbol? #f 0 void?)
  fail-thunk : (-> any) = (lambda () ....)
procedure
(dynamic-require-for-syntax  mod              
                             provided         
                            [fail-thunk]) -> any
  mod : module-path?
  provided : (or/c symbol? #f)
  fail-thunk : (-> any) = (lambda () ....)
procedure
(module-declared? mod [load?]) -> boolean?
  mod : (or/c module-path? module-path-index?
              resolved-module-path?)
  load? : any/c = #f
procedure
(module->language-info mod [load?])
 -> (or/c #f (vector/c module-path? symbol? any/c))
  mod : (or/c module-path? module-path-index?
              resolved-module-path?)
  load? : any/c = #f
procedure
(module->imports mod)
 -> (listof (cons/c (or/c exact-integer? #f)
                    (listof module-path-index?)))
  mod : (or/c module-path? module-path-index?
              resolved-module-path?)
procedure
(module->exports mod)
 -> (listof (cons/c (or/c exact-integer? #f) list?))
    (listof (cons/c (or/c exact-integer? #f) list?))
  mod : (or/c module-path? resolved-module-path?)
procedure
(module-predefined? mod) -> boolean?
  mod : (or/c module-path? resolved-module-path?)
procedure
(impersonator? v) -> boolean?
  v : any/c
procedure
(chaperone? v) -> boolean?
  v : any/c
procedure
(impersonator-of? v1 v2) -> boolean?
  v1 : any/c
  v2 : any/c
procedure
(chaperone-of? v1 v2) -> boolean?
  v1 : any/c
  v2 : any/c
procedure
(impersonator-ephemeron v) -> ephemeron?
  v : any/c
procedure
(impersonate-procedure proc         
                       wrapper-proc 
                       prop         
                       prop-val ... 
                       ...)         
 -> (and/c procedure? impersonator?)
  proc : procedure?
  wrapper-proc : (or/c procedure? #f)
  prop : impersonator-property?
  prop-val : any
procedure
(impersonate-procedure* proc         
                        wrapper-proc 
                        prop         
                        prop-val ... 
                        ...)         
 -> (and/c procedure? impersonator?)
  proc : procedure?
  wrapper-proc : (or/c procedure? #f)
  prop : impersonator-property?
  prop-val : any
procedure
(impersonate-struct  v                     
                    [struct-type]          
                     orig-proc             
                     redirect-proc ...     
                     ...                   
                     prop                  
                     prop-val ...          
                     ...)              -> any/c
  v : any/c
  struct-type : struct-type? = unspecified
  orig-proc : (or/c struct-accessor-procedure?
                    struct-mutator-procedure?
                    struct-type-property-accessor-procedure?)
  redirect-proc : (or/c procedure? #f)
  prop : impersonator-property?
  prop-val : any
procedure
(impersonate-vector vec          
                    ref-proc     
                    set-proc     
                    prop         
                    prop-val ... 
                    ...)         
 -> (and/c vector? impersonator?)
  vec : (and/c vector? (not/c immutable?))
  ref-proc : (vector? exact-nonnegative-integer? any/c . -> . any/c)
  set-proc : (vector? exact-nonnegative-integer? any/c . -> . any/c)
  prop : impersonator-property?
  prop-val : any
procedure
(impersonate-box box              
                 unbox-proc       
                 set-proc         
                 prop             
                 prop-val ...     
                 ...)         -> (and/c box? impersonator?)
  box : (and/c box? (not/c immutable?))
  unbox-proc : (box? any/c . -> . any/c)
  set-proc : (box? any/c . -> . any/c)
  prop : impersonator-property?
  prop-val : any
procedure
(impersonate-hash  hash             
                   ref-proc         
                   set-proc         
                   remove-proc      
                   key-proc         
                  [clear-proc]      
                   prop             
                   prop-val ...     
                   ...)         -> (and/c hash? impersonator?)
  hash : (and/c hash? (not/c immutable?))
  ref-proc : (hash? any/c . -> . (values
                                  any/c
                                  (hash? any/c any/c . -> . any/c)))
  set-proc : (hash? any/c any/c . -> . (values any/c any/c))
  remove-proc : (hash? any/c . -> . any/c)
  key-proc : (hash? any/c . -> . any/c)
  clear-proc : (or/c #f (hash? . -> . any)) = #f
  prop : impersonator-property?
  prop-val : any
procedure
(impersonate-channel channel      
                     get-proc     
                     put-proc     
                     prop         
                     prop-val ... 
                     ...)         
 -> (and/c channel? impersonator?)
  channel : channel?
  get-proc : (channel? . -> . (values channel? (any/c . -> . any/c)))
  put-proc : (channel? any/c . -> . any/c)
  prop : impersonator-property?
  prop-val : any
procedure
(impersonate-prompt-tag  prompt-tag               
                         handle-proc              
                         abort-proc               
                        [cc-guard-proc            
                         callcc-impersonate-proc] 
                         prop                     
                         prop-val ...             
                         ...)                     
 -> (and/c continuation-prompt-tag? impersonator?)
  prompt-tag : continuation-prompt-tag?
  handle-proc : procedure?
  abort-proc : procedure?
  cc-guard-proc : procedure? = values
  callcc-impersonate-proc : (procedure? . -> . procedure?)
                          = (lambda (p) p)
  prop : impersonator-property?
  prop-val : any
procedure
(impersonate-continuation-mark-key key          
                                   get-proc     
                                   set-proc     
                                   prop         
                                   prop-val ... 
                                   ...)         
 -> (and/c continuation-mark? impersonator?)
  key : continuation-mark-key?
  get-proc : procedure?
  set-proc : procedure?
  prop : impersonator-property?
  prop-val : any
value
prop:impersonator-of : struct-type-property?
procedure
(chaperone-procedure proc         
                     wrapper-proc 
                     prop         
                     prop-val ... 
                     ...)         
 -> (and/c procedure? chaperone?)
  proc : procedure?
  wrapper-proc : (or/c procedure? #f)
  prop : impersonator-property?
  prop-val : any
procedure
(chaperone-procedure* proc         
                      wrapper-proc 
                      prop         
                      prop-val ... 
                      ...)         
 -> (and/c procedure? chaperone?)
  proc : procedure?
  wrapper-proc : (or/c procedure? #f)
  prop : impersonator-property?
  prop-val : any
procedure
(chaperone-struct  v                     
                  [struct-type]          
                   orig-proc             
                   redirect-proc ...     
                   ...                   
                   prop                  
                   prop-val ...          
                   ...)              -> any/c
  v : any/c
  struct-type : struct-type? = unspecified
  orig-proc : (or/c struct-accessor-procedure?
                    struct-mutator-procedure?
                    struct-type-property-accessor-procedure?
                    (one-of/c struct-info))
  redirect-proc : (or/c procedure? #f)
  prop : impersonator-property?
  prop-val : any
procedure
(chaperone-vector vec              
                  ref-proc         
                  set-proc         
                  prop             
                  prop-val ...     
                  ...)         -> (and/c vector? chaperone?)
  vec : vector?
  ref-proc : (vector? exact-nonnegative-integer? any/c . -> . any/c)
  set-proc : (vector? exact-nonnegative-integer? any/c . -> . any/c)
  prop : impersonator-property?
  prop-val : any
procedure
(chaperone-box box              
               unbox-proc       
               set-proc         
               prop             
               prop-val ...     
               ...)         -> (and/c box? chaperone?)
  box : box?
  unbox-proc : (box? any/c . -> . any/c)
  set-proc : (box? any/c . -> . any/c)
  prop : impersonator-property?
  prop-val : any
procedure
(chaperone-hash  hash             
                 ref-proc         
                 set-proc         
                 remove-proc      
                 key-proc         
                [clear-proc]      
                 prop             
                 prop-val ...     
                 ...)         -> (and/c hash? chaperone?)
  hash : hash?
  ref-proc : (hash? any/c . -> . (values
                                  any/c
                                  (hash? any/c any/c . -> . any/c)))
  set-proc : (hash? any/c any/c . -> . (values any/c any/c))
  remove-proc : (hash? any/c . -> . any/c)
  key-proc : (hash? any/c . -> . any/c)
  clear-proc : (or/c #f (hash? . -> . any)) = #f
  prop : impersonator-property?
  prop-val : any
procedure
(chaperone-struct-type struct-type           
                       struct-info-proc      
                       make-constructor-proc 
                       guard-proc            
                       prop                  
                       prop-val ...          
                       ...)                  
 -> (and/c struct-type? chaperone?)
  struct-type : struct-type?
  struct-info-proc : procedure?
  make-constructor-proc : (procedure? . -> . procedure?)
  guard-proc : procedure?
  prop : impersonator-property?
  prop-val : any
procedure
(chaperone-evt evt proc prop prop-val ... ...)
 -> (and/c evt? chaperone?)
  evt : evt?
  proc : (evt? . -> . (values evt? (any/c . -> . any/c)))
  prop : impersonator-property?
  prop-val : any
procedure
(chaperone-channel channel          
                   get-proc         
                   put-proc         
                   prop             
                   prop-val ...     
                   ...)         -> (and/c channel? chaperone?)
  channel : channel?
  get-proc : (channel? . -> . (values channel? (any/c . -> . any/c)))
  put-proc : (channel? any/c . -> . any/c)
  prop : impersonator-property?
  prop-val : any
procedure
(chaperone-prompt-tag  prompt-tag             
                       handle-proc            
                       abort-proc             
                      [cc-guard-proc          
                       callcc-chaperone-proc] 
                       prop                   
                       prop-val ...           
                       ...)                   
 -> (and/c continuation-prompt-tag? chaperone?)
  prompt-tag : continuation-prompt-tag?
  handle-proc : procedure?
  abort-proc : procedure?
  cc-guard-proc : procedure? = values
  callcc-chaperone-proc : (procedure? . -> . procedure?)
                        = (lambda (p) p)
  prop : impersonator-property?
  prop-val : any
procedure
(chaperone-continuation-mark-key key          
                                 get-proc     
                                 set-proc     
                                 prop         
                                 prop-val ... 
                                 ...)         
 -> (and/c continuation-mark-key? chaperone?)
  key : continuation-mark-key?
  get-proc : procedure?
  set-proc : procedure?
  prop : impersonator-property?
  prop-val : any
procedure
(make-impersonator-property name) -> impersonator-property?
                                     (-> any/c boolean?)
                                     (-> impersonator? any)
  name : symbol?
procedure
(impersonator-property? v) -> boolean?
  v : any/c
procedure
(impersonator-property-accessor-procedure? v) -> boolean?
  v : any/c
value
impersonator-prop:application-mark : impersonator-property?
procedure
(security-guard? v) -> boolean?
  v : any/c
procedure
(make-security-guard  parent            
                      file-guard        
                      network-guard     
                     [link-guard])  -> security-guard?
  parent : security-guard?
  file-guard : (symbol?
                (or/c path? #f)
                (listof symbol?)
                . -> . any)
  network-guard : (symbol?
                   (or/c (and/c string? immutable?) #f)
                   (or/c (integer-in 1 65535) #f)
                   (or/c 'server 'client)
                   . -> . any)
  link-guard : (or/c (symbol? path? path? . -> . any) #f) = #f
parameter
(current-security-guard) -> security-guard?
(current-security-guard guard) -> void?
  guard : security-guard?
procedure
(custodian? v) -> boolean?
  v : any/c
procedure
(make-custodian [cust]) -> custodian?
  cust : custodian? = (current-custodian)
procedure
(custodian-shutdown-all cust) -> void?
  cust : custodian?
parameter
(current-custodian) -> custodian?
(current-custodian cust) -> void?
  cust : custodian?
procedure
(custodian-managed-list cust super) -> list?
  cust : custodian?
  super : custodian?
procedure
(custodian-memory-accounting-available?) -> boolean?
procedure
(custodian-require-memory limit-cust     
                          need-amt       
                          stop-cust) -> void?
  limit-cust : custodian?
  need-amt : exact-nonnegative-integer?
  stop-cust : custodian?
procedure
(custodian-limit-memory  limit-cust      
                         limit-amt       
                        [stop-cust]) -> void?
  limit-cust : custodian?
  limit-amt : exact-nonnegative-integer?
  stop-cust : custodian? = limit-cust
procedure
(make-custodian-box cust v) -> custodian-box?
  cust : custodian?
  v : any/c
procedure
(custodian-box? v) -> boolean?
  v : any/c
procedure
(custodian-box-value cb) -> any
  cb : custodian-box?
procedure
(make-thread-group [group]) -> thread-group?
  group : thread-group? = (current-thread-group)
procedure
(thread-group? v) -> boolean?
  v : any/c
parameter
(current-thread-group) -> thread-group?
(current-thread-group group) -> void?
  group : thread-group?
procedure
(inspector? v) -> boolean?
  v : any/c
procedure
(make-inspector [inspector]) -> inspector?
  inspector : inspector? = (current-inspector)
procedure
(make-sibling-inspector [inspector]) -> inspector?
  inspector : inspector? = (current-inspector)
parameter
(current-inspector) -> inspector?
(current-inspector insp) -> void?
  insp : inspector?
procedure
(struct-info v) -> (or/c struct-type? #f) boolean?
  v : any/c
procedure
(struct-type-info struct-type)
 -> symbol?
    exact-nonnegative-integer?
    exact-nonnegative-integer?
    struct-accessor-procedure?
    struct-mutator-procedure?
    (listof exact-nonnegative-integer?)
    (or/c struct-type? #f)
    boolean?
  struct-type : struct-type?
procedure
(struct-type-make-constructor struct-type)
 -> struct-constructor-procedure?
  struct-type : struct-type?
procedure
(struct-type-make-predicate struct-type) -> any
  struct-type : any/c
procedure
(object-name v) -> any
  v : any/c
value
prop:object-name : struct-type-property?
parameter
(current-code-inspector) -> inspector?
(current-code-inspector insp) -> void?
  insp : inspector?
procedure
(plumber? v) -> boolean?
  v : any/c
procedure
(make-plumber) -> pluber?
parameter
(current-plumber) -> plumber?
(current-plumber plumber) -> void?
  plumber : plumber?
procedure
(plumber-flush-all plumber) -> void?
  plumber : plumber?
procedure
(plumber-flush-handle? v) -> boolean?
  v : any/c
procedure
(plumber-add-flush! plumber proc [weak?]) -> plumber-flush-handle?
  plumber : plumber?
  proc : (plumber-flush-handle? . -> . any)
  weak? : any/c = #f
procedure
(plumber-flush-handle-remove! handle) -> void?
  handle : plumber-flush-handle?
procedure
(make-evaluator  language                              
                 input-program ...                     
                [#:requires requires                   
                 #:allow-for-require allow-for-require 
                 #:allow-for-load allow-for-load       
                 #:allow-read allow-read])             
 -> (any/c . -> . any)
  language : (or/c module-path?
                   (list/c 'special symbol?)
                   (cons/c 'begin list?))
  input-program : any/c
  requires : (listof (or/c module-path? path-string?
                           (cons/c 'for-syntax (listof module-path?))))
           = null
  allow-for-require : (listof (or/c module-path? path?)) = null
  allow-for-load : (listof path-string?) = null
  allow-read : (listof (or/c module-path? path-string?)) = null
(make-module-evaluator  module-decl                           
                       [#:language lang                       
                        #:allow-for-require allow-for-require 
                        #:allow-for-load allow-for-load       
                        #:allow-read allow-read])             
 -> (any/c . -> . any)
  module-decl : (or/c syntax? pair? path? input-port? string? bytes?)
  lang : (or/c #f module-path?) = #f
  allow-for-require : (listof (or/c module-path? path?)) = null
  allow-for-load : (listof path-string?) = null
  allow-read : (listof (or/c module-path? path-string?)) = null
procedure
(exn:fail:sandbox-terminated? v) -> boolean?
  v : any/c
(exn:fail:sandbox-terminated-reason exn) -> symbol?
  exn : exn:fail:sandbox-terminated?
procedure
(call-with-trusted-sandbox-configuration thunk) -> any
  thunk : (-> any)
parameter
(sandbox-init-hook) -> (-> any)
(sandbox-init-hook thunk) -> void?
  thunk : (-> any)
parameter
(sandbox-reader) -> (any/c . -> . any)
(sandbox-reader proc) -> void?
  proc : (any/c . -> . any)
parameter
(sandbox-input) -> (or/c #f
                         string? bytes?
                         input-port?
                         'pipe
                         (-> input-port?))
(sandbox-input in) -> void?
  in : (or/c #f
             string? bytes?
             input-port?
             'pipe
             (-> input-port?))
parameter
(sandbox-output) -> (or/c #f
                          output-port?
                          'pipe
                          'bytes
                          'string
                          (-> output-port?))
(sandbox-output in) -> void?
  in : (or/c #f
             output-port?
             'pipe
             'bytes
             'string
             (-> output-port?))
parameter
(sandbox-error-output) -> (or/c #f
                                output-port?
                                'pipe
                                'bytes
                                'string
                                (-> output-port?))
(sandbox-error-output in) -> void?
  in : (or/c #f
             output-port?
             'pipe
             'bytes
             'string
             (-> output-port?))
parameter
(sandbox-coverage-enabled) -> boolean?
(sandbox-coverage-enabled enabled?) -> void?
  enabled? : any/c
parameter
(sandbox-propagate-breaks) -> boolean?
(sandbox-propagate-breaks propagate?) -> void?
  propagate? : any/c
parameter
(sandbox-propagate-exceptions) -> boolean?
(sandbox-propagate-exceptions propagate?) -> void?
  propagate? : any/c
parameter
(sandbox-namespace-specs) -> (cons/c (-> namespace?)
                                     (listof module-path?))
(sandbox-namespace-specs spec) -> void?
  spec : (cons/c (-> namespace?)
                 (listof module-path?))
procedure
(sandbox-make-namespace) -> namespace?
parameter
(sandbox-gui-available) -> boolean?
(sandbox-gui-available avail?) -> void?
  avail? : any/c
parameter
(sandbox-override-collection-paths) -> (listof path-string?)
(sandbox-override-collection-paths paths) -> void?
  paths : (listof path-string?)
parameter
(sandbox-security-guard)
 -> (or/c security-guard? (-> security-guard?))
(sandbox-security-guard guard) -> void?
  guard : (or/c security-guard? (-> security-guard?))
parameter
(sandbox-path-permissions)
 -> (listof (list/c (or/c 'execute 'write 'delete
                          'read-bytecode 'read 'exists)
                    (or/c byte-regexp? bytes? string? path?)))
(sandbox-path-permissions perms) -> void?
  perms : (listof (list/c (or/c 'execute 'write 'delete
                                'read-bytecode 'read 'exists)
                          (or/c byte-regexp? bytes? string? path?)))
parameter
(sandbox-network-guard)
 -> (symbol?
     (or/c (and/c string? immutable?) #f)
     (or/c (integer-in 1 65535) #f)
     (or/c 'server 'client)
     . -> . any)
(sandbox-network-guard proc) -> void?
  proc : (symbol?
          (or/c (and/c string? immutable?) #f)
          (or/c (integer-in 1 65535) #f)
          (or/c 'server 'client)
          . -> . any)
parameter
(sandbox-exit-handler) -> (any/c . -> . any)
(sandbox-exit-handler handler) -> void?
  handler : (any/c . -> . any)
parameter
(sandbox-memory-limit) -> (or/c (>=/c 0) #f)
(sandbox-memory-limit limit) -> void?
  limit : (or/c (>=/c 0) #f)
parameter
(sandbox-eval-limits) -> (or/c (list/c (or/c (>=/c 0) #f)
                                       (or/c (>=/c 0) #f))
                               #f)
(sandbox-eval-limits limits) -> void?
  limits : (or/c (list/c (or/c (>=/c 0) #f)
                         (or/c (>=/c 0) #f))
                 #f)
parameter
(sandbox-eval-handlers)
 -> (list/c (or/c #f ((-> any) . -> . any))
            (or/c #f ((-> any) . -> . any)))
(sandbox-eval-handlers handlers) -> void?
  handlers : (list/c (or/c #f ((-> any) . -> . any))
                     (or/c #f ((-> any) . -> . any)))
parameter
(sandbox-run-submodules) -> (list/c symbol?)
(sandbox-run-submodules submod-syms) -> void?
  submod-syms : (list/c symbol?)
parameter
(sandbox-make-inspector) -> (-> inspector?)
(sandbox-make-inspector make) -> void?
  make : (-> inspector?)
parameter
(sandbox-make-code-inspector) -> (-> inspector?)
(sandbox-make-code-inspector make) -> void?
  make : (-> inspector?)
parameter
(sandbox-make-logger) -> (-> logger?)
(sandbox-make-logger make) -> void?
  make : (-> logger?)
parameter
(sandbox-make-plumber) -> (or/c (-> plumber?) 'propagate)
(sandbox-make-plumber make) -> void?
  make : (or/c (-> plumber?) 'propagate)
parameter
(sandbox-make-environment-variables)
 -> (-> environment-variables?)
(sandbox-make-environment-variables make) -> void?
  make : (-> environment-variables?)
procedure
(evaluator-alive? evaluator) -> boolean?
  evaluator : (any/c . -> . any)
procedure
(kill-evaluator evaluator) -> void?
  evaluator : (any/c . -> . any)
procedure
(break-evaluator evaluator) -> void?
  evaluator : (any/c . -> . any)
procedure
(get-user-custodian evaluator) -> void?
  evaluator : (any/c . -> . any)
procedure
(set-eval-limits evaluator secs mb) -> void?
  evaluator : (any/c . -> . any)
  secs : (or/c exact-nonnegative-integer? #f)
  mb : (or/c exact-nonnegative-integer? #f)
procedure
(set-eval-handler evaluator handler) -> void?
  evaluator : (any/c . -> . any)
  handler : (or/c #f ((-> any) . -> . any))
procedure
(call-with-custodian-shutdown thunk) -> any
  thunk : (-> any)
(call-with-killing-threads thunk) -> any
  thunk : (-> any)
procedure
(put-input evaluator) -> output-port?
  evaluator : (any/c . -> . any)
(put-input evaluator i/o) -> void?
  evaluator : (any/c . -> . any)
  i/o : (or/c bytes? string? eof-object?)
procedure
(get-output evaluator) -> (or/c #f input-port? bytes? string?)
  evaluator : (any/c . -> . any)
(get-error-output evaluator)
 -> (or/c #f input-port? bytes? string?)
  evaluator : (any/c . -> . any)
procedure
(get-uncovered-expressions  evaluator     
                           [prog?         
                            src])     -> (listof syntax?)
  evaluator : (any/c . -> . any)
  prog? : any/c = #t
  src : any/c = default-src
procedure
(call-in-sandbox-context  evaluator           
                          thunk               
                         [unrestricted?]) -> any
  evaluator : (any/c . -> . any)
  thunk : (-> any)
  unrestricted? : boolean? = #f
value
gui? : boolean?
procedure
(call-with-limits secs mb thunk) -> any
  secs : (or/c exact-nonnegative-integer? #f)
  mb : (or/c exact-nonnegative-integer? #f)
  thunk : (-> any)
syntax
(with-limits sec-expr mb-expr body ...)
procedure
(call-with-deep-time-limit secs thunk) -> any
  secs : exact-nonnegative-integer?
  thunk : (-> any)
syntax
(with-deep-time-limit secs-expr body ...)
procedure
(exn:fail:resource? v) -> boolean?
  v : any/c
(exn:fail:resource-resource exn)
 -> (or/c 'time 'memory 'deep-time)
  exn : exn:fail:resource?
procedure
(path? v) -> boolean?
  v : any/c
procedure
(path-string? v) -> boolean?
  v : any/c
procedure
(path-for-some-system? v) -> boolean?
  v : any/c
procedure
(string->path str) -> path?
  str : string?
procedure
(bytes->path bstr [type]) -> path?
  bstr : bytes?
  type : (or/c 'unix 'windows) = (system-path-convention-type)
procedure
(path->string path) -> string?
  path : path?
procedure
(path->bytes path) -> bytes?
  path : path-for-some-system?
procedure
(string->path-element str) -> path?
  str : string?
procedure
(bytes->path-element bstr [type]) -> path-for-some-system?
  bstr : bytes?
  type : (or/c 'unix 'windows) = (system-path-convention-type)
procedure
(path-element->string path) -> string?
  path : path-element?
procedure
(path-element->bytes path) -> bytes?
  path : path-element?
procedure
(path<? a-path b-path ...) -> boolean?
  a-path : path?
  b-path : path?
procedure
(path-convention-type path) -> (or/c 'unix 'windows)
  path : path-for-some-system?
procedure
(system-path-convention-type) -> (or/c 'unix 'windows)
procedure
(build-path base sub ...) -> path-for-some-system?
  base : (or/c path-string? path-for-some-system? 'up 'same)
  sub : (or/c (and/c (or/c path-string? path-for-some-system?)
                     (not/c complete-path?))
              (or/c 'up 'same))
procedure
(build-path/convention-type type         
                            base         
                            sub ...) -> path-for-some-system?
  type : (or/c 'unix 'windows)
  base : (or/c path-string? path-for-some-system? 'up 'same)
  sub : (or/c (and/c (or/c path-string? path-for-some-system?)
                     (not/c complete-path?))
              (or/c 'up 'same))
procedure
(absolute-path? path) -> boolean?
  path : (or/c path-string? path-for-some-system?)
procedure
(relative-path? path) -> boolean?
  path : (or/c path-string? path-for-some-system?)
procedure
(complete-path? path) -> boolean?
  path : (or/c path-string? path-for-some-system?)
procedure
(path->complete-path path [base]) -> path-for-some-system?
  path : (or/c path-string? path-for-some-system?)
  base : (or/c path-string? path-for-some-system?)
       = (current-directory)
procedure
(path->directory-path path) -> path-for-some-system?
  path : (or/c path-string? path-for-some-system?)
procedure
(resolve-path path) -> path?
  path : path-string?
procedure
(cleanse-path path) -> path-for-some-system?
  path : (or/c path-string? path-for-some-system?)
procedure
(expand-user-path path) -> path?
  path : path-string?
procedure
(simplify-path path [use-filesystem?]) -> path-for-some-system?
  path : (or/c path-string? path-for-some-system?)
  use-filesystem? : boolean? = #t
procedure
(normal-case-path path) -> path-for-some-system?
  path : (or/c path-string? path-for-some-system?)
procedure
(split-path path) -> (or/c path-for-some-system? 'relative #f)
                     (or/c path-for-some-system? 'up 'same)
                     boolean?
  path : (or/c path-string? path-for-some-system?)
procedure
(explode-path path)
 -> (listof (or/c path-for-some-system? 'up 'same))
  path : (or/c path-string? path-for-some-system?)
procedure
(path-replace-suffix path suffix) -> path-for-some-system?
  path : (or/c path-string? path-for-some-system?)
  suffix : (or/c string? bytes?)
procedure
(path-add-suffix path suffix) -> path-for-some-system?
  path : (or/c path-string? path-for-some-system?)
  suffix : (or/c string? bytes?)
procedure
(reroot-path path root-path) -> path-for-some-system?
  path : (or/c path-string? path-for-some-system?)
  root-path : (or/c path-string? path-for-some-system?)
procedure
(file-name-from-path path) -> (or/c path-for-some-system? #f)
  path : (or/c path-string? path-for-some-system?)
procedure
(filename-extension path) -> (or/c bytes? #f)
  path : (or/c path-string? path-for-some-system?)
procedure
(find-relative-path  base                                
                     path                                
                    [#:more-than-root? more-than-root?]) 
 -> path-for-some-system?
  base : (or/c path-string? path-for-some-system?)
  path : (or/c path-string?  path-for-some-system?)
  more-than-root? : any/c = #f
procedure
(normalize-path path [wrt]) -> path?
  path : path-string?
  wrt : (and/c path-string? complete-path?)
      = (current-directory)
procedure
(path-element? path) -> boolean?
  path : any/c
procedure
(path-only path) -> (or/c #f path-for-some-system?)
  path : (or/c path-string? path-for-some-system?)
procedure
(simple-form-path path) -> path?
  path : path-string?
procedure
(some-system-path->string path) -> string?
  path : path-for-some-system?
procedure
(string->some-system-path str kind) -> path-for-some-system?
  str : string?
  kind : (or/c 'unix 'windows)
procedure
(shrink-path-wrt pth other-pths) -> (or/c #f path?)
  pth : path?
  other-pths : (listof path?)
procedure
(find-system-path kind) -> path?
  kind : symbol?
procedure
(path-list-string->path-list str                
                             default-path-list) 
 -> (listof path?)
  str : (or/c string? bytes?)
  default-path-list : (listof path?)
procedure
(find-executable-path  program        
                      [related        
                       deepest?]) -> (or/c path? #f)
  program : path-string?
  related : (or/c path-string? #f) = #f
  deepest? : any/c = #f
procedure
(file-exists? path) -> boolean?
  path : path-string?
procedure
(link-exists? path) -> boolean?
  path : path-string?
procedure
(delete-file path) -> void?
  path : path-string?
procedure
(rename-file-or-directory  old              
                           new              
                          [exists-ok?]) -> void?
  old : path-string?
  new : path-string?
  exists-ok? : any/c = #f
procedure
(file-or-directory-modify-seconds  path         
                                  [secs-n]) -> exact-integer?
  path : path-string?
  secs-n : #f = #f
(file-or-directory-modify-seconds path        
                                  secs-n) -> void?
  path : path-string?
  secs-n : exact-integer?
(file-or-directory-modify-seconds  path             
                                  [secs-n           
                                   fail-thunk]) -> any
  path : path-string?
  secs-n : (or/c exact-integer? #f) = #f
  fail-thunk : (-> any)
             = (lambda () (raise (make-exn:fail:filesystem ....)))
procedure
(file-or-directory-permissions path [mode])
 -> (listof (or/c 'read 'write 'execute))
  path : path-string?
  mode : #f = #f
(file-or-directory-permissions path mode) -> (integer-in 0 65535)
  path : path-string?
  mode : 'bits
(file-or-directory-permissions path mode) -> void
  path : path-string?
  mode : (integer-in 0 65535)
procedure
(file-or-directory-identity path [as-link?])
 -> exact-positive-integer?
  path : path-string?
  as-link? : any/c = #f
procedure
(file-size path) -> exact-nonnegative-integer?
  path : path-string?
procedure
(copy-file src dest [exists-ok?]) -> void?
  src : path-string?
  dest : path-string?
  exists-ok? : any/c = #f
procedure
(make-file-or-directory-link to path) -> void?
  to : path-string?
  path : path-string?
parameter
(current-force-delete-permissions) -> boolean?
(current-force-delete-permissions any/c) -> void?
  any/c : boolean?
parameter
(current-directory) -> (and/c path? complete-path?)
(current-directory path) -> void?
  path : path-string?
parameter
(current-directory-for-user) -> (and/c path? complete-path?)
(current-directory-for-user path) -> void?
  path : path-string?
procedure
(current-drive) -> path?
procedure
(directory-exists? path) -> boolean?
  path : path-string?
procedure
(make-directory path) -> void?
  path : path-string?
procedure
(delete-directory path) -> void?
  path : path-string?
procedure
(directory-list [path #:build? build?]) -> (listof path?)
  path : path-string? = (current-directory)
  build? : any/c = #f
procedure
(filesystem-root-list) -> (listof path?)
procedure
(filesystem-change-evt? v) -> boolean?
  v : any/c
procedure
(filesystem-change-evt path) -> filesystem-change-evt?
  path : path-string?
(filesystem-change-evt path failure-thunk) -> any
  path : path-string?
  failure-thunk : (-> any)
procedure
(filesystem-change-evt-cancel evt) -> void?
  evt : filesystem-change-evt?
syntax
(define-runtime-path id expr)
syntax
(define-runtime-paths (id ...) expr)
syntax
(define-runtime-path-list id expr)
syntax
(define-runtime-module-path-index id module-path-expr)
syntax
(runtime-require module-path)
syntax
(define-runtime-module-path id module-path)
syntax
(runtime-paths module-path)
procedure
(file->string path [#:mode mode-flag]) -> string?
  path : path-string?
  mode-flag : (or/c 'binary 'text) = 'binary
procedure
(file->bytes path [#:mode mode-flag]) -> bytes?
  path : path-string?
  mode-flag : (or/c 'binary 'text) = 'binary
procedure
(file->value path [#:mode mode-flag]) -> any
  path : path-string?
  mode-flag : (or/c 'binary 'text) = 'binary
procedure
(file->list path [proc #:mode mode-flag]) -> (listof any/c)
  path : path-string?
  proc : (input-port? . -> . any/c) = read
  mode-flag : (or/c 'binary 'text) = 'binary
procedure
(file->lines  path                        
             [#:mode mode-flag            
              #:line-mode line-mode]) -> (listof string?)
  path : path-string?
  mode-flag : (or/c 'binary 'text) = 'binary
  line-mode : (or/c 'linefeed 'return 'return-linefeed 'any 'any-one)
            = 'any
procedure
(file->bytes-lines  path                        
                   [#:mode mode-flag            
                    #:line-mode line-mode]) -> (listof bytes?)
  path : path-string?
  mode-flag : (or/c 'binary 'text) = 'binary
  line-mode : (or/c 'linefeed 'return 'return-linefeed 'any 'any-one)
            = 'any
procedure
(display-to-file  v                          
                  path                       
                 [#:mode mode-flag           
                  #:exists exists-flag]) -> void?
  v : any/c
  path : path-string?
  mode-flag : (or/c 'binary 'text) = 'binary
  exists-flag : (or/c 'error 'append 'update
                      'replace 'truncate 'truncate/replace)
              = 'error
procedure
(write-to-file  v                          
                path                       
               [#:mode mode-flag           
                #:exists exists-flag]) -> void?
  v : any/c
  path : path-string?
  mode-flag : (or/c 'binary 'text) = 'binary
  exists-flag : (or/c 'error 'append 'update
                      'replace 'truncate 'truncate/replace)
              = 'error
procedure
(display-lines-to-file  lst                        
                        path                       
                       [#:separator separator      
                        #:mode mode-flag           
                        #:exists exists-flag]) -> void?
  lst : list?
  path : path-string?
  separator : any/c = #"\n"
  mode-flag : (or/c 'binary 'text) = 'binary
  exists-flag : (or/c 'error 'append 'update
                      'replace 'truncate 'truncate/replace)
              = 'error
procedure
(copy-directory/files                                              
                      src                                          
                      dest                                         
                      #:keep-modify-seconds? keep-modify-seconds?) 
 -> void?
  src : path-string?
  dest : path-string?
  keep-modify-seconds? : #f
procedure
(delete-directory/files path                           
                        #:must-exist? must-exist?) -> void?
  path : path-string?
  must-exist? : #t
procedure
(find-files  predicate                          
            [start-path]                        
             #:follow-links? follow-links?) -> (listof path?)
  predicate : (path? . -> . any/c)
  start-path : (or/c path-string? #f) = #f
  follow-links? : #f
procedure
(pathlist-closure path-list                      
                  #:follow-links? follow-links?) 
 -> (listof path?)
  path-list : (listof path-string?)
  follow-links? : #f
procedure
(fold-files  proc                
             init-val            
            [start-path          
             follow-links?]) -> any
  proc : (or/c (path? (or/c 'file 'dir 'link) any/c
                 . -> . any/c)
               (path? (or/c 'file 'dir 'link) any/c
                 . -> . (values any/c any/c)))
  init-val : any/c
  start-path : (or/c path-string? #f) = #f
  follow-links? : any/c = #t
procedure
(make-directory* path) -> void?
  path : path-string?
procedure
(make-parent-directory* path) -> void?
  path : path-string?
procedure
(make-temporary-file [template               
                      copy-from-filename     
                      directory])        -> path?
  template : string? = "rkttmp~a"
  copy-from-filename : (or/c path-string? #f 'directory) = #f
  directory : (or/c path-string? #f) = #f
procedure
(call-with-atomic-output-file  file                              
                               proc                              
                              [#:security-guard security-guard]) 
 -> any
  file : path-string?
  proc : ([port output-port?] [tmp-path path?]  . -> . any)
  security-guard : (or/c #f security-guard?) = #f
procedure
(get-preference  name                                        
                [failure-thunk                               
                 flush-mode                                  
                 filename                                    
                 #:use-lock? use-lock?                       
                 #:timeout-lock-there timeout-lock-there     
                 #:lock-there lock-there])               -> any
  name : symbol?
  failure-thunk : (-> any) = (lambda () #f)
  flush-mode : any/c = 'timestamp
  filename : (or/c string-path? #f) = #f
  use-lock? : any/c = #t
  timeout-lock-there : (or/c (path? . -> . any) #f) = #f
  lock-there : (or/c (path? . -> . any) #f)
             = (make-handle-get-preference-locked
                0.01 name failure-thunk flush-mode filename
                #:lock-there timeout-lock-there)
procedure
(put-preferences  names           
                  vals            
                 [locked-proc     
                  filename])  -> void?
  names : (listof symbol?)
  vals : list?
  locked-proc : (or/c #f (path? . -> . any)) = #f
  filename : (or/c #f path-string?) = #f
procedure
(preferences-lock-file-mode) -> (or/c 'exists 'file-lock)
procedure
(make-handle-get-preference-locked  delay                   
                                    name                    
                                   [failure-thunk           
                                    flush-mode              
                                    filename                
                                    #:lock-there lock-there 
                                    #:max-delay max-delay]) 
 -> (path-string? . -> . any)
  delay : real?
  name : symbol?
  failure-thunk : (-> any) = (lambda () #f)
  flush-mode : any/c = 'timestamp
  filename : (or/c path-string? #f) = #f
  lock-there : (or/c (path? . -> . any) #f) = #f
  max-delay : real? = 0.2
procedure
(call-with-file-lock/timeout  filename                    
                              kind                        
                              thunk                       
                              failure-thunk               
                             [#:lock-file lock-file       
                              #:delay delay               
                              #:max-delay max-delay]) -> any
  filename : (or/c path-string? #f)
  kind : (or/c 'shared 'exclusive)
  thunk : (-> any)
  failure-thunk : (-> any)
  lock-file : (or/c #f path-string?) = #f
  delay : (and/c real? (not/c negative?)) = 0.01
  max-delay : (and/c real? (not/c negative?)) = 0.2
procedure
(make-lock-file-name path) -> path?
  path : (or path-string? path-for-some-system?)
(make-lock-file-name dir name) -> path?
  dir : (or path-string? path-for-some-system?)
  name : path-element?
value
user-read-bit : #o400
value
user-write-bit : #o200
value
user-execute-bit : #o100
value
group-read-bit : #o040
value
group-write-bit : #o020
value
group-execute-bit : #o010
value
other-read-bit : #o004
value
other-write-bit : #o002
value
other-execute-bit : #o001
procedure
(tcp-listen  port-no            
            [max-allow-wait     
             reuse?             
             hostname])     -> tcp-listener?
  port-no : (integer-in 0 65535)
  max-allow-wait : exact-nonnegative-integer? = 4
  reuse? : any/c = #f
  hostname : (or/c string? #f) = #f
procedure
(tcp-connect  hostname            
              port-no             
             [local-hostname      
              local-port-no]) -> input-port? output-port?
  hostname : string?
  port-no : (integer-in 1 65535)
  local-hostname : (or/c string? #f) = #f
  local-port-no : (or/c (integer-in 1 65535) #f) = #f
procedure
(tcp-connect/enable-break  hostname        
                           port-no         
                          [local-hostname] 
                           local-port-no)  
 -> input-port? output-port?
  hostname : string?
  port-no : (integer-in 1 65535)
  local-hostname : (or/c string? #f) = #f
  local-port-no : (or/c (integer-in 1 65535) #f)
procedure
(tcp-accept listener) -> input-port? output-port?
  listener : tcp-listener?
procedure
(tcp-accept/enable-break listener) -> input-port? output-port?
  listener : tcp-listener?
procedure
(tcp-accept-ready? listener) -> boolean?
  listener : tcp-listener?
procedure
(tcp-close listener) -> void?
  listener : tcp-listener?
procedure
(tcp-listener? v) -> boolean?
  v : any/c
procedure
(tcp-accept-evt listener) -> evt?
  listener : tcp-listener?
procedure
(tcp-abandon-port tcp-port) -> void?
  tcp-port : tcp-port?
procedure
(tcp-addresses tcp-port [port-numbers?])
 -> (or/c (values string? string?)
          (values string? (integer-in 1 65535)
                  string? (integer-in 0 65535)))
  tcp-port : (or/c tcp-port? tcp-listener?)
  port-numbers? : any/c = #f
procedure
(tcp-port? v) -> boolean?
  v : any/c
procedure
(udp-open-socket [family-hostname      
                  family-port-no]) -> udp?
  family-hostname : (or/c string? #f) = #f
  family-port-no : (or/c (integer-in 1 65535) #f) = #f
procedure
(udp-bind!  udp-socket          
            hostname-string     
            port-no             
           [reuse?])        -> void?
  udp-socket : udp?
  hostname-string : (or/c string? #f)
  port-no : (integer-in 0 65535)
  reuse? : any/c = #f
procedure
(udp-connect! udp-socket          
              hostname-string     
              port-no)        -> void?
  udp-socket : udp?
  hostname-string : (or/c string? #f)
  port-no : (or/c (integer-in 1 65535)
                  #f)
procedure
(udp-send-to  udp-socket     
              hostname       
              port-no        
              bstr           
             [start-pos      
              end-pos])  -> void
  udp-socket : udp?
  hostname : string?
  port-no : (integer-in 1 65535)
  bstr : bytes?
  start-pos : exact-nonnegative-integer? = 0
  end-pos : exact-nonnegative-integer? = (bytes-length bstr)
procedure
(udp-send udp-socket bstr [start-pos end-pos]) -> void
  udp-socket : udp?
  bstr : bytes?
  start-pos : exact-nonnegative-integer? = 0
  end-pos : exact-nonnegative-integer? = (bytes-length bstr)
procedure
(udp-send-to*  udp-socket     
               hostname       
               port-no        
               bstr           
              [start-pos      
               end-pos])  -> boolean?
  udp-socket : udp?
  hostname : string?
  port-no : (integer-in 1 65535)
  bstr : bytes?
  start-pos : exact-nonnegative-integer? = 0
  end-pos : exact-nonnegative-integer? = (bytes-length bstr)
procedure
(udp-send* udp-socket bstr [start-pos end-pos]) -> boolean?
  udp-socket : udp?
  bstr : bytes?
  start-pos : exact-nonnegative-integer? = 0
  end-pos : exact-nonnegative-integer? = (bytes-length bstr)
procedure
(udp-send-to/enable-break  udp-socket     
                           hostname       
                           port-no        
                           bstr           
                          [start-pos      
                           end-pos])  -> void
  udp-socket : udp?
  hostname : string?
  port-no : (integer-in 1 65535)
  bstr : bytes?
  start-pos : exact-nonnegative-integer? = 0
  end-pos : exact-nonnegative-integer? = (bytes-length bstr)
procedure
(udp-send/enable-break  udp-socket     
                        bstr           
                       [start-pos      
                        end-pos])  -> void
  udp-socket : udp?
  bstr : bytes?
  start-pos : exact-nonnegative-integer? = 0
  end-pos : exact-nonnegative-integer? = (bytes-length bstr)
procedure
(udp-receive!  udp-socket     
               bstr           
              [start-pos      
               end-pos])  -> exact-nonnegative-integer?
                             string?
                             (integer-in 1 65535)
  udp-socket : udp?
  bstr : (and/c bytes? (not immutable?))
  start-pos : exact-nonnegative-integer? = 0
  end-pos : exact-nonnegative-integer? = (bytes-length bstr)
procedure
(udp-receive!*  udp-socket 
                bstr       
               [start-pos  
                end-pos])  
 -> (or/c exact-nonnegative-integer? #f)
    (or/c string? #f)
    (or/c (integer-in 1 65535) #f)
  udp-socket : udp?
  bstr : (and/c bytes? (not immutable?))
  start-pos : exact-nonnegative-integer? = 0
  end-pos : exact-nonnegative-integer? = (bytes-length bstr)
procedure
(udp-receive!/enable-break  udp-socket 
                            bstr       
                           [start-pos  
                            end-pos])  
 -> exact-nonnegative-integer?
    string?
    (integer-in 1 65535)
  udp-socket : udp?
  bstr : (and/c bytes? (not immutable?))
  start-pos : exact-nonnegative-integer? = 0
  end-pos : exact-nonnegative-integer? = (bytes-length bstr)
procedure
(udp-close udp-socket) -> void?
  udp-socket : udp?
procedure
(udp? v) -> boolean?
  v : any/c
procedure
(udp-bound? udp-socket) -> boolean?
  udp-socket : udp?
procedure
(udp-connected? udp-socket) -> boolean?
  udp-socket : udp?
procedure
(udp-send-ready-evt udp-socket) -> evt?
  udp-socket : udp?
procedure
(udp-receive-ready-evt udp-socket) -> evt?
  udp-socket : udp?
procedure
(udp-send-to-evt  udp-socket     
                  hostname       
                  port-no        
                  bstr           
                 [start-pos      
                  end-pos])  -> evt?
  udp-socket : udp?
  hostname : string?
  port-no : (integer-in 1 65535)
  bstr : bytes?
  start-pos : exact-nonnegative-integer? = 0
  end-pos : exact-nonnegative-integer? = (bytes-length bstr)
procedure
(udp-send-evt  udp-socket     
               bstr           
              [start-pos      
               end-pos])  -> evt?
  udp-socket : udp?
  bstr : bytes?
  start-pos : exact-nonnegative-integer? = 0
  end-pos : exact-nonnegative-integer? = (bytes-length bstr)
procedure
(udp-receive!-evt  udp-socket     
                   bstr           
                  [start-pos      
                   end-pos])  -> evt?
  udp-socket : udp?
  bstr : (and/c bytes? (not immutable?))
  start-pos : exact-nonnegative-integer? = 0
  end-pos : exact-nonnegative-integer? = (bytes-length bstr)
procedure
(udp-addresses udp-port [port-numbers?])
 -> (or/c (values string? string?)
          (values string? (integer-in 0 65535)
                  string? (integer-in 0 65535)))
  udp-port : udp?
  port-numbers? : any/c = #f
procedure
(udp-multicast-join-group! udp-socket         
                           multicast-addr     
                           hostname)      -> void?
  udp-socket : udp?
  multicast-addr : string?
  hostname : (or/c string? #f)
procedure
(udp-multicast-leave-group! udp-socket         
                            multicast-addr     
                            hostname)      -> void?
  udp-socket : udp?
  multicast-addr : string?
  hostname : (or/c string? #f)
procedure
(udp-multicast-interface udp-socket) -> string?
  udp-socket : udp?
procedure
(udp-multicast-set-interface! udp-socket     
                              hostname)  -> void?
  udp-socket : udp?
  hostname : (or/c string? #f)
procedure
(udp-multicast-set-loopback! udp-socket     
                             loopback?) -> void?
  udp-socket : udp?
  loopback? : any/c
procedure
(udp-multicast-loopback? udp-socket) -> boolean?
  udp-socket : udp?
procedure
(udp-multicast-set-ttl! udp-socket ttl) -> void?
  udp-socket : udp?
  ttl : byte?
procedure
(udp-multicast-ttl udp-socket) -> byte?
  udp-socket : udp?
procedure
(subprocess stdout   
            stdin    
            stderr   
            command  
            arg ...) 
 -> subprocess?
    (or/c (and/c input-port? file-stream-port?) #f)
    (or/c (and/c output-port? file-stream-port?) #f)
    (or/c (and/c input-port? file-stream-port?) #f)
  stdout : (or/c (and/c output-port? file-stream-port?) #f)
  stdin : (or/c (and/c input-port? file-stream-port?) #f)
  stderr : (or/c (and/c output-port? file-stream-port?) #f 'stdout)
  command : path-string?
  arg : (or/c path? string-no-nuls? bytes-no-nuls?)
(subprocess stdout  
            stdin   
            stderr  
            command 
            exact   
            arg)    
 -> subprocess?
    (or/c (and/c input-port? file-stream-port?) #f)
    (or/c (and/c output-port? file-stream-port?) #f)
    (or/c (and/c input-port? file-stream-port?) #f)
  stdout : (or/c (and/c output-port? file-stream-port?) #f)
  stdin : (or/c (and/c input-port? file-stream-port?) #f)
  stderr : (or/c (and/c output-port? file-stream-port?) #f)
  command : path-string?
  exact : 'exact
  arg : string?
procedure
(subprocess-wait subproc) -> void?
  subproc : subprocess?
procedure
(subprocess-status subproc) -> (or/c 'running
                                     exact-nonnegative-integer?)
  subproc : subprocess?
procedure
(subprocess-kill subproc force?) -> void?
  subproc : subprocess?
  force? : any/c
procedure
(subprocess-pid subproc) -> exact-nonnegative-integer?
  subproc : subprocess?
procedure
(subprocess? v) -> boolean?
  v : any/c
parameter
(current-subprocess-custodian-mode)
 -> (or/c #f 'kill 'interrupt)
(current-subprocess-custodian-mode mode) -> void?
  mode : (or/c #f 'kill 'interrupt)
parameter
(subprocess-group-enabled) -> boolean?
(subprocess-group-enabled on?) -> void?
  on? : any/c
procedure
(shell-execute verb           
               target         
               parameters     
               dir            
               show-mode) -> #f
  verb : (or/c string? #f)
  target : string?
  parameters : string?
  dir : path-string?
  show-mode : symbol?
procedure
(system command [#:set-pwd? set-pwd?]) -> boolean?
  command : (or/c string-no-nuls? bytes-no-nuls?)
  set-pwd? : any/c = (member (system-type) '(unix macosx))
procedure
(system* command arg ... [#:set-pwd? set-pwd?]) -> boolean?
  command : path-string?
  arg : (or/c path? string-no-nuls? bytes-no-nuls?)
  set-pwd? : any/c = (member (system-type) '(unix macosx))
(system*  command                   
          exact                     
          arg                       
         [#:set-pwd? set-pwd?]) -> boolean?
  command : path-string?
  exact : 'exact
  arg : string?
  set-pwd? : any/c = (member (system-type) '(unix macosx))
procedure
(system/exit-code  command                   
                  [#:set-pwd? set-pwd?]) -> byte?
  command : (or/c string-no-nuls? bytes-no-nuls?)
  set-pwd? : any/c = (member (system-type) '(unix macosx))
procedure
(system*/exit-code  command                   
                    arg ...                   
                   [#:set-pwd? set-pwd?]) -> byte?
  command : path-string?
  arg : (or/c path? string-no-nuls? bytes-no-nuls?)
  set-pwd? : any/c = (member (system-type) '(unix macosx))
(system*/exit-code  command                   
                    exact                     
                    arg                       
                   [#:set-pwd? set-pwd?]) -> byte?
  command : path-string?
  exact : 'exact
  arg : string?
  set-pwd? : any/c = (member (system-type) '(unix macosx))
procedure
(process command [#:set-pwd? set-pwd?])
 -> (list input-port?
          output-port?
          exact-nonnegative-integer?
          input-port?
          ((or/c 'status 'wait 'interrupt 'kill) . -> . any))
  command : (or/c string-no-nuls? bytes-no-nuls?)
  set-pwd? : any/c = (member (system-type) '(unix macosx))
procedure
(process*  command                   
           arg ...                   
          [#:set-pwd? set-pwd?]) -> list?
  command : path-string?
  arg : (or/c path? string-no-nuls? bytes-no-nuls?)
  set-pwd? : any/c = (member (system-type) '(unix macosx))
(process*  command                   
           exact                     
           arg                       
          [#:set-pwd? set-pwd?]) -> list?
  command : path-string?
  exact : 'exact
  arg : string?
  set-pwd? : any/c = (member (system-type) '(unix macosx))
procedure
(process/ports  out                       
                in                        
                error-out                 
                command                   
               [#:set-pwd? set-pwd?]) -> list?
  out : (or/c #f output-port?)
  in : (or/c #f input-port?)
  error-out : (or/c #f output-port? 'stdout)
  command : (or/c path? string-no-nuls? bytes-no-nuls?)
  set-pwd? : any/c = (member (system-type) '(unix macosx))
procedure
(process*/ports  out                       
                 in                        
                 error-out                 
                 command                   
                 arg ...                   
                [#:set-pwd? set-pwd?]) -> list?
  out : (or/c #f output-port?)
  in : (or/c #f input-port?)
  error-out : (or/c #f output-port? 'stdout)
  command : path-string?
  arg : (or/c path? string-no-nuls? bytes-no-nuls?)
  set-pwd? : any/c = (member (system-type) '(unix macosx))
(process*/ports  out                       
                 in                        
                 error-out                 
                 command                   
                 exact                     
                 arg                       
                [#:set-pwd? set-pwd?]) -> list?
  out : (or/c #f output-port?)
  in : (or/c #f input-port?)
  error-out : (or/c #f output-port? 'stdout)
  command : path-string?
  exact : 'exact
  arg : string?
  set-pwd? : any/c = (member (system-type) '(unix macosx))
procedure
(string-no-nuls? x) -> boolean?
  x : any/c
procedure
(bytes-no-nuls? x) -> boolean?
  x : any/c
procedure
(logger? v) -> boolean?
  v : any/c
procedure
(make-logger [topic                    
              parent                   
              propagate-level          
              propagate-topic ...]     
              ...)                 -> logger?
  topic : (or/c symbol? #f) = #f
  parent : (or/c logger? #f) = #f
  propagate-level : (or/c 'none 'fatal 'error 'warning 'info 'debug)
                  = 'debug
  propagate-topic : (or/c #f symbol?) = #f
procedure
(logger-name logger) -> (or/c symbol? #f)
  logger : logger?
parameter
(current-logger) -> logger?
(current-logger logger) -> void?
  logger : logger?
syntax
(define-logger id)
procedure
(log-message  logger                
              level                 
             [topic]                
              message               
              data                  
             [prefix-message?]) -> void?
  logger : logger?
  level : (or/c 'fatal 'error 'warning 'info 'debug)
  topic : (or/c symbol? #f) = (logger-name logger)
  message : string?
  data : any/c
  prefix-message? : any/c = #t
procedure
(log-level? logger level [topic]) -> boolean?
  logger : logger?
  level : (or/c 'fatal 'error 'warning 'info 'debug)
  topic : (or/c symbol? #f) = #f
procedure
(log-max-level logger [topic])
 -> (or/c #f 'fatal 'error 'warning 'info 'debug)
  logger : logger?
  topic : (or/c symbol? #f) = #f
procedure
(log-all-levels logger)
 -> (list/c (or/c #f 'fatal 'error 'warning 'info 'debug)
            (or/c #f symbol?)
            ... ...)
  logger : logger?
procedure
(log-level-evt logger) -> evt?
  logger : logger?
syntax
(log-fatal string-expr)
(log-fatal format-string-expr v ...)
syntax
(log-error string-expr)
(log-error format-string-expr v ...)
syntax
(log-warning string-expr)
(log-warning format-string-expr v ...)
syntax
(log-info string-expr)
(log-info format-string-expr v ...)
syntax
(log-debug string-expr)
(log-debug format-string-expr v ...)
procedure
(log-receiver? v) -> boolean?
  v : any/c
procedure
(make-log-receiver logger level [topic ...] ...) -> log-receiver?
  logger : logger?
  level : (or/c 'none 'fatal 'error 'warning 'info 'debug)
  topic : (or/c #f symbol?) = #f
procedure
(current-seconds) -> exact-integer?
procedure
(current-inexact-milliseconds) -> real?
procedure
(seconds->date secs-n [local-time?]) -> date*?
  secs-n : real?
  local-time? : any/c = #t
struct
(struct date (second
              minute
              hour
              day
              month
              year
              week-day
              year-day
              dst?
              time-zone-offset)
    #:extra-constructor-name make-date
    #:transparent)
  second : (integer-in 0 60)
  minute : (integer-in 0 59)
  hour : (integer-in 0 23)
  day : (integer-in 1 31)
  month : (integer-in 1 12)
  year : exact-integer?
  week-day : (integer-in 0 6)
  year-day : (integer-in 0 365)
  dst? : boolean?
  time-zone-offset : exact-integer?
struct
(struct date* date (nanosecond time-zone-name)
    #:extra-constructor-name make-date*)
  nanosecond : (integer-in 0 999999999)
  time-zone-name : (and/c string? immutable?)
procedure
(current-milliseconds) -> exact-integer?
procedure
(current-process-milliseconds [scope]) -> exact-integer?
  scope : (or/c #f thread? 'subprocesses) = #f
procedure
(current-gc-milliseconds) -> exact-integer?
procedure
(time-apply proc lst) -> list?
                         exact-integer?
                         exact-integer?
                         exact-integer?
  proc : procedure?
  lst : list?
syntax
(time body ...+)
procedure
(current-date) -> date*?
procedure
(date->string date [time?]) -> string?
  date : date?
  time? : any/c = #f
parameter
(date-display-format) -> (or/c 'american
                               'chinese
                               'german
                               'indian
                               'irish
                               'iso-8601
                               'rfc2822
                               'julian)
(date-display-format format) -> void?
  format : (or/c 'american
                 'chinese
                 'german
                 'indian
                 'irish
                 'iso-8601
                 'rfc2822
                 'julian)
procedure
(date->seconds date [local-time?]) -> exact-integer?
  date : date?
  local-time? : any/c = #t
procedure
(date*->seconds date [local-time?]) -> real?
  date : date?
  local-time? : any/c = #t
procedure
(find-seconds  second            
               minute            
               hour              
               day               
               month             
               year              
              [local-time?]) -> exact-integer?
  second : (integer-in 0 61)
  minute : (integer-in 0 59)
  hour : (integer-in 0 23)
  day : (integer-in 1 31)
  month : (integer-in 1 12)
  year : exact-nonnegative-integer?
  local-time? : any/c = #t
procedure
(date->julian/scalinger date) -> exact-integer?
  date : date?
procedure
(julian/scalinger->string date-number) -> string?
  date-number : exact-integer?
procedure
(environment-variables? v) -> boolean?
  v : any/c
parameter
(current-environment-variables) -> environment-variables?
(current-environment-variables env) -> void?
  env : environment-variables?
procedure
(bytes-environment-variable-name? v) -> boolean?
  v : any/c
procedure
(make-environment-variables name val ... ...)
 -> environment-variables?
  name : bytes-environment-variable-name?
  val : bytes-no-nuls?
procedure
(environment-variables-ref env name)
 -> (or/c #f (and/c bytes-no-nuls? immutable?))
  env : environment-variables?
  name : bytes-environment-variable-name?
procedure
(environment-variables-set!  env            
                             name           
                             maybe-bstr     
                            [fail])     -> any
  env : environment-variables?
  name : bytes-environment-variable-name?
  maybe-bstr : (or/c bytes-no-nuls? #f)
  fail : (-> any) = (lambda ()
                      (raise (make-exn:fail ....)))
procedure
(environment-variables-names env)
 -> (listof (and/c bytes-environment-variable-name? immutable?))
  env : environment-variables?
procedure
(environment-variables-copy env) -> environment-variables?
  env : environment-variables?
procedure
(getenv name) -> (or/c string-no-nuls? #f)
  name : string-environment-variable-name?
procedure
(putenv name value) -> boolean?
  name : string-environment-variable-name?
  value : string-no-nuls?
procedure
(string-environment-variable-name? v) -> boolean?
  v : any/c
procedure
(system-type [mode])
 -> (or/c symbol? string? bytes? exact-positive-integer? vector?)
  mode : (or/c 'os 'word 'gc 'link 'machine    = 'os
               'so-suffix 'so-mode 'fs-change)
procedure
(system-language+country) -> string?
procedure
(system-library-subpath [mode]) -> path?
  mode : (or/c 'cgc '3m #f) = (system-type 'gc)
procedure
(version) -> (and/c string? immutable?)
procedure
(banner) -> (and/c string? immutable?)
parameter
(current-command-line-arguments) -> (vectorof string?)
(current-command-line-arguments argv) -> void?
  argv : (vectorof (and/c string? immutable?))
parameter
(current-thread-initial-stack-size) -> exact-positive-integer?
(current-thread-initial-stack-size size) -> void?
  size : exact-positive-integer?
procedure
(vector-set-performance-stats! results [thd]) -> void?
  results : (and/c vector?
                   (not/c immutable?))
  thd : (or/c thread? #f) = #f
syntax
(command-line optional-name-expr optional-argv-expr
              flag-clause ...
              finish-clause)
 
optional-name-expr = 
                   | #:program name-expr
                      
optional-argv-expr = 
                   | #:argv argv-expr
                      
       flag-clause = #:multi flag-spec ...
                   | #:once-each flag-spec ...
                   | #:once-any flag-spec ...
                   | #:final flag-spec ...
                   | #:usage-help string ...
                   | #:help-labels string ...
                   | #:ps string ...
                      
         flag-spec = (flags id ... help-spec body ...+)
                   | (flags => handler-expr help-expr)
                      
             flags = flag-string
                   | (flag-string ...+)
                      
         help-spec = string
                   | (string-expr ...+)
                      
     finish-clause = 
                   | #:args arg-formals body ...+
                   | #:handlers handlers-exprs
                      
       arg-formals = rest-id
                   | (arg ...)
                   | (arg ...+ . rest-id)
                      
               arg = id
                   | [id default-expr]
                      
    handlers-exprs = finish-expr arg-strings-expr
                   | finish-expr arg-strings-expr help-expr
                   | finish-expr arg-strings-expr help-expr
                     unknown-expr
procedure
(parse-command-line  name               
                     argv               
                     table              
                     finish-proc        
                     arg-help-strs      
                    [help-proc          
                     unknown-proc]) -> any
  name : (or/c string? path?)
  argv : (or/c (listof string?) (vectorof string?))
  table : (listof (cons/c symbol? list?))
  finish-proc : ((list?) () #:rest list? . ->* . any)
  arg-help-strs : (listof string?)
  help-proc : (string? . -> . any) = (lambda (str) ....)
  unknown-proc : (string? . -> . any) = (lambda (str) ...)
procedure
(make-weak-box v) -> weak-box?
  v : any/c
procedure
(weak-box-value weak-box [gced-v]) -> any/c
  weak-box : weak-box?
  gced-v : any/c = #f
procedure
(weak-box? v) -> boolean?
  v : any/c
procedure
(make-ephemeron key v) -> ephemeron?
  key : any/c
  v : any/c
procedure
(ephemeron-value ephemeron [gced-v]) -> any/c
  ephemeron : ephemeron?
  gced-v : any/c = #f
procedure
(ephemeron? v) -> boolean?
  v : any/c
procedure
(make-will-executor) -> will-executor?
procedure
(will-executor? v) -> boolean?
  v : any/c
procedure
(will-register executor v proc) -> void?
  executor : will-executor?
  v : any/c
  proc : (any/c . -> . any)
procedure
(will-execute executor) -> any
  executor : will-executor?
procedure
(will-try-execute executor) -> any
  executor : any/c
procedure
(collect-garbage) -> void?
procedure
(current-memory-use [cust]) -> exact-nonnegative-integer?
  cust : custodian? = #f
procedure
(dump-memory-stats v ...) -> any
  v : any/c
procedure
(phantom-bytes? v) -> boolean?
  v : any/c
procedure
(make-phantom-bytes k) -> phantom-bytes?
  k : exact-nonnegative-integer?
procedure
(set-phantom-bytes! phantom-bstr k) -> phantom-bytes?
  phantom-bstr : phantom-bytes?
  k : exact-nonnegative-integer?
procedure
(unsafe-fx+ a b) -> fixnum?
  a : fixnum?
  b : fixnum?
procedure
(unsafe-fx- a b) -> fixnum?
  a : fixnum?
  b : fixnum?
procedure
(unsafe-fx* a b) -> fixnum?
  a : fixnum?
  b : fixnum?
procedure
(unsafe-fxquotient a b) -> fixnum?
  a : fixnum?
  b : fixnum?
procedure
(unsafe-fxremainder a b) -> fixnum?
  a : fixnum?
  b : fixnum?
procedure
(unsafe-fxmodulo a b) -> fixnum?
  a : fixnum?
  b : fixnum?
procedure
(unsafe-fxabs a) -> fixnum?
  a : fixnum?
procedure
(unsafe-fxand a b) -> fixnum?
  a : fixnum?
  b : fixnum?
procedure
(unsafe-fxior a b) -> fixnum?
  a : fixnum?
  b : fixnum?
procedure
(unsafe-fxxor a b) -> fixnum?
  a : fixnum?
  b : fixnum?
procedure
(unsafe-fxnot a) -> fixnum?
  a : fixnum?
procedure
(unsafe-fxlshift a b) -> fixnum?
  a : fixnum?
  b : fixnum?
procedure
(unsafe-fxrshift a b) -> fixnum?
  a : fixnum?
  b : fixnum?
procedure
(unsafe-fx= a b) -> boolean?
  a : fixnum?
  b : fixnum?
procedure
(unsafe-fx< a b) -> boolean?
  a : fixnum?
  b : fixnum?
procedure
(unsafe-fx> a b) -> boolean?
  a : fixnum?
  b : fixnum?
procedure
(unsafe-fx<= a b) -> boolean?
  a : fixnum?
  b : fixnum?
procedure
(unsafe-fx>= a b) -> boolean?
  a : fixnum?
  b : fixnum?
procedure
(unsafe-fxmin a b) -> fixnum?
  a : fixnum?
  b : fixnum?
procedure
(unsafe-fxmax a b) -> fixnum?
  a : fixnum?
  b : fixnum?
procedure
(unsafe-fl+ a b) -> flonum?
  a : flonum?
  b : flonum?
procedure
(unsafe-fl- a b) -> flonum?
  a : flonum?
  b : flonum?
procedure
(unsafe-fl* a b) -> flonum?
  a : flonum?
  b : flonum?
procedure
(unsafe-fl/ a b) -> flonum?
  a : flonum?
  b : flonum?
procedure
(unsafe-flabs a) -> flonum?
  a : flonum?
procedure
(unsafe-fl= a b) -> boolean?
  a : flonum?
  b : flonum?
procedure
(unsafe-fl< a b) -> boolean?
  a : flonum?
  b : flonum?
procedure
(unsafe-fl> a b) -> boolean?
  a : flonum?
  b : flonum?
procedure
(unsafe-fl<= a b) -> boolean?
  a : flonum?
  b : flonum?
procedure
(unsafe-fl>= a b) -> boolean?
  a : flonum?
  b : flonum?
procedure
(unsafe-flmin a b) -> flonum?
  a : flonum?
  b : flonum?
procedure
(unsafe-flmax a b) -> flonum?
  a : flonum?
  b : flonum?
procedure
(unsafe-flround a) -> flonum?
  a : flonum?
procedure
(unsafe-flfloor a) -> flonum?
  a : flonum?
procedure
(unsafe-flceiling a) -> flonum?
  a : flonum?
procedure
(unsafe-fltruncate a) -> flonum?
  a : flonum?
procedure
(unsafe-flsin a) -> flonum?
  a : flonum?
procedure
(unsafe-flcos a) -> flonum?
  a : flonum?
procedure
(unsafe-fltan a) -> flonum?
  a : flonum?
procedure
(unsafe-flasin a) -> flonum?
  a : flonum?
procedure
(unsafe-flacos a) -> flonum?
  a : flonum?
procedure
(unsafe-flatan a) -> flonum?
  a : flonum?
procedure
(unsafe-fllog a) -> flonum?
  a : flonum?
procedure
(unsafe-flexp a) -> flonum?
  a : flonum?
procedure
(unsafe-flsqrt a) -> flonum?
  a : flonum?
procedure
(unsafe-flexpt a b) -> flonum?
  a : flonum?
  b : flonum?
procedure
(unsafe-make-flrectangular a b)
 -> (and/c complex?
           (lambda (c) (flonum? (real-part c)))
           (lambda (c) (flonum? (imag-part c))))
  a : flonum?
  b : flonum?
procedure
(unsafe-flreal-part a) -> flonum?
  a : (and/c complex?
             (lambda (c) (flonum? (real-part c)))
             (lambda (c) (flonum? (imag-part c))))
procedure
(unsafe-flimag-part a) -> flonum?
  a : (and/c complex?
             (lambda (c) (flonum? (real-part c)))
             (lambda (c) (flonum? (imag-part c))))
procedure
(unsafe-fx->fl a) -> flonum?
  a : fixnum?
procedure
(unsafe-fl->fx a) -> fixnum?
  a : flonum?
procedure
(unsafe-flrandom rand-gen) -> (and flonum? (>/c 0) (</c 1))
  rand-gen : pseudo-random-generator?
procedure
(unsafe-car p) -> any/c
  p : pair?
procedure
(unsafe-cdr p) -> any/c
  p : pair?
procedure
(unsafe-mcar p) -> any/c
  p : mpair?
procedure
(unsafe-mcdr p) -> any/c
  p : mpair?
procedure
(unsafe-set-mcar! p v) -> void?
  p : mpair?
  v : any/c
procedure
(unsafe-set-mcdr! p v) -> void?
  p : mpair?
  v : any/c
procedure
(unsafe-cons-list v rest) -> (and/c pair? list?)
  v : any/c
  rest : list?
procedure
(unsafe-list-ref lst pos) -> any/c
  lst : pair?
  pos : (and/c exact-nonnegative-integer? fixnum?)
procedure
(unsafe-list-tail lst pos) -> any/c
  lst : any/c
  pos : (and/c exact-nonnegative-integer? fixnum?)
procedure
(unsafe-unbox b) -> fixnum?
  b : box?
procedure
(unsafe-set-box! b k) -> void?
  b : box?
  k : fixnum?
procedure
(unsafe-unbox* v) -> any/c
  v : (and/c box? (not/c impersonator?))
procedure
(unsafe-set-box*! v val) -> void?
  v : (and/c box? (not/c impersonator?))
  val : any/c
procedure
(unsafe-box*-cas! loc old new) -> boolean?
  loc : box?
  old : any/c
  new : any/c
procedure
(unsafe-vector-length v) -> fixnum?
  v : vector?
procedure
(unsafe-vector-ref v k) -> any/c
  v : vector?
  k : fixnum?
procedure
(unsafe-vector-set! v k val) -> void?
  v : vector?
  k : fixnum?
  val : any/c
procedure
(unsafe-vector*-length v) -> fixnum?
  v : (and/c vector? (not/c impersonator?))
procedure
(unsafe-vector*-ref v k) -> any/c
  v : (and/c vector? (not/c impersonator?))
  k : fixnum?
procedure
(unsafe-vector*-set! v k val) -> void?
  v : (and/c vector? (not/c impersonator?))
  k : fixnum?
  val : any/c
procedure
(unsafe-string-length str) -> fixnum?
  str : string?
procedure
(unsafe-string-ref str k)
 -> (and/c char? (lambda (ch) (<= 0 (char->integer ch) 255)))
  str : string?
  k : fixnum?
procedure
(unsafe-string-set! str k ch) -> void?
  str : (and/c string? (not/c immutable?))
  k : fixnum?
  ch : char?
procedure
(unsafe-bytes-length bstr) -> fixnum?
  bstr : bytes?
procedure
(unsafe-bytes-ref bstr k) -> byte?
  bstr : bytes?
  k : fixnum?
procedure
(unsafe-bytes-set! bstr k b) -> void?
  bstr : (and/c bytes? (not/c immutable?))
  k : fixnum?
  b : byte?
procedure
(unsafe-fxvector-length v) -> fixnum?
  v : fxvector?
procedure
(unsafe-fxvector-ref v k) -> fixnum?
  v : fxvector?
  k : fixnum?
procedure
(unsafe-fxvector-set! v k x) -> void?
  v : fxvector?
  k : fixnum?
  x : fixnum?
procedure
(unsafe-flvector-length v) -> fixnum?
  v : flvector?
procedure
(unsafe-flvector-ref v k) -> flonum?
  v : flvector?
  k : fixnum?
procedure
(unsafe-flvector-set! v k x) -> void?
  v : flvector?
  k : fixnum?
  x : flonum?
procedure
(unsafe-f64vector-ref vec k) -> flonum?
  vec : f64vector?
  k : fixnum?
procedure
(unsafe-f64vector-set! vec k n) -> void?
  vec : f64vector?
  k : fixnum?
  n : flonum?
procedure
(unsafe-s16vector-ref vec k) -> (integer-in -32768 32767)
  vec : s16vector?
  k : fixnum?
procedure
(unsafe-s16vector-set! vec k n) -> void?
  vec : s16vector?
  k : fixnum?
  n : (integer-in -32768 32767)
procedure
(unsafe-u16vector-ref vec k) -> (integer-in 0 65535)
  vec : u16vector?
  k : fixnum?
procedure
(unsafe-u16vector-set! vec k n) -> void?
  vec : u16vector?
  k : fixnum?
  n : (integer-in 0 65535)
procedure
(unsafe-struct-ref v k) -> any/c
  v : any/c
  k : fixnum?
procedure
(unsafe-struct-set! v k val) -> void?
  v : any/c
  k : fixnum?
  val : any/c
procedure
(unsafe-struct*-ref v k) -> any/c
  v : (not/c impersonator?)
  k : fixnum?
procedure
(unsafe-struct*-set! v k val) -> void?
  v : (not/c impersonator?)
  k : fixnum?
  val : any/c
procedure
(unsafe-extfl+ a b) -> extflonum?
  a : extflonum?
  b : extflonum?
procedure
(unsafe-extfl- a b) -> extflonum?
  a : extflonum?
  b : extflonum?
procedure
(unsafe-extfl* a b) -> extflonum?
  a : extflonum?
  b : extflonum?
procedure
(unsafe-extfl/ a b) -> extflonum?
  a : extflonum?
  b : extflonum?
procedure
(unsafe-extflabs a) -> extflonum?
  a : extflonum?
procedure
(unsafe-extfl= a b) -> boolean?
  a : extflonum?
  b : extflonum?
procedure
(unsafe-extfl< a b) -> boolean?
  a : extflonum?
  b : extflonum?
procedure
(unsafe-extfl> a b) -> boolean?
  a : extflonum?
  b : extflonum?
procedure
(unsafe-extfl<= a b) -> boolean?
  a : extflonum?
  b : extflonum?
procedure
(unsafe-extfl>= a b) -> boolean?
  a : extflonum?
  b : extflonum?
procedure
(unsafe-extflmin a b) -> extflonum?
  a : extflonum?
  b : extflonum?
procedure
(unsafe-extflmax a b) -> extflonum?
  a : extflonum?
  b : extflonum?
procedure
(unsafe-extflround a) -> extflonum?
  a : extflonum?
procedure
(unsafe-extflfloor a) -> extflonum?
  a : extflonum?
procedure
(unsafe-extflceiling a) -> extflonum?
  a : extflonum?
procedure
(unsafe-extfltruncate a) -> extflonum?
  a : extflonum?
procedure
(unsafe-extflsin a) -> extflonum?
  a : extflonum?
procedure
(unsafe-extflcos a) -> extflonum?
  a : extflonum?
procedure
(unsafe-extfltan a) -> extflonum?
  a : extflonum?
procedure
(unsafe-extflasin a) -> extflonum?
  a : extflonum?
procedure
(unsafe-extflacos a) -> extflonum?
  a : extflonum?
procedure
(unsafe-extflatan a) -> extflonum?
  a : extflonum?
procedure
(unsafe-extfllog a) -> extflonum?
  a : extflonum?
procedure
(unsafe-extflexp a) -> extflonum?
  a : extflonum?
procedure
(unsafe-extflsqrt a) -> extflonum?
  a : extflonum?
procedure
(unsafe-extflexpt a b) -> extflonum?
  a : extflonum?
  b : extflonum?
procedure
(unsafe-fx->extfl a) -> extflonum?
  a : fixnum?
procedure
(unsafe-extfl->fx a) -> fixnum?
  a : extflonum?
procedure
(unsafe-extflvector-length v) -> fixnum?
  v : extflvector?
procedure
(unsafe-extflvector-ref v k) -> extflonum?
  v : extflvector?
  k : fixnum?
procedure
(unsafe-extflvector-set! v k x) -> void?
  v : extflvector?
  k : fixnum?
  x : extflonum?
value
unsafe-undefined : any/c
procedure
(check-not-unsafe-undefined v sym)
 -> (and/c any/c (not/c (one-of/c unsafe-undefined)))
  v : any/c
  sym : symbol?
procedure
(check-not-unsafe-undefined/assign v sym)
 -> (and/c any/c (not/c (one-of/c unsafe-undefined)))
  v : any/c
  sym : symbol?
procedure
(chaperone-struct-unsafe-undefined v) -> any/c
  v : any/c
value
prop:chaperone-unsafe-undefined : struct-type-property?
procedure
(find-library-collection-paths [pre-extras        
                                post-extras]) -> (listof path?)
  pre-extras : (listof path-string?) = null
  post-extras : (listof path-string?) = null
procedure
(find-library-collection-links)
 -> (listof (or/c #f (and/c path? complete-path?)))
procedure
(collection-file-path  file                                
                       collection ...+                     
                      [#:check-compiled? check-compiled?]) 
 -> path?
  file : path-string?
  collection : path-string?
  check-compiled? : any/c = (regexp-match? #rx"[.]rkt$" file)
(collection-file-path  file                                    
                       collection ...+                         
                       #:fail fail-proc                        
                      [#:check-compiled? check-compiled?]) -> any
  file : path-string?
  collection : path-string?
  fail-proc : (string? . -> . any)
  check-compiled? : any/c = (regexp-match? #rx"[.]rkt$" file)
procedure
(collection-path collection ...+) -> path?
  collection : path-string?
(collection-path collection            
                 ...+                  
                 #:fail fail-proc) -> any
  collection : path-string?
  fail-proc : (string? . -> . any)
parameter
(current-library-collection-paths)
 -> (listof (and/c path? complete-path?))
(current-library-collection-paths paths) -> void?
  paths : (listof (and/c path-string? complete-path?))
parameter
(current-library-collection-links)
 -> (listof (or/c #f
                  (and/c path? complete-path?)
                  (hash/c (or/c (and/c symbol? module-path?) #f)
                          (listof (and/c path? complete-path?)))))
(current-library-collection-links paths) -> void?
  paths : (listof (or/c #f
                        (and/c path-string? complete-path?)
                        (hash/c (or/c (and/c symbol? module-path?) #f)
                                (listof (and/c path-string? complete-path?)))))
parameter
(use-user-specific-search-paths) -> boolean?
(use-user-specific-search-paths on?) -> void?
  on? : any/c
parameter
(use-collection-link-paths) -> boolean?
(use-collection-link-paths on?) -> void?
  on? : any/c
syntax
help
(help string ...)
(help id)
(help id #:from module-path)
(help #:search datum ...)
syntax
(enter! module-path)
(enter! #f)
(enter! module-path flag ...+)
 
flag = #:quiet
     | #:verbose-reload
     | #:verbose
     | #:dont-re-require-enter
procedure
(dynamic-enter!  mod                                         
                [#:verbosity verbosity                       
                 #:re-require-enter? re-require-enter?]) -> void?
  mod : (or/c module-path? #f)
  verbosity : (or/c 'all 'reload 'none) = 'reload
  re-require-enter? : any/c = #t
procedure
(dynamic-rerequire  module-path                 
                   [#:verbosity verbosity]) -> (listof path?)
  module-path : module-path?
  verbosity : (or/c 'all 'reload 'none) = 'reload
syntax
(trace id ...)
syntax
(trace-define id expr)
(trace-define (head args) body ...+)
syntax
(trace-define-syntax id expr)
(trace-define-syntax (head args) body ...+)
syntax
(trace-lambda [#:name id] args expr)
syntax
(trace-let id ([arg expr] ...+) body ...+)
syntax
(untrace id ...)
parameter
(current-trace-notify) -> (string? . -> . any)
(current-trace-notify proc) -> void?
  proc : (string? . -> . any)
procedure
(trace-call id proc #:<kw> kw-arg ...) -> any/c
  id : symbol?
  proc : procedure?
  kw-arg : any/c
parameter
(current-trace-print-args) -> (-> symbol?
                                  list?
                                  (listof keyword?)
                                  list?
                                  number?
                                  void?)
(current-trace-print-args trace-print-args) -> void?
  trace-print-args : (-> symbol?
                         list?
                         (listof keyword?)
                         list?
                         number?
                         void?)
parameter
(current-trace-print-results) -> (-> symbol?
                                     list?
                                     number?
                                     any)
(current-trace-print-results trace-print-results) -> void?
  trace-print-results : (-> symbol?
                            list?
                            number?
                            any)
parameter
(current-prefix-in) -> string?
(current-prefix-in prefix) -> void?
  prefix : string?
parameter
(current-prefix-out) -> string?
(current-prefix-out prefix) -> void?
  prefix : string?
