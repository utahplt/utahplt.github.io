39283
((3) 0 () 29 ((q lib "drracket/tool-lib.rkt") (q 36613 . 22) (c (? . 0) q drracket:unit:frame<%>) (c (? . 0) q drracket:language:language<%>) (c (? . 0) q drracket:rep:text%) (c (? . 0) q drracket:frame:name-message%) (c (? . 0) q drracket:unit:frame%) (c (? . 0) q drracket:language:simple-module-based-language%) (c (? . 0) q drracket:language:simple-module-based-language->module-based-language-mixin) (c (? . 0) q drracket:language:module-based-language<%>) (c (? . 0) q drracket:frame:basics-mixin) (q 36265 . 6) (c (? . 0) q drracket:rep:context<%>) (c (? . 0) q drracket:unit:tab<%>) (q 38634 . 9) (c (? . 0) q drracket:unit:program-editor-mixin) (c (? . 0) q drracket:language:module-based-language->language-mixin) (c (? . 0) q drracket:unit:definitions-text<%>) (q 15787 . 11) (q 61007 . 11) (c (? . 0) q drracket:language:module-language<%>) (c (? . 0) q drracket:frame:<%>) (q lib "drracket/syncheck-drracket-button.rkt") (c (? . 0) q drracket:unit:definitions-text%) (c (? . 0) q drracket:unit:tab%) (c (? . 0) q drracket:rep:drs-bindings-keymap-mixin) (c (? . 0) q drracket:language:simple-module-based-language<%>) (c (? . 0) q drracket:unit:interactions-canvas%) (q lib "lang/htdp-langs-save-file-prefix.rkt")) () (h ! (equal) ((c def c (c (? . 0) q drracket:rep:current-language-settings)) q (52886 . 6)) ((c def c (c (? . 28) q htdp-save-file-prefix)) q (351 . 2)) ((c meth c (c (? . 3) q front-end/interaction)) q (25996 . 7)) ((c meth c (c (? . 12) q get-directory)) q (51688 . 3)) ((c def c (? . 5)) q (53143 . 3)) ((c meth c (c (? . 15) q after-delete)) q (6676 . 6)) ((c def c (c (? . 0) q drscheme:tool^)) q (64138 . 2)) ((c def c (? . 20)) q (63754 . 2)) ((c def c (c (? . 0) q make-drracket:language:simple-settings)) c (? . 1)) ((c meth c (c (? . 2) q prev-tab)) q (10926 . 2)) ((c def c (c (? . 0) q drracket:unit:definitions-canvas%)) q (14804 . 3)) ((c meth c (c (? . 16) q front-end/interaction)) q (24173 . 3)) ((c meth c (c (? . 4) q get-error-range)) q (49200 . 3)) ((c def c (c (? . 0) q drracket:language:simple-settings-insert-newlines)) c (? . 1)) ((c meth c (c (? . 6) q get-canvas)) q (8822 . 3)) ((c def c (c (? . 0) q drracket:unit:teachpack-callbacks-add)) c (? . 18)) ((c def c (c (? . 0) q drscheme:modes:mode-repl-submit)) q (82275 . 3)) ((c meth c (c (? . 2) q get-definitions-text)) q (11434 . 3)) ((c def c (c (? . 0) q drscheme:debug:profile-unit-frame-mixin)) q (64319 . 2)) ((c def c (c (? . 22) q syncheck-drracket-button)) q (0 . 7)) ((c meth c (c (? . 3) q front-end/complete-program)) q (25541 . 7)) ((c def c (c (? . 0) q drracket:module-language-tools:register-online-expansion-pref)) q (63439 . 4)) ((c def c (c (? . 0) q drracket:language-configuration:language-dialog)) q (39138 . 9)) ((c def c (c (? . 0) q drracket:language:get-language-extensions)) q (30746 . 3)) ((c meth c (c (? . 3) q get-metadata)) q (26784 . 6)) ((c meth c (c (? . 4) q get-user-thread)) q (49682 . 3)) ((c def c (c (? . 0) q drscheme:eval:traverse-program/multiple)) q (71602 . 12)) ((c def c (c (? . 0) q drscheme:help-desk:goto-plt-license)) q (75308 . 2)) ((c def c (c (? . 0) q struct:drracket:language-configuration:language-settings)) c (? . 14)) ((c def c (c (? . 0) q drracket:language:create-distribution-for-executable)) q (34062 . 9)) ((c meth c (c (? . 4) q after-delete)) q (48430 . 2)) ((c constructor c (? . 5)) q (53214 . 4)) ((c meth c (c (? . 2) q ensure-rep-hidden)) q (10272 . 2)) ((c meth c (c (? . 6) q update-save-button)) q (9816 . 4)) ((c def c (c (? . 0) q drracket:modes:mode-name)) c (? . 19)) ((c meth c (c (? . 2) q get-tabs)) q (11846 . 3)) ((c meth c (c (? . 7) q get-language-numbers)) q (18593 . 3)) ((c meth c (c (? . 13) q set-breakables)) q (5541 . 5)) ((c def c (c (? . 0) q drscheme:language:get-capability-contract)) q (77603 . 4)) ((c def c (c (? . 0) q struct:drracket:language:text/pos)) c (? . 11)) ((c meth c (c (? . 6) q file-menu:save-string)) q (8581 . 2)) ((c meth c (c (? . 4) q run-in-evaluation-thread)) q (50678 . 3)) ((c meth c (c (? . 6) q break-callback)) q (7632 . 2)) ((c def c (c (? . 0) q drscheme:unit:add-search-help-desk-menu-item)) q (85248 . 3)) ((c meth c (c (? . 8) q marshall-settings)) q (20124 . 3)) ((c meth c (c (? . 7) q get-one-line-summary)) q (18939 . 3)) ((c meth c (c (? . 6) q edit-menu:between-select-all-and-find)) q (8027 . 3)) ((c def c (c (? . 0) q drscheme:unit:tab<%>)) q (65899 . 2)) ((c def c (c (? . 0) q drracket:get/extend:extend-definitions-text)) q (1747 . 9)) ((c meth c (c (? . 9) q on-execute)) q (22219 . 7)) ((c def c (c (? . 0) q drracket:language:create-executable-gui)) q (31331 . 13)) ((c meth c (c (? . 6) q make-searchable)) q (9498 . 3)) ((c meth c (c (? . 6) q get-break-button)) q (8652 . 3)) ((c meth c (c (? . 4) q highlight-errors)) q (49765 . 6)) ((c def c (c (? . 0) q drscheme:language:get-language-extensions)) q (78167 . 3)) ((c def c (c (? . 0) q drracket:unit:find-symbol)) q (16398 . 4)) ((c def c (c (? . 0) q drracket:modes:get-modes)) q (61575 . 2)) ((c meth c (c (? . 6) q file-menu:between-open-and-revert)) q (8181 . 3)) ((c def c (c (? . 0) q drracket:get/extend:get-definitions-canvas)) q (3543 . 3)) ((c def c (c (? . 0) q drscheme:get/extend:allow-re-extension!)) q (75081 . 2)) ((c meth c (c (? . 8) q get-transformer-module)) q (19994 . 3)) ((c meth c (c (? . 2) q get-current-tab)) q (10405 . 3)) ((c meth c (c (? . 4) q reset-highlighting)) q (50612 . 2)) ((c def c (c (? . 0) q drracket:debug:show-backtrace-window)) q (46541 . 12)) ((c def c (c (? . 0) q drscheme:rep:get-drs-bindings-keymap)) q (84420 . 2)) ((c def c (c (? . 0) q drracket:debug:show-backtrace-window/edition-pairs)) q (43510 . 21)) ((c meth c (c (? . 10) q file-menu:between-open-and-revert)) q (54095 . 4)) ((c meth c (c (? . 6) q get-canvas%)) q (8903 . 2)) ((c meth c (c (? . 9) q render-value/format)) q (22940 . 11)) ((c meth c (c (? . 6) q file-menu:save-as-string)) q (8507 . 2)) ((c meth c (c (? . 6) q change-to-file)) q (7696 . 3)) ((c def c (c (? . 0) q drracket:debug:make-debug-error-display-handler)) q (41847 . 4)) ((c meth c (c (? . 3) q capability-value)) q (24558 . 3)) ((c def c (c (? . 0) q drscheme:get/extend:get-definitions-text)) q (73784 . 3)) ((c meth c (c (? . 10) q file-menu:open-callback)) q (54650 . 6)) ((c def c (c (? . 0) q drracket:debug:get-error-color)) q (46475 . 2)) ((c def c (c (? . 0) q drracket:language:text/pos?)) c (? . 11)) ((c meth c (c (? . 4) q after-insert)) q (48490 . 2)) ((c meth c (c (? . 4) q queue-output)) q (50460 . 3)) ((c def c (c (? . 0) q drracket:unit:open-drscheme-window)) q (15136 . 6)) ((c def c (c (? . 0) q drscheme:language-configuration:language-dialog)) q (76394 . 5)) ((c def c (c (? . 0) q drscheme:language:module-based-language->language-mixin)) q (65328 . 2)) ((c meth c (c (? . 12) q disable-evaluation)) q (51318 . 2)) ((c def c (c (? . 0) q drracket:language:text/pos-text)) c (? . 11)) ((c def c (c (? . 0) q drscheme:unit:teachpack-callbacks-remove-all)) q (85859 . 3)) ((c def c (c (? . 0) q drscheme:debug:open-and-highlight-in-file)) q (67285 . 9)) ((c def c (c (? . 0) q drscheme:frame:mixin)) q (64919 . 2)) ((c meth c (c (? . 9) q get-reader)) q (21837 . 3)) ((c meth c (c (? . 17) q get-tab)) q (14259 . 3)) ((c def c (c (? . 0) q drracket:get/extend:get-definitions-text)) q (2274 . 3)) ((c def c (c (? . 0) q drracket:unit:make-teachpack-callbacks)) q (16338 . 2)) ((c meth c (c (? . 9) q get-language-position)) q (21537 . 3)) ((c meth c (c (? . 3) q get-comment-character)) q (26315 . 3)) ((c sig-val c (c (? . 0) q drracket:tool-exports^ phase1)) q (558 . 2)) ((c def c (c (? . 0) q drracket:rep:get-welcome-delta)) q (52249 . 2)) ((c def c (c (? . 0) q drscheme:debug:test-coverage-tab-mixin)) q (64512 . 2)) ((c def c (c (? . 0) q drracket:language:simple-settings-case-sensitive)) c (? . 1)) ((c def c (c (? . 0) q drscheme:rep:get-dark-green-delta)) q (84277 . 2)) ((c def c (c (? . 0) q drracket:language-configuration:get-settings-preferences-symbol)) q (38544 . 3)) ((c def c (c (? . 0) q drscheme:unit:teachpack-callbacks?)) q (85413 . 2)) ((c def c (c (? . 0) q drscheme:language:make-simple-settings)) q (81473 . 2)) ((c def c (c (? . 0) q drscheme:language:make-setup-printing-parameters)) q (79943 . 3)) ((c meth c (c (? . 13) q disable-evaluation)) q (4644 . 2)) ((c def c (c (? . 0) q drscheme:debug:get-error-color)) q (69598 . 2)) ((c def c (c (? . 0) q drscheme:language-configuration:language-settings-settings)) q (76102 . 3)) ((c def c (c (? . 0) q drscheme:unit:open-drscheme-window)) q (85077 . 5)) ((c def c (c (? . 0) q drscheme:language:module-based-language<%>)) q (65046 . 2)) ((c meth c (c (? . 10) q file-menu:new-callback)) q (54359 . 6)) ((c meth c (c (? . 3) q first-opened)) q (25435 . 4)) ((c meth c (c (? . 10) q edit-menu:between-find-and-preferences)) q (54004 . 3)) ((c def c (c (? . 0) q drscheme:module-language-tools:tab<%>)) q (66043 . 2)) ((c def c (c (? . 0) q drracket:debug:profile-definitions-text-mixin)) q (40910 . 4)) ((c meth c (c (? . 8) q default-settings?)) q (19717 . 3)) ((c def c (c (? . 0) q drracket:language-configuration:language-settings-language)) c (? . 14)) ((c meth c (c (? . 4) q insert-prompt)) q (50280 . 2)) ((c def c (c (? . 0) q drracket:language:create-module-based-stand-alone-executable)) q (32008 . 17)) ((c def c (c (? . 0) q drscheme:unit:definitions-canvas%)) q (64639 . 2)) ((c meth c (c (? . 13) q get-directory)) q (4985 . 3)) ((c def c (c (? . 0) q drscheme:language:create-module-based-stand-alone-executable)) q (78905 . 6)) ((c meth c (c (? . 4) q evaluate-from-port)) q (48653 . 9)) ((c def c (c (? . 0) q drscheme:debug:profiling-enabled)) q (67036 . 2)) ((c def c (c (? . 0) q drscheme:language:create-executable-gui)) q (78459 . 11)) ((c def c (c (? . 0) q drracket:modes:struct:mode)) q (61525 . 2)) ((c def c (? . 26)) q (16529 . 2)) ((c meth c (c (? . 4) q get-user-eventspace)) q (49415 . 3)) ((c def c (c (? . 0) q drracket:language:text/pos-end)) c (? . 11)) ((c meth c (c (? . 7) q get-reader)) q (19039 . 3)) ((c def c (? . 15)) q (6520 . 4)) ((c meth c (c (? . 3) q front-end/finished-complete-program)) q (25869 . 4)) ((c def c (c (? . 0) q drscheme:language:make-text/pos)) q (80459 . 2)) ((c def c (c (? . 0) q drscheme:language-configuration:language-settings?)) q (75813 . 3)) ((c meth c (c (? . 13) q enable-evaluation)) q (4710 . 2)) ((c meth c (c (? . 5) q set-message)) q (53368 . 6)) ((c meth c (c (? . 8) q render-value)) q (20356 . 3)) ((c def c (c (? . 0) q drscheme:module-language-tools:tab-mixin)) q (65607 . 2)) ((c def c (c (? . 0) q drscheme:language:simple-settings-case-sensitive)) q (80636 . 3)) ((c def c (c (? . 0) q drscheme:language:create-module-based-launcher)) q (79423 . 5)) ((c def c (c (? . 0) q drscheme:get/extend:get-unit-frame)) q (73099 . 3)) ((c meth c (c (? . 16) q on-execute)) q (24412 . 3)) ((c meth c (c (? . 13) q get-last-touched)) q (6211 . 2)) ((c def c (c (? . 0) q drracket:debug:show-backtrace-window/edition-pairs/two)) q (44632 . 33)) ((c meth c (c (? . 6) q get-execute-button)) q (9326 . 3)) ((c def c (c (? . 0) q drscheme:language-configuration:fill-language-dialog)) q (76667 . 11)) ((c meth c (c (? . 10) q help-menu:before-about)) q (55351 . 4)) ((c meth c (c (? . 3) q unmarshall-settings)) q (29103 . 4)) ((c def c (c (? . 0) q drscheme:get/extend:get-definitions-canvas)) q (74524 . 3)) ((c def c (c (? . 0) q drscheme:rep:current-language-settings)) q (84729 . 3)) ((c def c (c (? . 0) q drscheme:module-language-tools:frame-mixin)) q (65548 . 2)) ((c meth c (c (? . 6) q file-menu:between-save-as-and-print)) q (8349 . 3)) ((c def c (c (? . 0) q drscheme:unit:definitions-text<%>)) q (65849 . 2)) ((c meth c (c (? . 9) q marshall-settings)) q (22092 . 4)) ((c def c (c (? . 0) q drscheme:module-language:module-language-put-file-mixin)) q (84062 . 3)) ((c def c (c (? . 0) q drscheme:language:simple-settings-printing-style)) q (80747 . 3)) ((c meth c (c (? . 17) q set-next-settings)) q (14466 . 7)) ((c def c (c (? . 0) q drscheme:debug:add-prefs-panel)) q (66698 . 2)) ((c def c (c (? . 0) q drracket:rep:get-dark-green-delta)) q (52321 . 2)) ((c def c (c (? . 0) q drscheme:language:simple-settings-annotations)) q (81320 . 3)) ((c meth c (c (? . 2) q get-tab-filename)) q (10497 . 3)) ((c def c (c (? . 0) q drscheme:unit:frame<%>)) q (65810 . 2)) ((c def c (? . 27)) q (7036 . 3)) ((c def c (c (? . 0) q drracket:language:simple-settings-fraction-style)) c (? . 1)) ((c def c (c (? . 0) q drscheme:get/extend:get-tab)) q (73429 . 3)) ((c def c (c (? . 0) q drracket:debug:small-planet-bitmap)) q (42772 . 2)) ((c meth c (c (? . 2) q register-capability-menu-item)) q (12171 . 7)) ((c def c (c (? . 0) q drracket:eval:get-snip-classes)) q (56892 . 3)) ((c def c (c (? . 0) q drracket:modes:add-mode)) q (60161 . 13)) ((c def c (c (? . 0) q drracket:unit:teachpack-callbacks-get-names)) c (? . 18)) ((c def c (c (? . 0) q drracket:get/extend:get-unit-frame)) q (1108 . 3)) ((c def c (c (? . 0) q drracket:language:simple-settings)) c (? . 1)) ((c def c (c (? . 0) q drracket:module-language-tools:start?)) q (63352 . 3)) ((c meth c (c (? . 4) q kill-evaluation)) q (50341 . 2)) ((c meth c (c (? . 2) q move-current-tab-right)) q (10984 . 2)) ((c meth c (c (? . 21) q get-show-menu)) q (56115 . 2)) ((c def c (c (? . 0) q drscheme:debug:profile-definitions-text-mixin)) q (64208 . 2)) ((c def c (c (? . 0) q drscheme:frame:basics-mixin)) q (64956 . 2)) ((c meth c (c (? . 8) q unmarshall-settings)) q (20589 . 3)) ((c def c (c (? . 0) q drscheme:language:text/pos-end)) q (80355 . 3)) ((c meth c (c (? . 6) q on-close)) q (9632 . 2)) ((c def c (c (? . 0) q drracket:get/extend:get-interactions-canvas)) q (4193 . 3)) ((c def c (c (? . 0) q drscheme:rep:current-rep)) q (84492 . 3)) ((c meth c (c (? . 12) q set-breakables)) q (51925 . 5)) ((c meth c (c (? . 4) q get-user-custodian)) q (49326 . 3)) ((c def c (c (? . 0) q drscheme:language:struct:text/pos)) q (80512 . 2)) ((c def c (c (? . 0) q drscheme:language:extend-language-interface)) q (77908 . 5)) ((c def c (c (? . 0) q drracket:modes:mode)) c (? . 19)) ((c def c (? . 7)) q (17206 . 4)) ((c def c (c (? . 0) q drscheme:language:register-capability)) q (77106 . 7)) ((c def c (c (? . 0) q drscheme:rep:context<%>)) q (65936 . 2)) ((c def c (c (? . 0) q drscheme:frame:<%>)) q (65775 . 2)) ((c meth c (c (? . 13) q can-close?)) q (4583 . 2)) ((c meth c (c (? . 2) q get-language-menu)) q (10126 . 3)) ((c meth c (c (? . 17) q set-needs-execution-message)) q (14352 . 4)) ((c def c (c (? . 0) q drracket:get/extend:allow-re-extension!)) q (4371 . 2)) ((c meth c (c (? . 12) q ensure-rep-shown)) q (51455 . 3)) ((c def c (c (? . 0) q drracket:language-configuration:language-settings)) c (? . 14)) ((c meth c (c (? . 9) q get-language-numbers)) q (21419 . 3)) ((c def c (c (? . 0) q drracket:get/extend:extend-unit-frame)) q (618 . 9)) ((c def c (c (? . 0) q drscheme:help-desk:help-desk)) q (75143 . 6)) ((c def c (c (? . 0) q drracket:debug:open-and-highlight-in-file)) q (42836 . 11)) ((c meth c (c (? . 3) q get-reader-module)) q (27134 . 3)) ((c meth c (c (? . 7) q get-language-position)) q (18718 . 3)) ((c def c (c (? . 0) q drracket:debug:profile-interactions-text-mixin)) q (40775 . 3)) ((c meth c (c (? . 9) q default-settings)) q (21083 . 3)) ((c def c (c (? . 0) q drracket:modes:mode-intended-to-edit-programs?)) c (? . 19)) ((c def c (c (? . 0) q drscheme:module-language-tools:definitions-text<%>)) q (65976 . 2)) ((c def c (c (? . 0) q drracket:language:simple-module-based-language-convert-value)) q (35474 . 7)) ((c def c (c (? . 0) q drracket:get/extend:get-interactions-text)) q (2906 . 3)) ((c meth c (c (? . 20) q get-users-language-name)) q (63816 . 3)) ((c def c (c (? . 0) q drscheme:module-language-tools:add-online-expansion-handler)) q (83045 . 6)) ((c meth c (c (? . 3) q extra-repl-information)) q (27419 . 7)) ((c meth c (c (? . 9) q default-settings?)) q (21173 . 4)) ((c meth c (c (? . 21) q update-shown)) q (56185 . 2)) ((c def c (c (? . 0) q drscheme:rep:current-value-port)) q (84581 . 2)) ((c def c (c (? . 0) q drscheme:language:language<%>)) q (65000 . 2)) ((c meth c (c (? . 6) q get-text-to-search)) q (9408 . 3)) ((c meth c (c (? . 6) q get-editor)) q (9175 . 2)) ((c meth c (c (? . 3) q render-value/format)) q (28631 . 11)) ((c meth c (c (? . 2) q get-tab-count)) q (10605 . 3)) ((c meth c (c (? . 4) q shutdown)) q (50776 . 2)) ((c meth c (c (? . 9) q get-init-code)) q (21300 . 4)) ((c meth c (c (? . 3) q get-style-delta)) q (27253 . 3)) ((c def c (c (? . 0) q drscheme:modes:struct:mode)) q (82618 . 2)) ((c def c (c (? . 0) q drscheme:language:create-distribution-for-executable)) q (79273 . 7)) ((c def c (? . 2)) q (10078 . 2)) ((c meth c (c (? . 4) q display-results)) q (48550 . 3)) ((c def c (c (? . 0) q drscheme:language:simple-settings-insert-newlines)) q (81208 . 3)) ((c def c (c (? . 0) q drscheme:rep:get-welcome-delta)) q (84206 . 2)) ((c def c (c (? . 0) q drracket:unit:get-program-editor-mixin)) q (14887 . 3)) ((c def c (c (? . 0) q drscheme:language:setup-printing-parameters)) q (79803 . 3)) ((c def c (c (? . 0) q drscheme:module-language:add-module-language)) q (83997 . 2)) ((c def c (c (? . 0) q drracket:language:create-module-based-launcher)) q (34520 . 17)) ((c def c (c (? . 0) q drscheme:language:simple-module-based-language<%>)) q (65105 . 2)) ((c def c (c (? . 0) q drscheme:language:text/pos-start)) q (80249 . 3)) ((c meth c (c (? . 2) q unregister-toolbar-button)) q (13128 . 4)) ((c def c (c (? . 0) q drracket:debug:test-coverage-off-style-name)) q (42441 . 2)) ((c def c (c (? . 0) q drracket:language-configuration:add-language)) q (38024 . 8)) ((c meth c (c (? . 9) q render-value)) q (22563 . 9)) ((c meth c (c (? . 3) q default-settings)) q (25244 . 3)) ((c meth c (c (? . 3) q marshall-settings)) q (27703 . 4)) ((c def c (c (? . 0) q drracket:language:object/c)) q (29230 . 2)) ((c def c (c (? . 0) q drscheme:module-language-tools:start?)) q (83648 . 2)) ((c meth c (c (? . 10) q help-menu:create-about?)) q (55472 . 3)) ((c meth c (c (? . 3) q create-executable)) q (24805 . 9)) ((c meth c (c (? . 16) q get-language-name)) q (24312 . 3)) ((c def c (c (? . 0) q drracket:language:get-capability-contract)) q (29821 . 3)) ((c meth c (c (? . 12) q clear-annotations)) q (51250 . 2)) ((c meth c (c (? . 6) q find-matching-tab)) q (7787 . 4)) ((c def c (c (? . 0) q drscheme:module-language-tools:add-online-expansion-monitor)) q (83345 . 8)) ((c def c (c (? . 0) q drracket:language-configuration:language-settings-settings)) c (? . 14)) ((c def c (c (? . 0) q drscheme:modes:get-modes)) q (82668 . 2)) ((c def c (c (? . 0) q drracket:get/extend:extend-interactions-text)) q (2388 . 9)) ((c meth c (c (? . 3) q config-panel)) q (24653 . 4)) ((c def c (c (? . 0) q drscheme:rep:text%)) q (64847 . 2)) ((c def c (c (? . 0) q drscheme:rep:get-error-delta)) q (84351 . 2)) ((c meth c (c (? . 12) q enable-evaluation)) q (51387 . 2)) ((c meth c (c (? . 10) q get-additional-important-urls)) q (54944 . 3)) ((c meth c (c (? . 8) q on-execute)) q (20245 . 3)) ((c def c (c (? . 0) q drscheme:language-configuration:make-language-settings)) q (76317 . 3)) ((c def c (c (? . 0) q drscheme:unit:teachpack-callbacks-remove)) q (85732 . 3)) ((c def c (c (? . 0) q drscheme:get/extend:extend-definitions-text)) q (73516 . 6)) ((c meth c (c (? . 4) q get-user-language-settings)) q (49506 . 3)) ((c meth c (c (? . 3) q default-settings?)) q (25321 . 4)) ((c meth c (c (? . 3) q get-language-name)) q (26403 . 3)) ((c def c (c (? . 0) q drscheme:unit:make-teachpack-callbacks)) q (86040 . 2)) ((c meth c (c (? . 13) q is-current-tab?)) q (5293 . 2)) ((c def c (c (? . 0) q drscheme:debug:test-coverage-definitions-text-mixin)) q (64444 . 2)) ((c def c (c (? . 0) q drracket:get/extend:disallow-re-extension!)) q (4305 . 2)) ((c meth c (c (? . 4) q reset-console)) q (50551 . 2)) ((c def c (c (? . 0) q drracket:debug:profile-unit-frame-mixin)) q (40594 . 4)) ((c def c (c (? . 0) q drscheme:language-configuration:get-settings-preferences-symbol)) q (75724 . 3)) ((c meth c (c (? . 13) q on-close)) q (5421 . 2)) ((c meth c (c (? . 4) q highlight-errors/exn)) q (50000 . 3)) ((c def c (? . 17)) q (13795 . 2)) ((c meth c (c (? . 4) q on-execute)) q (49087 . 3)) ((c def c (c (? . 0) q drracket:language:text/pos-start)) c (? . 11)) ((c meth c (c (? . 3) q order-manuals)) q (28232 . 4)) ((c meth c (c (? . 2) q ensure-rep-shown)) q (10339 . 2)) ((c meth c (c (? . 3) q render-value)) q (28366 . 8)) ((c meth c (c (? . 9) q config-panel)) q (20918 . 4)) ((c def c (c (? . 0) q drscheme:module-language-tools:frame<%>)) q (66097 . 2)) ((c meth c (c (? . 2) q next-tab)) q (10868 . 2)) ((c def c (c (? . 0) q drracket:eval:traverse-program/multiple)) q (57853 . 16)) ((c def c (c (? . 0) q drracket:language-configuration:language-settings?)) c (? . 14)) ((c def c (c (? . 0) q drscheme:debug:hide-backtrace-window)) q (66639 . 2)) ((c def c (c (? . 0) q drscheme:module-language-tools:done)) q (83913 . 3)) ((c def c (c (? . 0) q struct:drracket:unit:teachpack-callbacks)) c (? . 18)) ((c meth c (c (? . 21) q set-show-menu-sort-key)) q (55904 . 5)) ((c def c (c (? . 0) q drracket:language:simple-settings->vector)) q (37765 . 4)) ((c def c (c (? . 0) q drscheme:frame:basics<%>)) q (65734 . 2)) ((c def c (c (? . 0) q drracket:eval:build-user-eventspace/custodian)) q (59536 . 11)) ((c def c (c (? . 0) q drscheme:debug:error-display-handler/stacktrace)) q (66153 . 8)) ((c meth c (c (? . 2) q get-definitions-canvas)) q (11322 . 3)) ((c meth c (c (? . 13) q get-ints)) q (5212 . 3)) ((c def c (? . 24)) q (6277 . 4)) ((c def c (c (? . 0) q drscheme:debug:test-coverage-off-style-name)) q (66974 . 2)) ((c meth c (c (? . 21) q add-show-menu-items)) q (55793 . 3)) ((c def c (c (? . 0) q drscheme:unit:teachpack-callbacks-get-names)) q (85480 . 3)) ((c meth c (c (? . 8) q config-panel)) q (19443 . 3)) ((c meth c (c (? . 13) q break-callback)) q (4521 . 2)) ((c def c (c (? . 0) q make-drracket:language-configuration:language-settings)) c (? . 14)) ((c def c (c (? . 0) q drscheme:unit:get-definitions-text%)) q (64689 . 2)) ((c def c (? . 21)) q (55642 . 5)) ((c meth c (c (? . 4) q wait-for-io-to-complete/user)) q (50903 . 3)) ((c def c (c (? . 0) q drracket:rep:after-expression)) q (52701 . 4)) ((c meth c (c (? . 8) q use-mred-launcher)) q (20729 . 3)) ((c def c (c (? . 0) q drscheme:debug:srcloc->edition/pair)) q (70035 . 13)) ((c def c (c (? . 0) q drracket:help-desk:help-desk)) q (56243 . 6)) ((c def c (c (? . 0) q drscheme:modes:add-mode)) q (81704 . 8)) ((c def c (c (? . 0) q drscheme:unit:get-program-editor-mixin)) q (84845 . 3)) ((c def c (c (? . 0) q drracket:language:text/pos)) c (? . 11)) ((c def c (c (? . 0) q drracket:module-language:add-module-language)) q (63905 . 2)) ((c def c (c (? . 0) q drracket:language:make-simple-settings)) q (37641 . 2)) ((c def c (c (? . 0) q drracket:debug:bug-info->ticket-url)) q (42644 . 3)) ((c def c (c (? . 0) q drracket:language:simple-settings-printing-style)) c (? . 1)) ((c def c (? . 4)) q (48184 . 4)) ((c def c (? . 6)) q (7252 . 5)) ((c def c (? . 23)) q (13326 . 5)) ((c form c (c (? . 22) q syncheck:button-callback)) q (274 . 2)) ((c def c (c (? . 0) q drracket:get/extend:extend-definitions-canvas)) q (3008 . 9)) ((c meth c (c (? . 4) q on-close)) q (50404 . 2)) ((c def c (c (? . 0) q drscheme:language:simple-settings->vector)) q (81597 . 3)) ((c def c (c (? . 0) q drracket:debug:error-display-handler/stacktrace)) q (41095 . 14)) ((c meth c (c (? . 6) q change-to-tab)) q (7917 . 3)) ((c meth c (c (? . 23) q set-modified)) q (13722 . 2)) ((c def c (c (? . 0) q drracket:frame:mixin)) q (53581 . 6)) ((c def c (? . 8)) q (19183 . 5)) ((c constructor c (? . 4)) q (48285 . 4)) ((c meth c (c (? . 13) q remove-bkg-running-color)) q (6061 . 3)) ((c def c (c (? . 0) q drscheme:debug:profile-tab-mixin)) q (64270 . 2)) ((c meth c (c (? . 8) q default-settings)) q (19597 . 3)) ((c meth c (c (? . 9) q get-module)) q (21656 . 3)) ((c def c (c (? . 0) q drracket:rep:current-value-port)) q (52629 . 2)) ((c def c (c (? . 0) q drracket:language:make-text/pos)) q (36503 . 2)) ((c def c (c (? . 0) q drracket:language:extend-language-interface)) q (30287 . 7)) ((c meth c (c (? . 4) q on-highlighted-errors)) q (50089 . 3)) ((c def c (c (? . 0) q drscheme:module-language-tools:definitions-text-mixin)) q (65664 . 2)) ((c def c (c (? . 0) q drracket:language-configuration:fill-language-dialog)) q (39726 . 15)) ((c meth c (c (? . 13) q get-frame)) q (5128 . 3)) ((c def c (c (? . 0) q drracket:modes:mode-matches-language)) c (? . 19)) ((c def c (c (? . 0) q drscheme:get/extend:get-interactions-text)) q (74153 . 3)) ((c def c (c (? . 0) q drracket:eval:expand-program)) q (56974 . 18)) ((c meth c (c (? . 2) q sort-toolbar-buttons-panel)) q (13249 . 3)) ((c meth c (c (? . 3) q metadata->settings)) q (27817 . 4)) ((c def c (c (? . 0) q drscheme:modes:mode-matches-language)) q (82401 . 3)) ((c def c (c (? . 0) q drscheme:rep:after-expression)) q (84652 . 2)) ((c def c (c (? . 0) q drscheme:language:text/pos?)) q (80094 . 2)) ((c meth c (c (? . 3) q on-execute)) q (27931 . 7)) ((c def c (c (? . 0) q drracket:language-configuration:make-language-settings)) q (39061 . 3)) ((c def c (? . 9)) q (20850 . 2)) ((c sig-val c (c (? . 0) q drracket:tool-exports^ phase2)) q (588 . 2)) ((c meth c (c (? . 2) q move-current-tab-left)) q (11056 . 2)) ((c def c (c (? . 0) q drracket:unit:teachpack-callbacks-remove-all)) c (? . 18)) ((c def c (c (? . 0) q drracket:unit:teachpack-callbacks?)) c (? . 18)) ((c def c (c (? . 0) q drracket:modes:mode-repl-submit)) c (? . 19)) ((c def c (c (? . 0) q drracket:rep:get-error-delta)) q (52396 . 2)) ((c meth c (c (? . 2) q get-interactions-text)) q (11750 . 3)) ((c def c (c (? . 0) q drscheme:tracing:frame-mixin)) q (65443 . 2)) ((c def c (? . 12)) q (51201 . 2)) ((c constructor c (? . 23)) q (13549 . 3)) ((c meth c (c (? . 6) q get-editor%)) q (9250 . 2)) ((c def c (c (? . 0) q drracket:module-language-tools:add-online-expansion-monitor)) q (62744 . 12)) ((c def c (c (? . 0) q drscheme:language:simple-settings?)) q (80569 . 2)) ((c def c (c (? . 0) q drracket:help-desk:goto-plt-license)) q (56513 . 2)) ((c meth c (c (? . 6) q add-show-menu-items)) q (7516 . 4)) ((c def c (c (? . 0) q drracket:eval:expand-program/multiple)) q (58639 . 18)) ((c def c (c (? . 0) q drracket:module-language-tools:done)) q (63670 . 3)) ((c constructor c (? . 24)) q (6373 . 3)) ((c def c (c (? . 0) q drscheme:language:simple-module-based-language%)) q (65171 . 2)) ((c meth c (c (? . 3) q get-language-url)) q (26691 . 3)) ((c meth c (c (? . 25) q get-keymaps)) q (51103 . 3)) ((c meth c (c (? . 9) q get-transformer-module)) q (21974 . 3)) ((c def c (c (? . 0) q drscheme:unit:tab%)) q (64567 . 2)) ((c def c (? . 13)) q (4434 . 3)) ((c def c (c (? . 0) q drracket:language:simple-settings?)) c (? . 1)) ((c def c (c (? . 0) q drscheme:debug:test-coverage-enabled)) q (66842 . 2)) ((c meth c (c (? . 10) q help-menu:about-callback)) q (55053 . 6)) ((c def c (c (? . 0) q drracket:rep:current-rep)) q (52539 . 3)) ((c def c (c (? . 0) q drracket:language:struct:simple-settings)) q (37701 . 2)) ((c meth c (c (? . 6) q still-untouched?)) q (9747 . 2)) ((c def c (c (? . 0) q drscheme:debug:make-debug-eval-handler)) q (66751 . 3)) ((c def c (c (? . 0) q drscheme:rep:text<%>)) q (64882 . 2)) ((c def c (c (? . 0) q drscheme:unit:add-to-program-editor-mixin)) q (84954 . 3)) ((c def c (c (? . 0) q drscheme:tracing:tab-mixin)) q (65400 . 2)) ((c meth c (c (? . 4) q get-user-namespace)) q (49593 . 3)) ((c meth c (c (? . 12) q get-breakables)) q (51571 . 4)) ((c def c (c (? . 0) q drscheme:module-language:module-language<%>)) q (65488 . 2)) ((c def c (c (? . 0) q drracket:language:put-executable)) q (30827 . 12)) ((c meth c (c (? . 12) q reset-offer-kill)) q (51858 . 2)) ((c meth c (c (? . 13) q get-enabled)) q (5066 . 2)) ((c meth c (c (? . 13) q reset-offer-kill)) q (5477 . 2)) ((c def c (c (? . 0) q make-drracket:unit:teachpack-callbacks)) c (? . 18)) ((c def c (c (? . 0) q drscheme:language:simple-settings-show-sharing)) q (81099 . 3)) ((c def c (c (? . 0) q drscheme:language:get-capability-default)) q (77390 . 5)) ((c def c (c (? . 0) q drscheme:debug:make-debug-error-display-handler)) q (66483 . 4)) ((c meth c (c (? . 10) q file-menu:open-string)) q (54869 . 2)) ((c def c (c (? . 0) q drracket:language:setup-printing-parameters)) q (35792 . 7)) ((c def c (c (? . 0) q drscheme:language:get-default-mixin)) q (78061 . 3)) ((c def c (c (? . 0) q drracket:language:capability-registered?)) q (29555 . 3)) ((c def c (c (? . 0) q drracket:module-language-tools:add-online-expansion-handler)) q (62220 . 11)) ((c def c (c (? . 0) q drracket:get/extend:extend-tab)) q (1197 . 9)) ((c def c (c (? . 0) q drracket:language:add-snip-value)) q (29962 . 7)) ((c meth c (c (? . 2) q create-new-tab)) q (10804 . 2)) ((c def c (c (? . 0) q drscheme:language:create-module-based-distribution)) q (79094 . 6)) ((c def c (c (? . 0) q drscheme:unit:struct:teachpack-callbacks)) q (85976 . 2)) ((c def c (? . 3)) q (24503 . 2)) ((c def c (c (? . 0) q drracket:language-configuration:struct:language-settings)) q (38980 . 3)) ((c meth c (c (? . 4) q wait-for-io-to-complete)) q (50832 . 2)) ((c def c (c (? . 0) q drscheme:unit:interactions-canvas%)) q (64741 . 2)) ((c meth c (c (? . 13) q get-breakables)) q (4775 . 4)) ((c def c (c (? . 0) q drscheme:module-language-tools:done?)) q (83844 . 2)) ((c meth c (c (? . 2) q on-tab-change)) q (11941 . 5)) ((c def c (c (? . 0) q drscheme:language-configuration:add-language)) q (75480 . 6)) ((c def c (c (? . 0) q drscheme:get/extend:extend-interactions-canvas)) q (74633 . 6)) ((c def c (c (? . 0) q drracket:get/extend:get-tab)) q (1659 . 3)) ((c def c (c (? . 0) q drracket:language:simple-settings-show-sharing)) c (? . 1)) ((c def c (c (? . 0) q drracket:language:get-capability-default)) q (29643 . 4)) ((c meth c (c (? . 23) q set-filename)) q (13649 . 2)) ((c meth c (c (? . 13) q add-bkg-running-color)) q (5763 . 7)) ((c meth c (c (? . 6) q update-shown)) q (10016 . 2)) ((c def c (c (? . 0) q drscheme:debug:small-planet-bitmap)) q (67221 . 2)) ((c def c (c (? . 0) q drscheme:debug:test-coverage-interactions-text-mixin)) q (64375 . 2)) ((c def c (? . 25)) q (50980 . 3)) ((c def c (c (? . 0) q drracket:unit:teachpack-callbacks)) c (? . 18)) ((c def c (c (? . 0) q drracket:debug:srcloc->edition/pair)) q (47127 . 16)) ((c meth c (c (? . 2) q reorder-tabs)) q (11127 . 3)) ((c meth c (c (? . 10) q help-menu:about-string)) q (55274 . 3)) ((c meth c (c (? . 2) q get-interactions-canvas)) q (11618 . 3)) ((c def c (c (? . 0) q drscheme:unit:find-symbol)) q (86100 . 3)) ((c meth c (c (? . 4) q initialize-console)) q (50214 . 2)) ((c def c (c (? . 0) q drscheme:modes:mode?)) q (82036 . 2)) ((c meth c (c (? . 26) q get-language-numbers)) q (16604 . 3)) ((c def c (c (? . 0) q drracket:eval:set-basic-parameters)) q (56572 . 7)) ((c meth c (c (? . 3) q get-language-position)) q (26585 . 3)) ((c def c (c (? . 0) q drscheme:language:add-snip-value)) q (77742 . 6)) ((c def c (c (? . 0) q drscheme:debug:test-coverage-on-style-name)) q (66913 . 2)) ((c def c (c (? . 0) q struct:drracket:modes:mode)) c (? . 19)) ((c meth c (c (? . 6) q get-button-panel)) q (8732 . 3)) ((c meth c (c (? . 9) q unmarshall-settings)) q (23477 . 4)) ((c def c (c (? . 0) q drscheme:modes:mode-name)) q (82089 . 2)) ((c def c (c (? . 0) q drscheme:debug:bug-info->ticket-url)) q (67103 . 4)) ((c meth c (c (? . 2) q open-in-new-tab)) q (10687 . 3)) ((c def c (c (? . 0) q drscheme:get/extend:extend-unit-frame)) q (72850 . 6)) ((c def c (c (? . 0) q drracket:language-configuration:get-languages)) q (37909 . 3)) ((c def c (c (? . 0) q struct:drracket:language:simple-settings)) c (? . 1)) ((c meth c (c (? . 15) q after-insert)) q (6856 . 6)) ((c meth c (c (? . 6) q file-menu:print-string)) q (8435 . 2)) ((c def c (c (? . 0) q drracket:language:create-module-based-distribution)) q (33074 . 17)) ((c def c (c (? . 0) q drscheme:eval:get-snip-classes)) q (71084 . 3)) ((c def c (c (? . 0) q drracket:frame:basics<%>)) q (55551 . 3)) ((c def c (c (? . 0) q drscheme:get/extend:extend-definitions-canvas)) q (74254 . 6)) ((c meth c (c (? . 13) q touched)) q (6156 . 2)) ((c meth c (c (? . 26) q get-module)) q (16855 . 3)) ((c def c (c (? . 0) q drracket:debug:hide-backtrace-window)) q (42012 . 2)) ((c def c (c (? . 0) q drracket:rep:text<%>)) q (48138 . 2)) ((c def c (c (? . 0) q drscheme:get/extend:extend-tab)) q (73187 . 6)) ((c def c (c (? . 0) q drscheme:language:simple-module-based-language-convert-value)) q (79678 . 3)) ((c def c (c (? . 0) q drracket:module-language-tools:done?)) q (63584 . 3)) ((c form c (c (? . 0) q drracket:tool^)) q (472 . 2)) ((c def c (c (? . 0) q drscheme:language:simple-module-based-language->module-based-language-mixin)) q (65235 . 3)) ((c meth c (c (? . 3) q get-metadata-lines)) q (26977 . 3)) ((c meth c (c (? . 13) q is-running?)) q (5359 . 2)) ((c def c (c (? . 0) q drracket:module-language:module-language-put-file-mixin)) q (63971 . 4)) ((c constructor c (? . 27)) q (7123 . 3)) ((c meth c (c (? . 9) q use-mred-launcher)) q (23617 . 3)) ((c meth c (c (? . 26) q get-language-position)) q (16729 . 3)) ((c meth c (c (? . 7) q get-module)) q (18824 . 3)) ((c def c (c (? . 28) q htdp-file-prefix?)) q (401 . 3)) ((c meth c (c (? . 17) q end-metadata-changes)) q (14086 . 3)) ((c def c (c (? . 0) q drracket:language:simple-settings-annotations)) c (? . 1)) ((c def c (c (? . 0) q drracket:debug:profiling-enabled)) q (42503 . 4)) ((c def c (c (? . 0) q drracket:language:register-capability)) q (29277 . 7)) ((c def c (c (? . 0) q drscheme:language:struct:simple-settings)) q (81533 . 2)) ((c def c (c (? . 22) q syncheck-bitmap)) q (306 . 2)) ((c def c (c (? . 0) q drracket:debug:add-prefs-panel)) q (42072 . 2)) ((c constructor c (? . 6)) q (7415 . 3)) ((c meth c (c (? . 26) q get-one-line-summary)) q (16950 . 3)) ((c constructor c (? . 7)) q (17360 . 18)) ((c def c (c (? . 0) q drscheme:modes:mode-intended-to-edit-programs?)) q (82523 . 3)) ((c meth c (c (? . 10) q file-menu:between-print-and-close)) q (54227 . 4)) ((c meth c (c (? . 6) q on-size)) q (9690 . 2)) ((c meth c (c (? . 13) q get-defs)) q (4889 . 3)) ((c def c (c (? . 0) q drscheme:eval:expand-program)) q (71165 . 12)) ((c def c (c (? . 0) q drscheme:get/extend:disallow-re-extension!)) q (75016 . 2)) ((c def c (c (? . 0) q drscheme:language:simple-settings-fraction-style)) q (80912 . 3)) ((c def c (c (? . 0) q drracket:module-language-tools:add-opt-out-toolbar-button)) q (61648 . 11)) ((c def c (c (? . 0) q drscheme:tool-exports^)) q (64169 . 2)) ((c meth c (c (? . 17) q after-set-next-settings)) q (13854 . 4)) ((c meth c (c (? . 10) q file-menu:new-string)) q (54576 . 2)) ((c meth c (c (? . 9) q get-one-line-summary)) q (21744 . 3)) ((c def c (c (? . 0) q drscheme:modes:mode-surrogate)) q (82160 . 3)) ((c def c (c (? . 0) q drscheme:debug:show-backtrace-window)) q (69663 . 9)) ((c def c (c (? . 0) q drscheme:unit:teachpack-callbacks-add)) q (85608 . 3)) ((c def c (c (? . 0) q drracket:unit:struct:teachpack-callbacks)) q (16274 . 2)) ((c def c (c (? . 0) q drscheme:eval:set-basic-parameters)) q (70937 . 5)) ((c def c (c (? . 0) q drracket:debug:test-coverage-enabled)) q (42231 . 4)) ((c def c (c (? . 0) q drracket:debug:make-debug-eval-handler)) q (42126 . 3)) ((c meth c (c (? . 24) q clear-annotations)) q (6455 . 2)) ((c def c (c (? . 0) q drracket:modes:mode-surrogate)) c (? . 19)) ((c def c (c (? . 0) q drscheme:language:put-executable)) q (78247 . 8)) ((c def c (c (? . 0) q drracket:unit:add-search-help-desk-menu-item)) q (15348 . 9)) ((c meth c (c (? . 12) q needs-execution)) q (51772 . 3)) ((c def c (c (? . 0) q make-drracket:language:text/pos)) c (? . 11)) ((c def c (c (? . 0) q drscheme:unit:frame%)) q (64602 . 2)) ((c def c (c (? . 0) q drracket:debug:test-coverage-on-style-name)) q (42380 . 2)) ((c def c (c (? . 0) q drscheme:eval:build-user-eventspace/custodian)) q (72592 . 7)) ((c def c (c (? . 0) q drracket:language:get-default-mixin)) q (30639 . 3)) ((c def c (c (? . 0) q drracket:language:make-setup-printing-parameters)) q (36113 . 3)) ((c meth c (c (? . 6) q file-menu:between-print-and-close)) q (8265 . 3)) ((c def c (c (? . 0) q drscheme:eval:expand-program/multiple)) q (72086 . 13)) ((c meth c (c (? . 26) q get-reader)) q (17062 . 3)) ((c meth c (c (? . 3) q get-one-line-summary)) q (27054 . 3)) ((c meth c (c (? . 2) q close-current-tab)) q (11255 . 2)) ((c def c (c (? . 0) q drracket:unit:add-to-program-editor-mixin)) q (14997 . 3)) ((c meth c (c (? . 2) q register-toolbar-buttons)) q (12755 . 7)) ((c def c (c (? . 0) q drscheme:language:capability-registered?)) q (77315 . 2)) ((c def c (c (? . 0) q drscheme:language-configuration:language-settings-language)) q (75897 . 3)) ((c def c (c (? . 0) q drracket:unit:teachpack-callbacks-remove)) c (? . 18)) ((c def c (c (? . 0) q drscheme:rep:drs-bindings-keymap-mixin)) q (64792 . 2)) ((c meth c (c (? . 4) q after-many-evals)) q (49025 . 2)) ((c form c (c (? . 0) q drracket:tool-exports^)) q (511 . 2)) ((c meth c (c (? . 6) q update-save-message)) q (9920 . 3)) ((c meth c (c (? . 12) q update-running)) q (52151 . 3)) ((c def c (c (? . 0) q drscheme:module-language-tools:add-opt-out-toolbar-button)) q (82740 . 8)) ((c meth c (c (? . 2) q ensure-defs-shown)) q (10205 . 2)) ((c def c (c (? . 0) q drracket:modes:mode?)) c (? . 19)) ((c meth c (c (? . 2) q register-toolbar-button)) q (12441 . 7)) ((c meth c (c (? . 8) q get-init-code)) q (19838 . 4)) ((c def c (c (? . 0) q drscheme:language:text/pos-text)) q (80154 . 3)) ((c def c (c (? . 0) q drracket:rep:get-drs-bindings-keymap)) q (52466 . 2)) ((c meth c (c (? . 8) q render-value/format)) q (20469 . 3)) ((c def c (c (? . 0) q drscheme:language-configuration:get-languages)) q (75366 . 3)) ((c meth c (c (? . 16) q front-end/complete-program)) q (24029 . 3)) ((c meth c (c (? . 6) q get-definitions/interactions-panel-parent)) q (8977 . 5)) ((c meth c (c (? . 2) q get-insert-menu)) q (11542 . 2)) ((c def c (c (? . 0) q drscheme:debug:show-backtrace-window/edition-pairs/two)) q (68494 . 26)) ((c def c (? . 10)) q (53836 . 4)) ((c def c (c (? . 0) q drscheme:debug:show-backtrace-window/edition-pairs)) q (67836 . 16)) ((c def c (c (? . 0) q drracket:get/extend:extend-interactions-canvas)) q (3653 . 9)) ((c meth c (c (? . 9) q use-namespace-require/copy?)) q (23708 . 3)) ((c def c (c (? . 0) q drracket:language:struct:text/pos)) q (36556 . 2)) ((c meth c (c (? . 3) q get-language-numbers)) q (26480 . 3)) ((c def c (c (? . 0) q drscheme:get/extend:extend-interactions-text)) q (73897 . 6)) ((c def c (? . 16)) q (23809 . 5)) ((c meth c (c (? . 17) q begin-metadata-changes)) q (14002 . 3)) ((c meth c (c (? . 6) q execute-callback)) q (8115 . 2)) ((c def c (c (? . 0) q drscheme:get/extend:get-interactions-canvas)) q (74905 . 3)) ((c def c (c (? . 0) q drscheme:language-configuration:struct:language-settings)) q (76236 . 3)) ((c meth c (c (? . 17) q get-next-settings)) q (14168 . 3)) ((c def c (c (? . 0) q drscheme:module-language-tools:register-online-expansion-pref)) q (83718 . 3))))
value
syncheck-drracket-button : (list/c
                            string?
                            (is-a?/c bitmap%)
                            (-> (is-a?/c
                                 top-level-window<%>)
                                any))
syntax
syncheck:button-callback
value
syncheck-bitmap : (is-a?/c bitmap%)
value
htdp-save-file-prefix : (listof string?)
procedure
(htdp-file-prefix? ip) -> boolean?
  ip : input-port?
signature
drracket:tool^ : signature
signature
drracket:tool-exports^ : signature
procedure
(phase1) -> void?
procedure
(phase2) -> void?
procedure
(drracket:get/extend:extend-unit-frame                                        
                                        mixin                                 
                                       [before                                
                                        #:name-for-changes name-for-changes]) 
 -> void?
  mixin : (make-mixin-contract drracket:unit:frame%)
  before : boolean? = #t
  name-for-changes : (or/c #f symbol?) = #f
procedure
(drracket:get/extend:get-unit-frame)
 -> (subclass?/c drracket:unit:frame%)
procedure
(drracket:get/extend:extend-tab                                        
                                 mixin                                 
                                [before                                
                                 #:name-for-changes name-for-changes]) 
 -> void?
  mixin : (make-mixin-contract drracket:unit:tab<%>)
  before : boolean? = #t
  name-for-changes : (or/c #f symbol?) = #f
procedure
(drracket:get/extend:get-tab)
 -> (implementation?/c drracket:unit:tab<%>)
procedure
(drracket:get/extend:extend-definitions-text                                        
                                              mixin                                 
                                             [before                                
                                              #:name-for-changes name-for-changes]) 
 -> void?
  mixin : (make-mixin-contract drracket:unit:definitions-text<%>)
  before : boolean? = #t
  name-for-changes : (or/c #f symbol?) = #f
procedure
(drracket:get/extend:get-definitions-text)
 -> (implementation?/c drracket:unit:definitions-text<%>)
procedure
(drracket:get/extend:extend-interactions-text                                        
                                               mixin                                 
                                              [before                                
                                               #:name-for-changes name-for-changes]) 
 -> void?
  mixin : (make-mixin-contract drracket:rep:text<%>)
  before : boolean? = #t
  name-for-changes : (or/c #f symbol?) = #f
procedure
(drracket:get/extend:get-interactions-text)
 -> (implementation?/c drracket:rep:text<%>)
procedure
(drracket:get/extend:extend-definitions-canvas                                        
                                                mixin                                 
                                               [before                                
                                                #:name-for-changes name-for-changes]) 
 -> void?
  mixin : (make-mixin-contract drracket:unit:definitions-canvas%)
  before : boolean? = #t
  name-for-changes : (or/c #f symbol?) = #f
procedure
(drracket:get/extend:get-definitions-canvas)
 -> (subclass?/c drracket:unit:definitions-canvas%)
procedure
(drracket:get/extend:extend-interactions-canvas                                        
                                                 mixin                                 
                                                [before                                
                                                 #:name-for-changes name-for-changes]) 
 -> void?
  mixin : (make-mixin-contract drracket:unit:interactions-canvas%)
  before : boolean? = #t
  name-for-changes : (or/c #f symbol?) = #f
procedure
(drracket:get/extend:get-interactions-canvas)
 -> (subclass?/c drracket:unit:interactions-canvas%)
procedure
(drracket:get/extend:disallow-re-extension!) -> void?
procedure
(drracket:get/extend:allow-re-extension!) -> void?
interface
drracket:unit:tab<%> : interface?
  implements: drracket:rep:context<%>
method
(send a-drracket:unit:tab break-callback) -> void?
method
(send a-drracket:unit:tab can-close?) -> boolean?
method
(send a-drracket:unit:tab disable-evaluation) -> void?
method
(send a-drracket:unit:tab enable-evaluation) -> void?
method
(send a-drracket:unit:tab get-breakables)
 -> (or/c thread? false/c)
    (or/c custodian? false/c)
method
(send a-drracket:unit:tab get-defs)
 -> (is-a?/c drracket:unit:definitions-text<%>)
method
(send a-drracket:unit:tab get-directory)
 -> (or/c string? false/c)
method
(send a-drracket:unit:tab get-enabled) -> boolean?
method
(send a-drracket:unit:tab get-frame)
 -> (is-a?/c drracket:unit:frame%)
method
(send a-drracket:unit:tab get-ints)
 -> (is-a?/c drracket:rep:text%)
method
(send a-drracket:unit:tab is-current-tab?) -> boolean?
method
(send a-drracket:unit:tab is-running?) -> boolean?
method
(send a-drracket:unit:tab on-close) -> void?
method
(send a-drracket:unit:tab reset-offer-kill) -> void?
method
(send a-drracket:unit:tab set-breakables thread         
                                         custodian) -> void?
  thread : (or/c thread? false/c)
  custodian : (or/c custodian? false/c)
method
(send a-drracket:unit:tab add-bkg-running-color id         
                                                color      
                                                label) -> void?
  id : symbol?
  color : (or/c string? (is-a?/c color%))
  label : string?
method
(send a-drracket:unit:tab remove-bkg-running-color id) -> void?
  id : symbol?
method
(send a-drracket:unit:tab touched) -> void?
method
(send a-drracket:unit:tab get-last-touched) -> flonum?
class
drracket:unit:tab% : class?
  superclass: object%
  extends: drracket:unit:tab<%>
constructor
(make-object drracket:unit:tab%)
 -> (is-a?/c drracket:unit:tab%)
method
(send a-drracket:unit:tab clear-annotations) -> void?
mixin
drracket:unit:program-editor-mixin : (class? . -> . class?)
  argument extends/implements: text%
                               editor:basic<%>
method
(send a-drracket:unit:program-editor after-delete start 
                                                  len)  
 -> void?
  start : number
  len : number
method
(send a-drracket:unit:program-editor after-insert start 
                                                  len)  
 -> void?
  start : number
  len : number
class
drracket:unit:interactions-canvas% : class?
  superclass: canvas:wide-snip%
constructor
(new drracket:unit:interactions-canvas% ...superclass-args...)
 -> (is-a?/c drracket:unit:interactions-canvas%)
class
drracket:unit:frame% : class?
  superclass: (drracket:frame:basics-mixin (drracket:frame:mixin
frame:searchable%))
  extends: drracket:unit:frame<%>
constructor
(new drracket:unit:frame% ...superclass-args...)
 -> (is-a?/c drracket:unit:frame%)
method
(send a-drracket:unit:frame add-show-menu-items show-menu)
 -> void?
  show-menu : (is-a?/c menu%)
method
(send a-drracket:unit:frame break-callback) -> void?
method
(send a-drracket:unit:frame change-to-file file) -> void?
  file : string?
method
(send a-drracket:unit:frame find-matching-tab p)
 -> (or/c (is-a?/c drracket:unit:tab%) #f)
  p : path-string?
method
(send a-drracket:unit:frame change-to-tab tab) -> void?
  tab : (is-a?/c drracket:unit:tab%)
method
(send a-drracket:unit:frame edit-menu:between-select-all-and-find)
 -> void?
method
(send a-drracket:unit:frame execute-callback) -> void?
method
(send a-drracket:unit:frame file-menu:between-open-and-revert)
 -> void?
method
(send a-drracket:unit:frame file-menu:between-print-and-close)
 -> void?
method
(send a-drracket:unit:frame file-menu:between-save-as-and-print)
 -> void?
method
(send a-drracket:unit:frame file-menu:print-string) -> void?
method
(send a-drracket:unit:frame file-menu:save-as-string) -> void?
method
(send a-drracket:unit:frame file-menu:save-string) -> void?
method
(send a-drracket:unit:frame get-break-button)
 -> (is-a?/c button%)
method
(send a-drracket:unit:frame get-button-panel)
 -> (is-a?/c horizontal-panel%)
method
(send a-drracket:unit:frame get-canvas)
 -> (is-a?/c editor-canvas%)
method
(send a-drracket:unit:frame get-canvas%) -> (is-a?/c canvas%)
method
(send a-drracket:unit:frame get-definitions/interactions-panel-parent)
 -> (is-a?/c vertical-panel%)
(send a-drracket:unit:frame get-definitions/interactions-panel-parent)
 -> void?
method
(send a-drracket:unit:frame get-editor) -> (is-a?/c editor<%>)
method
(send a-drracket:unit:frame get-editor%) -> (is-a?/c editor<%>)
method
(send a-drracket:unit:frame get-execute-button)
 -> (is-a?/c button%)
method
(send a-drracket:unit:frame get-text-to-search)
 -> (is-a?/c text:searching%)
method
(send a-drracket:unit:frame make-searchable canvas) -> void?
  canvas : (is-a?/c drracket:unit:interactions-canvas%)
method
(send a-drracket:unit:frame on-close) -> void?
method
(send a-drracket:unit:frame on-size) -> void?
method
(send a-drracket:unit:frame still-untouched?) -> boolean?
method
(send a-drracket:unit:frame update-save-button modified?)
 -> void?
  modified? : any/c
method
(send a-drracket:unit:frame update-save-message name) -> void?
  name : string?
method
(send a-drracket:unit:frame update-shown) -> void?
interface
drracket:unit:frame<%> : interface?
method
(send a-drracket:unit:frame get-language-menu)
 -> (is-a?/c menu%)
method
(send a-drracket:unit:frame ensure-defs-shown) -> void?
method
(send a-drracket:unit:frame ensure-rep-hidden) -> void?
method
(send a-drracket:unit:frame ensure-rep-shown) -> void?
method
(send a-drracket:unit:frame get-current-tab)
 -> (is-a?/c drracket:unit:tab<%>)
method
(send a-drracket:unit:frame get-tab-filename i) -> string?
  i : (<=/c 0 (get-tab-count))
method
(send a-drracket:unit:frame get-tab-count)
 -> exact-positive-integer?
method
(send a-drracket:unit:frame open-in-new-tab filename) -> void?
  filename : (or/c path-string? #f)
method
(send a-drracket:unit:frame create-new-tab) -> void?
method
(send a-drracket:unit:frame next-tab) -> void?
method
(send a-drracket:unit:frame prev-tab) -> void?
method
(send a-drracket:unit:frame move-current-tab-right) -> void?
method
(send a-drracket:unit:frame move-current-tab-left) -> void?
method
(send a-drracket:unit:frame reorder-tabs tab-order) -> void?
  tab-order : (listof exact-nonnegative-integer?)
method
(send a-drracket:unit:frame close-current-tab) -> void?
method
(send a-drracket:unit:frame get-definitions-canvas)
 -> (is-a?/c drracket:unit:definitions-canvas%)
method
(send a-drracket:unit:frame get-definitions-text)
 -> (is-a?/c drracket:unit:definitions-text%)
method
(send a-drracket:unit:frame get-insert-menu) -> (is-a?/c menu%)
method
(send a-drracket:unit:frame get-interactions-canvas)
 -> (instanceof (derivedfrom drracket:unit:interactions-canvas%))
method
(send a-drracket:unit:frame get-interactions-text)
 -> (is-a?/c drracket:rep:text%)
method
(send a-drracket:unit:frame get-tabs)
 -> (listof (is-a?/c drracket:unit:tab<%>))
method
(send a-drracket:unit:frame on-tab-change from-tab     
                                          to-tab)  -> void?
  from-tab : (is-a?/c drracket:unit:tab<%>)
  to-tab : (is-a?/c drracket:unit:tab<%>)
method
(send a-drracket:unit:frame register-capability-menu-item       
                                                          key   
                                                          menu) 
 -> void?
  key : symbol
  menu : (is-a? menu%)
method
(send a-drracket:unit:frame register-toolbar-button                 
                                                     tb             
                                                    [#:number num]) 
 -> void?
  tb : (is-a?/c switchable-button%)
  num : (or/c #f real?) = #f
method
(send a-drracket:unit:frame register-toolbar-buttons                   
                                                      tbs              
                                                     [#:numbers nums]) 
 -> void?
  tbs : (listof (is-a?/c switchable-button%))
  nums : (listof (or/c real? #f)) = (make-list (length tbs) #f)
method
(send a-drracket:unit:frame unregister-toolbar-button tb)
 -> void?
  tb : (is-a?/c switchable-button%)
method
(send a-drracket:unit:frame sort-toolbar-buttons-panel)
 -> void?
class
drracket:unit:definitions-text% : class?
  superclass: (drracket:rep:drs-bindings-keymap-mixin
(drracket:unit:program-editor-mixin (racket:text-mixin text:info%)))
  extends: drracket:unit:definitions-text<%>
constructor
(new drracket:unit:definitions-text%)
 -> (is-a?/c drracket:unit:definitions-text%)
method
(send a-drracket:unit:definitions-text set-filename) -> void?
method
(send a-drracket:unit:definitions-text set-modified) -> void?
interface
drracket:unit:definitions-text<%> : interface?
method
(send a-drracket:unit:definitions-text after-set-next-settings language-settings)
 -> void?
  language-settings : language-settings
method
(send a-drracket:unit:definitions-text begin-metadata-changes)
 -> void?
method
(send a-drracket:unit:definitions-text end-metadata-changes)
 -> void?
method
(send a-drracket:unit:definitions-text get-next-settings)
 -> language-settings
method
(send a-drracket:unit:definitions-text get-tab)
 -> (is-a?/c drracket:unit:tab%)
method
(send a-drracket:unit:definitions-text set-needs-execution-message msg)
 -> void?
  msg : string?
method
(send a-drracket:unit:definitions-text set-next-settings                    
                                                          language-settings 
                                                         [update-prefs?])   
 -> void?
  language-settings : language-settings
  update-prefs? : any/c = #t
class
drracket:unit:definitions-canvas% : class?
  superclass: editor-canvas%
procedure
(drracket:unit:get-program-editor-mixin)
 -> ((subclass?/c text%) . -> . (subclass?/c text%))
procedure
(drracket:unit:add-to-program-editor-mixin mixin) -> void?
  mixin : ((subclass?/c text%) . -> . (subclass?/c text%))
procedure
(drracket:unit:open-drscheme-window)
 -> (is-a?/c drracket:unit:frame%)
(drracket:unit:open-drscheme-window filename)
 -> (is-a?/c drracket:unit:frame%)
  filename : (or/c string? false/c)
procedure
(drracket:unit:add-search-help-desk-menu-item  text          
                                               menu          
                                               position      
                                              [add-sep]) -> void?
  text : (is-a?/c text%)
  menu : (is-a?/c menu-item-container<%>)
  position : exact-nonnegative-integer?
  add-sep : (-> any) = void
struct
(struct drracket:unit:teachpack-callbacks (get-names
                                           add
                                           remove
                                           remove-all)
    #:extra-constructor-name
    make-drracket:unit:teachpack-callbacks)
  get-names : (-> any/c (listof string?))
  add : (-> any/c path-string? any/c)
  remove : (-> path-string? any/c any/c)
  remove-all : (-> any/c any/c)
value
drracket:unit:struct:teachpack-callbacks : struct-type?
value
drracket:unit:make-teachpack-callbacks : procedure?
procedure
(drracket:unit:find-symbol text pos) -> string?
  text : (is-a?/c text%)
  pos : exact-nonnegative-integer?
interface
drracket:language:simple-module-based-language<%> : interface?
method
(send a-drracket:language:simple-module-based-language get-language-numbers)
 -> (cons number (listof number))
method
(send a-drracket:language:simple-module-based-language get-language-position)
 -> (cons string (listof string))
method
(send a-drracket:language:simple-module-based-language get-module)
 -> s-expression
method
(send a-drracket:language:simple-module-based-language get-one-line-summary)
 -> (or/c #f string?)
method
(send a-drracket:language:simple-module-based-language get-reader)
 -> (->* () (any/c input-port?) (or/c syntax? eof-object?))
class
drracket:language:simple-module-based-language% : class?
  superclass: object%
  extends: drracket:language:simple-module-based-language<%>
constructor
(make-object drracket:language:simple-module-based-language%                           
                                                              module                   
                                                              language-position        
                                                             [language-numbers         
                                                              one-line-summary         
                                                              documentation-reference] 
                                                              reader                   
                                                              language-id)             
 -> (is-a?/c drracket:language:simple-module-based-language%)
  module : s-expression
  language-position : (cons string (listof string))
  language-numbers : (cons number (listof number))
                   = (map (lambda (x) 0) language-position)
  one-line-summary : string? = ""
  documentation-reference : (or/c false/c something-else) = #f
  reader : (->* () (any/c input-port?) (or/c syntax? eof-object?))
  language-id : string?
method
(send a-drracket:language:simple-module-based-language get-language-numbers)
 -> (cons number (listof number))
method
(send a-drracket:language:simple-module-based-language get-language-position)
 -> s-expression
method
(send a-drracket:language:simple-module-based-language get-module)
 -> (cons string (listof string))
method
(send a-drracket:language:simple-module-based-language get-one-line-summary)
 -> string?
method
(send a-drracket:language:simple-module-based-language get-reader)
 -> (->* () (any/c input-port?) (or/c syntax? eof-object?))
mixin
drracket:language:simple-module-based-language->module-based-language-mixin : (class?
. -> . class?)
  argument extends/implements: drracket:language:simple-module-based-language<%>
  result implements: drracket:language:module-based-language<%>
method
(send a-drracket:language:simple-module-based-language->module-based-language config-panel)
 -> (case-> (-> settings) (settings -> void))
method
(send a-drracket:language:simple-module-based-language->module-based-language default-settings)
 -> settings
method
(send a-drracket:language:simple-module-based-language->module-based-language default-settings?)
 -> boolean?
method
(send a-drracket:language:simple-module-based-language->module-based-language get-init-code settings)
 -> sexpression
  settings : settings
method
(send a-drracket:language:simple-module-based-language->module-based-language get-transformer-module)
 -> s-expression
method
(send a-drracket:language:simple-module-based-language->module-based-language marshall-settings)
 -> writable
method
(send a-drracket:language:simple-module-based-language->module-based-language on-execute)
 -> void?
method
(send a-drracket:language:simple-module-based-language->module-based-language render-value)
 -> void?
method
(send a-drracket:language:simple-module-based-language->module-based-language render-value/format)
 -> void?
method
(send a-drracket:language:simple-module-based-language->module-based-language unmarshall-settings)
 -> (or/c false/c settings)
method
(send a-drracket:language:simple-module-based-language->module-based-language use-mred-launcher)
 -> boolean?
interface
drracket:language:module-based-language<%> : interface?
method
(send a-drracket:language:module-based-language config-panel parent)
 -> (case-> (-> settings) (settings -> void))
  parent : (is-a?/c panel%)
method
(send a-drracket:language:module-based-language default-settings)
 -> settings
method
(send a-drracket:language:module-based-language default-settings? settings)
 -> boolean?
  settings : settings
method
(send a-drracket:language:module-based-language get-init-code settings)
 -> sexp
  settings : settings
method
(send a-drracket:language:module-based-language get-language-numbers)
 -> (cons number (listof number))
method
(send a-drracket:language:module-based-language get-language-position)
 -> (cons string (listof string))
method
(send a-drracket:language:module-based-language get-module)
 -> s-expression
method
(send a-drracket:language:module-based-language get-one-line-summary)
 -> string?
method
(send a-drracket:language:module-based-language get-reader)
 -> (->* () (any/c input-port?) (or/c syntax? eof-object?))
method
(send a-drracket:language:module-based-language get-transformer-module)
 -> (or/c quoted-module-path #f)
method
(send a-drracket:language:module-based-language marshall-settings settings)
 -> writable
  settings : settings
method
(send a-drracket:language:module-based-language on-execute                     
                                                           settings            
                                                           run-on-user-thread) 
 -> void?
  settings : settings
  run-on-user-thread : ((-> void) -> void)
method
(send a-drracket:language:module-based-language render-value          
                                                             value    
                                                             settings 
                                                             port)    
 -> void?
  value : TST
  settings : settings
  port : port
method
(send a-drracket:language:module-based-language render-value/format          
                                                                    value    
                                                                    settings 
                                                                    port     
                                                                    width)   
 -> void?
  value : TST
  settings : settings
  port : port
  width : (or/c number (symbols 'infinity))
method
(send a-drracket:language:module-based-language unmarshall-settings input)
 -> (or/c settings false/c)
  input : writable
method
(send a-drracket:language:module-based-language use-mred-launcher)
 -> boolean?
method
(send a-drracket:language:module-based-language use-namespace-require/copy?)
 -> boolean?
mixin
drracket:language:module-based-language->language-mixin : (class? . -> .
class?)
  argument extends/implements: drracket:language:module-based-language<%>
  result implements: drracket:language:language<%>
method
(send a-drracket:language:module-based-language->language front-end/complete-program)
 -> (-> (or/c sexp/c syntax? eof-object?))
method
(send a-drracket:language:module-based-language->language front-end/interaction)
 -> (-> (or/c sexp/c syntax? eof-object?))
method
(send a-drracket:language:module-based-language->language get-language-name)
 -> string?
method
(send a-drracket:language:module-based-language->language on-execute)
 -> void?
interface
drracket:language:language<%> : interface?
method
(send a-drracket:language:language capability-value key) -> any
  key : symbol
method
(send a-drracket:language:language config-panel parent)
 -> (case-> (-> settings) (settings -> void))
  parent : (is-a?/c panel%)
method
(send a-drracket:language:language create-executable                   
                                                     settings          
                                                     parent            
                                                     program-filename) 
 -> void?
  settings : settings
  parent : (or/c (is-a?/c dialog%) (is-a?/c frame%))
  program-filename : string?
method
(send a-drracket:language:language default-settings)
 -> settings
method
(send a-drracket:language:language default-settings? settings)
 -> boolean?
  settings : settings
method
(send a-drracket:language:language first-opened settings)
 -> void?
  settings : settings
method
(send a-drracket:language:language front-end/complete-program           
                                                              port      
                                                              settings) 
 -> (-> (or/c sexp/c syntax? eof-object?))
  port : port
  settings : settings
method
(send a-drracket:language:language front-end/finished-complete-program settings)
 -> any
  settings : settings
method
(send a-drracket:language:language front-end/interaction           
                                                         port      
                                                         settings) 
 -> (-> (or/c sexp/c syntax? eof-object?))
  port : input-port
  settings : settings
method
(send a-drracket:language:language get-comment-character)
 -> string? char?
method
(send a-drracket:language:language get-language-name)
 -> string?
method
(send a-drracket:language:language get-language-numbers)
 -> (cons number (listof number))
method
(send a-drracket:language:language get-language-position)
 -> (cons string (listof string))
method
(send a-drracket:language:language get-language-url)
 -> (or/c string? false/c)
method
(send a-drracket:language:language get-metadata modname   
                                                settings) 
 -> string?
  modname : symbol?
  settings : any/c
method
(send a-drracket:language:language get-metadata-lines)
 -> number
method
(send a-drracket:language:language get-one-line-summary)
 -> string?
method
(send a-drracket:language:language get-reader-module)
 -> (or/c sexp-representing-a-require-spec false/c)
method
(send a-drracket:language:language get-style-delta)
 -> (or/c #f (is-a?/c style-delta%) (listof (list/c (is-a?/c style-delta%) number? number?)))
method
(send a-drracket:language:language extra-repl-information          
                                                          settings 
                                                          port)    
 -> void?
  settings : settings
  port : output-port?
method
(send a-drracket:language:language marshall-settings settings)
 -> writable
  settings : settings
method
(send a-drracket:language:language metadata->settings metadata)
 -> settings
  metadata : string?
method
(send a-drracket:language:language on-execute                     
                                              settings            
                                              run-on-user-thread) 
 -> any
  settings : settings
  run-on-user-thread : ((-> any) -> any)
method
(send a-drracket:language:language order-manuals manuals)
 -> (listof bytes?) boolean?
  manuals : (listof bytes?)
method
(send a-drracket:language:language render-value value    
                                                settings 
                                                port)    
 -> void?
  value : TST
  settings : settings
  port : port
method
(send a-drracket:language:language render-value/format          
                                                       value    
                                                       settings 
                                                       port     
                                                       width)   
 -> void?
  value : TST
  settings : settings
  port : port
  width : (or/c number (symbols 'infinity))
method
(send a-drracket:language:language unmarshall-settings input)
 -> (or/c settings false/c)
  input : writable
value
drracket:language:object/c : contract?
procedure
(drracket:language:register-capability s                
                                       the-contract     
                                       default)     -> void?
  s : symbol?
  the-contract : contract?
  default : the-contract
procedure
(drracket:language:capability-registered? s) -> boolean?
  s : symbol?
procedure
(drracket:language:get-capability-default s)
 -> (drracket:language:get-capability-contract s)
  s : (and/c symbol? drracket:language:capability-registered?)
procedure
(drracket:language:get-capability-contract s) -> contract?
  s : (and/c symbol? drracket:language:capability-registered?)
procedure
(drracket:language:add-snip-value  test-value        
                                   convert-value     
                                  [setup-thunk]) -> void?
  test-value : (-> any/c boolean?)
  convert-value : (-> any/c (is-a?/c snip%))
  setup-thunk : (-> any/c) = void
procedure
(drracket:language:extend-language-interface                         
                                             interface               
                                             default-implementation) 
 -> void?
  interface : interface?
  default-implementation : (make-mixin-contract drracket:language:language<%>)
procedure
(drracket:language:get-default-mixin)
 -> (make-mixin-contract drracket:language:language<%>)
procedure
(drracket:language:get-language-extensions)
 -> (listof interface?)
procedure
(drracket:language:put-executable parent           
                                  program-filename 
                                  mode             
                                  mred?            
                                  title)           
 -> (or/c false/c path?)
  parent : (is-a?/c top-level-window<%>)
  program-filename : path?
  mode : (or/c boolean? 'launcher 'standalone 'distribution)
  mred? : boolean?
  title : string?
procedure
(drracket:language:create-executable-gui parent       
                                         program-name 
                                         show-type    
                                         show-base)   
 -> (or/c false/c
          (list/c (or/c 'no-show 'launcher 'stand-alone 'distribution)
                  (or/c 'no-show 'mred 'mzscheme)
                  string?))
  parent : (or/c false/c (is-a?/c top-level-window<%>))
  program-name : (or/c false/c string?)
  show-type : (or/c #t 'launcher 'standalone 'distribution)
  show-base : (or/c #t 'mzscheme 'mred)
procedure
(drracket:language:create-module-based-stand-alone-executable                                  
                                                              program-filename                 
                                                              executable-filename              
                                                              module-language-spec             
                                                              transformer-module-language-spec 
                                                              init-code                        
                                                              gui?                             
                                                              use-copy?)                       
 -> void?
  program-filename : (or/c path? string?)
  executable-filename : (or/c path? string?)
  module-language-spec : any/c
  transformer-module-language-spec : any/c
  init-code : any/c
  gui? : boolean?
  use-copy? : boolean?
procedure
(drracket:language:create-module-based-distribution                                  
                                                    program-filename                 
                                                    distribution-filename            
                                                    module-language-spec             
                                                    transformer-module-language-spec 
                                                    init-code                        
                                                    gui?                             
                                                    use-copy?)                       
 -> void?
  program-filename : (or/c path? string?)
  distribution-filename : (or/c path? string?)
  module-language-spec : any/c
  transformer-module-language-spec : any/c
  init-code : any/c
  gui? : boolean?
  use-copy? : boolean?
procedure
(drracket:language:create-distribution-for-executable                       
                                                      distribution-filename 
                                                      gui?                  
                                                      make-executable)      
 -> void?
  distribution-filename : (or/c path? string?)
  gui? : boolean?
  make-executable : (-> path? void?)
procedure
(drracket:language:create-module-based-launcher                                  
                                                program-filename                 
                                                executable-filename              
                                                module-language-spec             
                                                transformer-module-language-spec 
                                                init-code                        
                                                gui?                             
                                                use-copy?)                       
 -> void?
  program-filename : (or/c path? string?)
  executable-filename : (or/c path? string?)
  module-language-spec : any/c
  transformer-module-language-spec : any/c
  init-code : any/c
  gui? : boolean?
  use-copy? : boolean?
procedure
(drracket:language:simple-module-based-language-convert-value           
                                                              value     
                                                              settings) 
 -> any
  value : any/c
  settings : drracket:language:simple-settings?
procedure
(drracket:language:setup-printing-parameters thunk        
                                             settings     
                                             width)   -> any
  thunk : (-> any)
  settings : drracket:language:simple-settings?
  width : (or/c number? 'infinity)
procedure
(drracket:language:make-setup-printing-parameters)
 -> (-> (-> any) drracket:language:simple-settings? (or/c number? 'infinity) any)
struct
(struct drracket:language:text/pos (text start end)
    #:extra-constructor-name make-drracket:language:text/pos)
  text : (is-a?/c text%)
  start : exact-nonnegative-integer?
  end : exact-nonnegative-integer?
value
drracket:language:make-text/pos : procedure?
value
drracket:language:struct:text/pos : struct-type?
struct
(struct drracket:language:simple-settings (case-sensitive
                                           printing-style
                                           fraction-style
                                           show-sharing
                                           insert-newlines
                                           annotations)
    #:extra-constructor-name
    make-drracket:language:simple-settings)
  case-sensitive : boolean?
  printing-style : (or/c 'constructor
                         'quasiquote
                         'write
                         'trad-write
                         'print)
  fraction-style : (or/c 'mixed-fraction
                         'mixed-fraction-e
                         'repeating-decimal
                         'repeating-decimal-e)
  show-sharing : boolean?
  insert-newlines : boolean?
  annotations : (or/c 'none 'debug 'debug/profile 'test-coverage)
value
drracket:language:make-simple-settings : procedure?
value
drracket:language:struct:simple-settings : struct-type?
procedure
(drracket:language:simple-settings->vector simple-settings)
 -> vector?
  simple-settings : drracket:language:simple-settings?
procedure
(drracket:language-configuration:get-languages)
 -> (listof (is-a?/c drracket:language:language<%>))
procedure
(drracket:language-configuration:add-language                                                            
                                               language                                                  
                                              [#:allow-executable-creation? allow-executable-creation?]) 
 -> void?
  language : (and/c (is-a?/c drracket:language:language<%>)
                    drracket:language:object/c)
  allow-executable-creation? : boolean? = #f
procedure
(drracket:language-configuration:get-settings-preferences-symbol)
 -> symbol?
struct
(struct drracket:language-configuration:language-settings
        (language
         settings)
    #:extra-constructor-name
    make-drracket:language-configuration:language-settings)
  language : (or/c (is-a?/c drracket:language:language<%>)
                   drracket:language:object/c)
  settings : any/c
value
drracket:language-configuration:struct:language-settings
 : struct-type?
value
drracket:language-configuration:make-language-settings
 : procedure?
procedure
(drracket:language-configuration:language-dialog                            
                                                  show-welcome?             
                                                  language-settings-to-show 
                                                 [parent])                  
 -> (or/c false/c drracket:language-configuration:language-settings?)
  show-welcome? : boolean?
  language-settings-to-show : drracket:language-configuration:language-settings?
  parent : (or/c false/c (is-a?/c top-level-window<%>)) = #t
procedure
(drracket:language-configuration:fill-language-dialog                   
                                                       panel            
                                                       button-panel     
                                                       language-setting 
                                                      [re-center        
                                                       ok-handler])     
 -> (-> (is-a?/c drracket:language:language<%>))
    (-> any/c)
    (-> any/c (is-a?/c mouse-event%) any)
  panel : (is-a?/c vertical-panel%)
  button-panel : (is-a?/c area-container<%>)
  language-setting : drracket:language-configuration:language-settings?
  re-center : (or/c false/c (is-a?/c top-level-window<%>)) = #f
  ok-handler : (-> symbol? void?) = void
mixin
drracket:debug:profile-unit-frame-mixin : (class? . -> . class?)
  argument extends/implements: drracket:frame:<%>
                               drracket:unit:frame<%>
mixin
drracket:debug:profile-interactions-text-mixin : (class? . -> . class?)
  argument extends/implements: drracket:rep:text<%>
mixin
drracket:debug:profile-definitions-text-mixin : (class? . -> . class?)
  argument extends/implements: drracket:unit:definitions-text<%>
                               text%
procedure
(drracket:debug:error-display-handler/stacktrace                             
                                                  msg                        
                                                  exn                        
                                                 [stack                      
                                                  #:definitions-text defs    
                                                  #:interactions-text ints]) 
 -> any/c
  msg : string?
  exn : any/c
  stack : (or/c false/c (listof srcloc?)) = #f
  defs : (or/c #f (is-a?/c drracket:unit:definitions-text<%>))
       = #f
  ints : (or/c #f (is-a?/c drracket:rep:text<%>)) = #f
procedure
(drracket:debug:make-debug-error-display-handler oedh)
 -> (-> string? (or/c any/c exn?) any)
  oedh : (-> string? (or/c any/c exn?) any)
procedure
(drracket:debug:hide-backtrace-window) -> void?
procedure
(drracket:debug:add-prefs-panel) -> void?
procedure
(drracket:debug:make-debug-eval-handler oe) -> (-> any/c any)
  oe : (-> any/c any)
parameter
(drracket:debug:test-coverage-enabled) -> boolean?
(drracket:debug:test-coverage-enabled enabled?) -> void?
  enabled? : boolean?
value
drracket:debug:test-coverage-on-style-name : string?
value
drracket:debug:test-coverage-off-style-name : string?
parameter
(drracket:debug:profiling-enabled) -> boolean?
(drracket:debug:profiling-enabled enabled?) -> void?
  enabled? : boolean?
procedure
(drracket:debug:bug-info->ticket-url query) -> url?
  query : (listof (cons/c symbol? (or/c #f string?)))
value
drracket:debug:small-planet-bitmap : (is-a?/c bitmap%)
procedure
(drracket:debug:open-and-highlight-in-file  debug-info     
                                           [edition-pair]) 
 -> void?
  debug-info : (or/c srcloc? (listof srcloc?))
  edition-pair : (or/c #f (cons/c (λ (x) (and (weak-box? x)
                                              (let ([v (weak-box-value x)])
                                                (or (not v)
                                                    (is-a?/c v editor<%>)))))
                                  number?))
               = #f
procedure
(drracket:debug:show-backtrace-window/edition-pairs                
                                                    error-message  
                                                    dis            
                                                    editions-pairs 
                                                    defs           
                                                    ints)          
 -> void?
  error-message : string?
  dis : (listof srcloc?)
  editions-pairs : (listof
                    (or/c
                     #f
                     (cons/c (λ (x)
                               (and (weak-box? x)
                                    (let ([v (weak-box-value x)])
                                      (or (not v)
                                          (is-a?/c v editor<%>)))))
                             number?)))
  defs : (or/c #f (is-a?/c drracket:unit:definitions-text<%>))
  ints : (or/c #f (is-a?/c drracket:rep:text<%>))
procedure
(drracket:debug:show-backtrace-window/edition-pairs/two                 
                                                        error-message   
                                                        dis1            
                                                        editions-pairs1 
                                                        dis2            
                                                        editions-pairs2 
                                                        defs            
                                                        ints)           
 -> void?
  error-message : string?
  dis1 : (listof srcloc?)
  editions-pairs1 : (listof
                     (or/c
                      #f
                      (cons/c (λ (x)
                                (and (weak-box? x)
                                     (let ([v (weak-box-value x)])
                                       (or (not v)
                                           (is-a?/c v editor<%>)))))
                              number?)))
  dis2 : (listof srcloc?)
  editions-pairs2 : (listof
                     (or/c
                      #f
                      (cons/c (λ (x)
                                (and (weak-box? x)
                                     (let ([v (weak-box-value x)])
                                       (or (not v)
                                           (is-a?/c v editor<%>)))))
                              number?)))
  defs : (or/c #f (is-a?/c drracket:unit:definitions-text<%>))
  ints : (or/c #f (is-a?/c drracket:rep:text<%>))
procedure
(drracket:debug:get-error-color) -> (is-a?/c color%)
procedure
(drracket:debug:show-backtrace-window  error-message     
                                       dis               
                                      [rep               
                                       defs])        -> void?
  error-message : string?
  dis : (or/c exn?
              (listof srcloc?)
              (non-empty-listof (cons/c string? (listof srcloc?))))
  rep : (or/c #f (is-a?/c drracket:rep:text<%>)) = #f
  defs : (or/c #f (is-a?/c drracket:unit:definitions-text<%>))
       = #f
procedure
(drracket:debug:srcloc->edition/pair  srcloc  
                                      ints    
                                      defs    
                                     [cache]) 
 -> (or/c #f (cons/c (let ([weak-box-containing-an-editor?
                            (λ (x) (and (weak-box? x)
                                        (let ([v (weak-box-value x)])
                                          (or (not v)
                                              (is-a?/c v editor<%>)))))])
                       weak-box-containing-an-editor?)
                     number?))
  srcloc : srcloc?
  ints : (or/c #f (is-a?/c drracket:rep:text<%>))
  defs : (or/c #f (is-a?/c drracket:unit:definitions-text<%>))
  cache : (or/c #f (and/c hash? hash-equal?)) = #f
interface
drracket:rep:text<%> : interface?
class
drracket:rep:text% : class?
  superclass: racket:text%
  extends: drracket:rep:text<%>
constructor
(make-object drracket:rep:text% context)
 -> (is-a?/c drracket:rep:text%)
  context : (implements drracket:rep:context<%>)
method
(send a-drracket:rep:text after-delete) -> void?
method
(send a-drracket:rep:text after-insert) -> void?
method
(send a-drracket:rep:text display-results results) -> void?
  results : (list-of TST)
method
(send a-drracket:rep:text evaluate-from-port                   
                                             port              
                                             complete-program? 
                                             cleanup)          
 -> any
  port : input-port?
  complete-program? : boolean?
  cleanup : (-> void)
method
(send a-drracket:rep:text after-many-evals) -> any
method
(send a-drracket:rep:text on-execute run-on-user-thread) -> any
  run-on-user-thread : (-> any)
method
(send a-drracket:rep:text get-error-range)
 -> (or/c false/c (list/c (is-a?/c text:basic%) number? number?))
method
(send a-drracket:rep:text get-user-custodian)
 -> (or/c false/c custodian?)
method
(send a-drracket:rep:text get-user-eventspace)
 -> (or/c false/c eventspace?)
method
(send a-drracket:rep:text get-user-language-settings)
 -> language-settings
method
(send a-drracket:rep:text get-user-namespace)
 -> (or/c false/c namespace?)
method
(send a-drracket:rep:text get-user-thread)
 -> (or/c false/c thread?)
method
(send a-drracket:rep:text highlight-errors  locs           
                                           [error-arrows]) 
 -> void?
  locs : (listof srcloc?)
  error-arrows : (or/c #f (listof srcloc?)) = #f
method
(send a-drracket:rep:text highlight-errors/exn exn) -> void?
  exn : exn
method
(send a-drracket:rep:text on-highlighted-errors loc/s) -> void?
  loc/s : (or/c srcloc? (listof srcloc?))
method
(send a-drracket:rep:text initialize-console) -> void?
method
(send a-drracket:rep:text insert-prompt) -> void?
method
(send a-drracket:rep:text kill-evaluation) -> void?
method
(send a-drracket:rep:text on-close) -> void?
method
(send a-drracket:rep:text queue-output thnk) -> void?
  thnk : (-> void?)
method
(send a-drracket:rep:text reset-console) -> void?
method
(send a-drracket:rep:text reset-highlighting) -> void?
method
(send a-drracket:rep:text run-in-evaluation-thread f) -> void?
  f : ( -> void)
method
(send a-drracket:rep:text shutdown) -> void?
method
(send a-drracket:rep:text wait-for-io-to-complete) -> void?
method
(send a-drracket:rep:text wait-for-io-to-complete/user)
 -> void?
mixin
drracket:rep:drs-bindings-keymap-mixin : (class? . -> . class?)
  argument extends/implements: editor:keymap<%>
method
(send a-drracket:rep:drs-bindings-keymap get-keymaps)
 -> (listof (is-a?/c keymap%))
interface
drracket:rep:context<%> : interface?
method
(send a-drracket:rep:context clear-annotations) -> void?
method
(send a-drracket:rep:context disable-evaluation) -> void?
method
(send a-drracket:rep:context enable-evaluation) -> void?
method
(send a-drracket:rep:context ensure-rep-shown rep) -> void?
  rep : (is-a?/c drracket:rep:text<%>)
method
(send a-drracket:rep:context get-breakables)
 -> (or/c thread? false/c)
    (or/c custodian? false/c)
method
(send a-drracket:rep:context get-directory)
 -> (union string false/c)
method
(send a-drracket:rep:context needs-execution)
 -> (or/c string? false/c)
method
(send a-drracket:rep:context reset-offer-kill) -> void?
method
(send a-drracket:rep:context set-breakables thread         
                                            custodian) -> void?
  thread : (or/c thread false/c)
  custodian : (or/c custodian false/c)
method
(send a-drracket:rep:context update-running running?) -> void?
  running? : any/c
procedure
(drracket:rep:get-welcome-delta) -> (is-a?/c style-delta%)
procedure
(drracket:rep:get-dark-green-delta) -> (is-a?/c style-delta%)
procedure
(drracket:rep:get-error-delta) -> (is-a?/c style-delta%)
procedure
(drracket:rep:get-drs-bindings-keymap) -> (is-a?/c keymap%)
procedure
(drracket:rep:current-rep)
 -> (or/c false/c (is-a?/c drracket:rep:text%))
procedure
(drracket:rep:current-value-port) -> (or/c false/c port?)
parameter
(drracket:rep:after-expression) -> (or/c #f (-> any))
(drracket:rep:after-expression top-level-expression) -> void?
  top-level-expression : (or/c #f (-> any))
parameter
(drracket:rep:current-language-settings)
 -> drracket:language-configuration:language-settings?
(drracket:rep:current-language-settings language-settings)
 -> void?
  language-settings : drracket:language-configuration:language-settings?
class
drracket:frame:name-message% : class?
  superclass: canvas%
constructor
(make-object drracket:frame:name-message% parent)
 -> (is-a?/c drracket:frame:name-message%)
  parent : (is-a?/c area-container<%>)
method
(send a-drracket:frame:name-message set-message name        
                                                short-name) 
 -> void?
  name : (or/c string? false/c)
  short-name : string?
mixin
drracket:frame:mixin : (class? . -> . class?)
  argument extends/implements: drracket:frame:basics<%>
                               frame:text-info<%>
                               frame:editor<%>
  result implements: drracket:frame:<%>
mixin
drracket:frame:basics-mixin : (class? . -> . class?)
  argument extends/implements: frame:standard-menus<%>
  result implements: drracket:frame:basics<%>
method
(send a-drracket:frame:basics edit-menu:between-find-and-preferences)
 -> void?
method
(send a-drracket:frame:basics file-menu:between-open-and-revert file-menu)
 -> void?
  file-menu : (is-a?/c menu%)
method
(send a-drracket:frame:basics file-menu:between-print-and-close file-menu)
 -> void?
  file-menu : (is-a?/c menu%)
method
(send a-drracket:frame:basics file-menu:new-callback item 
                                                     evt) 
 -> void?
  item : (is-a?/c menu-item%)
  evt : (is-a?/c control-event%)
method
(send a-drracket:frame:basics file-menu:new-string) -> string?
method
(send a-drracket:frame:basics file-menu:open-callback item 
                                                      evt) 
 -> void?
  item : (is-a?/c menu-item%)
  evt : (is-a?/c control-event%)
method
(send a-drracket:frame:basics file-menu:open-string) -> string?
method
(send a-drracket:frame:basics get-additional-important-urls)
 -> (listof (list string string))
method
(send a-drracket:frame:basics help-menu:about-callback item 
                                                       evt) 
 -> void?
  item : (is-a?/c menu-item%)
  evt : (is-a?/c control-event%)
method
(send a-drracket:frame:basics help-menu:about-string)
 -> string?
method
(send a-drracket:frame:basics help-menu:before-about help-menu)
 -> void?
  help-menu : (is-a?/c menu%)
method
(send a-drracket:frame:basics help-menu:create-about?)
 -> boolean?
interface
drracket:frame:basics<%> : interface?
  implements: frame:standard-menus<%>
interface
drracket:frame:<%> : interface?
  implements: frame:editor<%>
              frame:text-info<%>
              drracket:frame:basics<%>
method
(send a-drracket:frame: add-show-menu-items show-menu) -> void?
  show-menu : (is-a?/c menu%)
method
(send a-drracket:frame: set-show-menu-sort-key item     
                                               key) -> void?
  item : (is-a?/c menu-item<%>)
  key : (and/c real? positive?)
method
(send a-drracket:frame: get-show-menu) -> (is-a?/c menu%)
method
(send a-drracket:frame: update-shown) -> void?
procedure
(drracket:help-desk:help-desk [search-key           
                               search-context]) -> any
  search-key : (or/c #f string?) = #f
  search-context : (or/c #f string? (list/c string? string?))
                 = #f
procedure
(drracket:help-desk:goto-plt-license) -> void?
procedure
(drracket:eval:set-basic-parameters                               
                                     snipclasses                  
                                    [#:gui-modules? gui-modules]) 
 -> void?
  snipclasses : (listof (is-a?/c snip-class%))
  gui-modules : boolean? = #t
procedure
(drracket:eval:get-snip-classes)
 -> (listof (is-a?/c snip-class%))
procedure
(drracket:eval:expand-program  input                         
                               language-settings             
                               eval-compile-time-part?       
                               init                          
                               kill-termination              
                               iter                          
                              [#:gui-modules? gui-modules?]) 
 -> void?
  input : (or/c input-port? drracket:language:text/pos?)
  language-settings : drracket:language-configuration:language-settings?
  eval-compile-time-part? : boolean?
  init : (-> void?)
  kill-termination : (-> void?)
  iter : (-> (or/c eof-object? syntax? (cons/c string? any/c))
             (-> any)
             any)
  gui-modules? : boolean? = #t
procedure
(drracket:eval:traverse-program/multiple                               
                                          language-settings            
                                          init                         
                                          kill-termination             
                                         [#:gui-modules? gui-modules]) 
 -> (-> (or/c input-port? drracket:language:text/pos?)
        (-> (or/c eof-object? syntax? (cons/c string? any/c))
            (-> any)
            any)
        boolean?
        void?)
  language-settings : drracket:language-configuration:language-settings?
  init : (-> void?)
  kill-termination : (-> void?)
  gui-modules : boolean? = #t
procedure
(drracket:eval:expand-program/multiple                                
                                        language-settings             
                                        eval-compile-time-part?       
                                        init                          
                                        kill-termination              
                                       [#:gui-modules? gui-modules?]) 
 -> (-> (or/c input-port? drracket:language:text/pos?)
        (-> (or/c eof-object? syntax? (cons/c string? any/c))
            (-> any)
            any)
        boolean?
        void?)
  language-settings : drracket:language-configuration:language-settings?
  eval-compile-time-part? : boolean?
  init : (-> void?)
  kill-termination : (-> void?)
  gui-modules? : boolean? = #t
procedure
(drracket:eval:build-user-eventspace/custodian                                
                                                language-settings             
                                                init                          
                                                kill-termination              
                                               [#:gui-modules? gui-modules?]) 
 -> eventspace? custodian?
  language-settings : drracket:language-configuration:language-settings?
  init : (-> void?)
  kill-termination : (-> void?)
  gui-modules? : boolean? = #t
procedure
(drracket:modes:add-mode                                                            
                          name                                                      
                          surrogate                                                 
                          repl-submit                                               
                          matches-language                                          
                         [#:intended-to-edit-programs? intended-to-edit-programs?]) 
 -> drracket:modes:mode?
  name : string?
  surrogate : (or/c #f (is-a?/c mode:surrogate-text<%>))
  repl-submit : (-> (is-a?/c drracket:rep:text%) number? boolean?)
  matches-language : (-> (or/c #f (listof string?)) boolean?)
  intended-to-edit-programs? : boolean? = #t
struct
(struct drracket:modes:mode (name
                             surrogate
                             repl-submit
                             matches-language
                             intended-to-edit-programs?))
  name : string?
  surrogate : (or/c #f (is-a?/c mode:surrogate-text<%>))
  repl-submit : (-> (is-a?/c drracket:rep:text%) number? boolean?)
  matches-language : (-> (or/c #f (listof string?)) boolean?)
  intended-to-edit-programs? : boolean?
value
drracket:modes:struct:mode : struct-type?
procedure
(drracket:modes:get-modes) -> (listof drracket:modes:mode?)
procedure
(drracket:module-language-tools:add-opt-out-toolbar-button                    
                                                            make-button       
                                                            id                
                                                           [#:number number]) 
 -> void?
  make-button : (-> (is-a?/c top-level-window<%>)
                    (is-a?/c area-container<%>)
                    (is-a?/c switchable-button%))
  id : symbol?
  number : (or/c real? #f) = #f
procedure
(drracket:module-language-tools:add-online-expansion-handler                
                                                             mod-path       
                                                             id             
                                                             local-handler) 
 -> void?
  mod-path : path-string?
  id : symbol?
  local-handler : (-> (is-a?/c drracket:unit:definitions-text<%>)
                      any/c
                      any)
procedure
(drracket:module-language-tools:add-online-expansion-monitor                
                                                             mod-path       
                                                             id             
                                                             local-handler) 
 -> void?
  mod-path : path-string?
  id : symbol?
  local-handler : (-> (is-a?/c drracket:unit:definitions-text<%>)
                      (or/c drracket:module-language-tools:start?
                            any/c)
                      any)
procedure
(drracket:module-language-tools:start? val) -> boolean?
  val : any/c
procedure
(drracket:module-language-tools:register-online-expansion-pref func)
 -> void?
  func : (-> (is-a?/c vertical-panel%) void?)
procedure
(drracket:module-language-tools:done? val) -> boolean?
  val : any/c
value
drracket:module-language-tools:done
 : drracket:module-language-tools:done?
interface
drracket:language:module-language<%> : interface?
method
(send a-drracket:language:module-language get-users-language-name)
 -> string
procedure
(drracket:module-language:add-module-language) -> any
procedure
(drracket:module-language:module-language-put-file-mixin super%)
 -> (implementation?/c text:basic<%>)
  super% : (implementation?/c text:basic<%>)
value
drscheme:tool^ : any/c
value
drscheme:tool-exports^ : any/c
value
drscheme:debug:profile-definitions-text-mixin : any/c
value
drscheme:debug:profile-tab-mixin : any/c
value
drscheme:debug:profile-unit-frame-mixin : any/c
value
drscheme:debug:test-coverage-interactions-text-mixin : any/c
value
drscheme:debug:test-coverage-definitions-text-mixin : any/c
value
drscheme:debug:test-coverage-tab-mixin : any/c
value
drscheme:unit:tab% : any/c
value
drscheme:unit:frame% : any/c
value
drscheme:unit:definitions-canvas% : any/c
value
drscheme:unit:get-definitions-text% : any/c
value
drscheme:unit:interactions-canvas% : any/c
value
drscheme:rep:drs-bindings-keymap-mixin : any/c
value
drscheme:rep:text% : any/c
value
drscheme:rep:text<%> : any/c
value
drscheme:frame:mixin : any/c
value
drscheme:frame:basics-mixin : any/c
value
drscheme:language:language<%> : any/c
value
drscheme:language:module-based-language<%> : any/c
value
drscheme:language:simple-module-based-language<%> : any/c
value
drscheme:language:simple-module-based-language% : any/c
value
drscheme:language:simple-module-based-language->module-based-language-mixin
 : any/c
value
drscheme:language:module-based-language->language-mixin : any/c
value
drscheme:tracing:tab-mixin : any/c
value
drscheme:tracing:frame-mixin : any/c
value
drscheme:module-language:module-language<%> : any/c
value
drscheme:module-language-tools:frame-mixin : any/c
value
drscheme:module-language-tools:tab-mixin : any/c
value
drscheme:module-language-tools:definitions-text-mixin : any/c
value
drscheme:frame:basics<%> : any/c
value
drscheme:frame:<%> : any/c
value
drscheme:unit:frame<%> : any/c
value
drscheme:unit:definitions-text<%> : any/c
value
drscheme:unit:tab<%> : any/c
value
drscheme:rep:context<%> : any/c
value
drscheme:module-language-tools:definitions-text<%> : any/c
value
drscheme:module-language-tools:tab<%> : any/c
value
drscheme:module-language-tools:frame<%> : any/c
value
drscheme:debug:error-display-handler/stacktrace
 : (->* (string? any/c)
        ((or/c false/c (listof srcloc?))
         #:definitions-text (or/c #f (is-a?/c drracket:unit:definitions-text<%>))
         #:interactions-text (or/c #f (is-a?/c drracket:rep:text<%>)))
    
        any/c)
value
drscheme:debug:make-debug-error-display-handler
 : (-> (-> string? (or/c any/c exn?) any)
       (-> string? (or/c any/c exn?) any))
value
drscheme:debug:hide-backtrace-window : (-> void?)
value
drscheme:debug:add-prefs-panel : (-> void?)
value
drscheme:debug:make-debug-eval-handler
 : (-> (-> any/c any) (-> any/c any))
value
drscheme:debug:test-coverage-enabled : (parameter/c boolean?)
value
drscheme:debug:test-coverage-on-style-name : string?
value
drscheme:debug:test-coverage-off-style-name : string?
value
drscheme:debug:profiling-enabled : (parameter/c boolean?)
value
drscheme:debug:bug-info->ticket-url
 : (-> (listof (cons/c symbol? (or/c #f string?)))
       url?)
value
drscheme:debug:small-planet-bitmap : (is-a?/c bitmap%)
value
drscheme:debug:open-and-highlight-in-file
 : (->* ((or/c srcloc? (listof srcloc?)))
        ((or/c #f (cons/c (λ (x) (and (weak-box? x)
                                      (let ([v (weak-box-value x)])
                                        (or (not v)
                                            (is-a?/c v editor<%>)))))
                          number?)))
        void?)
value
drscheme:debug:show-backtrace-window/edition-pairs
 : (-> string?
       (listof srcloc?)
       (listof
        (or/c
         #f
         (cons/c (λ (x)
                   (and (weak-box? x)
                        (let ([v (weak-box-value x)])
                          (or (not v)
                              (is-a?/c v editor<%>)))))
                 number?)))
       (or/c #f (is-a?/c drracket:unit:definitions-text<%>))
       (or/c #f (is-a?/c drracket:rep:text<%>))
       void?)
value
drscheme:debug:show-backtrace-window/edition-pairs/two
 : (-> string?
       (listof srcloc?)
       (listof
        (or/c
         #f
         (cons/c (λ (x)
                   (and (weak-box? x)
                        (let ([v (weak-box-value x)])
                          (or (not v)
                              (is-a?/c v editor<%>)))))
                 number?)))
       (listof srcloc?)
       (listof
        (or/c
         #f
         (cons/c (λ (x)
                   (and (weak-box? x)
                        (let ([v (weak-box-value x)])
                          (or (not v)
                              (is-a?/c v editor<%>)))))
                 number?)))
       (or/c #f (is-a?/c drracket:unit:definitions-text<%>))
       (or/c #f (is-a?/c drracket:rep:text<%>))
       void?)
value
drscheme:debug:get-error-color : (-> (is-a?/c color%))
value
drscheme:debug:show-backtrace-window
 : (->* (string?
         (or/c exn?
               (listof srcloc?)
               (non-empty-listof (cons/c string? (listof srcloc?)))))
        ((or/c #f (is-a?/c drracket:rep:text<%>))
         (or/c #f (is-a?/c drracket:unit:definitions-text<%>)))
        void?)
value
drscheme:debug:srcloc->edition/pair
 : (->* (srcloc?
         (or/c #f (is-a?/c drracket:rep:text<%>))
         (or/c #f (is-a?/c drracket:unit:definitions-text<%>)))
        ((or/c #f (and/c hash? hash-equal?)))
        (or/c #f (cons/c (let ([weak-box-containing-an-editor?
                                (λ (x) (and (weak-box? x)
                                            (let ([v (weak-box-value x)])
                                              (or (not v)
                                                  (is-a?/c v editor<%>)))))])
                           weak-box-containing-an-editor?)
                         number?)))
value
drscheme:eval:set-basic-parameters
 : (->* ((listof (is-a?/c snip-class%)))
        (#:gui-modules? boolean?)
        void?)
value
drscheme:eval:get-snip-classes
 : (-> (listof (is-a?/c snip-class%)))
value
drscheme:eval:expand-program
 : (->* ((or/c input-port? drracket:language:text/pos?)
         drracket:language-configuration:language-settings?
         boolean?
         (-> void?)
         (-> void?)
         (-> (or/c eof-object? syntax? (cons/c string? any/c))
             (-> any)
             any))
        (#:gui-modules? boolean?)
        void?)
value
drscheme:eval:traverse-program/multiple
 : (->* (drracket:language-configuration:language-settings?
         (-> void?)
         (-> void?))
        (#:gui-modules? boolean?)
        (-> (or/c input-port? drracket:language:text/pos?)
            (-> (or/c eof-object? syntax? (cons/c string? any/c))
                (-> any)
                any)
            boolean?
            void?))
value
drscheme:eval:expand-program/multiple
 : (->* (drracket:language-configuration:language-settings?
         boolean?
         (-> void?)
         (-> void?))
        (#:gui-modules? boolean?)
        (-> (or/c input-port? drracket:language:text/pos?)
            (-> (or/c eof-object? syntax? (cons/c string? any/c))
                (-> any)
                any)
            boolean?
            void?))
value
drscheme:eval:build-user-eventspace/custodian
 : (->* (drracket:language-configuration:language-settings?
         (-> void?)
         (-> void?))
        (#:gui-modules? boolean?)
        (values eventspace? custodian?))
value
drscheme:get/extend:extend-unit-frame
 : (->i ([mixin (make-mixin-contract drracket:unit:frame%)])
        ([before boolean?]
         #:name-for-changes [name-for-changes (or/c #f symbol?)])
        [result void?])
value
drscheme:get/extend:get-unit-frame
 : (-> (subclass?/c drracket:unit:frame%))
value
drscheme:get/extend:extend-tab
 : (->i ([mixin (make-mixin-contract drracket:unit:tab<%>)])
        ([before boolean?]
         #:name-for-changes [name-for-changes (or/c #f symbol?)])
        [result void?])
value
drscheme:get/extend:get-tab
 : (-> (implementation?/c drracket:unit:tab<%>))
value
drscheme:get/extend:extend-definitions-text
 : (->i ([mixin (make-mixin-contract drracket:unit:definitions-text<%>)])
        ([before boolean?]
         #:name-for-changes [name-for-changes (or/c #f symbol?)])
        [result void?])
value
drscheme:get/extend:get-definitions-text
 : (-> (implementation?/c drracket:unit:definitions-text<%>))
value
drscheme:get/extend:extend-interactions-text
 : (->i ([mixin (make-mixin-contract drracket:rep:text<%>)])
        ([before boolean?]
         #:name-for-changes [name-for-changes (or/c #f symbol?)])
        [result void?])
value
drscheme:get/extend:get-interactions-text
 : (-> (implementation?/c drracket:rep:text<%>))
value
drscheme:get/extend:extend-definitions-canvas
 : (->i ([mixin (make-mixin-contract drracket:unit:definitions-canvas%)])
        ([before boolean?]
         #:name-for-changes [name-for-changes (or/c #f symbol?)])
        [result void?])
value
drscheme:get/extend:get-definitions-canvas
 : (-> (subclass?/c drracket:unit:definitions-canvas%))
value
drscheme:get/extend:extend-interactions-canvas
 : (->i ([mixin (make-mixin-contract drracket:unit:interactions-canvas%)])
        ([before boolean?]
         #:name-for-changes [name-for-changes (or/c #f symbol?)])
        [result void?])
value
drscheme:get/extend:get-interactions-canvas
 : (-> (subclass?/c drracket:unit:interactions-canvas%))
value
drscheme:get/extend:disallow-re-extension! : (-> void?)
value
drscheme:get/extend:allow-re-extension! : (-> void?)
value
drscheme:help-desk:help-desk
 : (->* ()
        ((or/c #f string?)
         (or/c #f string? (list/c string? string?)))
        any)
value
drscheme:help-desk:goto-plt-license : (-> void?)
value
drscheme:language-configuration:get-languages
 : (-> (listof (is-a?/c drracket:language:language<%>)))
value
drscheme:language-configuration:add-language
 : (->* ((and/c (is-a?/c drracket:language:language<%>)
                drracket:language:object/c))
        (#:allow-executable-creation? boolean?)
        void?)
value
drscheme:language-configuration:get-settings-preferences-symbol
 : (-> symbol?)
value
drscheme:language-configuration:language-settings?
 : (-> any/c boolean?)
value
drscheme:language-configuration:language-settings-language
 : (-> drracket:language-configuration:language-settings? (or/c (is-a?/c drracket:language:language<%>) drracket:language:object/c))
value
drscheme:language-configuration:language-settings-settings
 : (-> drracket:language-configuration:language-settings? any/c)
value
drscheme:language-configuration:struct:language-settings
 : struct-type?
value
drscheme:language-configuration:make-language-settings
 : procedure?
value
drscheme:language-configuration:language-dialog
 : (->* (boolean? drracket:language-configuration:language-settings?)
        ((or/c false/c (is-a?/c top-level-window<%>)))
        (or/c false/c drracket:language-configuration:language-settings?))
value
drscheme:language-configuration:fill-language-dialog
 : (->*
    ((is-a?/c vertical-panel%)
     (is-a?/c area-container<%>)
     drracket:language-configuration:language-settings?)
    ((or/c false/c (is-a?/c top-level-window<%>))
     (-> symbol? void?))
    (values (-> (is-a?/c drracket:language:language<%>))
            (-> any/c)
            (-> any/c (is-a?/c mouse-event%) any)))
value
drscheme:language:register-capability
 : (->i ([s symbol?]
         [the-contract contract?]
         [default (the-contract) the-contract])
        ()
        [res void?])
value
drscheme:language:capability-registered? : (-> symbol? boolean?)
value
drscheme:language:get-capability-default
 : (->i ([s (and/c symbol? drracket:language:capability-registered?)])
        ()
        [res (s) (drracket:language:get-capability-contract s)])
value
drscheme:language:get-capability-contract
 : (-> (and/c symbol? drracket:language:capability-registered?)
       contract?)
value
drscheme:language:add-snip-value
 : (->* ((-> any/c boolean?)
         (-> any/c (is-a?/c snip%)))
        ((-> any/c))
        void?)
value
drscheme:language:extend-language-interface
 : (-> interface?
       (make-mixin-contract drracket:language:language<%>)
       void?)
value
drscheme:language:get-default-mixin
 : (-> (make-mixin-contract drracket:language:language<%>))
value
drscheme:language:get-language-extensions
 : (-> (listof interface?))
value
drscheme:language:put-executable
 : ((is-a?/c top-level-window<%>)
    path?
    (or/c boolean? 'launcher 'standalone 'distribution)
    boolean?
    string?
    . -> . (or/c false/c path?))
value
drscheme:language:create-executable-gui
 : ((or/c false/c (is-a?/c top-level-window<%>))
    (or/c false/c string?)
    (or/c #t 'launcher 'standalone 'distribution)
    (or/c #t 'mzscheme 'mred)
    . -> .
    (or/c false/c
          (list/c (or/c 'no-show 'launcher 'stand-alone 'distribution)
                  (or/c 'no-show 'mred 'mzscheme)
                  string?)))
value
drscheme:language:create-module-based-stand-alone-executable
 : ((or/c path? string?)
    (or/c path? string?) any/c any/c any/c boolean? boolean?
    . -> .
    void?)
value
drscheme:language:create-module-based-distribution
 : ((or/c path? string?)
    (or/c path? string?) any/c any/c any/c boolean? boolean?
    . -> .
    void?)
value
drscheme:language:create-distribution-for-executable
 : ((or/c path? string?)
    boolean?
    (-> path? void?)
    . -> .
    void?)
value
drscheme:language:create-module-based-launcher
 : ((or/c path? string?) (or/c path? string?) any/c any/c any/c boolean? boolean?
                         . -> .
                         void?)
value
drscheme:language:simple-module-based-language-convert-value
 : (-> any/c drracket:language:simple-settings? any)
value
drscheme:language:setup-printing-parameters
 : (-> (-> any) drracket:language:simple-settings? (or/c number? 'infinity) any)
value
drscheme:language:make-setup-printing-parameters
 : (-> (-> (-> any) drracket:language:simple-settings? (or/c number? 'infinity) any))
value
drscheme:language:text/pos? : (-> any/c boolean?)
value
drscheme:language:text/pos-text
 : (-> drracket:language:text/pos? (is-a?/c text%))
value
drscheme:language:text/pos-start
 : (-> drracket:language:text/pos? exact-nonnegative-integer?)
value
drscheme:language:text/pos-end
 : (-> drracket:language:text/pos? exact-nonnegative-integer?)
value
drscheme:language:make-text/pos : procedure?
value
drscheme:language:struct:text/pos : struct-type?
value
drscheme:language:simple-settings? : (-> any/c boolean?)
value
drscheme:language:simple-settings-case-sensitive
 : (-> drracket:language:simple-settings? boolean?)
value
drscheme:language:simple-settings-printing-style
 : (-> drracket:language:simple-settings? (or/c 'constructor 'quasiquote 'write 'trad-write 'print))
value
drscheme:language:simple-settings-fraction-style
 : (-> drracket:language:simple-settings? (or/c 'mixed-fraction 'mixed-fraction-e 'repeating-decimal 'repeating-decimal-e))
value
drscheme:language:simple-settings-show-sharing
 : (-> drracket:language:simple-settings? boolean?)
value
drscheme:language:simple-settings-insert-newlines
 : (-> drracket:language:simple-settings? boolean?)
value
drscheme:language:simple-settings-annotations
 : (-> drracket:language:simple-settings? (or/c 'none 'debug 'debug/profile 'test-coverage))
value
drscheme:language:make-simple-settings : procedure?
value
drscheme:language:struct:simple-settings : struct-type?
value
drscheme:language:simple-settings->vector
 : (drracket:language:simple-settings? . -> . vector?)
value
drscheme:modes:add-mode
 : (->* (string?
         (or/c #f (is-a?/c mode:surrogate-text<%>))
         (-> (is-a?/c drracket:rep:text%) number? boolean?)
         (-> (or/c #f (listof string?)) boolean?))
        (#:intended-to-edit-programs? boolean?)
        drracket:modes:mode?)
value
drscheme:modes:mode? : (-> any/c boolean?)
value
drscheme:modes:mode-name : (-> drracket:modes:mode? string?)
value
drscheme:modes:mode-surrogate
 : (-> drracket:modes:mode? (or/c #f (is-a?/c mode:surrogate-text<%>)))
value
drscheme:modes:mode-repl-submit
 : (-> drracket:modes:mode? (-> (is-a?/c drracket:rep:text%) number? boolean?))
value
drscheme:modes:mode-matches-language
 : (-> drracket:modes:mode? (-> (or/c #f (listof string?)) boolean?))
value
drscheme:modes:mode-intended-to-edit-programs?
 : (-> drracket:modes:mode? boolean?)
value
drscheme:modes:struct:mode : struct-type?
value
drscheme:modes:get-modes : (-> (listof drracket:modes:mode?))
value
drscheme:module-language-tools:add-opt-out-toolbar-button
 : (->* ((-> (is-a?/c top-level-window<%>)
             (is-a?/c area-container<%>)
             (is-a?/c switchable-button%))
         symbol?)
        (#:number (or/c real? #f))
        void?)
value
drscheme:module-language-tools:add-online-expansion-handler
 : (-> path-string? symbol? (-> (is-a?/c drracket:unit:definitions-text<%>)
                                any/c
                                any)
       void?)
value
drscheme:module-language-tools:add-online-expansion-monitor
 : (-> path-string? symbol?
       (-> (is-a?/c drracket:unit:definitions-text<%>)
           (or/c drracket:module-language-tools:start?
                 any/c)
           any)
       void?)
value
drscheme:module-language-tools:start? : (-> any/c boolean?)
value
drscheme:module-language-tools:register-online-expansion-pref
 : (-> (-> (is-a?/c vertical-panel%) void?) void?)
value
drscheme:module-language-tools:done? : (-> any/c boolean?)
value
drscheme:module-language-tools:done
 : drracket:module-language-tools:done?
value
drscheme:module-language:add-module-language : (-> any)
value
drscheme:module-language:module-language-put-file-mixin
 : (-> (implementation?/c text:basic<%>) (implementation?/c text:basic<%>))
value
drscheme:rep:get-welcome-delta : (-> (is-a?/c style-delta%))
value
drscheme:rep:get-dark-green-delta : (-> (is-a?/c style-delta%))
value
drscheme:rep:get-error-delta : (-> (is-a?/c style-delta%))
value
drscheme:rep:get-drs-bindings-keymap : (-> (is-a?/c keymap%))
value
drscheme:rep:current-rep
 : (-> (or/c false/c (is-a?/c drracket:rep:text%)))
value
drscheme:rep:current-value-port : (-> (or/c false/c port?))
value
drscheme:rep:after-expression : (parameter/c (or/c #f (-> any)))
value
drscheme:rep:current-language-settings
 : (parameter/c drracket:language-configuration:language-settings?)
value
drscheme:unit:get-program-editor-mixin
 : (-> ((subclass?/c text%) . -> . (subclass?/c text%)))
value
drscheme:unit:add-to-program-editor-mixin
 : (((subclass?/c text%) . -> . (subclass?/c text%)) . -> . void?)
value
drscheme:unit:open-drscheme-window
 : (case->
    (-> (is-a?/c drracket:unit:frame%))
    ((or/c string? false/c) . -> . (is-a?/c drracket:unit:frame%)))
value
drscheme:unit:add-search-help-desk-menu-item
 : (->* ((is-a?/c text%) (is-a?/c menu-item-container<%>) exact-nonnegative-integer?) ((-> any)) void?)
value
drscheme:unit:teachpack-callbacks? : (-> any/c boolean?)
value
drscheme:unit:teachpack-callbacks-get-names
 : (-> drracket:unit:teachpack-callbacks? (-> any/c (listof string?)))
value
drscheme:unit:teachpack-callbacks-add
 : (-> drracket:unit:teachpack-callbacks? (-> any/c path-string? any/c))
value
drscheme:unit:teachpack-callbacks-remove
 : (-> drracket:unit:teachpack-callbacks? (-> path-string? any/c any/c))
value
drscheme:unit:teachpack-callbacks-remove-all
 : (-> drracket:unit:teachpack-callbacks? (-> any/c any/c))
value
drscheme:unit:struct:teachpack-callbacks : struct-type?
value
drscheme:unit:make-teachpack-callbacks : procedure?
value
drscheme:unit:find-symbol
 : (-> (is-a?/c text%) exact-nonnegative-integer? string?)
