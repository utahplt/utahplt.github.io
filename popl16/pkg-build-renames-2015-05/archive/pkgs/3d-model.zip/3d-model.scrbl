#lang scribble/manual

@title{3D Model Library}

@table-of-contents[]

@section{Introduction}
This library is used to represent 3 dimensional data as vertices and polygons (or polys in short) and also auxilary data such as materials and uvmaps.

This kind of representation is used fairly common among videogames and the like.
It is also used among most standard 3D model formats.
@section{Getting Started}
Install this library using planet or put it in racket staticlly.
Then see the function new-model to start generating model data.

A model is a container of meshes.
The meshes contain the actual data.

A mesh has a name aswell some amount of vertices, uv-cooridantes and polygons, also an optional origin vector to be used for movement calculations.
Each mesh must have a unique name.

At this time hierachry is not supported, all meshes are linearly stored.

Vertices and uv-coordiantes are referenced by polygons.
They can be refernced by multiple polygons.
New ones can be inserted without having to be referenced by a polygons.
However it is the programmers responsibility to ensure that polygons that have elements removed recive proper substitutes.

This library also provides some primitive geometric manipulative functions, but these are not optimized and thus unsuable for realtime or large scale data processing.
OpenGL support has been dileberatly omited to keep the library simple.
@section{Reference}

@defproc[(new-model [name (string?)]) mpair?]{
This function generates a new model object with a name, that stores meshes.

A model's actuall data is organized into and stored inside meshes.
}

@defproc[(add-mesh! [model (mpair?)] [name (string?)] [vertices (list?) '()] [uvs (list?) '()] [polys (list?) '()]) mesh?]{
Add a new mesh with a name to a model.

A mesh is the basic data container for 3 dimensional data.

Each mesh must have a unique name.

Can optionally be initialised with data, a list of verices, a list of uvmaps and a list of polys.

Returns the new mesh.
}

@defproc[(mesh? [mesh (any/c?)]) boolean?]{
Checks if a object represents a valid mesh.
}

@defproc[(get-mesh [model (mpair?)] [name (string?)]) (or/c mesh? boolean?)]{
Gets a mesh by name from a model.
}

@defproc[(get-mesh-name [mesh (mesh?)]) string?]{
Gets the name of a mesh.
}

@defproc[(rename-mesh! [mesh (mesh?)] [name (string?)]) void?]{
Renames a mesh.
}

@defproc[(delete-mesh! [model (mpair?)] [mesh (mesh?)]) void?]{
Deletes a mesh from a model.
}

@defproc[(join-meshes! [model (mpair?)] [mesh1 (mesh?)] [mesh2 (mesh?)]) void?]{
Joins mesh2 into mesh1.
This deletes mesh2 afterwards.
}

@defproc[(get-vertices [mesh (mesh?)]) list?]{
Gets list of the vertices of a mesh.
}

@defproc[(add-vertex! [mesh (mesh?)] [x (number?)] [y (number?)] [z (number?)]) void?]{
Adds a single point in space with the x y z coordinates.
}

@defproc[(delete-vertex! [mesh (mesh?)] [vertex (vector?)]) void?]{
Deletes a vertex from a mesh.
}

@defproc[(get-polys [mesh (mesh?)]) list?]{
Gets list of the polys of a mesh.
}

@defproc[(add-poly! [mesh (mesh?)] [vertices (list?) ()] [uvs (list?) ()] [material (string?) ""] [origin (vector?) #(0 0 0)]) void?]{
Adds a poly to a mesh consisting with optional vertex and the uv cooridante references aswell as a material and origin.
}

@defproc[(delete-poly! [mesh (mesh?)] [poly (vector?)]) void?]{
Deletes a poly from a mesh.

This function does not remove referenced vertices or uv-coordinates.
}

@defproc[(get-poly-vertices [mesh (mesh?)] [poly (vector?)]) list?]{
Gets a list the vertices of a poly.
}

@defproc[(get-uvmap [mesh (mesh?)]) list?]{
Gets a list the uv cooridnates of a mesh.
}

@defproc[(add-uv! [mesh (mesh?)] [x (number?)] [y (number?)] [z (number?)]) void?]{
Add uv coordinate to a mesh.
}

@defproc[(delete-uv! [mesh (mesh?)] [uv (vector?)]) void?]{
Deletes a uv coordinate from a mesh.
}

@defproc[(get-origin [mesh (mesh?)]) vector?]{
Get origin point of a mesh.

This defines the pivot point in rotations and for mirroring.
}

@defproc[(set-origin! [mesh (mesh?)] [x (number?)] [y (number?)] [z (number?)]) vector?]{
Set origin point of a mesh.
}

@defproc[(translate-vertex! [vertex (vector?)] [x-offset (number?)] [y-offset (number?)] [z-offset (number?)]) void?]{
Translate (move) a vertex by the given x y z offsets.
}

@defproc[(rotate-vertex! [vertex (vector?)] [xy (number?)] [yz (number?)] [zx (number?)] [origin (vector?)]) void?]{
Rotate a vertex clockwise around origin.

Rotation for each axis is specified by a floating number between 0 and 1, where 0 is no rotation and 1 would be one whole rotation.
0.5 would be a rotation of 180 degrees.
Numbers larger or equal than 1 will be wraped round.

Rotation is performed along 2 axis, you can choose any 2 axis.
Subsequent roatation along an axis 2 time will be complementary.

Caution: due to impercision in the representation subsequent rotation of large object may lead to significantly deformed results.
}

@defproc[(scale-vertex! [vertex (vector?)] [x (number?)] [y (number?)] [z (number?)]) void?]{
Scales a vertex some amount along any axis.
}

@defproc[(mirror-vertex! [vertex (vector?)] [x-axis (boolean?)] [y-axis (boolean?)] [z-axis (boolean?)] [origin (vector?)]) void?]{
Mirror a vertex at any of its axis relative to give origin.

Origin is a vector of 3 numbers, each describing the axis around which the mirroring should happen.

Set any of the cooridnate arguments to true to perform a mirroring on corresponding axis.
}

@defproc[(translate-mesh! [mesh (mesh?)] [x-offset (number?)] [y-offset (number?)] [z-offset (number?)]) void?]{
Translate (move) a mesh by the given x y z offsets.

Origin will be affected aswell.
}

@defproc[(rotate-mesh! [mesh (mesh?)] [xy (number?)] [yz (number?)] [zx (number?)]) void?]{
Rotate a mesh clockwise around origin.

Rotation for each axis is specified by a floating number between 0 and 1, where 0 is no rotation and 1 would be one whole rotation.
0.5 would be a rotation of 180 degrees.
Numbers larger or equal than 1 will be wraped round.

Rotation is performed along 2 axis, you can choose any 2 axis.
Subsequent roatation along an axis 2 time will be complementary.

Caution: due to impercision in the representation subsequent rotation of large object may lead to significantly deformed results.
}

@defproc[(scale-mesh! [mesh (mesh?)] [x (number?)] [y (number?)] [z (number?)]) void?]{
Scales a mesh some amount along any axis.
}

@defproc[(mirror-mesh! [mesh (mesh?)] [x-axis (boolean?)] [y-axis (boolean?)] [z-axis (boolean?)]) void?]{
Mirror a mesh at any of its axis relative to its origin.

Set any of the cooridnate arguments to true to perform a mirroring of corresponding axis.
}

@section{Copyright and contact}
Writen by "Code_Man".
Send feedback to Code_Man at Cybnet.ch.
See code_man.cybnet.ch for more stuff of mine.

Licenced under MIT X11.

No implied warranties or liability of any kind, use at own risk.
