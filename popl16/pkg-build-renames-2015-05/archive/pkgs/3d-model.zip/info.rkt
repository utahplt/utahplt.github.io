#lang info

(define collection "3d-model")
(define version "0.3")
(define scribblings '(("3d-model.scrbl" ())))
