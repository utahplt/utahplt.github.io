#lang racket

; 3d-model.rkt

; 3d model support using vertex/tri representation as meshes also handles origins, materials and uvmaps

; writen by "Code_Man" code_man@cybnet.ch

(provide (contract-out [new-model! (-> string? mpair?)]
                       [add-mesh! (->* (mpair? string?)
                                       (list? list? list?)
                                       mesh?)]
                       [mesh? (-> any/c boolean?)]
                       [get-mesh (-> mpair? string? (or/c mesh? false))]
                       [get-mesh-name (-> mesh? string?)]
                       [rename-mesh! (-> mesh? string? void)]
                       [delete-mesh! (-> mpair? mesh? void)]
                       [join-meshes! (-> mpair? mesh? mesh? void)]
                       [get-vertices (-> mesh? list?)]
                       [add-vertex! (-> mesh? number? number? number? void)]
                       [delete-vertex! (-> mesh? vector? void)]
                       [get-polys (-> mesh? list?)]
                       [add-poly! (-> mesh? list? list? string? vector? void)]
                       [delete-poly!(-> mesh? vector? void)]
                       [get-poly-vertices (-> mesh? vector? list?)]
                       [poly-to-tris (-> list? list? vector? string? list?)]
                       ;[delete-redundant-surfaces! (-> mesh? void)]
                       [get-uvmap (-> vector? list?)]
                       [add-uv! (-> vector? number? number? void)]
                       [delete-uv! (-> mesh? vector? any)]
                       ;[get-poly-uvs (-> mesh? vector? list?)]
                       [get-origin (-> mesh? vector?)]
                       [set-origin! (-> mesh? number? number? number? any)]
                       ;[calculate-center (-> mesh? vector?)]
                       [translate-vertex! (-> vector? number? number? number? void)]
                       [rotate-vertex! (-> vector? number? number? number? vector? void)]
                       [scale-vertex! (-> vector? number? number? number? void)]
                       [mirror-vertex! (-> vector? boolean? boolean? boolean? vector? void)]
                       [translate-mesh! (-> mesh? number? number? number? void)]
                       [rotate-mesh! (-> mesh? number? number? number? void)]
                       [scale-mesh! (-> mesh? number? number? number? void)]
                       [mirror-mesh! (-> mesh? boolean? boolean? boolean? void)])
         ;calculate-normal
         )

; Make a new model object
(define (new-model! name)
  (mcons name
         '()))

; Add a new mesh to a model with all fields empty
(define (add-mesh! model name [vertices '()] [uvs '()] [polys '()])
  (when false (error ""))
  (define mesh
    (vector name vertices uvs polys
            (vector 0 0 0)))
  (set-mcdr! model
             (append (mcdr model)
                     (list mesh)))
  mesh)

; Checks if a object represents a valid mesh
(define (mesh? mesh)
  (if (and (vector? mesh)
           (= (vector-length mesh)
              5))
      true false))

; Get a mesh by name from a model
(define (get-mesh model name)
  (ormap (lambda (mesh)
           (if (string=? (get-mesh-name mesh)
                         name)
               mesh false))
         (mcdr model)))

; Get the name of a mesh
(define (get-mesh-name mesh)
  (vector-ref mesh 0))

; Rename a mesh
(define (rename-mesh! mesh name)
  (vector-set! mesh 0 name))

; Delete a mesh from a model
(define (delete-mesh! model mesh)
  (set-mcdr! model
             (remove mesh (mcdr model))))

; Join mesh2 into mesh1
(define (join-meshes! model mesh1 mesh2)
  (let ((offset (length (get-vertices mesh1))))
    (vector-set! mesh1 1
                 (append (get-vertices mesh1)
                         (get-vertices mesh2)))
    (vector-set! mesh1 3
                 (append (get-polys mesh1)
                         (map (lambda (poly)
                                (map (lambda (vert)
                                       (+ vert offset))
                                     poly))
                              (get-polys mesh2))))
    (vector-set! mesh1 2
                 (append (get-uvmap mesh1)
                         (get-uvmap mesh2)))
    (delete-mesh! model mesh2)))

; Get the list of vertices of a mesh
(define (get-vertices mesh)
  (vector-ref mesh 1))

; Add new vertex to a mesh
(define (add-vertex! mesh x y z)
  (vector-set! mesh 1
               (append (get-vertices mesh)
                       (list (vector x y z)))))

; Deletes a vertex from a mesh
(define (delete-vertex! mesh vertex)
  (vector-set! mesh 1
               (remove vertex
                       (get-vertices mesh))))

; Gets polys of a mesh
(define (get-polys mesh)
  (vector-ref mesh 3))

; Adds a poly to a mesh
(define (add-poly! mesh vertices uvs material normal)
  (unless (= (length vertices)
             (length uvs))
         (error "diferent amount of vertex and uv indeces"))
  (vector-set! mesh 3
               (append (get-polys mesh)
                       (list (list vertices uvs material normal)))))

; Deletes a poly from a mesh
(define (delete-poly! mesh poly)
  (vector-set! mesh 3
               (remove poly
                       (get-polys mesh)
                       (lambda (a b)
                         (equal? a b)))))

; Gets the vertices of a poly
(define (get-poly-vertices mesh poly)
  (map (lambda (vindex)
         (list-ref (get-vertices mesh)
                   vindex))
       (list-ref poly 0)))

; Gets the uvs of a poly
(define (get-poly-uvs mesh poly)
  (map (lambda (vertex-index)
         (list-ref (get-vertices mesh)
                   vertex-index))
       (list-ref poly 1)))

; Gets material of a poly
(define (get-material poly)
  (list-ref poly 3))

; Sets material of a poly
(define (set-material poly material)
  (vector-set! poly 3 material))

; Converts a poly to a list of tris
(define (poly-to-tris face uv mesh material)
   (let ((tris
         '()))
     (do ([i 0
             (+ i 1)])
       ((>= i
            (- (length face)
               2)))
       (set! tris
             (append tris
                     (list (list (list (list-ref face 0)
                                       (list-ref face
                                                 (+ i 1))
                                       (list-ref face
                                                 (+ i 2))) 
                                 (list (list-ref uv 0)
                                       (list-ref uv 
                                                 (+ i 1))
                                       (list-ref uv
                                                 (+ i 2)))
                           material
                           (vector 0 0 0))))))
     ;(do ([i 0
     ;        (+ i 1)])
     ;  ((>= i
     ;       (- (length tris)
     ;          1)))
     ;  (add-uv! mesh (vector-ref (list-ref (get-vertices mesh)
     ;                                      (list-ref face 0))
     ;                            0)
     ;           0)
     ;  (add-uv! mesh (vector-ref (list-ref (get-vertices mesh)
     ;                                      (list-ref face 0))
     ;                            0)
     ;           0))
     tris))

; Convert a list of tris to polys
(define (tris-to-polys mesh)
  (map (lambda (tri1)
         (map (lambda (tri2)
                (unless (equal? tri1 tri2)
                  tri2))))
       (get-polys mesh)))

; Calculate normal of a tri
(define (calculate-normal tri mesh)
  (let ((vertices (vector (list-ref (get-vertices mesh)
                                    (vector-ref tri 0))
                          (list-ref (get-vertices mesh)
                                    (vector-ref tri 1))
                          (list-ref (get-vertices mesh)
                                    (vector-ref tri 2))))
        (normal (vector 0 0 0)))
    (vector-set! normal 0
                 (- (vector-ref (vector-ref vertices 0)
                                0)
                    (vector-ref (vector-ref vertices 1)
                                0)))
    (vector-set! normal 1
                 (- (vector-ref (vector-ref vertices 0)
                                1)
                    (vector-ref (vector-ref vertices 1)
                                1)))
    (vector-set! normal 2
                 (- (vector-ref (vector-ref vertices 0)
                                2)
                    (vector-ref (vector-ref vertices 1)
                                2)))
    (vector-set! normal 0
                 (if (= (vector-ref normal 1)
                        0)
                     0
                     (/ (vector-ref normal 0)
                        (vector-ref normal 1))))
    (vector-set! normal 2
                 (if (= (vector-ref normal 1)
                        0)
                     0
                     (if (< (vector-ref normal 1)
                            (vector-ref normal 2))
                         (/ (/ (vector-ref normal 2)
                               (vector-ref normal 1))
                            2)
                         (+ 0.5 
                            (/ 1
                               (/ (vector-ref normal 2)
                                  (vector-ref normal 1)))))))
    (vector-set! normal 1 0)
    normal))

; 
(define (delete-redundant-surfaces! mesh)
  (let ((verts1 '())
        (verts2 '())
        (assoc '())
        (multi 0))
    (for-each (lambda (face1)
                (set! verts1 ; Cache vertices
                      (get-poly-vertices mesh face1))
                (for-each (lambda (face2)
                            (unless (equal? face1 face2)
                              (set! verts2
                                    (get-poly-vertices mesh face2))
                              (when (andmap (lambda (vertex)
                                              (and (ormap (lambda (x)
                                                            (ormap (lambda (y)
                                                                     (and (<= (vector-ref vertex 0)
                                                                              (max (vector-ref x 0)
                                                                                   (vector-ref y 0)))
                                                                          (>= (vector-ref vertex 0)
                                                                              (min (vector-ref x 0)
                                                                                   (vector-ref y 0)))
                                                                          (<= (vector-ref vertex 1)
                                                                              (max (vector-ref x 1)
                                                                                   (vector-ref y 1)))
                                                                          (>= (vector-ref vertex 1)
                                                                              (min (vector-ref x 1)
                                                                                   (vector-ref y 1)))
                                                                          (<= (vector-ref vertex 2)
                                                                              (max (vector-ref x 2)
                                                                                   (vector-ref y 2)))
                                                                          (>= (vector-ref vertex 2)
                                                                              (min (vector-ref x 2)
                                                                                   (vector-ref y 2)))))
                                                                   verts2))
                                                          verts2)
                                                   (set! assoc ; 
                                                         (apply append ; flaten the topmost lists
                                                                (map (lambda (x)
                                                                       (remove* (list false)
                                                                                (map (lambda (y)
                                                                                       (if (and (<= (vector-ref vertex 0)
                                                                                                    (max (vector-ref x 0)
                                                                                                         (vector-ref y 0)))
                                                                                                (>= (vector-ref vertex 0)
                                                                                                    (min (vector-ref x 0)
                                                                                                         (vector-ref y 0)))
                                                                                                (<= (vector-ref vertex 1)
                                                                                                    (max (vector-ref x 1)
                                                                                                         (vector-ref y 1)))
                                                                                                (>= (vector-ref vertex 1)
                                                                                                    (min (vector-ref x 1)
                                                                                                         (vector-ref y 1)))
                                                                                                (<= (vector-ref vertex 2)
                                                                                                    (max (vector-ref x 2)
                                                                                                         (vector-ref y 2)))
                                                                                                (>= (vector-ref vertex 2)
                                                                                                    (min (vector-ref x 2)
                                                                                                         (vector-ref y 2))))
                                                                                           (cons x y)
                                                                                           false))
                                                                                     verts2)))
                                                                     verts2)))
                                                   (set! assoc
                                                         (car (sort assoc
                                                                          (lambda (a b)
                                                                            (and (>= (vector-ref (car a)
                                                                                                 0)
                                                                                     (vector-ref (car a)
                                                                                                 0))
                                                                                 (<= (vector-ref (car b)
                                                                                                 0)
                                                                                     (vector-ref (car b)
                                                                                                 0))))
                                                                          )))
                                                   ; When all tri2 vertices are contained inside ...
                                                   ; Inside a box made from the vertices of tri1 ...
                                                   ; Tri2 could be contained inside it
                                                   (and (>= (vector-ref vertex 0)
                                                            (+ (* (- (vector-ref vertex 1)
                                                                     (vector-ref (if (<= (vector-ref (car assoc)
                                                                                                     1)
                                                                                         (vector-ref (cdr assoc)
                                                                                                     1))
                                                                                     (car assoc)
                                                                                     (cdr assoc))
                                                                                 1))
                                                                  (if (<= (abs (- (vector-ref (car assoc)
                                                                                              0)
                                                                                  (vector-ref (cdr assoc)
                                                                                              0)))
                                                                          (abs (- (vector-ref (car assoc)
                                                                                              1)
                                                                                  (vector-ref (cdr assoc)
                                                                                              1))))
                                                                      (/ (- (vector-ref (car assoc)
                                                                                        0)
                                                                            (vector-ref (cdr assoc)
                                                                                        0))
                                                                         (- (vector-ref (car assoc)
                                                                                        1)
                                                                            (vector-ref (cdr assoc)
                                                                                        1))
                                                                         2)
                                                                      (- 1
                                                                         (/ (- (vector-ref (car assoc)
                                                                                           1)
                                                                               (vector-ref (cdr assoc)
                                                                                           1))
                                                                            (- (vector-ref (car assoc)
                                                                                           0)
                                                                               (vector-ref (cdr assoc)
                                                                                           0))
                                                                            2))))
                                                               (vector-ref (if (<= (vector-ref (car assoc)
                                                                                               1)
                                                                                   (vector-ref (cdr assoc)
                                                                                               1))
                                                                               (car assoc)
                                                                               (cdr assoc))
                                                                           0)))
                                                        (<= (vector-ref vertex
                                                                        0)
                                                            (+ (* (- (vector-ref vertex
                                                                                 1)
                                                                     (vector-ref (if (<= (vector-ref (car assoc)
                                                                                                     1)
                                                                                         (vector-ref (cdr assoc)
                                                                                                     1))
                                                                                     (car assoc)
                                                                                     (cdr assoc))
                                                                                 1))
                                                                  (if (<= (abs (- (vector-ref (car assoc)
                                                                                              0)
                                                                                  (vector-ref (cdr assoc)
                                                                                              0)))
                                                                          (abs (- (vector-ref (car assoc)
                                                                                              1)
                                                                                  (vector-ref (cdr assoc)
                                                                                              1))))
                                                                      (/ (- (vector-ref (car assoc)
                                                                                        0)
                                                                            (vector-ref (cdr assoc)
                                                                                        0))
                                                                         (- (vector-ref (car assoc)
                                                                                        1)
                                                                            (vector-ref (cdr assoc)
                                                                                        1))
                                                                         2)
                                                                      (- 1
                                                                         (/ (- (vector-ref (car assoc)
                                                                                           1)
                                                                               (vector-ref (cdr assoc)
                                                                                           1))
                                                                            (- (vector-ref (car assoc)
                                                                                           0)
                                                                               (vector-ref (cdr assoc)
                                                                                           0))
                                                                            2))))
                                                               (vector-ref (if (>= (vector-ref (car assoc)
                                                                                               1)
                                                                                   (vector-ref (cdr assoc)
                                                                                               1))
                                                                               (car assoc)
                                                                               (cdr assoc))
                                                                           0))
                                                            ))))
                                            verts1)
                                (delete-poly! mesh face1))))
                          (get-polys mesh)))
              (get-polys mesh))
    void))

; Get uvmap of a mesh
(define (get-uvmap mesh)
  (vector-ref mesh 2))

; Add uv to a mesh
(define (add-uv! mesh u v)
  (vector-set! mesh 2
               (append (get-uvmap mesh)
                       (list (vector u v)))))

; Delete uv of a mesh
(define (delete-uv! mesh uv)
  (vector-set! mesh 2
               (remove uv mesh)))

; Get origin point of a mesh
(define (get-origin mesh)
  (vector-ref mesh 4))

; Set origin point of a mesh
(define (set-origin! mesh x y z)
  (vector-set! mesh 4
               (vector x y z)))

; Calculate the center of a mesh
(define (calculate-center mesh)
  (let ((x 0)
        (y 0)
        (z 0)
        (vertices (get-vertices mesh)))
    (for-each (lambda (vertex)
                (set! x
                      (+ x 
                         (apply +
                                (map (lambda (v)
                                       (- (vector-ref vertex 0)
                                          (vector-ref v 0)))
                                     vertices)))))
              vertices)
    (vector x y z)))

; 
(define (flat-uvmap mesh)
  (for-each (lambda (v)
              (display v))
            (get-vertices mesh)))

; 
(define (calulate-length a b)
  (sqrt (+ (expt (abs (- (vector-ref a 0)
                         (vector-ref b 0)))
                 2)
           (expt (abs (- (vector-ref a 0)
                         (vector-ref b 0)))
                 2))))

; Translate (move) a vertex by some fixed amount
(define (translate-vertex! vertex x-offset y-offset z-offset)
  (vector-set! vertex 0
               (+ (vector-ref vertex 0)
                  x-offset))
  (vector-set! vertex 1
               (+ (vector-ref vertex 1)
                  y-offset))
  (vector-set! vertex 2
               (+ (vector-ref vertex 2)
                  z-offset)))

; Rotate vertex
(define (rotate-vertex! vertex xy-axis yz-axis xz-axis origin)
  (set! xy-axis
        (- xy-axis
           (floor xy-axis)))
    (set! yz-axis
        (- yz-axis
           (floor yz-axis)))
    (set! xz-axis
        (- xz-axis
           (floor xz-axis)))
  (let ((val '()))
    (set! val
          (rotate (vector-ref vertex 0)
                  (vector-ref vertex 1)
                  (vector-ref origin 0)
                  (vector-ref origin 1)
                  xy-axis))
    (vector-set! vertex 0
                 (car val))
    (vector-set! vertex 1
                 (cdr val))
    (set! val
          (rotate (vector-ref vertex 1)
                  (vector-ref vertex 2)
                  (vector-ref origin 1) 
                  (vector-ref origin 2) 
                  yz-axis))
    (vector-set! vertex 1
                 (car val))
    (vector-set! vertex 2
                 (cdr val))
    (set! val
          (rotate (vector-ref vertex 0)
                  (vector-ref vertex 2)
                  (vector-ref origin 0)
                  (vector-ref origin 2)
                  xz-axis))
    (vector-set! vertex 0
                 (car val))
    (vector-set! vertex 2
                 (cdr val))))

; Scale a vertex
(define (scale-vertex! vertex x-scale y-scale z-scale)
  (vector-set! vertex 0
               (* (vector-ref vertex 0)
                  x-scale))
  (vector-set! vertex 1
               (* (vector-ref vertex 1)
                  y-scale))
  (vector-set! vertex 2
               (* (vector-ref vertex 2)
                  z-scale)))

; Mirror a vertex
(define (mirror-vertex! vertex x-axis y-axis z-axis origin)
  (when x-axis
    (vector-set! vertex 0)
    (- (- (vector-ref vertex 0)
          (if origin
              (vector-ref origin 0)
              0))))
  (when y-axis
    (vector-set! vertex 1)
    (- (- (vector-ref vertex 1)
          (if origin
              (vector-ref origin 1)
              1))))
  (when x-axis
    (vector-set! vertex 2)
    (- (- (vector-ref vertex 2)
          (if origin
              (vector-ref origin 2)
              2)))))

; Translate (move) a mesh by some fixed amount
(define (translate-mesh! mesh x-offset y-offset z-offset)
  (for-each (lambda (vertex)
              (translate-vertex! vertex x-offset y-offset z-offset))
            (get-vertices mesh))
  (set-origin! mesh ; If the mesh moves so does the origin
               (+ (vector-ref (get-origin mesh)
                              0)
                  x-offset)
               (+ (vector-ref (get-origin mesh)
                              1)
                  y-offset)
               (+ (vector-ref (get-origin mesh)
                              2)
                  z-offset)))

; Perform clockwise rotational opertion in 2 arbitrary axis
(define (rotate x y xo yo rot)
  (let* ((ang (if (<= (abs (- x xo)) ; Calculate the ratio of both axis
                      (abs (- y yo)))
                  (/ (abs (- x xo))
                     (abs (- y yo))
                     2)
                  (- 1 ; 
                     (/ (abs (- y yo))
                        (abs (- x yo))
                        2))))
         (len (+ (* (abs (- x xo)) ; Calculate length between vertex and origin
                    (sqrt ang))
                 (* (abs (- y yo))
                    (sqrt (- 1 ang)))))
         (c (when (or (and (<= y 0) ;
                           (> x 0))
                      (and (>= (- y yo)
                               0)
                           (< (- x xo)
                              0)))
              (set! ang ;
                    (- 1 ang))))
         (d (cond [(> rot .75) ; Filter out operations in other quadrant
                   (- rot .75)]
                  [(> rot .5)
                   (- rot .5)]
                  [(> rot .25)
                   (- rot .25)]
                  [true rot])))
    (set! rot
          (- rot d))
    (set! d ;
          (+ (* d 4)
             ang))
    (when (> d 1)
      (set! rot
            (+ rot
               (- (/ d 4)
                  .25)))
      (when (>= rot 1)
        (set! rot
              (- rot 1)))
      (set! d 1))
    (cond ; Perform specific x and y scaling operation depending on quadrant
      [(and (>= x xo)
            (> y yo))
       (set! x
             (* len
                (sqrt d)))
       (set! y
             (* len
                (sqrt (- 1 d))))]
      [(and (> x xo)
            (<= y yo))
       (set! x
             (* len
                (sqrt (- 1 d))))
       (set! y
             (- (* len
                   (sqrt d))))]
      [(and (<= x xo)
            (< y yo))
       (set! x
             (- (* len
                   (sqrt d))))
       (set! y
             (- (* len
                   (sqrt (- 1 d)))))]
      [(and (< x xo)
            (>= y yo))
       (set! x
             (- (* len
                   (sqrt (- 1 d)))))
       (set! y
             (* len
                (sqrt d)))])
    (if (> rot 0)
        (rotate x y xo yo rot) ; Perform potential rotations inside remaining quadrants
        (cons x y))))

; Rotate mesh
(define (rotate-mesh! mesh xy-axis yz-axis xz-axis)
  (for-each (lambda (vertex)
              (rotate-vertex! vertex xy-axis yz-axis xz-axis
                              (get-origin mesh)))
            (get-vertices mesh)))

; Scale a mesh
(define (scale-mesh! mesh x-scale y-scale z-scale)
  (for-each (lambda (vertex)
              (scale-vertex! vertex x-scale y-scale z-scale))
            (get-vertices mesh)))

; Mirror a mesh
(define (mirror-mesh! mesh x-axis y-axis z-axis)
  (for-each (lambda (vertex)
              (mirror-vertex! vertex x-axis y-axis z-axis
                              (get-origin mesh)))
            (get-vertices mesh)))
