27322
((3) 0 () 60 ((q lib "net/nntp.rkt") (q lib "net/uri-codec.rkt") (q lib "net/tcp-sig.rkt") (q lib "net/cookie.rkt") (q lib "net/imap.rkt") (q lib "net/pop3.rkt") (q lib "net/mime.rkt") (q 29821 . 26) (q lib "net/base64.rkt") (q lib "net/url.rkt") (q lib "net/cgi.rkt") (q 30584 . 16) (q lib "net/http-client.rkt") (q 29297 . 4) (q lib "net/qp.rkt") (q lib "net/ftp.rkt") (q 33213 . 3) (q lib "net/sendurl.rkt") (q lib "net/unihead.rkt") (q 28396 . 4) (q lib "net/head.rkt") (q lib "net/url-structs.rkt") (q 4067 . 18) (q 31554 . 4) (q 33938 . 7) (q 25730 . 8) (q 28021 . 3) (q 37144 . 3) (q 28561 . 5) (q 36228 . 4) (q 28294 . 3) (q 36756 . 4) (q 36902 . 3) (q 32001 . 3) (q 36064 . 5) (q 29142 . 4) (q 31401 . 4) (q 28749 . 5) (q 36351 . 4) (q 4660 . 5) (q 43689 . 3) (q 33113 . 3) (q 35989 . 3) (q 31703 . 3) (q 33035 . 3) (q 31168 . 3) (q 28947 . 5) (q 28192 . 3) (q 31901 . 3) (q 29647 . 6) (q 31260 . 4) (q lib "net/dns.rkt") (q 37004 . 4) (q lib "net/url-sig.rkt") (q 36496 . 4) (q 36625 . 4) (q lib "net/sendmail.rkt") (q 28096 . 3) (q 31807 . 3) (q lib "net/smtp.rkt")) () (h ! (equal) ((c def c (c (? . 6) q entity-charset)) c (? . 7)) ((c def c (c (? . 3) q cookie:secure)) q (43147 . 4)) ((c def c (c (? . 15) q ftp-establish-connection)) q (11406 . 9)) ((c def c (c (? . 4) q imap-flag->symbol)) q (23746 . 3)) ((c def c (c (? . 8) q base64-decode)) q (32291 . 3)) ((c def c (c (? . 0) q communicator-server)) c (? . 24)) ((c def c (c (? . 1) q uri-unreserved-encode)) q (10403 . 3)) ((q def ((lib "net/url-unit.rkt") url@)) q (9907 . 2)) ((c def c (c (? . 0) q article-not-found?)) c (? . 52)) ((c def c (c (? . 1) q current-alist-separator-mode)) q (11071 . 5)) ((c def c (c (? . 10) q get-bindings)) q (40529 . 3)) ((q def ((lib "net/mime-unit.rkt") mime@)) q (32119 . 2)) ((c sig-val c (c (? . 2) q tcp^ tcp-connect)) q (37748 . 12)) ((c def c (c (? . 1) q form-urlencoded-decode)) q (10790 . 3)) ((c sig-val c (c (? . 2) q tcp^ tcp-listener?)) q (39241 . 3)) ((c def c (c (? . 20) q extract-all-fields)) q (18177 . 5)) ((c def c (c (? . 5) q communicator-state)) c (? . 25)) ((c def c (c (? . 3) q cookie:add-max-age)) q (42816 . 4)) ((c def c (c (? . 0) q open-news-group)) q (34408 . 7)) ((c def c (c (? . 3) q print-cookie)) q (43372 . 3)) ((c def c (c (? . 4) q imap-connect*)) q (20933 . 18)) ((c def c (c (? . 9) q delete-pure-port)) q (6356 . 4)) ((c def c (c (? . 5) q malformed-server-response-communicator)) c (? . 13)) ((c def c (c (? . 6) q entity-id)) c (? . 7)) ((c def c (c (? . 4) q imap-examine)) q (21907 . 5)) ((c def c (c (? . 6) q entity-other)) c (? . 7)) ((c def c (c (? . 6) q empty-mechanism?)) c (? . 43)) ((c def c (c (? . 5) q not-ready-for-transaction)) c (? . 19)) ((c def c (c (? . 12) q http-conn-recv!)) q (1796 . 10)) ((c def c (c (? . 3) q cookie?)) q (42265 . 3)) ((c def c (c (? . 8) q base64-encode)) q (32171 . 4)) ((c def c (c (? . 21) q url-host)) c (? . 22)) ((c def c (c (? . 6) q disposition?)) c (? . 11)) ((c def c (c (? . 9) q combine-url/relative)) q (4970 . 4)) ((c def c (c (? . 0) q bad-newsgroup-line)) c (? . 54)) ((c def c (c (? . 9) q netscape/string->url)) q (5072 . 3)) ((c def c (c (? . 9) q current-url-encode-mode)) q (5771 . 4)) ((c def c (c (? . 10) q generate-error-output)) q (41958 . 3)) ((c def c (c (? . 6) q struct:disposition)) c (? . 11)) ((q form ((lib "net/imap-sig.rkt") imap^)) q (25700 . 2)) ((q def ((lib "net/base64-unit.rkt") base64@)) q (32611 . 2)) ((c def c (c (? . 12) q http-sendrecv)) q (3051 . 20)) ((c def c (c (? . 6) q struct:entity)) c (? . 7)) ((c def c (c (? . 6) q struct:missing-multipart-boundary-parameter)) c (? . 36)) ((c def c (c (? . 0) q make-authentication-rejected)) c (? . 27)) ((c def c (c (? . 5) q not-given-headers-message)) c (? . 28)) ((c def c (c (? . 14) q struct:qp-wrong-line-size)) c (? . 16)) ((c def c (c (? . 5) q struct:malformed-server-response)) c (? . 13)) ((c def c (c (? . 17) q send-url/file)) q (14108 . 9)) ((c def c (c (? . 5) q make-malformed-server-response)) c (? . 13)) ((c def c (c (? . 1) q uri-decode)) q (10054 . 3)) ((c def c (c (? . 14) q qp-error)) c (? . 44)) ((c def c (c (? . 15) q ftp-directory-list)) q (11906 . 7)) ((c def c (c (? . 12) q http-conn?)) q (0 . 3)) ((c def c (c (? . 9) q call/input-url)) q (8513 . 10)) ((q def ((lib "net/git-checkout.rkt") git-checkout)) q (43841 . 29)) ((q form ((lib "net/uri-codec-sig.rkt") uri-codec^)) q (11310 . 2)) ((c def c (c (? . 5) q connect-to-server)) q (26035 . 4)) ((c def c (c (? . 9) q options-impure-port)) q (6958 . 4)) ((q def ((lib "net/pop3-unit.rkt") pop3@)) q (29462 . 2)) ((c def c (c (? . 6) q make-mime-error)) c (? . 45)) ((c def c (c (? . 4) q imap-uidvalidity)) q (22708 . 3)) ((c def c (c (? . 14) q qp-wrong-line-size?)) c (? . 16)) ((c def c (c (? . 9) q http-sendrecv/url)) q (9167 . 12)) ((c def c (c (? . 10) q get-bindings/get)) q (40704 . 3)) ((c def c (c (? . 0) q nntp?)) c (? . 42)) ((c def c (c (? . 6) q malformed-multipart-entity-msg)) c (? . 23)) ((c def c (c (? . 17) q unix-browser-list)) q (15139 . 2)) ((q form ((lib "net/dns-sig.rkt") dns^)) q (33909 . 2)) ((c def c (c (? . 6) q disposition-size)) c (? . 11)) ((c def c (c (? . 18) q decode-for-header)) q (19943 . 3)) ((c def c (c (? . 18) q encode-for-header)) q (19879 . 3)) ((c def c (c (? . 5) q pop3)) c (? . 26)) ((c def c (c (? . 5) q make-not-ready-for-transaction)) c (? . 19)) ((c def c (c (? . 20) q insert-field)) q (18511 . 5)) ((c def c (c (? . 9) q head-impure-port)) q (6716 . 4)) ((c def c (c (? . 14) q qp-wrong-input)) c (? . 41)) ((c def c (c (? . 4) q imap-force-disconnect)) q (21624 . 3)) ((q def ((lib "net/ftp-unit.rkt") ftp@)) q (13833 . 2)) ((c def c (c (? . 21) q make-url)) c (? . 22)) ((c def c (c (? . 5) q malformed-server-response)) c (? . 13)) ((c def c (c (? . 17) q send-url/contents)) q (14468 . 11)) ((c def c (c (? . 6) q struct:malformed-multipart-entity)) c (? . 23)) ((c def c (c (? . 14) q qp-encode-stream)) q (32787 . 5)) ((c def c (c (? . 0) q communicator-sender)) c (? . 24)) ((q form ((lib "net/cgi-sig.rkt") cgi^)) q (42236 . 2)) ((c def c (c (? . 6) q make-empty-subtype)) c (? . 48)) ((c def c (c (? . 0) q unexpected-response-code)) c (? . 34)) ((c def c (c (? . 6) q entity)) c (? . 7)) ((c def c (c (? . 14) q qp-wrong-line-size)) c (? . 16)) ((c def c (c (? . 0) q make-bad-status-line)) c (? . 29)) ((c def c (c (? . 21) q path/param-param)) c (? . 39)) ((c def c (c (? . 14) q qp-encode)) q (32667 . 3)) ((c def c (c (? . 6) q message)) c (? . 49)) ((c def c (c (? . 0) q premature-close-communicator)) c (? . 38)) ((q def ((lib "net/tcp-redirect.rkt") tcp-redirect)) q (39668 . 3)) ((c def c (c (? . 1) q uri-path-segment-encode)) q (10115 . 3)) ((c def c (c (? . 10) q get-bindings/post)) q (40614 . 3)) ((c def c (c (? . 17) q send-url)) q (13883 . 7)) ((c def c (c (? . 6) q mime-analyze)) q (29514 . 4)) ((c def c (c (? . 5) q communicator-receiver)) c (? . 25)) ((c def c (c (? . 9) q purify-port)) q (7727 . 3)) ((c def c (c (? . 10) q get-cgi-method)) q (42038 . 2)) ((c def c (c (? . 5) q make-pop3)) c (? . 26)) ((c def c (c (? . 0) q article-not-in-group-article)) c (? . 31)) ((c def c (c (? . 6) q struct:empty-disposition-type)) c (? . 33)) ((c def c (c (? . 15) q ftp-upload-file)) q (12837 . 11)) ((c def c (c (? . 5) q password-rejected?)) c (? . 30)) ((c def c (c (? . 0) q authentication-rejected?)) c (? . 27)) ((c def c (c (? . 15) q ftp-delete-directory)) q (13571 . 4)) ((c def c (c (? . 5) q make-not-given-headers)) c (? . 28)) ((c def c (c (? . 0) q communicator?)) c (? . 24)) ((c def c (c (? . 21) q url-query)) c (? . 22)) ((c def c (c (? . 0) q bad-status-line-line)) c (? . 29)) ((c def c (c (? . 9) q post-impure-port)) q (7368 . 5)) ((c def c (c (? . 4) q imap-uidnext)) q (22603 . 3)) ((c def c (c (? . 5) q password-rejected)) c (? . 30)) ((c def c (c (? . 5) q get-message/headers)) q (26901 . 6)) ((c def c (c (? . 0) q article-not-in-group)) c (? . 31)) ((c def c (c (? . 0) q make-communicator)) c (? . 24)) ((c def c (c (? . 1) q uri-userinfo-decode)) q (10333 . 3)) ((c def c (c (? . 21) q url-scheme)) c (? . 22)) ((c def c (c (? . 0) q no-group-selected)) c (? . 32)) ((c def c (c (? . 4) q imap-new?)) q (22817 . 3)) ((c sig-val c (c (? . 2) q tcp^ tcp-accept/enable-break)) q (38974 . 3)) ((c def c (c (? . 4) q imap-get-hierarchy-delimiter)) q (25450 . 3)) ((c def c (c (? . 3) q cookie-error)) c (? . 40)) ((c def c (c (? . 5) q communicator-server)) c (? . 25)) ((c def c (c (? . 12) q http-conn-send!)) q (966 . 17)) ((c def c (c (? . 0) q make-no-group-selected)) c (? . 32)) ((c def c (c (? . 6) q empty-disposition-type?)) c (? . 33)) ((c def c (c (? . 4) q imap-create-mailbox)) q (24964 . 4)) ((c def c (c (? . 10) q generate-link-text)) q (41854 . 4)) ((c def c (c (? . 5) q cannot-delete-message-message)) c (? . 46)) ((c def c (c (? . 6) q empty-disposition-type)) c (? . 33)) ((c def c (c (? . 12) q http-conn-close!)) q (832 . 3)) ((c def c (c (? . 15) q ftp-close-connection)) q (11713 . 3)) ((c def c (c (? . 10) q extract-binding/single)) q (40970 . 4)) ((c def c (c (? . 1) q form-urlencoded->alist)) q (10969 . 4)) ((c def c (c (? . 6) q disposition-modification)) c (? . 11)) ((c def c (c (? . 9) q path->url)) q (5199 . 3)) ((c def c (c (? . 0) q struct:unexpected-response)) c (? . 34)) ((c def c (c (? . 6) q entity-params)) c (? . 7)) ((c def c (c (? . 5) q struct:password-rejected)) c (? . 30)) ((c def c (c (? . 0) q extract-desired-headers)) q (35844 . 4)) ((c def c (c (? . 3) q cookie-value?)) q (42435 . 3)) ((c sig-val c (c (? . 2) q tcp^ tcp-listen)) q (37339 . 10)) ((c def c (c (? . 5) q get-unique-id/all)) q (27663 . 4)) ((c def c (c (? . 6) q disposition-creation)) c (? . 11)) ((c def c (c (? . 6) q entity-description)) c (? . 7)) ((c def c (c (? . 5) q disconnect-not-quiet)) c (? . 35)) ((c def c (c (? . 0) q unexpected-response?)) c (? . 34)) ((c def c (c (? . 5) q make-disconnect-not-quiet)) c (? . 35)) ((c def c (c (? . 4) q imap-mailbox-flags)) q (25539 . 4)) ((c def c (c (? . 15) q ftp-rename-file)) q (13693 . 5)) ((c def c (c (? . 6) q missing-multipart-boundary-parameter?)) c (? . 36)) ((c def c (c (? . 5) q illegal-message-number?)) c (? . 37)) ((q form ((lib "net/head-sig.rkt") head^)) q (19849 . 2)) ((c def c (c (? . 4) q imap-get-updates)) q (23157 . 5)) ((c def c (c (? . 12) q http-conn-live?)) q (56 . 3)) ((c def c (c (? . 4) q imap-get-messages)) q (23411 . 8)) ((c def c (c (? . 9) q make-http-connection)) q (8365 . 2)) ((q form ((lib "net/ftp-sig.rkt") ftp^)) q (13854 . 2)) ((q def ((lib "net/imap-unit.rkt") imap@)) q (25678 . 2)) ((q form ((lib "net/cookie-sig.rkt") cookie^)) q (43809 . 2)) ((c def c (c (? . 0) q communicator-receiver)) c (? . 24)) ((c def c (c (? . 5) q struct:illegal-message-number)) c (? . 37)) ((c def c (c (? . 1) q uri-encode)) q (9993 . 3)) ((q form ((lib "net/mime-sig.rkt") mime^)) q (32141 . 2)) ((c def c (c (? . 9) q http-connection-close)) q (8420 . 3)) ((c def c (c (? . 0) q struct:premature-close)) c (? . 38)) ((c def c (c (? . 21) q path/param?)) c (? . 39)) ((c def c (c (? . 0) q make-article-not-in-group)) c (? . 31)) ((q def ((lib "net/url-connect.rkt") current-https-protocol)) q (9730 . 4)) ((c def c (c (? . 3) q cookie-error?)) c (? . 40)) ((c def c (c (? . 5) q make-password-rejected)) c (? . 30)) ((q def ((lib "net/uri-codec-unit.rkt") uri-codec@)) q (11283 . 2)) ((c def c (c (? . 12) q http-conn)) q (117 . 2)) ((c def c (c (? . 14) q struct:qp-wrong-input)) c (? . 41)) ((q form ((lib "net/pop3-sig.rkt") pop3^)) q (29484 . 2)) ((c def c (c (? . 5) q make-communicator)) c (? . 25)) ((c def c (c (? . 12) q data-procedure/c)) q (4020 . 2)) ((c def c (c (? . 5) q get-message/complete)) q (26692 . 6)) ((c def c (c (? . 4) q imap-get-expunges)) q (22964 . 3)) ((c def c (c (? . 0) q struct:article-not-in-group)) c (? . 31)) ((c def c (c (? . 1) q uri-unreserved-decode)) q (10475 . 3)) ((c def c (c (? . 6) q make-entity)) c (? . 7)) ((c def c (c (? . 0) q premature-close)) c (? . 38)) ((c def c (c (? . 6) q unexpected-termination)) c (? . 50)) ((c def c (c (? . 0) q bad-status-line?)) c (? . 29)) ((q form ((lib "net/base64-sig.rkt") base64^)) q (32635 . 2)) ((c def c (c (? . 5) q struct:cannot-connect)) c (? . 57)) ((c def c (c (? . 9) q file-url-path-convention-type)) q (5614 . 4)) ((c def c (c (? . 9) q options-pure-port)) q (6476 . 4)) ((c def c (c (? . 0) q struct:nntp)) c (? . 42)) ((c def c (c (? . 5) q username-rejected?)) c (? . 47)) ((q def ((lib "net/ssl-tcp-unit.rkt") make-ssl-tcp@)) q (39772 . 15)) ((c def c (c (? . 6) q malformed-multipart-entity?)) c (? . 23)) ((c def c (c (? . 6) q make-empty-disposition-type)) c (? . 33)) ((c def c (c (? . 6) q struct:empty-mechanism)) c (? . 43)) ((c def c (c (? . 14) q qp-error?)) c (? . 44)) ((c def c (c (? . 20) q remove-field)) q (18365 . 4)) ((c def c (c (? . 6) q struct:mime-error)) c (? . 45)) ((c def c (c (? . 5) q not-given-headers?)) c (? . 28)) ((c def c (c (? . 12) q http-conn-abandon!)) q (898 . 3)) ((c def c (c (? . 6) q make-missing-multipart-boundary-parameter)) c (? . 36)) ((c def c (c (? . 15) q ftp-cd)) q (11800 . 4)) ((c def c (c (? . 0) q unexpected-response-text)) c (? . 34)) ((c def c (c (? . 6) q empty-type?)) c (? . 58)) ((c def c (c (? . 4) q imap-recent)) q (22407 . 3)) ((c def c (c (? . 21) q struct:url)) c (? . 22)) ((c def c (c (? . 10) q generate-html-output)) q (41186 . 15)) ((c def c (c (? . 5) q authenticate/plain-text)) q (26276 . 7)) ((c def c (c (? . 9) q post-pure-port)) q (7081 . 5)) ((c def c (c (? . 5) q make-cannot-delete-message)) c (? . 46)) ((c def c (c (? . 10) q extract-bindings)) q (40793 . 4)) ((c def c (c (? . 0) q article-not-in-group?)) c (? . 31)) ((c def c (c (? . 6) q mime-error)) c (? . 45)) ((c def c (c (? . 9) q get-impure-port)) q (6597 . 4)) ((c def c (c (? . 4) q imap-pending-expunges?)) q (23072 . 3)) ((c def c (c (? . 20) q replace-field)) q (18702 . 5)) ((c def c (c (? . 5) q make-illegal-message-number)) c (? . 37)) ((c def c (c (? . 14) q make-qp-error)) c (? . 44)) ((c def c (c (? . 4) q imap-reselect)) q (21705 . 5)) ((c def c (c (? . 17) q external-browser)) q (14953 . 4)) ((c def c (c (? . 3) q cookie:add-expires)) q (43046 . 4)) ((c def c (c (? . 5) q communicator-sender)) c (? . 25)) ((c def c (c (? . 15) q ftp-make-file-seconds)) q (12173 . 3)) ((c def c (c (? . 0) q head-of-message)) q (34842 . 5)) ((c def c (c (? . 51) q dns-get-name)) q (33596 . 4)) ((c def c (c (? . 6) q entity-encoding)) c (? . 7)) ((c def c (c (? . 10) q output-http-headers)) q (41143 . 2)) ((c def c (c (? . 10) q string->html)) q (41791 . 3)) ((c def c (c (? . 6) q missing-multipart-boundary-parameter)) c (? . 36)) ((c def c (c (? . 9) q url-exception?)) q (9107 . 3)) ((c def c (c (? . 4) q imap-pending-updates?)) q (23327 . 3)) ((c def c (c (? . 5) q username-rejected)) c (? . 47)) ((c def c (c (? . 4) q imap-store)) q (23884 . 6)) ((c def c (c (? . 3) q cookie-name?)) q (42377 . 3)) ((c def c (c (? . 6) q entity-disposition)) c (? . 7)) ((c def c (c (? . 21) q path/param)) c (? . 39)) ((q def ((lib "net/cgi-unit.rkt") cgi@)) q (42215 . 2)) ((c def c (c (? . 21) q url)) c (? . 22)) ((c def c (c (? . 21) q url-path)) c (? . 22)) ((c def c (c (? . 5) q cannot-delete-message)) c (? . 46)) ((c def c (c (? . 1) q uri-userinfo-encode)) q (10263 . 3)) ((q def ((lib "net/dns-unit.rkt") dns@)) q (33888 . 2)) ((c def c (c (? . 4) q imap-disconnect)) q (21549 . 3)) ((c def c (c (? . 6) q disposition-params)) c (? . 11)) ((c form c (c (? . 53) q url+scheme^)) q (9957 . 2)) ((c def c (c (? . 3) q make-cookie-error)) c (? . 40)) ((c def c (c (? . 5) q not-given-headers-communicator)) c (? . 28)) ((c def c (c (? . 5) q struct:not-ready-for-transaction)) c (? . 19)) ((c sig-val c (c (? . 2) q tcp^ tcp-connect/enable-break)) q (38300 . 13)) ((c def c (c (? . 9) q relative-path->relative-url-string)) q (5444 . 4)) ((c def c (c (? . 21) q url-fragment)) c (? . 22)) ((c def c (c (? . 0) q generic-message-command)) q (35390 . 9)) ((c def c (c (? . 14) q qp-wrong-input?)) c (? . 41)) ((c def c (c (? . 4) q imap-unseen)) q (22499 . 3)) ((c def c (c (? . 21) q url-port)) c (? . 22)) ((c def c (c (? . 0) q struct:authentication-rejected)) c (? . 27)) ((c def c (c (? . 3) q valid-domain?)) q (42318 . 3)) ((c def c (c (? . 12) q http-conn-sendrecv!)) q (2203 . 18)) ((q def ((lib "net/tcp-unit.rkt") tcp@)) q (39647 . 2)) ((c def c (c (? . 9) q http-connection?)) q (8303 . 3)) ((c def c (c (? . 12) q http-conn-open!)) q (155 . 9)) ((c def c (c (? . 0) q non-existent-group-group)) c (? . 55)) ((c def c (c (? . 4) q imap-mailbox-exists?)) q (24832 . 4)) ((c def c (c (? . 6) q struct:empty-subtype)) c (? . 48)) ((c def c (c (? . 6) q make-empty-mechanism)) c (? . 43)) ((c def c (c (? . 0) q make-nntp)) c (? . 42)) ((c def c (c (? . 5) q not-given-headers)) c (? . 28)) ((c def c (c (? . 6) q message?)) c (? . 49)) ((c def c (c (? . 5) q disconnect-not-quiet?)) c (? . 35)) ((c def c (c (? . 4) q imap-append)) q (24369 . 7)) ((c def c (c (? . 15) q ftp-connection?)) q (11345 . 3)) ((c def c (c (? . 6) q mime-error?)) c (? . 45)) ((q form ((lib "net/sendmail-sig.rkt") sendmail^)) q (17866 . 2)) ((c def c (c (? . 5) q illegal-message-number-message)) c (? . 37)) ((c def c (c (? . 6) q disposition-filename)) c (? . 11)) ((c def c (c (? . 6) q make-unexpected-termination)) c (? . 50)) ((c def c (c (? . 51) q dns-find-nameserver)) q (33826 . 2)) ((c def c (c (? . 6) q make-malformed-multipart-entity)) c (? . 23)) ((c def c (c (? . 5) q struct:disconnect-not-quiet)) c (? . 35)) ((c def c (c (? . 14) q struct:qp-error)) c (? . 44)) ((c def c (c (? . 4) q symbol->imap-flag)) q (23816 . 3)) ((c def c (c (? . 0) q make-premature-close)) c (? . 38)) ((c def c (c (? . 6) q disposition-type)) c (? . 11)) ((c form c (c (? . 2) q tcp^)) q (37310 . 2)) ((c def c (c (? . 20) q standard-message-header)) q (19057 . 11)) ((c def c (c (? . 5) q disconnect-from-server)) q (26181 . 3)) ((c def c (c (? . 6) q entity?)) c (? . 7)) ((c def c (c (? . 0) q struct:bad-status-line)) c (? . 29)) ((c sig-val c (c (? . 2) q tcp^ tcp-abandon-port)) q (39300 . 3)) ((c def c (c (? . 9) q put-impure-port)) q (7514 . 5)) ((c def c (c (? . 21) q struct:path/param)) c (? . 39)) ((c def c (c (? . 4) q imap-poll)) q (22244 . 3)) ((c def c (c (? . 3) q struct:cookie-error)) c (? . 40)) ((c def c (c (? . 6) q message-entity)) c (? . 49)) ((c def c (c (? . 17) q browser-preference?)) q (15074 . 3)) ((c def c (c (? . 4) q imap-noop)) q (22107 . 4)) ((c def c (c (? . 0) q struct:article-not-found)) c (? . 52)) ((c form c (c (? . 53) q url^)) q (9928 . 2)) ((c def c (c (? . 5) q disconnect-not-quiet-communicator)) c (? . 35)) ((q def ((lib "net/smtp-unit.rkt") smtp@)) q (16731 . 2)) ((c def c (c (? . 5) q get-mailbox-status)) q (26516 . 4)) ((c def c (c (? . 1) q uri-path-segment-unreserved-encode)) q (10547 . 3)) ((c def c (c (? . 0) q article-not-found-article)) c (? . 52)) ((c def c (c (? . 20) q data-lines->data)) q (19428 . 3)) ((q def ((lib "net/qp-unit.rkt") qp@)) q (33321 . 2)) ((c def c (c (? . 0) q nntp)) c (? . 42)) ((c def c (c (? . 0) q make-desired-header)) q (35760 . 3)) ((c def c (c (? . 4) q imap-connection?)) q (20101 . 3)) ((c def c (c (? . 14) q make-qp-wrong-line-size)) c (? . 16)) ((c def c (c (? . 4) q imap-port-number)) q (20810 . 4)) ((c def c (c (? . 1) q uri-path-segment-decode)) q (10189 . 3)) ((c def c (c (? . 0) q make-bad-newsgroup-line)) c (? . 54)) ((c def c (c (? . 9) q delete-impure-port)) q (6836 . 4)) ((q def ((lib "net/cookie-unit.rkt") cookie@)) q (43785 . 2)) ((c def c (c (? . 0) q make-article-not-found)) c (? . 52)) ((q def ((lib "net/head-unit.rkt") head@)) q (19827 . 2)) ((c def c (c (? . 5) q cannot-delete-message?)) c (? . 46)) ((c def c (c (? . 0) q struct:non-existent-group)) c (? . 55)) ((c def c (c (? . 4) q imap-expunge)) q (24105 . 3)) ((c def c (c (? . 6) q entity-subtype)) c (? . 7)) ((c def c (c (? . 0) q article-not-found)) c (? . 52)) ((c def c (c (? . 6) q make-message)) c (? . 49)) ((c def c (c (? . 6) q message-fields)) c (? . 49)) ((c def c (c (? . 5) q struct:username-rejected)) c (? . 47)) ((c def c (c (? . 0) q make-non-existent-group)) c (? . 55)) ((c def c (c (? . 5) q get-message/body)) q (27108 . 6)) ((q def ((lib "net/nntp-unit.rkt") nntp@)) q (37258 . 2)) ((c def c (c (? . 6) q struct:message)) c (? . 49)) ((c def c (c (? . 5) q communicator)) c (? . 25)) ((c def c (c (? . 3) q set-cookie)) q (42494 . 4)) ((c sig-val c (c (? . 2) q tcp^ tcp-accept)) q (38879 . 3)) ((c def c (c (? . 4) q imap-status)) q (24667 . 5)) ((c def c (c (? . 5) q extract-desired-headers)) q (27876 . 4)) ((c def c (c (? . 20) q append-headers)) q (18903 . 4)) ((c def c (c (? . 0) q bad-status-line)) c (? . 29)) ((c def c (c (? . 21) q url-user)) c (? . 22)) ((c def c (c (? . 21) q path/param-path)) c (? . 39)) ((c def c (c (? . 6) q entity-body)) c (? . 7)) ((c def c (c (? . 6) q entity-fields)) c (? . 7)) ((c def c (c (? . 15) q ftp-make-directory)) q (13451 . 4)) ((c def c (c (? . 6) q make-disposition)) c (? . 11)) ((c def c (c (? . 6) q unexpected-termination?)) c (? . 50)) ((c def c (c (? . 9) q url->path)) q (5294 . 4)) ((c def c (c (? . 51) q dns-get-mail-exchanger)) q (33706 . 4)) ((c def c (c (? . 8) q base64-decode-stream)) q (32510 . 4)) ((c def c (c (? . 6) q empty-subtype?)) c (? . 48)) ((c def c (c (? . 5) q make-desired-header)) q (27792 . 3)) ((c def c (c (? . 9) q current-proxy-servers)) q (8885 . 5)) ((c def c (c (? . 14) q make-qp-wrong-input)) c (? . 41)) ((c def c (c (? . 5) q not-ready-for-transaction-communicator)) c (? . 19)) ((c def c (c (? . 5) q communicator?)) c (? . 25)) ((q form ((lib "net/smtp-sig.rkt") smtp^)) q (16753 . 2)) ((c def c (c (? . 3) q get-cookie)) q (43441 . 4)) ((c def c (c (? . 56) q send-mail-message)) q (17299 . 15)) ((c def c (c (? . 21) q make-path/param)) c (? . 39)) ((c def c (c (? . 6) q malformed-multipart-entity)) c (? . 23)) ((c def c (c (? . 9) q display-pure-port)) q (7659 . 3)) ((c def c (c (? . 5) q struct:not-given-headers)) c (? . 28)) ((c def c (c (? . 56) q send-mail-message/port)) q (16783 . 13)) ((c def c (c (? . 5) q delete-message)) q (27309 . 5)) ((c def c (c (? . 0) q body-of-message)) q (35035 . 5)) ((c def c (c (? . 0) q make-unexpected-response)) c (? . 34)) ((c def c (c (? . 0) q connect-to-server)) q (34167 . 4)) ((c def c (c (? . 0) q communicator)) c (? . 24)) ((c def c (c (? . 6) q empty-subtype)) c (? . 48)) ((c def c (c (? . 14) q qp-decode-stream)) q (32938 . 4)) ((c def c (c (? . 8) q base64-encode-stream)) q (32355 . 5)) ((c def c (c (? . 4) q imap-copy)) q (24177 . 5)) ((c def c (c (? . 5) q get-unique-id/single)) q (27479 . 5)) ((c def c (c (? . 51) q dns-get-address)) q (33369 . 7)) ((c def c (c (? . 0) q non-existent-group?)) c (? . 55)) ((c def c (c (? . 4) q imap-reset-new!)) q (22889 . 3)) ((c def c (c (? . 3) q cookie:add-path)) q (42943 . 4)) ((c def c (c (? . 5) q make-username-rejected)) c (? . 47)) ((c def c (c (? . 6) q empty-mechanism)) c (? . 43)) ((c def c (c (? . 5) q malformed-server-response?)) c (? . 13)) ((c def c (c (? . 59) q smtp-sending-end-of-message)) q (16606 . 4)) ((c def c (c (? . 5) q cannot-delete-message-communicator)) c (? . 46)) ((c def c (c (? . 20) q empty-header)) q (17900 . 2)) ((c def c (c (? . 10) q bindings-as-html)) q (42096 . 3)) ((c def c (c (? . 3) q cookie:version)) q (43249 . 4)) ((c def c (c (? . 1) q alist->form-urlencoded)) q (10863 . 3)) ((c def c (c (? . 6) q unexpected-termination-msg)) c (? . 50)) ((c def c (c (? . 5) q illegal-message-number)) c (? . 37)) ((c def c (c (? . 0) q bad-newsgroup-line-line)) c (? . 54)) ((c def c (c (? . 3) q cookie:add-comment)) q (42597 . 4)) ((c def c (c (? . 14) q qp-decode)) q (32727 . 3)) ((c def c (c (? . 0) q struct:bad-newsgroup-line)) c (? . 54)) ((c def c (c (? . 1) q form-urlencoded-encode)) q (10717 . 3)) ((c sig-val c (c (? . 2) q tcp^ tcp-close)) q (39167 . 3)) ((c def c (c (? . 0) q newnews-since)) q (35228 . 4)) ((c def c (c (? . 5) q struct:communicator)) c (? . 25)) ((q def ((lib "net/sendmail-unit.rkt") sendmail@)) q (17840 . 2)) ((c def c (c (? . 0) q disconnect-from-server)) q (34313 . 3)) ((c def c (c (? . 21) q url-path-absolute?)) c (? . 22)) ((c def c (c (? . 18) q generalize-encoding)) q (20007 . 3)) ((c def c (c (? . 5) q make-cannot-connect)) c (? . 57)) ((c def c (c (? . 5) q cannot-connect?)) c (? . 57)) ((c def c (c (? . 6) q struct:unexpected-termination)) c (? . 50)) ((q form ((lib "net/nntp-sig.rkt") nntp^)) q (37280 . 2)) ((c def c (c (? . 9) q head-pure-port)) q (6238 . 4)) ((c def c (c (? . 5) q illegal-message-number-communicator)) c (? . 37)) ((c def c (c (? . 0) q no-group-selected?)) c (? . 32)) ((c def c (c (? . 5) q struct:pop3)) c (? . 26)) ((c def c (c (? . 6) q disposition-read)) c (? . 11)) ((c def c (c (? . 5) q pop3?)) c (? . 26)) ((c def c (c (? . 5) q cannot-connect)) c (? . 57)) ((c def c (c (? . 9) q get-pure-port/headers)) q (7791 . 12)) ((c def c (c (? . 6) q struct:empty-type)) c (? . 58)) ((c def c (c (? . 0) q struct:communicator)) c (? . 24)) ((c def c (c (? . 21) q url?)) c (? . 22)) ((c def c (c (? . 9) q put-pure-port)) q (7225 . 5)) ((c def c (c (? . 6) q entity-type)) c (? . 7)) ((c def c (c (? . 0) q struct:no-group-selected)) c (? . 32)) ((c def c (c (? . 4) q imap-messages)) q (22313 . 3)) ((c def c (c (? . 20) q validate-header)) q (17931 . 3)) ((c def c (c (? . 4) q imap-list-child-mailboxes)) q (25092 . 9)) ((c def c (c (? . 20) q extract-field)) q (18021 . 4)) ((c def c (c (? . 9) q string->url)) q (4833 . 4)) ((c def c (c (? . 12) q http-conn-open)) q (525 . 7)) ((c def c (c (? . 5) q struct:cannot-delete-message)) c (? . 46)) ((c def c (c (? . 9) q get-pure-port)) q (5936 . 7)) ((c def c (c (? . 6) q message-version)) c (? . 49)) ((c def c (c (? . 6) q empty-type)) c (? . 58)) ((c def c (c (? . 3) q get-cookie/single)) q (43558 . 4)) ((c def c (c (? . 1) q uri-path-segment-unreserved-decode)) q (10632 . 3)) ((c def c (c (? . 0) q premature-close?)) c (? . 38)) ((c def c (c (? . 5) q communicator-port)) c (? . 25)) ((c def c (c (? . 3) q cookie:add-domain)) q (42705 . 4)) ((c def c (c (? . 6) q make-empty-type)) c (? . 58)) ((c def c (c (? . 6) q disposition)) c (? . 11)) ((c def c (c (? . 0) q unexpected-response)) c (? . 34)) ((q form ((lib "net/qp-sig.rkt") qp^)) q (33341 . 2)) ((c def c (c (? . 0) q authenticate-user)) q (34617 . 7)) ((c sig-val c (c (? . 2) q tcp^ tcp-addresses)) q (39373 . 7)) ((c def c (c (? . 15) q ftp-download-file)) q (12262 . 13)) ((c sig-val c (c (? . 2) q tcp^ tcp-accept-ready?)) q (39082 . 3)) ((c def c (c (? . 6) q entity-parts)) c (? . 7)) ((c def c (c (? . 0) q non-existent-group)) c (? . 55)) ((c def c (c (? . 15) q ftp-delete-file)) q (13327 . 4)) ((c def c (c (? . 0) q bad-newsgroup-line?)) c (? . 54)) ((c def c (c (? . 20) q assemble-address-field)) q (19740 . 3)) ((c def c (c (? . 0) q authentication-rejected)) c (? . 27)) ((c def c (c (? . 4) q imap-connect)) q (20163 . 15)) ((c def c (c (? . 5) q not-ready-for-transaction?)) c (? . 19)) ((c def c (c (? . 20) q extract-addresses)) q (19501 . 7)) ((c def c (c (? . 59) q smtp-send-message)) q (15185 . 29)) ((c def c (c (? . 0) q communicator-port)) c (? . 24)) ((c def c (c (? . 9) q url->string)) q (5140 . 3))))
procedure
(http-conn? x) -> boolean?
  x : any/c
procedure
(http-conn-live? x) -> boolean?
  x : any/c
procedure
(http-conn) -> http-conn?
procedure
(http-conn-open!  hc                
                  host              
                 [#:ssl? ssl?       
                  #:port port]) -> void?
  hc : http-conn?
  host : (or/c bytes? string?)
  ssl? : (or/c boolean? ssl-client-context? symbol?) = #f
  port : (between/c 1 65535) = (if ssl? 443 80)
procedure
(http-conn-open  host              
                [#:ssl? ssl?       
                 #:port port]) -> http-conn?
  host : (or/c bytes? string?)
  ssl? : (or/c boolean? ssl-client-context? symbol?) = #f
  port : (between/c 1 65535) = (if ssl? 443 80)
procedure
(http-conn-close! hc) -> void?
  hc : http-conn?
procedure
(http-conn-abandon! hc) -> void?
  hc : http-conn?
procedure
(http-conn-send!  hc                           
                  uri                          
                 [#:version version            
                  #:method method              
                  #:close? close?              
                  #:headers headers            
                  #:content-decode decodes     
                  #:data data])            -> void?
  hc : http-conn-live?
  uri : (or/c bytes? string?)
  version : (or/c bytes? string?) = #"1.1"
  method : (or/c bytes? string? symbol?) = #"GET"
  close? : boolean? = #f
  headers : (listof (or/c bytes? string?)) = empty
  decodes : (listof symbol?) = '(gzip)
  data : (or/c false/c bytes? string? data-procedure/c) = #f
procedure
(http-conn-recv!  hc                       
                 [#:content-decode decodes 
                  #:method method          
                  #:close? close?])        
 -> bytes? (listof bytes?) input-port?
  hc : http-conn-live?
  decodes : (listof symbol?) = '(gzip)
  method : (or/c bytes? string? symbol?) = #"GET"
  close? : boolean? = #f
procedure
(http-conn-sendrecv!  hc                       
                      uri                      
                     [#:version version        
                      #:method method          
                      #:headers headers        
                      #:data data              
                      #:content-decode decodes 
                      #:close? close?])        
 -> bytes? (listof bytes?) input-port?
  hc : http-conn-live?
  uri : (or/c bytes? string?)
  version : (or/c bytes? string?) = #"1.1"
  method : (or/c bytes? string? symbol?) = #"GET"
  headers : (listof (or/c bytes? string?)) = empty
  data : (or/c false/c bytes? string? data-procedure/c) = #f
  decodes : (listof symbol?) = '(gzip)
  close? : boolean? = #f
procedure
(http-sendrecv  host                       
                uri                        
               [#:ssl? ssl?                
                #:port port                
                #:version version          
                #:method method            
                #:headers headers          
                #:data data                
                #:content-decode decodes]) 
 -> bytes? (listof bytes?) input-port?
  host : (or/c bytes? string?)
  uri : (or/c bytes? string?)
  ssl? : (or/c boolean? ssl-client-context? symbol?) = #f
  port : (between/c 1 65535) = (if ssl? 443 80)
  version : (or/c bytes? string?) = #"1.1"
  method : (or/c bytes? string? symbol?) = #"GET"
  headers : (listof (or/c bytes? string?)) = empty
  data : (or/c false/c bytes? string? data-procedure/c) = #f
  decodes : (listof symbol?) = '(gzip)
value
data-procedure/c : chaperone-contract?
struct
(struct url (scheme
             user
             host
             port
             path-absolute?
             path
             query
             fragment)
    #:extra-constructor-name make-url)
  scheme : (or/c false/c string?)
  user : (or/c false/c string?)
  host : (or/c false/c string?)
  port : (or/c false/c exact-nonnegative-integer?)
  path-absolute? : boolean?
  path : (listof path/param?)
  query : (listof (cons/c symbol? (or/c false/c string?)))
  fragment : (or/c false/c string?)
struct
(struct path/param (path param)
    #:extra-constructor-name make-path/param)
  path : (or/c string? (or/c 'up 'same))
  param : (listof string?)
procedure
(string->url str) -> url?
  str : (or/c (not/c #rx"^([^:/?#]*):")
              #rx"^[a-zA-Z][a-zA-Z0-9+.-]*:")
procedure
(combine-url/relative base relative) -> url?
  base : url?
  relative : string?
procedure
(netscape/string->url str) -> url?
  str : string?
procedure
(url->string URL) -> string?
  URL : url?
procedure
(path->url path) -> url?
  path : (or/c path-string? path-for-some-system?)
procedure
(url->path URL [kind]) -> path-for-some-system?
  URL : url?
  kind : (or/c 'unix 'windows) = (system-path-convention-type)
procedure
(relative-path->relative-url-string path) -> string?
  path : (and/c (or/c path-string? path-for-some-system?)
                relative-path?)
parameter
(file-url-path-convention-type) -> (or/c 'unix 'windows)
(file-url-path-convention-type kind) -> void?
  kind : (or/c 'unix 'windows)
parameter
(current-url-encode-mode) -> (or/c 'recommended 'unreserved)
(current-url-encode-mode mode) -> void?
  mode : (or/c 'recommended 'unreserved)
procedure
(get-pure-port  URL                               
               [header                            
                #:redirections redirections]) -> input-port?
  URL : url?
  header : (listof string?) = null
  redirections : exact-nonnegative-integer? = 0
procedure
(head-pure-port URL [header]) -> input-port?
  URL : url?
  header : (listof string?) = null
procedure
(delete-pure-port URL [header]) -> input-port?
  URL : url?
  header : (listof string?) = null
procedure
(options-pure-port URL [header]) -> input-port?
  URL : url?
  header : (listof string?) = null
procedure
(get-impure-port URL [header]) -> input-port?
  URL : url?
  header : (listof string?) = null
procedure
(head-impure-port URL [header]) -> input-port?
  URL : url?
  header : (listof string?) = null
procedure
(delete-impure-port URL [header]) -> input-port?
  URL : url?
  header : (listof string?) = null
procedure
(options-impure-port URL [header]) -> input-port?
  URL : url?
  header : (listof string?) = null
procedure
(post-pure-port URL post [header]) -> input-port?
  URL : url?
  post : bytes?
  header : (listof string?) = null
procedure
(put-pure-port URL post [header]) -> input-port?
  URL : url?
  post : bytes?
  header : (listof string?) = null
procedure
(post-impure-port URL post [header]) -> input-port?
  URL : url?
  post : bytes?
  header : (listof string?) = null
procedure
(put-impure-port URL post [header]) -> input-port?
  URL : url?
  post : bytes?
  header : (listof string?) = null
procedure
(display-pure-port in) -> void?
  in : input-port?
procedure
(purify-port in) -> string?
  in : input-port?
procedure
(get-pure-port/headers  url                         
                       [headers                     
                        #:redirections redirections 
                        #:status? status?]          
                        #:connection connection)    
 -> input-port? string?
  url : url?
  headers : (listof string?) = '()
  redirections : exact-nonnegative-integer? = 0
  status? : boolean? = #f
  connection : (or/c #f http-connection?)
procedure
(http-connection? v) -> boolean?
  v : any/c
procedure
(make-http-connection) -> http-connection?
procedure
(http-connection-close connection) -> void?
  connection : http-connection?
procedure
(call/input-url URL connect handle) -> any
  URL : url?
  connect : (url? . -> . input-port?)
  handle : (input-port? . -> . any)
(call/input-url URL connect handle header) -> any
  URL : url?
  connect : (url? (listof string?) . -> . input-port?)
  handle : (input-port? . -> . any)
  header : (listof string?)
parameter
(current-proxy-servers)
 -> (listof (list/c string? string? (integer-in 0 65535)))
(current-proxy-servers mapping) -> void?
  mapping : (listof (list/c string? string? (integer-in 0 65535)))
procedure
(url-exception? x) -> boolean?
  x : any/c
procedure
(http-sendrecv/url  u                          
                   [#:method method            
                    #:headers headers          
                    #:data data                
                    #:content-decode decodes]) 
 -> bytes? (listof bytes?) input-port?
  u : url?
  method : (or/c bytes? string? symbol?) = #"GET"
  headers : (listof (or/c bytes? string?)) = empty
  data : (or/c false/c bytes? string? data-procedure/c) = #f
  decodes : (listof symbol?) = '(gzip)
parameter
(current-https-protocol) -> (or/c ssl-client-context? symbol?)
(current-https-protocol protocol) -> void?
  protocol : (or/c ssl-client-context? symbol?)
value
url@ : unit?
signature
url^ : signature
signature
url+scheme^ : signature
procedure
(uri-encode str) -> string?
  str : string?
procedure
(uri-decode str) -> string?
  str : string?
procedure
(uri-path-segment-encode str) -> string?
  str : string?
procedure
(uri-path-segment-decode str) -> string?
  str : string?
procedure
(uri-userinfo-encode str) -> string?
  str : string?
procedure
(uri-userinfo-decode str) -> string?
  str : string?
procedure
(uri-unreserved-encode str) -> string?
  str : string?
procedure
(uri-unreserved-decode str) -> string?
  str : string?
procedure
(uri-path-segment-unreserved-encode str) -> string?
  str : string?
procedure
(uri-path-segment-unreserved-decode str) -> string?
  str : string?
procedure
(form-urlencoded-encode str) -> string?
  str : string?
procedure
(form-urlencoded-decode str) -> string?
  str : string?
procedure
(alist->form-urlencoded alist) -> string?
  alist : (listof (cons/c symbol? string?))
procedure
(form-urlencoded->alist str)
 -> (listof (cons/c symbol? string?))
  str : string
parameter
(current-alist-separator-mode)
 -> (one-of/c 'amp 'semi 'amp-or-semi 'semi-or-amp)
(current-alist-separator-mode mode) -> void?
  mode : (one-of/c 'amp 'semi 'amp-or-semi 'semi-or-amp)
value
uri-codec@ : unit?
signature
uri-codec^ : signature
procedure
(ftp-connection? v) -> boolean?
  v : any/c
procedure
(ftp-establish-connection server      
                          port-no     
                          user        
                          passwd) -> ftp-connection?
  server : string?
  port-no : (integer-in 0 65535)
  user : string?
  passwd : string?
procedure
(ftp-close-connection ftp-conn) -> void?
  ftp-conn : ftp-connection?
procedure
(ftp-cd ftp-conn new-dir) -> void?
  ftp-conn : ftp-connection?
  new-dir : string?
procedure
(ftp-directory-list ftp-conn [path])
 -> (listof (list/c (one-of/c "-" "d" "l")
                    string?
                    string?))
  ftp-conn : ftp-connection?
  path : (or/c false/c string?) = #f
procedure
(ftp-make-file-seconds ftp-date) -> exact-integer?
  ftp-date : string?
procedure
(ftp-download-file  ftp-conn                       
                    local-dir                      
                    file                           
                   [#:progress progress-proc]) -> void?
  ftp-conn : ftp-connection?
  local-dir : path-string?
  file : string?
  progress-proc : (or/c #f
                        (-> (-> (values exact-nonnegative-integer?
                                        evt?))
                            any))
                = #f
procedure
(ftp-upload-file  ftp-conn                       
                  file-path                      
                 [#:progress progress-proc]) -> void?
  ftp-conn : ftp-connection?
  file-path : path-string?
  progress-proc : (or/c #f
                        (-> (-> (values exact-nonnegative-integer?
                                        evt?))
                            any))
                = #f
procedure
(ftp-delete-file ftp-conn file-path) -> void?
  ftp-conn : ftp-connection?
  file-path : path-string?
procedure
(ftp-make-directory ftp-conn dir-name) -> void?
  ftp-conn : ftp-connection?
  dir-name : string?
procedure
(ftp-delete-directory ftp-conn dir-name) -> void?
  ftp-conn : ftp-connection?
  dir-name : string?
procedure
(ftp-rename-file ftp-conn origin dest) -> void?
  ftp-conn : ftp-connection?
  origin : string?
  dest : string?
value
ftp@ : unit?
signature
ftp^ : signature
procedure
(send-url  str                     
          [separate-window?        
           #:escape? escape?]) -> void?
  str : string?
  separate-window? : any/c = #t
  escape? : any/c = #t
procedure
(send-url/file  path                    
               [separate-window?        
                #:fragment fragment     
                #:query query])     -> void?
  path : path-string?
  separate-window? : any/c = #t
  fragment : (or/c string? false/c) = #f
  query : (or/c string? false/c) = #f
procedure
(send-url/contents  contents                  
                   [separate-window?          
                    #:fragment fragment       
                    #:query query             
                    #:delete-at seconds]) -> void?
  contents : string?
  separate-window? : any/c = #t
  fragment : (or/c string? false/c) = #f
  query : (or/c string? false/c) = #f
  seconds : (or/c number? false/c) = #f
parameter
(external-browser) -> browser-preference?
(external-browser cmd) -> void?
  cmd : browser-preference?
procedure
(browser-preference? a) -> boolean?
  a : any/c
value
unix-browser-list : (listof symbol?)
procedure
(smtp-send-message  server-address            
                    from                      
                    to                        
                    header                    
                    message                   
                   [#:port-no port-no/k       
                    #:auth-user user          
                    #:auth-passwd pw          
                    #:tcp-connect connect     
                    #:tls-encode encode       
                    port-no])             -> void?
  server-address : string?
  from : string?
  to : (listof string?)
  header : string?
  message : (listof (or/c string? bytes?))
  port-no/k : (integer-in 0 65535) = 25
  user : (or/c string? false/c) = #f
  pw : (or/c string? false/c) = #f
  connect : ((string? (integer-in 0 65535))      = tcp-connect
             . ->* . (input-port? output-port?))
  encode : (or/c false/c                               = #f
                 ((input-port? output-port?
                   #:mode (one-of/c 'connect)
                   #:encrypt (one-of/c 'tls)
                   #:close-original? (one-of/c #t))
                  . ->* . (input-port? output-port?)))
  port-no : (integer-in 0 65535) = port-no/k
parameter
(smtp-sending-end-of-message) -> (-> any)
(smtp-sending-end-of-message proc) -> void?
  proc : (-> any)
value
smtp@ : unit?
signature
smtp^ : signature
procedure
(send-mail-message/port from                  
                        subject               
                        to                    
                        cc                    
                        bcc                   
                        extra-header ...) -> output-port?
  from : (or/c string? false/c)
  subject : string?
  to : (listof string?)
  cc : (listof string?)
  bcc : (listof string?)
  extra-header : string?
procedure
(send-mail-message from                  
                   subject               
                   to                    
                   cc                    
                   bcc                   
                   body                  
                   extra-header ...) -> void?
  from : string?
  subject : string?
  to : (listof string?)
  cc : (listof string?)
  bcc : (listof string?)
  body : (listof string?)
  extra-header : string?
value
sendmail@ : unit?
signature
sendmail^ : signature
value
empty-header : string?
procedure
(validate-header candidate) -> void?
  candidate : (or string? bytes?)
procedure
(extract-field field header) -> (or/c string? bytes? false/c)
  field : (or/c string? bytes?)
  header : (or/c string? bytes?)
procedure
(extract-all-fields header)
 -> (listof (cons/c (or/c string? bytes?)
                    (or/c string? bytes?)))
  header : (or/c string? bytes?)
procedure
(remove-field field header) -> (or/c string? bytes?)
  field : (or/c string? bytes?)
  header : (or/c string? bytes?)
procedure
(insert-field field value header) -> (or/c string? bytes?)
  field : (or/c string? bytes?)
  value : (or/c string? bytes?)
  header : (or/c string? bytes?)
procedure
(replace-field field value header) -> (or/c string? bytes?)
  field : (or/c string? bytes?)
  value : (or/c string? bytes? false/c)
  header : (or/c string? bytes?)
procedure
(append-headers header1 header2) -> (or/c string? bytes?)
  header1 : (or/c string? bytes?)
  header2 : (or/c string? bytes?)
procedure
(standard-message-header from         
                         to           
                         cc           
                         bcc          
                         subject) -> string?
  from : string?
  to : (listof string?)
  cc : (listof string?)
  bcc : (listof string?)
  subject : string?
procedure
(data-lines->data listof) -> string?
  listof : string?
procedure
(extract-addresses line kind)
 -> (or/c (listof string?)
          (listof (list/c string? string? string?)))
  line : string?
  kind : (one-of/c 'name 'address
                   'full 'all)
procedure
(assemble-address-field addrs) -> string?
  addrs : (listof string?)
value
head@ : unit?
signature
head^ : signature
procedure
(encode-for-header s) -> string?
  s : string?
procedure
(decode-for-header s) -> string?
  s : string?
procedure
(generalize-encoding s) -> (or string? bytes?)
  s : (or string? bytes?)
procedure
(imap-connection? v) -> boolean?
  v : any/c
procedure
(imap-connect  server                    
               username                  
               password                  
               mailbox                   
              [#:tls? tls?               
               #:try-tls? try-tls?]) -> imap-connection?
                                        exact-nonnegative-integer?
                                        exact-nonnegative-integer?
  server : string?
  username : (or/c string? bytes?)
  password : (or/c string? bytes?)
  mailbox : (or/c string? bytes?)
  tls? : any/c = #f
  try-tls? : any/c = #t
parameter
(imap-port-number) -> (integer-in 0 65535)
(imap-port-number k) -> void?
  k : (integer-in 0 65535)
procedure
(imap-connect*  in                    
                out                   
                username              
                password              
                mailbox               
               [#:tls? tls?           
                #:try-tls? try-tls?]) 
 -> imap-connection?
    exact-nonnegative-integer?
    exact-nonnegative-integer?
  in : input-port?
  out : output-port?
  username : (or/c string? bytes?)
  password : (or/c string? bytes?)
  mailbox : (or/c string? bytes?)
  tls? : any/c = #f
  try-tls? : any/c = #t
procedure
(imap-disconnect imap) -> void?
  imap : imap-connection?
procedure
(imap-force-disconnect imap) -> void?
  imap : imap-connection?
procedure
(imap-reselect imap mailbox) -> exact-nonnegative-integer?
                                exact-nonnegative-integer?
  imap : imap-connection?
  mailbox : (or/c string? bytes?)
procedure
(imap-examine imap mailbox) -> exact-nonnegative-integer?
                               exact-nonnegative-integer?
  imap : imap-connection?
  mailbox : (or/c string? bytes?)
procedure
(imap-noop imap) -> exact-nonnegative-integer?
                    exact-nonnegative-integer?
  imap : imap-connection?
procedure
(imap-poll imap) -> void?
  imap : imap-connection?
procedure
(imap-messages imap) -> exact-nonnegative-integer?
  imap : imap-connection?
procedure
(imap-recent imap) -> exact-nonnegative-integer?
  imap : imap-connection?
procedure
(imap-unseen imap) -> (or/c exact-nonnegative-integer? #f)
  imap : imap-connection?
procedure
(imap-uidnext imap) -> (or/c exact-nonnegative-integer? #f)
  imap : imap-connection?
procedure
(imap-uidvalidity imap) -> (or/c exact-nonnegative-integer? #f)
  imap : imap-connection?
procedure
(imap-new? imap) -> boolean?
  imap : imap-connection?
procedure
(imap-reset-new! imap) -> void?
  imap : imap-connection?
procedure
(imap-get-expunges imap) -> (listof exact-nonnegative-integer?)
  imap : imap-connection?
procedure
(imap-pending-expunges? imap) -> boolean?
  imap : imap-connection?
procedure
(imap-get-updates imap)
 -> (listof (cons/c exact-nonnegative-integer?
                    (listof pair?)))
  imap : imap-connection?
procedure
(imap-pending-updates? imap) -> boolean?
  imap : imap-connection?
procedure
(imap-get-messages imap msg-nums fields) -> (listof list?)
  imap : imap-connection?
  msg-nums : (listof exact-nonnegative-integer?)
  fields : (listof (or/c 'uid
                         'header
                         'body
                         'flags))
procedure
(imap-flag->symbol flag) -> symbol?
  flag : symbol?
procedure
(symbol->imap-flag sym) -> symbol?
  sym : symbol?
procedure
(imap-store imap mode msg-nums imap-flags) -> void?
  imap : imap-connection?
  mode : (or/c '+ '- '!)
  msg-nums : (listof exact-nonnegative-integer?)
  imap-flags : (listof symbol?)
procedure
(imap-expunge imap) -> void?
  imap : imap-connection?
procedure
(imap-copy imap msg-nums dest-mailbox) -> void?
  imap : imap-connection?
  msg-nums : (listof exact-nonnegative-integer?)
  dest-mailbox : (or/c string? bytes?)
procedure
(imap-append imap mailbox message [flags]) -> void?
  imap : imap-connection?
  mailbox : string?
  message : (or/c string? bytes?)
  flags : (listof (or/c 'seen 'answered 'flagged  = '(seen)
                        'deleted 'draft 'recent))
procedure
(imap-status imap mailbox statuses) -> list?
  imap : imap-connection?
  mailbox : (or/c string? bytes?)
  statuses : (listof symbol?)
procedure
(imap-mailbox-exists? imap mailbox) -> boolean?
  imap : imap-connection?
  mailbox : (or/c string? bytes?)
procedure
(imap-create-mailbox imap mailbox) -> void?
  imap : imap-connection?
  mailbox : (or/c string? bytes?)
procedure
(imap-list-child-mailboxes  imap        
                            mailbox     
                           [delimiter]) 
 -> (listof (list/c (listof symbol?) bytes?))
  imap : imap-connection?
  mailbox : (or/c string? bytes? #f)
  delimiter : (or/c string? bytes?)
            = (imap-get-hierarchy-delimiter)
procedure
(imap-get-hierarchy-delimiter imap) -> bytes?
  imap : imap-connection?
procedure
(imap-mailbox-flags imap mailbox) -> (listof symbol?)
  imap : imap-connection?
  mailbox : (or/c string? bytes?)
value
imap@ : unit?
signature
imap^ : signature
struct
(struct communicator (sender receiver server port state)
    #:extra-constructor-name make-communicator)
  sender : output-port?
  receiver : input-port?
  server : string?
  port : (integer-in 0 65535)
  state : (one-of/c 'disconnected 'authorization 'transaction)
procedure
(connect-to-server server [port-number]) -> communicator?
  server : string?
  port-number : (integer-in 0 65535) = 110
procedure
(disconnect-from-server communicator) -> void?
  communicator : communicator?
procedure
(authenticate/plain-text user              
                         passwd            
                         communicator) -> void?
  user : string?
  passwd : string?
  communicator : communicator?
procedure
(get-mailbox-status communicator) -> exact-nonnegative-integer?
                                     exact-nonnegative-integer?
  communicator : communicator?
procedure
(get-message/complete communicator    
                      message-number) 
 -> (listof string?) (listof string?)
  communicator : communicator?
  message-number : exact-integer?
procedure
(get-message/headers communicator    
                     message-number) 
 -> (listof string?) (listof string?)
  communicator : communicator?
  message-number : exact-integer?
procedure
(get-message/body communicator    
                  message-number) 
 -> (listof string?) (listof string?)
  communicator : communicator?
  message-number : exact-integer?
procedure
(delete-message communicator        
                message-number) -> void?
  communicator : communicator?
  message-number : exact-integer?
procedure
(get-unique-id/single communicator        
                      message-number) -> string?
  communicator : communicator?
  message-number : exact-integer?
procedure
(get-unique-id/all communicator)
 -> (listof (cons/c exact-integer? string?))
  communicator : communicator?
procedure
(make-desired-header tag-string) -> regexp?
  tag-string : string?
procedure
(extract-desired-headers header desireds) -> (listof string?)
  header : (listof string?)
  desireds : (listof regexp?)
struct
(struct pop3 exn ()
    #:extra-constructor-name make-pop3)
struct
(struct cannot-connect pop3 ()
    #:extra-constructor-name make-cannot-connect)
struct
(struct username-rejected pop3 ()
    #:extra-constructor-name make-username-rejected)
struct
(struct password-rejected pop3 ()
    #:extra-constructor-name make-password-rejected)
struct
(struct not-ready-for-transaction pop3 (communicator)
    #:extra-constructor-name make-not-ready-for-transaction)
  communicator : communicator?
struct
(struct not-given-headers pop3 (communicator message)
    #:extra-constructor-name make-not-given-headers)
  communicator : communicator?
  message : exact-integer?
struct
(struct illegal-message-number pop3 (communicator message)
    #:extra-constructor-name make-illegal-message-number)
  communicator : communicator?
  message : exact-integer?
struct
(struct cannot-delete-message exn (communicator message)
    #:extra-constructor-name make-cannot-delete-message)
  communicator : communicator?
  message : exact-integer?
struct
(struct disconnect-not-quiet pop3 (communicator)
    #:extra-constructor-name make-disconnect-not-quiet)
  communicator : communicator?
struct
(struct malformed-server-response pop3 (communicator)
    #:extra-constructor-name make-malformed-server-response)
  communicator : communicator?
value
pop3@ : unit?
signature
pop3^ : signature
procedure
(mime-analyze message-in [part?]) -> message?
  message-in : (or/c bytes? input-port)
  part? : any/c = #f
struct
(struct message (version entity fields)
    #:extra-constructor-name make-message)
  version : real?
  entity : entity
  fields : (listof string?)
struct
(struct entity (type
                subtype
                charset
                encoding
                disposition
                params
                id
                description
                other
                fields
                parts
                body)
    #:extra-constructor-name make-entity)
  type : symbol?
  subtype : symbol?
  charset : symbol?
  encoding : symbol?
  disposition : disposition?
  params : (listof (cons/c symbol? string?))
  id : string?
  description : string?
  other : (listof string?)
  fields : (listof string?)
  parts : (listof message?)
  body : (or/c (output-port? . -> . void?) null?)
struct
(struct disposition (type
                     filename
                     creation
                     modification
                     read
                     size
                     params)
    #:extra-constructor-name make-disposition)
  type : symbol?
  filename : (or/c string? false/c)
  creation : (or/c string? false/c)
  modification : (or/c string? false/c)
  read : (or/c string? false/c)
  size : (or/c exact-nonnegative-integer? false/c)
  params : (listof (cons/c symbol? string?))
struct
(struct mime-error exn:fail ()
    #:extra-constructor-name make-mime-error)
struct
(struct unexpected-termination mime-error (msg)
    #:extra-constructor-name make-unexpected-termination)
  msg : string?
struct
(struct missing-multipart-boundary-parameter mime-error ()
    #:extra-constructor-name
    make-missing-multipart-boundary-parameter)
struct
(struct malformed-multipart-entity mime-error (msg)
    #:extra-constructor-name make-malformed-multipart-entity)
  msg : string?
struct
(struct empty-mechanism mime-error ()
    #:extra-constructor-name make-empty-mechanism)
struct
(struct empty-type mime-error ()
    #:extra-constructor-name make-empty-type)
struct
(struct empty-subtype mime-error ()
    #:extra-constructor-name make-empty-subtype)
struct
(struct empty-disposition-type mime-error ()
    #:extra-constructor-name make-empty-disposition-type)
value
mime@ : unit?
signature
mime^ : signature
procedure
(base64-encode bstr [newline-bstr]) -> bytes?
  bstr : bytes?
  newline-bstr : bytes? = #"\r\n"
procedure
(base64-decode bstr) -> bytes?
  bstr : bytes?
procedure
(base64-encode-stream in out [newline-bstr]) -> void?
  in : input-port?
  out : output-port?
  newline-bstr : bytes? = #"\n"
procedure
(base64-decode-stream in out) -> void?
  in : input-port?
  out : output-port?
value
base64@ : unit?
signature
base64^ : signature
procedure
(qp-encode bstr) -> bytes?
  bstr : bytes?
procedure
(qp-decode bstr) -> bytes?
  bstr : bytes?
procedure
(qp-encode-stream in out [newline-bstr]) -> void?
  in : input-port?
  out : output-port?
  newline-bstr : bytes? = #"\n"
procedure
(qp-decode-stream in out) -> void?
  in : input-port?
  out : output-port?
struct
(struct qp-error ()
    #:extra-constructor-name make-qp-error)
struct
(struct qp-wrong-input qp-error ()
    #:extra-constructor-name make-qp-wrong-input)
struct
(struct qp-wrong-line-size qp-error ()
    #:extra-constructor-name make-qp-wrong-line-size)
value
qp@ : unit?
signature
qp^ : signature
procedure
(dns-get-address  nameserver          
                  address             
                 [#:ipv6? ipv6?]) -> string?
  nameserver : string?
  address : string?
  ipv6? : any/c = #f
procedure
(dns-get-name nameserver address) -> string?
  nameserver : string?
  address : string?
procedure
(dns-get-mail-exchanger nameserver address) -> string?
  nameserver : string?
  address : string?
procedure
(dns-find-nameserver) -> (or/c string? false/c)
value
dns@ : unit?
signature
dns^ : signature
struct
(struct communicator (sender receiver server port)
    #:extra-constructor-name make-communicator)
  sender : output-port?
  receiver : input-port?
  server : string?
  port : (integer-in 0 65535)
procedure
(connect-to-server server [port-number]) -> communicator?
  server : string?
  port-number : (integer-in 0 65535) = 119
procedure
(disconnect-from-server communicator) -> void?
  communicator : communicator?
procedure
(open-news-group communicator newsgroup)
 -> exact-nonnegative-integer?
    exact-nonnegative-integer?
    exact-nonnegative-integer?
  communicator : communicator?
  newsgroup : string?
procedure
(authenticate-user communicator     
                   username         
                   password)    -> void?
  communicator : communicator?
  username : string?
  password : string?
procedure
(head-of-message communicator       
                 message-index) -> (listof string?)
  communicator : communicator?
  message-index : exact-nonnegative-integer?
procedure
(body-of-message communicator       
                 message-index) -> (listof string?)
  communicator : communicator?
  message-index : exact-nonnegative-integer?
procedure
(newnews-since communicator message-index) -> (listof string?)
  communicator : communicator?
  message-index : exact-nonnegative-integer?
procedure
((generic-message-command command            
                          ok-code)           
                          communicator       
                          message-index) -> (listof string?)
  command : string?
  ok-code : exact-integer?
  communicator : communicator?
  message-index : exact-nonnegative-integer?
procedure
(make-desired-header tag-string) -> regexp?
  tag-string : string?
procedure
(extract-desired-headers header desireds) -> (listof string?)
  header : (listof string?)
  desireds : (listof regexp?)
struct
(struct nntp exn ()
    #:extra-constructor-name make-nntp)
struct
(struct unexpected-response nntp (code text)
    #:extra-constructor-name make-unexpected-response)
  code : exact-integer?
  text : string?
struct
(struct bad-status-line nntp (line)
    #:extra-constructor-name make-bad-status-line)
  line : string?
struct
(struct premature-close nntp (communicator)
    #:extra-constructor-name make-premature-close)
  communicator : communicator?
struct
(struct bad-newsgroup-line nntp (line)
    #:extra-constructor-name make-bad-newsgroup-line)
  line : string?
struct
(struct non-existent-group nntp (group)
    #:extra-constructor-name make-non-existent-group)
  group : string?
struct
(struct article-not-in-group nntp (article)
    #:extra-constructor-name make-article-not-in-group)
  article : exact-integer?
struct
(struct no-group-selected nntp ()
    #:extra-constructor-name make-no-group-selected)
struct
(struct article-not-found nntp (article)
    #:extra-constructor-name make-article-not-found)
  article : exact-integer?
struct
(struct authentication-rejected nntp ()
    #:extra-constructor-name make-authentication-rejected)
value
nntp@ : unit?
signature
nntp^ : signature
signature
tcp^ : signature
procedure
(tcp-listen  port-no            
            [max-allow-wait     
             reuse?             
             hostname])     -> tcp-listener?
  port-no : (and/c exact-nonnegative-integer?
                   (integer-in 1 65535))
  max-allow-wait : exact-nonnegative-integer? = 4
  reuse? : any/c = #f
  hostname : (or/c string? false/c) = #f
procedure
(tcp-connect  hostname            
              port-no             
             [local-hostname      
              local-port-no]) -> input-port? output-port?
  hostname : string?
  port-no : (and/c exact-nonnegative-integer?
                  (integer-in 1 65535))
  local-hostname : (or/c string? false/c) = #f
  local-port-no : (or/c (and/c exact-nonnegative-integer? = #f
                               (integer-in 1 65535))
                        false/c)
procedure
(tcp-connect/enable-break  hostname        
                           port-no         
                          [local-hostname] 
                           local-port-no)  
 -> input-port? output-port?
  hostname : string?
  port-no : (and/c exact-nonnegative-integer?
                  (integer-in 1 65535))
  local-hostname : (or/c string? false/c) = #f
  local-port-no : (or/c (and/c exact-nonnegative-integer?
                               (integer-in 1 65535))
                        false/c)
procedure
(tcp-accept listener) -> input-port? output-port?
  listener : tcp-listener?
procedure
(tcp-accept/enable-break listener) -> input-port? output-port?
  listener : tcp-listener?
procedure
(tcp-accept-ready? listener) -> boolean?
  listener : tcp-listener?
procedure
(tcp-close listener) -> void?
  listener : tcp-listener?
procedure
(tcp-listener? v) -> boolean?
  v : any/c
procedure
(tcp-abandon-port tcp-port) -> void?
  tcp-port : port?
procedure
(tcp-addresses tcp-port [port-numbers?])
 -> (or/c (values string? string?)
          (values string? (integer-in 1 65535)
                  string? (integer-in 1 65535)))
  tcp-port : port?
  port-numbers? : any/c = #f
value
tcp@ : unit?
procedure
(tcp-redirect port-numbers) -> unit?
  port-numbers : (listof (integer-in 0 65535))
procedure
(make-ssl-tcp@ server-cert-file             
               server-key-file              
               server-root-cert-files       
               server-suggest-auth-file     
               client-cert-file             
               client-key-file              
               client-root-cert-files)  -> unit?
  server-cert-file : (or/c path-string? false/c)
  server-key-file : (or/c path-string? false/c)
  server-root-cert-files : (or/c (listof path-string?) false/c)
  server-suggest-auth-file : path-string?
  client-cert-file : (or/c path-string? false/c)
  client-key-file : (or/c path-string? false/c)
  client-root-cert-files : (listof path-string?)
procedure
(get-bindings)
 -> (listof (cons/c (or/c symbol? string?) string?))
procedure
(get-bindings/post)
 -> (listof (cons/c (or/c symbol? string?) string?))
procedure
(get-bindings/get)
 -> (listof (cons/c (or/c symbol? string?) string?))
procedure
(extract-bindings key? bindings) -> (listof string?)
  key? : (or/c symbol? string?)
  bindings : (listof (cons/c (or/c symbol? string?) string?))
procedure
(extract-binding/single key? bindings) -> string?
  key? : (or/c symbol? string?)
  bindings : (listof (cons/c (or/c symbol? string?) string?))
procedure
(output-http-headers) -> void?
procedure
(generate-html-output  title             
                       body              
                      [text-color        
                       bg-color          
                       link-color        
                       vlink-color       
                       alink-color]) -> void?
  title : string?
  body : (listof string?)
  text-color : string? = "#000000"
  bg-color : string? = "#ffffff"
  link-color : string? = "#cc2200"
  vlink-color : string? = "#882200"
  alink-color : string? = "#444444"
procedure
(string->html str) -> string?
  str : string?
procedure
(generate-link-text str html-str) -> string?
  str : string?
  html-str : string?
procedure
(generate-error-output strs) -> any
  strs : (listof string?)
procedure
(get-cgi-method) -> (one-of/c "GET" "POST")
procedure
(bindings-as-html listof) -> (listof string?)
  listof : (cons/c (or/c symbol? string?) string?)
value
cgi@ : unit?
signature
cgi^ : signature
procedure
(cookie? v) -> boolean?
  v : any/c
procedure
(valid-domain? v) -> boolean?
  v : any/c
procedure
(cookie-name? v) -> boolean?
  v : any/c
procedure
(cookie-value? v) -> boolean?
  v : any/c
procedure
(set-cookie name value) -> cookie?
  name : cookie-name?
  value : cookie-value?
procedure
(cookie:add-comment cookie comment) -> cookie?
  cookie : cookie?
  comment : string?
procedure
(cookie:add-domain cookie domain) -> cookie?
  cookie : cookie?
  domain : valid-domain?
procedure
(cookie:add-max-age cookie seconds) -> cookie?
  cookie : cookie?
  seconds : exact-nonnegative-integer?
procedure
(cookie:add-path cookie path) -> cookie?
  cookie : cookie?
  path : valid-path?
procedure
(cookie:add-expires cookie path) -> cookie?
  cookie : cookie?
  path : string
procedure
(cookie:secure cookie secure) -> cookie?
  cookie : cookie?
  secure : boolean?
procedure
(cookie:version cookie version) -> cookie?
  cookie : cookie?
  version : exact-nonnegative-integer?
procedure
(print-cookie cookie) -> string?
  cookie : cookie?
procedure
(get-cookie name cookies) -> (listof cookie-value?)
  name : cookie-name?
  cookies : string?
procedure
(get-cookie/single name cookies) -> (or/c cookie-value? false/c)
  name : cookie-name?
  cookies : string?
struct
(struct cookie-error exn:fail ()
    #:extra-constructor-name make-cookie-error)
value
cookie@ : unit?
signature
cookie^ : signature
procedure
(git-checkout  hostname                            
               repository                          
               #:dest-dir dest-dir                 
              [#:ref ref                           
               #:transport transport               
               #:depth depth                       
               #:status-printf status-printf       
               #:tmp-dir given-tmp-dir             
               #:clean-tmp-dir? clean-tmp-dir?     
               #:verify-server? verify-server?     
               #:port port])                   -> string?
  hostname : string?
  repository : string?
  dest-dir : (or/c path-string? #f)
  ref : string? = "master"
  transport : (or/c 'git 'http 'https) = 'git
  depth : (or/c #f exact-positive-integer?) = 1
  status-printf : (string? any/c ... . -> . void?)
                = (lambda args
                    (apply printf args)
                    (flush-output))
  given-tmp-dir : (or/c #f path-string?) = #f
  clean-tmp-dir? : any/c = (not given-tmp-dir)
  verify-server? : any/c = #t
  port : (or/c #f (integer-in 1 65535)) = (case transport
                                            [(git) 9418]
                                            [(http) 80]
                                            [(https) 443])
