scribble --markdown manual.scrbl
