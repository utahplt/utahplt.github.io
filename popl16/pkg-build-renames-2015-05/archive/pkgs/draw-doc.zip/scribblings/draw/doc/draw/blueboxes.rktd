16764
((3) 0 () 25 ((q lib "racket/draw.rkt") (c (? . 0) q dc<%>) (c (? . 0) q ps-setup%) (c (? . 0) q gl-config%) (c (? . 0) q region%) (c (? . 0) q pen%) (c (? . 0) q bitmap-dc%) (c (? . 0) q dc-path%) (c (? . 0) q bitmap%) (c (? . 0) q color%) (c (? . 0) q font-name-directory<%>) (c (? . 0) q pen-list%) (c (? . 0) q record-dc%) (c (? . 0) q brush%) (c (? . 0) q font%) (c (? . 0) q point%) (c (? . 0) q post-script-dc%) (c (? . 0) q linear-gradient%) (c (? . 0) q font-list%) (c (? . 0) q svg-dc%) (c (? . 0) q color-database<%>) (c (? . 0) q brush-list%) (c (? . 0) q radial-gradient%) (c (? . 0) q gl-context<%>) (c (? . 0) q pdf-dc%)) () (h ! (equal) ((c meth c (c (? . 7) q get-bounding-box)) q (25622 . 2)) ((c meth c (c (? . 1) q end-doc)) q (17867 . 2)) ((c meth c (c (? . 13) q get-gradient)) q (9218 . 4)) ((c meth c (c (? . 3) q get-accum-size)) q (34919 . 2)) ((c def c (c (? . 0) q read-bitmap)) q (55469 . 19)) ((c def c (c (? . 0) q font-smoothing/c)) q (56841 . 2)) ((c meth c (c (? . 9) q alpha)) q (12183 . 2)) ((c meth c (c (? . 1) q draw-bitmap)) q (13632 . 14)) ((c meth c (c (? . 6) q get-argb-pixels)) q (6347 . 15)) ((c meth c (c (? . 1) q get-origin)) q (18793 . 2)) ((c meth c (c (? . 1) q ok?)) q (20276 . 2)) ((c constructor c (? . 4)) q (46948 . 3)) ((c meth c (c (? . 2) q set-mode)) q (44990 . 3)) ((c meth c (c (? . 2) q set-level-2)) q (44772 . 3)) ((c meth c (c (? . 3) q set-accum-size)) q (35407 . 3)) ((c meth c (c (? . 1) q draw-polygon)) q (16202 . 10)) ((c meth c (c (? . 5) q set-style)) q (39896 . 3)) ((c meth c (c (? . 4) q set-polygon)) q (48447 . 10)) ((c meth c (c (? . 5) q is-immutable?)) q (39303 . 2)) ((c def c (? . 6)) q (4854 . 4)) ((c constructor c (? . 14)) q (27732 . 36)) ((c meth c (c (? . 2) q get-translation)) q (44286 . 4)) ((c meth c (c (? . 3) q set-share-context)) q (35771 . 3)) ((c def c (c (? . 0) q pen-cap-style/c)) q (56960 . 2)) ((c meth c (c (? . 1) q cache-font-metrics-key)) q (12834 . 2)) ((c meth c (c (? . 1) q get-clipping-region)) q (18342 . 2)) ((c meth c (c (? . 10) q set-post-script-name)) q (33993 . 10)) ((c meth c (c (? . 7) q translate)) q (27599 . 4)) ((c constructor c (? . 22)) q (45675 . 17)) ((c meth c (c (? . 8) q set-argb-pixels)) q (3979 . 17)) ((c meth c (c (? . 4) q get-dc)) q (47123 . 2)) ((c meth c (c (? . 1) q get-scale)) q (19102 . 2)) ((c meth c (c (? . 7) q curve-to)) q (25253 . 8)) ((c meth c (c (? . 8) q get-width)) q (2573 . 2)) ((c constructor c (? . 5)) q (38365 . 14)) ((c meth c (c (? . 7) q rotate)) q (26501 . 3)) ((c meth c (c (? . 9) q is-immutable?)) q (12487 . 2)) ((c def c (? . 10)) q (32186 . 2)) ((c meth c (c (? . 5) q set-cap)) q (39353 . 3)) ((c meth c (c (? . 1) q set-transformation)) q (23812 . 4)) ((c meth c (c (? . 2) q get-scaling)) q (44122 . 4)) ((c meth c (c (? . 3) q set-multisample-size)) q (35673 . 3)) ((c meth c (c (? . 3) q get-stereo)) q (35354 . 2)) ((c meth c (c (? . 4) q xor)) q (49843 . 3)) ((c meth c (c (? . 10) q get-font-id)) q (33053 . 7)) ((c meth c (c (? . 1) q set-pen)) q (22335 . 17)) ((c meth c (c (? . 1) q get-pen)) q (18843 . 2)) ((c constructor c (? . 6)) q (4927 . 3)) ((c constructor c (? . 12)) q (46511 . 6)) ((c meth c (c (? . 1) q draw-rectangle)) q (16632 . 6)) ((c meth c (c (? . 3) q set-stereo)) q (35984 . 3)) ((c def c (? . 2)) q (42907 . 3)) ((c meth c (c (? . 3) q set-double-buffered)) q (35591 . 3)) ((c meth c (c (? . 1) q flush)) q (17986 . 2)) ((c meth c (c (? . 8) q set-loaded-mask)) q (4764 . 3)) ((c def c (c (? . 0) q make-platform-bitmap)) q (55139 . 8)) ((c meth c (c (? . 11) q find-or-create-pen)) q (40161 . 28)) ((c constructor c (? . 15)) q (41591 . 5)) ((c meth c (c (? . 1) q get-path-bounding-box)) q (18893 . 5)) ((c meth c (c (? . 20) q find-color)) q (12618 . 4)) ((c constructor c (? . 18)) q (30093 . 2)) ((c meth c (c (? . 1) q transform)) q (24165 . 3)) ((c constructor c (? . 9)) q (11714 . 9)) ((c meth c (c (? . 7) q reset)) q (26413 . 2)) ((c def c (? . 11)) q (40054 . 3)) ((c meth c (c (? . 12) q get-recorded-procedure)) q (46807 . 3)) ((c def c (c (? . 0) q get-current-gl-context)) q (36686 . 2)) ((c meth c (c (? . 6) q set-pixel)) q (8015 . 5)) ((c meth c (c (? . 10) q get-face-name)) q (32743 . 4)) ((c meth c (c (? . 5) q get-style)) q (39199 . 2)) ((c meth c (c (? . 4) q in-region?)) q (47189 . 4)) ((c meth c (c (? . 2) q set-command)) q (44454 . 3)) ((c meth c (c (? . 13) q get-color)) q (9161 . 2)) ((c meth c (c (? . 3) q set-stencil-size)) q (35890 . 3)) ((c meth c (c (? . 1) q get-background)) q (18076 . 2)) ((c def c (? . 8)) q (0 . 3)) ((c meth c (c (? . 1) q try-color)) q (24357 . 4)) ((c meth c (c (? . 5) q get-color)) q (39021 . 2)) ((c meth c (c (? . 1) q set-origin)) q (22254 . 4)) ((c def c (c (? . 0) q make-color)) q (52739 . 6)) ((c meth c (c (? . 14) q get-font-id)) q (29355 . 2)) ((c def c (c (? . 0) q current-ps-setup)) q (50563 . 4)) ((c meth c (c (? . 10) q find-family-default-font-id)) q (32234 . 5)) ((c def c (c (? . 0) q the-pen-list)) q (56681 . 2)) ((c meth c (c (? . 1) q get-text-foreground)) q (19906 . 2)) ((c meth c (c (? . 8) q is-color?)) q (2695 . 2)) ((c meth c (c (? . 13) q get-stipple)) q (9475 . 2)) ((c meth c (c (? . 1) q end-page)) q (17907 . 2)) ((c def c (? . 9)) q (11665 . 3)) ((c meth c (c (? . 1) q draw-point)) q (16121 . 4)) ((c meth c (c (? . 1) q clear)) q (12898 . 2)) ((c meth c (c (? . 15) q set-y)) q (41873 . 3)) ((c meth c (c (? . 4) q union)) q (49765 . 3)) ((c meth c (c (? . 2) q get-margin)) q (43623 . 5)) ((c meth c (c (? . 1) q start-page)) q (24076 . 2)) ((c meth c (c (? . 1) q rotate)) q (20360 . 3)) ((c meth c (c (? . 4) q set-arc)) q (47408 . 13)) ((q def ((lib "racket/draw/unsafe/cairo-lib.rkt") cairo-lib)) q (57795 . 2)) ((c meth c (c (? . 5) q set-stipple)) q (39797 . 3)) ((c meth c (c (? . 7) q text-outline)) q (27104 . 11)) ((c meth c (c (? . 1) q set-clipping-region)) q (21960 . 3)) ((c meth c (c (? . 8) q ok?)) q (3504 . 2)) ((c meth c (c (? . 9) q green)) q (12102 . 2)) ((c constructor c (? . 2)) q (42959 . 2)) ((c meth c (c (? . 13) q get-transformation)) q (9600 . 4)) ((c meth c (c (? . 14) q get-underlined)) q (29756 . 2)) ((c meth c (c (? . 1) q set-brush)) q (20858 . 17)) ((c def c (? . 17)) q (36740 . 3)) ((c meth c (c (? . 7) q scale)) q (27023 . 4)) ((c constructor c (? . 16)) q (42011 . 17)) ((c meth c (c (? . 1) q draw-spline)) q (17278 . 8)) ((c meth c (c (? . 7) q reverse)) q (26456 . 2)) ((c meth c (c (? . 3) q set-legacy?)) q (36111 . 3)) ((c def c (c (? . 0) q recorded-datum->procedure)) q (56356 . 4)) ((c meth c (c (? . 3) q get-multisample-size)) q (35119 . 2)) ((c def c (c (? . 0) q the-font-list)) q (56567 . 2)) ((c def c (? . 23)) q (36193 . 2)) ((c meth c (c (? . 9) q set)) q (12234 . 6)) ((c meth c (c (? . 7) q rounded-rectangle)) q (26576 . 11)) ((c meth c (c (? . 1) q set-text-foreground)) q (23543 . 5)) ((c def c (? . 21)) q (10669 . 3)) ((c def c (c (? . 0) q the-font-name-directory)) q (56613 . 2)) ((c meth c (c (? . 4) q set-rectangle)) q (48889 . 9)) ((c meth c (c (? . 1) q resume-flush)) q (20315 . 2)) ((c meth c (c (? . 7) q arc)) q (24662 . 15)) ((c meth c (c (? . 1) q get-font)) q (18564 . 2)) ((c meth c (c (? . 2) q set-margin)) q (44845 . 4)) ((c def c (? . 16)) q (41933 . 4)) ((c meth c (c (? . 1) q get-size)) q (19151 . 3)) ((c meth c (c (? . 2) q set-scaling)) q (45378 . 4)) ((c meth c (c (? . 1) q get-char-width)) q (18266 . 2)) ((c meth c (c (? . 15) q get-x)) q (41731 . 2)) ((c meth c (c (? . 13) q get-handle)) q (9413 . 2)) ((c meth c (c (? . 1) q copy)) q (12936 . 8)) ((c def c (? . 4)) q (46898 . 3)) ((c constructor c (? . 13)) q (8190 . 18)) ((c meth c (c (? . 6) q get-pixel)) q (7117 . 5)) ((c meth c (c (? . 1) q draw-path)) q (15777 . 9)) ((c meth c (c (? . 7) q append)) q (24579 . 3)) ((c meth c (c (? . 1) q get-initial-matrix)) q (18694 . 3)) ((c meth c (c (? . 2) q get-editor-margin)) q (43260 . 5)) ((c meth c (c (? . 1) q draw-bitmap-section)) q (14173 . 22)) ((c meth c (c (? . 8) q load-file)) q (2744 . 14)) ((c meth c (c (? . 17) q get-line)) q (37242 . 2)) ((c meth c (c (? . 7) q open?)) q (26168 . 2)) ((c def c (? . 5)) q (38318 . 3)) ((c meth c (c (? . 1) q set-text-mode)) q (23718 . 3)) ((c meth c (c (? . 13) q set-style)) q (10589 . 3)) ((c constructor c (? . 24)) q (37494 . 17)) ((q form ((lib "racket/draw/draw-sig.rkt") draw^)) q (57104 . 2)) ((c meth c (c (? . 1) q draw-arc)) q (13167 . 13)) ((c def c (c (? . 0) q brush-style/c)) q (57043 . 2)) ((c meth c (c (? . 2) q set-translation)) q (45524 . 4)) ((c def c (? . 7)) q (24475 . 3)) ((c meth c (c (? . 8) q get-height)) q (2431 . 2)) ((c def c (? . 15)) q (41542 . 3)) ((c def c (c (? . 0) q make-font)) q (52907 . 21)) ((c def c (? . 13)) q (8141 . 3)) ((c meth c (c (? . 7) q line-to)) q (25697 . 4)) ((c def c (c (? . 0) q font-style/c)) q (56764 . 2)) ((c meth c (c (? . 6) q set-argb-pixels)) q (7246 . 15)) ((c meth c (c (? . 14) q get-hinting)) q (29410 . 2)) ((c meth c (c (? . 5) q get-join)) q (39076 . 2)) ((c meth c (c (? . 9) q ok?)) q (12539 . 2)) ((c meth c (c (? . 14) q screen-glyph-exists?)) q (29861 . 5)) ((c meth c (c (? . 1) q scale)) q (20426 . 4)) ((c meth c (c (? . 4) q subtract)) q (49684 . 3)) ((c def c (? . 18)) q (30040 . 3)) ((c constructor c (? . 19)) q (49989 . 12)) ((c meth c (c (? . 2) q set-preview-command)) q (45287 . 3)) ((c meth c (c (? . 3) q get-share-context)) q (35194 . 3)) ((c def c (c (? . 0) q make-pen)) q (54224 . 18)) ((c meth c (c (? . 1) q translate)) q (24273 . 4)) ((c meth c (c (? . 3) q get-depth-size)) q (34988 . 2)) ((c meth c (c (? . 1) q draw-rounded-rectangle)) q (16831 . 11)) ((c def c (c (? . 0) q get-family-builtin-face)) q (50901 . 4)) ((c meth c (c (? . 8) q has-alpha-channel?)) q (2637 . 2)) ((c meth c (c (? . 10) q get-screen-name)) q (33667 . 8)) ((c meth c (c (? . 8) q get-handle)) q (2380 . 2)) ((c meth c (c (? . 13) q set-color)) q (9854 . 9)) ((c meth c (c (? . 2) q get-mode)) q (43853 . 2)) ((c meth c (c (? . 1) q set-clipping-rect)) q (21627 . 9)) ((c constructor c (? . 3)) q (34862 . 2)) ((c meth c (c (? . 1) q set-alpha)) q (20610 . 3)) ((c meth c (c (? . 8) q get-loaded-mask)) q (2496 . 2)) ((q def ((lib "racket/draw/unsafe/brush.rkt") make-handle-brush)) q (57134 . 13)) ((c def c (? . 12)) q (46438 . 4)) ((c meth c (c (? . 13) q get-style)) q (9547 . 2)) ((c meth c (c (? . 1) q glyph-exists?)) q (20208 . 3)) ((c meth c (c (? . 1) q draw-ellipse)) q (15149 . 6)) ((c meth c (c (? . 10) q get-family)) q (32861 . 5)) ((c def c (c (? . 0) q get-face-list)) q (50686 . 6)) ((c meth c (c (? . 7) q ellipse)) q (25425 . 6)) ((c meth c (c (? . 2) q set-orientation)) q (45090 . 3)) ((c meth c (c (? . 1) q get-device-scale)) q (18419 . 3)) ((c meth c (c (? . 13) q is-immutable?)) q (9802 . 2)) ((c def c (c (? . 0) q make-bitmap)) q (51077 . 9)) ((c meth c (c (? . 1) q get-rotation)) q (19057 . 2)) ((c meth c (c (? . 7) q close)) q (25210 . 2)) ((c meth c (c (? . 1) q set-scale)) q (23158 . 4)) ((c meth c (c (? . 4) q is-empty?)) q (47359 . 2)) ((c meth c (c (? . 1) q start-doc)) q (24001 . 3)) ((c meth c (c (? . 1) q set-initial-matrix)) q (22137 . 3)) ((c constructor c (? . 11)) q (40106 . 2)) ((c meth c (c (? . 4) q set-rounded-rectangle)) q (49222 . 11)) ((c def c (c (? . 0) q make-monochrome-bitmap)) q (54026 . 5)) ((c meth c (c (? . 5) q set-width)) q (39972 . 3)) ((c def c (c (? . 0) q pen-join-style/c)) q (57001 . 2)) ((c def c (? . 19)) q (49919 . 4)) ((c meth c (c (? . 20) q get-names)) q (12737 . 2)) ((c meth c (c (? . 1) q draw-text)) q (17448 . 13)) ((c meth c (c (? . 1) q set-alignment-scale)) q (20526 . 3)) ((c meth c (c (? . 10) q set-screen-name)) q (34402 . 9)) ((c meth c (c (? . 10) q get-post-script-name)) q (33326 . 8)) ((c meth c (c (? . 12) q get-recorded-datum)) q (46749 . 2)) ((c meth c (c (? . 2) q get-command)) q (43208 . 2)) ((c meth c (c (? . 2) q get-file)) q (43504 . 2)) ((c def c (? . 3)) q (34809 . 3)) ((c meth c (c (? . 21) q find-or-create-brush)) q (10782 . 19)) ((c meth c (c (? . 2) q set-file)) q (44673 . 3)) ((c meth c (c (? . 1) q set-rotation)) q (23086 . 3)) ((c meth c (c (? . 7) q transform)) q (27486 . 3)) ((c meth c (c (? . 22) q get-stops)) q (46333 . 3)) ((c meth c (c (? . 5) q set-join)) q (39707 . 3)) ((c meth c (c (? . 1) q get-smoothing)) q (19280 . 3)) ((c meth c (c (? . 5) q get-width)) q (39248 . 2)) ((c meth c (c (? . 1) q get-alpha)) q (18024 . 2)) ((c meth c (c (? . 2) q copy-from)) q (43014 . 5)) ((c meth c (c (? . 8) q make-dc)) q (3444 . 2)) ((c meth c (c (? . 8) q get-argb-pixels)) q (1439 . 17)) ((c def c (c (? . 0) q the-brush-list)) q (56461 . 2)) ((c meth c (c (? . 2) q get-level-2)) q (43570 . 2)) ((c meth c (c (? . 1) q get-brush)) q (18135 . 2)) ((c def c (c (? . 0) q font-family/c)) q (56725 . 2)) ((c meth c (c (? . 1) q get-text-background)) q (19362 . 2)) ((c meth c (c (? . 18) q find-or-create-font)) q (30150 . 41)) ((c meth c (c (? . 7) q move-to)) q (26085 . 4)) ((c meth c (c (? . 9) q red)) q (12063 . 2)) ((c meth c (c (? . 23) q call-as-current)) q (36232 . 7)) ((c meth c (c (? . 9) q copy-from)) q (12395 . 3)) ((c constructor c (? . 7)) q (24526 . 2)) ((c meth c (c (? . 23) q ok?)) q (36586 . 2)) ((c meth c (c (? . 1) q get-char-height)) q (18189 . 2)) ((c meth c (c (? . 1) q get-text-mode)) q (19970 . 2)) ((c meth c (c (? . 14) q get-style)) q (29705 . 2)) ((c meth c (c (? . 1) q get-text-extent)) q (19426 . 13)) ((c meth c (c (? . 2) q get-preview-command)) q (44062 . 2)) ((c def c (c (? . 0) q the-color-database)) q (56509 . 2)) ((c meth c (c (? . 14) q get-family)) q (29302 . 2)) ((c meth c (c (? . 7) q lines)) q (25780 . 8)) ((c constructor c (? . 21)) q (10723 . 2)) ((c def c (? . 24)) q (37424 . 4)) ((c meth c (c (? . 6) q draw-bitmap-section-smooth)) q (5048 . 27)) ((c meth c (c (? . 4) q get-bounding-box)) q (47049 . 2)) ((c meth c (c (? . 14) q get-face)) q (29245 . 2)) ((c meth c (c (? . 5) q get-stipple)) q (39129 . 2)) ((c meth c (c (? . 9) q blue)) q (12143 . 2)) ((c meth c (c (? . 10) q find-or-create-font-id)) q (32448 . 7)) ((c def c (c (? . 0) q pen-style/c)) q (56923 . 2)) ((c meth c (c (? . 17) q get-stops)) q (37317 . 3)) ((c meth c (c (? . 3) q get-double-buffered)) q (35057 . 2)) ((c meth c (c (? . 3) q get-stencil-size)) q (35283 . 2)) ((c meth c (c (? . 14) q get-weight)) q (29808 . 2)) ((c meth c (c (? . 6) q get-bitmap)) q (7042 . 2)) ((q def ((lib "racket/draw/draw-unit.rkt") draw@)) q (57082 . 2)) ((c def c (c (? . 0) q font-weight/c)) q (56802 . 2)) ((c meth c (c (? . 1) q suspend-flush)) q (24119 . 2)) ((c meth c (c (? . 1) q set-font)) q (22060 . 3)) ((c def c (? . 22)) q (45616 . 3)) ((c meth c (c (? . 1) q draw-line)) q (15346 . 6)) ((c meth c (c (? . 14) q get-point-size)) q (29465 . 2)) ((c meth c (c (? . 3) q set-depth-size)) q (35499 . 3)) ((c meth c (c (? . 7) q rectangle)) q (26214 . 6)) ((c meth c (c (? . 4) q set-path)) q (48091 . 9)) ((c constructor c (? . 8)) q (50 . 30)) ((c meth c (c (? . 1) q erase)) q (17948 . 2)) ((c meth c (c (? . 14) q get-size)) q (29530 . 2)) ((c meth c (c (? . 15) q get-y)) q (41772 . 2)) ((c meth c (c (? . 3) q get-legacy?)) q (36057 . 2)) ((c meth c (c (? . 1) q set-smoothing)) q (23262 . 3)) ((c meth c (c (? . 22) q get-circles)) q (46240 . 3)) ((c def c (? . 20)) q (12575 . 2)) ((c meth c (c (? . 1) q get-transformation)) q (20039 . 4)) ((c meth c (c (? . 2) q set-editor-margin)) q (44537 . 4)) ((c meth c (c (? . 4) q intersect)) q (47277 . 3)) ((c constructor c (? . 17)) q (36799 . 13)) ((c meth c (c (? . 4) q set-ellipse)) q (47891 . 6)) ((c meth c (c (? . 13) q set-stipple)) q (10128 . 8)) ((c meth c (c (? . 8) q get-backing-scale)) q (2254 . 2)) ((c meth c (c (? . 2) q get-paper-name)) q (44007 . 2)) ((c meth c (c (? . 8) q save-file)) q (3547 . 9)) ((c meth c (c (? . 5) q get-cap)) q (38970 . 2)) ((c meth c (c (? . 6) q set-bitmap)) q (7911 . 3)) ((c meth c (c (? . 1) q set-text-background)) q (23368 . 5)) ((c meth c (c (? . 2) q get-orientation)) q (43928 . 3)) ((c meth c (c (? . 23) q get-handle)) q (36531 . 2)) ((c meth c (c (? . 15) q set-x)) q (41813 . 3)) ((c def c (c (? . 0) q make-brush)) q (51476 . 22)) ((c meth c (c (? . 1) q set-background)) q (20693 . 5)) ((c meth c (c (? . 8) q get-depth)) q (2313 . 2)) ((c def c (? . 14)) q (27684 . 3)) ((c meth c (c (? . 2) q set-paper-name)) q (45207 . 3)) ((c meth c (c (? . 5) q set-color)) q (39439 . 9)) ((c meth c (c (? . 23) q swap-buffers)) q (36633 . 2)) ((c meth c (c (? . 14) q get-size-in-pixels)) q (29590 . 2)) ((c meth c (c (? . 1) q get-gl-context)) q (18616 . 2)) ((c meth c (c (? . 14) q get-smoothing)) q (29646 . 2)) ((c meth c (c (? . 1) q draw-lines)) q (15472 . 8)) ((c def c (c (? . 0) q font-hinting/c)) q (56883 . 2)) ((c def c (? . 1)) q (12803 . 2))))
class
bitmap% : class?
  superclass: object%
constructor
(make-object bitmap%  width               
                      height              
                     [monochrome?         
                      alpha?              
                      backing-scale]) -> (is-a?/c bitmap%)
  width : exact-positive-integer?
  height : exact-positive-integer?
  monochrome? : any/c = #f
  alpha? : any/c = #f
  backing-scale : (>/c 0.0) = 1.0
(make-object bitmap%  in                       
                     [kind                     
                      bg-color                 
                      complain-on-failure?     
                      backing-scale])      -> (is-a?/c bitmap%)
  in : (or/c path-string? input-port?)
  kind : (or/c 'unknown 'unknown/mask 'unknown/alpha = 'unknown
               'gif 'gif/mask 'gif/alpha
               'jpeg 'jpeg/alpha
               'png 'png/mask 'png/alpha
               'xbm 'xbm/alpha 'xpm 'xpm/alpha
               'bmp 'bmp/alpha)
  bg-color : (or/c (is-a?/c color%) #f) = #f
  complain-on-failure? : any/c = #f
  backing-scale : (>/c 0.0) = 1.0
(make-object bitmap% bits width height) -> (is-a?/c bitmap%)
  bits : bytes?
  width : exact-positive-integer?
  height : exact-positive-integer?
method
(send a-bitmap get-argb-pixels  x                           
                                y                           
                                width                       
                                height                      
                                pixels                      
                               [just-alpha?                 
                                pre-multiplied?             
                                #:unscaled? unscaled?]) -> void?
  x : real?
  y : real?
  width : exact-nonnegative-integer?
  height : exact-nonnegative-integer?
  pixels : (and/c bytes? (not/c immutable?))
  just-alpha? : any/c = #f
  pre-multiplied? : any/c = #f
  unscaled? : any/c = #f
method
(send a-bitmap get-backing-scale) -> (>/c 0.0)
method
(send a-bitmap get-depth) -> exact-nonnegative-integer?
method
(send a-bitmap get-handle) -> cpointer?
method
(send a-bitmap get-height) -> exact-positive-integer?
method
(send a-bitmap get-loaded-mask) -> (or/c (is-a?/c bitmap%) #f)
method
(send a-bitmap get-width) -> exact-positive-integer?
method
(send a-bitmap has-alpha-channel?) -> boolean?
method
(send a-bitmap is-color?) -> boolean?
method
(send a-bitmap load-file  in                         
                         [kind                       
                          bg-color                   
                          complain-on-failure?]) -> boolean?
  in : (or/c path-string? input-port?)
  kind : (or/c 'unknown 'unknown/mask 'unknown/alpha = 'unknown
               'gif 'gif/mask 'gif/alpha
               'jpeg 'jpeg/alpha
               'png 'png/mask 'png/alpha
               'xbm 'xbm/alpha 'xpm 'xpm/alpha
               'bmp 'bmp/alpha)
  bg-color : (or/c (is-a?/c color%) #f) = #f
  complain-on-failure? : any/c = #f
method
(send a-bitmap make-dc) -> (is-a?/c bitmap-dc%)
method
(send a-bitmap ok?) -> boolean?
method
(send a-bitmap save-file  name                        
                          kind                        
                         [quality                     
                          #:unscaled? unscaled?]) -> boolean?
  name : (or/c path-string? output-port?)
  kind : (or/c 'png 'jpeg 'xbm 'xpm 'bmp)
  quality : (integer-in 0 100) = 75
  unscaled? : any/c = #f
method
(send a-bitmap set-argb-pixels  x                           
                                y                           
                                width                       
                                height                      
                                pixels                      
                               [just-alpha?                 
                                pre-multiplied?             
                                #:unscaled? unscaled?]) -> void?
  x : real?
  y : real?
  width : exact-nonnegative-integer?
  height : exact-nonnegative-integer?
  pixels : bytes?
  just-alpha? : any/c = #f
  pre-multiplied? : any/c = #f
  unscaled? : any/c = #f
method
(send a-bitmap set-loaded-mask mask) -> void?
  mask : (is-a?/c bitmap%)
class
bitmap-dc% : class?
  superclass: object%
  extends: dc<%>
constructor
(new bitmap-dc% [bitmap bitmap]) -> (is-a?/c bitmap-dc%)
  bitmap : (or/c (is-a?/c bitmap%) #f)
method
(send a-bitmap-dc draw-bitmap-section-smooth  source      
                                              dest-x      
                                              dest-y      
                                              dest-width  
                                              dest-height 
                                              src-x       
                                              src-y       
                                              src-width   
                                              src-height  
                                             [style       
                                              color       
                                              mask])      
 -> boolean?
  source : (is-a?/c bitmap%)
  dest-x : real?
  dest-y : real?
  dest-width : (and/c real? (not/c negative?))
  dest-height : (and/c real? (not/c negative?))
  src-x : real?
  src-y : real?
  src-width : (and/c real? (not/c negative?))
  src-height : (and/c real? (not/c negative?))
  style : (or/c 'solid 'opaque 'xor) = 'solid
  color : (is-a?/c color%)
        = (send the-color-database find-color "black")
  mask : (or/c (is-a?/c bitmap%) #f) = #f
method
(send a-bitmap-dc get-argb-pixels  x                     
                                   y                     
                                   width                 
                                   height                
                                   pixels                
                                  [just-alpha?           
                                   pre-multiplied?]) -> void?
  x : real?
  y : real?
  width : exact-nonnegative-integer?
  height : exact-nonnegative-integer?
  pixels : (and/c bytes? (not/c immutable?))
  just-alpha? : any/c = #f
  pre-multiplied? : any/c = #f
method
(send a-bitmap-dc get-bitmap) -> (or/c (is-a?/c bitmap%) #f)
method
(send a-bitmap-dc get-pixel x y color) -> boolean?
  x : real?
  y : real?
  color : (is-a?/c color%)
method
(send a-bitmap-dc set-argb-pixels  x                     
                                   y                     
                                   width                 
                                   height                
                                   pixels                
                                  [just-alpha?           
                                   pre-multiplied?]) -> void?
  x : real?
  y : real?
  width : exact-nonnegative-integer?
  height : exact-nonnegative-integer?
  pixels : bytes?
  just-alpha? : any/c = #f
  pre-multiplied? : any/c = #f
method
(send a-bitmap-dc set-bitmap bitmap) -> void?
  bitmap : (or/c (is-a?/c bitmap%) #f)
method
(send a-bitmap-dc set-pixel x y color) -> void?
  x : real?
  y : real?
  color : (is-a?/c color%)
class
brush% : class?
  superclass: object%
constructor
(new brush%                                    
            [[color color]                     
             [style style]                     
             [stipple stipple]                 
             [gradient gradient]               
             [transformation transformation]]) 
 -> (is-a?/c brush%)
  color : (or/c string? (is-a?/c color%)) = "black"
  style : brush-style/c = 'solid
  stipple : (or/c #f (is-a?/c bitmap%)) = #f
  gradient : (or/c #f                          = #f
                   (is-a?/c linear-gradient%)
                   (is-a?/c radial-gradient%))
  transformation : (or/c #f (vector/c (vector/c real? real? real?
                                                real? real? real?)
                                       real? real? real? real? real?))
                 = #f
method
(send a-brush get-color) -> (is-a?/c color%)
method
(send a-brush get-gradient) -> (or/c (is-a?/c linear-gradient%)
                                     (is-a?/c radial-gradient%)
                                     #f)
method
(send a-brush get-handle) -> (or/c cpointer? #f)
method
(send a-brush get-stipple) -> (or/c (is-a?/c bitmap%) #f)
method
(send a-brush get-style) -> brush-style/c
method
(send a-brush get-transformation)
 -> (or/c #f (vector/c (vector/c real? real? real? real? real? real?)
                       real? real? real? real? real?))
method
(send a-brush is-immutable?) -> boolean?
method
(send a-brush set-color color) -> void?
  color : (is-a?/c color%)
(send a-brush set-color color-name) -> void?
  color-name : string?
(send a-brush set-color red green blue) -> void?
  red : byte?
  green : byte?
  blue : byte?
method
(send a-brush set-stipple  bitmap               
                          [transformation]) -> void?
  bitmap : (or/c (is-a?/c bitmap%) #f)
  transformation : (or/c #f (vector/c (vector/c real? real? real?
                                                real? real? real?)
                                       real? real? real? real? real?))
                 = #f
method
(send a-brush set-style style) -> void?
  style : brush-style/c
class
brush-list% : class?
  superclass: object%
constructor
(new brush-list%) -> (is-a?/c brush-list%)
method
(send a-brush-list find-or-create-brush color  
                                        style) 
 -> (is-a?/c brush%)
  color : (or/c string? (is-a?/c color%))
  style : (or/c 'transparent 'solid 'opaque
                'xor 'hilite 'panel
                'bdiagonal-hatch 'crossdiag-hatch
                'fdiagonal-hatch 'cross-hatch
                'horizontal-hatch 'vertical-hatch)
(send a-brush-list find-or-create-brush color-name 
                                        style)     
 -> (or/c (is-a?/c brush%) #f)
  color-name : string?
  style : (or/c 'transparent 'solid 'opaque
                'xor 'hilite 'panel
                'bdiagonal-hatch 'crossdiag-hatch
                'fdiagonal-hatch 'cross-hatch
                'horizontal-hatch 'vertical-hatch)
class
color% : class?
  superclass: object%
constructor
(make-object color%) -> (is-a?/c color%)
(make-object color% red green blue [alpha]) -> (is-a?/c color%)
  red : byte?
  green : byte?
  blue : byte?
  alpha : (real-in 0 1) = 1.0
(make-object color% color-name-or-obj) -> (is-a?/c color%)
  color-name-or-obj : (or/c string? (is-a?/c color%))
method
(send a-color red) -> byte?
method
(send a-color green) -> byte?
method
(send a-color blue) -> byte?
method
(send a-color alpha) -> (real-in 0 1)
method
(send a-color set red green blue [alpha]) -> void?
  red : byte?
  green : byte?
  blue : byte?
  alpha : (real-in 0 1) = 1.0
method
(send a-color copy-from src) -> (is-a?/c color%)
  src : (is-a?/c color%)
method
(send a-color is-immutable?) -> boolean?
method
(send a-color ok?) -> #t
interface
color-database<%> : interface?
method
(send a-color-database find-color color-name)
 -> (or/c (is-a?/c color%) #f)
  color-name : string?
method
(send a-color-database get-names) -> (listof string?)
interface
dc<%> : interface?
method
(send a-dc cache-font-metrics-key) -> exact-integer?
method
(send a-dc clear) -> void?
method
(send a-dc copy x y width height x2 y2) -> void?
  x : real?
  y : real?
  width : (and/c real? (not/c negative?))
  height : (and/c real? (not/c negative?))
  x2 : real?
  y2 : real?
method
(send a-dc draw-arc x                 
                    y                 
                    width             
                    height            
                    start-radians     
                    end-radians)  -> void?
  x : real?
  y : real?
  width : (and/c real? (not/c negative?))
  height : (and/c real? (not/c negative?))
  start-radians : real?
  end-radians : real?
method
(send a-dc draw-bitmap  source     
                        dest-x     
                        dest-y     
                       [style      
                        color      
                        mask]) -> boolean?
  source : (is-a?/c bitmap%)
  dest-x : real?
  dest-y : real?
  style : (or/c 'solid 'opaque 'xor) = 'solid
  color : (is-a?/c color%)
        = (send the-color-database find-color "black")
  mask : (or/c (is-a?/c bitmap%) #f) = #f
method
(send a-dc draw-bitmap-section  source         
                                dest-x         
                                dest-y         
                                src-x          
                                src-y          
                                src-width      
                                src-height     
                               [style          
                                color          
                                mask])     -> boolean?
  source : (is-a?/c bitmap%)
  dest-x : real?
  dest-y : real?
  src-x : real?
  src-y : real?
  src-width : (and/c real? (not/c negative?))
  src-height : (and/c real? (not/c negative?))
  style : (or/c 'solid 'opaque 'xor) = 'solid
  color : (is-a?/c color%)
        = (send the-color-database find-color "black")
  mask : (or/c (is-a?/c bitmap%) #f) = #f
method
(send a-dc draw-ellipse x y width height) -> void?
  x : real?
  y : real?
  width : (and/c real? (not/c negative?))
  height : (and/c real? (not/c negative?))
method
(send a-dc draw-line x1 y1 x2 y2) -> void?
  x1 : real?
  y1 : real?
  x2 : real?
  y2 : real?
method
(send a-dc draw-lines  points        
                      [xoffset       
                       yoffset]) -> void?
  points : (or/c (listof (is-a?/c point%))
                 (listof (cons/c real? real?)))
  xoffset : real? = 0
  yoffset : real? = 0
method
(send a-dc draw-path  path             
                     [xoffset          
                      yoffset          
                      fill-style]) -> void?
  path : (is-a?/c dc-path%)
  xoffset : real? = 0
  yoffset : real? = 0
  fill-style : (or/c 'odd-even 'winding) = 'odd-even
method
(send a-dc draw-point x y) -> void?
  x : real?
  y : real?
method
(send a-dc draw-polygon  points           
                        [xoffset          
                         yoffset          
                         fill-style]) -> void?
  points : (or/c (listof (is-a?/c point%))
                 (listof (cons/c real? real?)))
  xoffset : real? = 0
  yoffset : real? = 0
  fill-style : (or/c 'odd-even 'winding) = 'odd-even
method
(send a-dc draw-rectangle x y width height) -> void?
  x : real?
  y : real?
  width : (and/c real? (not/c negative?))
  height : (and/c real? (not/c negative?))
method
(send a-dc draw-rounded-rectangle  x            
                                   y            
                                   width        
                                   height       
                                  [radius]) -> void?
  x : real?
  y : real?
  width : (and/c real? (not/c negative?))
  height : (and/c real? (not/c negative?))
  radius : real? = -0.25
method
(send a-dc draw-spline x1 y1 x2 y2 x3 y3) -> void?
  x1 : real?
  y1 : real?
  x2 : real?
  y2 : real?
  x3 : real?
  y3 : real?
method
(send a-dc draw-text  text         
                      x            
                      y            
                     [combine?     
                      offset       
                      angle])  -> void?
  text : string?
  x : real?
  y : real?
  combine? : any/c = #f
  offset : exact-nonnegative-integer? = 0
  angle : real? = 0
method
(send a-dc end-doc) -> void?
method
(send a-dc end-page) -> void?
method
(send a-dc erase) -> void?
method
(send a-dc flush) -> void?
method
(send a-dc get-alpha) -> (real-in 0 1)
method
(send a-dc get-background) -> (is-a?/c color%)
method
(send a-dc get-brush) -> (is-a?/c brush%)
method
(send a-dc get-char-height) -> (and/c real? (not/c negative?))
method
(send a-dc get-char-width) -> (and/c real? (not/c negative?))
method
(send a-dc get-clipping-region) -> (or/c (is-a?/c region%) #f)
method
(send a-dc get-device-scale) -> (and/c real? (not/c negative?))
                                (and/c real? (not/c negative?))
method
(send a-dc get-font) -> (is-a?/c font%)
method
(send a-dc get-gl-context) -> (or/c (is-a?/c gl-context<%>) #f)
method
(send a-dc get-initial-matrix)
 -> (vector/c real? real? real? real? real? real?)
method
(send a-dc get-origin) -> real? real?
method
(send a-dc get-pen) -> (is-a?/c pen%)
method
(send a-dc get-path-bounding-box path type)
 -> real? real? real? real?
  path : (is-a?/c dc-path%)
  type : (or/c 'path 'stroke 'fill)
method
(send a-dc get-rotation) -> real?
method
(send a-dc get-scale) -> real? real?
method
(send a-dc get-size) -> (and/c real? (not/c negative?))
                        (and/c real? (not/c negative?))
method
(send a-dc get-smoothing)
 -> (or/c 'unsmoothed 'smoothed 'aligned)
method
(send a-dc get-text-background) -> (is-a?/c color%)
method
(send a-dc get-text-extent  string   
                           [font     
                            combine? 
                            offset]) 
 -> (and/c real? (not/c negative?))
    (and/c real? (not/c negative?))
    (and/c real? (not/c negative?))
    (and/c real? (not/c negative?))
  string : string?
  font : (or/c (is-a?/c font%) #f) = #f
  combine? : any/c = #f
  offset : exact-nonnegative-integer? = 0
method
(send a-dc get-text-foreground) -> (is-a?/c color%)
method
(send a-dc get-text-mode) -> (or/c 'solid 'transparent)
method
(send a-dc get-transformation)
 -> (vector/c (vector/c real? real? real? real? real? real?)
              real? real? real? real? real?)
method
(send a-dc glyph-exists? c) -> boolean?
  c : char?
method
(send a-dc ok?) -> boolean?
method
(send a-dc resume-flush) -> void?
method
(send a-dc rotate angle) -> void?
  angle : real?
method
(send a-dc scale x-scale y-scale) -> void?
  x-scale : real?
  y-scale : real?
method
(send a-dc set-alignment-scale scale) -> void?
  scale : (>/c 0.0)
method
(send a-dc set-alpha opacity) -> void?
  opacity : (real-in 0 1)
method
(send a-dc set-background color) -> void?
  color : (is-a?/c color%)
(send a-dc set-background color-name) -> void?
  color-name : string?
method
(send a-dc set-brush brush) -> void?
  brush : (is-a?/c brush%)
(send a-dc set-brush color style) -> void?
  color : (is-a?/c color%)
  style : (or/c 'transparent 'solid 'opaque
                'xor 'hilite 'panel
                'bdiagonal-hatch 'crossdiag-hatch
                'fdiagonal-hatch 'cross-hatch
                'horizontal-hatch 'vertical-hatch)
(send a-dc set-brush color-name style) -> void?
  color-name : string?
  style : (or/c 'transparent 'solid 'opaque
                'xor 'hilite 'panel
                'bdiagonal-hatch 'crossdiag-hatch
                'fdiagonal-hatch 'cross-hatch
                'horizontal-hatch 'vertical-hatch)
method
(send a-dc set-clipping-rect x           
                             y           
                             width       
                             height) -> void?
  x : real?
  y : real?
  width : (and/c real? (not/c negative?))
  height : (and/c real? (not/c negative?))
method
(send a-dc set-clipping-region rgn) -> void?
  rgn : (or/c (is-a?/c region%) #f)
method
(send a-dc set-font font) -> void?
  font : (is-a?/c font%)
method
(send a-dc set-initial-matrix m) -> void?
  m : (vector/c real? real? real? real? real? real?)
method
(send a-dc set-origin x y) -> void?
  x : real?
  y : real?
method
(send a-dc set-pen pen) -> void?
  pen : (is-a?/c pen%)
(send a-dc set-pen color width style) -> void?
  color : (is-a?/c color%)
  width : (real-in 0 255)
  style : (or/c 'transparent 'solid 'xor 'hilite
                'dot 'long-dash 'short-dash 'dot-dash
                'xor-dot 'xor-long-dash 'xor-short-dash
                'xor-dot-dash)
(send a-dc set-pen color-name width style) -> void?
  color-name : string?
  width : (real-in 0 255)
  style : (or/c 'transparent 'solid 'xor 'hilite
                'dot 'long-dash 'short-dash 'dot-dash
                'xor-dot 'xor-long-dash 'xor-short-dash
                'xor-dot-dash)
method
(send a-dc set-rotation angle) -> void?
  angle : real?
method
(send a-dc set-scale x-scale y-scale) -> void?
  x-scale : real?
  y-scale : real?
method
(send a-dc set-smoothing mode) -> void?
  mode : (or/c 'unsmoothed 'smoothed 'aligned)
method
(send a-dc set-text-background color) -> void?
  color : (is-a?/c color%)
(send a-dc set-text-background color-name) -> void?
  color-name : string?
method
(send a-dc set-text-foreground color) -> void?
  color : (is-a?/c color%)
(send a-dc set-text-foreground color-name) -> void?
  color-name : string?
method
(send a-dc set-text-mode mode) -> void?
  mode : (or/c 'solid 'transparent)
method
(send a-dc set-transformation t) -> void?
  t : (vector/c (vector/c real? real? real? real? real? real?)
                real? real? real? real? real?)
method
(send a-dc start-doc message) -> void?
  message : string?
method
(send a-dc start-page) -> void?
method
(send a-dc suspend-flush) -> void?
method
(send a-dc transform m) -> void?
  m : (vector/c real? real? real? real? real? real?)
method
(send a-dc translate dx dy) -> void?
  dx : real?
  dy : real?
method
(send a-dc try-color try result) -> void?
  try : (is-a?/c color%)
  result : (is-a?/c color%)
class
dc-path% : class?
  superclass: object%
constructor
(new dc-path%) -> (is-a?/c dc-path%)
method
(send a-dc-path append path) -> void?
  path : (is-a?/c dc-path%)
method
(send a-dc-path arc  x                        
                     y                        
                     width                    
                     height                   
                     start-radians            
                     end-radians              
                    [counter-clockwise?]) -> void?
  x : real?
  y : real?
  width : real?
  height : real?
  start-radians : real?
  end-radians : real?
  counter-clockwise? : any/c = #t
method
(send a-dc-path close) -> void?
method
(send a-dc-path curve-to x1 y1 x2 y2 x3 y3) -> void?
  x1 : real?
  y1 : real?
  x2 : real?
  y2 : real?
  x3 : real?
  y3 : real?
method
(send a-dc-path ellipse x y width height) -> void?
  x : real?
  y : real?
  width : (and/c real? (not/c negative?))
  height : (and/c real? (not/c negative?))
method
(send a-dc-path get-bounding-box) -> real? real? real? real?
method
(send a-dc-path line-to x y) -> void?
  x : real?
  y : real?
method
(send a-dc-path lines  points        
                      [xoffset       
                       yoffset]) -> void?
  points : (or/c (listof (is-a?/c point%))
                 (listof (cons/c real? real?)))
  xoffset : real? = 0
  yoffset : real? = 0
method
(send a-dc-path move-to x y) -> void?
  x : real?
  y : real?
method
(send a-dc-path open?) -> boolean?
method
(send a-dc-path rectangle x y width height) -> void?
  x : real?
  y : real?
  width : (and/c real? (not/c negative?))
  height : (and/c real? (not/c negative?))
method
(send a-dc-path reset) -> void?
method
(send a-dc-path reverse) -> void?
method
(send a-dc-path rotate radians) -> void?
  radians : real?
method
(send a-dc-path rounded-rectangle  x            
                                   y            
                                   width        
                                   height       
                                  [radius]) -> void?
  x : real?
  y : real?
  width : (and/c real? (not/c negative?))
  height : (and/c real? (not/c negative?))
  radius : real? = -0.25
method
(send a-dc-path scale x y) -> void?
  x : real?
  y : real?
method
(send a-dc-path text-outline  font           
                              str            
                              x              
                              y              
                             [combine?]) -> void?
  font : (is-a?/c font%)
  str : string?
  x : real?
  y : real?
  combine? : any/c = #f
method
(send a-dc-path transform m) -> void?
  m : (vector/c real? real? real? real? real? real?)
method
(send a-dc-path translate x y) -> void?
  x : real?
  y : real?
class
font% : class?
  superclass: object%
constructor
(make-object font%) -> (is-a?/c font%)
(make-object font%  size                
                    family              
                   [style               
                    weight              
                    underline?          
                    smoothing           
                    size-in-pixels?     
                    hinting])       -> (is-a?/c font%)
  size : (real-in 0.0 1024.0)
  family : font-family/c
  style : font-style/c = 'normal
  weight : font-weight/c = 'normal
  underline? : any/c = #f
  smoothing : font-smoothing/c = 'default
  size-in-pixels? : any/c = #f
  hinting : font-hinting/c = 'aligned
(make-object font%  size                
                    face                
                    family              
                   [style               
                    weight              
                    underline?          
                    smoothing           
                    size-in-pixels?     
                    hinting])       -> (is-a?/c font%)
  size : (real-in 0.0 1024.0)
  face : string?
  family : font-family/c
  style : font-style/c = 'normal
  weight : font-weight/c = 'normal
  underline? : any/c = #f
  smoothing : font-smoothing/c = 'default
  size-in-pixels? : any/c = #f
  hinting : font-hinting/c = 'aligned
method
(send a-font get-face) -> (or/c string? #f)
method
(send a-font get-family) -> font-family/c
method
(send a-font get-font-id) -> exact-integer?
method
(send a-font get-hinting) -> font-hinting/c
method
(send a-font get-point-size) -> (integer-in 1 1024)
method
(send a-font get-size) -> (real-in 0.0 1024.0)
method
(send a-font get-size-in-pixels) -> boolean?
method
(send a-font get-smoothing) -> font-smoothing/c
method
(send a-font get-style) -> font-style/c
method
(send a-font get-underlined) -> boolean?
method
(send a-font get-weight) -> font-weight/c
method
(send a-font screen-glyph-exists?  c                
                                  [for-label?]) -> boolean?
  c : char?
  for-label? : any/c = #f
class
font-list% : class?
  superclass: object%
constructor
(new font-list%) -> (is-a?/c font-list%)
method
(send a-font-list find-or-create-font  size            
                                       family          
                                       style           
                                       weight          
                                      [underline?      
                                       smoothing       
                                       size-in-pixels? 
                                       hinting])       
 -> (is-a?/c font%)
  size : (real-in 0.0 1024.0)
  family : (or/c 'default 'decorative 'roman 'script
                 'swiss 'modern 'symbol 'system)
  style : (or/c 'normal 'italic 'slant)
  weight : (or/c 'normal 'bold 'light)
  underline? : any/c = #f
  smoothing : (or/c 'default 'partly-smoothed 'smoothed 'unsmoothed)
            = 'default
  size-in-pixels? : any/c = #f
  hinting : (or/c 'aligned 'unaligned) = 'aligned
(send a-font-list find-or-create-font  size            
                                       face            
                                       family          
                                       style           
                                       weight          
                                      [underline       
                                       smoothing       
                                       size-in-pixels? 
                                       hinting])       
 -> (is-a?/c font%)
  size : (real-in 0.0 1024.0)
  face : string?
  family : (or/c 'default 'decorative 'roman 'script
                 'swiss 'modern 'symbol 'system)
  style : (or/c 'normal 'italic 'slant)
  weight : (or/c 'normal 'bold 'light)
  underline : any/c = #f
  smoothing : (or/c 'default 'partly-smoothed 'smoothed 'unsmoothed)
            = 'default
  size-in-pixels? : any/c = #f
  hinting : (or/c 'aligned 'unaligned) = 'aligned
interface
font-name-directory<%> : interface?
method
(send a-font-name-directory find-family-default-font-id family)
 -> exact-integer?
  family : (or/c 'default 'decorative 'roman 'script
                 'swiss 'modern 'symbol 'system)
method
(send a-font-name-directory find-or-create-font-id name    
                                                   family) 
 -> exact-integer?
  name : string?
  family : (or/c 'default 'decorative 'roman 'script
                 'swiss 'modern 'symbol 'system)
method
(send a-font-name-directory get-face-name font-id)
 -> (or/c string? #f)
  font-id : exact-integer?
method
(send a-font-name-directory get-family font-id)
 -> (or/c 'default 'decorative 'roman 'script
          'swiss 'modern 'symbol 'system)
  font-id : exact-integer?
method
(send a-font-name-directory get-font-id name    
                                        family) 
 -> exact-integer?
  name : string?
  family : (or/c 'default 'decorative 'roman 'script
                 'swiss 'modern 'symbol 'system)
method
(send a-font-name-directory get-post-script-name font-id 
                                                 weight  
                                                 style)  
 -> (or/c string? #f)
  font-id : exact-integer?
  weight : (or/c 'normal 'bold 'light)
  style : (or/c 'normal 'italic 'slant)
method
(send a-font-name-directory get-screen-name font-id 
                                            weight  
                                            style)  
 -> (or/c string? #f)
  font-id : exact-integer?
  weight : (or/c 'normal 'bold 'light)
  style : (or/c 'normal 'italic 'slant)
method
(send a-font-name-directory set-post-script-name font-id 
                                                 weight  
                                                 style   
                                                 name)   
 -> void?
  font-id : exact-integer?
  weight : (or/c 'normal 'bold 'light)
  style : (or/c 'normal 'italic 'slant)
  name : string?
method
(send a-font-name-directory set-screen-name font-id     
                                            weight      
                                            style       
                                            name)   -> void?
  font-id : exact-integer?
  weight : (or/c 'normal 'bold 'light)
  style : (or/c 'normal 'italic 'slant)
  name : string?
class
gl-config% : class?
  superclass: object%
constructor
(new gl-config%) -> (is-a?/c gl-config%)
method
(send a-gl-config get-accum-size) -> (integer-in 0 256)
method
(send a-gl-config get-depth-size) -> (integer-in 0 256)
method
(send a-gl-config get-double-buffered) -> boolean?
method
(send a-gl-config get-multisample-size) -> (integer-in 0 256)
method
(send a-gl-config get-share-context)
 -> (or/c #f (is-a?/c gl-context<%>))
method
(send a-gl-config get-stencil-size) -> (integer-in 0 256)
method
(send a-gl-config get-stereo) -> boolean?
method
(send a-gl-config set-accum-size on?) -> void?
  on? : (integer-in 0 256)
method
(send a-gl-config set-depth-size on?) -> void?
  on? : (integer-in 0 256)
method
(send a-gl-config set-double-buffered on?) -> void?
  on? : any/c
method
(send a-gl-config set-multisample-size on?) -> void?
  on? : (integer-in 0 256)
method
(send a-gl-config set-share-context context) -> void?
  context : (or/c #f (is-a?/c gl-context<%>))
method
(send a-gl-config set-stencil-size on?) -> void?
  on? : (integer-in 0 256)
method
(send a-gl-config set-stereo on?) -> void?
  on? : any/c
method
(send a-gl-config get-legacy?) -> boolean?
method
(send a-gl-config set-legacy? legacy?) -> void?
  legacy? : any/c
interface
gl-context<%> : interface?
method
(send a-gl-context call-as-current  thunk                
                                   [alternate            
                                    enable-breaks?]) -> any/c
  thunk : (-> any)
  alternate : evt? = never-evt
  enable-breaks? : any/c = #f
method
(send a-gl-context get-handle) -> cpointer?
method
(send a-gl-context ok?) -> boolean?
method
(send a-gl-context swap-buffers) -> void?
procedure
(get-current-gl-context) -> gl-context<%>
class
linear-gradient% : class?
  superclass: object%
constructor
(new linear-gradient%                
                      [x0 x0]        
                      [y0 y0]        
                      [x1 x1]        
                      [y1 y1]        
                      [stops stops]) 
 -> (is-a?/c linear-gradient%)
  x0 : real?
  y0 : real?
  x1 : real?
  y1 : real?
  stops : (listof (list/c (real-in 0 1) (is-a?/c color%)))
method
(send a-linear-gradient get-line) -> real? real? real? real?
method
(send a-linear-gradient get-stops)
 -> (listof (list/c (real-in/c 0 1) (is-a?/c color%)))
class
pdf-dc% : class?
  superclass: object%
  extends: dc<%>
constructor
(new pdf-dc%                                  
             [[interactive interactive]       
              [parent parent]                 
              [use-paper-bbox use-paper-bbox] 
              [as-eps as-eps]                 
              [width width]                   
              [height height]                 
              [output output]])               
 -> (is-a?/c pdf-dc%)
  interactive : any/c = #t
  parent : (or/c (is-a?/c frame%) (is-a?/c dialog%) #f) = #f
  use-paper-bbox : any/c = #f
  as-eps : any/c = #t
  width : (or/c (and/c real? (not/c negative?)) #f) = #f
  height : (or/c (and/c real? (not/c negative?)) #f) = #f
  output : (or/c path-string? output-port? #f) = #f
class
pen% : class?
  superclass: object%
constructor
(new pen%                          
          [[color color]           
           [width width]           
           [style style]           
           [cap cap]               
           [join join]             
           [stipple stipple]]) -> (is-a?/c pen%)
  color : (or/c string? (is-a?/c color%)) = "black"
  width : (real-in 0 255) = 0
  style : pen-style/c = 'solid
  cap : pen-cap-style/c = 'round
  join : pen-join-style/c = 'round
  stipple : (or/c #f (is-a?/c bitmap%)) = #f
method
(send a-pen get-cap) -> pen-cap-style/c
method
(send a-pen get-color) -> (is-a?/c color%)
method
(send a-pen get-join) -> pen-join-style/c
method
(send a-pen get-stipple) -> (or/c (is-a?/c bitmap%) #f)
method
(send a-pen get-style) -> pen-style/c
method
(send a-pen get-width) -> (real-in 0 255)
method
(send a-pen is-immutable?) -> boolean?
method
(send a-pen set-cap cap-style) -> void?
  cap-style : pen-cap-style/c
method
(send a-pen set-color color) -> void?
  color : (is-a?/c color%)
(send a-pen set-color color-name) -> void?
  color-name : string?
(send a-pen set-color red green blue) -> void?
  red : byte?
  green : byte?
  blue : byte?
method
(send a-pen set-join join-style) -> void?
  join-style : pen-join-style/c
method
(send a-pen set-stipple bitmap) -> void?
  bitmap : (or/c (is-a?/c bitmap%) #f)
method
(send a-pen set-style style) -> void?
  style : pen-style/c
method
(send a-pen set-width width) -> void?
  width : (real-in 0 255)
class
pen-list% : class?
  superclass: object%
constructor
(new pen-list%) -> (is-a?/c pen-list%)
method
(send a-pen-list find-or-create-pen  color      
                                     width      
                                     style      
                                    [cap        
                                     join]) -> (is-a?/c pen%)
  color : (is-a?/c color%)
  width : (real-in 0 255)
  style : (or/c 'transparent 'solid 'xor 'hilite
                'dot 'long-dash 'short-dash 'dot-dash
                'xor-dot 'xor-long-dash 'xor-short-dash
                'xor-dot-dash)
  cap : (or/c 'round 'projecting 'butt) = 'round
  join : (or/c 'round 'bevel 'miter) = 'round
(send a-pen-list find-or-create-pen  color-name 
                                     width      
                                     style      
                                    [cap        
                                     join])     
 -> (or/c (is-a?/c pen%) #f)
  color-name : string?
  width : (real-in 0 255)
  style : (or/c 'transparent 'solid 'xor 'hilite
                'dot 'long-dash 'short-dash 'dot-dash
                'xor-dot 'xor-long-dash 'xor-short-dash
                'xor-dot-dash)
  cap : (or/c 'round 'projecting 'butt) = 'round
  join : (or/c 'round 'bevel 'miter) = 'round
class
point% : class?
  superclass: object%
constructor
(make-object point%) -> (is-a?/c point%)
(make-object point% x y) -> (is-a?/c point%)
  x : real?
  y : real?
method
(send a-point get-x) -> real?
method
(send a-point get-y) -> real?
method
(send a-point set-x x) -> void?
  x : real?
method
(send a-point set-y y) -> void?
  y : real?
class
post-script-dc% : class?
  superclass: object%
  extends: dc<%>
constructor
(new post-script-dc%                                  
                     [[interactive interactive]       
                      [parent parent]                 
                      [use-paper-bbox use-paper-bbox] 
                      [as-eps as-eps]                 
                      [width width]                   
                      [height height]                 
                      [output output]])               
 -> (is-a?/c post-script-dc%)
  interactive : any/c = #t
  parent : (or/c (is-a?/c frame%) (is-a?/c dialog%) #f) = #f
  use-paper-bbox : any/c = #f
  as-eps : any/c = #t
  width : (or/c (and/c real? (not/c negative?)) #f) = #f
  height : (or/c (and/c real? (not/c negative?)) #f) = #f
  output : (or/c path-string? output-port? #f) = #f
class
ps-setup% : class?
  superclass: object%
constructor
(new ps-setup%) -> (is-a?/c ps-setup%)
method
(send a-ps-setup copy-from  source               
                           [copy-filename?]) -> void?
  source : (is-a?/c ps-setup%)
  copy-filename? : any/c = #f
method
(send a-ps-setup get-command) -> string?
method
(send a-ps-setup get-editor-margin h-margin      
                                   v-margin) -> void?
  h-margin : (box/c (and/c real? (not/c negative?)))
  v-margin : (box/c (and/c real? (not/c negative?)))
method
(send a-ps-setup get-file) -> (or/c path-string? #f)
method
(send a-ps-setup get-level-2) -> boolean?
method
(send a-ps-setup get-margin h-margin      
                            v-margin) -> void?
  h-margin : (box/c (and/c real? (not/c negative?)))
  v-margin : (box/c (and/c real? (not/c negative?)))
method
(send a-ps-setup get-mode) -> (or/c 'preview 'file 'printer)
method
(send a-ps-setup get-orientation)
 -> (or/c 'portrait 'landscape)
method
(send a-ps-setup get-paper-name) -> string?
method
(send a-ps-setup get-preview-command) -> string?
method
(send a-ps-setup get-scaling x y) -> void?
  x : (box/c (and/c real? (not/c negative?)))
  y : (box/c (and/c real? (not/c negative?)))
method
(send a-ps-setup get-translation x y) -> void?
  x : (box/c (and/c real? (not/c negative?)))
  y : (box/c (and/c real? (not/c negative?)))
method
(send a-ps-setup set-command command) -> void?
  command : string?
method
(send a-ps-setup set-editor-margin h v) -> void?
  h : exact-nonnegative-integer?
  v : exact-nonnegative-integer?
method
(send a-ps-setup set-file filename) -> void?
  filename : (or/c path-string? #f)
method
(send a-ps-setup set-level-2 on?) -> void?
  on? : any/c
method
(send a-ps-setup set-margin h v) -> void?
  h : (and/c real? (not/c negative?))
  v : (and/c real? (not/c negative?))
method
(send a-ps-setup set-mode mode) -> void?
  mode : (or/c 'preview 'file 'printer)
method
(send a-ps-setup set-orientation orientation) -> void?
  orientation : (or/c 'portrait 'landscape)
method
(send a-ps-setup set-paper-name type) -> void?
  type : string?
method
(send a-ps-setup set-preview-command command) -> void?
  command : string?
method
(send a-ps-setup set-scaling x y) -> void?
  x : (and/c real? (not/c negative?))
  y : (and/c real? (not/c negative?))
method
(send a-ps-setup set-translation x y) -> void?
  x : real?
  y : real?
class
radial-gradient% : class?
  superclass: object%
constructor
(new radial-gradient%                
                      [x0 x0]        
                      [y0 y0]        
                      [r0 r0]        
                      [x1 x1]        
                      [y1 y1]        
                      [r1 r1]        
                      [stops stops]) 
 -> (is-a?/c radial-gradient%)
  x0 : real?
  y0 : real?
  r0 : real?
  x1 : real?
  y1 : real?
  r1 : real?
  stops : (listof (list/c (real-in 0 1) (is-a?/c color%)))
method
(send a-radial-gradient get-circles)
 -> real? real? real? real? real? real?
method
(send a-radial-gradient get-stops)
 -> (listof (list/c (real-in 0 1) (is-a?/c color%)))
class
record-dc% : class?
  superclass: object%
  extends: dc<%>
constructor
(new record-dc%                        
                [[width width]         
                 [height height]]) -> (is-a?/c record-dc%)
  width : (>=/c 0) = 640
  height : (>=/c 0) = 480
method
(send a-record-dc get-recorded-datum) -> any/c
method
(send a-record-dc get-recorded-procedure)
 -> ((is-a?/c dc<%>) . -> . void?)
class
region% : class?
  superclass: object%
constructor
(new region% [dc dc]) -> (is-a?/c region%)
  dc : (or/c (is-a?/c dc<%>) #f)
method
(send a-region get-bounding-box) -> real? real? real? real?
method
(send a-region get-dc) -> (or/c (is-a?/c dc<%>) #f)
method
(send a-region in-region? x y) -> boolean?
  x : real?
  y : real?
method
(send a-region intersect rgn) -> void?
  rgn : (is-a?/c region%)
method
(send a-region is-empty?) -> boolean?
method
(send a-region set-arc x                 
                       y                 
                       width             
                       height            
                       start-radians     
                       end-radians)  -> void?
  x : real?
  y : real?
  width : (and/c real? (not/c negative?))
  height : (and/c real? (not/c negative?))
  start-radians : real?
  end-radians : real?
method
(send a-region set-ellipse x y width height) -> void?
  x : real?
  y : real?
  width : (and/c real? (not/c negative?))
  height : (and/c real? (not/c negative?))
method
(send a-region set-path  path             
                        [xoffset          
                         yoffset          
                         fill-style]) -> void?
  path : (is-a?/c dc-path%)
  xoffset : real? = 0
  yoffset : real? = 0
  fill-style : (or/c 'odd-even 'winding) = 'odd-even
method
(send a-region set-polygon  points           
                           [xoffset          
                            yoffset          
                            fill-style]) -> void?
  points : (or/c (listof (is-a?/c point%))
                 (listof (cons/c real? real?)))
  xoffset : real? = 0
  yoffset : real? = 0
  fill-style : (or/c 'odd-even 'winding) = 'odd-even
method
(send a-region set-rectangle x           
                             y           
                             width       
                             height) -> void?
  x : real?
  y : real?
  width : (and/c real? (not/c negative?))
  height : (and/c real? (not/c negative?))
method
(send a-region set-rounded-rectangle  x            
                                      y            
                                      width        
                                      height       
                                     [radius]) -> void?
  x : real?
  y : real?
  width : (and/c real? (not/c negative?))
  height : (and/c real? (not/c negative?))
  radius : real? = -0.25
method
(send a-region subtract rgn) -> void?
  rgn : (is-a?/c region%)
method
(send a-region union rgn) -> void?
  rgn : (is-a?/c region%)
method
(send a-region xor rgn) -> void?
  rgn : (is-a?/c region%)
class
svg-dc% : class?
  superclass: object%
  extends: dc<%>
constructor
(new svg-dc%                        
              [width width]         
              [height height]       
              [output output]       
             [[exists exists]]) -> (is-a?/c svg-dc%)
  width : (and/c real? (not/c negative?))
  height : (and/c real? (not/c negative?))
  output : (or/c path-string? output-port?)
  exists : (or/c 'error 'append 'update 'can-update = 'error
                 'replace 'truncate
                 'must-truncate 'truncate/replace)
parameter
(current-ps-setup) -> (is-a?/c ps-setup%)
(current-ps-setup pss) -> void?
  pss : (is-a?/c ps-setup%)
procedure
(get-face-list [kind                            
                #:all-variants? all-variants?]) 
 -> (listof string?)
  kind : (or/c 'mono 'all) = 'all
  all-variants? : any/c = #f
procedure
(get-family-builtin-face family) -> string?
  family : (or/c 'default 'decorative 'roman 'script
                 'swiss 'modern 'symbol 'system)
procedure
(make-bitmap  width                               
              height                              
             [alpha?                              
              #:backing-scale backing-scale]) -> (is-a?/c bitmap%)
  width : exact-positive-integer?
  height : exact-positive-integer?
  alpha? : any/c = #t
  backing-scale : (>/c 0.0) = 1.0
procedure
(make-brush [#:color color                       
             #:style style                       
             #:stipple stipple                   
             #:gradient gradient                 
             #:transformation transformation     
             #:immutable? immutable?])       -> (is-a?/c brush%)
  color : (or/c string? (is-a?/c color%)) = (make-color 0 0 0)
  style : (or/c 'transparent 'solid 'opaque        = 'solid
                'xor 'hilite 'panel
                'bdiagonal-hatch 'crossdiag-hatch
                'fdiagonal-hatch 'cross-hatch
                'horizontal-hatch 'vertical-hatch)
  stipple : (or/c #f (is-a?/c bitmap%)) = #f
  gradient : (or/c #f                         = #f
                  (is-a?/c linear-gradient%)
                  (is-a?/c radial-gradient%))
  transformation : (or/c #f (vector/c (vector/c real? real? real?
                                                real? real? real?)
                                       real? real? real? real? real?))
                 = #f
  immutable? : any/c = #t
procedure
(make-color red green blue [alpha]) -> (is-a?/c color%)
  red : byte?
  green : byte?
  blue : byte?
  alpha : (real-in 0 1) = 1.0
procedure
(make-font [#:size size                           
            #:face face                           
            #:family family                       
            #:style style                         
            #:weight weight                       
            #:underlined? underlined?             
            #:smoothing smoothing                 
            #:size-in-pixels? size-in-pixels?     
            #:hinting hinting])               -> (is-a?/c font%)
  size : (real-in 0.0 1024.0) = 12
  face : (or/c string? #f) = #f
  family : (or/c 'default 'decorative 'roman 'script = 'default
                 'swiss 'modern 'symbol 'system)
  style : (or/c 'normal 'italic 'slant) = 'normal
  weight : (or/c 'normal 'bold 'light) = 'normal
  underlined? : any/c = #f
  smoothing : (or/c 'default 'partly-smoothed = 'default
                    'smoothed 'unsmoothed)
  size-in-pixels? : any/c = #f
  hinting : (or/c 'aligned 'unaligned) = 'aligned
procedure
(make-monochrome-bitmap width height [bits]) -> (is-a?/c bitmap%)
  width : exact-positive-integer?
  height : exact-positive-integer?
  bits : (or/c bytes? #f) = #f
procedure
(make-pen [#:color color                 
           #:width width                 
           #:style style                 
           #:cap cap                     
           #:join join                   
           #:stipple stipple             
           #:immutable? immutable?]) -> (is-a?/c pen%)
  color : (or/c string? (is-a?/c color%)) = (make-color 0 0 0)
  width : (real-in 0 255) = 0
  style : (or/c 'transparent 'solid 'xor 'hilite        = 'solid
                'dot 'long-dash 'short-dash 'dot-dash
                'xor-dot 'xor-long-dash 'xor-short-dash
                'xor-dot-dash)
  cap : (or/c 'round 'projecting 'butt) = 'round
  join : (or/c 'round 'bevel 'miter) = 'round
  stipple : (or/c #f (is-a?/c bitmap%)) = #f
  immutable? : any/c = #t
procedure
(make-platform-bitmap  width                           
                       height                          
                      [#:backing-scale backing-scale]) 
 -> (is-a?/c bitmap%)
  width : exact-positive-integer?
  height : exact-positive-integer?
  backing-scale : (>/c 0.0) = 1.0
procedure
(read-bitmap  in                                
             [kind                              
              bg-color                          
              complain-on-failure?              
              #:backing-scale backing-scale     
              #:try-@2x? try-@2x?])         -> (is-a?/c bitmap%)
  in : (or path-string? input-port?)
  kind : (or/c 'unknown 'unknown/mask 'unknown/alpha
               'gif 'gif/mask 'gif/alpha
               'jpeg 'jpeg/alpha
               'png 'png/mask 'png/alpha
               'xbm 'xbm/alpha 'xpm 'xpm/alpha
               'bmp 'bmp/alpha)
       = 'unknown/alpha
  bg-color : (or/c (is-a?/c color%) #f) = #f
  complain-on-failure? : any/c = #t
  backing-scale : (>/c 0.0) = 1.0
  try-@2x? : any/c = #f
procedure
(recorded-datum->procedure datum)
 -> ((is-a?/c dc<%>) . -> . void?)
  datum : any/c
value
the-brush-list : (is-a?/c brush-list%)
value
the-color-database : (is-a?/c color-database<%>)
value
the-font-list : (is-a?/c font-list%)
value
the-font-name-directory : (is-a?/c font-name-directory<%>)
value
the-pen-list : (is-a?/c pen-list%)
value
font-family/c : flat-contract?
value
font-style/c : flat-contract?
value
font-weight/c : flat-contract?
value
font-smoothing/c : flat-contract?
value
font-hinting/c : flat-contract?
value
pen-style/c : flat-contract?
value
pen-cap-style/c : flat-contract?
value
pen-join-style/c : flat-contract?
value
brush-style/c : flat-contract?
value
draw@ : unit?
signature
draw^ : signature
procedure
(make-handle-brush  handle              
                    width               
                    height              
                    transformation      
                   [#:copy? copy?]) -> (is-a?/c brush%)
  handle : cpointer?
  width : exact-nonnegative-integer?
  height : exact-nonnegative-integer?
  transformation : (or/c #f (vector/c (vector/c real? real? real?
                                                real? real? real?)
                                      real? real? real? real? real?))
  copy? : any/c = #t
value
cairo-lib : (or/c ffi-lib? #f)
