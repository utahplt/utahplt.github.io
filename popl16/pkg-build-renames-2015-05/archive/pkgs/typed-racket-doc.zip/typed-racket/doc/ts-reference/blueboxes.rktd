19991
((3) 0 () 9 ((q lib "typed/racket/class.rkt") (q lib "typed-racket/base-env/base-types.rkt") (q lib "typed-racket/base-env/prims.rkt") (q lib "typed-racket/base-env/base-types-extra.rkt") (q lib "typed-racket/typed-racket.rkt") (q lib "typed/scheme/base.rkt") (q lib "typed-racket/base-env/extra-procs.rkt") (q lib "typed/racket/base.rkt") (q lib "typed/untyped-utils.rkt")) () (h ! (equal) ((c form c (c (? . 0) q define/pubment)) q (15756 . 3)) ((c form c (c (? . 1) q Thread)) q (2880 . 2)) ((c form c (c (? . 7) q values)) q (20845 . 2)) ((c form c (c (? . 0) q private)) q (16330 . 2)) ((c form c (c (? . 1) q Exact-Number)) q (172 . 2)) ((c form c (c (? . 2) q let/cc:)) q (19594 . 2)) ((c form c (c (? . 2) q for/hasheq)) q (8292 . 2)) ((c form c (c (? . 2) q λ)) q (7709 . 2)) ((c form c (c (? . 1) q Positive-Index)) q (1611 . 2)) ((c form c (c (? . 2) q for*/hasheqv)) q (9293 . 2)) ((c form c (c (? . 5) q require-typed-struct)) q (21306 . 2)) ((c form c (c (? . 1) q Struct-Type-Property)) q (2613 . 2)) ((c form c (c (? . 1) q Inexact-Real-Nan)) q (1293 . 2)) ((c form c (c (? . 1) q Sexp)) q (3921 . 2)) ((c form c (c (? . 1) q Inspector)) q (2752 . 2)) ((c form c (c (? . 2) q :type)) q (17956 . 5)) ((c form c (c (? . 2) q :query-type/result)) q (18101 . 2)) ((c form c (c (? . 1) q Nonpositive-Real)) q (1513 . 2)) ((c form c (c (? . 1) q Prompt-TagTop)) q (3974 . 2)) ((c form c (c (? . 2) q for*/or)) q (9638 . 2)) ((c form c (c (? . 0) q field)) q (16062 . 2)) ((c def c (c (? . 2) q index?)) q (17479 . 3)) ((c form c (c (? . 1) q Undefined)) q (2373 . 2)) ((c form c (c (? . 1) q Pretty-Print-Style-Table)) q (2558 . 2)) ((c form c (c (? . 1) q Positive-Exact-Rational)) q (1317 . 2)) ((c form c (c (? . 1) q VectorTop)) q (3393 . 2)) ((c form c (c (? . 2) q define-typed-struct/exec)) q (21390 . 2)) ((c form c (c (? . 1) q Prompt-Tagof)) q (3946 . 2)) ((c form c (c (? . 0) q inherit-field)) q (16094 . 2)) ((c form c (c (? . 0) q init-rest)) q (16134 . 2)) ((c form c (c (? . 2) q for/and)) q (8635 . 2)) ((c form c (c (? . 1) q Boolean)) q (1977 . 2)) ((c form c (c (? . 2) q for/hasheqv)) q (8359 . 2)) ((c form c (c (? . 3) q Struct-Type)) q (6108 . 2)) ((c form c (c (? . 1) q Bytes)) q (2241 . 2)) ((c form c (c (? . 3) q List)) q (3113 . 2)) ((c form c (c (? . 1) q Bytes-Converter)) q (2688 . 2)) ((c form c (c (? . 2) q for*/hash:)) q (20088 . 2)) ((c form c (c (? . 1) q Exact-Nonnegative-Integer)) q (346 . 2)) ((c form c (c (? . 2) q for*/fold:)) q (20070 . 2)) ((c form c (c (? . 1) q Negative-Single-Flonum)) q (894 . 2)) ((c form c (c (? . 1) q Nonnegative-Inexact-Real)) q (1107 . 2)) ((c form c (c (? . 2) q let/ec:)) q (19628 . 2)) ((c form c (c (? . 2) q require/typed/provide)) q (13401 . 2)) ((c form c (c (? . 2) q require-typed-struct/provide)) q (20714 . 2)) ((c form c (c (? . 1) q Compiled-Module-Expression)) q (2462 . 2)) ((c form c (c (? . 2) q for*/hasheq:)) q (20106 . 2)) ((c form c (c (? . 2) q letrec:)) q (19323 . 2)) ((c form c (c (? . 2) q for*/first:)) q (20004 . 2)) ((c form c (c (? . 1) q HashTable)) q (3410 . 2)) ((c form c (c (? . 2) q for/sum)) q (8897 . 2)) ((c form c (c (? . 2) q struct:)) q (19911 . 2)) ((c form c (c (? . 2) q for*/list:)) q (20165 . 2)) ((c form c (c (? . 1) q Async-ChannelTop)) q (3541 . 2)) ((c form c (c (? . 1) q Keyword)) q (2031 . 2)) ((c form c (c (? . 2) q for*/vector:)) q (20273 . 2)) ((c form c (c (? . 1) q Option)) q (6224 . 2)) ((c form c (c (? . 2) q for*/hasheqv:)) q (20126 . 2)) ((c form c (c (? . 1) q Struct-TypeTop)) q (6133 . 2)) ((c form c (c (? . 2) q for*/or:)) q (20219 . 2)) ((c form c (c (? . 2) q for*/hasheq)) q (9225 . 2)) ((c form c (c (? . 1) q Positive-Float)) q (457 . 2)) ((c form c (c (? . 1) q Weak-BoxTop)) q (3772 . 2)) ((c form c (c (? . 1) q Flonum-Positive-Zero)) q (731 . 2)) ((c form c (c (? . 2) q for*/flvector:)) q (20023 . 2)) ((c form c (c (? . 3) q Values)) q (6007 . 2)) ((c form c (c (? . 1) q Nonpositive-Inexact-Real)) q (1168 . 2)) ((c form c (c (? . 1) q Nonpositive-Fixnum)) q (1719 . 2)) ((c form c (c (? . 1) q Flonum)) q (83 . 2)) ((c form c (c (? . 4) q let*-values:)) q (19534 . 2)) ((c form c (c (? . 1) q Nonnegative-Exact-Rational)) q (1348 . 2)) ((c form c (c (? . 2) q for*/fold)) q (10388 . 4)) ((c form c (c (? . 2) q struct)) q (11604 . 12)) ((c form c (c (? . 2) q for*/last)) q (9773 . 2)) ((c form c (c (? . 1) q Syntax)) q (3872 . 2)) ((c form c (c (? . 2) q let)) q (6262 . 13)) ((c form c (c (? . 2) q for/flvector:)) q (20340 . 2)) ((c form c (c (? . 4) q for*/extflvector)) q (9500 . 2)) ((c form c (c (? . 1) q Exact-Rational)) q (138 . 2)) ((c form c (c (? . 3) q pred)) q (20766 . 2)) ((c form c (c (? . 1) q Flonum-Zero)) q (777 . 2)) ((c form c (c (? . 1) q Parameterization)) q (2711 . 2)) ((c form c (c (? . 1) q Index)) q (1598 . 2)) ((c form c (c (? . 2) q for/list)) q (8162 . 2)) ((c form c (c (? . 1) q Nonnegative-Flonum)) q (527 . 2)) ((c form c (c (? . 2) q let*:)) q (19369 . 2)) ((c form c (c (? . 3) q Instance)) q (17171 . 2)) ((c form c (c (? . 1) q Single-Flonum-Zero)) q (1027 . 2)) ((c form c (c (? . 3) q ∀)) q (6213 . 2)) ((c form c (c (? . 2) q lambda:)) q (18429 . 6)) ((c form c (c (? . 1) q Namespace)) q (2254 . 2)) ((c form c (c (? . 3) q Class)) q (16403 . 17)) ((c form c (c (? . 1) q MPairof)) q (3226 . 2)) ((c form c (c (? . 2) q define-struct:)) q (19926 . 2)) ((c form c (c (? . 1) q Path-String)) q (3053 . 2)) ((c form c (c (? . 1) q PRegexp)) q (2187 . 2)) ((c form c (c (? . 2) q for/hasheq:)) q (20419 . 2)) ((c form c (c (? . 2) q for/first:)) q (20322 . 2)) ((c form c (c (? . 1) q Exact-Positive-Integer)) q (289 . 2)) ((c form c (c (? . 2) q typecheck-fail)) q (17531 . 8)) ((c form c (c (? . 1) q Nonpositive-Float)) q (598 . 2)) ((c form c (c (? . 1) q Negative-Inexact-Real)) q (1139 . 2)) ((c form c (c (? . 3) q Struct)) q (6088 . 2)) ((c form c (c (? . 1) q Pseudo-Random-Generator)) q (3022 . 2)) ((c form c (c (? . 1) q Char)) q (2060 . 2)) ((c form c (c (? . 1) q Nonnegative-Fixnum)) q (1670 . 2)) ((c form c (c (? . 2) q for*/hash)) q (9159 . 2)) ((c form c (c (? . 1) q Path-For-Some-System)) q (2145 . 2)) ((c form c (c (? . 2) q let-values)) q (6677 . 2)) ((c form c (c (? . 3) q Un)) q (20783 . 2)) ((c form c (c (? . 1) q Place)) q (2932 . 2)) ((c form c (c (? . 2) q for/sum:)) q (20561 . 2)) ((c form c (c (? . 1) q Sequenceof)) q (3650 . 2)) ((c form c (c (? . 1) q ExtFlonum-Negative-Zero)) q (1872 . 2)) ((c form c (c (? . 2) q define)) q (10674 . 30)) ((c form c (c (? . 2) q for*/last:)) q (20147 . 2)) ((c form c (c (? . 1) q UDP-Socket)) q (2791 . 2)) ((c form c (c (? . 2) q ann)) q (12678 . 2)) ((c def c (c (? . 2) q default-continuation-prompt-tag)) q (13472 . 3)) ((c form c (c (? . 1) q Impersonator-Property)) q (2641 . 2)) ((c form c (c (? . 1) q MListof)) q (3206 . 2)) ((c form c (c (? . 1) q Null)) q (2321 . 2)) ((c form c (c (? . 4) q for/flvector)) q (8494 . 2)) ((c form c (c (? . 1) q Continuation-Mark-KeyTop)) q (4031 . 2)) ((c form c (c (? . 2) q pdefine:)) q (20750 . 2)) ((c form c (c (? . 1) q Float-Zero)) q (759 . 2)) ((c form c (c (? . 1) q Any)) q (0 . 2)) ((c form c (c (? . 1) q Flonum-Nan)) q (813 . 2)) ((c form c (c (? . 2) q for/hash:)) q (20402 . 2)) ((c form c (c (? . 0) q define/public)) q (15596 . 3)) ((c form c (c (? . 1) q Positive-Inexact-Real)) q (1078 . 2)) ((c form c (c (? . 2) q define-type-alias)) q (20607 . 2)) ((c form c (c (? . 3) q Top)) q (5843 . 2)) ((c form c (c (? . 2) q for/product:)) q (20541 . 2)) ((c form c (c (? . 1) q Single-Flonum-Complex)) q (213 . 2)) ((c form c (c (? . 2) q for/fold)) q (10129 . 4)) ((c form c (c (? . 1) q Integer)) q (55 . 2)) ((c form c (c (? . 2) q λ:)) q (18588 . 2)) ((c form c (c (? . 5) q require/typed)) q (20859 . 12)) ((c form c (c (? . 1) q MPairTop)) q (3249 . 2)) ((c form c (c (? . 1) q Inexact-Real-Negative-Zero)) q (1200 . 2)) ((c form c (c (? . 1) q Positive-Fixnum)) q (1647 . 2)) ((c form c (c (? . 1) q Setof)) q (3455 . 2)) ((c form c (c (? . 1) q Continuation-Mark-Keyof)) q (3995 . 2)) ((c form c (c (? . 1) q Syntax-E)) q (3886 . 2)) ((c form c (c (? . 1) q Positive-Integer)) q (265 . 2)) ((c form c (c (? . 2) q let-values:)) q (19413 . 2)) ((c form c (c (? . 2) q provide:)) q (12629 . 2)) ((c form c (c (? . 2) q case-lambda)) q (7738 . 2)) ((c form c (c (? . 1) q Nonpositive-Single-Flonum)) q (924 . 2)) ((c form c (c (? . 1) q Procedure)) q (5865 . 2)) ((c form c (c (? . 2) q for)) q (7794 . 14)) ((c form c (c (? . 1) q Positive-Byte)) q (1577 . 2)) ((c form c (c (? . 1) q Security-Guard)) q (2769 . 2)) ((c form c (c (? . 1) q Special-Comment)) q (2590 . 2)) ((c form c (c (? . 1) q FSemaphore)) q (2983 . 2)) ((c form c (c (? . 1) q Nonpositive-Flonum)) q (623 . 2)) ((c form c (c (? . 1) q Listof)) q (3094 . 2)) ((c form c (c (? . 2) q for/set)) q (9029 . 2)) ((c form c (c (? . 4) q #%top-interaction)) q (13599 . 2)) ((c form c (c (? . 1) q Negative-Fixnum)) q (1696 . 2)) ((c def c (c (? . 6) q assert)) q (17206 . 6)) ((c form c (c (? . 0) q define/augment)) q (15836 . 3)) ((c form c (c (? . 1) q Resolved-Module-Path)) q (2434 . 2)) ((c form c (c (? . 1) q FlVector)) q (3342 . 2)) ((c form c (c (? . 1) q Thread-CellTop)) q (3727 . 2)) ((c form c (c (? . 2) q with-asserts)) q (17321 . 5)) ((c form c (c (? . 1) q Pair)) q (20833 . 2)) ((c form c (c (? . 0) q class)) q (13634 . 45)) ((c form c (c (? . 1) q Single-Flonum-Nan)) q (1053 . 2)) ((c form c (c (? . 1) q Read-Table)) q (2670 . 2)) ((c form c (c (? . 2) q for/product)) q (8961 . 2)) ((c form c (c (? . 1) q Void)) q (2072 . 2)) ((c form c (c (? . 1) q Complex)) q (40 . 2)) ((c form c (c (? . 1) q Nonnegative-ExtFlonum)) q (1788 . 2)) ((c form c (c (? . 1) q Negative-Flonum)) q (575 . 2)) ((c form c (c (? . 1) q False)) q (2004 . 2)) ((c form c (c (? . 0) q define/private)) q (15916 . 3)) ((c form c (c (? . 1) q Positive-Flonum)) q (479 . 2)) ((c form c (c (? . 1) q Float-Complex)) q (192 . 2)) ((c form c (c (? . 1) q Nothing)) q (11 . 2)) ((c form c (c (? . 1) q ExtFlonum-Zero)) q (1934 . 2)) ((c form c (c (? . 3) q case→)) q (6198 . 2)) ((c form c (c (? . 1) q Thread-Cellof)) q (3701 . 2)) ((c form c (c (? . 2) q for*/lists:)) q (20183 . 2)) ((c form c (c (? . 3) q Tuple)) q (20803 . 2)) ((c form c (c (? . 2) q for/and:)) q (20306 . 2)) ((c form c (c (? . 2) q for/first)) q (8766 . 2)) ((c form c (c (? . 4) q for/extflvector)) q (8563 . 2)) ((c form c (c (? . 2) q do:)) q (20596 . 2)) ((c form c (c (? . 1) q Negative-Exact-Rational)) q (1382 . 2)) ((c form c (c (? . 1) q ExtFlonum-Positive-Zero)) q (1903 . 2)) ((c form c (c (? . 2) q pcase-lambda:)) q (19066 . 3)) ((c form c (c (? . 2) q letrec)) q (6599 . 2)) ((c form c (c (? . 2) q with-handlers)) q (13451 . 2)) ((c form c (c (? . 2) q for*/sum)) q (9839 . 2)) ((c form c (c (? . 1) q ExtFlVector)) q (3358 . 2)) ((c form c (c (? . 1) q One)) q (1554 . 2)) ((c form c (c (? . 1) q ExtFlonum)) q (1745 . 2)) ((c form c (c (? . 2) q :query-type/args)) q (18064 . 2)) ((c form c (c (? . 1) q EOF)) q (2333 . 2)) ((c form c (c (? . 3) q All)) q (5954 . 3)) ((c form c (c (? . 2) q require/typed)) q (12855 . 15)) ((c form c (c (? . 1) q Evtof)) q (3815 . 2)) ((c form c (c (? . 4) q with-type)) q (18135 . 10)) ((c form c (c (? . 1) q Positive-Single-Flonum)) q (831 . 2)) ((c form c (c (? . 1) q Log-Level)) q (2863 . 2)) ((c form c (c (? . 3) q Prefab)) q (6155 . 2)) ((c form c (c (? . 2) q require-typed-struct)) q (20686 . 2)) ((c form c (c (? . 1) q Real-Zero)) q (1537 . 2)) ((c form c (c (? . 2) q for*)) q (10232 . 3)) ((c form c (c (? . 1) q Continuation-Mark-Set)) q (2344 . 2)) ((c form c (c (? . 2) q let/cc)) q (6852 . 2)) ((c form c (c (? . 1) q Flonum-Negative-Zero)) q (676 . 2)) ((c form c (c (? . 0) q pubment)) q (16203 . 2)) ((c form c (c (? . 3) q Bot)) q (5854 . 2)) ((c form c (c (? . 2) q :)) q (12599 . 3)) ((c form c (c (? . 2) q let/ec)) q (6885 . 2)) ((c form c (c (? . 1) q Log-Receiver)) q (2843 . 2)) ((c form c (c (? . 2) q let:)) q (19177 . 3)) ((c form c (c (? . 2) q for/list:)) q (20475 . 2)) ((c form c (c (? . 1) q Single-Flonum)) q (97 . 2)) ((c form c (c (? . 1) q Fixnum)) q (1633 . 2)) ((c form c (c (? . 2) q for/lists)) q (10038 . 4)) ((c form c (c (? . 2) q for/vector:)) q (20577 . 2)) ((c form c (c (? . 2) q for/last:)) q (20458 . 2)) ((c form c (c (? . 2) q for*/product:)) q (20235 . 2)) ((c form c (c (? . 1) q Positive-ExtFlonum)) q (1762 . 2)) ((c form c (c (? . 1) q Identifier)) q (3854 . 2)) ((c form c (c (? . 2) q let*)) q (6639 . 2)) ((c form c (c (? . 1) q Will-Executor)) q (3001 . 2)) ((c form c (c (? . 2) q define-predicate)) q (12564 . 2)) ((c form c (c (? . 1) q Compiled-Expression)) q (2496 . 2)) ((c form c (c (? . 2) q letrec-values)) q (6734 . 2)) ((c form c (c (? . 2) q for*/set:)) q (20202 . 2)) ((c form c (c (? . 1) q Real)) q (160 . 2)) ((c form c (c (? . 3) q →)) q (6187 . 2)) ((c form c (c (? . 1) q True)) q (1992 . 2)) ((c form c (c (? . 1) q ExtFlonum-Nan)) q (1956 . 2)) ((c form c (c (? . 3) q ->)) q (4063 . 45)) ((c form c (c (? . 2) q for/hash)) q (8227 . 2)) ((c form c (c (? . 2) q make-predicate)) q (12537 . 2)) ((c form c (c (? . 1) q TCP-Listener)) q (2809 . 2)) ((c form c (c (? . 1) q Custodian-Boxof)) q (3673 . 2)) ((c form c (c (? . 1) q Internal-Definition-Context)) q (2523 . 2)) ((c form c (c (? . 1) q Datum)) q (3933 . 2)) ((c form c (c (? . 2) q for/vector)) q (8427 . 2)) ((c form c (c (? . 1) q Promise)) q (3609 . 2)) ((c form c (c (? . 3) q Refinement)) q (21366 . 2)) ((c form c (c (? . 1) q Futureof)) q (3629 . 2)) ((c form c (c (? . 2) q for/set:)) q (20510 . 2)) ((c def c (c (? . 6) q defined?)) q (17425 . 3)) ((c form c (c (? . 2) q define:)) q (19662 . 7)) ((c form c (c (? . 2) q plambda:)) q (18618 . 3)) ((c form c (c (? . 1) q Port)) q (2121 . 2)) ((c form c (c (? . 2) q define-struct/exec)) q (12251 . 5)) ((c def c (c (? . 8) q syntax-local-typed-context?)) q (17902 . 2)) ((c form c (c (? . 2) q do)) q (10492 . 7)) ((c form c (c (? . 1) q Symbol)) q (2046 . 2)) ((c form c (c (? . 1) q Nonpositive-ExtFlonum)) q (1843 . 2)) ((c form c (c (? . 2) q for*/product)) q (9904 . 2)) ((c form c (c (? . 3) q Parameter)) q (20816 . 2)) ((c form c (c (? . 1) q Channelof)) q (3473 . 2)) ((c form c (c (? . 1) q Input-Port)) q (2084 . 2)) ((c form c (c (? . 1) q Float-Nan)) q (796 . 2)) ((c form c (c (? . 3) q Parameterof)) q (3565 . 3)) ((c form c (c (? . 1) q Natural)) q (379 . 2)) ((c form c (c (? . 2) q case-lambda:)) q (19046 . 2)) ((c form c (c (? . 1) q Negative-Real)) q (1492 . 2)) ((c form c (c (? . 2) q for*/vector)) q (9362 . 2)) ((c form c (c (? . 2) q for*/first)) q (9706 . 2)) ((c form c (c (? . 2) q for*/and:)) q (19987 . 2)) ((c form c (c (? . 3) q case->)) q (5901 . 2)) ((c form c (c (? . 7) q define-type)) q (12376 . 6)) ((c form c (c (? . 0) q public)) q (16162 . 2)) ((c form c (c (? . 2) q for/last)) q (8832 . 2)) ((c form c (c (? . 2) q popt-lambda:)) q (18947 . 3)) ((c form c (c (? . 1) q Module-Path)) q (2390 . 2)) ((c form c (c (? . 2) q for/hasheqv:)) q (20438 . 2)) ((c form c (c (? . 2) q declare-refinement)) q (21334 . 2)) ((c form c (c (? . 8) q require/untyped-contract)) q (17696 . 5)) ((c form c (c (? . 1) q HashTableTop)) q (3435 . 2)) ((c form c (c (? . 0) q init-field)) q (16026 . 2)) ((c form c (c (? . 1) q Place-Channel)) q (2945 . 2)) ((c form c (c (? . 1) q Byte-Regexp)) q (2202 . 2)) ((c form c (c (? . 2) q cast)) q (12716 . 2)) ((c form c (c (? . 0) q augment)) q (16288 . 2)) ((c form c (c (? . 0) q init)) q (15996 . 2)) ((c form c (c (? . 1) q Byte-PRegexp)) q (2221 . 2)) ((c form c (c (? . 1) q FxVector)) q (3377 . 2)) ((c form c (c (? . 3) q ->*)) q (5489 . 14)) ((c form c (c (? . 2) q lambda)) q (6918 . 26)) ((c form c (c (? . 8) q define-typed/untyped-identifier)) q (17829 . 2)) ((c form c (c (? . 1) q Number)) q (26 . 2)) ((c form c (c (? . 1) q Async-Channelof)) q (3513 . 2)) ((c form c (c (? . 1) q Inexact-Real-Zero)) q (1268 . 2)) ((c form c (c (? . 1) q Namespace-Anchor)) q (2271 . 2)) ((c form c (c (? . 1) q Inexact-Complex)) q (242 . 2)) ((c form c (c (? . 2) q define-struct)) q (11938 . 11)) ((c form c (c (? . 1) q Float)) q (70 . 2)) ((c form c (c (? . 1) q Logger)) q (2829 . 2)) ((c form c (c (? . 1) q Pairof)) q (3072 . 2)) ((c form c (c (? . 2) q plet:)) q (19269 . 2)) ((c form c (c (? . 2) q require/opaque-type)) q (20659 . 2)) ((c form c (c (? . 1) q Ephemeronof)) q (3791 . 2)) ((c form c (c (? . 2) q for:)) q (19975 . 2)) ((c form c (c (? . 1) q Negative-ExtFlonum)) q (1817 . 2)) ((c form c (c (? . 2) q for/extflvector:)) q (20361 . 2)) ((c form c (c (? . 1) q Weak-Boxof)) q (3749 . 2)) ((c form c (c (? . 1) q Module-Path-Index)) q (2409 . 2)) ((c form c (c (? . 0) q define/override)) q (15674 . 3)) ((c form c (c (? . 0) q inherit)) q (16361 . 2)) ((c form c (c (? . 2) q for*/and)) q (9573 . 2)) ((c form c (c (? . 1) q Single-Flonum-Positive-Zero)) q (992 . 2)) ((c form c (c (? . 2) q inst)) q (12736 . 3)) ((c form c (c (? . 4) q #%module-begin)) q (13564 . 2)) ((c form c (c (? . 1) q Nonnegative-Float)) q (502 . 2)) ((c form c (c (? . 3) q Opaque)) q (6243 . 2)) ((c form c (c (? . 1) q Float-Positive-Zero)) q (704 . 2)) ((c form c (c (? . 2) q for/or)) q (8699 . 2)) ((c form c (c (? . 2) q opt-lambda:)) q (18709 . 6)) ((c form c (c (? . 2) q for*:)) q (20293 . 2)) ((c form c (c (? . 2) q for*/list)) q (9093 . 2)) ((c form c (c (? . 1) q Inexact-Real)) q (118 . 2)) ((c form c (c (? . 1) q Nonnegative-Real)) q (1468 . 2)) ((c form c (c (? . 1) q Output-Port)) q (2102 . 2)) ((c form c (c (? . 1) q Custodian)) q (2735 . 2)) ((c form c (c (? . 1) q Negative-Integer)) q (394 . 2)) ((c form c (c (? . 1) q Nonpositive-Exact-Rational)) q (1413 . 2)) ((c form c (c (? . 2) q for/or:)) q (20526 . 2)) ((c form c (c (? . 0) q override)) q (16245 . 2)) ((c form c (c (? . 1) q Single-Flonum-Negative-Zero)) q (957 . 2)) ((c form c (c (? . 1) q Vectorof)) q (3297 . 2)) ((c form c (c (? . 3) q Vector)) q (3318 . 2)) ((c form c (c (? . 1) q String)) q (2017 . 2)) ((c form c (c (? . 2) q define-typed-struct)) q (20632 . 2)) ((c form c (c (? . 7) q let*-values)) q (6794 . 2)) ((c form c (c (? . 1) q Sexpof)) q (3902 . 2)) ((c form c (c (? . 1) q Thread-Group)) q (2894 . 2)) ((c form c (c (? . 2) q for*/lists)) q (10296 . 4)) ((c form c (c (? . 2) q letrec-values:)) q (19472 . 2)) ((c form c (c (? . 2) q for*/set)) q (9973 . 2)) ((c form c (c (? . 1) q Float-Negative-Zero)) q (649 . 2)) ((c form c (c (? . 1) q BoxTop)) q (3283 . 2)) ((c form c (c (? . 1) q Byte)) q (1565 . 2)) ((c form c (c (? . 2) q for*/extflvector:)) q (20045 . 2)) ((c form c (c (? . 1) q Inexact-Real-Positive-Zero)) q (1234 . 2)) ((c form c (c (? . 3) q Rec)) q (6069 . 2)) ((c form c (c (? . 1) q Syntaxof)) q (3833 . 2)) ((c form c (c (? . 2) q :print-type)) q (18040 . 2)) ((c form c (c (? . 1) q Semaphore)) q (2966 . 2)) ((c form c (c (? . 3) q List*)) q (3176 . 2)) ((c form c (c (? . 2) q for/fold:)) q (20385 . 2)) ((c form c (c (? . 3) q mu)) q (20793 . 2)) ((c form c (c (? . 1) q Nonpositive-Integer)) q (418 . 2)) ((c form c (c (? . 1) q ChannelTop)) q (3495 . 2)) ((c form c (c (? . 1) q Nonnegative-Integer)) q (319 . 2)) ((c form c (c (? . 1) q Regexp)) q (2173 . 2)) ((c form c (c (? . 4) q for*/flvector)) q (9430 . 2)) ((c form c (c (? . 3) q Object)) q (17046 . 5)) ((c form c (c (? . 1) q Nonnegative-Single-Flonum)) q (861 . 2)) ((c form c (c (? . 1) q Path)) q (2133 . 2)) ((c form c (c (? . 1) q Zero)) q (445 . 2)) ((c form c (c (? . 1) q Boxof)) q (3265 . 2)) ((c form c (c (? . 1) q Positive-Real)) q (1447 . 2)) ((c form c (c (? . 3) q U)) q (5882 . 2)) ((c form c (c (? . 1) q Variable-Reference)) q (2295 . 2)) ((c form c (c (? . 1) q Subprocess)) q (2914 . 2)) ((c form c (c (? . 2) q for/lists:)) q (20492 . 2)) ((c form c (c (? . 1) q ClassTop)) q (17030 . 2)) ((c form c (c (? . 2) q for*/sum:)) q (20256 . 2)) ((c form c (c (? . 1) q Negative-Float)) q (553 . 2)) ((c form c (c (? . 2) q define-struct/exec:)) q (19948 . 2))))
syntax
Any
syntax
Nothing
syntax
Number
syntax
Complex
syntax
Integer
syntax
Float
syntax
Flonum
syntax
Single-Flonum
syntax
Inexact-Real
syntax
Exact-Rational
syntax
Real
syntax
Exact-Number
syntax
Float-Complex
syntax
Single-Flonum-Complex
syntax
Inexact-Complex
syntax
Positive-Integer
syntax
Exact-Positive-Integer
syntax
Nonnegative-Integer
syntax
Exact-Nonnegative-Integer
syntax
Natural
syntax
Negative-Integer
syntax
Nonpositive-Integer
syntax
Zero
syntax
Positive-Float
syntax
Positive-Flonum
syntax
Nonnegative-Float
syntax
Nonnegative-Flonum
syntax
Negative-Float
syntax
Negative-Flonum
syntax
Nonpositive-Float
syntax
Nonpositive-Flonum
syntax
Float-Negative-Zero
syntax
Flonum-Negative-Zero
syntax
Float-Positive-Zero
syntax
Flonum-Positive-Zero
syntax
Float-Zero
syntax
Flonum-Zero
syntax
Float-Nan
syntax
Flonum-Nan
syntax
Positive-Single-Flonum
syntax
Nonnegative-Single-Flonum
syntax
Negative-Single-Flonum
syntax
Nonpositive-Single-Flonum
syntax
Single-Flonum-Negative-Zero
syntax
Single-Flonum-Positive-Zero
syntax
Single-Flonum-Zero
syntax
Single-Flonum-Nan
syntax
Positive-Inexact-Real
syntax
Nonnegative-Inexact-Real
syntax
Negative-Inexact-Real
syntax
Nonpositive-Inexact-Real
syntax
Inexact-Real-Negative-Zero
syntax
Inexact-Real-Positive-Zero
syntax
Inexact-Real-Zero
syntax
Inexact-Real-Nan
syntax
Positive-Exact-Rational
syntax
Nonnegative-Exact-Rational
syntax
Negative-Exact-Rational
syntax
Nonpositive-Exact-Rational
syntax
Positive-Real
syntax
Nonnegative-Real
syntax
Negative-Real
syntax
Nonpositive-Real
syntax
Real-Zero
syntax
One
syntax
Byte
syntax
Positive-Byte
syntax
Index
syntax
Positive-Index
syntax
Fixnum
syntax
Positive-Fixnum
syntax
Nonnegative-Fixnum
syntax
Negative-Fixnum
syntax
Nonpositive-Fixnum
syntax
ExtFlonum
syntax
Positive-ExtFlonum
syntax
Nonnegative-ExtFlonum
syntax
Negative-ExtFlonum
syntax
Nonpositive-ExtFlonum
syntax
ExtFlonum-Negative-Zero
syntax
ExtFlonum-Positive-Zero
syntax
ExtFlonum-Zero
syntax
ExtFlonum-Nan
syntax
Boolean
syntax
True
syntax
False
syntax
String
syntax
Keyword
syntax
Symbol
syntax
Char
syntax
Void
syntax
Input-Port
syntax
Output-Port
syntax
Port
syntax
Path
syntax
Path-For-Some-System
syntax
Regexp
syntax
PRegexp
syntax
Byte-Regexp
syntax
Byte-PRegexp
syntax
Bytes
syntax
Namespace
syntax
Namespace-Anchor
syntax
Variable-Reference
syntax
Null
syntax
EOF
syntax
Continuation-Mark-Set
syntax
Undefined
syntax
Module-Path
syntax
Module-Path-Index
syntax
Resolved-Module-Path
syntax
Compiled-Module-Expression
syntax
Compiled-Expression
syntax
Internal-Definition-Context
syntax
Pretty-Print-Style-Table
syntax
Special-Comment
syntax
Struct-Type-Property
syntax
Impersonator-Property
syntax
Read-Table
syntax
Bytes-Converter
syntax
Parameterization
syntax
Custodian
syntax
Inspector
syntax
Security-Guard
syntax
UDP-Socket
syntax
TCP-Listener
syntax
Logger
syntax
Log-Receiver
syntax
Log-Level
syntax
Thread
syntax
Thread-Group
syntax
Subprocess
syntax
Place
syntax
Place-Channel
syntax
Semaphore
syntax
FSemaphore
syntax
Will-Executor
syntax
Pseudo-Random-Generator
syntax
Path-String
syntax
(Pairof s t)
syntax
(Listof t)
syntax
(List t ...)
syntax
(List t ... trest ... bound)
syntax
(List* t t1 ... s)
syntax
(MListof t)
syntax
(MPairof t u)
syntax
MPairTop
syntax
(Boxof t)
syntax
BoxTop
syntax
(Vectorof t)
syntax
(Vector t ...)
syntax
FlVector
syntax
ExtFlVector
syntax
FxVector
syntax
VectorTop
syntax
(HashTable k v)
syntax
HashTableTop
syntax
(Setof t)
syntax
(Channelof t)
syntax
ChannelTop
syntax
(Async-Channelof t)
syntax
Async-ChannelTop
syntax
(Parameterof t)
(Parameterof s t)
syntax
(Promise t)
syntax
(Futureof t)
syntax
(Sequenceof t)
syntax
(Custodian-Boxof t)
syntax
(Thread-Cellof t)
syntax
Thread-CellTop
syntax
(Weak-Boxof t)
syntax
Weak-BoxTop
syntax
(Ephemeronof t)
syntax
(Evtof t)
syntax
(Syntaxof t)
syntax
Identifier
syntax
Syntax
syntax
Syntax-E
syntax
(Sexpof t)
syntax
Sexp
syntax
Datum
syntax
(Prompt-Tagof s t)
syntax
Prompt-TagTop
syntax
(Continuation-Mark-Keyof t)
syntax
Continuation-Mark-KeyTop
syntax
(-> dom ... rng optional-filter)
(-> dom ... rest * rng)
(-> dom ... rest ooo bound rng)
(dom ... -> rng optional-filter)
(dom ... rest * -> rng)
(dom ... rest ooo bound -> rng)
 
            ooo = ...
                   
            dom = type
                | mandatory-kw
                | optional-kw
                   
   mandatory-kw = keyword type
                   
    optional-kw = [keyword type]
                   
optional-filter = 
                | : type
                | : pos-filter neg-filter object
                   
     pos-filter = 
                | #:+ proposition ...
                   
     neg-filter = 
                | #:- proposition ...
                   
         object = 
                | #:object index
                   
    proposition = type
                | (! type)
                | (type @ path-elem ... index)
                | (! type @ path-elem ... index)
                | (and proposition ...)
                | (or proposition ...)
                | (implies proposition ...)
                   
      path-elem = car
                | cdr
                   
          index = positive-integer
                | (positive-integer positive-integer)
                | identifier
syntax
(->* (mandatory-dom ...) optional-doms rest rng)
 
mandatory-dom = type
              | keyword type
                 
optional-doms = 
              | (optional-dom ...)
                 
 optional-dom = type
              | keyword type
                 
         rest = 
              | #:rest type
syntax
Top
syntax
Bot
syntax
Procedure
syntax
(U t ...)
syntax
(case-> fun-ty ...)
syntax
(t t1 t2 ...)
syntax
(All (a ...) t)
(All (a ... a ooo) t)
syntax
(Values t ...)
syntax
v
syntax
(quote val)
syntax
i
syntax
(Rec n t)
syntax
(Struct st)
syntax
(Struct-Type st)
syntax
Struct-TypeTop
syntax
(Prefab key type ...)
syntax
→
syntax
case→
syntax
∀
syntax
(Option t)
syntax
(Opaque t)
syntax
(let maybe-tvars (binding ...) . body)
(let loop maybe-ret (binding ...) . body)
 
    binding = [var e]
            | [var : type e]
               
maybe-tvars = 
            | #:forall (tvar ...)
            | #:∀ (tvar ...)
               
  maybe-ret = 
            | : type0
syntax
(letrec (binding ...) . body)
syntax
(let* (binding ...) . body)
syntax
(let-values ([(var+type ...) e] ...) . body)
syntax
(letrec-values ([(var+type ...) e] ...) . body)
syntax
(let*-values ([(var+type ...) e] ...) . body)
syntax
(let/cc v : t . body)
syntax
(let/ec v : t . body)
syntax
(lambda maybe-tvars formals maybe-ret . body)
 
    formals = (formal ...)
            | (formal ... . rst)
               
     formal = var
            | [var default-expr]
            | [var : type]
            | [var : type default-expr]
            | keyword var
            | keyword [var : type]
            | keyword [var : type default-expr]
               
        rst = var
            | [var : type *]
            | [var : type ooo bound]
               
maybe-tvars = 
            | #:forall (tvar ...)
            | #:∀ (tvar ...)
            | #:forall (tvar ... ooo)
            | #:∀ (tvar ... ooo)
               
  maybe-ret = 
            | : type
syntax
(λ formals . body)
syntax
(case-lambda maybe-tvars [formals body] ...)
syntax
(for type-ann-maybe (for-clause ...)
  expr ...+)
 
type-ann-maybe = 
               | : u
                  
    for-clause = [id : t seq-expr]
               | [(binding ...) seq-expr]
               | [id seq-expr]
               | #:when guard
                  
       binding = id
               | [id : t]
syntax
(for/list type-ann-maybe (for-clause ...) expr ...+)
syntax
(for/hash type-ann-maybe (for-clause ...) expr ...+)
syntax
(for/hasheq type-ann-maybe (for-clause ...) expr ...+)
syntax
(for/hasheqv type-ann-maybe (for-clause ...) expr ...+)
syntax
(for/vector type-ann-maybe (for-clause ...) expr ...+)
syntax
(for/flvector type-ann-maybe (for-clause ...) expr ...+)
syntax
(for/extflvector type-ann-maybe (for-clause ...) expr ...+)
syntax
(for/and type-ann-maybe (for-clause ...) expr ...+)
syntax
(for/or   type-ann-maybe (for-clause ...) expr ...+)
syntax
(for/first type-ann-maybe (for-clause ...) expr ...+)
syntax
(for/last type-ann-maybe (for-clause ...) expr ...+)
syntax
(for/sum type-ann-maybe (for-clause ...) expr ...+)
syntax
(for/product type-ann-maybe (for-clause ...) expr ...+)
syntax
(for/set type-ann-maybe (for-clause ...) expr ...+)
syntax
(for*/list type-ann-maybe (for-clause ...) expr ...+)
syntax
(for*/hash type-ann-maybe (for-clause ...) expr ...+)
syntax
(for*/hasheq type-ann-maybe (for-clause ...) expr ...+)
syntax
(for*/hasheqv type-ann-maybe (for-clause ...) expr ...+)
syntax
(for*/vector type-ann-maybe (for-clause ...) expr ...+)
syntax
(for*/flvector type-ann-maybe (for-clause ...) expr ...+)
syntax
(for*/extflvector type-ann-maybe (for-clause ...) expr ...+)
syntax
(for*/and type-ann-maybe (for-clause ...) expr ...+)
syntax
(for*/or   type-ann-maybe (for-clause ...) expr ...+)
syntax
(for*/first type-ann-maybe (for-clause ...) expr ...+)
syntax
(for*/last type-ann-maybe (for-clause ...) expr ...+)
syntax
(for*/sum type-ann-maybe (for-clause ...) expr ...+)
syntax
(for*/product type-ann-maybe (for-clause ...) expr ...+)
syntax
(for*/set type-ann-maybe (for-clause ...) expr ...+)
syntax
(for/lists type-ann-maybe ([id : t] ...)
  (for-clause ...)
  expr ...+)
syntax
(for/fold  type-ann-maybe ([id : t init-expr] ...)
  (for-clause ...)
  expr ...+)
syntax
(for* void-ann-maybe (for-clause ...)
  expr ...+)
syntax
(for*/lists type-ann-maybe ([id : t] ...)
  (for-clause ...)
  expr ...+)
syntax
(for*/fold  type-ann-maybe ([id : t init-expr] ...)
  (for-clause ...)
  expr ...+)
syntax
(do : u ([id : t init-expr step-expr-maybe] ...)
        (stop?-expr finish-expr ...)
  expr ...+)
 
step-expr-maybe = 
                | step-expr
syntax
(define maybe-tvars v maybe-ann e)
(define maybe-tvars header maybe-ann . body)
 
     header = (function-name . formals)
            | (header . formals)
               
    formals = (formal ...)
            | (formal ... . rst)
               
     formal = var
            | [var default-expr]
            | [var : type]
            | [var : type default-expr]
            | keyword var
            | keyword [var : type]
            | keyword [var : type default-expr]
               
        rst = var
            | [var : type *]
            | [var : type ooo bound]
               
maybe-tvars = 
            | #:forall (tvar ...)
            | #:∀ (tvar ...)
            | #:forall (tvar ... ooo)
            | #:∀ (tvar ... ooo)
               
  maybe-ann = 
            | : type
syntax
(struct maybe-type-vars name-spec ([f : t] ...) options ...)
 
maybe-type-vars = 
                | (v ...)
                   
      name-spec = name
                | name parent
                   
        options = #:transparent
                | #:mutable
                | #:prefab
syntax
(define-struct maybe-type-vars name-spec ([f : t] ...) options ...)
 
maybe-type-vars = 
                | (v ...)
                   
      name-spec = name
                | (name parent)
                   
        options = #:transparent
                | #:mutable
syntax
(define-struct/exec name-spec ([f : t] ...) [e : proc-t])
 
name-spec = name
          | (name parent)
syntax
(define-type name t maybe-omit-def)
(define-type (name v ...) t maybe-omit-def)
 
maybe-omit-def = #:omit-define-syntaxes
               | 
syntax
(make-predicate t)
syntax
(define-predicate name t)
syntax
(: v t)
(: v : t)
syntax
(provide: [v t] ...)
syntax
#{v : t}
syntax
(ann e t)
syntax
#{e :: t}
syntax
(cast e t)
syntax
(inst e t ...)
(inst e t ... t ooo bound)
syntax
#{e @ t ...}
syntax
#{e @ t ... t ooo bound}
syntax
(require/typed m rt-clause ...)
 
    rt-clause = [maybe-renamed t]
              | [#:struct name ([f : t] ...)
                     struct-option ...]
              | [#:struct (name parent) ([f : t] ...)
                     struct-option ...]
              | [#:opaque t pred]
                 
maybe-renamed = id
              | (orig-id new-id)
                 
struct-option = #:constructor-name constructor-id
              | #:extra-constructor-name constructor-id
syntax
(require/typed/provide m rt-clause ...)
syntax
with-handlers
procedure
(default-continuation-prompt-tag)
 -> (-> (Prompt-Tagof Any (Any -> Any)))
syntax
(#%module-begin form ...)
syntax
(#%top-interaction . form)
syntax
(class superclass-expr
  maybe-type-parameters
  class-clause ...)
 
         class-clause = (inspect inspector-expr)
                      | (init init-decl ...)
                      | (init-field init-decl ...)
                      | (init-rest id/type)
                      | (field field-decl ...)
                      | (inherit-field field-decl ...)
                      | (public maybe-renamed/type ...)
                      | (pubment maybe-renamed/type ...)
                      | (override maybe-renamed/type ...)
                      | (augment maybe-renamed/type ...)
                      | (private id/type ...)
                      | (inherit id ...)
                      | method-definition
                      | definition
                      | expr
                      | (begin class-clause ...)
                         
maybe-type-parameters = 
                      | #:forall (type-variable ...)
                      | #:∀ (type-variable ...)
                         
            init-decl = id/type
                      | [renamed]
                      | [renamed : type-expr]
                      | [maybe-renamed default-value-expr]
                      | [maybe-renamed : type-expr default-value-expr]
                         
           field-decl = (maybe-renamed default-value-expr)
                      | (maybe-renamed : type-expr default-value-expr)
                         
              id/type = id
                      | [id : type-expr]
                         
   maybe-renamed/type = maybe-renamed
                      | [maybe-renamed : type-expr]
                         
        maybe-renamed = id
                      | renamed
                         
              renamed = (internal-id external-id)
syntax
(define/public id expr)
(define/public (id . formals) body ...+)
syntax
(define/override id expr)
(define/override (id . formals) body ...+)
syntax
(define/pubment id expr)
(define/pubment (id . formals) body ...+)
syntax
(define/augment id expr)
(define/augment (id . formals) body ...+)
syntax
(define/private id expr)
(define/private (id . formals) body ...+)
syntax
(init init-decl ...)
syntax
(init-field init-decl ...)
syntax
(field field-decl ...)
syntax
(inherit-field field-decl ...)
syntax
(init-rest id/type)
syntax
(public maybe-renamed/type ...)
syntax
(pubment maybe-renamed/type ...)
syntax
(override maybe-renamed/type ...)
syntax
(augment maybe-renamed/type ...)
syntax
(private id/type ...)
syntax
(inherit maybe-renamed/type ...)
syntax
(Class class-type-clause ...)
 
class-type-clause = name+type
                  | (init init-type ...)
                  | (init-field init-type ...)
                  | (init-rest name+type)
                  | (field name+type ...)
                  | (augment name+type ...)
                  | #:implements type-alias-id
                  | #:implements/inits inits-id
                  | #:row-var row-var-id
                     
        init-type = name+type
                  | [id type #:optional]
                     
        name+type = [id type]
syntax
ClassTop
syntax
(Object object-type-clause ...)
 
object-type-clause = name+type
                   | (field name+type ...)
syntax
(Instance class-type-expr)
procedure
(assert v) -> A
  v : (U #f A)
(assert v p?) -> B
  v : A
  p? : (A -> Any : B)
syntax
(with-asserts ([id maybe-pred] ...) body ...+)
 
maybe-pred = 
           | predicate
procedure
(defined? v) -> boolean?
  v : any/c
procedure
(index? v) -> boolean?
  v : any/c
syntax
(typecheck-fail orig-stx maybe-msg maybe-id)
 
maybe-msg = 
          | msg-string
             
 maybe-id = 
          | #:covered-id id
syntax
(require/untyped-contract maybe-begin module [name subtype] ...)
 
maybe-begin = 
            | (begin expr ...)
syntax
(define-typed/untyped-identifier name typed-name untyped-name)
procedure
(syntax-local-typed-context?) -> boolean?
syntax
(:type maybe-verbose t)
 
maybe-verbose = 
              | #:verbose
syntax
(:print-type e)
syntax
(:query-type/args f t ...)
syntax
(:query-type/result f t)
syntax
(with-type result-spec fv-clause body ...+)
(with-type export-spec fv-clause body ...+)
 
  fv-clause = 
            | #:freevars ([id fv-type] ...)
               
result-spec = #:result type
               
export-spec = ([export-id export-type] ...)
syntax
(lambda: formals . body)
 
formals = ([v : t] ...)
        | ([v : t] ... v : t *)
        | ([v : t] ... v : t ooo bound)
syntax
(λ: formals . body)
syntax
(plambda: (a ...) formals . body)
(plambda: (a ... b ooo) formals . body)
syntax
(opt-lambda: formals . body)
 
formals = ([v : t] ... [v : t default] ...)
        | ([v : t] ... [v : t default] ... v : t *)
        | ([v : t] ... [v : t default] ... v : t ooo bound)
syntax
(popt-lambda: (a ...) formals . body)
(popt-lambda: (a ... a ooo) formals . body)
syntax
case-lambda:
syntax
(pcase-lambda: (a ...) [formals body] ...)
(pcase-lambda: (a ... b ooo) [formals body] ...)
syntax
(let: ([v : t e] ...) . body)
(let: loop : t0 ([v : t e] ...) . body)
syntax
(plet: (a ...) ([v : t e] ...) . body)
syntax
(letrec: ([v : t e] ...) . body)
syntax
(let*: ([v : t e] ...) . body)
syntax
(let-values: ([([v : t] ...) e] ...) . body)
syntax
(letrec-values: ([([v : t] ...) e] ...) . body)
syntax
(let*-values: ([([v : t] ...) e] ...) . body)
syntax
(let/cc: v : t . body)
syntax
(let/ec: v : t . body)
syntax
(define: v : t e)
(define: (a ...) v : t e)
(define: (a ... a ooo) v : t e)
(define: (f . formals) : t . body)
(define: (a ...) (f . formals) : t . body)
(define: (a ... a ooo) (f . formals) : t . body)
syntax
struct:
syntax
define-struct:
syntax
define-struct/exec:
syntax
for:
syntax
for*/and:
syntax
for*/first:
syntax
for*/flvector:
syntax
for*/extflvector:
syntax
for*/fold:
syntax
for*/hash:
syntax
for*/hasheq:
syntax
for*/hasheqv:
syntax
for*/last:
syntax
for*/list:
syntax
for*/lists:
syntax
for*/set:
syntax
for*/or:
syntax
for*/product:
syntax
for*/sum:
syntax
for*/vector:
syntax
for*:
syntax
for/and:
syntax
for/first:
syntax
for/flvector:
syntax
for/extflvector:
syntax
for/fold:
syntax
for/hash:
syntax
for/hasheq:
syntax
for/hasheqv:
syntax
for/last:
syntax
for/list:
syntax
for/lists:
syntax
for/set:
syntax
for/or:
syntax
for/product:
syntax
for/sum:
syntax
for/vector:
syntax
do:
syntax
define-type-alias
syntax
define-typed-struct
syntax
require/opaque-type
syntax
require-typed-struct
syntax
require-typed-struct/provide
syntax
pdefine:
syntax
(pred t)
syntax
Un
syntax
mu
syntax
Tuple
syntax
Parameter
syntax
Pair
syntax
values
syntax
(require/typed m rt-clause ...)
 
    rt-clause = [r t]
              | [struct name ([f : t] ...)
                     struct-option ...]
              | [struct (name parent) ([f : t] ...)
                     struct-option ...]
              | [opaque t pred]
                 
struct-option = #:constructor-name constructor-id
              | #:extra-constructor-name constructor-id
syntax
require-typed-struct
syntax
(declare-refinement id)
syntax
(Refinement id)
syntax
(define-typed-struct/exec forms ...)
