#lang racket/base

(require pkg/lib
         racket/path
         (submod compiler/commands/test paths))

(provide find-collection-dir)

;; Path-String -> (Listof Path)
;; Return list of possible paths for collection
(define (find-collection-dir collection)
  (if (relative-path? collection)
      (append (find/file-path collection)
              (sort (collection-paths collection) usefulness))
      null))

;; Path-String -> (Listof Path)
;; Given a collection path, return a file path to the
;; containing directory (.rkt ending is optional) or null if
;; none found
(define (find/file-path collection)
  (define-values (base name _1)
    (split-path collection))
  (define file-path
    (and (path-string? base)
         (path-string? name)
         (if (racket-extension? name)
             (collection-file-path name base #:fail (λ (_) #f))
             (collection-file-path (path-add-suffix name ".rkt")
                                   base #:fail (λ (_) #f)))))
  (and file-path
       (file-exists? file-path)
       (let-values ([(collection-base _2 _3)
                     (split-path file-path)])
         collection-base))
  (or (and file-path
           (file-exists? file-path)
           (let-values ([(collection-base _2 _3)
                         (split-path file-path)])
             (list collection-base)))
      null))

;; comparison function that orders by "usefulness"
(define (usefulness p1 p2)
  (and ;; prefer `collects` paths
       (path->pkg p2)
       (or (and (not (path->pkg p1))
                (path->pkg p2))
           ;; prefer `-lib` packages otherwise
           (and (from-lib-pkg? p1)
                (not (from-lib-pkg? p2))))))

;; Path-String -> Boolean
;; test whether a given path comes from a "lib" package
(define (from-lib-pkg? path)
  (define pkg (path->pkg path))
  (and pkg (regexp-match? #rx".*-lib$" pkg)))

;; check if the path has a Racket module extension
(define (racket-extension? path)
  (define ext (filename-extension path))
  (and ext (bytes=? ext #"rkt")))

(module+ test
  (require rackunit)
  (check-not-exn (λ () (find-collection-dir "/bin/bash")))
  (check-not-exn (λ () (find-collection-dir "raco-find-collection"))))

