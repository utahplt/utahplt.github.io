12474
((3) 0 () 35 ((q lib "unstable/automata/machine.rkt") (q lib "unstable/class-iop.rkt") (q lib "unstable/automata/re-ext.rkt") (q lib "unstable/temp-c/monitor.rkt") (q lib "unstable/debug.rkt") (q lib "unstable/list.rkt") (q lib "unstable/options.rkt") (q lib "unstable/automata/re.rkt") (q lib "unstable/automata/nfa-ep.rkt") (q 0 . 3) (q 20177 . 16) (q lib "unstable/contract.rkt") (q 20659 . 18) (q 19951 . 4) (q 20029 . 6) (q lib "unstable/temp-c/dsl.rkt") (q lib "unstable/markparam.rkt") (q lib "unstable/error.rkt") (q lib "unstable/parameter-group.rkt") (q lib "unstable/syntax.rkt") (q lib "unstable/socket.rkt") (q lib "unstable/pretty.rkt") (q 70 . 3) (q lib "unstable/custom-write.rkt") (q lib "unstable/logging.rkt") (q lib "unstable/sequence.rkt") (q lib "unstable/future.rkt") (q lib "unstable/define.rkt") (q lib "unstable/match.rkt") (q lib "unstable/function.rkt") (q lib "unstable/struct.rkt") (q 13594 . 2) (q lib "unstable/bytes.rkt") (q lib "unstable/macro-testing.rkt") (q lib "unstable/hash.rkt")) () (h ! (equal) ((c def c (c (? . 0) q machine-star)) q (529 . 3)) ((c def c (c (? . 3) q monitor:call-proj-label)) c (? . 10)) ((c def c (c (? . 5) q map/values)) q (11229 . 5)) ((c def c (c (? . 6) q exercise-option)) q (15301 . 3)) ((c def c (c (? . 0) q machine-next)) c (? . 9)) ((c form c (c (? . 1) q init-private/i)) q (10002 . 5)) ((c form c (c (? . 1) q init/i)) q (9872 . 2)) ((c form c (c (? . 2) q intersection)) q (2530 . 2)) ((c def c (c (? . 19) q syntax-source-file-name)) q (19867 . 3)) ((c form c (c (? . 1) q define-interface)) q (9455 . 2)) ((c form c (c (? . 4) q let*-values/debug)) q (5365 . 2)) ((c form c (c (? . 2) q plus)) q (2442 . 2)) ((c def c (c (? . 0) q machine-seq)) q (770 . 4)) ((c form c (c (? . 7) q dseq)) q (2357 . 2)) ((c def c (c (? . 3) q struct:monitor:return)) c (? . 12)) ((c form c (c (? . 15) q ret)) q (21395 . 2)) ((c def c (c (? . 0) q machine-accepting?)) c (? . 22)) ((c form c (c (? . 8) q epsilon)) q (1464 . 2)) ((c form c (c (? . 4) q define/debug)) q (4626 . 3)) ((c def c (c (? . 0) q machine-epsilon)) q (393 . 2)) ((c def c (c (? . 5) q check-duplicate)) q (10894 . 8)) ((c def c (c (? . 11) q truth/c)) q (3278 . 2)) ((c form c (c (? . 4) q begin/debug)) q (4594 . 2)) ((c def c (c (? . 6) q tweak-option)) q (15445 . 3)) ((c form c (c (? . 7) q union)) q (2302 . 2)) ((c form c (c (? . 8) q nfa/ep)) q (1479 . 14)) ((c form c (c (? . 28) q object)) q (14371 . 10)) ((c def c (c (? . 16) q mark-parameter-all)) q (13791 . 5)) ((c def c (c (? . 0) q machine)) c (? . 9)) ((c def c (c (? . 5) q split-common-prefix)) q (10579 . 5)) ((c def c (c (? . 24) q stop-recording)) q (13033 . 7)) ((c def c (c (? . 0) q struct:machine)) c (? . 9)) ((c def c (c (? . 3) q monitor:call-app-label)) c (? . 10)) ((c form c (c (? . 7) q complement)) q (2273 . 2)) ((c def c (c (? . 3) q struct:monitor)) c (? . 13)) ((c def c (c (? . 11) q failure-result/c)) q (3064 . 2)) ((c def c (c (? . 3) q monitor:return-app-label)) c (? . 12)) ((q def ((lib "unstable/sandbox.rkt") make-log-based-eval)) q (17363 . 4)) ((c def c (c (? . 5) q group-by)) q (11610 . 5)) ((c form c (c (? . 18) q parameterize/group)) q (16340 . 5)) ((c def c (c (? . 29) q conjoin)) q (8255 . 4)) ((c def c (c (? . 3) q monitor:return)) c (? . 12)) ((q form ((lib "unstable/2d/tabular.rkt") 2dmatch)) q (23678 . 26)) ((q form ((lib "unstable/2d/cond.rkt") 2dcond)) q (21717 . 33)) ((c def c (c (? . 30) q struct->list)) q (18190 . 4)) ((c def c (c (? . 0) q machine-complement)) q (462 . 3)) ((c form c (c (? . 4) q debug)) q (4285 . 5)) ((c def c (c (? . 23) q make-constructor-style-printer)) q (18349 . 6)) ((c def c (c (? . 3) q monitor:proj-label)) c (? . 14)) ((c form c (c (? . 4) q debugf)) q (4472 . 5)) ((c def c (c (? . 5) q drop-common-prefix)) q (10456 . 5)) ((c def c (c (? . 3) q monitor?)) c (? . 13)) ((c def c (c (? . 3) q monitor:proj-proj-label)) c (? . 14)) ((c form c (c (? . 1) q send/i)) q (9600 . 2)) ((c def c (c (? . 5) q remf)) q (11529 . 4)) ((c form c (c (? . 15) q call)) q (21370 . 2)) ((c form c (c (? . 16) q mark-parameterize)) q (14173 . 2)) ((c def c (c (? . 17) q compose-error-message)) q (7171 . 13)) ((c def c (c (? . 3) q monitor:return?)) c (? . 12)) ((c def c (c (? . 21) q break-lines)) q (17191 . 4)) ((c form c (c (? . 4) q define/public/debug)) q (4788 . 3)) ((c form c (c (? . 7) q epsilon)) q (2327 . 2)) ((c def c (c (? . 20) q unix-socket-path?)) q (21654 . 3)) ((c form c (c (? . 4) q letrec/debug)) q (5232 . 2)) ((c form c (c (? . 7) q rec)) q (2369 . 2)) ((c def c (c (? . 6) q waive-option)) q (15390 . 3)) ((c def c (c (? . 3) q monitor:return-rets)) c (? . 12)) ((c form c (c (? . 26) q for*/async)) q (8204 . 2)) ((c form c (c (? . 1) q init-field/i)) q (9934 . 2)) ((c def c (c (? . 17) q error-display)) q (8098 . 3)) ((c def c (c (? . 11) q port-number?)) q (2788 . 2)) ((c form c (c (? . 18) q parameterize*/group)) q (16500 . 5)) ((c form c (c (? . 4) q letrec-values/debug)) q (5438 . 2)) ((c form c (c (? . 4) q with-syntax/debug)) q (5513 . 2)) ((c form c (c (? . 15) q label)) q (21464 . 2)) ((c def c (c (? . 5) q list-prefix?)) q (10262 . 4)) ((q form ((lib "unstable/automata/dfa.rkt") dfa)) q (959 . 11)) ((c def c (c (? . 3) q monitor:return-kw-args)) c (? . 12)) ((q form ((lib "unstable/2d/match.rkt") 2dmatch)) q (22844 . 22)) ((c form c (c (? . 27) q in-phase1/pass2)) q (5765 . 2)) ((c form c (c (? . 4) q parameterize/debug)) q (5648 . 2)) ((c def c (c (? . 19) q explode-module-path-index)) q (18701 . 4)) ((c def c (c (? . 20) q unix-socket-available?)) q (21498 . 2)) ((c def c (c (? . 3) q monitor:call)) c (? . 10)) ((c form c (c (? . 4) q let-values/debug)) q (5293 . 2)) ((c def c (c (? . 25) q in-syntax)) q (17501 . 3)) ((c form c (c (? . 7) q re)) q (1926 . 15)) ((c form c (c (? . 2) q rep)) q (2464 . 2)) ((c def c (c (? . 6) q option/c)) q (14635 . 15)) ((c def c (c (? . 21) q pretty-format/display)) q (16837 . 5)) ((c def c (c (? . 0) q machine-accepting)) c (? . 22)) ((c def c (c (? . 23) q prop:auto-custom-write)) q (18629 . 2)) ((c def c (c (? . 16) q mark-parameters-all)) q (13952 . 6)) ((c def c (c (? . 6) q transfer/c)) q (15359 . 2)) ((c def c (c (? . 11) q path-piece?)) q (2858 . 2)) ((c form c (c (? . 4) q define/augment/debug)) q (4966 . 3)) ((q def ((lib "unstable/wrapc.rkt") wrap-expr/c)) q (3392 . 19)) ((c def c (c (? . 24) q start-recording)) q (12897 . 3)) ((c def c (c (? . 11) q if/c)) q (2890 . 5)) ((c def c (c (? . 25) q in-pairs)) q (17563 . 3)) ((c def c (c (? . 19) q syntax-within?)) q (19617 . 4)) ((c def c (c (? . 3) q monitor:call?)) c (? . 10)) ((c form c (c (? . 1) q send/apply/i)) q (9741 . 2)) ((c def c (c (? . 11) q rename-contract)) q (3101 . 4)) ((c def c (c (? . 0) q machine-accepting-next)) c (? . 22)) ((c form c (c (? . 26) q for/async)) q (8154 . 2)) ((c form c (c (? . 27) q in-phase1)) q (5743 . 2)) ((c def c (c (? . 11) q treeof)) q (3311 . 3)) ((q form ((lib "unstable/recontract.rkt") recontract-out)) q (17330 . 2)) ((c def c (c (? . 21) q pretty-format/print)) q (17015 . 5)) ((c def c (c (? . 0) q machine-seq*)) q (856 . 4)) ((c def c (c (? . 3) q struct:monitor:call)) c (? . 10)) ((q form ((lib "unstable/automata/nfa.rkt") nfa)) q (1193 . 11)) ((c def c (c (? . 5) q map2)) q (11406 . 4)) ((c def c (c (? . 17) q error*)) q (5793 . 13)) ((c def c (c (? . 19) q make-variable-like-transformer)) q (18874 . 6)) ((c def c (c (? . 0) q machine-intersect)) q (678 . 4)) ((c form c (c (? . 28) q match?)) q (14235 . 2)) ((c def c (c (? . 17) q compose-error-detail)) q (7870 . 5)) ((c def c (c (? . 3) q monitor:return-label)) c (? . 12)) ((c form c (c (? . 4) q with-syntax*/debug)) q (5580 . 2)) ((c def c (c (? . 18) q parameter-group?)) q (16084 . 3)) ((c def c (c (? . 3) q monitor:call-kws)) c (? . 10)) ((c form c (c (? . 33) q convert-compile-time-error)) q (13516 . 2)) ((c def c (c (? . 3) q monitor:proj-v)) c (? . 14)) ((c def c (c (? . 32) q read/bytes)) q (2604 . 3)) ((c def c (c (? . 16) q mark-parameter)) c (? . 31)) ((c def c (c (? . 3) q monitor/c)) q (21215 . 5)) ((c def c (c (? . 19) q syntax-source-directory)) q (19783 . 3)) ((c def c (c (? . 11) q non-empty-string?)) q (2725 . 3)) ((c form c (c (? . 4) q let*/debug)) q (5173 . 2)) ((c form c (c (? . 7) q define-re-transformer)) q (2380 . 2)) ((c form c (c (? . 28) q as)) q (14271 . 2)) ((c def c (c (? . 3) q monitor:call-args)) c (? . 10)) ((c def c (c (? . 11) q maybe/c)) q (3206 . 3)) ((c def c (c (? . 0) q machine-accepts?/prefix-closed)) q (253 . 4)) ((c def c (c (? . 0) q struct:machine-accepting)) c (? . 22)) ((c def c (c (? . 29) q disjoin)) q (8352 . 4)) ((c form c (c (? . 18) q define-parameter-group)) q (16146 . 7)) ((c form c (c (? . 1) q define-interface-expander)) q (10138 . 2)) ((c def c (c (? . 20) q unix-socket-connect)) q (21540 . 3)) ((c form c (c (? . 1) q define-interface/dynamic)) q (9529 . 2)) ((c def c (c (? . 5) q take-common-prefix)) q (10339 . 5)) ((c def c (c (? . 4) q dprintf)) q (4388 . 4)) ((q form ((lib "unstable/lazy-require.rkt") begin-on-demand)) q (10195 . 3)) ((c def c (c (? . 3) q monitor)) c (? . 13)) ((c form c (c (? . 7) q nullset)) q (2342 . 2)) ((c def c (c (? . 3) q monitor-label)) c (? . 13)) ((c def c (c (? . 3) q monitor:return-f)) c (? . 12)) ((c def c (c (? . 24) q with-intercepted-logging)) q (12372 . 12)) ((c form c (c (? . 1) q define/i)) q (9829 . 2)) ((c def c (c (? . 3) q monitor:call-kw-args)) c (? . 10)) ((c def c (c (? . 3) q monitor:proj)) c (? . 14)) ((c form c (c (? . 28) q match*?)) q (14320 . 2)) ((c form c (c (? . 4) q let/debug)) q (5055 . 3)) ((c def c (c (? . 6) q invariant/c)) q (15628 . 11)) ((c form c (c (? . 4) q define/override/debug)) q (4875 . 3)) ((c def c (c (? . 5) q filter-multiple)) q (10711 . 4)) ((c def c (c (? . 3) q struct:monitor:proj)) c (? . 14)) ((c def c (c (? . 5) q list-update)) q (11868 . 5)) ((c def c (c (? . 3) q monitor:proj?)) c (? . 14)) ((c def c (c (? . 3) q monitor:return-proj-label)) c (? . 12)) ((c form c (c (? . 2) q opt)) q (2421 . 2)) ((q form ((lib "unstable/open-place.rkt") open-place)) q (14599 . 2)) ((c def c (c (? . 3) q monitor:call-label)) c (? . 10)) ((c def c (c (? . 19) q format-unique-id)) q (19085 . 13)) ((c def c (c (? . 0) q machine?)) c (? . 9)) ((c form c (c (? . 19) q phase-of-enclosing-module)) q (18839 . 2)) ((c form c (c (? . 30) q make)) q (18154 . 2)) ((c def c (c (? . 5) q list-set)) q (12032 . 5)) ((c def c (c (? . 5) q cartesian-product)) q (11777 . 3)) ((c form c (c (? . 4) q define/private/debug)) q (4699 . 3)) ((c def c (c (? . 24) q with-logging-to-port)) q (12176 . 5)) ((c def c (c (? . 5) q extend)) q (10803 . 5)) ((c def c (c (? . 3) q monitor:return-args)) c (? . 12)) ((c def c (c (? . 6) q has-option-with-contract?)) q (15557 . 3)) ((c def c (c (? . 16) q mark-parameter?)) c (? . 31)) ((c def c (c (? . 0) q machine-sigma*)) q (428 . 2)) ((c def c (c (? . 6) q has-option?)) q (15500 . 3)) ((c def c (c (? . 17) q exn:not-break?)) q (8038 . 3)) ((c def c (c (? . 16) q struct:mark-parameter)) c (? . 31)) ((c def c (c (? . 0) q machine-accepts?)) q (159 . 4)) ((c def c (c (? . 25) q in-slice)) q (17815 . 4)) ((c def c (c (? . 32) q write/bytes)) q (2664 . 3)) ((c def c (c (? . 19) q syntax-length)) q (19700 . 3)) ((c def c (c (? . 17) q raise-syntax-error*)) q (6386 . 15)) ((q def ((lib "unstable/string.rkt") regexp-filter)) q (17925 . 5)) ((c def c (c (? . 3) q monitor:return-kws)) c (? . 12)) ((c def c (c (? . 0) q machine-null)) q (361 . 2)) ((c form c (c (? . 1) q send*/i)) q (9666 . 2)) ((c form c (c (? . 33) q convert-syntax-error)) q (13558 . 2)) ((c def c (c (? . 16) q mark-parameter-first)) q (13628 . 5)) ((c form c (c (? . 2) q seq/close)) q (2572 . 2)) ((c def c (c (? . 11) q tcp-listen-port?)) q (2821 . 2)) ((c def c (c (? . 21) q pretty-format/write)) q (16661 . 5)) ((c form c (c (? . 33) q phase1-eval)) q (13327 . 8)) ((c form c (c (? . 2) q difference)) q (2490 . 2)) ((c form c (c (? . 7) q seq)) q (2291 . 2)) ((c form c (c (? . 27) q at-end)) q (5721 . 2)) ((c def c (c (? . 3) q monitor:call-f)) c (? . 10)) ((c form c (c (? . 7) q star)) q (2315 . 2)) ((c def c (c (? . 34) q hash-union!)) q (8964 . 11)) ((c def c (c (? . 0) q machine-union)) q (590 . 4)) ((c form c (c (? . 15) q with-monitor)) q (21419 . 2)) ((c def c (c (? . 34) q hash-union)) q (8449 . 12)) ((c def c (c (? . 25) q in-sequence-forever)) q (17626 . 4)) ((c def c (c (? . 25) q sequence-lift)) q (17723 . 4))))
struct
(struct machine (next))
  next : (any/c . -> . machine?)
struct
(struct machine-accepting machine (next))
  next : (any/c . -> . machine?)
procedure
(machine-accepts? m i) -> boolean?
  m : machine?
  i : (listof any/c)
procedure
(machine-accepts?/prefix-closed m i) -> boolean?
  m : machine?
  i : (listof any/c)
value
machine-null : machine?
value
machine-epsilon : machine?
value
machine-sigma* : machine?
procedure
(machine-complement m) -> machine?
  m : machine?
procedure
(machine-star m) -> machine?
  m : machine?
procedure
(machine-union m0 m1) -> machine?
  m0 : machine?
  m1 : machine?
procedure
(machine-intersect m0 m1) -> machine?
  m0 : machine?
  m1 : machine?
procedure
(machine-seq m0 m1) -> machine?
  m0 : machine?
  m1 : machine?
procedure
(machine-seq* m0 make-m1) -> machine?
  m0 : machine?
  make-m1 : (-> machine?)
syntax
(dfa start
     (end ...)
     [state ([evt next-state]
             ...)]
     ...)
 
  start : identifier?
  end : identifier?
  state : identifier?
  next-state : identifier?
syntax
(nfa (start:id ...)
     (end:id ...)
     [state:id ([evt:expr (next-state:id ...)]
                ...)]
     ...)
 
  start : identifier?
  end : identifier?
  state : identifier?
  next-state : identifier?
syntax
epsilon
syntax
(nfa/ep (start:id ...)
        (end:id ...)
        [state:id ([epsilon (epsilon-state:id ...)]
                   ...
                   [evt:expr (next-state:id ...)]
                   ...)]
        ...)
 
  start : identifier?
  end : identifier?
  state : identifier?
  epsilon-state : identifier?
  next-state : identifier?
syntax
(re re-pat)
 
re-pat = (rec id re-pat)
       | ,expr
       | (complement re-pat)
       | (seq re-pat ...)
       | (union re-pat ...)
       | (star re-pat)
       | epsilon
       | nullset
       | re-transformer
       | (re-transformer . datum)
       | (dseq pat re-pat)
       | pat
syntax
complement
syntax
seq
syntax
union
syntax
star
syntax
epsilon
syntax
nullset
syntax
dseq
syntax
rec
syntax
(define-re-transformer id expr)
syntax
(opt re-pat)
syntax
(plus re-pat)
syntax
(rep re-pat num)
syntax
(difference re-pat_0 re-pat_1)
syntax
(intersection re-pat_0 re-pat_1)
syntax
(seq/close re-pat ...)
procedure
(read/bytes b) -> printable/c
  b : bytes?
procedure
(write/bytes v) -> bytes?
  v : printable/c
procedure
(non-empty-string? x) -> boolean?
  x : any/c
value
port-number? : contract?
value
tcp-listen-port? : contract?
value
path-piece? : contract?
procedure
(if/c predicate then-contract else-contract) -> contract?
  predicate : (-> any/c any/c)
  then-contract : contract?
  else-contract : contract?
value
failure-result/c : contract?
procedure
(rename-contract contract name) -> contract?
  contract : contract?
  name : any/c
procedure
(maybe/c contract) -> contract?
  contract : contract?
value
truth/c : flat-contract?
procedure
(treeof elem-contract) -> contract?
  elem-contract : contract?
procedure
(wrap-expr/c  contract-expr            
              expr                     
             [#:positive pos-blame     
              #:negative neg-blame     
              #:name expr-name         
              #:macro macro-name       
              #:context context])  -> syntax?
  contract-expr : syntax?
  expr : syntax?
  pos-blame : (or/c syntax? string? module-path-index?
                    'from-macro 'use-site 'unknown)
            = 'use-site
  neg-blame : (or/c syntax? string? module-path-index?
                    'from-macro 'use-site 'unknown)
            = 'from-macro
  expr-name : (or/c identifier? symbol? string? #f) = #f
  macro-name : (or/c identifier? symbol? string? #f) = #f
  context : (or/c syntax? #f) = (current-syntax-context)
syntax
(debug options ... expr)
 
options = #:name name-expr
        | #:source srcloc-expr
procedure
(dprintf fmt arg ...) -> void?
  fmt : string?
  arg : any/c
syntax
(debugf function-expr argument ...)
 
argument = argument-expr
         | argument-keyword argument-expr
syntax
(begin/debug expr ...)
syntax
(define/debug id expr)
(define/debug (head args) body ...+)
syntax
(define/private/debug id expr)
(define/private/debug (head args) body ...+)
syntax
(define/public/debug id expr)
(define/public/debug (head args) body ...+)
syntax
(define/override/debug id expr)
(define/override/debug (head args) body ...+)
syntax
(define/augment/debug id expr)
(define/augment/debug (head args) body ...+)
syntax
(let/debug ([lhs-id rhs-expr] ...) body ...+)
(let/debug loop-id ([lhs-id rhs-expr] ...) body ...+)
syntax
(let*/debug ([lhs-id rhs-expr] ...) body ...+)
syntax
(letrec/debug ([lhs-id rhs-expr] ...) body ...+)
syntax
(let-values/debug ([(lhs-id ...) rhs-expr] ...) body ...+)
syntax
(let*-values/debug ([(lhs-id ...) rhs-expr] ...) body ...+)
syntax
(letrec-values/debug ([(lhs-id ...) rhs-expr] ...) body ...+)
syntax
(with-syntax/debug ([pattern stx-expr] ...) body ...+)
syntax
(with-syntax*/debug ([pattern stx-expr] ...) body ...+)
syntax
(parameterize/debug ([param-expr value-expr] ...) body ...+)
syntax
(at-end expr)
syntax
(in-phase1 e)
syntax
(in-phase1/pass2 e)
procedure
(error*  name                                
         message                             
         field                               
         value ...                           
         ...                                 
        [#:continued continued-message]) -> any
  name : symbol?
  message : string?
  field : (let ([option/c (or/c 'value 'multi 'maybe)])
            (or/c string? (cons/c string? (listof option/c))))
  value : any/c
  continued-message : (or/c string? (listof string?)) = null
procedure
(raise-syntax-error*  message                             
                      expr                                
                      sub-expr                            
                      field                               
                      value ...                           
                      ...                                 
                     [#:continued continued-message]) -> any
  message : string?
  expr : (or/c syntax? #f)
  sub-expr : (or/c syntax? #f)
  field : (let ([option/c (or/c 'value 'multi 'maybe)])
            (or/c string? (cons/c string? (listof option/c))))
  value : any/c
  continued-message : (or/c string? (listof string?)) = null
procedure
(compose-error-message  name                                
                        message                             
                        field                               
                        value ...                           
                        ...                                 
                       [#:continued continued-message]) -> string?
  name : (or/c symbol? #f)
  message : string?
  field : (let ([option/c (or/c 'value 'multi 'maybe)])
            (or/c string? (cons/c string? (listof option/c))))
  value : any/c
  continued-message : (or/c string? (listof string?)) = null
procedure
(compose-error-detail field options value) -> string?
  field : string?
  options : (listof (or/c 'value 'multi 'maybe))
  value : any/c
procedure
(exn:not-break? x) -> boolean?
  x : any/c
procedure
(error-display x) -> void?
  x : any/c
syntax
(for/async (for-clause ...) body ...+)
syntax
(for*/async (for-clause ...) body ...+)
procedure
((conjoin f ...) x ...) -> boolean?
  f : (-> A ... boolean?)
  x : A
procedure
((disjoin f ...) x ...) -> boolean?
  f : (-> A ... boolean?)
  x : A
procedure
(hash-union  h0                          
             h ...                       
            [#:combine combine           
             #:combine/key combine/key]) 
 -> (and/c hash? hash-can-functional-set?)
  h0 : (and/c hash? hash-can-functional-set?)
  h : hash?
  combine : (-> any/c any/c any/c)
          = (lambda _ (error 'hash-union ....))
  combine/key : (-> any/c any/c any/c any/c)
              = (lambda (k a b) (combine a b))
procedure
(hash-union!  h0                              
              h ...                           
             [#:combine combine               
              #:combine/key combine/key]) -> void?
  h0 : (and/c hash? hash-mutable?)
  h : hash?
  combine : (-> any/c any/c any/c)
          = (lambda _ (error 'hash-union ....))
  combine/key : (-> any/c any/c any/c any/c)
              = (lambda (k a b) (combine a b))
syntax
(define-interface name-id (super-ifc-id ...) (method-id ...))
syntax
(define-interface/dynamic name-id ifc-expr (method-id ...))
syntax
(send/i obj-exp static-ifc-id method-id arg-expr ...)
syntax
(send*/i obj-expr static-ifc-id (method-id arg-expr ...) ...)
syntax
(send/apply/i obj-expr static-ifc-id method-id arg-expr ... list-arg-expr)
syntax
(define/i id static-ifc-id expr)
syntax
(init/i (id static-ifc-id maybe-default-expr) ...)
syntax
(init-field/i (id static-ifc-id maybe-default-expr) ...)
syntax
(init-private/i (id static-ifc-id maybe-default-expr) ...)
 
maybe-default-expr = ()
                   | default-expr
syntax
(define-interface-expander id transformer-expr)
syntax
(begin-on-demand #:export (fun-id ...)
   body ...+)
procedure
(list-prefix? l r) -> boolean?
  l : list?
  r : list?
procedure
(take-common-prefix l r #:same? same?) -> list?
  l : list?
  r : list?
  same? : equal?
procedure
(drop-common-prefix l r #:same same?) -> list? list?
  l : list?
  r : list?
  same? : equal?
procedure
(split-common-prefix l r #:same? same?) -> list? list? list?
  l : list?
  r : list?
  same? : equal?
procedure
(filter-multiple l f ...) -> list? ...
  l : list?
  f : procedure?
procedure
(extend l1 l2 v) -> list?
  l1 : list?
  l2 : list?
  v : any/c
procedure
(check-duplicate  lst                   
                 [#:key extract-key     
                  #:same? same?])   -> (or/c any/c #f)
  lst : list?
  extract-key : (-> any/c any/c) = (lambda (x) x)
  same? : (or/c (any/c any/c . -> . any/c) = equal?
                dict?)
procedure
(map/values n f lst ...) -> (listof B_1) ... (listof B_n)
  n : natural-number/c
  f : (-> A ... (values B_1 ... B_n))
  lst : (listof A)
procedure
(map2 f lst ...) -> (listof B) (listof C)
  f : (-> A ... (values B C))
  lst : (listof A)
procedure
(remf pred lst) -> list?
  pred : procedure?
  lst : list?
procedure
(group-by extract-key lst [=?]) -> (listof (listof A))
  extract-key : (-> A B)
  lst : (listof A)
  =? : (-> B B any/c) = equal?
procedure
(cartesian-product lst ...) -> (listof (listof A))
  lst : (listof A)
procedure
(list-update lst index updater) -> list?
  lst : list?
  index : (and/c (>=/c 0) (</c (length lst)))
  updater : (-> any/c any/c)
procedure
(list-set lst index value) -> list?
  lst : list?
  index : (and/c (>=/c 0) (</c (length lst)))
  value : any/c
procedure
(with-logging-to-port port proc log-spec ...) -> any
  port : output-port?
  proc : (-> any)
  log-spec : (or/c 'fatal 'error 'warning 'info 'debug symbol? #f)
procedure
(with-intercepted-logging interceptor       
                          proc              
                          log-spec ...) -> any
  interceptor : (-> (vector/c
                      (or/c 'fatal 'error 'warning 'info 'debug)
                      string?
                      any/c
                      (or/c symbol? #f))
                     any)
  proc : (-> any)
  log-spec : (or/c 'fatal 'error 'warning 'info 'debug symbol? #f)
procedure
(start-recording log-spec ...) -> listener?
  log-spec : (or/c 'fatal 'error 'warning 'info 'debug symbol? #f)
procedure
(stop-recording listener)
 -> (listof (vector/c (or/c 'fatal 'error 'warning 'info 'debug)
                      string?
                      any/c
                      (or/c symbol? #f)))
  listener : listener?
syntax
(phase1-eval ct-expr maybe-quote maybe-catch?)
 
 maybe-quote = 
             | #:quote quote-id
                
maybe-catch? = 
             | #:catch? catch?
syntax
(convert-compile-time-error expr)
syntax
(convert-syntax-error expr)
struct
(struct mark-parameter ())
procedure
(mark-parameter-first mp [tag]) -> any/c
  mp : mark-parameter?
  tag : continuation-prompt-tag?
      = default-continuation-prompt-tag
procedure
(mark-parameter-all mp [tag]) -> list?
  mp : mark-parameter?
  tag : continuation-prompt-tag?
      = default-continuation-prompt-tag
procedure
(mark-parameters-all mps none-v [tag]) -> (listof vector?)
  mps : (listof mark-parameter?)
  none-v : [any/c #f]
  tag : continuation-prompt-tag?
      = default-continuation-prompt-tag
syntax
(mark-parameterize ([mp expr] ...) body-expr ...)
syntax
(match? val-expr pat ...)
syntax
(as ([lhs-id rhs-expr] ...) pat ...)
syntax
(match*? (val-expr ...) (pat ...) ...)
syntax
(object maybe-class field-clause ...)
 
 maybe-class = 
             | class-expr
                
field-clause = (field field-id maybe-pat)
                
   maybe-pat = 
             | pat
syntax
(open-place id body ...+)
procedure
(option/c  c                         
          [#:with-contract with      
           #:tester tester           
           #:invariant invariant     
           #:immutable immutable     
           #:flat? flat?             
           #:struct struct-id])  -> contract?
  c : contract?
  with : boolean? = #f
  tester : (or/c (-> any boolean?) 'dont-care) = 'dont-care
  invariant : (or/c (-> any boolean?) 'dont-care) = 'dont-care
  immutable : (or/c #t #f 'dont-care) = 'dont-care
  flat? : boolean? = #f
  struct-id : (or/c identifier? 'none) = 'none
procedure
(exercise-option x) -> any/c
  x : any/c
value
transfer/c : contract?
procedure
(waive-option x) -> any/c
  x : any/c
procedure
(tweak-option x) -> any/c
  x : any/c
procedure
(has-option? v) -> boolean?
  v : any/c
procedure
(has-option-with-contract? v) -> boolean?
  v : any/c
procedure
(invariant/c  c                         
              invariant                 
             [#:immutable immutable     
              #:flat? flat?             
              #:struct struct-id])  -> contract?
  c : contract?
  invariant : (-> any boolean?)
  immutable : (or/c #t #f 'dont-care) = 'dont-care
  flat? : boolean? = #f
  struct-id : (or/c identifier? 'none) = 'none
procedure
(parameter-group? v) -> boolean?
  v : any/c
syntax
(define-parameter-group name (param-or-group-expr ...) options)
 
options = 
        | #:struct struct-name
 
  param-or-group-expr : (or/c parameter? parameter-group?)
syntax
(parameterize/group ([param-or-group-expr  value-expr] ...)
  body-expr ...+)
 
  param-or-group-expr : (or/c parameter? parameter-group?)
syntax
(parameterize*/group ([param-or-group-expr  value-expr] ...)
  body-expr ...+)
 
  param-or-group-expr : (or/c parameter? parameter-group?)
procedure
(pretty-format/write x [columns]) -> string?
  x : any/c
  columns : (or/c exact-nonnegative-integer? 'infinity)
          = (pretty-print-columns)
procedure
(pretty-format/display x [columns]) -> string?
  x : any/c
  columns : (or/c exact-nonnegative-integer? 'infinity)
          = (pretty-print-columns)
procedure
(pretty-format/print x [columns]) -> string?
  x : any/c
  columns : (or/c exact-nonnegative-integer? 'infinity)
          = (pretty-print-columns)
procedure
(break-lines s [columns]) -> string?
  s : string?
  columns : exact-nonnegative-integer? = (pretty-print-columns)
syntax
(recontract-out id ...)
procedure
(make-log-based-eval log-file mode) -> (-> any/c any)
  log-file : path-string?
  mode : (or/c 'record 'replay)
procedure
(in-syntax stx) -> sequence?
  stx : syntax?
procedure
(in-pairs seq) -> sequence?
  seq : sequence?
procedure
(in-sequence-forever seq val) -> sequence?
  seq : sequence?
  val : any/c
procedure
(sequence-lift f seq) -> sequence?
  f : procedure?
  seq : sequence?
procedure
(in-slice length seq) -> sequence?
  length : exact-positive-integer?
  seq : sequence?
procedure
(regexp-filter pattern lst)
 -> (listof (or/c string? bytes? path? input-port?))
  pattern : (or/c string? bytes? regexp? byte-regexp?)
  lst : (listof (or/c string? bytes? path? input-port?))
syntax
(make struct-id expr ...)
procedure
(struct->list v [#:on-opaque on-opaque]) -> (or/c list? #f)
  v : any/c
  on-opaque : (or/c 'error 'return-false 'skip) = 'error
procedure
(make-constructor-style-printer get-constructor 
                                get-contents)   
 -> (-> any/c output-port? (or/c #t #f 0 1) void?)
  get-constructor : (-> any/c (or/c symbol? string?))
  get-contents : (-> any/c sequence?)
value
prop:auto-custom-write : (struct-type-property/c 'constructor)
procedure
(explode-module-path-index mpi)
 -> (listof (or/c module-path? resolved-module-path? #f))
  mpi : module-path-index?
syntax
(phase-of-enclosing-module)
procedure
(make-variable-like-transformer  reference-stx 
                                [setter-stx])  
 -> set!-transformer?
  reference-stx : syntax?
  setter-stx : (or/c syntax? #f) = #f
procedure
(format-unique-id  lctx              
                   fmt               
                   v ...             
                  [#:source src      
                   #:props props     
                   #:cert cert]) -> identifier?
  lctx : (or/c syntax? #f)
  fmt : string?
  v : (or/c string? symbol? identifier? keyword? char? number?)
  src : (or/c syntax? #f) = #f
  props : (or/c syntax? #f) = #f
  cert : (or/c syntax? #f) = #f
procedure
(syntax-within? a b) -> boolean?
  a : syntax?
  b : syntax?
procedure
(syntax-length stx) -> exact-nonnegative-integer?
  stx : syntax?
procedure
(syntax-source-directory stx) -> (or/c path? #f)
  stx : syntax?
procedure
(syntax-source-file-name stx) -> (or/c path? #f)
  stx : syntax?
struct
(struct monitor (label)
    #:transparent)
  label : symbol?
struct
(struct monitor:proj monitor (label proj-label v)
    #:transparent)
  label : symbol?
  proj-label : symbol?
  v : any/c
struct
(struct monitor:call monitor (label
                              proj-label
                              f
                              app-label
                              kws
                              kw-args
                              args)
    #:transparent)
  label : symbol?
  proj-label : symbol?
  f : procedure?
  app-label : symbol?
  kws : (listof keyword?)
  kw-args : list?
  args : list?
struct
(struct monitor:return monitor (label
                                proj-label
                                f
                                app-label
                                kws
                                kw-args
                                args
                                rets)
    #:transparent)
  label : symbol?
  proj-label : symbol?
  f : procedure?
  app-label : symbol?
  kws : (listof keyword?)
  kw-args : list?
  args : list?
  rets : list?
procedure
(monitor/c monitor-allows? label c) -> contract?
  monitor-allows? : (-> monitor? boolean?)
  label : symbol?
  c : contract?
syntax
(call n a ...)
syntax
(ret n a ...)
syntax
(with-monitor contract-expr re-pat)
syntax
(label id contract-expr)
value
unix-socket-available? : boolean?
procedure
(unix-socket-connect socket-path) -> input-port? output-port?
  socket-path : unix-socket-path?
procedure
(unix-socket-path? v) -> boolean?
  v : any/c
syntax
(2dcond cond-content)
 
 cond-content = question-row
                body-row
                ⋮
              | question-row
                body-row
                ⋮
                else-row
                 
 question-row = empty-cell question-cell ⋯
              | empty-cell question-cell ⋯ else-cell
                 
     body-row = question-cell exprs-cell ⋯
                 
     else-row = question-cell exprs-cell ⋯ else-cell
                 
question-cell = ╔═════════════╗
                ║question-expr║
                ╚═════════════╝
                 
   empty-cell = ╔═══╗
                ║   ║
                ╚═══╝
                 
   exprs-cell = ╔═════════════╗
                ║expr expr ...║
                ╚═════════════╝
                 
    else-cell = ╔══════╗
                ║ else ║
                ╚══════╝
syntax
(2dmatch match-content)
 
  match-content = match-first-row
                  match-row
                  ⋮
                   
match-first-row = two-expr-cell match-pat-cell ⋯
                   
      match-row = match-pat-cell exprs-cell ⋯
                   
  two-expr-cell = ╔═════════════════╗
                  ║col-expr row-expr║
                  ╚═════════════════╝
                   
 match-pat-cell = ╔═════╗
                  ║ pat ║
                  ╚═════╝
                   
     exprs-cell = ╔═════════════╗
                  ║expr expr ...║
                  ╚═════════════╝
syntax
(2dmatch tabular-content)
 
tabular-content = tabular-row
                  ⋮
                | tabular-row
                  ⋮
                  style-cell
                   
    tabular-row = tabular-cell ⋯
                   
   tabular-cell = ╔════════════════╗
                  ║tabular-expr ...║
                  ╚════════════════╝
                   
     style-cell = ╔═════════════════╗
                  ║style-content ...║
                  ╚═════════════════╝
                   
  style-content = #:style style-expr
                | #:sep sep-expr
                | #:ignore-first-row
 
  style-expr : style?
  sep-expr : (or/c block? content? #f)
  tabular-expr : (or/c block? content?)
