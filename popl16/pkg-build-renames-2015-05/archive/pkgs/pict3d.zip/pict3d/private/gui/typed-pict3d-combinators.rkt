#lang typed/racket/base

(require (except-in racket/list flatten)
         (only-in racket/unsafe/ops unsafe-fx+)
         racket/fixnum
         racket/match
         racket/promise
         math/flonum
         math/base
         "../math.rkt"
         "../engine.rkt"
         "../shape.rkt"
         "../utils.rkt"
         "typed-user-types.rkt"
         "pict3d-struct.rkt"
         "parameters.rkt"
         "shape/light-grid.rkt"
         )

(provide
 ;; Types
 Pict3Ds
 ;; Parameters
 default-color
 default-emitted
 default-material
 current-color
 current-emitted
 current-material
 set-color
 set-emitted
 set-material
 ;; Naming, mapping, finding
 group
 basis
 group-tag
 group-contents
 replace-group
 replace-in-group
 ungroup
 remove-group
 remove-in-group
 map-group
 map-group/transform
 find-group-transforms
 find-group-transform
 ;; Basic shapes
 triangle
 ;triangle-mesh
 quad
 rectangle
 cube
 ellipsoid
 sphere
 sunlight
 light
 freeze
 ;; Transformations
 transform
 scale-x
 scale-y
 scale-z
 scale
 rotate-x
 rotate-y
 rotate-z
 rotate
 move-x
 move-y
 move-z
 move
 relocate
 local-transform
 rotate-x/center
 rotate-y/center
 rotate-z/center
 rotate/center
 scale-x/center
 scale-y/center
 scale-z/center
 scale/center
 set-origin
 find-group-transforms
 find-group-transform
 point-at
 ;; Information
 camera-transform
 bounding-rectangle
 center
 ;; Combining scenes
 combine
 pin
 weld
 join
 glue
 pin*
 weld*
 join*
 glue*
 ;; Testing
 plane-cull
 rect-cull
 frustum-cull
 ;; Other shapes
 arrow
 cylinder
 cone
 ;; Collision detection
 trace
 trace/normal
 trace/data
 surface
 surface/normal
 surface/data
 ;; Camera/view
 canvas-projection
 bitmap-projection
 camera->view
 camera-ray-dir
 ;;
 light-grid
 )

;; ===================================================================================================
;; Parameters

(define default-color (rgba 1.0 1.0 1.0 1.0))
(define default-emitted (emitted 0.0 0.0 0.0 0.0))
(define default-material (make-material 0.05 0.6 0.35 0.3))

(: current-color (Parameterof RGBA))
(define current-color (make-parameter default-color))

(: current-emitted (Parameterof Emitted))
(define current-emitted (make-parameter default-emitted))

(: current-material (Parameterof Material))
(define current-material (make-parameter default-material))

(: set-color (-> Pict3D RGBA Pict3D))
(define (set-color p c)
  (pict3d (scene-map-shapes (pict3d-scene p) (λ (a) (shape-set-color a c)))))

(: set-emitted (-> Pict3D Emitted Pict3D))
(define (set-emitted p e)
  (pict3d (scene-map-shapes (pict3d-scene p) (λ (a) (shape-set-emitted a e)))))

(: set-material (-> Pict3D Material Pict3D))
(define (set-material p m)
  (pict3d (scene-map-shapes (pict3d-scene p) (λ (a) (shape-set-material a m)))))

;; ===================================================================================================
;; Union, naming, mapping, finding

(define-type Pict3Ds (U Pict3D (Listof Pict3Ds)))

(require/typed
 racket/list
 [flatten  (-> (Listof Pict3Ds) (Listof Pict3D))])

(: combine (-> Pict3Ds * Pict3D))
(define (combine . ps)
  (pict3d (scene-union* (map pict3d-scene (flatten ps)))))

(: group (-> Pict3D (U #f Tag) Pict3D))
(define (group p n)
  (if n (pict3d (make-group-scene (pict3d-scene p) n)) p))

(: basis (-> Tag Affine Pict3D))
(define (basis n t)
  (pict3d (make-trans-scene (make-group-scene empty-scene n) t)))

(: group-tag (-> Pict3D (U #f Tag)))
(define (group-tag p)
  (define s (pict3d-scene p))
  (if (group-scene? s)
      (group-scene-tag s)
      #f))

(: group-contents (-> Pict3D Pict3D))
(define (group-contents p)
  (define s (pict3d-scene p))
  (if (group-scene? s)
      (pict3d (group-scene-scene s))
      p))

(: replace-group (-> Pict3D (Listof Tag) (-> Pict3D Pict3D) Pict3D))
(define (replace-group p n f)
  (if (empty? n)
      (f p)
      (pict3d (scene-replace-group (pict3d-scene p) n (λ (s) (pict3d-scene (f (pict3d s))))))))

(: replace-in-group (-> Pict3D (Listof Tag) (-> Pict3D Pict3D) Pict3D))
(define (replace-in-group p n f)
  (replace-group p n (λ (p) (group (f (group-contents p)) (group-tag p)))))

(: ungroup (-> Pict3D (Listof Tag) Pict3D))
(define (ungroup p n)
  (replace-group p n group-contents))

(: remove-group (-> Pict3D (Listof Tag) Pict3D))
(define (remove-group p n)
  (replace-group p n (λ (_) empty-pict3d)))

(: remove-in-group (-> Pict3D (Listof Tag) Pict3D))
(define (remove-in-group p n)
  (replace-in-group p n (λ (_) empty-pict3d)))

(: map-group (All (A) (-> Pict3D (Listof Tag) (-> Pict3D A) (Listof A))))
(define (map-group p n f)
  (if (empty? n)
      (list (f p))
      (scene-map-group (pict3d-scene p) n (λ ([s : group-scene]) (f (pict3d s))))))

(: map-group/transform (All (A) (-> Pict3D (Listof Tag) (-> Affine Pict3D A) (Listof A))))
(define (map-group/transform p n f)
  (if (empty? n)
      (list (f identity-affine p))
      (scene-map-group/transform (pict3d-scene p) n (λ ([t : FlAffine3] [s : group-scene])
                                                      (f (flaffine3->affine t) (pict3d s))))))

(: find-group-transforms (-> Pict3D (Listof Tag) (Listof Affine)))
(define (find-group-transforms p n)
  (map-group/transform p n (λ ([t : Affine] _) t)))

(: find-group-transform (-> Pict3D (Listof Tag) Affine))
(define (find-group-transform p n)
  (: fail (-> Index Nothing))
  (define (fail m)
    (error 'find-group-transform "expected one group with path ~e; given a Pict3D with ~a such groups"
           n m))
  (define ts (find-group-transforms p n))
  (cond [(empty? ts)  (fail 0)]
        [(empty? (rest ts))  (first ts)]
        [else  (fail (length ts))]))

;; ===================================================================================================
;; Information

(: camera-transform (-> Pict3D (U #f Affine)))
(define (camera-transform p)
  (define ts (scene-map-group/transform (pict3d-scene p) '(camera) (λ ([t : FlAffine3] _) t)))
  (and (pair? ts) (flaffine3->affine (first ts))))

(: bounding-rectangle (-> Pict3D (Values (U #f Pos) (U #f Pos))))
(define (bounding-rectangle p)
  (define r (maybe-bbox-rect (scene-visible-bbox/badness (pict3d-scene p) tight-badness)))
  (if (flrect3? r)
      (values (call/flv3-values (flrect3-min r) pos)
              (call/flv3-values (flrect3-max r) pos))
      (values #f #f)))

(: center (-> Pict3D (U #f Pos)))
(define (center p)
  (define-values (v1 v2) (bounding-rectangle p))
  (if (and v1 v2) (pos-between v1 v2 0.5) #f))

;; ===================================================================================================
;; Basic shapes

(: interpret-vertex (-> (U Pos Vertex) FlV4 FlV4 Material
                        (Values FlV3 (U #f FlV3) FlV4 FlV4 Material)))
(define (interpret-vertex vert cc ce cm)
  (cond [(pos? vert)
         (values vert #f cc ce cm)]
        [else
         (match-define (Vertex v n c e m) vert)
         (values v n (if c c cc) (if e e ce) (if m m cm))]))

(: standard-transform (-> Pos (U Pos Dir Real) FlAffine3))
(define (standard-transform v1 v2)
  (if (pos? v2)
      (flt3compose (move-flt3 (flv3* (flv3+ v1 v2) 0.5))
                   (scale-flt3 (flv3* (flv3- v2 v1) 0.5)))
      (flt3compose (move-flt3 v1)
                   (scale-flt3 (if (real? v2) (fl v2) v2)))))

;; ---------------------------------------------------------------------------------------------------
;; Triangle

(: triangle (->* [(U Pos Vertex) (U Pos Vertex) (U Pos Vertex)] [#:back? Any] Pict3D))
(define (triangle vert1 vert2 vert3 #:back? [back? #f])
  (define cc (current-color))
  (define ce (current-emitted))
  (define cm (current-material))
  (define-values (v1 n1 c1 e1 m1) (interpret-vertex vert1 cc ce cm))
  (define-values (v2 n2 c2 e2 m2) (interpret-vertex vert2 cc ce cm))
  (define-values (v3 n3 c3 e3 m3) (interpret-vertex vert3 cc ce cm))
  (define norm (flv3triangle-normal v1 v2 v3))
  (cond [norm
         (pict3d
          (make-triangle-shape
           (vtx v1 (if n1 n1 norm) c1 e1 m1)
           (vtx v2 (if n2 n2 norm) c2 e2 m2)
           (vtx v3 (if n3 n3 norm) c3 e3 m3)
           (and back? #t)))]
        [else  empty-pict3d]))
#|
;; ---------------------------------------------------------------------------------------------------
;; Triangle mesh

(: smooth-normal (-> (Vectorof (U Pos Vertex)) (Vectorof Index) (Vectorof (Listof Index)) Index
                     (U #f FlV3)))
(define (smooth-normal verts idxs vert-idxs j)
  (define vert (vector-ref verts j))
  (define n
    (for/fold ([s : FlV3  zero-flv3]) ([i  (in-list (vector-ref vert-idxs j))])
      (define base-i (fx* 3 (fxquotient i 3)))
      (define mod-i (fx- i base-i))
      (define j0 (vector-ref idxs (fx+ base-i mod-i)))
      (define j1 (vector-ref idxs (fx+ base-i (fxmodulo (fx+ mod-i 1) 3))))
      (define j2 (vector-ref idxs (fx+ base-i (fxmodulo (fx+ mod-i 2) 3))))
      (define v0 (vector-ref verts j0))
      (define v1 (vector-ref verts j1))
      (define v2 (vector-ref verts j2))
      (let ([v0  (if (vertex? v0) (vertex-pos v0) v0)]
            [v1  (if (vertex? v1) (vertex-pos v1) v1)]
            [v2  (if (vertex? v2) (vertex-pos v2) v2)])
        (define n (flv3triangle-normal v0 v1 v2))
        (define dv10 (flv3- v1 v0))
        (define dv20 (flv3- v2 v0))
        (define d (acos (/ (flv3dot dv10 dv20) (flv3mag dv10) (flv3mag dv20))))
        (if (and n (< 0.0 d +inf.0))
            (flv3+ s (flv3* n d))
            s))))
  (flv3normalize n))

(define empty-vtx (vtx zero-flv3 zero-flv3 zero-flv4 zero-flv4 zero-flv4))

(define max-index 268435455)

(: triangle-mesh (->* [(Listof (U Pos Vertex)) (Listof (Listof Integer))] [#:back? Any] Pict3D))
(define (triangle-mesh orig-verts idxss #:back? [back? #f])
  (define m (assert (for/fold ([m : Nonnegative-Fixnum  0]) ([idxs  (in-list idxss)])
                      (unsafe-fx+ m (length idxs)))
                    index?))
  
  (define idxs ((inst make-vector Index) m 0))
  
  (define-values (vs-lst _1 _2)
    (let* ([verts  (list->vector orig-verts)]
           [n  (vector-length verts)]
           [vtx-map  ((inst make-vector Index) n max-index)])
      (for*/fold ([vs : (Listof (U Pos Vertex))  empty]
                  [i : Index  0]
                  [next-j : Index  0])
                 ([js  (in-list idxss)]
                  [_   (in-value
                        (when (not (= 3 (length js)))
                          (error 'bad)))]
                  [j   (in-list js)])
        (cond
          [(and (<= 0 j) (< j n))
           (define new-j (vector-ref vtx-map j))
           (cond [(< new-j max-index)
                  (vector-set! idxs i new-j)
                  (values vs (assert (unsafe-fx+ i 1) index?) next-j)]
                 [else
                  (vector-set! vtx-map j next-j)
                  (vector-set! idxs i next-j)
                  (define vert (vector-ref verts j))
                  (values (cons vert vs)
                          (assert (unsafe-fx+ i 1) index?)
                          (assert (unsafe-fx+ next-j 1) index?))])]
          [else
           (error 'bad)]))))
  
  (define verts (list->vector (reverse vs-lst)))
  (define n (vector-length verts))
  
  (define vert-idxs ((inst make-vector (Listof Index)) n empty))
  (let loop ([i : Nonnegative-Fixnum  0])
    (when (< i m)
      (define j (vector-ref idxs i))
      (define is (vector-ref vert-idxs j))
      (vector-set! vert-idxs j (cons i is))
      (loop (+ i 1))))
  
  (define cc (current-color))
  (define ce (current-emitted))
  (define cm (current-material))
  (define vtxs ((inst make-vector vtx) n empty-vtx))
  (for ([i   (in-range m)])
    (define j (vector-ref idxs i))
    (define vert (vector-ref verts j))
    (define n (let* ([n  (if (vertex? vert) (vertex-normal vert) #f)]
                     [n  (if n n (smooth-normal verts idxs vert-idxs j))])
                (if n n +z)))
    (cond [(vertex? vert)
           (match-define (Vertex v _ c e m) vert)
           (vector-set! vtxs j (vtx v n (if c c cc) (if e e ce) (if m m cm)))]
          [else
           (vector-set! vtxs j (vtx vert n cc ce cm))]))
  
  (pict3d (make-triangle-mesh-shape vtxs idxs (and back? #t))))
|#
;; ---------------------------------------------------------------------------------------------------
;; Quad

(: quad (->* [(U Pos Vertex) (U Pos Vertex) (U Pos Vertex) (U Pos Vertex)] [#:back? Any] Pict3D))
(define (quad vert1 vert2 vert3 vert4 #:back? [back? #f])
  (define cc (current-color))
  (define ce (current-emitted))
  (define cm (current-material))
  (define-values (v1 n1 c1 e1 m1) (interpret-vertex vert1 cc ce cm))
  (define-values (v2 n2 c2 e2 m2) (interpret-vertex vert2 cc ce cm))
  (define-values (v3 n3 c3 e3 m3) (interpret-vertex vert3 cc ce cm))
  (define-values (v4 n4 c4 e4 m4) (interpret-vertex vert4 cc ce cm))
  (define norm (flv3polygon-normal (vector v1 v2 v3 v3)))
  (cond [norm
         (pict3d
          (make-quad-shape
           (vtx v1 (if n1 n1 norm) c1 e1 m1)
           (vtx v2 (if n2 n2 norm) c2 e2 m2)
           (vtx v3 (if n3 n3 norm) c3 e3 m3)
           (vtx v4 (if n4 n4 norm) c4 e4 m4)
           (and back? #t)))]
        [else  empty-pict3d]))

;; ---------------------------------------------------------------------------------------------------
;; Rectangle

(: rectangle (->* [Pos (U Pos Dir Real)] [#:inside? Any] Pict3D))
(define (rectangle v1 v2 #:inside? [inside? #f])
  (define b
    (cond [(pos? v2)  (flrect3 v1 v2)]
          [(real? v2)
           (define r (abs (fl v2)))
           (call/flv3-values v1
             (λ (x y z)
               (FlRect3 (flv3 (- x r) (- y r) (- z r))
                        (flv3 (+ x r) (+ y r) (+ z r)))))]
          [else
           (flrect3 (flv3- v1 v2)
                    (flv3+ v1 v2))]))
  (define cc (current-color))
  (define ce (current-emitted))
  (define cm (current-material))
  (pict3d (make-rectangle-shape b cc ce cm (and inside? #t))))

(: cube (->* [Pos Real] [#:inside? Any] Pict3D))
(define cube rectangle)

;; ---------------------------------------------------------------------------------------------------
;; Ellipsoid

(: ellipsoid (->* [Pos (U Pos Dir Real)] [#:inside? Any] Pict3D))
(define (ellipsoid v1 v2 #:inside? [inside? #f])
  (define t (standard-transform v1 v2))
  (define cc (current-color))
  (define ce (current-emitted))
  (define cm (current-material))
  (pict3d (make-sphere-shape t cc ce cm (and inside? #t))))

(: sphere (->* [Pos Real] [#:inside? Any] Pict3D))
(define sphere ellipsoid)

;; ---------------------------------------------------------------------------------------------------
;; Directional light

(: sunlight (->* [Dir] [Emitted] Pict3D))
(define (sunlight dv [e  (emitted 1.0 1.0 1.0 1.0)])
  (let ([dv : (U #f FlV3)  (flv3normalize dv)])
    (if dv
        (pict3d (make-directional-light-shape e dv))
        empty-pict3d)))

;; ---------------------------------------------------------------------------------------------------
;; Point light

(: light (->* [Pos] [Emitted #:min-radius Real #:max-radius Real] Pict3D))
(define (light v
               [e  (emitted 1.0 1.0 1.0 1.0)]
               #:min-radius [r0 0.0]
               #:max-radius [r1 (flsqrt (* 20.0 (emitted-intensity e)))])
  (let ([r0  (abs (fl r0))]
        [r1  (abs (fl r1))])
    (if (< r0 r1)
        (let ([t : FlAffine3  (move-flt3 v)])
          (pict3d (make-point-light-shape e t r0 r1)))
        empty-pict3d)))

;; ---------------------------------------------------------------------------------------------------
;; Efficiency

(: freeze (-> Pict3D Pict3D))
(define (freeze p)
  (define s (pict3d-scene p))
  (cond [(empty-scene? s)  p]
        [else
         (combine
          (pict3d (make-frozen-scene-shape s))
          (for/list : (Listof Pict3D) ([nt  (in-list (scene-group-transforms s 'empty))])
            (basis (car nt) (flaffine3->affine (cdr nt)))))]))

;; ===================================================================================================
;; Transformations

(: transform (-> Pict3D Affine Pict3D))
(define (transform p t)
  (if (eq? t identity-affine) p (pict3d (make-trans-scene (pict3d-scene p) t))))

(: make-transformer (All (A) (-> (-> A FlAffine3)
                                 (case-> (-> A Affine)
                                         (-> Pict3D A Pict3D)))))
(define (make-transformer f)
  (case-lambda
    [(v)  (flaffine3->affine (f v))]
    [(p v)  (transform p (flaffine3->affine (f v)))]))

;; ---------------------------------------------------------------------------------------------------
;; Scale

(: check-real-scale (-> Symbol Real Flonum))
(define (check-real-scale name v)
  (let ([v  (fl v)])
    (if (= v 0.0)
        (raise-argument-error name "nonzero scale factor" v)
        v)))

(: check-dir-scale (-> Symbol Dir FlV3))
(define (check-dir-scale name v)
  (call/flv3-values v
    (λ (x y z)
      (if (or (= x 0.0) (= y 0.0) (= z 0.0))
          (raise-argument-error name "scale direction with nonzero components" v)
          v))))

(: check-scale (case-> (-> Symbol Real Flonum)
                       (-> Symbol Dir FlV3)
                       (-> Symbol (U Real Dir) (U Flonum FlV3))))
(define (check-scale name v)
  (if (real? v)
      (check-real-scale name v)
      (check-dir-scale name v)))

(define scale-x (make-transformer (λ ([v : Real]) (scale-x-flt3 (check-real-scale 'scale-x v)))))
(define scale-y (make-transformer (λ ([v : Real]) (scale-y-flt3 (check-real-scale 'scale-y v)))))
(define scale-z (make-transformer (λ ([v : Real]) (scale-z-flt3 (check-real-scale 'scale-z v)))))
(define scale (make-transformer (λ ([v : (U Real Dir)]) (scale-flt3 (check-scale 'scale v)))))

;; ---------------------------------------------------------------------------------------------------
;; Translate

(define move-x
  (make-transformer (λ ([v : Real])
                      (let ([v  (fl v)])
                        (if (= v 0.0) identity-affine (move-x-flt3 v))))))

(define move-y
  (make-transformer (λ ([v : Real])
                      (let ([v  (fl v)])
                        (if (= v 0.0) identity-affine (move-y-flt3 v))))))

(define move-z
  (make-transformer (λ ([v : Real])
                      (let ([v  (fl v)])
                        (if (= v 0.0) identity-affine (move-z-flt3 v))))))

(define move (make-transformer move-flt3))

;; ---------------------------------------------------------------------------------------------------
;; Rotate

(: check-axis (-> Symbol Dir FlV3))
(define (check-axis name orig-v)
  (define v (flv3normalize orig-v))
  (if v v (raise-argument-error name "nonzero axis vector" v)))

(define rotate-x
  (make-transformer (λ ([a : Real])
                      (let ([a  (fl a)])
                        (if (= a 0.0) identity-affine (rotate-x-flt3 (degrees->radians a)))))))

(define rotate-y
  (make-transformer (λ ([a : Real])
                      (let ([a  (fl a)])
                        (if (= a 0.0) identity-affine (rotate-y-flt3 (degrees->radians a)))))))

(define rotate-z
  (make-transformer (λ ([a : Real])
                      (let ([a  (fl a)])
                        (if (= a 0.0) identity-affine (rotate-z-flt3 (degrees->radians a)))))))

(: rotate (case-> (-> Dir Real Affine)
                  (-> Pict3D Dir Real Pict3D)))
(define rotate
  (case-lambda
    [(v a)
     (let ([a  (fl a)]
           [v : FlV3  (check-axis 'rotate v)])
       (if (= a 0.0) identity-affine (flaffine3->affine (rotate-flt3 v (degrees->radians a)))))]
    [(p v a)
     (transform p (rotate v a))]))

;; ---------------------------------------------------------------------------------------------------
;; Change of basis

(: relocate (case-> (-> Affine Affine Affine)
                    (-> Pict3D Affine Affine Pict3D)))
(define relocate
  (case-lambda
    [(t1 t2)  (affine-compose t2 (affine-inverse t1))]
    [(pict t1 t2)  (transform pict (relocate t1 t2))]))

(: local-transform (case-> (-> Affine Affine Affine)
                           (-> Pict3D Affine Affine Pict3D)))
(define local-transform
  (case-lambda
    [(t local-t)  (affine-compose local-t (relocate local-t t))]
    [(pict t local-t)  (transform pict (local-transform t local-t))]))

;; ---------------------------------------------------------------------------------------------------
;; Local scaling

(: center-or-origin (-> Pict3D Pos))
(define (center-or-origin pict)
  (define v (center pict))
  (if v v origin))

(: scale/center (->* [Pict3D (U Real Dir)] [Pos] Pict3D))
(define (scale/center pict dv [v (center-or-origin pict)])
  (local-transform pict (scale dv) (move (pos- v origin))))

(: scale-x/center (->* [Pict3D Real] [Pos] Pict3D))
(define (scale-x/center pict dx [v (center-or-origin pict)])
  (scale/center pict (dir dx 1 1) v))

(: scale-y/center (->* [Pict3D Real] [Pos] Pict3D))
(define (scale-y/center pict dy [v (center-or-origin pict)])
  (scale/center pict (dir 1 dy 1) v))

(: scale-z/center (->* [Pict3D Real] [Pos] Pict3D))
(define (scale-z/center pict dz [v (center-or-origin pict)])
  (scale/center pict (dir 1 1 dz) v))

;; ---------------------------------------------------------------------------------------------------
;; Local rotation

(: rotate/center (->* [Pict3D Dir Real] [Pos] Pict3D))
(define (rotate/center pict axis angle [v (center-or-origin pict)])
  (local-transform pict (rotate axis angle) (move (pos- v origin))))

(: rotate-x/center (->* [Pict3D Real] [Pos] Pict3D))
(define (rotate-x/center pict angle [v (center-or-origin pict)])
  (rotate/center pict +x angle v))

(: rotate-y/center (->* [Pict3D Real] [Pos] Pict3D))
(define (rotate-y/center pict angle [v (center-or-origin pict)])
  (rotate/center pict +y angle v))

(: rotate-z/center (-> Pict3D Real Pict3D))
(define (rotate-z/center pict angle [v (center-or-origin pict)])
  (rotate/center pict +z angle v))

;; ---------------------------------------------------------------------------------------------------
;; Point at/to

(: point-at (->* [Pos (U Pos Dir)] [#:angle Real #:up Dir #:normalize? Any] Affine))
(define (point-at from to 
                  #:angle [angle 0.0]
                  #:up [up +z]
                  #:normalize? [normalize? #t])
  (define z-axis (if (dir? to) to (pos- to from)))
  (if (= (dir-dist z-axis) 0.0)
      (raise-argument-error 'point-at "nonzero look direction" 1 from to)
      (flaffine3->affine
       (point-at-flt3 from z-axis (degrees->radians (fl angle)) up (and normalize? #t)))))

;; ===================================================================================================
;; Combining scenes

(: set-origin (-> Pict3D (Listof Tag) Pict3D))
(define (set-origin p n)
  (transform p (affine-inverse (find-group-transform p n))))

(: pin* (->* [Pict3D (Listof Tag) Pict3D] [(Listof Tag)] Pict3D))
(define (pin* p1 n1 p2 [n2 empty])
  (let ([p2  (ungroup (set-origin p2 n2) n2)])
    (replace-in-group p1 n1 (λ ([p : Pict3D]) (combine p p2)))))

(: weld* (->* [Pict3D (Listof Tag) Pict3D] [(Listof Tag)] Pict3D))
(define (weld* p1 n1 p2 [n2 empty])
  (let ([p2  (ungroup (set-origin p2 n2) n2)])
    (replace-group p1 n1 (λ ([p : Pict3D]) (combine (group-contents p) p2)))))

(: pin (->* [Pict3D (Listof Tag) Pict3D] [(Listof Tag)] Pict3D))
(define (pin p1 n1 p2 [n2 empty])
  (check-pin-multi 'pin p1 n1)
  (pin* p1 n1 p2 n2))

(: weld (->* [Pict3D (Listof Tag) Pict3D] [(Listof Tag)] Pict3D))
(define (weld p1 n1 p2 [n2 empty])
  (check-pin-multi 'weld p1 n1)
  (weld* p1 n1 p2 n2))

(: check-pin-multi : Symbol Pict3D (Listof Tag) -> Void)
(define (check-pin-multi pin p1 n1)
  (define ps (map-group p1 n1 (λ ([p : Pict3D]) p)))
  (define n (length ps))
  (unless (= n 1)
    (error pin "~v groups with path ~v exist \
(if this is intentional, use ~a* instead)"
           n n1 pin)))

(: join (->* [Pict3D (Listof Tag) Pict3D] [(Listof Tag)] Pict3D))
(define (join p1 n1 p2 [n2 empty])
  (combine
   p1
   (relocate p2
             (find-group-transform p2 n2)
             (find-group-transform p1 n1))))

(: glue (->* [Pict3D (Listof Tag) Pict3D] [(Listof Tag)] Pict3D))
(define (glue p1 n1 p2 [n2 empty])
  (combine
   (ungroup p1 n1)
   (relocate (ungroup p2 n2)
             (find-group-transform p2 n2)
             (find-group-transform p1 n1))))

(: join* (->* [Pict3D (Listof Tag) Pict3D] [(Listof Tag)] Pict3D))
(define (join* p1 n1 p2 [n2 empty])
  (let ([p2 (set-origin p2 n2)])
    (combine
     p1
     (map-group/transform p1 n1 (λ ([t1 : Affine] _) (transform p2 t1))))))

(: glue* (->* [Pict3D (Listof Tag) Pict3D] [(Listof Tag)] Pict3D))
(define (glue* p1 n1 p2 [n2 empty])
  (let ([p2 (ungroup (set-origin p2 n2) n2)])
    (combine
     (ungroup p1 n1)
     (map-group/transform p1 n1 (λ ([t1 : Affine] _) (transform p2 t1))))))

;; ===================================================================================================
;; Testing combinators

(: plane-cull (-> Pict3D FlPlane3 Pict3D))
(define (plane-cull s p)
  (pict3d (scene-plane-cull (pict3d-scene s) p)))

(: rect-cull (-> Pict3D FlRect3 Pict3D))
(define (rect-cull s b)
  (pict3d (scene-rect-cull (pict3d-scene s) b)))

(: frustum-cull (-> Pict3D FlTransform3 Pict3D))
(define (frustum-cull s t)
  (pict3d (scene-frustum-cull (pict3d-scene s) t)))

;; ===================================================================================================
;; Other shapes

;; ---------------------------------------------------------------------------------------------------
;; Arrows

(define (up-arrow)
  (freeze
   (combine
    (rectangle (pos #i-1/64 #i-1/64 #i0)
               (pos #i1/64 #i1/64 #i56/64))
    (let ([p  (triangle (pos #i2/64 #i2/64 #i56/64)
                        (pos #i-2/64 #i2/64 #i56/64)
                        (pos #i0 #i0 #i1))])
      (combine p (rotate-z p 90.0) (rotate-z p 180.0) (rotate-z p 270.0)))
    (quad (pos #i2/64 #i2/64 #i56/64)
          (pos #i2/64 #i-2/64 #i56/64)
          (pos #i-2/64 #i-2/64 #i56/64)
          (pos #i-2/64 #i2/64 #i56/64)))))

(: arrow (->* [Pos (U Pos Dir)] [#:normalize? Any] Pict3D))
(define (arrow from to #:normalize? [normalize? #f])
  (transform (up-arrow) (point-at from to #:normalize? normalize?)))

;; ---------------------------------------------------------------------------------------------------
;; Cylinder

(: standard-cylinder-scene (-> Boolean Natural Scene))
(define (standard-cylinder-scene inside? n)
  (define c (current-color))
  (define e (current-emitted))
  (define m (current-material))
  (scene-union*
   (for/list ([i  (in-range n)])
     (define t1 (* (* 2.0 pi) (/ (fl i) (fl n))))
     (define t2 (* (* 2.0 pi) (/ (+ (fl i) 1.0) (fl n))))
     (define x1 (flcos t1))
     (define y1 (flsin t1))
     (define x2 (flcos t2))
     (define y2 (flsin t2))
     (scene-union*
      (list
       ;; Top
       (make-triangle-shape
        (vtx (flv3 x1 y1 1.0) +z-flv3 c e m)
        (vtx (flv3 x2 y2 1.0) +z-flv3 c e m)
        (vtx +z-flv3 +z-flv3 c e m)
        inside?)
       ;; Sides
       (make-quad-shape
        (vtx (flv3 x1 y1 -1.0) (flv3 x1 y1 0.0) c e m)
        (vtx (flv3 x2 y2 -1.0) (flv3 x2 y2 0.0) c e m)
        (vtx (flv3 x2 y2 +1.0) (flv3 x2 y2 0.0) c e m)
        (vtx (flv3 x1 y1 +1.0) (flv3 x1 y1 0.0) c e m)
        inside?)
       ;; Bottom
       (make-triangle-shape
        (vtx (flv3 x2 y2 -1.0) -z-flv3 c e m)
        (vtx (flv3 x1 y1 -1.0) -z-flv3 c e m)
        (vtx -z-flv3 -z-flv3 c e m)
        inside?))))))

(: cylinder (->* [Pos (U Pos Dir Real)] [#:inside? Any #:segments Natural] Pict3D))
(define (cylinder v1 v2 #:inside? [inside? #f] #:segments [n 32])
  (freeze (pict3d (make-trans-scene (standard-cylinder-scene (and inside? #t) n)
                                    (standard-transform v1 v2)))))

;; ---------------------------------------------------------------------------------------------------
;; Cone

(: standard-cone-scene (-> Boolean Natural Boolean Scene))
(define (standard-cone-scene inside? n smooth?)
  (define nx (/ 1.0 (flsqrt (+ (sqr 1.0) (sqr 0.5)))))
  (define ny (/ 0.5 (flsqrt (+ (sqr 1.0) (sqr 0.5)))))
  (define c (current-color))
  (define e (current-emitted))
  (define m (current-material))
  (scene-union*
   (for/list ([i  (in-range n)])
     (define t0 (* (* 2.0 pi) (/ (+ (fl i) 0.5) (fl n))))
     (define t1 (* (* 2.0 pi) (/ (fl i) (fl n))))
     (define t2 (* (* 2.0 pi) (/ (+ (fl i) 1.0) (fl n))))
     (define x0 (flcos t0))
     (define y0 (flsin t0))
     (define x1 (flcos t1))
     (define y1 (flsin t1))
     (define x2 (flcos t2))
     (define y2 (flsin t2))
     (scene-union
      ;; Sides
      (make-triangle-shape
       (vtx +z-flv3 (if smooth? +z-flv3 (flv3 (* nx x0) (* nx y0) ny)) c e m)
       (vtx (flv3 x1 y1 -1.0) (flv3 (* nx x1) (* nx y1) ny) c e m)
       (vtx (flv3 x2 y2 -1.0) (flv3 (* nx x2) (* nx y2) ny) c e m)
       inside?)
      ;; Bottom
      (make-triangle-shape
       (vtx (flv3 x2 y2 -1.0) -z-flv3 c e m)
       (vtx (flv3 x1 y1 -1.0) -z-flv3 c e m)
       (vtx -z-flv3 -z-flv3 c e m)
       inside?)))))

(: cone (->* [Pos (U Pos Dir Real)] [#:inside? Any #:segments Natural #:smooth? Any] Pict3D))
(define (cone v1 v2 #:inside? [inside? #f] #:segments [n 32] #:smooth? [smooth? #f])
    (freeze (pict3d (make-trans-scene (standard-cone-scene (and inside? #t) n (and smooth? #t))
                                      (standard-transform v1 v2)))))

;; ===================================================================================================
;; Collision detection

(: trace (-> Pict3D Pos (U Pos Dir) (U #f Pos)))
(define (trace p v1 to)
  (when (= +inf.0 (flv3mag^2 v1))
    (raise-argument-error 'trace "Pos with finite squared magnitude" 1 p v1 to))
  (when (= +inf.0 (flv3mag^2 to))
    (raise-argument-error 'trace "Pos or Dir with finite squared magnitude" 2 p v1 to))
  (define-values (time data)
    (cond [(pos? to)  (scene-line-intersect (pict3d-scene p) v1 (flv3- to v1))]
          [else       (scene-ray-intersect  (pict3d-scene p) v1 to)]))
  (and time data (flv3->pos (trace-data-pos (force data)))))

(: trace/data (-> Pict3D Pos (U Pos Dir) (U #f Surface-Data)))
(define (trace/data p v1 to)
  (when (= +inf.0 (flv3mag^2 v1))
    (raise-argument-error 'trace/data "Pos with finite squared magnitude" 1 p v1 to))
  (when (= +inf.0 (flv3mag^2 to))
    (raise-argument-error 'trace/data "Pos or Dir with finite squared magnitude" 2 p v1 to))
  (define-values (time data)
    (cond [(pos? to)  (scene-line-intersect (pict3d-scene p) v1 (flv3- to v1))]
          [else       (scene-ray-intersect  (pict3d-scene p) v1 to)]))
  (and time data (trace-data->surface-data time (force data))))

(: trace/normal (-> Pict3D Pos (U Pos Dir) (Values (U #f Pos) (U #f Dir))))
(define (trace/normal p v1 to)
  (define data (trace/data p v1 to))
  (cond [data  (values (surface-data-pos data)
                       (surface-data-normal data))]
        [else  (values #f #f)]))

(: find-surface-endpoints (-> Pict3D Dir (Values (U #f Pos) (U #f Pos))))
(define (find-surface-endpoints p dv)
  (define-values (v1 v2) (bounding-rectangle p))
  (define m (dir-dist dv))
  (cond
    [(and v1 v2 (> m 0.0))
     (define v (pos-between v1 v2 0.5))
     (define r (dir-dist (pos- v2 v1)))
     (values v (pos+ v (dir-scale dv (/ r m))))]
    [else
     (values #f #f)]))

(: surface (->* [Pict3D Dir] [#:inside? Any] (U #f Pos)))
(define (surface p dv #:inside? [inside? #f])
  (define-values (vin vout) (find-surface-endpoints p dv))
  (and vin vout
       (if inside?
           (trace p vin vout)
           (trace p vout vin))))

(: surface/data (->* [Pict3D Dir] [#:inside? Any] (U #f Surface-Data)))
(define (surface/data p dv #:inside? [inside? #f])
  (define-values (vin vout) (find-surface-endpoints p dv))
  (if (and vin vout)
      (if inside?
          (trace/data p vin vout)
          (trace/data p vout vin))
      #f))

(: surface/normal (->* [Pict3D Dir] [#:inside? Any] (Values (U #f Pos) (U #f Dir))))
(define (surface/normal p dv #:inside? [inside? #f])
  (define data (surface/data  p dv #:inside? inside?))
  (cond [data  (values (surface-data-pos data)
                       (surface-data-normal data))]
        [else  (values #f #f)]))

;; ===================================================================================================
;; Camera/view

(: canvas-projection
   (->* []
        [#:width Integer #:height Integer #:z-near Real #:z-far Real #:fov Real]
        FlTransform3))
(define (canvas-projection #:width [width (current-pict3d-width)]
                           #:height [height (current-pict3d-height)]
                           #:z-near [z-near (current-pict3d-z-near)]
                           #:z-far [z-far (current-pict3d-z-far)]
                           #:fov [fov (current-pict3d-fov)])
  (let ([width   (fl (max 1 width))]
        [height  (fl (max 1 height))]
        [z-near  (max default-pict3d-z-near (min default-pict3d-z-far (fl z-near)))]
        [z-far   (max default-pict3d-z-near (min default-pict3d-z-far (fl z-far)))]
        [fov     (max 1.0 (min 179.0 (fl fov)))])
    (perspective-flt3/viewport width height (degrees->radians fov) z-near z-far)))

(: bitmap-projection
   (->* []
        [#:width Integer #:height Integer #:z-near Real #:z-far Real #:fov Real]
        FlTransform3))
;; Like canvas projection but upside-down because OpenGL origin is lower-left
(define (bitmap-projection #:width [width (current-pict3d-width)]
                           #:height [height (current-pict3d-height)]
                           #:z-near [z-near (current-pict3d-z-near)]
                           #:z-far [z-far (current-pict3d-z-far)]
                           #:fov [fov (current-pict3d-fov)])
  (flt3compose
   (scale-flt3 +x-y+z-flv3)
   (canvas-projection #:width width #:height height #:z-near z-near #:z-far z-far #:fov fov)))

(: camera->view (-> Affine Affine))
;; Inverts a camera basis to get a view transform; also negates the y and z axes
;; In OpenGL, +z is toward the viewer and +y is up
;; In Pict3D, +z is away from the viewer and +y is down (like typical bitmap coordinates)
(define (camera->view t)
  (flaffine3->affine
   (flt3compose (scale-flt3 +x-y-z-flv3)
                (flt3inverse t))))

(: camera-ray-dir
   (->* [Affine]
        [#:width Integer #:height Integer #:z-near Real #:z-far Real #:fov Real]
        (-> Real Real Dir)))
(define (camera-ray-dir t
                        #:width [width (current-pict3d-width)]
                        #:height [height (current-pict3d-height)]
                        #:z-near [z-near (current-pict3d-z-near)]
                        #:z-far [z-far (current-pict3d-z-far)]
                        #:fov [fov (current-pict3d-fov)])
  (define unview (flt3inverse (camera->view t)))
  (define unproj
    (flt3inverse
     (bitmap-projection #:width width #:height height #:z-near z-near #:z-far z-far #:fov fov)))
  (define w (fl (max 1 width)))
  (define h (fl (max 1 height)))
  (λ (x y)
    ;; View direction
    (define clip-x (* (- (/ (fl x) w) 0.5) 2.0))
    (define clip-y (* (- (/ (fl y) h) 0.5) 2.0))
    (define dv
      (let ([dv  (flt3apply/pos unproj (flv3 clip-x clip-y -1.0))])
        (flt3apply/dir unview dv)))
    (define n (flv3normalize dv))
    (if n
        (call/flv3-values dv dir)
        (error 'camera-ray-dir "view transform inverse ~e returned zero direction ~e" unview dv))))

;; ===================================================================================================

(: light-grid (->* [Emitted Emitted Emitted] [Real] Pict3D))
(define (light-grid ex ey ez [s 1.0])
  (pict3d (make-light-grid-shape ex ey ez (real->double-flonum s))))
