#lang datalog
