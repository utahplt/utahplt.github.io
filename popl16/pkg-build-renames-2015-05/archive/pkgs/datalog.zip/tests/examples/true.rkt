#lang datalog
true.
true?
