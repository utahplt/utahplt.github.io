71446
((3) 0 () 105 ((q lib "mred/main.rkt") (c (? . 0) q editor<%>) (q lib "racket/snip.rkt") (c (? . 2) q snip%) (c (? . 2) q style-delta%) (c (? . 0) q text%) (c (? . 0) q clipboard<%>) (c (? . 0) q editor-snip%) (c (? . 0) q labelled-menu-item<%>) (q lib "wxme/main.rkt") (c (? . 0) q pasteboard%) (c (? . 0) q key-event%) (c (? . 0) q editor-canvas%) (c (? . 2) q style-list%) (c (? . 0) q scroll-event%) (c (? . 0) q mouse-event%) (c (? . 2) q snip-admin%) (c (? . 0) q frame%) (c (? . 0) q control-event%) (c (? . 0) q selectable-menu-item<%>) (c (? . 0) q list-box%) (c (? . 2) q image-snip%) (q lib "wxme/comment.rkt") (c (? . 0) q canvas<%>) (c (? . 0) q editor-admin%) (c (? . 2) q style<%>) (c (? . 2) q snip-class%) (c (? . 2) q mult-color<%>) (c (? . 0) q list-control<%>) (c (? . 0) q window<%>) (c (? . 0) q top-level-window<%>) (c (? . 0) q timer%) (c (? . 0) q gauge%) (c (? . 0) q check-box%) (c (? . 75) q test-case%) (c (? . 0) q subarea<%>) (c (? . 0) q area-container<%>) (c (? . 2) q add-color<%>) (c (? . 0) q keymap%) (c (? . 0) q editor-data-class%) (c (? . 0) q tab-panel%) (c (? . 0) q editor-data%) (c (? . 0) q canvas%) (c (? . 0) q editor-wordbreak-map%) (c (? . 0) q printer-dc%) (c (? . 0) q area<%>) (c (? . 0) q vertical-pane%) (c (? . 0) q editor-stream-out%) (c (? . 0) q dialog%) (c (? . 9) q stream<%>) (c (? . 0) q editor-stream-in-base%) (c (? . 0) q combo-field%) (c (? . 68) q racket-editor%) (c (? . 0) q cursor%) (c (? . 0) q editor-stream-in%) (q lib "wxme/xml.rkt") (c (? . 0) q editor-stream-out-base%) (c (? . 0) q editor-data-class-list<%>) (q (lib "wxme/image.rkt") image%) (c (? . 0) q group-box-panel%) (c (? . 0) q menu-item<%>) (c (? . 2) q snip-class-list<%>) (c (? . 0) q radio-box%) (c (? . 22) q comment-editor%) (c (? . 0) q popup-menu%) (c (? . 0) q editor-snip-editor-admin<%>) (c (? . 0) q text-field%) (c (? . 0) q message%) (q lib "wxme/scheme.rkt") (c (? . 0) q menu-bar%) (c (? . 0) q checkable-menu-item%) (c (? . 0) q clipboard-client%) (c (? . 0) q subwindow<%>) (c (? . 55) q xml-editor%) (c (? . 0) q menu-item-container<%>) (q lib "wxme/test-case.rkt") (c (? . 0) q vertical-panel%) (c (? . 0) q editor-stream-out-bytes-base%) (c (? . 91) q cache-image%) (c (? . 0) q slider%) (c (? . 2) q string-snip%) (c (? . 0) q event%) (c (? . 2) q tab-snip%) (c (? . 84) q text-editor%) (q lib "wxme/text.rkt") (c (? . 0) q horizontal-panel%) (c (? . 0) q button%) (c (? . 0) q panel%) (c (? . 0) q control<%>) (c (? . 0) q column-control-event%) (c (? . 0) q separator-menu-item%) (q lib "wxme/cache-image.rkt") (c (? . 0) q menu%) (c (? . 0) q menu-item%) (c (? . 0) q horizontal-pane%) (c (? . 9) q readable<%>) (c (? . 0) q editor-stream-in-bytes-base%) (c (? . 2) q readable-snip<%>) (c (? . 0) q choice%) (q lib "racket/gui/dynamic.rkt") (q lib "racket/gui/base.rkt") (c (? . 9) q snip-reader<%>) (c (? . 0) q pane%) (q (lib "wxme/editor.rkt") editor%) (c (? . 0) q grow-box-spacer-pane%)) () (h ! (equal) ((c def c (c (? . 9) q wxme-port->port)) q (220239 . 5)) ((c meth c (c (? . 5) q find-string)) q (195031 . 14)) ((c meth c (c (? . 3) q get-scroll-step-offset)) q (114571 . 4)) ((c meth c (c (? . 1) q get-keymap)) q (140267 . 2)) ((c meth c (c (? . 1) q insert-box)) q (142156 . 3)) ((c meth c (c (? . 1) q get-extent)) q (139598 . 4)) ((c meth c (c (? . 4) q set-transparent-text-backing-off)) q (132771 . 3)) ((c meth c (c (? . 16) q modified)) q (119054 . 4)) ((c meth c (c (? . 10) q resize)) q (188019 . 5)) ((c meth c (c (? . 6) q get-clipboard-bitmap)) q (18098 . 4)) ((c meth c (c (? . 1) q write-footers-to-file)) q (156174 . 3)) ((c def c (c (? . 0) q label->plain-label)) q (103408 . 3)) ((c def c (c (? . 0) q get-file)) q (86847 . 18)) ((c meth c (c (? . 3) q release-from-owner)) q (117248 . 2)) ((c meth c (c (? . 4) q set-style-off)) q (132556 . 3)) ((c meth c (c (? . 4) q get-transparent-text-backing-off)) q (128740 . 3)) ((c def c (? . 63)) q (223451 . 4)) ((c meth c (c (? . 5) q set-paragraph-margins)) q (212862 . 9)) ((c meth c (c (? . 34) q get-enabled?)) q (226652 . 2)) ((c meth c (c (? . 5) q call-clickback)) q (190044 . 4)) ((c meth c (c (? . 14) q get-direction)) q (68353 . 3)) ((c meth c (c (? . 5) q set-tabs)) q (214690 . 7)) ((c def c (? . 13)) q (133326 . 3)) ((c meth c (c (? . 5) q position-paragraph)) q (209748 . 6)) ((c def c (? . 59)) q (32017 . 3)) ((c def c (c (? . 0) q yield)) q (98509 . 4)) ((c def c (c (? . 0) q begin-busy-cursor)) q (101139 . 2)) ((c meth c (c (? . 7) q set-align-top-line)) q (170985 . 3)) ((c meth c (c (? . 26) q get-version)) q (121730 . 2)) ((c meth c (c (? . 6) q set-clipboard-bitmap)) q (18618 . 5)) ((c meth c (c (? . 7) q show-border)) q (172205 . 3)) ((c meth c (c (? . 8) q on-demand)) q (42511 . 2)) ((c meth c (c (? . 1) q get-max-view-size)) q (140599 . 2)) ((c meth c (c (? . 12) q horizontal-inset)) q (162346 . 5)) ((c meth c (c (? . 28) q get-number)) q (48363 . 2)) ((c meth c (c (? . 27) q set-g)) q (109831 . 3)) ((c meth c (c (? . 1) q on-display-size)) q (145932 . 2)) ((c def c (c (? . 0) q get-display-size)) q (100454 . 11)) ((c constructor c (? . 44)) q (62995 . 3)) ((c meth c (c (? . 8) q get-plain-label)) q (42376 . 2)) ((c constructor c (? . 80)) q (123007 . 5)) ((c meth c (c (? . 4) q set-delta-face)) q (131153 . 8)) ((c def c (c (? . 9) q wxme-port->text-port)) q (220124 . 4)) ((c constructor c (? . 4)) q (125728 . 32)) ((c meth c (c (? . 49) q read-integer)) q (222301 . 3)) ((c def c (? . 3)) q (110420 . 4)) ((c meth c (c (? . 43) q get-map)) q (176971 . 4)) ((c meth c (c (? . 45) q get-top-level-window)) q (207 . 3)) ((c meth c (c (? . 1) q locked-for-flow?)) q (144948 . 2)) ((c meth c (c (? . 15) q get-right-down)) q (56975 . 2)) ((c meth c (c (? . 30) q show)) q (79844 . 3)) ((c meth c (c (? . 4) q equal?)) q (127266 . 3)) ((c meth c (c (? . 19) q set-shortcut-prefix)) q (66920 . 9)) ((c meth c (c (? . 4) q set-delta-foreground)) q (131460 . 7)) ((c meth c (c (? . 1) q find-scroll-line)) q (139016 . 4)) ((c meth c (c (? . 5) q do-paste-x-selection)) q (192822 . 5)) ((c meth c (c (? . 5) q on-new-string-snip)) q (206753 . 2)) ((c meth c (c (? . 21) q get-filetype)) q (107854 . 6)) ((c meth c (c (? . 10) q get-scroll-step)) q (184194 . 3)) ((c meth c (c (? . 11) q set-caps-down)) q (40559 . 3)) ((c meth c (c (? . 10) q after-resize)) q (181019 . 9)) ((c meth c (c (? . 25) q get-foreground)) q (124102 . 2)) ((c meth c (c (? . 37) q get-r)) q (105926 . 2)) ((c meth c (c (? . 1) q write-to-file)) q (156404 . 3)) ((c meth c (c (? . 17) q maximize)) q (29372 . 3)) ((c meth c (c (? . 11) q set-y)) q (41983 . 3)) ((c meth c (c (? . 36) q container-flow-modified)) q (1495 . 2)) ((c meth c (c (? . 12) q scroll-to)) q (163153 . 13)) ((c meth c (c (? . 1) q can-do-edit-operation?)) q (136469 . 7)) ((c meth c (c (? . 33) q get-value)) q (13472 . 2)) ((c meth c (c (? . 13) q forget-notification)) q (134177 . 3)) ((c meth c (c (? . 5) q set-paragraph-alignment)) q (212640 . 5)) ((c def c (c (? . 0) q small-control-font)) q (101003 . 2)) ((c meth c (c (? . 61) q nth)) q (122762 . 4)) ((c constructor c (? . 18)) q (22311 . 11)) ((c meth c (c (? . 14) q get-event-type)) q (68435 . 4)) ((c meth c (c (? . 4) q set-smoothing-on)) q (132402 . 4)) ((c meth c (c (? . 15) q get-control-down)) q (56379 . 2)) ((c def c (? . 32)) q (29992 . 4)) ((c meth c (c (? . 8) q is-enabled?)) q (42448 . 2)) ((c meth c (c (? . 23) q suspend-flush)) q (6576 . 2)) ((c meth c (c (? . 1) q set-max-height)) q (154643 . 3)) ((c def c (? . 16)) q (118260 . 3)) ((c constructor c (? . 20)) q (42853 . 47)) ((c constructor c (? . 53)) q (23498 . 12)) ((c meth c (c (? . 1) q default-style-name)) q (138007 . 2)) ((c meth c (c (? . 5) q find-next-non-string-snip)) q (193645 . 4)) ((c meth c (c (? . 29) q get-plain-label)) q (84567 . 2)) ((c meth c (c (? . 11) q get-other-caps-key-code)) q (40025 . 3)) ((c meth c (c (? . 17) q has-status-line?)) q (29083 . 2)) ((c meth c (c (? . 11) q get-other-shift-altgr-key-code)) q (40119 . 3)) ((c def c (c (? . 0) q key-code-symbol?)) q (105506 . 3)) ((c def c (c (? . 0) q queue-callback)) q (98380 . 4)) ((c meth c (c (? . 60) q delete)) q (50348 . 2)) ((c meth c (c (? . 5) q move-position)) q (205848 . 7)) ((c def c (c (? . 9) q is-wxme-stream?)) q (220055 . 3)) ((c meth c (c (? . 18) q get-event-type)) q (22867 . 6)) ((c meth c (c (? . 1) q is-printing?)) q (144183 . 2)) ((c meth c (c (? . 5) q find-snip)) q (194755 . 6)) ((c meth c (c (? . 1) q set-modified)) q (155257 . 3)) ((c meth c (c (? . 10) q add-selected)) q (179563 . 8)) ((c def c (? . 19)) q (66040 . 3)) ((c meth c (c (? . 10) q can-move-to?)) q (182115 . 9)) ((c meth c (c (? . 16) q get-editor)) q (118443 . 3)) ((c meth c (c (? . 13) q find-or-create-join-style)) q (133719 . 6)) ((c def c (c (? . 0) q is-color-display?)) q (100867 . 2)) ((c meth c (c (? . 20) q number-of-visible-items)) q (46524 . 3)) ((c meth c (c (? . 5) q do-copy)) q (192498 . 6)) ((c meth c (c (? . 16) q scroll-to)) q (120094 . 15)) ((c def c (c (? . 0) q read-editor-version)) q (219007 . 9)) ((c meth c (c (? . 31) q interval)) q (77563 . 2)) ((c meth c (c (? . 5) q after-delete)) q (189462 . 4)) ((c meth c (c (? . 15) q get-shift-down)) q (57034 . 2)) ((c meth c (c (? . 15) q set-event-type)) q (57558 . 5)) ((c def c (c (? . 0) q bell)) q (101180 . 2)) ((c meth c (c (? . 56) q write)) q (176389 . 3)) ((c meth c (c (? . 24) q get-dc)) q (156630 . 4)) ((c meth c (c (? . 1) q undo-preserves-all-history?)) q (155975 . 2)) ((c meth c (c (? . 21) q other-equal-to?)) q (108767 . 5)) ((c meth c (c (? . 4) q set-delta)) q (129416 . 35)) ((c def c (c (? . 0) q get-text-from-user)) q (94240 . 16)) ((c def c (c (? . 0) q menu-control-font)) q (100911 . 2)) ((c meth c (c (? . 11) q get-mod5-down)) q (39874 . 2)) ((c def c (c (? . 0) q eventspace-shutdown?)) q (98682 . 3)) ((c meth c (c (? . 3) q do-edit-operation)) q (111484 . 10)) ((c meth c (c (? . 10) q get-selection-visible)) q (184280 . 2)) ((c meth c (c (? . 5) q get-padding)) q (200056 . 5)) ((c meth c (c (? . 10) q set-scroll-step)) q (188568 . 3)) ((c meth c (c (? . 1) q set-undo-preserves-all-history)) q (155678 . 3)) ((c meth c (c (? . 1) q after-load-file)) q (135599 . 3)) ((c meth c (c (? . 1) q on-default-event)) q (145833 . 3)) ((c def c (c (? . 22) q reader)) q (223408 . 2)) ((c meth c (c (? . 23) q set-resize-corner)) q (6499 . 3)) ((c def c (? . 66)) q (74779 . 4)) ((c meth c (c (? . 1) q copy-self)) q (137506 . 3)) ((c meth c (c (? . 4) q set-weight-on)) q (133220 . 3)) ((c def c (c (? . 0) q find-graphical-system-path)) q (102001 . 3)) ((c meth c (c (? . 5) q get-between-threshold)) q (199417 . 3)) ((c meth c (c (? . 1) q on-edit-sequence)) q (146049 . 2)) ((c def c (c (? . 0) q end-busy-cursor)) q (101272 . 2)) ((c meth c (c (? . 4) q get-style-off)) q (128561 . 3)) ((c meth c (c (? . 24) q get-max-view)) q (156799 . 11)) ((c meth c (c (? . 24) q grab-caret)) q (157623 . 3)) ((c def c (? . 24)) q (156511 . 3)) ((c meth c (c (? . 3) q on-goodbye-event)) q (116498 . 13)) ((c meth c (c (? . 1) q lock)) q (144879 . 3)) ((c meth c (c (? . 58) q get-w)) q (223154 . 2)) ((c meth c (c (? . 5) q on-set-size-constraint)) q (206933 . 2)) ((c meth c (c (? . 5) q position-locations)) q (209031 . 15)) ((c meth c (c (? . 16) q get-view)) q (118538 . 7)) ((c meth c (c (? . 10) q on-interactive-resize)) q (186824 . 3)) ((c meth c (c (? . 25) q get-transparent-text-backing)) q (125014 . 2)) ((c def c (c (? . 0) q get-choices-from-user)) q (95010 . 15)) ((c meth c (c (? . 1) q can-load-file?)) q (136816 . 6)) ((c def c (? . 26)) q (121561 . 3)) ((c meth c (c (? . 40) q append)) q (74042 . 3)) ((c meth c (c (? . 5) q line-length)) q (205286 . 3)) ((c meth c (c (? . 27) q get-b)) q (109527 . 2)) ((c meth c (c (? . 15) q set-middle-down)) q (57965 . 3)) ((c constructor c (? . 51)) q (19261 . 35)) ((c meth c (c (? . 5) q set-styles-sticky)) q (214607 . 3)) ((c meth c (c (? . 28) q clear)) q (48117 . 2)) ((c meth c (c (? . 1) q begin-edit-sequence)) q (135898 . 5)) ((c meth c (c (? . 5) q set-line-spacing)) q (212077 . 3)) ((c meth c (c (? . 1) q set-snip-data)) q (155436 . 4)) ((c def c (c (? . 9) q broken-wxme-big-endian?)) q (220907 . 4)) ((c meth c (c (? . 29) q client->screen)) q (83656 . 5)) ((c meth c (c (? . 1) q remove-canvas)) q (151237 . 3)) ((c meth c (c (? . 1) q clear)) q (137292 . 2)) ((c meth c (c (? . 17) q on-toolbar-button-click)) q (29855 . 2)) ((c meth c (c (? . 4) q get-alignment-off)) q (127362 . 3)) ((c meth c (c (? . 30) q get-focus-object)) q (78474 . 3)) ((c meth c (c (? . 25) q get-size-in-pixels)) q (124331 . 2)) ((c meth c (c (? . 1) q cut)) q (137715 . 4)) ((c meth c (c (? . 5) q find-string-all)) q (196682 . 14)) ((c meth c (c (? . 11) q control+meta-is-altgr)) q (40722 . 3)) ((c meth c (c (? . 10) q do-paste)) q (183547 . 3)) ((c meth c (c (? . 41) q get-dataclass)) q (164663 . 3)) ((c def c (? . 31)) q (77127 . 3)) ((c def c (? . 72)) q (71659 . 4)) ((c meth c (c (? . 32) q get-range)) q (31717 . 2)) ((c meth c (c (? . 10) q on-select)) q (187653 . 4)) ((c meth c (c (? . 12) q force-display-focus)) q (162000 . 4)) ((c def c (? . 35)) q (71312 . 3)) ((c meth c (c (? . 11) q set-other-caps-key-code)) q (41463 . 3)) ((c def c (? . 33)) q (11682 . 4)) ((c meth c (c (? . 34) q get-error-box?)) q (226764 . 2)) ((c def c (c (? . 0) q message-box/custom)) q (90902 . 23)) ((c def c (c (? . 0) q read-editor-global-footer)) q (218815 . 3)) ((c meth c (c (? . 4) q get-underlined-off)) q (128895 . 2)) ((c meth c (c (? . 10) q can-delete?)) q (181496 . 3)) ((c meth c (c (? . 103) q get-content-port)) q (222983 . 2)) ((c meth c (c (? . 4) q set-style-on)) q (132664 . 3)) ((c def c (c (? . 0) q editor-set-x-selection-mode)) q (216768 . 3)) ((c def c (c (? . 55) q reader)) q (224006 . 2)) ((c meth c (c (? . 1) q locked-for-write?)) q (145062 . 2)) ((c def c (c (? . 0) q view-control-font)) q (101094 . 2)) ((c meth c (c (? . 1) q on-paint)) q (147324 . 21)) ((c meth c (c (? . 38) q break-sequence)) q (177650 . 2)) ((c meth c (c (? . 25) q get-text-height)) q (124677 . 4)) ((c meth c (c (? . 11) q get-other-shift-key-code)) q (40220 . 3)) ((c meth c (c (? . 10) q can-resize?)) q (182684 . 5)) ((c meth c (c (? . 10) q after-delete)) q (179832 . 3)) ((c meth c (c (? . 1) q put-file)) q (149565 . 5)) ((c meth c (c (? . 19) q command)) q (66128 . 3)) ((c meth c (c (? . 26) q set-version)) q (122196 . 3)) ((c meth c (c (? . 1) q redo)) q (150371 . 2)) ((c meth c (c (? . 5) q find-wordbreak)) q (198478 . 7)) ((c meth c (c (? . 50) q skip)) q (174512 . 3)) ((c meth c (c (? . 4) q set-face)) q (131681 . 3)) ((c meth c (c (? . 7) q get-min-width)) q (170672 . 3)) ((c meth c (c (? . 42) q show-scrollbars)) q (11259 . 5)) ((c meth c (c (? . 54) q jump-to)) q (173458 . 3)) ((c def c (c (? . 0) q positive-dimension-integer?)) q (104085 . 3)) ((c meth c (c (? . 23) q get-dc)) q (5747 . 2)) ((c meth c (c (? . 29) q on-subwindow-focus)) q (85801 . 5)) ((c meth c (c (? . 35) q vert-margin)) q (71517 . 4)) ((c def c (c (? . 0) q eventspace-handler-thread)) q (98754 . 3)) ((c def c (? . 5)) q (188870 . 4)) ((c meth c (c (? . 1) q on-save-file)) q (148134 . 6)) ((c meth c (c (? . 12) q get-line-count)) q (162258 . 3)) ((c meth c (c (? . 14) q set-position)) q (68930 . 3)) ((c meth c (c (? . 12) q allow-scroll-to-last)) q (161627 . 4)) ((c def c (? . 36)) q (834 . 3)) ((c meth c (c (? . 27) q set)) q (109665 . 5)) ((c meth c (c (? . 28) q get-selection)) q (48437 . 3)) ((c meth c (c (? . 37) q set-r)) q (106323 . 3)) ((c meth c (c (? . 1) q read-header-from-file)) q (150181 . 5)) ((c meth c (c (? . 11) q get-key-code)) q (39540 . 3)) ((c def c (c (? . 100) q make-gui-empty-namespace)) q (103669 . 2)) ((c def c (? . 87)) q (60053 . 5)) ((c meth c (c (? . 10) q lower)) q (185720 . 3)) ((c meth c (c (? . 25) q get-delta)) q (123761 . 3)) ((c meth c (c (? . 1) q local-to-global)) q (144686 . 4)) ((c meth c (c (? . 3) q previous)) q (117182 . 2)) ((c meth c (c (? . 86) q set-label)) q (5302 . 4)) ((c meth c (c (? . 15) q get-left-down)) q (56625 . 2)) ((c meth c (c (? . 28) q set-string-selection)) q (48851 . 3)) ((c constructor c (? . 14)) q (67774 . 12)) ((c meth c (c (? . 1) q get-min-width)) q (140854 . 3)) ((c meth c (c (? . 8) q set-label)) q (42678 . 3)) ((c meth c (c (? . 38) q call-function)) q (177701 . 9)) ((c constructor c (? . 39)) q (165192 . 2)) ((c constructor c (? . 38)) q (177375 . 2)) ((c meth c (c (? . 5) q find-line)) q (193137 . 4)) ((c meth c (c (? . 11) q get-x)) q (40372 . 2)) ((c meth c (c (? . 23) q on-paint)) q (6262 . 2)) ((c meth c (c (? . 36) q change-children)) q (1324 . 4)) ((c meth c (c (? . 10) q do-paste-x-selection)) q (183630 . 3)) ((c def c (c (? . 0) q get-window-text-extent)) q (102531 . 8)) ((c meth c (c (? . 5) q get-visible-line-range)) q (202234 . 7)) ((c def c (c (? . 0) q the-editor-wordbreak-map)) q (219583 . 2)) ((c meth c (c (? . 12) q scroll-with-bottom-base)) q (163696 . 4)) ((c constructor c (? . 96)) q (174774 . 4)) ((c meth c (c (? . 29) q get-y)) q (84825 . 2)) ((c def c (c (? . 0) q get-display-backing-scale)) q (99763 . 4)) ((c meth c (c (? . 3) q get-text!)) q (115028 . 9)) ((c def c (c (? . 0) q get-highlight-text-color)) q (102459 . 2)) ((c meth c (c (? . 3) q match?)) q (115464 . 3)) ((c meth c (c (? . 39) q get-classname)) q (165265 . 2)) ((c meth c (c (? . 48) q show)) q (26302 . 3)) ((c meth c (c (? . 29) q get-client-size)) q (83975 . 3)) ((c def c (c (? . 0) q open-input-graphical-file)) q (217107 . 3)) ((c def c (? . 67)) q (52375 . 4)) ((c meth c (c (? . 40) q set-selection)) q (74686 . 3)) ((c def c (? . 92)) q (48935 . 5)) ((c meth c (c (? . 1) q read-from-file)) q (149959 . 5)) ((c meth c (c (? . 5) q last-line)) q (204877 . 2)) ((c meth c (c (? . 10) q is-selected?)) q (185628 . 3)) ((c def c (? . 82)) q (135097 . 3)) ((c meth c (c (? . 1) q set-max-undo-history)) q (154766 . 3)) ((c meth c (c (? . 14) q set-direction)) q (68644 . 3)) ((c meth c (c (? . 52) q read-special)) q (224761 . 9)) ((c meth c (c (? . 3) q own-caret)) q (116944 . 3)) ((c meth c (c (? . 41) q get-next)) q (164756 . 3)) ((c meth c (c (? . 42) q swap-gl-buffers)) q (11428 . 2)) ((c def c (c (? . 0) q map-command-as-meta-key)) q (216997 . 4)) ((c meth c (c (? . 10) q on-delete)) q (186273 . 3)) ((c def c (? . 43)) q (176828 . 3)) ((c meth c (c (? . 11) q set-mod4-down)) q (41184 . 3)) ((c meth c (c (? . 3) q set-snipclass)) q (117708 . 3)) ((c meth c (c (? . 5) q find-string-embedded)) q (195650 . 22)) ((c meth c (c (? . 1) q own-caret)) q (148539 . 3)) ((c constructor c (? . 77)) q (176662 . 3)) ((c meth c (c (? . 25) q get-font)) q (124047 . 2)) ((c meth c (c (? . 5) q get-extend-end-position)) q (199753 . 3)) ((c meth c (c (? . 21) q load-file)) q (108086 . 14)) ((c meth c (c (? . 69) q enable)) q (50106 . 3)) ((c def c (? . 97)) q (109961 . 2)) ((c meth c (c (? . 25) q get-name)) q (124164 . 2)) ((c meth c (c (? . 8) q set-help-string)) q (42569 . 3)) ((c meth c (c (? . 7) q get-inset)) q (169870 . 6)) ((c meth c (c (? . 43) q set-map)) q (177110 . 5)) ((c meth c (c (? . 47) q jump-to)) q (175093 . 3)) ((c meth c (c (? . 71) q get-data)) q (17825 . 4)) ((c def c (? . 44)) q (62921 . 4)) ((c meth c (c (? . 5) q set-wordbreak-func)) q (214929 . 6)) ((c meth c (c (? . 13) q style-to-index)) q (134967 . 4)) ((c def c (c (? . 0) q normal-control-font)) q (100956 . 2)) ((c meth c (c (? . 3) q get-count)) q (113409 . 2)) ((c meth c (c (? . 15) q get-y)) q (57149 . 2)) ((c meth c (c (? . 16) q update-cursor)) q (120894 . 2)) ((c meth c (c (? . 15) q set-right-down)) q (58295 . 3)) ((c meth c (c (? . 29) q get-label)) q (84244 . 9)) ((c def c (c (? . 0) q get-highlight-background-color)) q (102393 . 2)) ((c def c (c (? . 0) q application-quit-handler)) q (99438 . 4)) ((c def c (c (? . 9) q string->lib-path)) q (220659 . 4)) ((c meth c (c (? . 15) q get-event-type)) q (56440 . 5)) ((c meth c (c (? . 5) q line-start-position)) q (205639 . 6)) ((c meth c (c (? . 4) q get-family)) q (127769 . 4)) ((c meth c (c (? . 1) q paste)) q (148611 . 3)) ((c meth c (c (? . 3) q can-do-edit-operation?)) q (111075 . 8)) ((c def c (? . 46)) q (79920 . 3)) ((c meth c (c (? . 1) q add-canvas)) q (135244 . 3)) ((c meth c (c (? . 10) q on-resize)) q (187471 . 5)) ((c meth c (c (? . 45) q get-graphical-min-size)) q (33 . 3)) ((c meth c (c (? . 3) q draw)) q (111914 . 23)) ((c meth c (c (? . 21) q get-bitmap-mask)) q (107624 . 3)) ((c meth c (c (? . 36) q get-children)) q (2167 . 3)) ((c constructor c (? . 46)) q (79975 . 26)) ((c meth c (c (? . 40) q get-selection)) q (74378 . 3)) ((c meth c (c (? . 20) q append-column)) q (45499 . 3)) ((c meth c (c (? . 5) q on-reflow)) q (206889 . 2)) ((c meth c (c (? . 10) q on-double-click)) q (186359 . 5)) ((c meth c (c (? . 15) q get-meta-down)) q (56683 . 2)) ((c meth c (c (? . 1) q end-write-header-footer-to-file)) q (138712 . 6)) ((c def c (c (? . 0) q message+check-box)) q (92109 . 16)) ((c def c (? . 85)) q (35681 . 3)) ((c meth c (c (? . 47) q pretty-finish)) q (175248 . 2)) ((c meth c (c (? . 5) q paste)) q (207698 . 5)) ((c constructor c (? . 48)) q (24184 . 36)) ((c def c (c (? . 0) q get-top-level-edit-target-window)) q (98077 . 3)) ((c meth c (c (? . 4) q set-size-add)) q (131935 . 3)) ((c meth c (c (? . 20) q set-first-visible-item)) q (47683 . 3)) ((c meth c (c (? . 3) q set-admin)) q (117444 . 3)) ((c meth c (c (? . 40) q get-item-label)) q (74211 . 3)) ((c meth c (c (? . 15) q set-alt-down)) q (57310 . 3)) ((c def c (c (? . 0) q add-pasteboard-keymap-functions)) q (215742 . 3)) ((c meth c (c (? . 1) q print-to-dc)) q (149427 . 4)) ((c meth c (c (? . 10) q interactive-adjust-move)) q (185012 . 7)) ((c def c (? . 79)) q (69031 . 4)) ((c meth c (c (? . 3) q get-extent)) q (113471 . 22)) ((c meth c (c (? . 5) q flash-on)) q (198860 . 11)) ((c meth c (c (? . 19) q get-shortcut)) q (66233 . 3)) ((c meth c (c (? . 23) q resume-flush)) q (6353 . 2)) ((c meth c (c (? . 8) q get-help-string)) q (42225 . 3)) ((c meth c (c (? . 24) q scroll-to)) q (158477 . 13)) ((c meth c (c (? . 62) q get-item-plain-label)) q (65534 . 3)) ((c meth c (c (? . 29) q refresh)) q (86305 . 2)) ((c meth c (c (? . 49) q read-bytes)) q (222643 . 3)) ((c def c (c (? . 0) q the-style-list)) q (219651 . 2)) ((c meth c (c (? . 81) q get-time-stamp)) q (26591 . 2)) ((c meth c (c (? . 29) q accept-drop-files)) q (83509 . 4)) ((c meth c (c (? . 50) q read)) q (174064 . 4)) ((c meth c (c (? . 5) q get-line-spacing)) q (199919 . 3)) ((c meth c (c (? . 51) q on-popup)) q (21318 . 3)) ((c meth c (c (? . 38) q set-break-sequence-callback)) q (178859 . 3)) ((c def c (c (? . 0) q spacing-integer?)) q (105217 . 3)) ((c meth c (c (? . 10) q after-reorder)) q (180762 . 7)) ((c meth c (c (? . 3) q get-admin)) q (113336 . 2)) ((c meth c (c (? . 24) q popup-menu)) q (158193 . 5)) ((c meth c (c (? . 38) q add-function)) q (177426 . 4)) ((c meth c (c (? . 42) q with-gl-context)) q (11480 . 5)) ((c def c (? . 65)) q (166176 . 2)) ((c meth c (c (? . 10) q get-dragable)) q (184138 . 2)) ((c meth c (c (? . 1) q style-has-changed)) q (155825 . 3)) ((c meth c (c (? . 52) q get-data)) q (224709 . 2)) ((c meth c (c (? . 29) q get-handle)) q (84133 . 2)) ((c def c (c (? . 0) q current-eventspace)) q (97432 . 4)) ((c def c (? . 53)) q (23448 . 3)) ((c constructor c (? . 10)) q (179504 . 2)) ((c meth c (c (? . 5) q get-overwrite-mode)) q (200000 . 2)) ((c meth c (c (? . 10) q remove-selected)) q (187927 . 3)) ((c meth c (c (? . 54) q get-bytes)) q (172841 . 3)) ((c meth c (c (? . 4) q set-alignment-off)) q (129197 . 3)) ((c meth c (c (? . 30) q on-message)) q (78997 . 3)) ((c meth c (c (? . 33) q set-label)) q (13524 . 3)) ((c meth c (c (? . 10) q no-selected)) q (186119 . 2)) ((c meth c (c (? . 1) q insert-port)) q (143202 . 9)) ((c meth c (c (? . 15) q get-mod3-down)) q (56801 . 2)) ((c meth c (c (? . 64) q get-popup-target)) q (62720 . 3)) ((c meth c (c (? . 1) q on-default-char)) q (145737 . 3)) ((c meth c (c (? . 10) q erase)) q (183725 . 2)) ((c meth c (c (? . 54) q get-inexact)) q (173241 . 2)) ((c meth c (c (? . 57) q nth)) q (165960 . 4)) ((c meth c (c (? . 5) q write-to-file)) q (215422 . 5)) ((c meth c (c (? . 10) q can-insert?)) q (181587 . 9)) ((c meth c (c (? . 29) q on-superwindow-show)) q (86069 . 3)) ((c meth c (c (? . 42) q get-virtual-size)) q (8913 . 3)) ((c meth c (c (? . 101) q read-snip)) q (221431 . 9)) ((c meth c (c (? . 8) q get-label)) q (42310 . 2)) ((c meth c (c (? . 49) q read-editor)) q (222716 . 3)) ((c meth c (c (? . 17) q on-menu-char)) q (29570 . 3)) ((c meth c (c (? . 1) q get-min-height)) q (140757 . 3)) ((c meth c (c (? . 19) q set-shortcut)) q (66803 . 3)) ((c meth c (c (? . 1) q set-caret-owner)) q (153676 . 5)) ((c meth c (c (? . 10) q can-interactive-resize?)) q (182012 . 3)) ((c meth c (c (? . 15) q set-y)) q (58540 . 3)) ((c meth c (c (? . 1) q copy-self-to)) q (137597 . 3)) ((c def c (? . 37)) q (105568 . 2)) ((c meth c (c (? . 5) q on-insert)) q (206617 . 4)) ((c meth c (c (? . 25) q get-text-descent)) q (124563 . 4)) ((c meth c (c (? . 17) q get-menu-bar)) q (29008 . 2)) ((c meth c (c (? . 5) q get-extend-start-position)) q (199671 . 3)) ((c meth c (c (? . 16) q release-snip)) q (119885 . 3)) ((c constructor c (? . 7)) q (166365 . 35)) ((c meth c (c (? . 21) q equal-hash-code-of)) q (107275 . 4)) ((c constructor c (? . 93)) q (50702 . 24)) ((c meth c (c (? . 73) q read-special)) q (224178 . 9)) ((c meth c (c (? . 15) q set-x)) q (58461 . 3)) ((c meth c (c (? . 12) q on-focus)) q (162847 . 3)) ((c meth c (c (? . 3) q equal-secondary-hash-code-of)) q (113111 . 4)) ((c meth c (c (? . 21) q set-offset)) q (109266 . 4)) ((c def c (c (? . 0) q application-about-handler)) q (98967 . 4)) ((c meth c (c (? . 38) q is-function-added?)) q (177563 . 3)) ((c def c (c (? . 0) q open-output-text-editor)) q (218168 . 12)) ((c def c (? . 42)) q (6626 . 4)) ((c def c (c (? . 0) q tiny-control-font)) q (101049 . 2)) ((c meth c (c (? . 5) q last-paragraph)) q (204942 . 2)) ((c meth c (c (? . 4) q get-style-on)) q (128651 . 3)) ((c meth c (c (? . 56) q seek)) q (176207 . 3)) ((c meth c (c (? . 1) q get-snip-location)) q (141134 . 9)) ((c meth c (c (? . 17) q create-status-line)) q (28869 . 2)) ((c meth c (c (? . 70) q is-checked?)) q (15630 . 2)) ((c meth c (c (? . 29) q get-width)) q (84712 . 2)) ((c def c (? . 57)) q (165538 . 2)) ((c meth c (c (? . 54) q get-fixed-exact)) q (173169 . 2)) ((c meth c (c (? . 58) q get-dx)) q (223304 . 2)) ((c meth c (c (? . 30) q on-activate)) q (78799 . 3)) ((c meth c (c (? . 1) q insert)) q (142076 . 3)) ((c meth c (c (? . 30) q display-changed)) q (79085 . 2)) ((c meth c (c (? . 47) q put-unterminated)) q (175896 . 4)) ((c constructor c (? . 32)) q (30066 . 31)) ((c meth c (c (? . 30) q get-edit-target-object)) q (78183 . 3)) ((c meth c (c (? . 16) q get-selected-text-color)) q (121035 . 3)) ((c meth c (c (? . 27) q get)) q (109399 . 5)) ((c meth c (c (? . 39) q read)) q (165329 . 4)) ((c meth c (c (? . 20) q get-column-width)) q (45865 . 5)) ((c meth c (c (? . 42) q set-scroll-range)) q (11071 . 5)) ((c meth c (c (? . 7) q set-max-width)) q (171757 . 3)) ((c meth c (c (? . 11) q set-x)) q (41906 . 3)) ((c constructor c (? . 59)) q (32084 . 34)) ((c meth c (c (? . 78) q get-pin-x)) q (226106 . 2)) ((c def c (? . 14)) q (67719 . 3)) ((c def c (c (? . 0) q get-display-depth)) q (99960 . 2)) ((c meth c (c (? . 1) q dc-location-to-editor-location)) q (137836 . 5)) ((c meth c (c (? . 1) q get-paste-text-only)) q (140950 . 2)) ((c meth c (c (? . 1) q scroll-line-location)) q (152700 . 4)) ((c def c (c (? . 0) q make-gl-bitmap)) q (103481 . 5)) ((c meth c (c (? . 5) q set-file-format)) q (211963 . 3)) ((c def c (c (? . 0) q get-color-from-user)) q (95655 . 9)) ((c meth c (c (? . 17) q on-subwindow-char)) q (29664 . 5)) ((c def c (c (? . 0) q unregister-collecting-blit)) q (104986 . 3)) ((c meth c (c (? . 1) q scroll-editor-to)) q (152164 . 13)) ((c def c (? . 45)) q (0 . 2)) ((c meth c (c (? . 1) q set-inactive-caret-threshold)) q (154283 . 3)) ((c def c (c (? . 0) q text-editor-load-handler)) q (219370 . 5)) ((c meth c (c (? . 54) q get-exact)) q (172985 . 2)) ((c meth c (c (? . 42) q set-scroll-page)) q (10775 . 4)) ((c def c (c (? . 0) q dimension-integer?)) q (101208 . 3)) ((c constructor c (? . 31)) q (77176 . 9)) ((c meth c (c (? . 7) q resize)) q (170837 . 4)) ((c meth c (c (? . 3) q split)) q (117987 . 5)) ((c meth c (c (? . 38) q set-double-click-interval)) q (178946 . 3)) ((c meth c (c (? . 11) q get-meta-down)) q (39706 . 2)) ((c meth c (c (? . 1) q get-max-undo-history)) q (140504 . 3)) ((c meth c (c (? . 20) q get-selections)) q (46345 . 3)) ((c meth c (c (? . 32) q set-range)) q (31842 . 3)) ((c meth c (c (? . 1) q do-edit-operation)) q (138065 . 9)) ((c meth c (c (? . 6) q set-clipboard-string)) q (19021 . 5)) ((c meth c (c (? . 3) q set-style)) q (117800 . 3)) ((c meth c (c (? . 10) q on-reorder)) q (187226 . 7)) ((c meth c (c (? . 11) q set-key-release-code)) q (40913 . 3)) ((c def c (? . 60)) q (50310 . 2)) ((c meth c (c (? . 11) q get-mod4-down)) q (39818 . 2)) ((c meth c (c (? . 5) q can-set-size-constraint?)) q (190614 . 2)) ((c meth c (c (? . 5) q on-new-tab-snip)) q (206824 . 2)) ((c meth c (c (? . 15) q get-caps-down)) q (56321 . 2)) ((c meth c (c (? . 29) q set-cursor)) q (86494 . 3)) ((c meth c (c (? . 30) q get-eventspace)) q (78407 . 2)) ((c meth c (c (? . 24) q refresh-delayed?)) q (158330 . 2)) ((c meth c (c (? . 47) q put)) q (175371 . 14)) ((c meth c (c (? . 61) q find)) q (122530 . 4)) ((c meth c (c (? . 15) q get-alt-down)) q (56264 . 2)) ((c meth c (c (? . 1) q num-scroll-lines)) q (145527 . 2)) ((c meth c (c (? . 11) q get-mod3-down)) q (39762 . 2)) ((c meth c (c (? . 25) q get-size)) q (124287 . 2)) ((c meth c (c (? . 40) q delete)) q (74125 . 3)) ((c def c (c (? . 0) q the-clipboard)) q (105339 . 2)) ((c def c (c (? . 9) q wxme-read-syntax)) q (221079 . 4)) ((c meth c (c (? . 54) q skip)) q (173774 . 3)) ((c constructor c (? . 17)) q (26819 . 39)) ((c constructor c (? . 62)) q (63224 . 37)) ((c meth c (c (? . 47) q ok?)) q (175193 . 2)) ((c meth c (c (? . 13) q index-to-style)) q (134260 . 4)) ((c meth c (c (? . 15) q set-mod4-down)) q (58131 . 3)) ((c meth c (c (? . 7) q set-max-height)) q (171637 . 3)) ((c meth c (c (? . 13) q find-named-style)) q (133608 . 4)) ((c meth c (c (? . 10) q on-interactive-move)) q (186719 . 3)) ((c meth c (c (? . 34) q get-should-raise)) q (226503 . 2)) ((c meth c (c (? . 48) q on-subwindow-char)) q (26109 . 5)) ((c meth c (c (? . 3) q write)) q (118177 . 3)) ((c meth c (c (? . 37) q set-b)) q (106153 . 3)) ((c meth c (c (? . 36) q container-size)) q (1564 . 7)) ((c meth c (c (? . 1) q set-min-width)) q (155135 . 3)) ((c meth c (c (? . 63) q read-special)) q (223585 . 9)) ((c meth c (c (? . 4) q set-size-in-pixels-on)) q (132091 . 3)) ((c meth c (c (? . 1) q set-keymap)) q (154431 . 3)) ((c def c (? . 64)) q (61856 . 4)) ((c meth c (c (? . 5) q line-end-position)) q (205081 . 6)) ((c meth c (c (? . 31) q start)) q (77671 . 4)) ((c meth c (c (? . 1) q get-view-size)) q (141696 . 4)) ((c meth c (c (? . 11) q set-mod3-down)) q (41104 . 3)) ((c constructor c (? . 40)) q (71999 . 38)) ((c meth c (c (? . 5) q set-autowrap-bitmap)) q (211112 . 4)) ((c meth c (c (? . 1) q set-cursor)) q (153902 . 5)) ((c meth c (c (? . 41) q set-dataclass)) q (164838 . 3)) ((c meth c (c (? . 1) q get-descent)) q (139520 . 2)) ((c meth c (c (? . 65) q get-snip)) q (166229 . 3)) ((c meth c (c (? . 5) q scroll-to-position)) q (210638 . 9)) ((c meth c (c (? . 1) q on-change)) q (145602 . 2)) ((c meth c (c (? . 34) q get-expected)) q (226445 . 2)) ((c constructor c (? . 66)) q (74858 . 35)) ((c meth c (c (? . 19) q get-shortcut-prefix)) q (66318 . 8)) ((c def c (c (? . 0) q get-top-level-focus-window)) q (97982 . 3)) ((c meth c (c (? . 4) q get-alignment-on)) q (127454 . 3)) ((c def c (? . 30)) q (77845 . 3)) ((c def c (c (? . 0) q check-for-break)) q (97844 . 2)) ((c meth c (c (? . 4) q get-foreground-mult)) q (127999 . 3)) ((c meth c (c (? . 5) q copy)) q (191608 . 6)) ((c meth c (c (? . 5) q can-delete?)) q (190332 . 4)) ((c meth c (c (? . 1) q refresh-delayed?)) q (151091 . 2)) ((c meth c (c (? . 66) q set-value)) q (77052 . 3)) ((c meth c (c (? . 26) q write-header)) q (122276 . 3)) ((c constructor c (? . 98)) q (15774 . 34)) ((c meth c (c (? . 5) q get-snip-position-and-location)) q (200892 . 9)) ((c def c (? . 25)) q (123515 . 2)) ((c meth c (c (? . 16) q get-line-spacing)) q (120948 . 3)) ((c meth c (c (? . 10) q get-center)) q (184080 . 2)) ((c meth c (c (? . 5) q set-region-data)) q (214422 . 5)) ((c meth c (c (? . 24) q modified)) q (157752 . 3)) ((c constructor c (? . 3)) q (110491 . 2)) ((c meth c (c (? . 10) q set-dragable)) q (188476 . 3)) ((c meth c (c (? . 8) q enable)) q (42137 . 3)) ((c constructor c (? . 67)) q (52451 . 29)) ((c meth c (c (? . 11) q get-y)) q (40426 . 2)) ((c def c (c (? . 0) q event-dispatch-handler)) q (97594 . 4)) ((c meth c (c (? . 26) q reading-version)) q (121998 . 3)) ((c def c (c (? . 68) q reader)) q (224583 . 2)) ((c meth c (c (? . 50) q read-byte)) q (174337 . 2)) ((c def c (c (? . 0) q get-font-from-user)) q (96083 . 9)) ((c meth c (c (? . 1) q locked-for-read?)) q (145005 . 2)) ((c meth c (c (? . 54) q set-boundary)) q (173674 . 3)) ((c meth c (c (? . 30) q resize)) q (79368 . 5)) ((c meth c (c (? . 57) q add)) q (165589 . 3)) ((c constructor c (? . 69)) q (49740 . 8)) ((c meth c (c (? . 21) q resize)) q (108974 . 4)) ((c meth c (c (? . 1) q get-admin)) q (139213 . 2)) ((c def c (? . 74)) q (52180 . 2)) ((c meth c (c (? . 61) q add)) q (122429 . 3)) ((c def c (? . 89)) q (21573 . 3)) ((c meth c (c (? . 67) q set-label)) q (54081 . 3)) ((c meth c (c (? . 28) q delete)) q (48165 . 3)) ((c meth c (c (? . 70) q check)) q (15546 . 3)) ((c meth c (c (? . 29) q on-size)) q (85285 . 4)) ((c meth c (c (? . 26) q read-header)) q (121901 . 3)) ((c constructor c (? . 71)) q (17668 . 2)) ((c meth c (c (? . 42) q on-paint)) q (10215 . 2)) ((c meth c (c (? . 41) q set-next)) q (164937 . 3)) ((c meth c (c (? . 72) q reparent)) q (71750 . 4)) ((c def c (? . 34)) q (226269 . 3)) ((c meth c (c (? . 10) q delete)) q (183311 . 4)) ((c constructor c (? . 5)) q (188942 . 8)) ((c meth c (c (? . 4) q get-underlined-on)) q (128958 . 2)) ((c meth c (c (? . 73) q get-data)) q (224129 . 2)) ((c meth c (c (? . 23) q accept-tab-focus)) q (5497 . 4)) ((c meth c (c (? . 5) q paragraph-start-line)) q (207341 . 4)) ((c meth c (c (? . 3) q equal-hash-code-of)) q (112988 . 3)) ((c meth c (c (? . 7) q set-min-width)) q (171996 . 3)) ((c def c (? . 102)) q (58619 . 5)) ((c meth c (c (? . 25) q set-shift-style)) q (125443 . 3)) ((c meth c (c (? . 54) q tell)) q (173866 . 2)) ((c meth c (c (? . 7) q adjust-cursor)) q (168128 . 14)) ((c meth c (c (? . 1) q get-dc)) q (139453 . 2)) ((c meth c (c (? . 1) q set-filename)) q (154091 . 5)) ((q def ((lib "wxme/number.rkt") reader)) q (225758 . 2)) ((c meth c (c (? . 17) q iconize)) q (29138 . 3)) ((c meth c (c (? . 61) q number)) q (122881 . 2)) ((c meth c (c (? . 5) q read-from-file)) q (209953 . 11)) ((c def c (c (? . 0) q special-control-key)) q (98178 . 4)) ((c meth c (c (? . 20) q set)) q (46730 . 4)) ((c meth c (c (? . 5) q can-insert?)) q (190473 . 4)) ((c meth c (c (? . 5) q get-snip-position)) q (200770 . 4)) ((c meth c (c (? . 64) q set-min-width)) q (62827 . 3)) ((c def c (c (? . 0) q current-text-keymap-initializer)) q (216582 . 5)) ((c meth c (c (? . 1) q size-cache-invalid)) q (155769 . 2)) ((c meth c (c (? . 38) q get-double-click-interval)) q (178198 . 3)) ((c meth c (c (? . 25) q get-family)) q (123909 . 4)) ((c meth c (c (? . 5) q find-position-in-line)) q (194235 . 12)) ((c meth c (c (? . 5) q do-paste)) q (192697 . 4)) ((c meth c (c (? . 4) q set-size-mult)) q (132173 . 3)) ((c constructor c (? . 54)) q (172502 . 4)) ((c meth c (c (? . 5) q kill)) q (204638 . 7)) ((c meth c (c (? . 5) q line-paragraph)) q (205521 . 3)) ((c meth c (c (? . 51) q append)) q (21176 . 3)) ((c meth c (c (? . 1) q on-char)) q (145649 . 3)) ((c constructor c (? . 21)) q (106460 . 18)) ((c def c (c (? . 0) q get-top-level-windows)) q (97886 . 3)) ((c meth c (c (? . 25) q get-weight)) q (125134 . 2)) ((c meth c (c (? . 1) q end-edit-sequence)) q (138657 . 2)) ((c meth c (c (? . 5) q find-string-embedded-all)) q (197316 . 21)) ((c meth c (c (? . 5) q last-position)) q (205012 . 2)) ((c meth c (c (? . 20) q set-column-width)) q (47188 . 9)) ((c meth c (c (? . 1) q save-port)) q (151822 . 8)) ((c meth c (c (? . 30) q get-focus-window)) q (78595 . 3)) ((c meth c (c (? . 5) q on-delete)) q (206481 . 4)) ((c meth c (c (? . 12) q on-event)) q (162749 . 3)) ((c def c (c (? . 0) q play-sound)) q (103916 . 4)) ((c meth c (c (? . 1) q set-paste-text-only)) q (155342 . 3)) ((c def c (c (? . 0) q register-collecting-blit)) q (104158 . 23)) ((c constructor c (? . 16)) q (118314 . 2)) ((c constructor c (? . 24)) q (156567 . 2)) ((c meth c (c (? . 49) q read-fixed-integer)) q (222384 . 3)) ((c def c (c (? . 9) q read-snip-from-port)) q (222795 . 5)) ((c meth c (c (? . 7) q set-min-height)) q (171876 . 3)) ((c constructor c (? . 42)) q (6700 . 32)) ((c meth c (c (? . 1) q get-file)) q (139784 . 3)) ((c meth c (c (? . 5) q caret-hidden?)) q (190676 . 2)) ((c meth c (c (? . 10) q set-after)) q (188201 . 4)) ((c def c (? . 76)) q (81414 . 3)) ((c meth c (c (? . 25) q set-base-style)) q (125252 . 3)) ((c meth c (c (? . 74) q get-items)) q (52228 . 3)) ((c meth c (c (? . 5) q get-styles-sticky)) q (201401 . 2)) ((c meth c (c (? . 30) q set-icon)) q (79547 . 7)) ((c meth c (c (? . 47) q put-fixed)) q (175785 . 4)) ((c constructor c (? . 13)) q (133380 . 2)) ((c meth c (c (? . 42) q make-bitmap)) q (10062 . 4)) ((c meth c (c (? . 27) q set-b)) q (109766 . 3)) ((c def c (? . 69)) q (49651 . 4)) ((c def c (c (? . 0) q application-start-empty-handler)) q (99575 . 4)) ((c meth c (c (? . 15) q button-changed?)) q (55771 . 3)) ((c meth c (c (? . 15) q get-x)) q (57093 . 2)) ((c meth c (c (? . 5) q set-position)) q (213296 . 11)) ((c meth c (c (? . 4) q get-size-mult)) q (128267 . 2)) ((c meth c (c (? . 31) q notify)) q (77629 . 2)) ((c meth c (c (? . 5) q get-end-position)) q (199599 . 2)) ((c meth c (c (? . 12) q call-as-primary-owner)) q (161913 . 3)) ((c meth c (c (? . 1) q get-filename)) q (139896 . 3)) ((c def c (c (? . 0) q add-editor-keymap-functions)) q (215649 . 3)) ((c meth c (c (? . 50) q tell)) q (174609 . 3)) ((c meth c (c (? . 23) q get-canvas-background)) q (5664 . 3)) ((c meth c (c (? . 38) q remove-grab-key-function)) q (178735 . 2)) ((c meth c (c (? . 30) q on-traverse-char)) q (79147 . 3)) ((c meth c (c (? . 11) q get-shift-down)) q (40315 . 2)) ((c def c (c (? . 0) q message+check-box/custom)) q (92863 . 25)) ((c meth c (c (? . 57) q find-position)) q (165820 . 4)) ((c meth c (c (? . 7) q get-max-height)) q (170367 . 3)) ((c meth c (c (? . 10) q copy-self-to)) q (183190 . 3)) ((c meth c (c (? . 30) q get-edit-target-window)) q (78310 . 3)) ((c constructor c (? . 33)) q (11760 . 32)) ((c def c (c (? . 75) q reader)) q (226226 . 2)) ((c meth c (c (? . 11) q set-key-code)) q (40810 . 3)) ((c meth c (c (? . 21) q set-bitmap)) q (109121 . 4)) ((c def c (c (? . 0) q get-display-left-top-inset)) q (100022 . 11)) ((c meth c (c (? . 10) q interactive-adjust-resize)) q (185279 . 7)) ((c meth c (c (? . 20) q get-column-order)) q (45778 . 3)) ((c meth c (c (? . 64) q get-font)) q (62660 . 2)) ((c def c (? . 47)) q (174896 . 3)) ((c def c (? . 62)) q (63146 . 4)) ((c meth c (c (? . 25) q get-text-space)) q (124790 . 4)) ((c def c (c (? . 0) q special-option-key)) q (98280 . 4)) ((c meth c (c (? . 45) q get-parent)) q (125 . 3)) ((c meth c (c (? . 61) q find-position)) q (122637 . 4)) ((c meth c (c (? . 11) q set-other-shift-key-code)) q (41706 . 3)) ((c meth c (c (? . 71) q get-types)) q (17934 . 2)) ((c meth c (c (? . 36) q border)) q (1176 . 4)) ((c meth c (c (? . 21) q get-filename)) q (107707 . 4)) ((c meth c (c (? . 36) q begin-container-sequence)) q (1106 . 2)) ((c def c (c (? . 0) q put-file)) q (88733 . 18)) ((c meth c (c (? . 1) q get-snip-data)) q (141010 . 4)) ((c meth c (c (? . 12) q get-editor)) q (162147 . 3)) ((c meth c (c (? . 57) q find)) q (165705 . 4)) ((c meth c (c (? . 5) q erase)) q (193003 . 2)) ((c meth c (c (? . 16) q resized)) q (119977 . 4)) ((c meth c (c (? . 29) q show)) q (86668 . 3)) ((c meth c (c (? . 3) q other-equal-to?)) q (112847 . 4)) ((c meth c (c (? . 5) q set-between-threshold)) q (211246 . 3)) ((c meth c (c (? . 34) q get-comment)) q (226322 . 2)) ((c def c (? . 18)) q (22255 . 3)) ((c meth c (c (? . 54) q remove-boundary)) q (173611 . 2)) ((c meth c (c (? . 1) q undo)) q (155933 . 2)) ((c meth c (c (? . 35) q horiz-margin)) q (71373 . 4)) ((c meth c (c (? . 24) q resized)) q (158393 . 3)) ((c def c (? . 49)) q (222266 . 2)) ((c meth c (c (? . 3) q get-style)) q (114785 . 2)) ((c meth c (c (? . 27) q set-r)) q (109896 . 3)) ((c meth c (c (? . 4) q set-weight-off)) q (133113 . 3)) ((c constructor c (? . 76)) q (81471 . 32)) ((c meth c (c (? . 1) q adjust-cursor)) q (135420 . 4)) ((c meth c (c (? . 13) q notify-on-change)) q (134578 . 3)) ((c meth c (c (? . 17) q is-fullscreened?)) q (29214 . 2)) ((c meth c (c (? . 3) q get-text)) q (114843 . 5)) ((c meth c (c (? . 4) q collapse)) q (127077 . 3)) ((c meth c (c (? . 34) q get-error-message)) q (226577 . 2)) ((c constructor c (? . 12)) q (159159 . 42)) ((c meth c (c (? . 7) q get-max-width)) q (170469 . 3)) ((c def c (? . 94)) q (34160 . 3)) ((c def c (? . 15)) q (54191 . 3)) ((c meth c (c (? . 1) q set-style-list)) q (155572 . 3)) ((c meth c (c (? . 31) q stop)) q (77805 . 2)) ((c meth c (c (? . 40) q set-item-label)) q (74557 . 4)) ((c meth c (c (? . 29) q on-move)) q (85179 . 4)) ((c meth c (c (? . 10) q on-move-to)) q (186922 . 9)) ((c meth c (c (? . 11) q get-control+meta-is-altgr)) q (39472 . 2)) ((c meth c (c (? . 36) q get-alignment)) q (2041 . 4)) ((c meth c (c (? . 14) q set-event-type)) q (68760 . 4)) ((c def c (c (? . 0) q send-message-to-window)) q (105078 . 5)) ((c def c (c (? . 0) q flush-display)) q (99726 . 2)) ((c constructor c (? . 47)) q (174957 . 4)) ((c meth c (c (? . 3) q resize)) q (117304 . 4)) ((c meth c (c (? . 83) q get-data)) q (225302 . 2)) ((c meth c (c (? . 30) q on-system-menu-char)) q (79256 . 3)) ((c meth c (c (? . 1) q after-edit-sequence)) q (135542 . 2)) ((c meth c (c (? . 5) q find-newline)) q (193280 . 8)) ((c def c (? . 7)) q (166312 . 3)) ((c meth c (c (? . 3) q get-num-scroll-steps)) q (114494 . 3)) ((c meth c (c (? . 23) q on-event)) q (6172 . 3)) ((c meth c (c (? . 4) q get-transparent-text-backing-on)) q (128818 . 3)) ((c meth c (c (? . 1) q begin-write-header-footer-to-file)) q (136114 . 8)) ((c meth c (c (? . 1) q is-locked?)) q (144079 . 2)) ((c def c (c (? . 0) q append-editor-operation-menu-items)) q (216051 . 10)) ((c meth c (c (? . 36) q after-new-child)) q (1002 . 3)) ((c meth c (c (? . 15) q set-mod5-down)) q (58213 . 3)) ((c meth c (c (? . 3) q equal-to?)) q (112712 . 4)) ((c def c (c (? . 0) q graphical-read-eval-print-loop)) q (102853 . 5)) ((c meth c (c (? . 30) q can-exit?)) q (77992 . 2)) ((c meth c (c (? . 33) q set-value)) q (13636 . 3)) ((c def c (? . 77)) q (176574 . 3)) ((c meth c (c (? . 10) q remove)) q (187844 . 3)) ((c meth c (c (? . 5) q copy-self-to)) q (191869 . 3)) ((c meth c (c (? . 1) q kill)) q (144236 . 3)) ((c meth c (c (? . 4) q get-face)) q (127705 . 2)) ((c meth c (c (? . 10) q set-before)) q (188337 . 4)) ((c meth c (c (? . 1) q set-max-width)) q (154890 . 3)) ((c def c (c (? . 0) q get-default-shortcut-prefix)) q (102113 . 6)) ((c meth c (c (? . 78) q get-width)) q (225961 . 2)) ((c meth c (c (? . 1) q get-inactive-caret-threshold)) q (140153 . 3)) ((c meth c (c (? . 4) q get-size-in-pixels-off)) q (128134 . 2)) ((c meth c (c (? . 29) q has-focus?)) q (84879 . 2)) ((c meth c (c (? . 5) q get-revision-number)) q (200686 . 3)) ((c meth c (c (? . 20) q set-column-order)) q (47061 . 3)) ((c meth c (c (? . 34) q get-test)) q (226391 . 2)) ((c def c (c (? . 0) q file-creator-and-type)) q (101311 . 15)) ((c def c (c (? . 0) q application-file-handler)) q (99106 . 4)) ((c meth c (c (? . 28) q get-string-selection)) q (48650 . 3)) ((c constructor c (? . 79)) q (69106 . 38)) ((c meth c (c (? . 5) q find-position)) q (193779 . 12)) ((c meth c (c (? . 16) q get-view-size)) q (118862 . 4)) ((c meth c (c (? . 5) q after-split-snip)) q (189949 . 3)) ((c meth c (c (? . 34) q get-collapsed?)) q (226707 . 2)) ((c def c (? . 80)) q (122954 . 3)) ((c meth c (c (? . 1) q use-file-text-mode)) q (156043 . 4)) ((c def c (c (? . 99) q gui-available?)) q (226821 . 2)) ((c meth c (c (? . 77) q get-bytes)) q (176758 . 2)) ((c meth c (c (? . 5) q extend-position)) q (193043 . 3)) ((c meth c (c (? . 62) q get-selection)) q (65707 . 3)) ((c def c (? . 12)) q (159078 . 4)) ((c meth c (c (? . 29) q on-drop-file)) q (85029 . 3)) ((c meth c (c (? . 1) q get-canvases)) q (139372 . 3)) ((c def c (? . 81)) q (26425 . 3)) ((c meth c (c (? . 4) q set-alignment-on)) q (129307 . 3)) ((c meth c (c (? . 95) q read-special)) q (221869 . 9)) ((c meth c (c (? . 49) q read-inexact)) q (222473 . 3)) ((c def c (? . 51)) q (19202 . 3)) ((c def c (? . 20)) q (42771 . 4)) ((c meth c (c (? . 7) q set-editor)) q (171075 . 3)) ((c meth c (c (? . 4) q get-background-mult)) q (127624 . 3)) ((c def c (c (? . 0) q get-current-mouse-state)) q (103152 . 5)) ((c constructor c (? . 82)) q (135154 . 2)) ((c meth c (c (? . 10) q insert)) q (184345 . 15)) ((c def c (? . 70)) q (13712 . 4)) ((c constructor c (? . 41)) q (164602 . 2)) ((c meth c (c (? . 1) q copy)) q (137384 . 4)) ((c meth c (c (? . 41) q write)) q (165037 . 3)) ((c meth c (c (? . 5) q set-padding)) q (212260 . 9)) ((c meth c (c (? . 5) q position-location)) q (208462 . 13)) ((c meth c (c (? . 10) q set-selection-visible)) q (188775 . 3)) ((c def c (c (? . 0) q make-eventspace)) q (97387 . 2)) ((c meth c (c (? . 40) q set)) q (74465 . 3)) ((c meth c (c (? . 1) q blink-caret)) q (136420 . 2)) ((c meth c (c (? . 5) q hide-caret)) q (202984 . 3)) ((c def c (? . 4)) q (125673 . 3)) ((c meth c (c (? . 17) q fullscreen)) q (28923 . 3)) ((c def c (? . 83)) q (225221 . 4)) ((c meth c (c (? . 5) q after-insert)) q (189601 . 4)) ((c meth c (c (? . 1) q paste-x-selection)) q (148696 . 3)) ((c def c (? . 41)) q (164547 . 3)) ((c meth c (c (? . 1) q on-focus)) q (146194 . 3)) ((c def c (c (? . 84) q reader)) q (225178 . 2)) ((c meth c (c (? . 5) q get-tabs)) q (201456 . 7)) ((c meth c (c (? . 57) q number)) q (166094 . 3)) ((c meth c (c (? . 1) q set-min-height)) q (155012 . 3)) ((c meth c (c (? . 5) q get-anchor)) q (199279 . 2)) ((c meth c (c (? . 29) q on-focus)) q (85111 . 3)) ((c def c (? . 23)) q (5432 . 3)) ((c meth c (c (? . 6) q same-clipboard-client?)) q (18503 . 3)) ((c def c (? . 54)) q (172442 . 3)) ((c def c (c (? . 0) q eventspace?)) q (97537 . 3)) ((c meth c (c (? . 3) q partial-offset)) q (117019 . 6)) ((c meth c (c (? . 5) q on-default-char)) q (206292 . 3)) ((c meth c (c (? . 50) q seek)) q (174411 . 3)) ((c meth c (c (? . 66) q get-value)) q (76900 . 2)) ((c meth c (c (? . 30) q on-close)) q (78888 . 2)) ((c meth c (c (? . 18) q set-event-type)) q (23138 . 6)) ((c constructor c (? . 26)) q (121615 . 2)) ((c meth c (c (? . 85) q set-orientation)) q (37582 . 3)) ((c meth c (c (? . 15) q button-down?)) q (55902 . 3)) ((c meth c (c (? . 78) q get-pin-y)) q (226166 . 2)) ((c def c (? . 90)) q (67469 . 4)) ((c def c (c (? . 0) q get-directory)) q (89674 . 11)) ((c meth c (c (? . 4) q get-size-add)) q (128080 . 2)) ((c meth c (c (? . 23) q on-tab-in)) q (6307 . 2)) ((c meth c (c (? . 13) q replace-named-style)) q (134763 . 6)) ((c meth c (c (? . 56) q bad?)) q (176146 . 2)) ((c meth c (c (? . 27) q get-g)) q (109573 . 2)) ((c meth c (c (? . 5) q get-file-format)) q (199833 . 3)) ((c meth c (c (? . 80) q insert)) q (123218 . 5)) ((c meth c (c (? . 12) q on-paint)) q (162923 . 2)) ((c meth c (c (? . 10) q after-move-to)) q (180446 . 9)) ((c constructor c (? . 86)) q (3534 . 33)) ((c meth c (c (? . 1) q get-focus-snip)) q (140078 . 2)) ((c meth c (c (? . 7) q style-background-used?)) q (172286 . 2)) ((c meth c (c (? . 45) q min-width)) q (304 . 4)) ((c meth c (c (? . 4) q set-family)) q (131764 . 4)) ((c meth c (c (? . 29) q is-enabled?)) q (84929 . 2)) ((c def c (? . 38)) q (177325 . 3)) ((c meth c (c (? . 15) q set-left-down)) q (57801 . 3)) ((c meth c (c (? . 62) q set-selection)) q (65935 . 3)) ((c def c (? . 39)) q (165131 . 3)) ((c meth c (c (? . 88) q command)) q (21481 . 3)) ((c meth c (c (? . 29) q on-subwindow-char)) q (85411 . 5)) ((c meth c (c (? . 10) q can-interactive-move?)) q (181902 . 3)) ((c meth c (c (? . 78) q get-argb)) q (225899 . 2)) ((c meth c (c (? . 7) q get-tight-text-fit)) q (170773 . 2)) ((c def c (? . 8)) q (42060 . 3)) ((c meth c (c (? . 26) q set-classname)) q (122115 . 3)) ((c meth c (c (? . 20) q is-selected?)) q (46430 . 3)) ((c meth c (c (? . 25) q get-base-style)) q (123685 . 2)) ((c meth c (c (? . 1) q resized)) q (151337 . 4)) ((c meth c (c (? . 5) q after-set-position)) q (189836 . 2)) ((c meth c (c (? . 40) q get-number)) q (74307 . 2)) ((c meth c (c (? . 3) q get-flags)) q (114438 . 2)) ((c meth c (c (? . 29) q focus)) q (83875 . 2)) ((c meth c (c (? . 10) q after-select)) q (181384 . 4)) ((c def c (? . 6)) q (18060 . 2)) ((c meth c (c (? . 47) q tell)) q (176006 . 2)) ((c meth c (c (? . 5) q delete)) q (192244 . 6)) ((c meth c (c (? . 1) q read-footer-from-file)) q (149769 . 5)) ((c meth c (c (? . 62) q get-item-label)) q (65438 . 3)) ((c meth c (c (? . 1) q is-modified?)) q (144130 . 2)) ((c meth c (c (? . 54) q ok?)) q (173557 . 2)) ((c meth c (c (? . 23) q flush)) q (5622 . 2)) ((c meth c (c (? . 7) q set-margin)) q (171424 . 6)) ((c meth c (c (? . 3) q on-event)) q (116100 . 13)) ((c meth c (c (? . 17) q is-maximized?)) q (29320 . 2)) ((c meth c (c (? . 42) q scroll)) q (10618 . 4)) ((c meth c (c (? . 42) q init-auto-scrollbars)) q (9009 . 9)) ((c meth c (c (? . 29) q get-cursor)) q (84061 . 2)) ((c meth c (c (? . 1) q invalidate-bitmap-cache)) q (143583 . 11)) ((c meth c (c (? . 16) q recounted)) q (119766 . 4)) ((c meth c (c (? . 13) q new-named-style)) q (134382 . 6)) ((c meth c (c (? . 16) q set-caret-owner)) q (120693 . 5)) ((c meth c (c (? . 38) q remove-grab-mouse-function)) q (178796 . 2)) ((c meth c (c (? . 10) q on-insert)) q (186543 . 6)) ((c meth c (c (? . 5) q paragraph-start-position)) q (207474 . 6)) ((c def c (? . 40)) q (71938 . 3)) ((c meth c (c (? . 79) q get-value)) q (71169 . 2)) ((c meth c (c (? . 56) q write-bytes)) q (176483 . 3)) ((c constructor c (? . 87)) q (60166 . 32)) ((c meth c (c (? . 4) q set-underlined-off)) q (132956 . 3)) ((c meth c (c (? . 38) q set-grab-mouse-function)) q (179234 . 7)) ((c def c (? . 28)) q (47966 . 3)) ((c meth c (c (? . 1) q get-max-width)) q (140661 . 3)) ((c meth c (c (? . 62) q enable)) q (65251 . 6)) ((c meth c (c (? . 5) q set-overwrite-mode)) q (212184 . 3)) ((c meth c (c (? . 15) q get-mod5-down)) q (56917 . 2)) ((c meth c (c (? . 74) q on-demand)) q (52316 . 2)) ((c meth c (c (? . 11) q set-other-altgr-key-code)) q (41344 . 3)) ((c def c (c (? . 0) q write-editor-global-header)) q (219799 . 3)) ((c meth c (c (? . 25) q get-face)) q (123851 . 2)) ((c def c (? . 104)) q (33995 . 3)) ((c meth c (c (? . 21) q equal-secondary-hash-code-of)) q (107406 . 4)) ((c meth c (c (? . 1) q global-to-local)) q (141885 . 4)) ((c meth c (c (? . 25) q switch-to)) q (125535 . 4)) ((c meth c (c (? . 23) q min-client-width)) q (5947 . 4)) ((c meth c (c (? . 30) q on-exit)) q (78943 . 2)) ((c meth c (c (? . 12) q set-editor)) q (163851 . 5)) ((c def c (? . 56)) q (176080 . 3)) ((c meth c (c (? . 27) q get-r)) q (109619 . 2)) ((c def c (c (? . 0) q get-the-snip-class-list)) q (216926 . 2)) ((c def c (c (? . 0) q system-position-ok-before-cancel?)) q (105279 . 2)) ((c meth c (c (? . 76) q get-orientation)) q (83386 . 2)) ((c meth c (c (? . 49) q read-raw-bytes)) q (222566 . 3)) ((c meth c (c (? . 7) q get-align-top-line)) q (168658 . 2)) ((c meth c (c (? . 16) q popup-menu)) q (119596 . 6)) ((c constructor c (? . 11)) q (37803 . 29)) ((c meth c (c (? . 1) q on-new-image-snip)) q (146790 . 13)) ((c meth c (c (? . 11) q set-other-shift-altgr-key-code)) q (41581 . 3)) ((c meth c (c (? . 11) q set-meta-down)) q (41024 . 3)) ((c meth c (c (? . 25) q get-shift-style)) q (124222 . 2)) ((c def c (c (? . 9) q extract-used-classes)) q (220426 . 3)) ((c meth c (c (? . 3) q set-unmodified)) q (117885 . 2)) ((c meth c (c (? . 28) q set-selection)) q (48755 . 3)) ((c meth c (c (? . 1) q print)) q (148793 . 14)) ((c def c (? . 78)) q (225844 . 3)) ((c meth c (c (? . 11) q get-other-altgr-key-code)) q (39930 . 3)) ((c meth c (c (? . 30) q can-close?)) q (77932 . 2)) ((c meth c (c (? . 42) q get-scroll-page)) q (8467 . 4)) ((c meth c (c (? . 1) q set-admin)) q (153571 . 3)) ((c meth c (c (? . 5) q get-autowrap-bitmap-width)) q (199327 . 3)) ((c def c (? . 71)) q (17608 . 3)) ((c meth c (c (? . 25) q get-underlined)) q (125081 . 2)) ((c meth c (c (? . 1) q on-event)) q (146103 . 3)) ((c def c (c (? . 0) q current-eventspace-has-standard-menus?)) q (98842 . 2)) ((c meth c (c (? . 29) q on-subwindow-event)) q (85604 . 5)) ((c meth c (c (? . 4) q get-weight-on)) q (129109 . 3)) ((c meth c (c (? . 5) q paste-next)) q (207930 . 2)) ((c def c (? . 88)) q (21415 . 3)) ((c meth c (c (? . 63) q get-data)) q (223535 . 2)) ((c meth c (c (? . 7) q use-style-background)) q (172354 . 3)) ((c def c (? . 50)) q (173939 . 3)) ((c def c (c (? . 0) q make-screen-bitmap)) q (103769 . 4)) ((c meth c (c (? . 5) q set-wordbreak-map)) q (215219 . 3)) ((c def c (? . 11)) q (37751 . 3)) ((c meth c (c (? . 12) q wheel-step)) q (164360 . 5)) ((c meth c (c (? . 1) q after-save-file)) q (135685 . 3)) ((c def c (c (? . 0) q the-x-selection-clipboard)) q (105387 . 2)) ((c meth c (c (? . 29) q enable)) q (83801 . 3)) ((c meth c (c (? . 58) q get-data)) q (223096 . 2)) ((c meth c (c (? . 4) q set-smoothing-off)) q (132247 . 4)) ((c meth c (c (? . 3) q on-char)) q (115710 . 13)) ((c meth c (c (? . 29) q screen->client)) q (86349 . 5)) ((c constructor c (? . 89)) q (21644 . 9)) ((c meth c (c (? . 60) q is-deleted?)) q (50510 . 2)) ((c meth c (c (? . 5) q get-text)) q (201784 . 9)) ((c def c (c (? . 0) q get-page-setup-from-user)) q (96906 . 10)) ((c meth c (c (? . 71) q on-replaced)) q (18002 . 2)) ((c meth c (c (? . 38) q handle-key-event)) q (178280 . 4)) ((c meth c (c (? . 36) q add-child)) q (902 . 3)) ((c meth c (c (? . 3) q next)) q (115648 . 2)) ((c meth c (c (? . 51) q get-menu)) q (21251 . 2)) ((c constructor c (? . 90)) q (67559 . 4)) ((c def c (? . 58)) q (223043 . 3)) ((c meth c (c (? . 25) q is-join?)) q (125205 . 2)) ((c meth c (c (? . 1) q set-active-canvas)) q (153467 . 3)) ((c meth c (c (? . 16) q get-tabs)) q (121215 . 7)) ((c meth c (c (? . 11) q set-shift-down)) q (41825 . 3)) ((c meth c (c (? . 1) q auto-wrap)) q (135771 . 4)) ((c meth c (c (? . 20) q append)) q (45387 . 4)) ((c meth c (c (? . 58) q get-h)) q (223229 . 2)) ((c def c (? . 10)) q (179426 . 4)) ((c meth c (c (? . 13) q number)) q (134695 . 2)) ((c def c (c (? . 0) q get-panel-background)) q (102337 . 2)) ((c meth c (c (? . 37) q get)) q (105606 . 5)) ((c meth c (c (? . 38) q set-grab-key-function)) q (179046 . 7)) ((c meth c (c (? . 30) q move)) q (78686 . 4)) ((c meth c (c (? . 1) q add-undo)) q (135341 . 3)) ((c meth c (c (? . 17) q modified)) q (29451 . 4)) ((c def c (c (? . 9) q register-lib-mapping!)) q (220528 . 4)) ((c meth c (c (? . 4) q get-size-in-pixels-on)) q (128201 . 2)) ((c meth c (c (? . 36) q end-container-sequence)) q (1973 . 2)) ((c meth c (c (? . 7) q set-tight-text-fit)) q (172115 . 3)) ((c def c (c (? . 0) q read-editor-global-header)) q (218911 . 3)) ((c meth c (c (? . 7) q get-min-height)) q (170570 . 3)) ((c def c (? . 73)) q (224049 . 4)) ((c def c (c (? . 0) q is-busy?)) q (103373 . 2)) ((c meth c (c (? . 53) q ok?)) q (24057 . 2)) ((c meth c (c (? . 23) q set-canvas-background)) q (6402 . 3)) ((c meth c (c (? . 1) q insert-file)) q (142262 . 8)) ((c meth c (c (? . 4) q set-size-in-pixels-off)) q (132008 . 3)) ((c meth c (c (? . 24) q needs-update)) q (157839 . 9)) ((c def c (c (? . 0) q open-input-text-editor)) q (217197 . 17)) ((c meth c (c (? . 1) q get-style-list)) q (141627 . 2)) ((c meth c (c (? . 20) q set-data)) q (47571 . 4)) ((c def c (c (? . 0) q write-editor-version)) q (219899 . 4)) ((c meth c (c (? . 47) q pretty-start)) q (175310 . 2)) ((c meth c (c (? . 10) q move-to)) q (185997 . 5)) ((c meth c (c (? . 56) q tell)) q (176309 . 3)) ((c def c (? . 27)) q (109360 . 2)) ((c meth c (c (? . 89) q set-column)) q (22144 . 3)) ((c meth c (c (? . 12) q on-size)) q (162976 . 5)) ((c meth c (c (? . 1) q select-all)) q (153419 . 2)) ((c meth c (c (? . 15) q moving?)) q (57258 . 2)) ((c meth c (c (? . 28) q find-string)) q (48254 . 4)) ((c meth c (c (? . 20) q get-column-labels)) q (45678 . 3)) ((c meth c (c (? . 39) q set-classname)) q (165455 . 3)) ((c meth c (c (? . 5) q after-change-style)) q (189317 . 4)) ((c meth c (c (? . 38) q remove-chained-keymap)) q (178635 . 3)) ((c meth c (c (? . 5) q get-position)) q (200323 . 4)) ((c def c (c (? . 0) q label-string?)) q (105447 . 3)) ((c meth c (c (? . 69) q is-enabled?)) q (50257 . 2)) ((c meth c (c (? . 1) q on-snip-modified)) q (148365 . 5)) ((c meth c (c (? . 25) q get-alignment)) q (123549 . 2)) ((c meth c (c (? . 4) q set-underlined-on)) q (133035 . 3)) ((c def c (? . 21)) q (106408 . 3)) ((c meth c (c (? . 1) q insert-image)) q (142615 . 13)) ((c meth c (c (? . 13) q basic-style)) q (133439 . 2)) ((c meth c (c (? . 15) q set-shift-down)) q (58378 . 3)) ((c meth c (c (? . 69) q get-frame)) q (50182 . 2)) ((c meth c (c (? . 21) q get-bitmap)) q (107547 . 2)) ((c def c (c (? . 0) q get-the-editor-data-class-list)) q (216840 . 3)) ((c meth c (c (? . 1) q on-display-size-when-ready)) q (145985 . 2)) ((c meth c (c (? . 45) q stretchable-width)) q (699 . 4)) ((c meth c (c (? . 10) q interactive-adjust-mouse)) q (184836 . 5)) ((c meth c (c (? . 11) q set-control-down)) q (40639 . 3)) ((c meth c (c (? . 5) q set-position-bias-scroll)) q (213767 . 13)) ((c def c (c (? . 0) q current-eventspace-has-menu-root?)) q (98907 . 2)) ((c meth c (c (? . 42) q set-scroll-pos)) q (10928 . 4)) ((c meth c (c (? . 1) q on-load-file)) q (146263 . 6)) ((c meth c (c (? . 12) q lazy-refresh)) q (162521 . 4)) ((c meth c (c (? . 5) q on-default-event)) q (206385 . 3)) ((c meth c (c (? . 15) q dragging?)) q (56156 . 2)) ((c meth c (c (? . 38) q chain-to-keymap)) q (178032 . 5)) ((c def c (? . 1)) q (135209 . 2)) ((c meth c (c (? . 3) q blink-caret)) q (110959 . 5)) ((c meth c (c (? . 4) q get-weight-off)) q (129020 . 3)) ((c meth c (c (? . 5) q change-style)) q (190727 . 17)) ((c meth c (c (? . 4) q set-delta-background)) q (130932 . 7)) ((c meth c (c (? . 5) q after-set-size-constraint)) q (189889 . 2)) ((c meth c (c (? . 4) q get-foreground-add)) q (127920 . 3)) ((c meth c (c (? . 37) q set-g)) q (106238 . 3)) ((c meth c (c (? . 62) q get-number)) q (65636 . 2)) ((c meth c (c (? . 25) q get-background)) q (123623 . 2)) ((c constructor c (? . 15)) q (54245 . 35)) ((c meth c (c (? . 5) q split-snip)) q (215333 . 3)) ((c meth c (c (? . 26) q get-classname)) q (121674 . 2)) ((c meth c (c (? . 6) q get-clipboard-data)) q (18218 . 6)) ((c meth c (c (? . 10) q find-snip)) q (183909 . 6)) ((c meth c (c (? . 5) q flash-off)) q (198816 . 2)) ((c meth c (c (? . 24) q update-cursor)) q (159021 . 2)) ((c meth c (c (? . 1) q needs-update)) q (145120 . 11)) ((c meth c (c (? . 5) q on-change-style)) q (206150 . 4)) ((c meth c (c (? . 11) q set-mod5-down)) q (41264 . 3)) ((c meth c (c (? . 28) q append)) q (48035 . 3)) ((c meth c (c (? . 15) q get-middle-down)) q (56741 . 2)) ((c meth c (c (? . 10) q on-default-event)) q (186171 . 3)) ((c meth c (c (? . 15) q set-control-down)) q (57473 . 3)) ((c meth c (c (? . 58) q get-dy)) q (223356 . 2)) ((c meth c (c (? . 5) q set-clickback)) q (211366 . 14)) ((c meth c (c (? . 10) q move)) q (185802 . 8)) ((c meth c (c (? . 20) q get-first-visible-item)) q (46198 . 3)) ((c meth c (c (? . 10) q can-select?)) q (182871 . 4)) ((c meth c (c (? . 5) q set-anchor)) q (211044 . 3)) ((c meth c (c (? . 17) q is-iconized?)) q (29269 . 2)) ((c meth c (c (? . 20) q set-string)) q (47784 . 5)) ((c meth c (c (? . 17) q set-status-text)) q (29914 . 3)) ((c meth c (c (? . 1) q get-flattened-text)) q (140020 . 2)) ((c def c (c (? . 0) q eventspace-event-evt)) q (97749 . 3)) ((c meth c (c (? . 6) q set-clipboard-client)) q (18816 . 5)) ((c def c (c (? . 91) q reader)) q (225801 . 2)) ((c meth c (c (? . 66) q get-field-background)) q (76827 . 2)) ((c constructor c (? . 92)) q (49054 . 13)) ((c meth c (c (? . 3) q adjust-cursor)) q (110538 . 14)) ((c meth c (c (? . 1) q get-load-overwrites-styles)) q (140340 . 2)) ((c meth c (c (? . 29) q set-label)) q (86595 . 3)) ((c meth c (c (? . 15) q set-caps-down)) q (57391 . 3)) ((c meth c (c (? . 15) q leaving?)) q (57205 . 2)) ((c def c (c (? . 0) q position-integer?)) q (104022 . 3)) ((c meth c (c (? . 1) q on-local-event)) q (146588 . 3)) ((c meth c (c (? . 78) q get-height)) q (226033 . 2)) ((c meth c (c (? . 5) q cut)) q (191984 . 6)) ((c meth c (c (? . 11) q get-key-release-code)) q (39619 . 3)) ((c meth c (c (? . 1) q release-snip)) q (151148 . 3)) ((c def c (c (? . 0) q message-box)) q (90293 . 13)) ((c meth c (c (? . 7) q set-inset)) q (171212 . 6)) ((c meth c (c (? . 10) q do-copy)) q (183434 . 4)) ((c meth c (c (? . 29) q get-size)) q (84633 . 3)) ((c meth c (c (? . 76) q set-orientation)) q (83284 . 3)) ((c meth c (c (? . 3) q find-scroll-step)) q (113245 . 3)) ((c meth c (c (? . 60) q get-parent)) q (50394 . 3)) ((c meth c (c (? . 1) q find-first-snip)) q (138940 . 2)) ((c meth c (c (? . 10) q change-style)) q (182985 . 5)) ((c meth c (c (? . 5) q paste-x-selection)) q (207975 . 7)) ((c meth c (c (? . 42) q init-manual-scrollbars)) q (9452 . 13)) ((c meth c (c (? . 3) q size-cache-invalid)) q (117934 . 2)) ((c meth c (c (? . 42) q get-scroll-pos)) q (8594 . 3)) ((c meth c (c (? . 66) q set-field-background)) q (76952 . 3)) ((c def c (c (? . 0) q get-display-count)) q (99901 . 2)) ((c meth c (c (? . 15) q set-meta-down)) q (57883 . 3)) ((c meth c (c (? . 36) q reflow-container)) q (2896 . 2)) ((c constructor c (? . 43)) q (176892 . 2)) ((c def c (c (? . 0) q append-editor-font-menu-items)) q (215930 . 3)) ((c meth c (c (? . 42) q on-scroll)) q (10260 . 3)) ((c meth c (c (? . 1) q write-headers-to-file)) q (156289 . 3)) ((c meth c (c (? . 10) q after-insert)) q (179921 . 9)) ((c meth c (c (? . 5) q get-visible-position-range)) q (202557 . 7)) ((c def c (? . 93)) q (50611 . 4)) ((c meth c (c (? . 5) q get-wordbreak-map)) q (202892 . 3)) ((c def c (? . 52)) q (224626 . 4)) ((c meth c (c (? . 5) q paragraph-end-line)) q (206990 . 4)) ((c meth c (c (? . 7) q get-margin)) q (170118 . 6)) ((c meth c (c (? . 29) q get-x)) q (84771 . 2)) ((c meth c (c (? . 29) q on-superwindow-enable)) q (85978 . 3)) ((c meth c (c (? . 30) q center)) q (78051 . 3)) ((c meth c (c (? . 1) q locations-computed?)) q (144819 . 2)) ((c meth c (c (? . 5) q after-merge-snips)) q (189740 . 3)) ((c meth c (c (? . 38) q handle-mouse-event)) q (178400 . 4)) ((c meth c (c (? . 10) q set-selected)) q (188686 . 3)) ((c meth c (c (? . 5) q line-location)) q (205393 . 4)) ((c def c (c (? . 9) q wxme-read)) q (221019 . 3)) ((c meth c (c (? . 10) q after-interactive-resize)) q (180345 . 3)) ((c meth c (c (? . 16) q call-with-busy-cursor)) q (121124 . 3)) ((c constructor c (? . 94)) q (34217 . 26)) ((c meth c (c (? . 85) q get-orientation)) q (37686 . 2)) ((c meth c (c (? . 20) q delete-column)) q (45586 . 3)) ((c meth c (c (? . 37) q set)) q (105992 . 5)) ((c def c (c (? . 0) q can-get-page-setup-from-user?)) q (97331 . 2)) ((c meth c (c (? . 12) q on-char)) q (162654 . 3)) ((c meth c (c (? . 1) q can-save-file?)) q (137054 . 6)) ((c meth c (c (? . 54) q get-fixed)) q (173051 . 4)) ((c meth c (c (? . 1) q get-space)) q (141551 . 2)) ((c def c (c (? . 0) q hide-cursor-until-moved)) q (103326 . 2)) ((c meth c (c (? . 7) q get-editor)) q (168722 . 3)) ((c meth c (c (? . 1) q get-canvas)) q (139291 . 3)) ((c meth c (c (? . 15) q button-up?)) q (56030 . 3)) ((c meth c (c (? . 1) q scroll-to)) q (152832 . 15)) ((c def c (? . 95)) q (221832 . 2)) ((c meth c (c (? . 29) q warp-pointer)) q (86736 . 4)) ((c meth c (c (? . 10) q after-interactive-move)) q (180237 . 3)) ((c meth c (c (? . 45) q stretchable-height)) q (562 . 4)) ((c meth c (c (? . 5) q position-line)) q (208304 . 5)) ((c meth c (c (? . 1) q get-active-canvas)) q (139125 . 3)) ((c meth c (c (? . 3) q merge-with)) q (115544 . 3)) ((c constructor c (? . 64)) q (61947 . 14)) ((c meth c (c (? . 15) q get-mod4-down)) q (56859 . 2)) ((c constructor c (? . 85)) q (35740 . 32)) ((c meth c (c (? . 11) q get-caps-down)) q (39357 . 2)) ((c meth c (c (? . 89) q get-column)) q (22061 . 3)) ((c meth c (c (? . 5) q get-region-data)) q (200513 . 5)) ((c meth c (c (? . 42) q refresh-now)) q (10352 . 6)) ((c meth c (c (? . 1) q on-local-char)) q (146494 . 3)) ((c def c (c (? . 0) q add-text-keymap-functions)) q (215839 . 3)) ((c meth c (c (? . 80) q read)) q (123383 . 4)) ((c meth c (c (? . 4) q get-smoothing-on)) q (128442 . 3)) ((c meth c (c (? . 42) q get-scroll-range)) q (8710 . 3)) ((c meth c (c (? . 25) q get-style)) q (124491 . 2)) ((c def c (? . 17)) q (26736 . 4)) ((c meth c (c (? . 1) q load-file)) q (144320 . 8)) ((c def c (c (? . 0) q write-editor-global-footer)) q (219699 . 3)) ((c def c (? . 96)) q (174688 . 3)) ((c def c (c (? . 0) q textual-read-eval-print-loop)) q (103100 . 2)) ((c meth c (c (? . 1) q on-new-box)) q (146685 . 3)) ((c meth c (c (? . 20) q get-label-font)) q (46281 . 2)) ((c meth c (c (? . 12) q set-line-count)) q (164076 . 3)) ((c def c (c (? . 0) q sleep/yield)) q (98593 . 3)) ((c meth c (c (? . 36) q spacing)) q (3197 . 4)) ((c meth c (c (? . 23) q on-char)) q (6091 . 3)) ((c meth c (c (? . 25) q set-delta)) q (125353 . 3)) ((c meth c (c (? . 32) q get-value)) q (31784 . 2)) ((c def c (c (? . 0) q get-file-list)) q (87788 . 19)) ((c meth c (c (? . 23) q min-client-height)) q (5801 . 4)) ((c def c (? . 48)) q (24100 . 4)) ((c meth c (c (? . 97) q read-special)) q (110003 . 9)) ((c meth c (c (? . 28) q get-string)) q (48527 . 4)) ((c meth c (c (? . 5) q remove-clickback)) q (210495 . 4)) ((c def c (? . 98)) q (15694 . 4)) ((c meth c (c (? . 29) q is-shown?)) q (84980 . 2)) ((c meth c (c (? . 14) q get-position)) q (68576 . 2)) ((c meth c (c (? . 10) q can-reorder?)) q (182430 . 7)) ((c meth c (c (? . 3) q get-snipclass)) q (114708 . 2)) ((c meth c (c (? . 6) q get-clipboard-string)) q (18407 . 3)) ((c meth c (c (? . 16) q needs-update)) q (119174 . 11)) ((c meth c (c (? . 5) q get-character)) q (199503 . 3)) ((c meth c (c (? . 1) q clear-undos)) q (137335 . 2)) ((c meth c (c (? . 10) q raise)) q (187762 . 3)) ((c meth c (c (? . 3) q is-owned?)) q (115417 . 2)) ((c meth c (c (? . 1) q set-load-overwrites-styles)) q (154542 . 3)) ((c meth c (c (? . 5) q get-start-position)) q (201327 . 2)) ((c meth c (c (? . 1) q get-max-height)) q (140407 . 3)) ((c meth c (c (? . 50) q read-bytes)) q (174198 . 4)) ((c meth c (c (? . 54) q get-unterminated-bytes)) q (173300 . 4)) ((c meth c (c (? . 38) q map-function)) q (178524 . 4)) ((c meth c (c (? . 4) q copy)) q (127175 . 3)) ((c meth c (c (? . 37) q get-b)) q (105794 . 2)) ((c def c (c (? . 99) q gui-dynamic-require)) q (226862 . 3)) ((c meth c (c (? . 62) q is-enabled?)) q (65794 . 4)) ((c meth c (c (? . 1) q editor-location-to-dc-location)) q (138486 . 5)) ((c meth c (c (? . 16) q get-dc)) q (118373 . 2)) ((c meth c (c (? . 32) q set-value)) q (31936 . 3)) ((c def c (c (? . 100) q make-gui-namespace)) q (103722 . 2)) ((c meth c (c (? . 26) q read)) q (121791 . 3)) ((c meth c (c (? . 66) q get-editor)) q (76765 . 2)) ((c meth c (c (? . 10) q find-next-selected-snip)) q (183771 . 4)) ((c meth c (c (? . 1) q in-edit-sequence?)) q (142018 . 2)) ((c meth c (c (? . 67) q auto-resize)) q (53964 . 4)) ((c meth c (c (? . 3) q set-flags)) q (117625 . 3)) ((c meth c (c (? . 60) q restore)) q (50564 . 2)) ((c meth c (c (? . 12) q allow-tab-exit)) q (161776 . 4)) ((c meth c (c (? . 5) q get-top-line-base)) q (202152 . 3)) ((c meth c (c (? . 54) q get)) q (172635 . 5)) ((c meth c (c (? . 81) q set-time-stamp)) q (26651 . 3)) ((c def c (? . 101)) q (221202 . 2)) ((c meth c (c (? . 1) q refresh)) q (150413 . 15)) ((c def c (c (? . 0) q get-ps-setup-from-user)) q (96489 . 10)) ((c meth c (c (? . 15) q set-mod3-down)) q (58049 . 3)) ((c meth c (c (? . 13) q convert)) q (133505 . 3)) ((c meth c (c (? . 83) q read-special)) q (225349 . 9)) ((c meth c (c (? . 20) q get-data)) q (46111 . 3)) ((c meth c (c (? . 37) q get-g)) q (105860 . 2)) ((c meth c (c (? . 4) q get-smoothing-off)) q (128322 . 3)) ((c constructor c (? . 102)) q (58722 . 26)) ((c def c (? . 61)) q (122385 . 2)) ((c meth c (c (? . 3) q set-count)) q (117544 . 3)) ((c meth c (c (? . 11) q set-alt-down)) q (40480 . 3)) ((c def c (? . 103)) q (222933 . 3)) ((c meth c (c (? . 12) q vertical-inset)) q (164190 . 4)) ((c meth c (c (? . 15) q entering?)) q (56210 . 2)) ((c meth c (c (? . 5) q can-change-style?)) q (190185 . 4)) ((c meth c (c (? . 50) q bad?)) q (174004 . 2)) ((c meth c (c (? . 36) q place-children)) q (2252 . 14)) ((c meth c (c (? . 1) q save-file)) q (151457 . 8)) ((c meth c (c (? . 4) q get-background-add)) q (127545 . 3)) ((c meth c (c (? . 36) q delete-child)) q (1870 . 3)) ((c meth c (c (? . 71) q add-type)) q (17739 . 3)) ((c def c (c (? . 0) q application-preferences-handler)) q (99263 . 4)) ((c meth c (c (? . 29) q popup-menu)) q (86154 . 5)) ((c meth c (c (? . 5) q paragraph-end-position)) q (207121 . 6)) ((c def c (c (? . 0) q area-container-window<%>)) q (3349 . 4)) ((c meth c (c (? . 42) q get-view-start)) q (8828 . 3)) ((c meth c (c (? . 7) q border-visible?)) q (168597 . 2)) ((c meth c (c (? . 25) q get-text-width)) q (124902 . 4)) ((c meth c (c (? . 101) q read-header)) q (221242 . 5)) ((c def c (? . 86)) q (3459 . 4)) ((c meth c (c (? . 25) q get-smoothing)) q (124388 . 3)) ((c meth c (c (? . 48) q show-without-yield)) q (26370 . 2)) ((c meth c (c (? . 7) q get-extent)) q (168831 . 22)) ((c meth c (c (? . 36) q set-alignment)) q (2958 . 5)) ((c meth c (c (? . 45) q min-height)) q (432 . 4)) ((c meth c (c (? . 11) q get-control-down)) q (39413 . 2)) ((c meth c (c (? . 4) q set-transparent-text-backing-on)) q (132864 . 3)) ((c meth c (c (? . 24) q get-view)) q (157317 . 7)) ((c constructor c (? . 70)) q (13813 . 28)) ((c meth c (c (? . 5) q insert)) q (203056 . 39)) ((c meth c (c (? . 20) q select)) q (46605 . 4)) ((c def c (? . 29)) q (83449 . 3)) ((c constructor c (? . 104)) q (34057 . 3)) ((c meth c (c (? . 29) q get-client-handle)) q (83917 . 2)) ((c meth c (c (? . 79) q set-value)) q (71227 . 3)) ((c meth c (c (? . 29) q get-height)) q (84184 . 2)) ((c meth c (c (? . 11) q get-alt-down)) q (39302 . 2)) ((c meth c (c (? . 20) q set-column-label)) q (46877 . 5)) ((c meth c (c (? . 3) q copy)) q (111434 . 2)) ((c def c (c (? . 9) q unknown-extensions-skip-enabled)) q (220777 . 4)) ((c meth c (c (? . 13) q find-or-create-style)) q (133956 . 6)) ((c constructor c (? . 81)) q (26474 . 3))))
interface
area<%> : interface?
method
(send an-area get-graphical-min-size)
 -> dimension-integer? dimension-integer?
method
(send an-area get-parent)
 -> (or/c (is-a?/c area-container<%>) #f)
method
(send an-area get-top-level-window)
 -> (or/c (is-a?/c frame%) (is-a?/c dialog%))
method
(send an-area min-width) -> dimension-integer?
(send an-area min-width w) -> void?
  w : dimension-integer?
method
(send an-area min-height) -> dimension-integer?
(send an-area min-height h) -> void?
  h : dimension-integer?
method
(send an-area stretchable-height) -> boolean?
(send an-area stretchable-height stretch?) -> void?
  stretch? : any/c
method
(send an-area stretchable-width) -> boolean?
(send an-area stretchable-width stretch?) -> void?
  stretch? : any/c
interface
area-container<%> : interface?
  implements: area<%>
method
(send an-area-container add-child child) -> void?
  child : (is-a?/c subwindow<%>)
method
(send an-area-container after-new-child child) -> void?
  child : (is-a?/c subarea<%>)
method
(send an-area-container begin-container-sequence) -> void?
method
(send an-area-container border) -> spacing-integer?
(send an-area-container border margin) -> void?
  margin : spacing-integer?
method
(send an-area-container change-children filter) -> void?
  filter : ((listof (is-a?/c subarea<%>))
            . -> . (listof (is-a?/c subarea<%>)))
method
(send an-area-container container-flow-modified) -> void?
method
(send an-area-container container-size info)
 -> dimension-integer? dimension-integer?
  info : (listof (list/c dimension-integer?
                         dimension-integer?
                         any/c
                         any/c))
method
(send an-area-container delete-child child) -> void?
  child : (is-a?/c subwindow<%>)
method
(send an-area-container end-container-sequence) -> void?
method
(send an-area-container get-alignment)
 -> (symbols 'right 'center 'left)
    (symbols 'bottom 'center 'top)
method
(send an-area-container get-children)
 -> (listof (is-a?/c subarea<%>))
method
(send an-area-container place-children info    
                                       width   
                                       height) 
 -> (listof (list/c dimension-integer?
                    dimension-integer?
                    dimension-integer?
                    dimension-integer?))
  info : (listof (list/c dimension-integer?
                         dimension-integer?
                         any/c
                         any/c))
  width : dimension-integer?
  height : dimension-integer?
method
(send an-area-container reflow-container) -> void?
method
(send an-area-container set-alignment horiz-align     
                                      vert-align) -> void?
  horiz-align : (symbols 'right 'center 'left)
  vert-align : (symbols 'bottom 'center 'top)
method
(send an-area-container spacing) -> spacing-integer?
(send an-area-container spacing spacing) -> void?
  spacing : spacing-integer?
interface
area-container-window<%> : interface?
  implements: area-container<%>
              window<%>
class
button% : class?
  superclass: object%
  extends: control<%>
constructor
(new button%                                            
              [label label]                             
              [parent parent]                           
             [[callback callback]                       
              [style style]                             
              [font font]                               
              [enabled enabled]                         
              [vert-margin vert-margin]                 
              [horiz-margin horiz-margin]               
              [min-width min-width]                     
              [min-height min-height]                   
              [stretchable-width stretchable-width]     
              [stretchable-height stretchable-height]]) 
 -> (is-a?/c button%)
  label : (or/c label-string?
                (is-a?/c bitmap%)
                (list/c (is-a?/c bitmap%)
                        label-string?
                        (or/c 'left 'top 'right 'bottom)))
  parent : (or/c (is-a?/c frame%) (is-a?/c dialog%)
                 (is-a?/c panel%) (is-a?/c pane%))
  callback : ((is-a?/c button%) (is-a?/c control-event%) . -> . any)
           = (lambda (b e) (void))
  style : (listof (or/c 'border 'deleted)) = null
  font : (is-a?/c font%) = normal-control-font
  enabled : any/c = #t
  vert-margin : spacing-integer? = 2
  horiz-margin : spacing-integer? = 2
  min-width : (or/c dimension-integer? #f) = #f
  min-height : (or/c dimension-integer? #f) = #f
  stretchable-width : any/c = #f
  stretchable-height : any/c = #f
method
(send a-button set-label label) -> void?
  label : (or/c label-string?
                (is-a?/c bitmap%))
interface
canvas<%> : interface?
  implements: subwindow<%>
method
(send a-canvas accept-tab-focus) -> boolean?
(send a-canvas accept-tab-focus on?) -> void?
  on? : any/c
method
(send a-canvas flush) -> void?
method
(send a-canvas get-canvas-background)
 -> (or/c (is-a?/c color%) #f)
method
(send a-canvas get-dc) -> (is-a?/c dc<%>)
method
(send a-canvas min-client-height) -> dimension-integer?
(send a-canvas min-client-height h) -> void?
  h : dimension-integer?
method
(send a-canvas min-client-width) -> dimension-integer?
(send a-canvas min-client-width w) -> void?
  w : dimension-integer?
method
(send a-canvas on-char ch) -> void?
  ch : (is-a?/c key-event%)
method
(send a-canvas on-event event) -> void?
  event : (is-a?/c mouse-event%)
method
(send a-canvas on-paint) -> void?
method
(send a-canvas on-tab-in) -> void?
method
(send a-canvas resume-flush) -> void?
method
(send a-canvas set-canvas-background color) -> void?
  color : (is-a?/c color%)
method
(send a-canvas set-resize-corner on?) -> void?
  on? : any/c
method
(send a-canvas suspend-flush) -> void?
class
canvas% : class?
  superclass: object%
  extends: canvas<%>
constructor
(new canvas%                                            
              [parent parent]                           
             [[style style]                             
              [paint-callback paint-callback]           
              [label label]                             
              [gl-config gl-config]                     
              [enabled enabled]                         
              [vert-margin vert-margin]                 
              [horiz-margin horiz-margin]               
              [min-width min-width]                     
              [min-height min-height]                   
              [stretchable-width stretchable-width]     
              [stretchable-height stretchable-height]]) 
 -> (is-a?/c canvas%)
  parent : (or/c (is-a?/c frame%) (is-a?/c dialog%)
                 (is-a?/c panel%) (is-a?/c pane%))
  style : (listof (or/c 'border 'control-border 'combo   = null
                        'vscroll 'hscroll 'resize-corner
                        'gl 'no-autoclear 'transparent
                        'no-focus 'deleted))
  paint-callback : ((is-a?/c canvas%) (is-a?/c dc<%>) . -> . any)
                 = void
  label : (or/c label-string? #f) = #f
  gl-config : (or/c (is-a?/c gl-config%) #f) = #f
  enabled : any/c = #t
  vert-margin : spacing-integer? = 0
  horiz-margin : spacing-integer? = 0
  min-width : (or/c dimension-integer? #f) = #f
  min-height : (or/c dimension-integer? #f) = #f
  stretchable-width : any/c = #t
  stretchable-height : any/c = #t
method
(send a-canvas get-scroll-page which)
 -> positive-dimension-integer?
  which : (or/c 'horizontal 'vertical)
method
(send a-canvas get-scroll-pos which) -> dimension-integer?
  which : (or/c 'horizontal 'vertical)
method
(send a-canvas get-scroll-range which) -> dimension-integer?
  which : (or/c 'horizontal 'vertical)
method
(send a-canvas get-view-start)
 -> dimension-integer? dimension-integer?
method
(send a-canvas get-virtual-size)
 -> (value dimension-integer? dimension-integer?)
method
(send a-canvas init-auto-scrollbars horiz-pixels     
                                    vert-pixels      
                                    h-value          
                                    v-value)     -> void?
  horiz-pixels : (or/c positive-dimension-integer? #f)
  vert-pixels : (or/c positive-dimension-integer? #f)
  h-value : (real-in 0.0 1.0)
  v-value : (real-in 0.0 1.0)
method
(send a-canvas init-manual-scrollbars h-length     
                                      v-length     
                                      h-page       
                                      v-page       
                                      h-value      
                                      v-value) -> void?
  h-length : (or/c dimension-integer? #f)
  v-length : (or/c dimension-integer? #f)
  h-page : positive-dimension-integer?
  v-page : positive-dimension-integer?
  h-value : dimension-integer?
  v-value : dimension-integer?
method
(send a-canvas make-bitmap width height) -> (is-a/c? bitmap%)
  width : exact-positive-integer?
  height : exact-positive-integer?
method
(send a-canvas on-paint) -> void?
method
(send a-canvas on-scroll event) -> void?
  event : (is-a?/c scroll-event%)
method
(send a-canvas refresh-now [paint-proc            
                            #:flush? flush?]) -> void?
  paint-proc : ((is-a?/c dc<%>) . -> . any)
             = (lambda (dc) (send a-canvas on-paint))
  flush? : any/c = #t
method
(send a-canvas scroll h-value v-value) -> void?
  h-value : (or/c (real-in 0.0 1.0) #f)
  v-value : (or/c (real-in 0.0 1.0) #f)
method
(send a-canvas set-scroll-page which value) -> void?
  which : (or/c 'horizontal 'vertical)
  value : positive-dimension-integer?
method
(send a-canvas set-scroll-pos which value) -> void?
  which : (or/c 'horizontal 'vertical)
  value : dimension-integer?
method
(send a-canvas set-scroll-range which      
                                value) -> void?
  which : (or/c 'horizontal 'vertical)
  value : dimension-integer?
method
(send a-canvas show-scrollbars show-horiz?     
                               show-vert?) -> void?
  show-horiz? : any/c
  show-vert? : any/c
method
(send a-canvas swap-gl-buffers) -> void?
method
(send a-canvas with-gl-context  thunk             
                               [#:fail fail]) -> any
  thunk : (-> any)
  fail : (-> any) = (lambda () (error ....))
class
check-box% : class?
  superclass: object%
  extends: control<%>
constructor
(new check-box%                                            
                 [label label]                             
                 [parent parent]                           
                [[callback callback]                       
                 [style style]                             
                 [value value]                             
                 [font font]                               
                 [enabled enabled]                         
                 [vert-margin vert-margin]                 
                 [horiz-margin horiz-margin]               
                 [min-width min-width]                     
                 [min-height min-height]                   
                 [stretchable-width stretchable-width]     
                 [stretchable-height stretchable-height]]) 
 -> (is-a?/c check-box%)
  label : (or/c label-string? (is-a?/c bitmap%))
  parent : (or/c (is-a?/c frame%) (is-a?/c dialog%)
                 (is-a?/c panel%) (is-a?/c pane%))
  callback : ((is-a?/c check-box%) (is-a?/c control-event%)
              . -> . any)
           = (lambda (c e) (void))
  style : (listof (or/c 'deleted)) = null
  value : any/c = #f
  font : (is-a?/c font%) = normal-control-font
  enabled : any/c = #t
  vert-margin : spacing-integer? = 2
  horiz-margin : spacing-integer? = 2
  min-width : (or/c dimension-integer? #f) = #f
  min-height : (or/c dimension-integer? #f) = #f
  stretchable-width : any/c = #f
  stretchable-height : any/c = #f
method
(send a-check-box get-value) -> boolean?
method
(send a-check-box set-label label) -> void?
  label : (or/c label-string? (is-a?/c bitmap%))
method
(send a-check-box set-value state) -> void?
  state : any/c
class
checkable-menu-item% : class?
  superclass: object%
  extends: selectable-menu-item<%>
constructor
(new checkable-menu-item%                                      
                           [label label]                       
                           [parent parent]                     
                          [[callback callback]                 
                           [shortcut shortcut]                 
                           [help-string help-string]           
                           [demand-callback demand-callback]   
                           [checked checked]                   
                           [shortcut-prefix shortcut-prefix]]) 
 -> (is-a?/c checkable-menu-item%)
  label : label-string?
  parent : (or/c (is-a?/c menu%) (is-a?/c popup-menu%))
  callback : ((is-a?/c checkable-menu-item%) (is-a?/c control-event%)
              . -> . any)
           = (lambda (i e) (void))
  shortcut : (or/c char? symbol? #f) = #f
  help-string : (or/c label-string? #f) = #f
  demand-callback : ((is-a?/c menu-item%) . -> . any)
                  = (lambda (i) (void))
  checked : any/c = #f
  shortcut-prefix : (and/c (listof (or/c 'alt 'cmd 'meta 'ctl
                                         'shift 'option))
                           (λ (x) (implies (equal? 'unix (system-type))
                                           (not (and (member 'alt x)
                                                     (member 'meta x)))))
                           (λ (x) (equal? x (remove-duplicates x))))
                  = (get-default-shortcut-prefix)
method
(send a-checkable-menu-item check check?) -> void?
  check? : any/c
method
(send a-checkable-menu-item is-checked?) -> boolean?
class
choice% : class?
  superclass: object%
  extends: list-control<%>
constructor
(new choice%                                            
              [label label]                             
              [choices choices]                         
              [parent parent]                           
             [[callback callback]                       
              [style style]                             
              [selection selection]                     
              [font font]                               
              [enabled enabled]                         
              [vert-margin vert-margin]                 
              [horiz-margin horiz-margin]               
              [min-width min-width]                     
              [min-height min-height]                   
              [stretchable-width stretchable-width]     
              [stretchable-height stretchable-height]]) 
 -> (is-a?/c choice%)
  label : (or/c label-string? #f)
  choices : (listof label-string?)
  parent : (or/c (is-a?/c frame%) (is-a?/c dialog%)
                 (is-a?/c panel%) (is-a?/c pane%))
  callback : ((is-a?/c choice%) (is-a?/c control-event%) . -> . any)
           = (lambda (c e) (void))
  style : (listof (or/c 'horizontal-label 'vertical-label = null
                        'deleted))
  selection : exact-nonnegative-integer? = 0
  font : (is-a?/c font%) = normal-control-font
  enabled : any/c = #t
  vert-margin : spacing-integer? = 2
  horiz-margin : spacing-integer? = 2
  min-width : (or/c dimension-integer? #f) = #f
  min-height : (or/c dimension-integer? #f) = #f
  stretchable-width : any/c = #f
  stretchable-height : any/c = #f
class
clipboard-client% : class?
  superclass: object%
constructor
(new clipboard-client%) -> (is-a?/c clipboard-client%)
method
(send a-clipboard-client add-type format) -> void?
  format : string?
method
(send a-clipboard-client get-data format)
 -> (or/c bytes? string? #f)
  format : string?
method
(send a-clipboard-client get-types) -> (listof string?)
method
(send a-clipboard-client on-replaced) -> void?
interface
clipboard<%> : interface?
method
(send a-clipboard get-clipboard-bitmap time)
 -> (or/c (is-a?/c bitmap%) #f)
  time : exact-integer?
method
(send a-clipboard get-clipboard-data format 
                                     time)  
 -> (or/c bytes? string? #f)
  format : string?
  time : exact-integer?
method
(send a-clipboard get-clipboard-string time) -> string?
  time : exact-integer?
method
(send a-clipboard same-clipboard-client? owner) -> boolean?
  owner : (is-a?/c clipboard-client%)
method
(send a-clipboard set-clipboard-bitmap new-bitmap     
                                       time)      -> void?
  new-bitmap : (is-a?/c bitmap%)
  time : exact-integer?
method
(send a-clipboard set-clipboard-client new-owner     
                                       time)     -> void?
  new-owner : (is-a?/c clipboard-client%)
  time : exact-integer?
method
(send a-clipboard set-clipboard-string new-text     
                                       time)    -> void?
  new-text : string?
  time : exact-integer?
class
combo-field% : class?
  superclass: text-field%
constructor
(new combo-field%                                            
                   [label label]                             
                   [choices choices]                         
                   [parent parent]                           
                  [[callback callback]                       
                   [init-value init-value]                   
                   [style style]                             
                   [font font]                               
                   [enabled enabled]                         
                   [vert-margin vert-margin]                 
                   [horiz-margin horiz-margin]               
                   [min-width min-width]                     
                   [min-height min-height]                   
                   [stretchable-width stretchable-width]     
                   [stretchable-height stretchable-height]]) 
 -> (is-a?/c combo-field%)
  label : (or/c label-string? #f)
  choices : (listof label-string?)
  parent : (or/c (is-a?/c frame%) (is-a?/c dialog%)
                 (is-a?/c panel%) (is-a?/c pane%))
  callback : ((is-a?/c combo-field%) (is-a?/c control-event%)
              . -> . any)
           = (lambda (c e) (void))
  init-value : string = ""
  style : (listof (or/c 'horizontal-label 'vertical-label = null
                        'deleted))
  font : (is-a?/c font%) = normal-control-font
  enabled : any/c = #t
  vert-margin : spacing-integer? = 2
  horiz-margin : spacing-integer? = 2
  min-width : (or/c dimension-integer? #f) = #f
  min-height : (or/c dimension-integer? #f) = #f
  stretchable-width : any/c = #t
  stretchable-height : any/c = #f
method
(send a-combo-field append l) -> void?
  l : label-string?
method
(send a-combo-field get-menu) -> (is-a?/c popup-menu%)
method
(send a-combo-field on-popup event) -> void?
  event : (is-a?/c control-event%)
interface
control<%> : interface?
  implements: subwindow<%>
method
(send a-control command event) -> void?
  event : (is-a?/c control-event%)
class
column-control-event% : class?
  superclass: control-event%
constructor
(new column-control-event%                            
                            [column column]           
                            [event-type event-type]   
                           [[time-stamp time-stamp]]) 
 -> (is-a?/c column-control-event%)
  column : exact-nonnegative-integer?
  event-type : (or/c 'list-box-column)
  time-stamp : exact-integer? = 0
method
(send a-column-control-event get-column)
 -> exact-nonnegative-integer?
method
(send a-column-control-event set-column column) -> void?
  column : exact-nonnegative-integer?
class
control-event% : class?
  superclass: event%
constructor
(new control-event%                            
                     [event-type event-type]   
                    [[time-stamp time-stamp]]) 
 -> (is-a?/c control-event%)
  event-type : (or/c 'button 'check-box 'choice
                     'list-box 'list-box-dclick 'list-box-column
                     'text-field 'text-field-enter
                     'menu 'slider 'radio-box 'tab-panel
                     'menu-popdown 'menu-popdown-none)
  time-stamp : exact-integer? = 0
method
(send a-control-event get-event-type)
 -> (or/c 'button 'check-box 'choice
          'list-box 'list-box-dclick 'text-field
          'text-field-enter 'menu 'slider 'radio-box
          'menu-popdown 'menu-popdown-none 'tab-panel)
method
(send a-control-event set-event-type type) -> void?
  type : (or/c 'button 'check-box 'choice
               'list-box 'list-box-dclick 'text-field
               'text-field-enter 'menu 'slider 'radio-box
               'menu-popdown 'menu-popdown-none 'tab-panel)
class
cursor% : class?
  superclass: object%
constructor
(make-object cursor%  image            
                      mask             
                     [hot-spot-x       
                      hot-spot-y]) -> (is-a?/c cursor%)
  image : (is-a?/c bitmap%)
  mask : (is-a?/c bitmap%)
  hot-spot-x : (integer-in 0 15) = 0
  hot-spot-y : (integer-in 0 15) = 0
(make-object cursor% id) -> (is-a?/c cursor%)
  id : (or/c 'arrow 'bullseye 'cross 'hand 'ibeam 'watch 'blank
             'size-n/s 'size-e/w 'size-ne/sw 'size-nw/se)
method
(send a-cursor ok?) -> boolean?
class
dialog% : class?
  superclass: object%
  extends: top-level-window<%>
constructor
(new dialog%                                            
              [label label]                             
             [[parent parent]                           
              [width width]                             
              [height height]                           
              [x x]                                     
              [y y]                                     
              [style style]                             
              [enabled enabled]                         
              [border border]                           
              [spacing spacing]                         
              [alignment alignment]                     
              [min-width min-width]                     
              [min-height min-height]                   
              [stretchable-width stretchable-width]     
              [stretchable-height stretchable-height]]) 
 -> (is-a?/c dialog%)
  label : label-string?
  parent : (or/c (is-a?/c frame%) (is-a?/c dialog%) #f) = #f
  width : (or/c dimension-integer? #f) = #f
  height : (or/c dimension-integer? #f) = #f
  x : (or/c dimension-integer? #f) = #f
  y : (or/c dimension-integer? #f) = #f
  style : (listof (or/c 'no-caption 'resize-border = null
                        'no-sheet 'close-button))
  enabled : any/c = #t
  border : spacing-integer? = 0
  spacing : spacing-integer? = 0
  alignment : (list/c (or/c 'left 'center 'right)
                      (or/c 'top 'center 'bottom))
            = '(center top)
  min-width : (or/c dimension-integer? #f) = #f
  min-height : (or/c dimension-integer? #f) = #f
  stretchable-width : any/c = #t
  stretchable-height : any/c = #t
method
(send a-dialog on-subwindow-char receiver     
                                 event)   -> boolean?
  receiver : (is-a?/c window<%>)
  event : (is-a?/c key-event%)
method
(send a-dialog show show?) -> void?
  show? : any/c
method
(send a-dialog show-without-yield) -> void?
class
event% : class?
  superclass: object%
constructor
(new event% [[time-stamp time-stamp]]) -> (is-a?/c event%)
  time-stamp : exact-integer? = 0
method
(send an-event get-time-stamp) -> exact-integer?
method
(send an-event set-time-stamp time) -> void?
  time : exact-integer?
class
frame% : class?
  superclass: object%
  extends: top-level-window<%>
constructor
(new frame%                                            
             [label label]                             
            [[parent parent]                           
             [width width]                             
             [height height]                           
             [x x]                                     
             [y y]                                     
             [style style]                             
             [enabled enabled]                         
             [border border]                           
             [spacing spacing]                         
             [alignment alignment]                     
             [min-width min-width]                     
             [min-height min-height]                   
             [stretchable-width stretchable-width]     
             [stretchable-height stretchable-height]]) 
 -> (is-a?/c frame%)
  label : label-string?
  parent : (or/c (is-a?/c frame%) #f) = #f
  width : (or/c dimension-integer? #f) = #f
  height : (or/c dimension-integer? #f) = #f
  x : (or/c position-integer? #f) = #f
  y : (or/c position-integer? #f) = #f
  style : (listof (or/c 'no-resize-border 'no-caption
                        'no-system-menu 'hide-menu-bar
                        'toolbar-button 'float 'metal
                        'fullscreen-button 'fullscreen-aux))
        = null
  enabled : any/c = #t
  border : spacing-integer? = 0
  spacing : spacing-integer? = 0
  alignment : (list/c (or/c 'left 'center 'right)
                      (or/c 'top 'center 'bottom))
            = '(center top)
  min-width : (or/c dimension-integer? #f) = #f
  min-height : (or/c dimension-integer? #f) = #f
  stretchable-width : any/c = #t
  stretchable-height : any/c = #t
method
(send a-frame create-status-line) -> void?
method
(send a-frame fullscreen fullscreen?) -> void?
  fullscreen? : any/c
method
(send a-frame get-menu-bar) -> (or/c (is-a?/c menu-bar%) #f)
method
(send a-frame has-status-line?) -> boolean?
method
(send a-frame iconize iconize?) -> void?
  iconize? : any/c
method
(send a-frame is-fullscreened?) -> boolean?
method
(send a-frame is-iconized?) -> boolean?
method
(send a-frame is-maximized?) -> boolean?
method
(send a-frame maximize maximize?) -> void?
  maximize? : any/c
method
(send a-frame modified) -> boolean?
(send a-frame modified modified?) -> void?
  modified? : any/c
method
(send a-frame on-menu-char event) -> boolean?
  event : (is-a?/c key-event%)
method
(send a-frame on-subwindow-char receiver     
                                event)   -> boolean?
  receiver : (is-a?/c window<%>)
  event : (is-a?/c key-event%)
method
(send a-frame on-toolbar-button-click) -> void?
method
(send a-frame set-status-text text) -> void?
  text : string?
class
gauge% : class?
  superclass: object%
  extends: control<%>
constructor
(new gauge%                                            
             [label label]                             
             [range range]                             
             [parent parent]                           
            [[style style]                             
             [font font]                               
             [enabled enabled]                         
             [vert-margin vert-margin]                 
             [horiz-margin horiz-margin]               
             [min-width min-width]                     
             [min-height min-height]                   
             [stretchable-width stretchable-width]     
             [stretchable-height stretchable-height]]) 
 -> (is-a?/c gauge%)
  label : (or/c label-string? #f)
  range : positive-dimension-integer?
  parent : (or/c (is-a?/c frame%) (is-a?/c dialog%)
                 (is-a?/c panel%) (is-a?/c pane%))
  style : (listof (or/c 'horizontal 'vertical
                        'vertical-label 'horizontal-label
                        'deleted))
        = '(horizontal)
  font : (is-a?/c font%) = normal-control-font
  enabled : any/c = #t
  vert-margin : spacing-integer? = 2
  horiz-margin : spacing-integer? = 2
  min-width : (or/c dimension-integer? #f) = #f
  min-height : (or/c dimension-integer? #f) = #f
  stretchable-width : any/c = (memq 'horizontal style)
  stretchable-height : any/c = (memq 'vertical style)
method
(send a-gauge get-range) -> positive-dimension-integer?
method
(send a-gauge get-value) -> dimension-integer?
method
(send a-gauge set-range range) -> void?
  range : positive-dimension-integer?
method
(send a-gauge set-value pos) -> void?
  pos : dimension-integer?
class
group-box-panel% : class?
  superclass: vertical-panel%
constructor
(new group-box-panel%                                            
                       [label label]                             
                       [parent parent]                           
                      [[style style]                             
                       [font font]                               
                       [enabled enabled]                         
                       [vert-margin vert-margin]                 
                       [horiz-margin horiz-margin]               
                       [border border]                           
                       [spacing spacing]                         
                       [alignment alignment]                     
                       [min-width min-width]                     
                       [min-height min-height]                   
                       [stretchable-width stretchable-width]     
                       [stretchable-height stretchable-height]]) 
 -> (is-a?/c group-box-panel%)
  label : label-string?
  parent : (or/c (is-a?/c frame%) (is-a?/c dialog%)
                 (is-a?/c panel%) (is-a?/c pane%))
  style : (listof (or/c 'deleted)) = null
  font : (is-a?/c font%) = small-control-font
  enabled : any/c = #t
  vert-margin : spacing-integer? = 2
  horiz-margin : spacing-integer? = 2
  border : spacing-integer? = 0
  spacing : spacing-integer? = 0
  alignment : (list/c (or/c 'left 'center 'right)
                      (or/c 'top 'center 'bottom))
            = '(center top)
  min-width : (or/c dimension-integer? #f) = #f
  min-height : (or/c dimension-integer? #f) = #f
  stretchable-width : any/c = #t
  stretchable-height : any/c = #t
class
grow-box-spacer-pane% : class?
  superclass: pane%
constructor
(new grow-box-spacer-pane% ...superclass-args...)
 -> (is-a?/c grow-box-spacer-pane%)
class
horizontal-pane% : class?
  superclass: pane%
constructor
(new horizontal-pane%                                            
                       [parent parent]                           
                      [[vert-margin vert-margin]                 
                       [horiz-margin horiz-margin]               
                       [border border]                           
                       [spacing spacing]                         
                       [alignment alignment]                     
                       [min-width min-width]                     
                       [min-height min-height]                   
                       [stretchable-width stretchable-width]     
                       [stretchable-height stretchable-height]]) 
 -> (is-a?/c horizontal-pane%)
  parent : (or/c (is-a?/c frame%) (is-a?/c dialog%)
                 (is-a?/c panel%) (is-a?/c pane%))
  vert-margin : spacing-integer? = 0
  horiz-margin : spacing-integer? = 0
  border : spacing-integer? = 0
  spacing : spacing-integer? = 0
  alignment : (list/c (or/c 'left 'center 'right)
                      (or/c 'top 'center 'bottom))
            = '(left center)
  min-width : (or/c dimension-integer? #f) = #f
  min-height : (or/c dimension-integer? #f) = #f
  stretchable-width : any/c = #t
  stretchable-height : any/c = #t
class
horizontal-panel% : class?
  superclass: panel%
constructor
(new horizontal-panel%                                            
                        [parent parent]                           
                       [[style style]                             
                        [enabled enabled]                         
                        [vert-margin vert-margin]                 
                        [horiz-margin horiz-margin]               
                        [border border]                           
                        [spacing spacing]                         
                        [alignment alignment]                     
                        [min-width min-width]                     
                        [min-height min-height]                   
                        [stretchable-width stretchable-width]     
                        [stretchable-height stretchable-height]]) 
 -> (is-a?/c horizontal-panel%)
  parent : (or/c (is-a?/c frame%) (is-a?/c dialog%)
                 (is-a?/c panel%) (is-a?/c pane%))
  style : (listof (or/c 'border 'deleted         = null
                        'hscroll 'auto-hscroll
                        'vscroll 'auto-vscroll))
  enabled : any/c = #t
  vert-margin : spacing-integer? = 0
  horiz-margin : spacing-integer? = 0
  border : spacing-integer? = 0
  spacing : spacing-integer? = 0
  alignment : (list/c (or/c 'left 'center 'right)
                      (or/c 'top 'center 'bottom))
            = '(left center)
  min-width : (or/c dimension-integer? #f) = #f
  min-height : (or/c dimension-integer? #f) = #f
  stretchable-width : any/c = #t
  stretchable-height : any/c = #t
method
(send a-horizontal-panel set-orientation horizontal?) -> void?
  horizontal? : boolean?
method
(send a-horizontal-panel get-orientation) -> boolean?
class
key-event% : class?
  superclass: event%
constructor
(new key-event%                                                  
                [[key-code key-code]                             
                 [shift-down shift-down]                         
                 [control-down control-down]                     
                 [meta-down meta-down]                           
                 [alt-down alt-down]                             
                 [x x]                                           
                 [y y]                                           
                 [time-stamp time-stamp]                         
                 [caps-down caps-down]                           
                 [mod3-down mod3-down]                           
                 [mod4-down mod4-down]                           
                 [mod5-down mod5-down]                           
                 [control+meta-is-altgr control+meta-is-altgr]]) 
 -> (is-a?/c key-event%)
  key-code : (or/c char? key-code-symbol?) = #\nul
  shift-down : any/c = #f
  control-down : any/c = #f
  meta-down : any/c = #f
  alt-down : any/c = #f
  x : exact-integer? = 0
  y : exact-integer? = 0
  time-stamp : exact-integer? = 0
  caps-down : any/c = #f
  mod3-down : any/c = #f
  mod4-down : any/c = #f
  mod5-down : any/c = #f
  control+meta-is-altgr : any/c = #f
method
(send a-key-event get-alt-down) -> boolean?
method
(send a-key-event get-caps-down) -> boolean?
method
(send a-key-event get-control-down) -> boolean?
method
(send a-key-event get-control+meta-is-altgr) -> boolean?
method
(send a-key-event get-key-code)
 -> (or/c char? key-code-symbol?)
method
(send a-key-event get-key-release-code)
 -> (or/c char? key-code-symbol?)
method
(send a-key-event get-meta-down) -> boolean?
method
(send a-key-event get-mod3-down) -> boolean?
method
(send a-key-event get-mod4-down) -> boolean?
method
(send a-key-event get-mod5-down) -> boolean?
method
(send a-key-event get-other-altgr-key-code)
 -> (or/c char? key-code-symbol? #f)
method
(send a-key-event get-other-caps-key-code)
 -> (or/c char? key-code-symbol? #f)
method
(send a-key-event get-other-shift-altgr-key-code)
 -> (or/c char? key-code-symbol? #f)
method
(send a-key-event get-other-shift-key-code)
 -> (or/c char? key-code-symbol? #f)
method
(send a-key-event get-shift-down) -> boolean?
method
(send a-key-event get-x) -> exact-integer?
method
(send a-key-event get-y) -> exact-integer?
method
(send a-key-event set-alt-down down?) -> void?
  down? : any/c
method
(send a-key-event set-caps-down down?) -> void?
  down? : any/c
method
(send a-key-event set-control-down down?) -> void?
  down? : any/c
method
(send a-key-event control+meta-is-altgr down?) -> void?
  down? : any/c
method
(send a-key-event set-key-code code) -> void?
  code : (or/c char? key-code-symbol?)
method
(send a-key-event set-key-release-code code) -> void?
  code : (or/c char? key-code-symbol?)
method
(send a-key-event set-meta-down down?) -> void?
  down? : any/c
method
(send a-key-event set-mod3-down down?) -> void?
  down? : any/c
method
(send a-key-event set-mod4-down down?) -> void?
  down? : any/c
method
(send a-key-event set-mod5-down down?) -> void?
  down? : any/c
method
(send a-key-event set-other-altgr-key-code code) -> void?
  code : (or/c char? key-code-symbol? #f)
method
(send a-key-event set-other-caps-key-code code) -> void?
  code : (or/c char? key-code-symbol? #f)
method
(send a-key-event set-other-shift-altgr-key-code code) -> void?
  code : (or/c char? key-code-symbol? #f)
method
(send a-key-event set-other-shift-key-code code) -> void?
  code : (or/c char? key-code-symbol? #f)
method
(send a-key-event set-shift-down down?) -> void?
  down? : any/c
method
(send a-key-event set-x pos) -> void?
  pos : exact-integer?
method
(send a-key-event set-y pos) -> void?
  pos : exact-integer?
interface
labelled-menu-item<%> : interface?
  implements: menu-item<%>
method
(send a-labelled-menu-item enable enabled?) -> void?
  enabled? : any/c
method
(send a-labelled-menu-item get-help-string)
 -> (or/c label-string? #f)
method
(send a-labelled-menu-item get-label) -> label-string?
method
(send a-labelled-menu-item get-plain-label) -> label-string?
method
(send a-labelled-menu-item is-enabled?) -> boolean?
method
(send a-labelled-menu-item on-demand) -> void?
method
(send a-labelled-menu-item set-help-string help) -> void?
  help : (or/c label-string? #f)
method
(send a-labelled-menu-item set-label label) -> void?
  label : label-string?
class
list-box% : class?
  superclass: object%
  extends: list-control<%>
constructor
(new list-box%                                          
                [label label]                           
                [choices choices]                       
                [parent parent]                         
               [[callback callback]                     
                [style style]                           
                [selection selection]                   
                [font font]                             
                [label-font label-font]                 
                [enabled enabled]                       
                [vert-margin vert-margin]               
                [horiz-margin horiz-margin]             
                [min-width min-width]                   
                [min-height min-height]                 
                [stretchable-width stretchable-width]   
                [stretchable-height stretchable-height] 
                [columns columns]                       
                [column-order column-order]])           
 -> (is-a?/c list-box%)
  label : (or/c label-string? #f)
  choices : (listof label-string?)
  parent : (or/c (is-a?/c frame%) (is-a?/c dialog%)
                 (is-a?/c panel%) (is-a?/c pane%))
  callback : ((is-a?/c list-box%) (is-a?/c control-event%)
              . -> . any)
           = (lambda (c e) (void))
  style : (listof (or/c 'single 'multiple 'extended
                        'vertical-label 'horizontal-label
                        'variable-columns 'column-headers
                        'clickable-headers 'reorderable-headers
                        'deleted))
        = '(single)
  selection : (or/c exact-nonnegative-integer? #f) = #f
  font : (is-a?/c font%) = view-control-font
  label-font : (is-a?/c font%) = normal-control-font
  enabled : any/c = #t
  vert-margin : spacing-integer? = 2
  horiz-margin : spacing-integer? = 2
  min-width : (or/c dimension-integer? #f) = #f
  min-height : (or/c dimension-integer? #f) = #f
  stretchable-width : any/c = #t
  stretchable-height : any/c = #t
  columns : (cons/c label-string? (listof label-string?))
          = '("Column")
  column-order : (or/c #f (listof exact-nonnegative-integer?))
               = #f
method
(send a-list-box append item [data]) -> void?
  item : label-string?
  data : any/c = #f
method
(send a-list-box append-column label) -> void?
  label : label-string?
method
(send a-list-box delete-column n) -> void?
  n : exact-nonnegative-integer?
method
(send a-list-box get-column-labels)
 -> (cons/c label-string? (listof label-string?))
method
(send a-list-box get-column-order)
 -> (listof exact-nonnegative-integer?)
method
(send a-list-box get-column-width column) -> dimension-integer?
                                             dimension-integer?
                                             dimension-integer?
  column : exact-nonnegative-integer?
method
(send a-list-box get-data n) -> any/c
  n : exact-nonnegative-integer?
method
(send a-list-box get-first-visible-item)
 -> exact-nonnegative-integer?
method
(send a-list-box get-label-font) -> (is-a?/c font%)
method
(send a-list-box get-selections)
 -> (listof exact-nonnegative-integer?)
method
(send a-list-box is-selected? n) -> boolean?
  n : exact-nonnegative-integer?
method
(send a-list-box number-of-visible-items)
 -> exact-positive-integer?
method
(send a-list-box select n [select?]) -> void?
  n : exact-nonnegative-integer?
  select? : any/c = #t
method
(send a-list-box set choices0 choices ...) -> void?
  choices0 : (listof label-string?)
  choices : (listof label-string?)
method
(send a-list-box set-column-label column     
                                  label) -> void?
  column : exact-nonnegative-integer?
  label : label-string?
method
(send a-list-box set-column-order column-order) -> void?
  column-order : (listof exact-nonnegative-integer?)
method
(send a-list-box set-column-width column         
                                  width          
                                  min-width      
                                  max-width) -> void?
  column : exact-nonnegative-integer?
  width : dimension-integer?
  min-width : dimension-integer?
  max-width : dimension-integer?
method
(send a-list-box set-data n data) -> void?
  n : exact-nonnegative-integer?
  data : any/c
method
(send a-list-box set-first-visible-item n) -> void?
  n : exact-nonnegative-integer?
method
(send a-list-box set-string n label [column]) -> void?
  n : exact-nonnegative-integer?
  label : label-string?
  column : exact-nonnegative-integer? = 0
interface
list-control<%> : interface?
  implements: control<%>
method
(send a-list-control append item) -> void?
  item : label-string?
method
(send a-list-control clear) -> void?
method
(send a-list-control delete n) -> void?
  n : exact-nonnegative-integer?
method
(send a-list-control find-string s)
 -> (or/c exact-nonnegative-integer? #f)
  s : string?
method
(send a-list-control get-number) -> exact-nonnegative-integer?
method
(send a-list-control get-selection)
 -> (or/c exact-nonnegative-integer? #f)
method
(send a-list-control get-string n)
 -> (and/c immutable? label-string?)
  n : exact-nonnegative-integer?
method
(send a-list-control get-string-selection)
 -> (or/c (and/c immutable? label-string?) #f)
method
(send a-list-control set-selection n) -> void?
  n : exact-nonnegative-integer?
method
(send a-list-control set-string-selection s) -> void?
  s : string?
class
menu% : class?
  superclass: object%
  extends: menu-item-container<%>
           labelled-menu-item<%>
constructor
(new menu%                                      
            [label label]                       
            [parent parent]                     
           [[help-string help-string]           
            [demand-callback demand-callback]]) 
 -> (is-a?/c menu%)
  label : label-string?
  parent : (or/c (is-a?/c menu%) (is-a?/c popup-menu%)
                 (is-a?/c menu-bar%))
  help-string : (or/c label-string? #f) = #f
  demand-callback : ((is-a?/c menu%) . -> . any)
                  = (lambda (m) (void))
class
menu-bar% : class?
  superclass: object%
  extends: menu-item-container<%>
constructor
(new menu-bar%                                      
                [parent parent]                     
               [[demand-callback demand-callback]]) 
 -> (is-a?/c menu-bar%)
  parent : (or/c (is-a?/c frame%) 'root)
  demand-callback : ((is-a?/c menu-bar%) . -> . any)
                  = (lambda (m) (void))
method
(send a-menu-bar enable enable?) -> void?
  enable? : any/c
method
(send a-menu-bar get-frame) -> (or/c (is-a?/c frame%) 'root)
method
(send a-menu-bar is-enabled?) -> boolean?
interface
menu-item<%> : interface?
method
(send a-menu-item delete) -> void?
method
(send a-menu-item get-parent)
 -> (or/c (is-a?/c menu%) (is-a?/c popup-menu%) (is-a?/c menu-bar%))
method
(send a-menu-item is-deleted?) -> boolean?
method
(send a-menu-item restore) -> void?
class
menu-item% : class?
  superclass: object%
  extends: selectable-menu-item<%>
constructor
(new menu-item%                                      
                 [label label]                       
                 [parent parent]                     
                 [callback callback]                 
                [[shortcut shortcut]                 
                 [help-string help-string]           
                 [demand-callback demand-callback]   
                 [shortcut-prefix shortcut-prefix]]) 
 -> (is-a?/c menu-item%)
  label : label-string?
  parent : (or/c (is-a?/c menu%) (is-a?/c popup-menu%))
  callback : ((is-a?/c menu-item%) (is-a?/c control-event%) . -> . any)
  shortcut : (or/c char? symbol? #f) = #f
  help-string : (or/c label-string? #f) = #f
  demand-callback : ((is-a?/c menu-item%) . -> . any)
                  = (lambda (i) (void))
  shortcut-prefix : (and/c (listof (or/c 'alt 'cmd 'meta 'ctl
                                         'shift 'option))
                           (λ (x) (implies (equal? 'unix (system-type))
                                           (not (and (member 'alt x)
                                                     (member 'meta x)))))
                           (λ (x) (equal? x (remove-duplicates x))))
                  = (get-default-shortcut-prefix)
interface
menu-item-container<%> : interface?
method
(send a-menu-item-container get-items)
 -> (listof (is-a?/c menu-item<%>))
method
(send a-menu-item-container on-demand) -> void?
class
message% : class?
  superclass: object%
  extends: control<%>
constructor
(new message%                                          
               [label label]                           
               [parent parent]                         
              [[style style]                           
               [font font]                             
               [enabled enabled]                       
               [vert-margin vert-margin]               
               [horiz-margin horiz-margin]             
               [min-width min-width]                   
               [min-height min-height]                 
               [stretchable-width stretchable-width]   
               [stretchable-height stretchable-height] 
               [auto-resize auto-resize]])             
 -> (is-a?/c message%)
  label : (or/c label-string? (is-a?/c bitmap%)
                (or/c 'app 'caution 'stop))
  parent : (or/c (is-a?/c frame%) (is-a?/c dialog%)
                 (is-a?/c panel%) (is-a?/c pane%))
  style : (listof (or/c 'deleted)) = null
  font : (is-a?/c font%) = normal-control-font
  enabled : any/c = #t
  vert-margin : spacing-integer? = 2
  horiz-margin : spacing-integer? = 2
  min-width : (or/c dimension-integer? #f) = #f
  min-height : (or/c dimension-integer? #f) = #f
  stretchable-width : any/c = #f
  stretchable-height : any/c = #f
  auto-resize : any/c = #f
method
(send a-message auto-resize) -> boolean?
(send a-message auto-resize on?) -> void?
  on? : any/c
method
(send a-message set-label label) -> void?
  label : (or/c label-string? (is-a?/c bitmap%))
class
mouse-event% : class?
  superclass: event%
constructor
(new mouse-event%                              
                   [event-type event-type]     
                  [[left-down left-down]       
                   [middle-down middle-down]   
                   [right-down right-down]     
                   [x x]                       
                   [y y]                       
                   [shift-down shift-down]     
                   [control-down control-down] 
                   [meta-down meta-down]       
                   [alt-down alt-down]         
                   [time-stamp time-stamp]     
                   [caps-down caps-down]       
                   [mod3-down mod3-down]       
                   [mod4-down mod4-down]       
                   [mod5-down mod5-down]])     
 -> (is-a?/c mouse-event%)
  event-type : (or/c 'enter 'leave 'left-down 'left-up
                     'middle-down 'middle-up
                     'right-down 'right-up 'motion)
  left-down : any/c = #f
  middle-down : any/c = #f
  right-down : any/c = #f
  x : exact-integer? = 0
  y : exact-integer? = 0
  shift-down : any/c = #f
  control-down : any/c = #f
  meta-down : any/c = #f
  alt-down : any/c = #f
  time-stamp : exact-integer? = 0
  caps-down : any/c = #f
  mod3-down : any/c = #f
  mod4-down : any/c = #f
  mod5-down : any/c = #f
method
(send a-mouse-event button-changed? [button]) -> boolean?
  button : (or/c 'left 'middle 'right 'any) = 'any
method
(send a-mouse-event button-down? [button]) -> boolean?
  button : (or/c 'left 'middle 'right 'any) = 'any
method
(send a-mouse-event button-up? [button]) -> boolean?
  button : (or/c 'left 'middle 'right 'any) = 'any
method
(send a-mouse-event dragging?) -> boolean?
method
(send a-mouse-event entering?) -> boolean?
method
(send a-mouse-event get-alt-down) -> boolean?
method
(send a-mouse-event get-caps-down) -> boolean?
method
(send a-mouse-event get-control-down) -> boolean?
method
(send a-mouse-event get-event-type)
 -> (or/c 'enter 'leave 'left-down 'left-up
          'middle-down 'middle-up
          'right-down 'right-up 'motion)
method
(send a-mouse-event get-left-down) -> boolean?
method
(send a-mouse-event get-meta-down) -> boolean?
method
(send a-mouse-event get-middle-down) -> boolean?
method
(send a-mouse-event get-mod3-down) -> boolean?
method
(send a-mouse-event get-mod4-down) -> boolean?
method
(send a-mouse-event get-mod5-down) -> boolean?
method
(send a-mouse-event get-right-down) -> boolean?
method
(send a-mouse-event get-shift-down) -> boolean?
method
(send a-mouse-event get-x) -> exact-integer?
method
(send a-mouse-event get-y) -> exact-integer?
method
(send a-mouse-event leaving?) -> boolean?
method
(send a-mouse-event moving?) -> boolean?
method
(send a-mouse-event set-alt-down down?) -> void?
  down? : any/c
method
(send a-mouse-event set-caps-down down?) -> void?
  down? : any/c
method
(send a-mouse-event set-control-down down?) -> void?
  down? : any/c
method
(send a-mouse-event set-event-type event-type) -> void?
  event-type : (or/c 'enter 'leave 'left-down 'left-up
                     'middle-down 'middle-up
                     'right-down 'right-up 'motion)
method
(send a-mouse-event set-left-down down?) -> void?
  down? : any/c
method
(send a-mouse-event set-meta-down down?) -> void?
  down? : any/c
method
(send a-mouse-event set-middle-down down?) -> void?
  down? : any/c
method
(send a-mouse-event set-mod3-down down?) -> void?
  down? : any/c
method
(send a-mouse-event set-mod4-down down?) -> void?
  down? : any/c
method
(send a-mouse-event set-mod5-down down?) -> void?
  down? : any/c
method
(send a-mouse-event set-right-down down?) -> void?
  down? : any/c
method
(send a-mouse-event set-shift-down down?) -> void?
  down? : any/c
method
(send a-mouse-event set-x pos) -> void?
  pos : exact-integer?
method
(send a-mouse-event set-y pos) -> void?
  pos : exact-integer?
class
pane% : class?
  superclass: object%
  extends: area-container<%>
           subarea<%>
constructor
(new pane%                                            
            [parent parent]                           
           [[vert-margin vert-margin]                 
            [horiz-margin horiz-margin]               
            [border border]                           
            [spacing spacing]                         
            [alignment alignment]                     
            [min-width min-width]                     
            [min-height min-height]                   
            [stretchable-width stretchable-width]     
            [stretchable-height stretchable-height]]) 
 -> (is-a?/c pane%)
  parent : (or/c (is-a?/c frame%) (is-a?/c dialog%)
                 (is-a?/c panel%) (is-a?/c pane%))
  vert-margin : spacing-integer? = 0
  horiz-margin : spacing-integer? = 0
  border : spacing-integer? = 0
  spacing : spacing-integer? = 0
  alignment : (list/c (or/c 'left 'center 'right)
                      (or/c 'top 'center 'bottom))
            = '(center top)
  min-width : (or/c dimension-integer? #f) = #f
  min-height : (or/c dimension-integer? #f) = #f
  stretchable-width : any/c = #t
  stretchable-height : any/c = #t
class
panel% : class?
  superclass: object%
  extends: area-container-window<%>
           subwindow<%>
constructor
(new panel%                                            
             [parent parent]                           
            [[style style]                             
             [enabled enabled]                         
             [vert-margin vert-margin]                 
             [horiz-margin horiz-margin]               
             [border border]                           
             [spacing spacing]                         
             [alignment alignment]                     
             [min-width min-width]                     
             [min-height min-height]                   
             [stretchable-width stretchable-width]     
             [stretchable-height stretchable-height]]) 
 -> (is-a?/c panel%)
  parent : (or/c (is-a?/c frame%) (is-a?/c dialog%)
                 (is-a?/c panel%) (is-a?/c pane%))
  style : (listof (or/c 'border 'deleted         = null
                        'hscroll 'auto-hscroll
                        'vscroll 'auto-vscroll))
  enabled : any/c = #t
  vert-margin : spacing-integer? = 0
  horiz-margin : spacing-integer? = 0
  border : spacing-integer? = 0
  spacing : spacing-integer? = 0
  alignment : (list/c (or/c 'left 'center 'right)
                      (or/c 'top 'center 'bottom))
            = '(center center)
  min-width : (or/c dimension-integer? #f) = #f
  min-height : (or/c dimension-integer? #f) = #f
  stretchable-width : any/c = #t
  stretchable-height : any/c = #t
class
popup-menu% : class?
  superclass: object%
  extends: menu-item-container<%>
constructor
(new popup-menu%                                      
                 [[title title]                       
                  [popdown-callback popdown-callback] 
                  [demand-callback demand-callback]   
                  [font font]])                       
 -> (is-a?/c popup-menu%)
  title : (or/c label-string? #f) = #f
  popdown-callback : ((is-a?/c popup-menu%) (is-a?/c control-event%)
                      . -> . any)
                   = (lambda (p e) (void))
  demand-callback : ((is-a?/c popup-menu%) . -> . any)
                  = (lambda (p) (void))
  font : (is-a?/c font%) = normal-control-font
method
(send a-popup-menu get-font) -> (is-a?/c font%)
method
(send a-popup-menu get-popup-target)
 -> (or/c (is-a?/c window<%>) (is-a?/c editor<%>) #f)
method
(send a-popup-menu set-min-width width) -> void?
  width : dimension-integer?
class
printer-dc% : class?
  superclass: object%
  extends: dc<%>
constructor
(new printer-dc% [[parent parent]]) -> (is-a?/c printer-dc%)
  parent : (or/c (is-a?/c frame%) (is-a?/c dialog%) #f) = #f
class
radio-box% : class?
  superclass: object%
  extends: control<%>
constructor
(new radio-box%                                            
                 [label label]                             
                 [choices choices]                         
                 [parent parent]                           
                [[callback callback]                       
                 [style style]                             
                 [selection selection]                     
                 [font font]                               
                 [enabled enabled]                         
                 [vert-margin vert-margin]                 
                 [horiz-margin horiz-margin]               
                 [min-width min-width]                     
                 [min-height min-height]                   
                 [stretchable-width stretchable-width]     
                 [stretchable-height stretchable-height]]) 
 -> (is-a?/c radio-box%)
  label : (or/c label-string? #f)
  choices : (or/c (listof label-string?) (listof (is-a?/c bitmap%)))
  parent : (or/c (is-a?/c frame%) (is-a?/c dialog%)
                 (is-a?/c panel%) (is-a?/c pane%))
  callback : ((is-a?/c radio-box%) (is-a?/c control-event%)
              . -> . any)
           = (lambda (r e) (void))
  style : (listof (or/c 'horizontal 'vertical
                        'vertical-label 'horizontal-label
                        'deleted))
        = '(vertical)
  selection : (or/c exact-nonnegative-integer? #f) = 0
  font : (is-a?/c font%) = normal-control-font
  enabled : any/c = #t
  vert-margin : spacing-integer? = 2
  horiz-margin : spacing-integer? = 2
  min-width : (or/c dimension-integer? #f) = #f
  min-height : (or/c dimension-integer? #f) = #f
  stretchable-width : any/c = #f
  stretchable-height : any/c = #f
method
(send a-radio-box enable enable?) -> void?
  enable? : any/c
(send a-radio-box enable n enable?) -> void?
  n : exact-nonnegative-integer?
  enable? : any/c
method
(send a-radio-box get-item-label n) -> string?
  n : exact-nonnegative-integer?
method
(send a-radio-box get-item-plain-label n) -> string?
  n : exact-nonnegative-integer?
method
(send a-radio-box get-number) -> exact-nonnegative-integer?
method
(send a-radio-box get-selection)
 -> (or/c exact-nonnegative-integer? #f)
method
(send a-radio-box is-enabled?) -> boolean?
(send a-radio-box is-enabled? n) -> boolean?
  n : exact-nonnegative-integer?
method
(send a-radio-box set-selection n) -> void?
  n : (or/c exact-nonnegative-integer? #f)
interface
selectable-menu-item<%> : interface?
  implements: labelled-menu-item<%>
method
(send a-selectable-menu-item command event) -> void?
  event : (is-a?/c control-event%)
method
(send a-selectable-menu-item get-shortcut)
 -> (or/c char? symbol? #f)
method
(send a-selectable-menu-item get-shortcut-prefix)
 -> (and/c (listof (or/c 'alt 'cmd 'meta 'ctl
                         'shift 'option))
           (λ (x) (implies (equal? 'unix (system-type))
                           (not (and (member 'alt x)
                                     (member 'meta x)))))
           (λ (x) (equal? x (remove-duplicates x))))
method
(send a-selectable-menu-item set-shortcut shortcut) -> void?
  shortcut : (or/c char? symbol? #f)
method
(send a-selectable-menu-item set-shortcut-prefix prefix)
 -> void?
  prefix : (and/c (listof (or/c 'alt 'cmd 'meta 'ctl
                                'shift 'option))
                  (λ (x) (implies (equal? 'unix (system-type))
                                  (not (and (member 'alt x)
                                            (member 'meta x)))))
                  (λ (x) (equal? x (remove-duplicates x))))
class
separator-menu-item% : class?
  superclass: object%
  extends: menu-item<%>
constructor
(new separator-menu-item% [parent parent])
 -> (is-a?/c separator-menu-item%)
  parent : (or/c (is-a?/c menu%) (is-a?/c popup-menu%))
class
scroll-event% : class?
  superclass: event%
constructor
(new scroll-event%                            
                   [[event-type event-type]   
                    [direction direction]     
                    [position position]       
                    [time-stamp time-stamp]]) 
 -> (is-a?/c scroll-event%)
  event-type : (or/c 'top 'bottom 'line-up 'line-down = 'thumb
                     'page-up 'page-down 'thumb)
  direction : (or/c 'horizontal 'vertical) = 'vertical
  position : dimension-integer? = 0
  time-stamp : exact-integer? = 0
method
(send a-scroll-event get-direction)
 -> (or/c 'horizontal 'vertical)
method
(send a-scroll-event get-event-type)
 -> (or/c 'top 'bottom 'line-up 'line-down
          'page-up 'page-down 'thumb)
method
(send a-scroll-event get-position) -> dimension-integer?
method
(send a-scroll-event set-direction direction) -> void?
  direction : (or/c 'horizontal 'vertical)
method
(send a-scroll-event set-event-type type) -> void?
  type : (or/c 'top 'bottom 'line-up 'line-down
               'page-up 'page-down 'thumb)
method
(send a-scroll-event set-position position) -> void?
  position : dimension-integer?
class
slider% : class?
  superclass: object%
  extends: control<%>
constructor
(new slider%                                            
              [label label]                             
              [min-value min-value]                     
              [max-value max-value]                     
              [parent parent]                           
             [[callback callback]                       
              [init-value init-value]                   
              [style style]                             
              [font font]                               
              [enabled enabled]                         
              [vert-margin vert-margin]                 
              [horiz-margin horiz-margin]               
              [min-width min-width]                     
              [min-height min-height]                   
              [stretchable-width stretchable-width]     
              [stretchable-height stretchable-height]]) 
 -> (is-a?/c slider%)
  label : (or/c label-string? #f)
  min-value : position-integer?
  max-value : position-integer?
  parent : (or/c (is-a?/c frame%) (is-a?/c dialog%)
                 (is-a?/c panel%) (is-a?/c pane%))
  callback : ((is-a?/c slider%) (is-a?/c control-event%) . -> . any)
           = (lambda (b e) (void))
  init-value : position-integer? = min-value
  style : (listof (or/c 'horizontal 'vertical 'plain
                        'vertical-label 'horizontal-label
                        'deleted))
        = '(horizontal)
  font : (is-a?/c font%) = normal-control-font
  enabled : any/c = #t
  vert-margin : spacing-integer? = 2
  horiz-margin : spacing-integer? = 2
  min-width : (or/c dimension-integer? #f) = #f
  min-height : (or/c dimension-integer? #f) = #f
  stretchable-width : any/c = (memq 'horizontal style)
  stretchable-height : any/c = (memq 'vertical style)
method
(send a-slider get-value) -> position-integer?
method
(send a-slider set-value value) -> void?
  value : position-integer?
interface
subarea<%> : interface?
  implements: area<%>
method
(send a-subarea horiz-margin) -> spacing-integer?
(send a-subarea horiz-margin margin) -> void?
  margin : spacing-integer?
method
(send a-subarea vert-margin) -> spacing-integer?
(send a-subarea vert-margin margin) -> void?
  margin : spacing-integer?
interface
subwindow<%> : interface?
  implements: subarea<%>
              window<%>
method
(send a-subwindow reparent new-parent) -> void?
  new-parent : (or/c (is-a?/c frame%) (is-a?/c dialog%)
                     (is-a?/c panel%) (is-a?/c pane%))
class
tab-panel% : class?
  superclass: vertical-panel%
constructor
(new tab-panel%                                            
                 [choices choices]                         
                 [parent parent]                           
                [[callback callback]                       
                 [style style]                             
                 [font font]                               
                 [enabled enabled]                         
                 [vert-margin vert-margin]                 
                 [horiz-margin horiz-margin]               
                 [border border]                           
                 [spacing spacing]                         
                 [alignment alignment]                     
                 [min-width min-width]                     
                 [min-height min-height]                   
                 [stretchable-width stretchable-width]     
                 [stretchable-height stretchable-height]]) 
 -> (is-a?/c tab-panel%)
  choices : (listof label-string?)
  parent : (or/c (is-a?/c frame%) (is-a?/c dialog%)
                 (is-a?/c panel%) (is-a?/c pane%))
  callback : ((is-a?/c tab-panel%) (is-a?/c control-event%)
              . -> . any)
           = (lambda (b e) (void))
  style : (listof (or/c 'no-border 'deleted)) = null
  font : (is-a?/c font%) = normal-control-font
  enabled : any/c = #t
  vert-margin : spacing-integer? = 0
  horiz-margin : spacing-integer? = 0
  border : spacing-integer? = 0
  spacing : spacing-integer? = 0
  alignment : (list/c (or/c 'left 'center 'right)
                      (or/c 'top 'center 'bottom))
            = '(center top)
  min-width : (or/c dimension-integer? #f) = #f
  min-height : (or/c dimension-integer? #f) = #f
  stretchable-width : any/c = #t
  stretchable-height : any/c = #t
method
(send a-tab-panel append choice) -> void?
  choice : label-string?
method
(send a-tab-panel delete n) -> void?
  n : exact-nonnegative-integer?
method
(send a-tab-panel get-item-label n) -> string?
  n : exact-nonnegative-integer?
method
(send a-tab-panel get-number) -> exact-nonnegative-integer?
method
(send a-tab-panel get-selection)
 -> (or/c exact-nonnegative-integer? #f)
method
(send a-tab-panel set choices) -> void?
  choices : (listof label-string?)
method
(send a-tab-panel set-item-label n label) -> void?
  n : exact-nonnegative-integer?
  label : label-string?
method
(send a-tab-panel set-selection n) -> void?
  n : exact-nonnegative-integer?
class
text-field% : class?
  superclass: object%
  extends: control<%>
constructor
(new text-field%                                            
                  [label label]                             
                  [parent parent]                           
                 [[callback callback]                       
                  [init-value init-value]                   
                  [style style]                             
                  [font font]                               
                  [enabled enabled]                         
                  [vert-margin vert-margin]                 
                  [horiz-margin horiz-margin]               
                  [min-width min-width]                     
                  [min-height min-height]                   
                  [stretchable-width stretchable-width]     
                  [stretchable-height stretchable-height]]) 
 -> (is-a?/c text-field%)
  label : (or/c label-string? #f)
  parent : (or/c (is-a?/c frame%) (is-a?/c dialog%)
                 (is-a?/c panel%) (is-a?/c pane%))
  callback : ((is-a?/c text-field%) (is-a?/c control-event%)
              . -> . any)
           = (lambda (t e) (void))
  init-value : string? = ""
  style : (listof (or/c 'single 'multiple 'hscroll 'password
                        'vertical-label 'horizontal-label
                        'deleted))
        = '(single)
  font : (is-a?/c font%) = normal-control-font
  enabled : any/c = #t
  vert-margin : spacing-integer? = 2
  horiz-margin : spacing-integer? = 2
  min-width : (or/c dimension-integer? #f) = #f
  min-height : (or/c dimension-integer? #f) = #f
  stretchable-width : any/c = #t
  stretchable-height : any/c = (memq 'multiple style)
method
(send a-text-field get-editor) -> (is-a?/c text%)
method
(send a-text-field get-field-background) -> (is-a?/c color%)
method
(send a-text-field get-value) -> string?
method
(send a-text-field set-field-background color) -> void?
  color : (is-a?/c color%)
method
(send a-text-field set-value val) -> void?
  val : string?
class
timer% : class?
  superclass: object%
constructor
(new timer%                                    
            [[notify-callback notify-callback] 
             [interval interval]               
             [just-once? just-once?]])         
 -> (is-a?/c timer%)
  notify-callback : (-> any) = void
  interval : (or/c (integer-in 0 1000000000) #f) = #f
  just-once? : any/c = #f
method
(send a-timer interval) -> (integer-in 0 1000000000)
method
(send a-timer notify) -> void?
method
(send a-timer start msec [just-once?]) -> void?
  msec : (integer-in 0 1000000000)
  just-once? : any/c = #f
method
(send a-timer stop) -> void?
interface
top-level-window<%> : interface?
  implements: area-container-window<%>
method
(send a-top-level-window can-close?) -> boolean?
method
(send a-top-level-window can-exit?) -> boolean?
method
(send a-top-level-window center [direction]) -> void?
  direction : (or/c 'horizontal 'vertical 'both) = 'both
method
(send a-top-level-window get-edit-target-object)
 -> (or/c (or/c (is-a?/c window<%>) (is-a?/c editor<%>)) #f)
method
(send a-top-level-window get-edit-target-window)
 -> (or/c (is-a?/c window<%>) #f)
method
(send a-top-level-window get-eventspace) -> eventspace?
method
(send a-top-level-window get-focus-object)
 -> (or/c (or/c (is-a?/c window<%>) (is-a?/c editor<%>)) #f)
method
(send a-top-level-window get-focus-window)
 -> (or/c (is-a?/c window<%>) #f)
method
(send a-top-level-window move x y) -> void?
  x : position-integer?
  y : position-integer?
method
(send a-top-level-window on-activate active?) -> void?
  active? : any/c
method
(send a-top-level-window on-close) -> void?
method
(send a-top-level-window on-exit) -> void?
method
(send a-top-level-window on-message message) -> any/c
  message : any/c
method
(send a-top-level-window display-changed) -> any/c
method
(send a-top-level-window on-traverse-char event) -> boolean?
  event : (is-a?/c key-event%)
method
(send a-top-level-window on-system-menu-char event) -> boolean?
  event : (is-a?/c key-event%)
method
(send a-top-level-window resize width       
                                height) -> void?
  width : dimension-integer?
  height : dimension-integer?
method
(send a-top-level-window set-icon  icon        
                                  [mask        
                                   which]) -> void?
  icon : (is-a?/c bitmap%)
  mask : (is-a?/c bitmap%) = #f
  which : (or/c 'small 'large 'both) = 'both
method
(send a-top-level-window show show) -> void?
  show : any/c
class
vertical-pane% : class?
  superclass: pane%
constructor
(new vertical-pane%                                            
                     [parent parent]                           
                    [[vert-margin vert-margin]                 
                     [horiz-margin horiz-margin]               
                     [border border]                           
                     [spacing spacing]                         
                     [alignment alignment]                     
                     [min-width min-width]                     
                     [min-height min-height]                   
                     [stretchable-width stretchable-width]     
                     [stretchable-height stretchable-height]]) 
 -> (is-a?/c vertical-pane%)
  parent : (or/c (is-a?/c frame%) (is-a?/c dialog%)
                 (is-a?/c panel%) (is-a?/c pane%))
  vert-margin : spacing-integer? = 0
  horiz-margin : spacing-integer? = 0
  border : spacing-integer? = 0
  spacing : spacing-integer? = 0
  alignment : (list/c (or/c 'left 'center 'right)
                      (or/c 'top 'center 'bottom))
            = '(center top)
  min-width : (or/c dimension-integer? #f) = #f
  min-height : (or/c dimension-integer? #f) = #f
  stretchable-width : any/c = #t
  stretchable-height : any/c = #t
class
vertical-panel% : class?
  superclass: panel%
constructor
(new vertical-panel%                                            
                      [parent parent]                           
                     [[style style]                             
                      [enabled enabled]                         
                      [vert-margin vert-margin]                 
                      [horiz-margin horiz-margin]               
                      [border border]                           
                      [spacing spacing]                         
                      [alignment alignment]                     
                      [min-width min-width]                     
                      [min-height min-height]                   
                      [stretchable-width stretchable-width]     
                      [stretchable-height stretchable-height]]) 
 -> (is-a?/c vertical-panel%)
  parent : (or/c (is-a?/c frame%) (is-a?/c dialog%)
                 (is-a?/c panel%) (is-a?/c pane%))
  style : (listof (or/c 'border 'deleted         = null
                        'hscroll 'auto-hscroll
                        'vscroll 'auto-vscroll))
  enabled : any/c = #t
  vert-margin : spacing-integer? = 0
  horiz-margin : spacing-integer? = 0
  border : spacing-integer? = 0
  spacing : spacing-integer? = 0
  alignment : (list/c (or/c 'left 'center 'right)
                      (or/c 'top 'center 'bottom))
            = '(center top)
  min-width : (or/c dimension-integer? #f) = #f
  min-height : (or/c dimension-integer? #f) = #f
  stretchable-width : any/c = #t
  stretchable-height : any/c = #t
method
(send a-vertical-panel set-orientation horizontal?) -> void?
  horizontal? : boolean?
method
(send a-vertical-panel get-orientation) -> boolean?
interface
window<%> : interface?
  implements: area<%>
method
(send a-window accept-drop-files) -> boolean?
(send a-window accept-drop-files accept-files?) -> void?
  accept-files? : any/c
method
(send a-window client->screen x y)
 -> position-integer? position-integer?
  x : position-integer?
  y : position-integer?
method
(send a-window enable enable?) -> void?
  enable? : any/c
method
(send a-window focus) -> void?
method
(send a-window get-client-handle) -> cpointer?
method
(send a-window get-client-size)
 -> dimension-integer? dimension-integer?
method
(send a-window get-cursor) -> (or/c (is-a?/c cursor%) #f)
method
(send a-window get-handle) -> cpointer?
method
(send a-window get-height) -> dimension-integer?
method
(send a-window get-label)
 -> (or/c label-string?
          (is-a?/c bitmap%)
          (or/c 'app 'caution 'stop)
          (list/c (is-a?/c bitmap%)
                  label-string?
                  (or/c 'left 'top 'right 'bottom))
          #f)
method
(send a-window get-plain-label) -> (or/c string? #f)
method
(send a-window get-size)
 -> dimension-integer? dimension-integer?
method
(send a-window get-width) -> dimension-integer?
method
(send a-window get-x) -> position-integer?
method
(send a-window get-y) -> position-integer?
method
(send a-window has-focus?) -> boolean?
method
(send a-window is-enabled?) -> boolean?
method
(send a-window is-shown?) -> boolean?
method
(send a-window on-drop-file pathname) -> void?
  pathname : path?
method
(send a-window on-focus on?) -> void?
  on? : any/c
method
(send a-window on-move x y) -> void?
  x : position-integer?
  y : position-integer?
method
(send a-window on-size width height) -> void?
  width : dimension-integer?
  height : dimension-integer?
method
(send a-window on-subwindow-char receiver     
                                 event)   -> boolean?
  receiver : (is-a?/c window<%>)
  event : (is-a?/c key-event%)
method
(send a-window on-subwindow-event receiver     
                                  event)   -> boolean?
  receiver : (is-a?/c window<%>)
  event : (is-a?/c mouse-event%)
method
(send a-window on-subwindow-focus receiver     
                                  on?)     -> void?
  receiver : (is-a?/c window<%>)
  on? : boolean?
method
(send a-window on-superwindow-enable enabled?) -> void?
  enabled? : any/c
method
(send a-window on-superwindow-show shown?) -> void?
  shown? : any/c
method
(send a-window popup-menu menu x y) -> void?
  menu : (is-a?/c popup-menu%)
  x : position-integer?
  y : position-integer?
method
(send a-window refresh) -> void?
method
(send a-window screen->client x y)
 -> position-integer? position-integer?
  x : position-integer?
  y : position-integer?
method
(send a-window set-cursor cursor) -> void?
  cursor : (or/c (is-a?/c cursor%) #f)
method
(send a-window set-label l) -> void?
  l : label-string?
method
(send a-window show show?) -> void?
  show? : any/c
method
(send a-window warp-pointer x y) -> void?
  x : position-integer?
  y : position-integer?
procedure
(get-file [message                           
           parent                            
           directory                         
           filename                          
           extension                         
           style                             
           filters                           
           #:dialog-mixin dialog-mixin]) -> (or/c path? #f)
  message : (or/c label-string? #f) = #f
  parent : (or/c (is-a?/c frame%) (is-a?/c dialog%) #f) = #f
  directory : (or/c path-string? #f) = #f
  filename : (or/c path-string? #f) = #f
  extension : (or/c string? #f) = #f
  style : (listof (or/c 'packages 'enter-packages 'common))
        = null
  filters : (listof (list/c string? string?)) = '(("Any" "*.*"))
  dialog-mixin : (make-mixin-contract path-dialog%) = (λ (x) x)
procedure
(get-file-list [message                       
                parent                        
                directory                     
                filename                      
                extension                     
                style                         
                filters                       
                #:dialog-mixin dialog-mixin]) 
 -> (or/c (listof path?) #f)
  message : (or/c label-string? #f) = #f
  parent : (or/c (is-a?/c frame%) (is-a?/c dialog%) #f) = #f
  directory : (or/c path-string? #f) = #f
  filename : (or/c path-string? #f) = #f
  extension : (or/c string? #f) = #f
  style : (listof (or/c 'packages 'enter-packages 'common))
        = null
  filters : (listof (list/c string? string?)) = '(("Any" "*.*"))
  dialog-mixin : (make-mixin-contract path-dialog%) = (λ (x) x)
procedure
(put-file [message                           
           parent                            
           directory                         
           filename                          
           extension                         
           style                             
           filters                           
           #:dialog-mixin dialog-mixin]) -> (or/c path? #f)
  message : (or/c label-string? #f) = #f
  parent : (or/c (is-a?/c frame%) (is-a?/c dialog%) #f) = #f
  directory : (or/c path-string? #f) = #f
  filename : (or/c path-string? #f) = #f
  extension : (or/c string? #f) = #f
  style : (listof (or/c 'packages 'enter-packages 'common))
        = null
  filters : (listof (list/c string? string?)) = '(("Any" "*.*"))
  dialog-mixin : (make-mixin-contract path-dialog%) = (λ (x) x)
procedure
(get-directory [message                           
                parent                            
                directory                         
                style                             
                #:dialog-mixin dialog-mixin]) -> (or/c path #f)
  message : (or/c label-string? #f) = #f
  parent : (or/c (is-a?/c frame%) (is-a?/c dialog%) #f) = #f
  directory : (or/c path-string? #f) = #f
  style : (listof (or/c 'enter-packages 'common)) = null
  dialog-mixin : (make-mixin-contract path-dialog%) = (λ (x) x)
procedure
(message-box  title                         
              message                       
             [parent                        
              style                         
              #:dialog-mixin dialog-mixin]) 
 -> (or/c 'ok 'cancel 'yes 'no)
  title : label-string?
  message : string?
  parent : (or/c (is-a?/c frame%) (is-a?/c dialog%) #f) = #f
  style : (listof (or/c 'ok 'ok-cancel 'yes-no    = '(ok)
                        'caution 'stop 'no-icon))
  dialog-mixin : (make-mixin-contract dialog%) = values
procedure
(message-box/custom  title                         
                     message                       
                     button1-label                 
                     button2-label                 
                     button3-label                 
                    [parent                        
                     style                         
                     close-result                  
                     #:dialog-mixin dialog-mixin]) 
 -> (or/c 1 2 3 close-result)
  title : label-string?
  message : string?
  button1-label : (or/c label-string? (is-a?/c bitmap%) #f)
  button2-label : (or/c label-string? (is-a?/c bitmap%) #f)
  button3-label : (or/c label-string? (is-a?/c bitmap%) #f)
  parent : (or/c (is-a?/c frame%) (is-a?/c dialog%) #f) = #f
  style : (listof (or/c 'stop 'caution 'no-icon 'number-order
                        'disallow-close 'no-default
                        'default=1 'default=2 'default=3))
        = '(no-default)
  close-result : any/c = #f
  dialog-mixin : (make-mixin-contract dialog%) = values
procedure
(message+check-box  title                         
                    message                       
                    check-label                   
                   [parent                        
                    style                         
                    #:dialog-mixin dialog-mixin]) 
 -> (or/c 'ok 'cancel 'yes 'no) boolean?
  title : label-string?
  message : string?
  check-label : label-string?
  parent : (or/c (is-a?/c frame%) (is-a?/c dialog%) #f) = #f
  style : (listof (or/c 'ok 'ok-cancel 'yes-no
                        'caution 'stop 'no-icon 'checked))
        = '(ok)
  dialog-mixin : (make-mixin-contract dialog%) = values
procedure
(message+check-box/custom  title                         
                           message                       
                           check-label                   
                           button1-label                 
                           button2-label                 
                           button3-label                 
                          [parent                        
                           style                         
                           close-result                  
                           #:dialog-mixin dialog-mixin]) 
 -> (or/c 1 2 3 (λ (x) (eq? x close-result)))
  title : label-string?
  message : string?
  check-label : label-string?
  button1-label : (or/c label-string? (is-a?/c bitmap%) #f)
  button2-label : (or/c label-string? (is-a?/c bitmap%) #f)
  button3-label : (or/c label-string? (is-a?/c bitmap%) #f)
  parent : (or/c (is-a?/c frame%) (is-a?/c dialog%) #f) = #f
  style : (listof (or/c 'stop 'caution 'no-icon 'number-order
                        'disallow-close 'no-default
                        'default=1 'default=2 'default=3))
        = '(no-default)
  close-result : any/c = #f
  dialog-mixin : (make-mixin-contract dialog%) = values
procedure
(get-text-from-user  title                         
                     message                       
                    [parent                        
                     init-val                      
                     style]                        
                     #:validate validate           
                    [#:dialog-mixin dialog-mixin]) 
 -> (or/c string? #f)
  title : label-string?
  message : (or/c label-string? #f)
  parent : (or/c (is-a?/c frame%) (is-a?/c dialog%) #f) = #f
  init-val : string? = ""
  style : (listof (or/c 'password 'disallow-invalid)) = null
  validate : (-> string? boolean?)
  dialog-mixin : (make-mixin-contract dialog%) = values
procedure
(get-choices-from-user  title        
                        message      
                        choices      
                       [parent       
                        init-choices 
                        style])      
 -> (or/c (listof exact-nonnegative-integer?) #f)
  title : label-string?
  message : (or/c label-string? #f)
  choices : (listof label-string?)
  parent : (or/c (is-a?/c frame%) (is-a?/c dialog%) #f) = #f
  init-choices : (listof exact-nonnegative-integer?) = null
  style : (listof (or/c 'single 'multiple 'extended))
        = '(single)
procedure
(get-color-from-user [message        
                      parent         
                      init-color     
                      style])    -> (or/c (is-a?/c color%) #f)
  message : (or/c label-string? #f) = #f
  parent : (or/c (is-a?/c frame%) (is-a?/c dialog%) #f) = #f
  init-color : (or/c (is-a?/c color%) #f) = #f
  style : (listof 'alpha) = null
procedure
(get-font-from-user [message       
                     parent        
                     init-font     
                     style])   -> (or/c (is-a?/c font%) #f)
  message : (or/c label-string? #f) = #f
  parent : (or/c (is-a?/c frame%) (is-a?/c dialog%) #f) = #f
  init-font : (or/c (is-a?/c font%) #f) = #f
  style : null? = null
procedure
(get-ps-setup-from-user [message    
                         parent     
                         init-setup 
                         style])    
 -> (or/c (is-a?/c ps-setup%) #f)
  message : (or/c label-string? #f) = #f
  parent : (or/c (is-a?/c frame%) (is-a?/c dialog%) #f) = #f
  init-setup : (or/c (is-a?/c ps-setup%) #f) = #f
  style : null? = null
procedure
(get-page-setup-from-user [message    
                           parent     
                           init-setup 
                           style])    
 -> (or/c (is-a?/c ps-setup%) #f)
  message : (or/c label-string? #f) = #f
  parent : (or/c (is-a?/c frame%) (is-a?/c dialog%) #f) = #f
  init-setup : (or/c (is-a?/c ps-setup%) #f) = #f
  style : null? = null
procedure
(can-get-page-setup-from-user?) -> boolean?
procedure
(make-eventspace) -> eventspace?
parameter
(current-eventspace) -> eventspace?
(current-eventspace e) -> void?
  e : eventspace?
procedure
(eventspace? v) -> boolean?
  v : any/c
parameter
(event-dispatch-handler) -> (eventspace? . -> . any)
(event-dispatch-handler handler) -> void?
  handler : (eventspace? . -> . any)
procedure
(eventspace-event-evt [e]) -> evt?
  e : eventspace? = (current-eventspace)
procedure
(check-for-break) -> boolean?
procedure
(get-top-level-windows)
 -> (listof (or/c (is-a?/c frame%) (is-a?/c dialog%)))
procedure
(get-top-level-focus-window)
 -> (or/c (is-a?/c frame%) (is-a?/c dialog%) #f)
procedure
(get-top-level-edit-target-window)
 -> (or/c (is-a?/c frame%) (is-a?/c dialog%) #f)
procedure
(special-control-key on?) -> void?
  on? : any/c
(special-control-key) -> boolean?
procedure
(special-option-key on?) -> void?
  on? : any/c
(special-option-key) -> boolean?
procedure
(queue-callback callback [high-priority?]) -> void?
  callback : (-> any)
  high-priority? : any/c = #t
procedure
(yield) -> boolean?
(yield v) -> any/c
  v : (or/c 'wait evt?)
procedure
(sleep/yield secs) -> void?
  secs : (and/c real? (not/c negative?))
procedure
(eventspace-shutdown? e) -> boolean?
  e : eventspace?
procedure
(eventspace-handler-thread e) -> (or/c thread? #f)
  e : eventspace?
procedure
(current-eventspace-has-standard-menus?) -> boolean?
procedure
(current-eventspace-has-menu-root?) -> boolean?
procedure
(application-about-handler) -> (-> any)
(application-about-handler handler-thunk) -> void?
  handler-thunk : (-> any)
procedure
(application-file-handler) -> (path? . -> . any)
(application-file-handler handler-proc) -> void?
  handler-proc : (path? . -> . any)
procedure
(application-preferences-handler) -> (or/c (-> any) #f)
(application-preferences-handler handler-thunk) -> void?
  handler-thunk : (or/c (-> any) #f)
procedure
(application-quit-handler) -> (-> any)
(application-quit-handler handler-thunk) -> void?
  handler-thunk : (-> any)
procedure
(application-start-empty-handler) -> (-> any)
(application-start-empty-handler handler-thunk) -> void?
  handler-thunk : (-> any)
procedure
(flush-display) -> void?
procedure
(get-display-backing-scale [#:monitor monitor])
 -> (or/c (>/c 0.0) #f)
  monitor : exact-nonnegative-integer? = 0
procedure
(get-display-count) -> exact-positive-integer?
procedure
(get-display-depth) -> exact-nonnegative-integer?
procedure
(get-display-left-top-inset [avoid-bars?         
                             #:monitor monitor]) 
 -> (if (= monitor 0)
        exact-nonnegative-integer?
        (or/c exact-nonnegative-integer? #f))
    (if (= monitor 0)
        exact-nonnegative-integer?
        (or/c exact-nonnegative-integer? #f))
  avoid-bars? : any/c = #f
  monitor : exact-nonnegative-integer? = 0
procedure
(get-display-size [full-screen?        
                   #:monitor monitor]) 
 -> (if (= monitor 0)
        exact-nonnegative-integer?
        (or/c exact-nonnegative-integer? #f))
    (if (= monitor 0)
        exact-nonnegative-integer?
        (or/c exact-nonnegative-integer? #f))
  full-screen? : any/c = #f
  monitor : exact-nonnegative-integer? = 0
procedure
(is-color-display?) -> boolean?
value
menu-control-font : (is-a?/c font%)
value
normal-control-font : (is-a?/c font%)
value
small-control-font : (is-a?/c font%)
value
tiny-control-font : (is-a?/c font%)
value
view-control-font : (is-a?/c font%)
procedure
(begin-busy-cursor) -> void?
procedure
(bell) -> void?
procedure
(dimension-integer? v) -> boolean?
  v : any/c
procedure
(end-busy-cursor) -> void?
procedure
(file-creator-and-type filename           
                       creator-string     
                       type-bytes)    -> void?
  filename : path?
  creator-string : (lambda (s) (and (bytes? s)
                                    (= 4 (bytes-length s))))
  type-bytes : (lambda (s) (and (bytes? s)
                                 (= 4 (bytes-length s))))
(file-creator-and-type filename)
 -> (lambda (s) (and (bytes? s)
                (= 4 (bytes-length s))))
    (lambda (s) (and (bytes? s)
                (= 4 (bytes-length s))))
  filename : path?
procedure
(find-graphical-system-path what) -> (or/c path? #f)
  what : (or/c 'init-file 'x-display)
procedure
(get-default-shortcut-prefix)
 -> (case (system-type)
      [(windows) (list/c 'ctl)]
      [(macosx)  (list/c 'cmd)]
      [(unix)    (list/c (or/c 'alt 'cmd 'meta 'ctl 'shift 'option))])
procedure
(get-panel-background) -> (is-a?/c color%)
procedure
(get-highlight-background-color) -> (is-a?/c color%)
procedure
(get-highlight-text-color) -> (or/c (is-a?/c color%) #f)
procedure
(get-window-text-extent  string         
                         font           
                        [combine?]) -> exact-nonnegative-integer?
                                       exact-nonnegative-integer?
  string : string?
  font : (is-a?/c font%)
  combine? : any/c = #f
procedure
(graphical-read-eval-print-loop [eval-eventspace       
                                 redirect-ports?]) -> void?
  eval-eventspace : (or/c eventspace? #f) = #f
  redirect-ports? : any/c = (not eval-eventspace)
procedure
(textual-read-eval-print-loop) -> void?
procedure
(get-current-mouse-state)
 -> (is-a?/c point%)
    (listof (or/c 'left 'middle 'right
                  'shift 'control 'alt 'meta 'caps))
procedure
(hide-cursor-until-moved) -> void?
procedure
(is-busy?) -> boolean?
procedure
(label->plain-label label) -> string?
  label : string?
procedure
(make-gl-bitmap width height config) -> (is-a?/c bitmap%)
  width : exact-positive-integer?
  height : exact-positive-integer?
  config : (is-a?/c gl-config%)
procedure
(make-gui-empty-namespace) -> namespace?
procedure
(make-gui-namespace) -> namespace?
procedure
(make-screen-bitmap width height) -> (is-a?/c bitmap%)
  width : exact-positive-integer?
  height : exact-positive-integer?
procedure
(play-sound filename async?) -> boolean?
  filename : path-string?
  async? : any/c
procedure
(position-integer? v) -> boolean?
  v : any/c
procedure
(positive-dimension-integer? v) -> boolean?
  v : any/c
procedure
(register-collecting-blit  canvas      
                           x           
                           y           
                           w           
                           h           
                           on          
                           off         
                          [on-x        
                           on-y        
                           off-x       
                           off-y]) -> void?
  canvas : (is-a?/c canvas%)
  x : position-integer?
  y : position-integer?
  w : dimension-integer?
  h : dimension-integer?
  on : (is-a?/c bitmap%)
  off : (is-a?/c bitmap%)
  on-x : real? = 0
  on-y : real? = 0
  off-x : real? = 0
  off-y : real? = 0
procedure
(unregister-collecting-blit canvas) -> void?
  canvas : (is-a?/c canvas%)
procedure
(send-message-to-window x y message) -> any/c
  x : position-integer?
  y : position-integer?
  message : any/c
procedure
(spacing-integer? v) -> boolean?
  v : any/c
procedure
(system-position-ok-before-cancel?) -> boolean?
value
the-clipboard : (is-a?/c clipboard<%>)
value
the-x-selection-clipboard : (is-a?/c clipboard<%>)
procedure
(label-string? v) -> boolean?
  v : any/c
procedure
(key-code-symbol? v) -> boolean?
  v : any/c
interface
add-color<%> : interface?
method
(send an-add-color get r g b) -> void?
  r : (box/c (integer-in -1000 1000))
  g : (box/c (integer-in -1000 1000))
  b : (box/c (integer-in -1000 1000))
method
(send an-add-color get-b) -> (integer-in -1000 1000)
method
(send an-add-color get-g) -> (integer-in -1000 1000)
method
(send an-add-color get-r) -> (integer-in -1000 1000)
method
(send an-add-color set r g b) -> void?
  r : (integer-in -1000 1000)
  g : (integer-in -1000 1000)
  b : (integer-in -1000 1000)
method
(send an-add-color set-b v) -> void?
  v : (integer-in -1000 1000)
method
(send an-add-color set-g v) -> void?
  v : (integer-in -1000 1000)
method
(send an-add-color set-r v) -> void?
  v : (integer-in -1000 1000)
class
image-snip% : class?
  superclass: snip%
constructor
(make-object image-snip% [file            
                          kind            
                          relative-path?  
                          inline?         
                          backing-scale]) 
 -> (is-a?/c image-snip%)
  file : (or/c path-string? input-port? #f) = #f
  kind : (or/c 'unknown 'unknown/mask 'unknown/alpha = 'unknown
               'gif 'gif/mask 'gif/alpha
               'jpeg 'png 'png/mask 'png/alpha
               'xbm 'xpm 'bmp 'pict)
  relative-path? : any/c = #f
  inline? : any/c = #t
  backing-scale : (>/c 0.0) = 1.0
(make-object image-snip% bitmap [mask]) -> (is-a?/c image-snip%)
  bitmap : (is-a?/c bitmap%)
  mask : (or/c (is-a?/c bitmap%) #f) = #f
method
(send an-image-snip equal-hash-code-of hash-code)
 -> exact-integer?
  hash-code : (any/c . -> . exact-integer?)
method
(send an-image-snip equal-secondary-hash-code-of hash-code)
 -> exact-integer?
  hash-code : (any/c . -> . exact-integer?)
method
(send an-image-snip get-bitmap) -> (or/c (is-a?/c bitmap%) #f)
method
(send an-image-snip get-bitmap-mask)
 -> (or/c (is-a?/c bitmap%) #f)
method
(send an-image-snip get-filename [relative-path])
 -> (or/c path-string? #f)
  relative-path : (or/c (box/c any/c) #f) = #f
method
(send an-image-snip get-filetype)
 -> (or/c 'unknown 'unknown/mask 'unknown/alpha
          'gif 'gif/mask 'gif/alpha
          'jpeg 'png 'png/mask 'png/alpha
          'xbm 'xpm 'bmp 'pict)
method
(send an-image-snip load-file  file                
                              [kind                
                               relative-path?      
                               inline?             
                               backing-scale]) -> void?
  file : (or/c path-string? input-port? #f)
  kind : (or/c 'unknown 'unknown/mask 'unknown/alpha = 'unknown
               'gif 'gif/mask 'gif/alpha
               'jpeg 'png 'png/mask 'png/alpha
               'xbm 'xpm 'bmp 'pict)
  relative-path? : any/c = #f
  inline? : any/c = #t
  backing-scale : (>/c 0.0) = 1.0
method
(send an-image-snip other-equal-to? snip        
                                    equal?) -> boolean?
  snip : (is-a?/c image-snip%)
  equal? : (any/c any/c . -> . boolean?)
method
(send an-image-snip resize w h) -> boolean?
  w : (and/c real? (not/c negative?))
  h : (and/c real? (not/c negative?))
method
(send an-image-snip set-bitmap bm [mask]) -> void?
  bm : (is-a?/c bitmap%)
  mask : (or/c (is-a?/c bitmap%) #f) = #f
method
(send an-image-snip set-offset dx dy) -> void?
  dx : real?
  dy : real?
interface
mult-color<%> : interface?
method
(send a-mult-color get r g b) -> void?
  r : (box/c real?)
  g : (box/c real?)
  b : (box/c real?)
method
(send a-mult-color get-b) -> real?
method
(send a-mult-color get-g) -> real?
method
(send a-mult-color get-r) -> real?
method
(send a-mult-color set r g b) -> void?
  r : real?
  g : real?
  b : real?
method
(send a-mult-color set-b v) -> void?
  v : real?
method
(send a-mult-color set-g v) -> void?
  v : real?
method
(send a-mult-color set-r v) -> void?
  v : real?
interface
readable-snip<%> : interface?
method
(send a-readable-snip read-special source        
                                   line          
                                   column        
                                   position) -> any/c
  source : any/c
  line : (or/c exact-nonnegative-integer? #f)
  column : (or/c exact-nonnegative-integer? #f)
  position : (or/c exact-nonnegative-integer? #f)
class
snip% : class?
  superclass: object%
  extends: equal<%>
constructor
(new snip%) -> (is-a?/c snip%)
method
(send a-snip adjust-cursor dc      
                           x       
                           y       
                           editorx 
                           editory 
                           event)  
 -> (or/c (is-a?/c cursor%) #f)
  dc : (is-a?/c dc<%>)
  x : real?
  y : real?
  editorx : real?
  editory : real?
  event : (is-a?/c mouse-event%)
method
(send a-snip blink-caret dc x y) -> void?
  dc : (is-a?/c dc<%>)
  x : real?
  y : real?
method
(send a-snip can-do-edit-operation?  op               
                                    [recursive?]) -> boolean?
  op : (or/c 'undo 'redo 'clear 'cut 'copy
             'paste 'kill 'select-all
             'insert-text-box 'insert-pasteboard-box
             'insert-image)
  recursive? : any/c = #t
method
(send a-snip copy) -> (is-a?/c snip%)
method
(send a-snip do-edit-operation  op             
                               [recursive?     
                                time])     -> void?
  op : (or/c 'undo 'redo 'clear 'cut 'copy
             'paste 'kill 'select-all
             'insert-text-box 'insert-pasteboard-box
             'insert-image)
  recursive? : any/c = #t
  time : exact-integer? = 0
method
(send a-snip draw dc              
                  x               
                  y               
                  left            
                  top             
                  right           
                  bottom          
                  dx              
                  dy              
                  draw-caret) -> void?
  dc : (is-a?/c dc<%>)
  x : real?
  y : real?
  left : real?
  top : real?
  right : real?
  bottom : real?
  dx : real?
  dy : real?
  draw-caret : (or/c 'no-caret 'show-inactive-caret 'show-caret
                     (cons/c exact-nonnegative-integer?
                             exact-nonnegative-integer?))
method
(send a-snip equal-to? snip equal?) -> boolean?
  snip : (is-a?/c snip%)
  equal? : (-> any/c any/c boolean?)
method
(send a-snip other-equal-to? that equal?) -> boolean?
  that : (is-a?/c snip%)
  equal? : (-> any/c any/c boolean?)
method
(send a-snip equal-hash-code-of hash-code) -> exact-integer?
  hash-code : (any/c . -> . exact-integer?)
method
(send a-snip equal-secondary-hash-code-of hash-code)
 -> exact-integer?
  hash-code : (any/c . -> . exact-integer?)
method
(send a-snip find-scroll-step y) -> exact-nonnegative-integer?
  y : real?
method
(send a-snip get-admin) -> (or/c (is-a?/c snip-admin%) #f)
method
(send a-snip get-count) -> (integer-in 0 100000)
method
(send a-snip get-extent  dc           
                         x            
                         y            
                        [w            
                         h            
                         descent      
                         space        
                         lspace       
                         rspace]) -> void?
  dc : (is-a?/c dc<%>)
  x : real?
  y : real?
  w : (or/c (box/c (and/c real? (not/c negative?))) #f) = #f
  h : (or/c (box/c (and/c real? (not/c negative?))) #f) = #f
  descent : (or/c (box/c (and/c real? (not/c negative?))) #f)
          = #f
  space : (or/c (box/c (and/c real? (not/c negative?))) #f) = #f
  lspace : (or/c (box/c (and/c real? (not/c negative?))) #f)
         = #f
  rspace : (or/c (box/c (and/c real? (not/c negative?))) #f)
         = #f
method
(send a-snip get-flags) -> (listof symbol?)
method
(send a-snip get-num-scroll-steps)
 -> exact-nonnegative-integer?
method
(send a-snip get-scroll-step-offset offset)
 -> (and/c real? (not/c negative?))
  offset : exact-nonnegative-integer?
method
(send a-snip get-snipclass) -> (or/c #f (is-a?/c snip-class%))
method
(send a-snip get-style) -> (is-a?/c style<%>)
method
(send a-snip get-text offset num [flattened?]) -> string?
  offset : exact-nonnegative-integer?
  num : exact-nonnegative-integer?
  flattened? : any/c = #f
method
(send a-snip get-text! buffer             
                       offset             
                       num                
                       buffer-offset) -> void?
  buffer : (and/c string? (not/c immutable?))
  offset : exact-nonnegative-integer?
  num : exact-nonnegative-integer?
  buffer-offset : exact-nonnegative-integer?
method
(send a-snip is-owned?) -> boolean?
method
(send a-snip match? snip) -> boolean?
  snip : (is-a?/c snip%)
method
(send a-snip merge-with prev) -> (or/c (is-a?/c snip%) #f)
  prev : (is-a?/c snip%)
method
(send a-snip next) -> (or/c (is-a?/c snip%) #f)
method
(send a-snip on-char dc          
                     x           
                     y           
                     editorx     
                     editory     
                     event)  -> void?
  dc : (is-a?/c dc<%>)
  x : real?
  y : real?
  editorx : real?
  editory : real?
  event : (is-a?/c key-event%)
method
(send a-snip on-event dc          
                      x           
                      y           
                      editorx     
                      editory     
                      event)  -> void?
  dc : (is-a?/c dc<%>)
  x : real?
  y : real?
  editorx : real?
  editory : real?
  event : (is-a?/c mouse-event%)
method
(send a-snip on-goodbye-event dc          
                              x           
                              y           
                              editorx     
                              editory     
                              event)  -> void?
  dc : (is-a?/c dc<%>)
  x : real?
  y : real?
  editorx : real?
  editory : real?
  event : (is-a?/c mouse-event%)
method
(send a-snip own-caret own-it?) -> void?
  own-it? : any/c
method
(send a-snip partial-offset dc x y len) -> real?
  dc : (is-a?/c dc<%>)
  x : real?
  y : real?
  len : exact-nonnegative-integer?
method
(send a-snip previous) -> (or/c (is-a?/c snip%) #f)
method
(send a-snip release-from-owner) -> boolean?
method
(send a-snip resize w h) -> boolean?
  w : (and/c real? (not/c negative?))
  h : (and/c real? (not/c negative?))
method
(send a-snip set-admin admin) -> void?
  admin : (or/c (is-a?/c snip-admin%) #f)
method
(send a-snip set-count c) -> void?
  c : (integer-in 1 100000)
method
(send a-snip set-flags flags) -> void?
  flags : (listof symbol?)
method
(send a-snip set-snipclass class) -> void?
  class : (is-a?/c snip-class%)
method
(send a-snip set-style style) -> void?
  style : (is-a?/c style<%>)
method
(send a-snip set-unmodified) -> void?
method
(send a-snip size-cache-invalid) -> void?
method
(send a-snip split position first second) -> void?
  position : exact-nonnegative-integer?
  first : (box/c (is-a?/c snip%))
  second : (box/c (is-a?/c snip%))
method
(send a-snip write f) -> void?
  f : (is-a?/c editor-stream-out%)
class
snip-admin% : class?
  superclass: object%
constructor
(new snip-admin%) -> (is-a?/c snip-admin%)
method
(send a-snip-admin get-dc) -> (or/c (is-a?/c dc<%>) #f)
method
(send a-snip-admin get-editor)
 -> (or/c (is-a?/c text%) (is-a?/c pasteboard%))
method
(send a-snip-admin get-view x y w h [snip]) -> void?
  x : (or/c (box/c real?) #f)
  y : (or/c (box/c real?) #f)
  w : (or/c (box/c (and/c real? (not/c negative?))) #f)
  h : (or/c (box/c (and/c real? (not/c negative?))) #f)
  snip : (or/c (is-a?/c snip%) #f) = #f
method
(send a-snip-admin get-view-size w h) -> void?
  w : (or/c (box/c (and/c real? (not/c negative?))) #f)
  h : (or/c (box/c (and/c real? (not/c negative?))) #f)
method
(send a-snip-admin modified snip modified?) -> void?
  snip : (is-a?/c snip%)
  modified? : any/c
method
(send a-snip-admin needs-update snip       
                                localx     
                                localy     
                                w          
                                h)     -> void?
  snip : (is-a?/c snip%)
  localx : real?
  localy : real?
  w : (and/c real? (not/c negative?))
  h : (and/c real? (not/c negative?))
method
(send a-snip-admin popup-menu menu snip x y) -> boolean?
  menu : (is-a?/c popup-menu%)
  snip : (is-a?/c snip%)
  x : real?
  y : real?
method
(send a-snip-admin recounted snip refresh?) -> void?
  snip : (is-a?/c snip%)
  refresh? : any/c
method
(send a-snip-admin release-snip snip) -> boolean?
  snip : (is-a?/c snip%)
method
(send a-snip-admin resized snip refresh?) -> void?
  snip : (is-a?/c snip%)
  refresh? : any/c
method
(send a-snip-admin scroll-to  snip         
                              localx       
                              localy       
                              w            
                              h            
                              refresh?     
                             [bias])   -> boolean?
  snip : (is-a?/c snip%)
  localx : real?
  localy : real?
  w : (and/c real? (not/c negative?))
  h : (and/c real? (not/c negative?))
  refresh? : any/c
  bias : (or/c 'start 'end 'none) = 'none
method
(send a-snip-admin set-caret-owner snip        
                                   domain) -> void?
  snip : (is-a?/c snip%)
  domain : (or/c 'immediate 'display 'global)
method
(send a-snip-admin update-cursor) -> void?
method
(send a-snip-admin get-line-spacing)
 -> (and/c real? (not/c negative?))
method
(send a-snip-admin get-selected-text-color)
 -> (or/c (is-a?/c color%) #f)
method
(send a-snip-admin call-with-busy-cursor thunk) -> any
  thunk : (-> any)
method
(send a-snip-admin get-tabs [length         
                             tab-width      
                             in-units]) -> (listof real?)
  length : (or/c (box/c exact-nonnegative-integer?) #f) = #f
  tab-width : (or/c (box/c real?) #f) = #f
  in-units : (or/c (box/c any/c) #f) = #f
class
snip-class% : class?
  superclass: object%
constructor
(new snip-class%) -> (is-a?/c snip-class%)
method
(send a-snip-class get-classname) -> string?
method
(send a-snip-class get-version) -> exact-integer?
method
(send a-snip-class read f) -> (or/c (is-a?/c snip%) #f)
  f : (is-a?/c editor-stream-in%)
method
(send a-snip-class read-header f) -> boolean?
  f : (is-a?/c editor-stream-in%)
method
(send a-snip-class reading-version stream) -> exact-integer?
  stream : (is-a?/c editor-stream-in%)
method
(send a-snip-class set-classname name) -> void?
  name : string?
method
(send a-snip-class set-version v) -> void?
  v : exact-integer?
method
(send a-snip-class write-header stream) -> boolean?
  stream : (is-a?/c editor-stream-out%)
interface
snip-class-list<%> : interface?
method
(send a-snip-class-list add snipclass) -> void?
  snipclass : (is-a?/c snip-class%)
method
(send a-snip-class-list find name)
 -> (or/c (is-a?/c snip-class%) #f)
  name : string?
method
(send a-snip-class-list find-position class)
 -> exact-nonnegative-integer?
  class : (is-a?/c snip-class%)
method
(send a-snip-class-list nth n)
 -> (or/c (is-a?/c snip-class%) #f)
  n : exact-nonnegative-integer?
method
(send a-snip-class-list number) -> exact-nonnegative-integer?
class
string-snip% : class?
  superclass: snip%
constructor
(make-object string-snip% [allocsize]) -> (is-a?/c string-snip%)
  allocsize : exact-nonnegative-integer? = 0
(make-object string-snip% s) -> (is-a?/c string-snip%)
  s : string?
method
(send a-string-snip insert s len [pos]) -> void?
  s : string?
  len : exact-nonnegative-integer?
  pos : exact-nonnegative-integer? = 0
method
(send a-string-snip read len f) -> void?
  len : exact-nonnegative-integer?
  f : (is-a?/c editor-stream-in%)
interface
style<%> : interface?
method
(send a-style get-alignment) -> (or/c 'top 'center 'bottom)
method
(send a-style get-background) -> (is-a?/c color%)
method
(send a-style get-base-style) -> (or/c (is-a?/c style<%>) #f)
method
(send a-style get-delta delta) -> void?
  delta : (is-a?/c style-delta%)
method
(send a-style get-face) -> (or/c string? #f)
method
(send a-style get-family)
 -> (or/c 'default 'decorative 'roman 'script
          'swiss 'modern 'symbol 'system)
method
(send a-style get-font) -> (is-a?/c font%)
method
(send a-style get-foreground) -> (is-a?/c color%)
method
(send a-style get-name) -> (or/c string? #f)
method
(send a-style get-shift-style) -> (is-a?/c style<%>)
method
(send a-style get-size) -> byte?
method
(send a-style get-size-in-pixels) -> boolean?
method
(send a-style get-smoothing)
 -> (or/c 'default 'partly-smoothed 'smoothed 'unsmoothed)
method
(send a-style get-style) -> (or/c 'normal 'italic 'slant)
method
(send a-style get-text-descent dc)
 -> (and/c real? (not/c negative?))
  dc : (is-a?/c dc<%>)
method
(send a-style get-text-height dc)
 -> (and/c real? (not/c negative?))
  dc : (is-a?/c dc<%>)
method
(send a-style get-text-space dc)
 -> (and/c real? (not/c negative?))
  dc : (is-a?/c dc<%>)
method
(send a-style get-text-width dc)
 -> (and/c real? (not/c negative?))
  dc : (is-a?/c dc<%>)
method
(send a-style get-transparent-text-backing) -> boolean?
method
(send a-style get-underlined) -> boolean?
method
(send a-style get-weight) -> (or/c 'normal 'bold 'light)
method
(send a-style is-join?) -> boolean?
method
(send a-style set-base-style base-style) -> void?
  base-style : (is-a?/c style<%>)
method
(send a-style set-delta delta) -> void?
  delta : (is-a?/c style-delta%)
method
(send a-style set-shift-style style) -> void?
  style : (is-a?/c style<%>)
method
(send a-style switch-to dc old-style) -> void?
  dc : (is-a?/c dc<%>)
  old-style : (or/c (is-a?/c style<%>) #f)
class
style-delta% : class?
  superclass: object%
constructor
(make-object style-delta% [change-command])
 -> (is-a?/c style-delta%)
  change-command : (or/c 'change-nothing
                         'change-normal
                         'change-toggle-underline
                         'change-toggle-size-in-pixels
                         'change-normal-color
                         'change-bold)
                 = 'change-nothing
(make-object style-delta% change-command v)
 -> (is-a?/c style-delta%)
  change-command : (or/c 'change-family
                         'change-style
                         'change-toggle-style
                         'change-weight
                         'change-toggle-weight
                         'change-smoothing
                         'change-toggle-smoothing
                         'change-alignment)
  v : symbol
(make-object style-delta% change-command v)
 -> (is-a?/c style-delta%)
  change-command : (or/c 'change-size
                         'change-bigger
                         'change-smaller)
  v : byte?
(make-object style-delta% change-command v)
 -> (is-a?/c style-delta%)
  change-command : (or/c 'change-underline
                         'change-size-in-pixels)
  v : any/c
method
(send a-style-delta collapse delta) -> boolean?
  delta : (is-a?/c style-delta%)
method
(send a-style-delta copy delta) -> void?
  delta : (is-a?/c style-delta%)
method
(send a-style-delta equal? delta) -> boolean?
  delta : (is-a?/c style-delta%)
method
(send a-style-delta get-alignment-off)
 -> (or/c 'base 'top 'center 'bottom)
method
(send a-style-delta get-alignment-on)
 -> (or/c 'base 'top 'center 'bottom)
method
(send a-style-delta get-background-add)
 -> (is-a?/c add-color<%>)
method
(send a-style-delta get-background-mult)
 -> (is-a?/c mult-color<%>)
method
(send a-style-delta get-face) -> (or/c string? #f)
method
(send a-style-delta get-family)
 -> (or/c 'base 'default 'decorative 'roman 'script
          'swiss 'modern 'symbol 'system)
method
(send a-style-delta get-foreground-add)
 -> (is-a?/c add-color<%>)
method
(send a-style-delta get-foreground-mult)
 -> (is-a?/c mult-color<%>)
method
(send a-style-delta get-size-add) -> byte?
method
(send a-style-delta get-size-in-pixels-off) -> boolean?
method
(send a-style-delta get-size-in-pixels-on) -> boolean?
method
(send a-style-delta get-size-mult) -> real?
method
(send a-style-delta get-smoothing-off)
 -> (or/c 'base 'default 'partly-smoothed 'smoothed 'unsmoothed)
method
(send a-style-delta get-smoothing-on)
 -> (or/c 'base 'default 'partly-smoothed 'smoothed 'unsmoothed)
method
(send a-style-delta get-style-off)
 -> (or/c 'base 'normal 'italic 'slant)
method
(send a-style-delta get-style-on)
 -> (or/c 'base 'normal 'italic 'slant)
method
(send a-style-delta get-transparent-text-backing-off)
 -> boolean?
method
(send a-style-delta get-transparent-text-backing-on)
 -> boolean?
method
(send a-style-delta get-underlined-off) -> boolean?
method
(send a-style-delta get-underlined-on) -> boolean?
method
(send a-style-delta get-weight-off)
 -> (or/c 'base 'normal 'bold 'light)
method
(send a-style-delta get-weight-on)
 -> (or/c 'base 'normal 'bold 'light)
method
(send a-style-delta set-alignment-off v) -> void?
  v : (or/c 'base 'top 'center 'bottom)
method
(send a-style-delta set-alignment-on v) -> void?
  v : (or/c 'base 'top 'center 'bottom)
method
(send a-style-delta set-delta [change-command])
 -> (is-a?/c style-delta%)
  change-command : (or/c 'change-nothing
                         'change-normal
                         'change-toggle-underline
                         'change-toggle-size-in-pixels
                         'change-normal-color
                         'change-bold)
                 = 'change-nothing
(send a-style-delta set-delta change-command 
                              param)         
 -> (is-a?/c style-delta%)
  change-command : (or/c 'change-family
                         'change-style
                         'change-toggle-style
                         'change-weight
                         'change-toggle-weight
                         'change-smoothing
                         'change-toggle-smoothing
                         'change-alignment)
  param : symbol?
(send a-style-delta set-delta change-command 
                              param)         
 -> (is-a?/c style-delta%)
  change-command : (or/c 'change-size
                         'change-bigger
                         'change-smaller)
  param : byte?
(send a-style-delta set-delta change-command 
                              on?)           
 -> (is-a?/c style-delta%)
  change-command : (or/c 'change-underline
                         'change-size-in-pixels)
  on? : any/c
method
(send a-style-delta set-delta-background name)
 -> (is-a?/c style-delta%)
  name : string?
(send a-style-delta set-delta-background color)
 -> (is-a?/c style-delta%)
  color : (is-a?/c color%)
method
(send a-style-delta set-delta-face  name     
                                   [family]) 
 -> (is-a?/c style-delta%)
  name : string?
  family : (or/c 'base 'default 'decorative 'roman
                 'script 'swiss 'modern 'symbol 'system)
         = 'default
method
(send a-style-delta set-delta-foreground name)
 -> (is-a?/c style-delta%)
  name : string?
(send a-style-delta set-delta-foreground color)
 -> (is-a?/c style-delta%)
  color : (is-a?/c color%)
method
(send a-style-delta set-face v) -> void?
  v : (or/c string? #f)
method
(send a-style-delta set-family v) -> void?
  v : (or/c 'base 'default 'decorative 'roman 'script
            'swiss 'modern 'symbol 'system)
method
(send a-style-delta set-size-add v) -> void?
  v : byte?
method
(send a-style-delta set-size-in-pixels-off v) -> void?
  v : any/c
method
(send a-style-delta set-size-in-pixels-on v) -> void?
  v : any/c
method
(send a-style-delta set-size-mult v) -> void?
  v : real?
method
(send a-style-delta set-smoothing-off v) -> void?
  v : (or/c 'base 'default 'partly-smoothed
            'smoothed 'unsmoothed)
method
(send a-style-delta set-smoothing-on v) -> void?
  v : (or/c 'base 'default 'partly-smoothed
            'smoothed 'unsmoothed)
method
(send a-style-delta set-style-off v) -> void?
  v : (or/c 'base 'normal 'italic 'slant)
method
(send a-style-delta set-style-on v) -> void?
  v : (or/c 'base 'normal 'italic 'slant)
method
(send a-style-delta set-transparent-text-backing-off v) -> void?
  v : any/c
method
(send a-style-delta set-transparent-text-backing-on v) -> void?
  v : any/c
method
(send a-style-delta set-underlined-off v) -> void?
  v : any/c
method
(send a-style-delta set-underlined-on v) -> void?
  v : any/c
method
(send a-style-delta set-weight-off v) -> void?
  v : (or/c 'base 'normal 'bold 'light)
method
(send a-style-delta set-weight-on v) -> void?
  v : (or/c 'base 'normal 'bold 'light)
class
style-list% : class?
  superclass: object%
constructor
(new style-list%) -> (is-a?/c style-list%)
method
(send a-style-list basic-style) -> (is-a?/c style<%>)
method
(send a-style-list convert style) -> (is-a?/c style<%>)
  style : (is-a?/c style<%>)
method
(send a-style-list find-named-style name)
 -> (or/c (is-a?/c style<%>) #f)
  name : string?
method
(send a-style-list find-or-create-join-style base-style   
                                             shift-style) 
 -> (is-a?/c style<%>)
  base-style : (is-a?/c style<%>)
  shift-style : (is-a?/c style<%>)
method
(send a-style-list find-or-create-style base-style 
                                        delta)     
 -> (is-a?/c style<%>)
  base-style : (is-a?/c style<%>)
  delta : (is-a?/c style-delta%)
method
(send a-style-list forget-notification key) -> void?
  key : any/c
method
(send a-style-list index-to-style i)
 -> (or/c (is-a?/c style<%>) #f)
  i : exact-nonnegative-integer?
method
(send a-style-list new-named-style name        
                                   like-style) 
 -> (is-a?/c style<%>)
  name : string?
  like-style : (is-a?/c style<%>)
method
(send a-style-list notify-on-change f) -> any/c
  f : ((or/c (is-a?/c style<%>) #f) . -> . any)
method
(send a-style-list number) -> exact-nonnegative-integer?
method
(send a-style-list replace-named-style name        
                                       like-style) 
 -> (is-a?/c style<%>)
  name : string?
  like-style : (is-a?/c style<%>)
method
(send a-style-list style-to-index style)
 -> (or/c exact-nonnegative-integer? #f)
  style : (is-a?/c style<%>)
class
tab-snip% : class?
  superclass: string-snip%
constructor
(new tab-snip%) -> (is-a?/c tab-snip%)
interface
editor<%> : interface?
method
(send an-editor add-canvas canvas) -> void?
  canvas : (is-a?/c editor-canvas%)
method
(send an-editor add-undo undoer) -> void?
  undoer : (-> any)
method
(send an-editor adjust-cursor event)
 -> (or/c (is-a?/c cursor%) #f)
  event : (is-a?/c mouse-event%)
method
(send an-editor after-edit-sequence) -> void?
method
(send an-editor after-load-file success?) -> void?
  success? : any/c
method
(send an-editor after-save-file success?) -> void?
  success? : any/c
method
(send an-editor auto-wrap) -> boolean?
(send an-editor auto-wrap auto-wrap?) -> void?
  auto-wrap? : any/c
method
(send an-editor begin-edit-sequence [undoable?               
                                     interrupt-streak?]) -> void?
  undoable? : any/c = #t
  interrupt-streak? : any/c = #t
method
(send an-editor begin-write-header-footer-to-file f       
                                                  name    
                                                  buffer) 
 -> void?
  f : (is-a?/c editor-stream-out%)
  name : string?
  buffer : (box/c exact-integer?)
method
(send an-editor blink-caret) -> void?
method
(send an-editor can-do-edit-operation?  op               
                                       [recursive?]) -> boolean?
  op : (or/c 'undo 'redo 'clear 'cut 'copy 'paste
             'kill 'select-all 'insert-text-box
             'insert-pasteboard-box 'insert-image)
  recursive? : any/c = #t
method
(send an-editor can-load-file? filename     
                               format)  -> boolean?
  filename : path?
  format : (or/c 'guess 'same 'copy 'standard
                 'text 'text-force-cr)
method
(send an-editor can-save-file? filename     
                               format)  -> boolean?
  filename : path?
  format : (or/c 'guess 'same 'copy 'standard
                 'text 'text-force-cr)
method
(send an-editor clear) -> void?
method
(send an-editor clear-undos) -> void?
method
(send an-editor copy [extend? time]) -> void?
  extend? : any/c = #f
  time : exact-integer? = 0
method
(send an-editor copy-self)
 -> (or/c (is-a?/c text%) (is-a?/c pasteboard%))
method
(send an-editor copy-self-to dest) -> void?
  dest : (or/c (is-a?/c text%) (is-a?/c pasteboard%))
method
(send an-editor cut [extend? time]) -> void?
  extend? : any/c = #f
  time : exact-integer? = 0
method
(send an-editor dc-location-to-editor-location x      
                                               y) -> real? real?
  x : real?
  y : real?
method
(send an-editor default-style-name) -> string?
method
(send an-editor do-edit-operation  op             
                                  [recursive?     
                                   time])     -> void?
  op : (or/c 'undo 'redo 'clear 'cut 'copy 'paste
             'kill 'select-all 'insert-text-box
             'insert-pasteboard-box 'insert-image)
  recursive? : any/c = #t
  time : exact-integer? = 0
method
(send an-editor editor-location-to-dc-location x      
                                               y) -> real? real?
  x : real?
  y : real?
method
(send an-editor end-edit-sequence) -> void?
method
(send an-editor end-write-header-footer-to-file f             
                                                buffer-value) 
 -> void?
  f : (is-a?/c editor-stream-out%)
  buffer-value : exact-integer?
method
(send an-editor find-first-snip) -> (or/c (is-a?/c snip%) #f)
method
(send an-editor find-scroll-line location)
 -> exact-nonnegative-integer?
  location : real?
method
(send an-editor get-active-canvas)
 -> (or/c (is-a?/c editor-canvas%) #f)
method
(send an-editor get-admin) -> (or/c (is-a?/c editor-admin%) #f)
method
(send an-editor get-canvas)
 -> (or/c (is-a?/c editor-canvas%) #f)
method
(send an-editor get-canvases)
 -> (listof (is-a?/c editor-canvas%))
method
(send an-editor get-dc) -> (or/c (is-a?/c dc<%>) #f)
method
(send an-editor get-descent) -> (and/c real? (not/c negative?))
method
(send an-editor get-extent w h) -> void?
  w : (or/c (box/c (and/c real? (not/c negative?))) #f)
  h : (or/c (box/c (and/c real? (not/c negative?))) #f)
method
(send an-editor get-file directory) -> (or/c path-string? #f)
  directory : (or/c path? #f)
method
(send an-editor get-filename [temp]) -> (or/c path-string? #f)
  temp : (or/c (box/c any/c) #f) = #f
method
(send an-editor get-flattened-text) -> string?
method
(send an-editor get-focus-snip) -> (or/c (is-a?/c snip%) #f)
method
(send an-editor get-inactive-caret-threshold)
 -> (or/c 'no-caret 'show-inactive-caret 'show-caret)
method
(send an-editor get-keymap) -> (or/c (is-a?/c keymap%) #f)
method
(send an-editor get-load-overwrites-styles) -> boolean?
method
(send an-editor get-max-height)
 -> (or/c (and/c real? (not/c negative?)) 'none)
method
(send an-editor get-max-undo-history)
 -> (or/c (integer-in 0 100000) 'forever)
method
(send an-editor get-max-view-size) -> real? real?
method
(send an-editor get-max-width)
 -> (or/c (and/c real? (not/c negative?)) 'none)
method
(send an-editor get-min-height)
 -> (or/c (and/c real? (not/c negative?)) 'none)
method
(send an-editor get-min-width)
 -> (or/c (and/c real? (not/c negative?)) 'none)
method
(send an-editor get-paste-text-only) -> boolean?
method
(send an-editor get-snip-data thesnip)
 -> (or/c (is-a?/c editor-data%) #f)
  thesnip : (is-a?/c snip%)
method
(send an-editor get-snip-location  thesnip             
                                  [x                   
                                   y                   
                                   bottom-right?]) -> boolean?
  thesnip : (is-a?/c snip%)
  x : (or/c (box/c real?) #f) = #f
  y : (or/c (box/c real?) #f) = #f
  bottom-right? : any/c = #f
method
(send an-editor get-space) -> (and/c real? (not/c negative?))
method
(send an-editor get-style-list) -> (is-a?/c style-list%)
method
(send an-editor get-view-size w h) -> void?
  w : (or/c (box/c (and/c real? (not/c negative?))) #f)
  h : (or/c (box/c (and/c real? (not/c negative?))) #f)
method
(send an-editor global-to-local x y) -> void?
  x : (or/c (box/c real?) #f)
  y : (or/c (box/c real?) #f)
method
(send an-editor in-edit-sequence?) -> boolean?
method
(send an-editor insert snip) -> void?
  snip : (is-a?/c snip%)
method
(send an-editor insert-box [type]) -> void?
  type : (or/c 'text 'pasteboard) = 'text
method
(send an-editor insert-file  filename           
                            [format             
                             show-errors?]) -> boolean?
  filename : path-string?
  format : (or/c 'guess 'same 'copy 'standard = 'guess
                 'text 'text-force-cr)
  show-errors? : any/c = #t
method
(send an-editor insert-image [filename           
                              type               
                              relative-path?     
                              inline?])      -> void?
  filename : (or/c path-string? #f) = #f
  type : (or/c 'unknown 'unknown/mask 'unknown/alpha
               'gif 'gif/mask 'gif/alpha
               'jpeg 'png 'png/mask 'png/alpha
               'xbm 'xpm 'bmp 'pict)
       = 'unknown/alpha
  relative-path? : any/c = #f
  inline? : any/c = #t
method
(send an-editor insert-port  port              
                            [format            
                             replace-styles?]) 
 -> (or/c 'standard 'text 'text-force-cr)
  port : input-port?
  format : (or/c 'guess 'same 'copy 'standard = 'guess
                 'text 'text-force-cr)
  replace-styles? : any/c = #t
method
(send an-editor invalidate-bitmap-cache [x            
                                         y            
                                         width        
                                         height]) -> void?
  x : real? = 0.0
  y : real? = 0.0
  width : (or/c (and/c real? (not/c negative?)) 'end 'display-end)
        = 'end
  height : (or/c (and/c real? (not/c negative?)) 'end 'display-end)
         = 'end
method
(send an-editor is-locked?) -> boolean?
method
(send an-editor is-modified?) -> boolean?
method
(send an-editor is-printing?) -> boolean?
method
(send an-editor kill [time]) -> void?
  time : exact-integer? = 0
method
(send an-editor load-file [filename           
                           format             
                           show-errors?]) -> boolean?
  filename : (or/c path-string? #f) = #f
  format : (or/c 'guess 'same 'copy 'standard = 'guess
                 'text 'text-force-cr)
  show-errors? : any/c = #t
method
(send an-editor local-to-global x y) -> void?
  x : (or/c (box/c real?) #f)
  y : (or/c (box/c real?) #f)
method
(send an-editor locations-computed?) -> boolean?
method
(send an-editor lock lock?) -> void?
  lock? : any/c
method
(send an-editor locked-for-flow?) -> boolean?
method
(send an-editor locked-for-read?) -> boolean?
method
(send an-editor locked-for-write?) -> boolean?
method
(send an-editor needs-update snip       
                             localx     
                             localy     
                             w          
                             h)     -> void?
  snip : (is-a?/c snip%)
  localx : real?
  localy : real?
  w : (and/c real? (not/c negative?))
  h : (and/c real? (not/c negative?))
method
(send an-editor num-scroll-lines) -> exact-nonnegative-integer?
method
(send an-editor on-change) -> void?
method
(send an-editor on-char event) -> void?
  event : (is-a?/c key-event%)
method
(send an-editor on-default-char event) -> void?
  event : (is-a?/c key-event%)
method
(send an-editor on-default-event event) -> void?
  event : (is-a?/c mouse-event%)
method
(send an-editor on-display-size) -> void?
method
(send an-editor on-display-size-when-ready) -> void?
method
(send an-editor on-edit-sequence) -> void?
method
(send an-editor on-event event) -> void?
  event : (is-a?/c mouse-event%)
method
(send an-editor on-focus on?) -> void?
  on? : any/c
method
(send an-editor on-load-file filename     
                             format)  -> void?
  filename : path?
  format : (or/c 'guess 'same 'copy 'standard
                 'text 'text-force-cr)
method
(send an-editor on-local-char event) -> void?
  event : (is-a?/c key-event%)
method
(send an-editor on-local-event event) -> void?
  event : (is-a?/c mouse-event%)
method
(send an-editor on-new-box type) -> (is-a?/c snip%)
  type : (or/c 'text 'pasteboard)
method
(send an-editor on-new-image-snip filename       
                                  kind           
                                  relative-path? 
                                  inline?)       
 -> (is-a?/c image-snip%)
  filename : path?
  kind : (or/c 'unknown 'unknown/mask 'unknown/alpha
               'gif 'gif/mask 'gif/alpha
               'jpeg 'png 'png/mask 'png/alpha
               'xbm 'xpm 'bmp 'pict)
  relative-path? : any/c
  inline? : any/c
method
(send an-editor on-paint before?         
                         dc              
                         left            
                         top             
                         right           
                         bottom          
                         dx              
                         dy              
                         draw-caret) -> void?
  before? : any/c
  dc : (is-a?/c dc<%>)
  left : real?
  top : real?
  right : real?
  bottom : real?
  dx : real?
  dy : real?
  draw-caret : (or/c 'no-caret 'show-inactive-caret 'show-caret
                     (cons/c exact-nonnegative-integer?
                             exact-nonnegative-integer?))
method
(send an-editor on-save-file filename     
                             format)  -> void?
  filename : path?
  format : (or/c 'guess 'same 'copy 'standard
                 'text 'text-force-cr)
method
(send an-editor on-snip-modified snip           
                                 modified?) -> void?
  snip : (is-a?/c snip%)
  modified? : any/c
method
(send an-editor own-caret own?) -> void?
  own? : any/c
method
(send an-editor paste [time]) -> void?
  time : exact-integer? = 0
method
(send an-editor paste-x-selection [time]) -> void?
  time : exact-integer? = 0
method
(send an-editor print [interactive?            
                       fit-on-page?            
                       output-mode             
                       parent                  
                       force-ps-page-bbox?     
                       as-eps?])           -> void?
  interactive? : any/c = #t
  fit-on-page? : any/c = #t
  output-mode : (or/c 'standard 'postscript 'pdf) = 'standard
  parent : (or/c (or/c (is-a?/c frame%) (is-a?/c dialog%)) #f)
         = #f
  force-ps-page-bbox? : any/c = #t
  as-eps? : any/c = #f
method
(send an-editor print-to-dc dc [page-number]) -> void?
  dc : (is-a?/c dc<%>)
  page-number : exact-integer? = -1
method
(send an-editor put-file directory         
                         default-name) -> (or/c path-string? #f)
  directory : (or/c path? #f)
  default-name : (or/c path? #f)
method
(send an-editor read-footer-from-file stream     
                                      name)  -> boolean?
  stream : (is-a?/c editor-stream-in%)
  name : string?
method
(send an-editor read-from-file  stream                  
                               [overwrite-styles?]) -> boolean?
  stream : (is-a?/c editor-stream-in%)
  overwrite-styles? : any/c = #f
method
(send an-editor read-header-from-file stream     
                                      name)  -> boolean?
  stream : (is-a?/c editor-stream-in%)
  name : string?
method
(send an-editor redo) -> void?
method
(send an-editor refresh x               
                        y               
                        width           
                        height          
                        draw-caret      
                        background) -> void?
  x : real?
  y : real?
  width : (and/c real? (not/c negative?))
  height : (and/c real? (not/c negative?))
  draw-caret : (or/c 'no-caret 'show-inactive-caret 'show-caret
                     (cons/c exact-nonnegative-integer?
                             exact-nonnegative-integer?))
  background : (or/c (is-a?/c color%) #f)
method
(send an-editor refresh-delayed?) -> boolean?
method
(send an-editor release-snip snip) -> boolean?
  snip : (is-a?/c snip%)
method
(send an-editor remove-canvas canvas) -> void?
  canvas : (is-a?/c editor-canvas%)
method
(send an-editor resized snip redraw-now?) -> void?
  snip : (is-a?/c snip%)
  redraw-now? : any/c
method
(send an-editor save-file [filename           
                           format             
                           show-errors?]) -> boolean?
  filename : (or/c path-string? #f) = #f
  format : (or/c 'guess 'same 'copy 'standard = 'same
                 'text 'text-force-cr)
  show-errors? : any/c = #t
method
(send an-editor save-port  port               
                          [format             
                           show-errors?]) -> boolean?
  port : output-port?
  format : (or/c 'guess 'same 'copy 'standard = 'same
                 'text 'text-force-cr)
  show-errors? : any/c = #t
method
(send an-editor scroll-editor-to localx       
                                 localy       
                                 width        
                                 height       
                                 refresh?     
                                 bias)    -> boolean?
  localx : real?
  localy : real?
  width : (and/c real? (not/c negative?))
  height : (and/c real? (not/c negative?))
  refresh? : any/c
  bias : (or/c 'start 'end 'none)
method
(send an-editor scroll-line-location pos)
 -> (and/c real? (not/c negative?))
  pos : exact-nonnegative-integer?
method
(send an-editor scroll-to  snip         
                           localx       
                           localy       
                           width        
                           height       
                           refresh?     
                          [bias])   -> boolean?
  snip : (is-a?/c snip%)
  localx : real?
  localy : real?
  width : (and/c real? (not/c negative?))
  height : (and/c real? (not/c negative?))
  refresh? : any/c
  bias : (or/c 'start 'end 'none) = 'none
method
(send an-editor select-all) -> void?
method
(send an-editor set-active-canvas canvas) -> void?
  canvas : (is-a?/c editor-canvas%)
method
(send an-editor set-admin admin) -> void?
  admin : (or/c (is-a?/c editor-admin%) #f)
method
(send an-editor set-caret-owner  snip         
                                [domain]) -> void?
  snip : (or/c (is-a?/c snip%) #f)
  domain : (or/c 'immediate 'display 'global) = 'immediate
method
(send an-editor set-cursor  cursor          
                           [override?]) -> void?
  cursor : (or/c (is-a?/c cursor%) #f)
  override? : any/c = #t
method
(send an-editor set-filename  filename         
                             [temporary?]) -> void?
  filename : (or/c path-string? #f)
  temporary? : any/c = #f
method
(send an-editor set-inactive-caret-threshold threshold) -> void?
  threshold : (or/c 'no-caret 'show-inactive-caret 'show-caret)
method
(send an-editor set-keymap [keymap]) -> void?
  keymap : (or/c (is-a?/c keymap%) #f) = #f
method
(send an-editor set-load-overwrites-styles overwrite?) -> void?
  overwrite? : any/c
method
(send an-editor set-max-height width) -> void?
  width : (or/c (and/c real? (not/c negative?)) 'none)
method
(send an-editor set-max-undo-history count) -> void?
  count : (or/c exact-nonnegative-integer? 'forever)
method
(send an-editor set-max-width width) -> void?
  width : (or/c (and/c real? (not/c negative?)) 'none)
method
(send an-editor set-min-height width) -> void?
  width : (or/c (and/c real? (not/c negative?)) 'none)
method
(send an-editor set-min-width width) -> void?
  width : (or/c (and/c real? (not/c negative?)) 'none)
method
(send an-editor set-modified modified?) -> void?
  modified? : any/c
method
(send an-editor set-paste-text-only text-only?) -> void?
  text-only? : any/c
method
(send an-editor set-snip-data thesnip data) -> void?
  thesnip : (is-a?/c snip%)
  data : (is-a?/c editor-data%)
method
(send an-editor set-style-list style-list) -> void?
  style-list : (is-a?/c style-list%)
method
(send an-editor set-undo-preserves-all-history on?) -> void?
  on? : any/c
method
(send an-editor size-cache-invalid) -> void?
method
(send an-editor style-has-changed style) -> void?
  style : (or/c (is-a?/c style<%>) #f)
method
(send an-editor undo) -> void?
method
(send an-editor undo-preserves-all-history?) -> boolean?
method
(send an-editor use-file-text-mode) -> boolean?
(send an-editor use-file-text-mode on?) -> void?
  on? : any/c
method
(send an-editor write-footers-to-file stream) -> boolean?
  stream : (is-a?/c editor-stream-out%)
method
(send an-editor write-headers-to-file stream) -> boolean?
  stream : (is-a?/c editor-stream-out%)
method
(send an-editor write-to-file stream) -> boolean?
  stream : (is-a?/c editor-stream-out%)
class
editor-admin% : class?
  superclass: object%
constructor
(new editor-admin%) -> (is-a?/c editor-admin%)
method
(send an-editor-admin get-dc [x y]) -> (or/c (is-a?/c dc<%>) #f)
  x : (or/c (box/c real?) #f) = #f
  y : (or/c (box/c real?) #f) = #f
method
(send an-editor-admin get-max-view  x           
                                    y           
                                    w           
                                    h           
                                   [full?]) -> void?
  x : (or/c (box/c real?) #f)
  y : (or/c (box/c real?) #f)
  w : (or/c (box/c (and/c real? (not/c negative?))) #f)
  h : (or/c (box/c (and/c real? (not/c negative?))) #f)
  full? : any/c = #f
method
(send an-editor-admin get-view x y w h [full?]) -> void?
  x : (or/c (box/c real?) #f)
  y : (or/c (box/c real?) #f)
  w : (or/c (box/c (and/c real? (not/c negative?))) #f)
  h : (or/c (box/c (and/c real? (not/c negative?))) #f)
  full? : any/c = #f
method
(send an-editor-admin grab-caret [domain]) -> void?
  domain : (or/c 'immediate 'display 'global) = 'global
method
(send an-editor-admin modified modified?) -> void?
  modified? : any/c
method
(send an-editor-admin needs-update localx     
                                   localy     
                                   w          
                                   h)     -> void?
  localx : real?
  localy : real?
  w : (and/c real? (not/c negative?))
  h : (and/c real? (not/c negative?))
method
(send an-editor-admin popup-menu menu x y) -> boolean?
  menu : (is-a?/c popup-menu%)
  x : real?
  y : real?
method
(send an-editor-admin refresh-delayed?) -> boolean?
method
(send an-editor-admin resized refresh?) -> void?
  refresh? : any/c
method
(send an-editor-admin scroll-to  localx       
                                 localy       
                                 w            
                                 h            
                                [refresh?     
                                 bias])   -> boolean?
  localx : real?
  localy : real?
  w : (and/c real? (not/c negative?))
  h : (and/c real? (not/c negative?))
  refresh? : any/c = #t
  bias : (or/c 'start 'end 'none) = 'none
method
(send an-editor-admin update-cursor) -> void?
class
editor-canvas% : class?
  superclass: object%
  extends: canvas<%>
constructor
(new editor-canvas%                                            
                     [parent parent]                           
                    [[editor editor]                           
                     [style style]                             
                     [scrolls-per-page scrolls-per-page]       
                     [label label]                             
                     [wheel-step wheel-step]                   
                     [line-count line-count]                   
                     [horizontal-inset horizontal-inset]       
                     [vertical-inset vertical-inset]           
                     [enabled enabled]                         
                     [vert-margin vert-margin]                 
                     [horiz-margin horiz-margin]               
                     [min-width min-width]                     
                     [min-height min-height]                   
                     [stretchable-width stretchable-width]     
                     [stretchable-height stretchable-height]]) 
 -> (is-a?/c editor-canvas%)
  parent : (or/c (is-a?/c frame%) (is-a?/c dialog%)
                 (is-a?/c panel%) (is-a?/c pane%))
  editor : (or/c (or/c (is-a?/c text%) (is-a?/c pasteboard%)) #f)
         = #f
  style : (listof (or/c 'no-border 'control-border 'combo = null
                        'no-hscroll 'no-vscroll
                        'hide-hscroll 'hide-vscroll
                        'auto-vscroll 'auto-hscroll
                        'resize-corner 'no-focus 'deleted
                        'transparent))
  scrolls-per-page : (integer-in 1 10000) = 100
  label : (or/c label-string? #f) = #f
  wheel-step : (or/c (integer-in 1 10000) #f) = 3
  line-count : (or/c (integer-in 1 1000) #f) = #f
  horizontal-inset : spacing-integer? = 5
  vertical-inset : spacing-integer? = 5
  enabled : any/c = #t
  vert-margin : spacing-integer? = 0
  horiz-margin : spacing-integer? = 0
  min-width : (or/c dimension-integer? #f) = #f
  min-height : (or/c dimension-integer? #f) = #f
  stretchable-width : any/c = #t
  stretchable-height : any/c = #t
method
(send an-editor-canvas allow-scroll-to-last) -> boolean?
(send an-editor-canvas allow-scroll-to-last on?) -> void?
  on? : any/c
method
(send an-editor-canvas allow-tab-exit) -> boolean?
(send an-editor-canvas allow-tab-exit on?) -> void?
  on? : any/c
method
(send an-editor-canvas call-as-primary-owner f) -> any
  f : (-> any)
method
(send an-editor-canvas force-display-focus) -> boolean?
(send an-editor-canvas force-display-focus on?) -> void?
  on? : any/c
method
(send an-editor-canvas get-editor)
 -> (or/c (or/c (is-a?/c text%) (is-a?/c pasteboard%)) #f)
method
(send an-editor-canvas get-line-count)
 -> (or/c (integer-in 1 1000) #f)
method
(send an-editor-canvas horizontal-inset)
 -> (integer-in 1 10000)
(send an-editor-canvas horizontal-inset step) -> void?
  step : (integer-in 1 10000)
method
(send an-editor-canvas lazy-refresh) -> boolean?
(send an-editor-canvas lazy-refresh on?) -> void?
  on? : any/c
method
(send an-editor-canvas on-char event) -> void?
  event : (is-a?/c key-event%)
method
(send an-editor-canvas on-event event) -> void?
  event : (is-a?/c mouse-event%)
method
(send an-editor-canvas on-focus on?) -> void?
  on? : any/c
method
(send an-editor-canvas on-paint) -> void?
method
(send an-editor-canvas on-size width       
                               height) -> void?
  width : dimension-integer?
  height : dimension-integer?
method
(send an-editor-canvas scroll-to  localx       
                                  localy       
                                  w            
                                  h            
                                  refresh?     
                                 [bias])   -> boolean?
  localx : real?
  localy : real?
  w : (and/c real? (not/c negative?))
  h : (and/c real? (not/c negative?))
  refresh? : any/c
  bias : (or/c 'start 'end 'none) = 'none
method
(send an-editor-canvas scroll-with-bottom-base) -> boolean?
(send an-editor-canvas scroll-with-bottom-base on?) -> void?
  on? : any/c
method
(send an-editor-canvas set-editor  edit          
                                  [redraw?]) -> void?
  edit : (or/c (or/c (is-a?/c text%) (is-a?/c pasteboard%)) #f)
  redraw? : any/c = #t
method
(send an-editor-canvas set-line-count count) -> void?
  count : (or/c (integer-in 1 1000) #f)
method
(send an-editor-canvas vertical-inset) -> (integer-in 1 10000)
(send an-editor-canvas vertical-inset step) -> void?
  step : (integer-in 1 10000)
method
(send an-editor-canvas wheel-step)
 -> (or/c (integer-in 1 10000) #f)
(send an-editor-canvas wheel-step step) -> void?
  step : (or/c (integer-in 1 10000) #f)
class
editor-data% : class?
  superclass: object%
constructor
(new editor-data%) -> (is-a?/c editor-data%)
method
(send an-editor-data get-dataclass)
 -> (or/c (is-a?/c editor-data-class%) #f)
method
(send an-editor-data get-next)
 -> (or/c (is-a?/c editor-data%) #f)
method
(send an-editor-data set-dataclass v) -> void?
  v : (is-a?/c editor-data-class%)
method
(send an-editor-data set-next v) -> void?
  v : (or/c (is-a?/c editor-data%) #f)
method
(send an-editor-data write f) -> boolean?
  f : (is-a?/c editor-stream-out%)
class
editor-data-class% : class?
  superclass: object%
constructor
(new editor-data-class%) -> (is-a?/c editor-data-class%)
method
(send an-editor-data-class get-classname) -> string?
method
(send an-editor-data-class read f)
 -> (or/c (is-a?/c editor-data%) #f)
  f : (is-a?/c editor-stream-in%)
method
(send an-editor-data-class set-classname v) -> void?
  v : string?
interface
editor-data-class-list<%> : interface?
method
(send an-editor-data-class-list add snipclass) -> void?
  snipclass : (is-a?/c editor-data-class%)
method
(send an-editor-data-class-list find name)
 -> (or/c (is-a?/c snip-class%) #f)
  name : string?
method
(send an-editor-data-class-list find-position class)
 -> exact-nonnegative-integer?
  class : (is-a?/c editor-data-class%)
method
(send an-editor-data-class-list nth n)
 -> (or/c (is-a?/c editor-data-class%) #f)
  n : exact-nonnegative-integer?
method
(send an-editor-data-class-list number)
 -> exact-nonnegative-integer?
interface
editor-snip-editor-admin<%> : interface?
method
(send an-editor-snip-editor-admin get-snip)
 -> (is-a?/c editor-snip%)
class
editor-snip% : class?
  superclass: snip%
constructor
(new editor-snip%                                
                  [[editor editor]               
                   [with-border? with-border?]   
                   [left-margin left-margin]     
                   [top-margin top-margin]       
                   [right-margin right-margin]   
                   [bottom-margin bottom-margin] 
                   [left-inset left-inset]       
                   [top-inset top-inset]         
                   [right-inset right-inset]     
                   [bottom-inset bottom-inset]   
                   [min-width min-width]         
                   [max-width max-width]         
                   [min-height min-height]       
                   [max-height max-height]])     
 -> (is-a?/c editor-snip%)
  editor : (or/c (is-a?/c editor<%>) #f) = #f
  with-border? : any/c = #t
  left-margin : exact-nonnegative-integer? = 5
  top-margin : exact-nonnegative-integer? = 5
  right-margin : exact-nonnegative-integer? = 5
  bottom-margin : exact-nonnegative-integer? = 5
  left-inset : exact-nonnegative-integer? = 1
  top-inset : exact-nonnegative-integer? = 1
  right-inset : exact-nonnegative-integer? = 1
  bottom-inset : exact-nonnegative-integer? = 1
  min-width : (or/c (and/c real? (not/c negative?)) 'none)
            = 'none
  max-width : (or/c (and/c real? (not/c negative?)) 'none)
            = 'none
  min-height : (or/c (and/c real? (not/c negative?)) 'none)
             = 'none
  max-height : (or/c (and/c real? (not/c negative?)) 'none)
             = 'none
method
(send an-editor-snip adjust-cursor dc      
                                   x       
                                   y       
                                   editorx 
                                   editory 
                                   event)  
 -> (or/c (is-a?/c cursor%) #f)
  dc : (is-a?/c dc<%>)
  x : real?
  y : real?
  editorx : real?
  editory : real?
  event : (is-a?/c mouse-event%)
method
(send an-editor-snip border-visible?) -> boolean?
method
(send an-editor-snip get-align-top-line) -> boolean?
method
(send an-editor-snip get-editor)
 -> (or/c (or/c (is-a?/c text%) (is-a?/c pasteboard%)) #f)
method
(send an-editor-snip get-extent  dc           
                                 x            
                                 y            
                                [w            
                                 h            
                                 descent      
                                 space        
                                 lspace       
                                 rspace]) -> void?
  dc : (is-a?/c dc<%>)
  x : real?
  y : real?
  w : (or/c (box/c (and/c real? (not/c negative?))) #f) = #f
  h : (or/c (box/c (and/c real? (not/c negative?))) #f) = #f
  descent : (or/c (box/c (and/c real? (not/c negative?))) #f)
          = #f
  space : (or/c (box/c (and/c real? (not/c negative?))) #f) = #f
  lspace : (or/c (box/c (and/c real? (not/c negative?))) #f)
         = #f
  rspace : (or/c (box/c (and/c real? (not/c negative?))) #f)
         = #f
method
(send an-editor-snip get-inset l t r b) -> void?
  l : (box/c exact-nonnegative-integer?)
  t : (box/c exact-nonnegative-integer?)
  r : (box/c exact-nonnegative-integer?)
  b : (box/c exact-nonnegative-integer?)
method
(send an-editor-snip get-margin l t r b) -> void?
  l : (box/c exact-nonnegative-integer?)
  t : (box/c exact-nonnegative-integer?)
  r : (box/c exact-nonnegative-integer?)
  b : (box/c exact-nonnegative-integer?)
method
(send an-editor-snip get-max-height)
 -> (or/c (and/c real? (not/c negative?)) 'none)
method
(send an-editor-snip get-max-width)
 -> (or/c (and/c real? (not/c negative?)) 'none)
method
(send an-editor-snip get-min-height)
 -> (or/c (and/c real? (not/c negative?)) 'none)
method
(send an-editor-snip get-min-width)
 -> (or/c (and/c real? (not/c negative?)) 'none)
method
(send an-editor-snip get-tight-text-fit) -> boolean?
method
(send an-editor-snip resize w h) -> boolean?
  w : (and/c real? (not/c negative?))
  h : (and/c real? (not/c negative?))
method
(send an-editor-snip set-align-top-line tight?) -> void?
  tight? : any/c
method
(send an-editor-snip set-editor editor) -> void?
  editor : (or/c (or/c (is-a?/c text%) (is-a?/c pasteboard%)) #f)
method
(send an-editor-snip set-inset l t r b) -> void?
  l : exact-nonnegative-integer?
  t : exact-nonnegative-integer?
  r : exact-nonnegative-integer?
  b : exact-nonnegative-integer?
method
(send an-editor-snip set-margin l t r b) -> void?
  l : exact-nonnegative-integer?
  t : exact-nonnegative-integer?
  r : exact-nonnegative-integer?
  b : exact-nonnegative-integer?
method
(send an-editor-snip set-max-height h) -> void?
  h : (or/c (and/c real? (not/c negative?)) 'none)
method
(send an-editor-snip set-max-width w) -> void?
  w : (or/c (and/c real? (not/c negative?)) 'none)
method
(send an-editor-snip set-min-height h) -> void?
  h : (or/c (and/c real? (not/c negative?)) 'none)
method
(send an-editor-snip set-min-width w) -> void?
  w : (or/c (and/c real? (not/c negative?)) 'none)
method
(send an-editor-snip set-tight-text-fit tight?) -> void?
  tight? : any/c
method
(send an-editor-snip show-border show?) -> void?
  show? : any/c
method
(send an-editor-snip style-background-used?) -> boolean?
method
(send an-editor-snip use-style-background use?) -> void?
  use? : any/c
class
editor-stream-in% : class?
  superclass: object%
constructor
(make-object editor-stream-in% base)
 -> (is-a?/c editor-stream-in%)
  base : (is-a?/c editor-stream-in-base%)
method
(send an-editor-stream-in get v) -> (is-a?/c editor-stream-in%)
  v : (box/c exact-integer?)
(send an-editor-stream-in get v) -> (is-a?/c editor-stream-in%)
  v : (box/c real?)
method
(send an-editor-stream-in get-bytes [len]) -> (or/c bytes? #f)
  len : (or/c (box/c exact-nonnegative-integer?) #f) = #f
method
(send an-editor-stream-in get-exact) -> exact-integer?
method
(send an-editor-stream-in get-fixed v)
 -> (is-a?/c editor-stream-in%)
  v : (box/c exact-integer?)
method
(send an-editor-stream-in get-fixed-exact) -> exact-integer?
method
(send an-editor-stream-in get-inexact) -> real?
method
(send an-editor-stream-in get-unterminated-bytes [len])
 -> (or/c bytes? #f)
  len : (or/c (box/c exact-nonnegative-integer?) #f) = #f
method
(send an-editor-stream-in jump-to pos) -> void?
  pos : exact-nonnegative-integer?
method
(send an-editor-stream-in ok?) -> boolean?
method
(send an-editor-stream-in remove-boundary) -> void?
method
(send an-editor-stream-in set-boundary n) -> void?
  n : exact-nonnegative-integer?
method
(send an-editor-stream-in skip n) -> void?
  n : exact-nonnegative-integer?
method
(send an-editor-stream-in tell) -> exact-nonnegative-integer?
class
editor-stream-in-base% : class?
  superclass: object%
method
(send an-editor-stream-in-base bad?) -> boolean?
method
(send an-editor-stream-in-base read data)
 -> exact-nonnegative-integer?
  data : (and/c vector? (not immutable?))
method
(send an-editor-stream-in-base read-bytes bstr)
 -> exact-nonnegative-integer?
  bstr : (and/c bytes? (not immutable?))
method
(send an-editor-stream-in-base read-byte) -> (or/c byte? #f)
method
(send an-editor-stream-in-base seek pos) -> void?
  pos : exact-nonnegative-integer?
method
(send an-editor-stream-in-base skip n) -> void?
  n : exact-nonnegative-integer?
method
(send an-editor-stream-in-base tell)
 -> exact-nonnegative-integer?
class
editor-stream-in-bytes-base% : class?
  superclass: editor-stream-in-base%
constructor
(make-object editor-stream-in-bytes-base% s)
 -> (is-a?/c editor-stream-in-bytes-base%)
  s : bytes?
class
editor-stream-out% : class?
  superclass: object%
constructor
(make-object editor-stream-out% base)
 -> (is-a?/c editor-stream-out%)
  base : (is-a?/c editor-stream-out-base%)
method
(send an-editor-stream-out jump-to pos) -> void?
  pos : exact-nonnegative-integer?
method
(send an-editor-stream-out ok?) -> boolean?
method
(send an-editor-stream-out pretty-finish) -> void?
method
(send an-editor-stream-out pretty-start) -> void?
method
(send an-editor-stream-out put n v)
 -> (is-a?/c editor-stream-out%)
  n : exact-nonnegative-integer?
  v : bytes?
(send an-editor-stream-out put v)
 -> (is-a?/c editor-stream-out%)
  v : bytes?
(send an-editor-stream-out put v)
 -> (is-a?/c editor-stream-out%)
  v : exact-integer?
(send an-editor-stream-out put v)
 -> (is-a?/c editor-stream-out%)
  v : real?
method
(send an-editor-stream-out put-fixed v)
 -> (is-a?/c editor-stream-out%)
  v : exact-integer?
method
(send an-editor-stream-out put-unterminated v)
 -> (is-a?/c editor-stream-out%)
  v : bytes?
method
(send an-editor-stream-out tell) -> exact-nonnegative-integer?
class
editor-stream-out-base% : class?
  superclass: object%
method
(send an-editor-stream-out-base bad?) -> boolean?
method
(send an-editor-stream-out-base seek pos) -> void?
  pos : exact-nonnegative-integer?
method
(send an-editor-stream-out-base tell)
 -> exact-nonnegative-integer?
method
(send an-editor-stream-out-base write data) -> void?
  data : (listof char?)
method
(send an-editor-stream-out-base write-bytes bstr) -> void?
  bstr : bytes?
class
editor-stream-out-bytes-base% : class?
  superclass: editor-stream-out-base%
constructor
(new editor-stream-out-bytes-base%)
 -> (is-a?/c editor-stream-out-bytes-base%)
method
(send an-editor-stream-out-bytes-base get-bytes) -> bytes?
class
editor-wordbreak-map% : class?
  superclass: object%
constructor
(new editor-wordbreak-map%) -> (is-a?/c editor-wordbreak-map%)
method
(send an-editor-wordbreak-map get-map char)
 -> (listof (or/c 'caret 'line 'selection 'user1 'user2))
  char : char?
method
(send an-editor-wordbreak-map set-map char       
                                      value) -> void?
  char : char?
  value : (listof (or/c 'caret 'line 'selection 'user1 'user2))
class
keymap% : class?
  superclass: object%
constructor
(new keymap%) -> (is-a?/c keymap%)
method
(send a-keymap add-function name func) -> void?
  name : string?
  func : (any/c (is-a?/c event%) . -> . any/c)
method
(send a-keymap is-function-added? fname) -> boolean?
  fname : string?
method
(send a-keymap break-sequence) -> void?
method
(send a-keymap call-function  name             
                              in               
                              event            
                             [try-chain?]) -> boolean?
  name : string?
  in : any/c
  event : (is-a?/c event%)
  try-chain? : any/c = #f
method
(send a-keymap chain-to-keymap next         
                               prefix?) -> void?
  next : (is-a?/c keymap%)
  prefix? : any/c
method
(send a-keymap get-double-click-interval)
 -> (integer-in 0 1000000)
method
(send a-keymap handle-key-event in event) -> boolean?
  in : any/c
  event : (is-a?/c key-event%)
method
(send a-keymap handle-mouse-event in event) -> boolean?
  in : any/c
  event : (is-a?/c mouse-event%)
method
(send a-keymap map-function keyname fname) -> void?
  keyname : string?
  fname : string?
method
(send a-keymap remove-chained-keymap keymap) -> void?
  keymap : (is-a?/c keymap%)
method
(send a-keymap remove-grab-key-function) -> void?
method
(send a-keymap remove-grab-mouse-function) -> void?
method
(send a-keymap set-break-sequence-callback f) -> void?
  f : (-> any)
method
(send a-keymap set-double-click-interval n) -> void?
  n : (integer-in 0 1000000)
method
(send a-keymap set-grab-key-function f) -> void?
  f : ((or/c string? false?)
       (is-a?/c keymap%)
       any/c
       (is-a?/c key-event%)
       . -> . any)
method
(send a-keymap set-grab-mouse-function f) -> void?
  f : ((or/c string? false?)
       (is-a?/c keymap%)
       any/c
       (is-a?/c mouse-event%)
       . -> . any)
class
pasteboard% : class?
  superclass: object%
  extends: editor<%>
constructor
(new pasteboard%) -> (is-a?/c pasteboard%)
method
(send a-pasteboard add-selected snip) -> void?
  snip : (is-a?/c snip%)
(send a-pasteboard add-selected x y w h) -> void?
  x : real?
  y : real?
  w : (and/c real? (not/c negative?))
  h : (and/c real? (not/c negative?))
method
(send a-pasteboard after-delete snip) -> void?
  snip : (is-a?/c snip%)
method
(send a-pasteboard after-insert snip       
                                before     
                                x          
                                y)     -> void?
  snip : (is-a?/c snip%)
  before : (or/c (is-a?/c snip%) #f)
  x : real?
  y : real?
method
(send a-pasteboard after-interactive-move event) -> void?
  event : (is-a?/c mouse-event%)
method
(send a-pasteboard after-interactive-resize snip) -> void?
  snip : (is-a?/c snip%)
method
(send a-pasteboard after-move-to snip           
                                 x              
                                 y              
                                 dragging?) -> void?
  snip : (is-a?/c snip%)
  x : real?
  y : real?
  dragging? : any/c
method
(send a-pasteboard after-reorder snip         
                                 to-snip      
                                 before?) -> boolean?
  snip : (is-a?/c snip%)
  to-snip : (is-a?/c snip%)
  before? : any/c
method
(send a-pasteboard after-resize snip          
                                w             
                                h             
                                resized?) -> void?
  snip : (is-a?/c snip%)
  w : (and/c real? (not/c negative?))
  h : (and/c real? (not/c negative?))
  resized? : any/c
method
(send a-pasteboard after-select snip on?) -> void?
  snip : (is-a?/c snip%)
  on? : any/c
method
(send a-pasteboard can-delete? snip) -> boolean?
  snip : (is-a?/c snip%)
method
(send a-pasteboard can-insert? snip       
                               before     
                               x          
                               y)     -> boolean?
  snip : (is-a?/c snip%)
  before : (or/c (is-a?/c snip%) #f)
  x : real?
  y : real?
method
(send a-pasteboard can-interactive-move? event) -> boolean?
  event : (is-a?/c mouse-event%)
method
(send a-pasteboard can-interactive-resize? snip) -> boolean?
  snip : (is-a?/c snip%)
method
(send a-pasteboard can-move-to? snip           
                                x              
                                y              
                                dragging?) -> boolean?
  snip : (is-a?/c snip%)
  x : real?
  y : real?
  dragging? : any/c
method
(send a-pasteboard can-reorder? snip         
                                to-snip      
                                before?) -> boolean?
  snip : (is-a?/c snip%)
  to-snip : (is-a?/c snip%)
  before? : any/c
method
(send a-pasteboard can-resize? snip w h) -> boolean?
  snip : (is-a?/c snip%)
  w : (and/c real? (not/c negative?))
  h : (and/c real? (not/c negative?))
method
(send a-pasteboard can-select? snip on?) -> boolean?
  snip : (is-a?/c snip%)
  on? : any/c
method
(send a-pasteboard change-style [style snip]) -> void?
  style : (or/c (is-a?/c style-delta%) (is-a?/c style<%>) #f)
        = #f
  snip : (or/c (is-a?/c snip%) #f) = #f
method
(send a-pasteboard copy-self-to dest) -> void?
  dest : (or/c (is-a?/c text%) (is-a?/c pasteboard%))
method
(send a-pasteboard delete) -> void?
(send a-pasteboard delete snip) -> void?
  snip : (is-a?/c snip%)
method
(send a-pasteboard do-copy time extend?) -> void?
  time : exact-integer?
  extend? : any/c
method
(send a-pasteboard do-paste time) -> void?
  time : exact-integer?
method
(send a-pasteboard do-paste-x-selection time) -> void?
  time : exact-integer?
method
(send a-pasteboard erase) -> void?
method
(send a-pasteboard find-next-selected-snip start)
 -> (or/c (is-a?/c snip%) #f)
  start : (or/c (is-a?/c snip%) #f)
method
(send a-pasteboard find-snip x y [after])
 -> (or/c (is-a?/c snip%) #f)
  x : real?
  y : real?
  after : (or/c (is-a?/c snip%) #f) = #f
method
(send a-pasteboard get-center) -> real? real?
method
(send a-pasteboard get-dragable) -> boolean?
method
(send a-pasteboard get-scroll-step)
 -> (and/c real? (not/c negative?))
method
(send a-pasteboard get-selection-visible) -> boolean?
method
(send a-pasteboard insert snip) -> void?
  snip : (is-a?/c snip%)
(send a-pasteboard insert snip before x y) -> void?
  snip : (is-a?/c snip%)
  before : (or/c (is-a?/c snip%) #f)
  x : real?
  y : real?
(send a-pasteboard insert snip x y) -> void?
  snip : (is-a?/c snip%)
  x : real?
  y : real?
(send a-pasteboard insert snip before) -> void?
  snip : (is-a?/c snip%)
  before : (or/c (is-a?/c snip%) #f)
method
(send a-pasteboard interactive-adjust-mouse x      
                                            y) -> void?
  x : (box/c real?)
  y : (box/c real?)
method
(send a-pasteboard interactive-adjust-move snip     
                                           x        
                                           y)   -> void?
  snip : (is-a?/c snip%)
  x : (box/c real?)
  y : (box/c real?)
method
(send a-pasteboard interactive-adjust-resize snip        
                                             width       
                                             height) -> void?
  snip : (is-a?/c snip%)
  width : (box/c (and/c real? (not/c negative?)))
  height : (box/c (and/c real? (not/c negative?)))
method
(send a-pasteboard is-selected? snip) -> boolean?
  snip : (is-a?/c snip%)
method
(send a-pasteboard lower snip) -> void?
  snip : (is-a?/c snip%)
method
(send a-pasteboard move snip x y) -> void?
  snip : (is-a?/c snip%)
  x : real?
  y : real?
(send a-pasteboard move x y) -> void?
  x : real?
  y : real?
method
(send a-pasteboard move-to snip x y) -> void?
  snip : (is-a?/c snip%)
  x : real?
  y : real?
method
(send a-pasteboard no-selected) -> void?
method
(send a-pasteboard on-default-event event) -> void?
  event : (is-a?/c mouse-event%)
method
(send a-pasteboard on-delete snip) -> void?
  snip : (is-a?/c snip%)
method
(send a-pasteboard on-double-click snip       
                                   event) -> void?
  snip : (is-a?/c snip%)
  event : (is-a?/c mouse-event%)
method
(send a-pasteboard on-insert snip before x y) -> void?
  snip : (is-a?/c snip%)
  before : (or/c (is-a?/c snip%) #f)
  x : real?
  y : real?
method
(send a-pasteboard on-interactive-move event) -> void?
  event : (is-a?/c mouse-event%)
method
(send a-pasteboard on-interactive-resize snip) -> void?
  snip : (is-a?/c snip%)
method
(send a-pasteboard on-move-to snip           
                              x              
                              y              
                              dragging?) -> void?
  snip : (is-a?/c snip%)
  x : real?
  y : real?
  dragging? : any/c
method
(send a-pasteboard on-reorder snip         
                              to-snip      
                              before?) -> void?
  snip : (is-a?/c snip%)
  to-snip : (is-a?/c snip%)
  before? : any/c
method
(send a-pasteboard on-resize snip w h) -> void?
  snip : (is-a?/c snip%)
  w : (and/c real? (not/c negative?))
  h : (and/c real? (not/c negative?))
method
(send a-pasteboard on-select snip on?) -> void?
  snip : (is-a?/c snip%)
  on? : any/c
method
(send a-pasteboard raise snip) -> void?
  snip : (is-a?/c snip%)
method
(send a-pasteboard remove snip) -> void?
  snip : (is-a?/c snip%)
method
(send a-pasteboard remove-selected snip) -> void?
  snip : (is-a?/c snip%)
method
(send a-pasteboard resize snip w h) -> boolean?
  snip : (is-a?/c snip%)
  w : (and/c real? (not/c negative?))
  h : (and/c real? (not/c negative?))
method
(send a-pasteboard set-after snip after) -> void?
  snip : (is-a?/c snip%)
  after : (or/c (is-a?/c snip%) #f)
method
(send a-pasteboard set-before snip before) -> void?
  snip : (is-a?/c snip%)
  before : (or/c (is-a?/c snip%) #f)
method
(send a-pasteboard set-dragable allow-drag?) -> void?
  allow-drag? : any/c
method
(send a-pasteboard set-scroll-step stepsize) -> void?
  stepsize : (and/c real? (not/c negative?))
method
(send a-pasteboard set-selected snip) -> void?
  snip : (is-a?/c snip%)
method
(send a-pasteboard set-selection-visible visible?) -> void?
  visible? : any/c
class
text% : class?
  superclass: object%
  extends: editor<%>
constructor
(new text%                                  
           [[line-spacing line-spacing]     
            [tab-stops tab-stops]           
            [auto-wrap auto-wrap]])     -> (is-a?/c text%)
  line-spacing : (and/c real? (not/c negative?)) = 1.0
  tab-stops : (listof real?) = null
  auto-wrap : any/c = #f
method
(send a-text after-change-style start len) -> void?
  start : exact-nonnegative-integer?
  len : exact-nonnegative-integer?
method
(send a-text after-delete start len) -> void?
  start : exact-nonnegative-integer?
  len : exact-nonnegative-integer?
method
(send a-text after-insert start len) -> void?
  start : exact-nonnegative-integer?
  len : exact-nonnegative-integer?
method
(send a-text after-merge-snips pos) -> void?
  pos : exact-nonnegative-integer?
method
(send a-text after-set-position) -> void?
method
(send a-text after-set-size-constraint) -> void?
method
(send a-text after-split-snip pos) -> void?
  pos : exact-nonnegative-integer?
method
(send a-text call-clickback start end) -> void?
  start : exact-nonnegative-integer?
  end : exact-nonnegative-integer?
method
(send a-text can-change-style? start len) -> boolean?
  start : exact-nonnegative-integer?
  len : exact-nonnegative-integer?
method
(send a-text can-delete? start len) -> boolean?
  start : exact-nonnegative-integer?
  len : exact-nonnegative-integer?
method
(send a-text can-insert? start len) -> boolean?
  start : exact-nonnegative-integer?
  len : exact-nonnegative-integer?
method
(send a-text can-set-size-constraint?) -> boolean?
method
(send a-text caret-hidden?) -> boolean?
method
(send a-text change-style  delta                
                          [start                
                           end                  
                           counts-as-mod?]) -> void?
  delta : (or/c (is-a?/c style-delta%) #f)
  start : (or/c exact-nonnegative-integer? 'start) = 'start
  end : (or/c exact-nonnegative-integer? 'end) = 'end
  counts-as-mod? : any/c = #t
(send a-text change-style  style                
                          [start                
                           end                  
                           counts-as-mod?]) -> void?
  style : (or/c (is-a?/c style<%>) #f)
  start : (or/c exact-nonnegative-integer? 'start) = 'start
  end : (or/c exact-nonnegative-integer? 'end) = 'end
  counts-as-mod? : any/c = #t
method
(send a-text copy [extend? time start end]) -> void?
  extend? : any/c = #f
  time : exact-integer? = 0
  start : (or/c exact-nonnegative-integer? 'start) = 'start
  end : (or/c exact-nonnegative-integer? 'end) = 'end
method
(send a-text copy-self-to dest) -> void?
  dest : (or/c (is-a?/c text%) (is-a?/c pasteboard%))
method
(send a-text cut [extend? time start end]) -> void?
  extend? : any/c = #f
  time : exact-integer? = 0
  start : (or/c exact-nonnegative-integer? 'start) = 'start
  end : (or/c exact-nonnegative-integer? 'end) = 'end
method
(send a-text delete start [end scroll-ok?]) -> void?
  start : (or/c exact-nonnegative-integer? 'start)
  end : (or/c exact-nonnegative-integer? 'back) = 'back
  scroll-ok? : any/c = #t
(send a-text delete) -> void?
method
(send a-text do-copy start end time extend?) -> void?
  start : exact-nonnegative-integer?
  end : exact-nonnegative-integer?
  time : exact-integer?
  extend? : any/c
method
(send a-text do-paste start time) -> void?
  start : exact-nonnegative-integer?
  time : exact-integer?
method
(send a-text do-paste-x-selection start     
                                  time) -> void?
  start : exact-nonnegative-integer?
  time : exact-integer?
method
(send a-text erase) -> void?
method
(send a-text extend-position pos) -> void?
  pos : exact-nonnegative-integer?
method
(send a-text find-line y [on-it?]) -> exact-nonnegative-integer?
  y : real?
  on-it? : (or/c (box/c any/c) #f) = #f
method
(send a-text find-newline [direction 
                           start     
                           end])     
 -> (or/c exact-nonnegative-integer? #f)
  direction : (or/c 'forward 'backward) = 'forward
  start : (or/c exact-nonnegative-integer? 'start) = 'start
  end : (or/c exact-nonnegative-integer? 'eof) = 'eof
method
(send a-text find-next-non-string-snip after)
 -> (or/c (is-a?/c snip%) #f)
  after : (or/c (is-a?/c snip%) #f)
method
(send a-text find-position  x             
                            y             
                           [at-eol?       
                            on-it?        
                            edge-close?]) 
 -> exact-nonnegative-integer?
  x : real?
  y : real?
  at-eol? : (or/c (box/c any/c) #f) = #f
  on-it? : (or/c (box/c any/c) #f) = #f
  edge-close? : (or/c (box/c real?) #f) = #f
method
(send a-text find-position-in-line  line          
                                    x             
                                   [at-eol?       
                                    on-it?        
                                    edge-close?]) 
 -> exact-nonnegative-integer?
  line : exact-nonnegative-integer?
  x : real?
  at-eol? : (or/c (box/c any/c) #f) = #f
  on-it? : (or/c (box/c any/c) #f) = #f
  edge-close? : (or/c (box/c real?) #f) = #f
method
(send a-text find-snip pos direction [s-pos])
 -> (or/c (is-a?/c snip%) #f)
  pos : exact-nonnegative-integer?
  direction : (or/c 'before-or-none 'before 'after 'after-or-none)
  s-pos : (or/c (box/c exact-nonnegative-integer?) #f) = #f
method
(send a-text find-string  str               
                         [direction         
                          start             
                          end               
                          get-start?        
                          case-sensitive?]) 
 -> (or/c exact-nonnegative-integer? #f)
  str : string?
  direction : (or/c 'forward 'backward) = 'forward
  start : (or/c exact-nonnegative-integer? 'start) = 'start
  end : (or/c exact-nonnegative-integer? 'eof) = 'eof
  get-start? : any/c = #t
  case-sensitive? : any/c = #t
method
(send a-text find-string-embedded  str               
                                  [direction         
                                   start             
                                   end               
                                   get-start?        
                                   case-sensitive?]) 
 -> (or/c exact-nonnegative-integer?
          #f
          (cons/c
           (is-a?/c editor<%>)
           (flat-rec-contract
            nested-editor-search-result
            (or/c (cons/c (is-a?/c editor<%>)
                          nested-editor-search-result)
                  exact-nonnegative-integer?))))
  str : string?
  direction : (or/c 'forward 'backward) = 'forward
  start : (or/c exact-nonnegative-integer? 'start) = 'start
  end : (or/c exact-nonnegative-integer? 'eof) = 'eof
  get-start? : any/c = #t
  case-sensitive? : any/c = #t
method
(send a-text find-string-all  str              
                             [direction        
                              start            
                              end              
                              get-start?       
                              case-sensitive]) 
 -> (listof exact-nonnegative-integer?)
  str : string?
  direction : (or/c 'forward 'backward) = 'forward
  start : (or/c exact-nonnegative-integer? 'start) = 'start
  end : (or/c exact-nonnegative-integer? 'eof) = 'eof
  get-start? : any/c = #t
  case-sensitive : any/c = #t
method
(send a-text find-string-embedded-all  str              
                                      [direction        
                                       start            
                                       end              
                                       get-start?       
                                       case-sensitive]) 
 -> (listof (or/c exact-nonnegative-integer?
                  (cons/c
                   (is-a?/c editor<%>)
                   (flat-rec-contract
                    nested-editor-search-result
                    (or/c (cons/c (is-a?/c editor<%>)
                                  nested-editor-search-result)
                          (listof exact-nonnegative-integer?))))))
  str : string?
  direction : (or/c 'forward 'backward) = 'forward
  start : (or/c exact-nonnegative-integer? 'start) = 'start
  end : (or/c exact-nonnegative-integer? 'eof) = 'eof
  get-start? : any/c = #t
  case-sensitive : any/c = #t
method
(send a-text find-wordbreak start       
                            end         
                            reason) -> void?
  start : (or/c (box/c exact-nonnegative-integer?) #f)
  end : (or/c (box/c exact-nonnegative-integer?) #f)
  reason : (or/c 'caret 'line 'selection 'user1 'user2)
method
(send a-text flash-off) -> void?
method
(send a-text flash-on  start         
                       end           
                      [at-eol?       
                       scroll?       
                       timeout]) -> void?
  start : exact-nonnegative-integer?
  end : exact-nonnegative-integer?
  at-eol? : any/c = #f
  scroll? : any/c = #t
  timeout : exact-nonnegative-integer? = 500
method
(send a-text get-anchor) -> boolean?
method
(send a-text get-autowrap-bitmap-width)
 -> (and/c real? (not/c negative?))
method
(send a-text get-between-threshold)
 -> (and/c real? (not/c negative?))
method
(send a-text get-character start) -> char?
  start : exact-nonnegative-integer?
method
(send a-text get-end-position) -> exact-nonnegative-integer?
method
(send a-text get-extend-start-position)
 -> exact-nonnegative-integer?
method
(send a-text get-extend-end-position)
 -> exact-nonnegative-integer?
method
(send a-text get-file-format)
 -> (or/c 'standard 'text 'text-force-cr)
method
(send a-text get-line-spacing)
 -> (and/c real? (not/c negative?))
method
(send a-text get-overwrite-mode) -> boolean?
method
(send a-text get-padding) -> (and/c real? (not/c negative?))
                             (and/c real? (not/c negative?))
                             (and/c real? (not/c negative?))
                             (and/c real? (not/c negative?))
method
(send a-text get-position start [end]) -> void?
  start : (or/c (box/c exact-nonnegative-integer?) #f)
  end : (or/c (box/c exact-nonnegative-integer?) #f) = #f
method
(send a-text get-region-data start end)
 -> (or/c (is-a?/c editor-data%) #f)
  start : exact-nonnegative-integer?
  end : exact-nonnegative-integer?
method
(send a-text get-revision-number)
 -> (and/c real? (not/c negative?))
method
(send a-text get-snip-position snip)
 -> (or/c exact-nonnegative-integer? #f)
  snip : (is-a?/c snip%)
method
(send a-text get-snip-position-and-location  snip     
                                             pos      
                                            [x        
                                             y])  -> boolean?
  snip : (is-a?/c snip%)
  pos : (or/c (box/c exact-nonnegative-integer?) #f)
  x : (or/c (box/c real?) #f) = #f
  y : (or/c (box/c real?) #f) = #f
method
(send a-text get-start-position) -> exact-nonnegative-integer?
method
(send a-text get-styles-sticky) -> boolean?
method
(send a-text get-tabs [length         
                       tab-width      
                       in-units]) -> (listof real?)
  length : (or/c (box/c exact-nonnegative-integer?) #f) = #f
  tab-width : (or/c (box/c real?) #f) = #f
  in-units : (or/c (box/c any/c) #f) = #f
method
(send a-text get-text [start           
                       end             
                       flattened?      
                       force-cr?]) -> string?
  start : exact-nonnegative-integer? = 0
  end : (or/c exact-nonnegative-integer? 'eof) = 'eof
  flattened? : any/c = #f
  force-cr? : any/c = #f
method
(send a-text get-top-line-base)
 -> (and/c real? (not/c negative?))
method
(send a-text get-visible-line-range  start      
                                     end        
                                    [all?]) -> void?
  start : (or/c (box/c exact-nonnegative-integer?) #f)
  end : (or/c (box/c exact-nonnegative-integer?) #f)
  all? : any/c = #t
method
(send a-text get-visible-position-range  start      
                                         end        
                                        [all?]) -> void?
  start : (or/c (box/c exact-nonnegative-integer?) #f)
  end : (or/c (box/c exact-nonnegative-integer?) #f)
  all? : any/c = #t
method
(send a-text get-wordbreak-map)
 -> (or/c (is-a?/c editor-wordbreak-map%) #f)
method
(send a-text hide-caret hide?) -> void?
  hide? : any/c
method
(send a-text insert str start [end scroll-ok?]) -> void?
  str : string?
  start : exact-nonnegative-integer?
  end : (or/c exact-nonnegative-integer? 'same) = 'same
  scroll-ok? : any/c = #t
(send a-text insert  n                
                     str              
                     start            
                    [end              
                     scroll-ok?]) -> void?
  n : (and/c exact-nonnegative-integer?
             (<=/c (string-length str)))
  str : string?
  start : exact-nonnegative-integer?
  end : (or/c exact-nonnegative-integer? 'same) = 'same
  scroll-ok? : any/c = #t
(send a-text insert str) -> void?
  str : string?
(send a-text insert n str) -> void?
  n : (and/c exact-nonnegative-integer?
             (<=/c (string-length str)))
  str : string?
(send a-text insert  snip             
                     start            
                    [end              
                     scroll-ok?]) -> void?
  snip : (is-a?/c snip%)
  start : exact-nonnegative-integer?
  end : (or/c exact-nonnegative-integer? 'same) = 'same
  scroll-ok? : any/c = #t
(send a-text insert snip) -> void?
  snip : (is-a?/c snip%)
(send a-text insert char) -> void?
  char : char?
(send a-text insert char start [end]) -> void?
  char : char?
  start : exact-nonnegative-integer?
  end : (or/c exact-nonnegative-integer? 'same) = 'same
method
(send a-text kill [time]) -> void?
  time : exact-integer? = 0
(send a-text kill time start end) -> void?
  time : exact-integer?
  start : exact-nonnegative-integer?
  end : exact-nonnegative-integer?
method
(send a-text last-line) -> exact-nonnegative-integer?
method
(send a-text last-paragraph) -> exact-nonnegative-integer?
method
(send a-text last-position) -> exact-nonnegative-integer?
method
(send a-text line-end-position  line       
                               [visible?]) 
 -> exact-nonnegative-integer?
  line : exact-nonnegative-integer?
  visible? : any/c = #t
method
(send a-text line-length i) -> exact-nonnegative-integer?
  i : exact-nonnegative-integer?
method
(send a-text line-location line [top?]) -> real?
  line : exact-nonnegative-integer?
  top? : any/c = #t
method
(send a-text line-paragraph start) -> exact-nonnegative-integer?
  start : exact-nonnegative-integer?
method
(send a-text line-start-position  line       
                                 [visible?]) 
 -> exact-nonnegative-integer?
  line : exact-nonnegative-integer?
  visible? : any/c = #t
method
(send a-text move-position  code        
                           [extend?     
                            kind])  -> void?
  code : (or/c 'home 'end 'right 'left 'up 'down)
  extend? : any/c = #f
  kind : (or/c 'simple 'word 'page 'line) = 'simple
method
(send a-text on-change-style start len) -> void?
  start : exact-nonnegative-integer?
  len : exact-nonnegative-integer?
method
(send a-text on-default-char event) -> void?
  event : (is-a?/c key-event%)
method
(send a-text on-default-event event) -> void?
  event : (is-a?/c mouse-event%)
method
(send a-text on-delete start len) -> void?
  start : exact-nonnegative-integer?
  len : exact-nonnegative-integer?
method
(send a-text on-insert start len) -> void?
  start : exact-nonnegative-integer?
  len : exact-nonnegative-integer?
method
(send a-text on-new-string-snip) -> (is-a?/c string-snip%)
method
(send a-text on-new-tab-snip) -> (is-a?/c tab-snip%)
method
(send a-text on-reflow) -> void?
method
(send a-text on-set-size-constraint) -> void?
method
(send a-text paragraph-end-line paragraph)
 -> exact-nonnegative-integer?
  paragraph : exact-nonnegative-integer?
method
(send a-text paragraph-end-position  paragraph  
                                    [visible?]) 
 -> exact-nonnegative-integer?
  paragraph : exact-nonnegative-integer?
  visible? : any/c = #t
method
(send a-text paragraph-start-line paragraph)
 -> exact-nonnegative-integer?
  paragraph : exact-nonnegative-integer?
method
(send a-text paragraph-start-position  paragraph  
                                      [visible?]) 
 -> exact-nonnegative-integer?
  paragraph : exact-nonnegative-integer?
  visible? : any/c = #t
method
(send a-text paste [time start end]) -> void?
  time : exact-integer? = 0
  start : (or/c exact-nonnegative-integer? 'start 'end) = 'start
  end : (or/c exact-nonnegative-integer? 'same) = 'same
method
(send a-text paste-next) -> void?
method
(send a-text paste-x-selection [time      
                                start     
                                end]) -> void?
  time : exact-integer? = 0
  start : (or/c exact-nonnegative-integer? 'start 'end) = 'start
  end : (or/c exact-nonnegative-integer? 'same) = 'same
method
(send a-text position-line start [at-eol?])
 -> exact-nonnegative-integer?
  start : exact-nonnegative-integer?
  at-eol? : any/c = #f
method
(send a-text position-location  start             
                               [x                 
                                y                 
                                top?              
                                at-eol?           
                                whole-line?]) -> void?
  start : exact-nonnegative-integer?
  x : (or/c (box/c real?) #f) = #f
  y : (or/c (box/c real?) #f) = #f
  top? : any/c = #t
  at-eol? : any/c = #f
  whole-line? : any/c = #f
method
(send a-text position-locations  start             
                                [top-x             
                                 top-y             
                                 bottom-x          
                                 bottom-y          
                                 at-eol?           
                                 whole-line?]) -> void?
  start : exact-nonnegative-integer?
  top-x : (or/c (box/c real?) #f) = #f
  top-y : (or/c (box/c real?) #f) = #f
  bottom-x : (or/c (box/c real?) #f) = #f
  bottom-y : (or/c (box/c real?) #f) = #f
  at-eol? : any/c = #f
  whole-line? : any/c = #f
method
(send a-text position-paragraph  start     
                                [at-eol?]) 
 -> exact-nonnegative-integer?
  start : exact-nonnegative-integer?
  at-eol? : any/c = #f
method
(send a-text read-from-file  stream                  
                             start                   
                            [overwrite-styles?]) -> boolean?
  stream : (is-a?/c editor-stream-in%)
  start : (or/c exact-nonnegative-integer? 'start)
  overwrite-styles? : any/c = #f
(send a-text read-from-file  stream                  
                            [overwrite-styles?]) -> boolean?
  stream : (is-a?/c editor-stream-in%)
  overwrite-styles? : any/c = #f
method
(send a-text remove-clickback start end) -> void?
  start : exact-nonnegative-integer?
  end : exact-nonnegative-integer?
method
(send a-text scroll-to-position  start       
                                [at-eol?     
                                 end         
                                 bias])  -> boolean?
  start : exact-nonnegative-integer?
  at-eol? : any/c = #f
  end : (or/c exact-nonnegative-integer? 'same) = 'same
  bias : (or/c 'start 'end 'none) = 'none
method
(send a-text set-anchor on?) -> void?
  on? : any/c
method
(send a-text set-autowrap-bitmap bitmap)
 -> (or/c (is-a?/c bitmap%) #f)
  bitmap : (or/c (is-a?/c bitmap%) #f)
method
(send a-text set-between-threshold threshold) -> void?
  threshold : (and/c real? (not/c negative?))
method
(send a-text set-clickback  start               
                            end                 
                            f                   
                           [hilite-delta        
                            call-on-down?]) -> void?
  start : exact-nonnegative-integer?
  end : exact-nonnegative-integer?
  f : (-> (is-a?/c text%)
          exact-nonnegative-integer?
          exact-nonnegative-integer?
          any)
  hilite-delta : (or/c (is-a?/c style-delta%) #f) = #f
  call-on-down? : any/c = #f
method
(send a-text set-file-format format) -> void?
  format : (or/c 'standard 'text 'text-force-cr)
method
(send a-text set-line-spacing space) -> void?
  space : (and/c real? (not/c negative?))
method
(send a-text set-overwrite-mode on?) -> void?
  on? : any/c
method
(send a-text set-padding left        
                         top         
                         right       
                         bottom) -> void?
  left : (and/c real? (not/c negative?))
  top : (and/c real? (not/c negative?))
  right : (and/c real? (not/c negative?))
  bottom : (and/c real? (not/c negative?))
method
(send a-text set-paragraph-alignment paragraph      
                                     alignment) -> void?
  paragraph : exact-nonnegative-integer?
  alignment : (or/c 'left 'center 'right)
method
(send a-text set-paragraph-margins paragraph      
                                   first-left     
                                   left           
                                   right)     -> void?
  paragraph : exact-nonnegative-integer?
  first-left : (and/c real? (not/c negative?))
  left : (and/c real? (not/c negative?))
  right : (and/c real? (not/c negative?))
method
(send a-text set-position  start         
                          [end           
                           at-eol?       
                           scroll?       
                           seltype]) -> void?
  start : exact-nonnegative-integer?
  end : (or/c exact-nonnegative-integer? 'same) = 'same
  at-eol? : any/c = #f
  scroll? : any/c = #t
  seltype : (or/c 'default 'x 'local) = 'default
method
(send a-text set-position-bias-scroll  bias          
                                       start         
                                      [end           
                                       ateol?        
                                       scroll?       
                                       seltype]) -> void?
  bias : (or/c 'start-only 'start 'none 'end 'end-only)
  start : exact-nonnegative-integer?
  end : (or/c exact-nonnegative-integer? 'same) = 'same
  ateol? : any/c = #f
  scroll? : any/c = #t
  seltype : (or/c 'default 'x 'local) = 'default
method
(send a-text set-region-data start end data) -> void?
  start : exact-nonnegative-integer?
  end : exact-nonnegative-integer?
  data : (is-a?/c editor-data%)
method
(send a-text set-styles-sticky sticky?) -> void?
  sticky? : any/c
method
(send a-text set-tabs  tabs            
                      [tab-width       
                       in-units?]) -> void?
  tabs : (listof real?)
  tab-width : real? = 20
  in-units? : any/c = #t
method
(send a-text set-wordbreak-func f) -> void?
  f : ((is-a?/c text%) (or/c (box/c exact-nonnegative-integer?) #f)
                       (or/c (box/c exact-nonnegative-integer?) #f)
                       symbol?
       . -> . any)
method
(send a-text set-wordbreak-map map) -> void?
  map : (or/c (is-a?/c editor-wordbreak-map%) #f)
method
(send a-text split-snip pos) -> void?
  pos : exact-nonnegative-integer?
method
(send a-text write-to-file stream [start end]) -> boolean?
  stream : (is-a?/c editor-stream-out%)
  start : exact-nonnegative-integer? = 0
  end : (or/c exact-nonnegative-integer? 'eof) = 'eof
procedure
(add-editor-keymap-functions keymap) -> void?
  keymap : (is-a?/c keymap%)
procedure
(add-pasteboard-keymap-functions keymap) -> void?
  keymap : (is-a?/c keymap%)
procedure
(add-text-keymap-functions keymap) -> void?
  keymap : (is-a?/c keymap%)
procedure
(append-editor-font-menu-items menu) -> void?
  menu : (or/c (is-a?/c menu%) (is-a?/c popup-menu%))
procedure
(append-editor-operation-menu-items                                    
                                     menu                              
                                    [text-only?                        
                                     #:popup-position popup-position]) 
 -> void?
  menu : (or/c (is-a?/c menu%) (is-a?/c popup-menu%))
  text-only? : any/c = #t
  popup-position : (or/c #f (list/c (is-a?/c text%) exact-nonnegative-integer?))
                 = #f
parameter
(current-text-keymap-initializer)
 -> ((is-a?/c keymap%) . -> . any/c)
(current-text-keymap-initializer proc) -> void?
  proc : ((is-a?/c keymap%) . -> . any/c)
procedure
(editor-set-x-selection-mode on) -> void?
  on : any/c
procedure
(get-the-editor-data-class-list)
 -> (is-a?/c editor-data-class-list<%>)
procedure
(get-the-snip-class-list) -> (is-a?/c snip-class-list<%>)
procedure
(map-command-as-meta-key on?) -> void?
  on? : any/c
(map-command-as-meta-key) -> boolean?
procedure
(open-input-graphical-file filename) -> input-port?
  filename : string?
procedure
(open-input-text-editor                                              
                         text-editor                                 
                        [start-position                              
                         end-position                                
                         snip-filter                                 
                         port-name                                   
                         expect-to-read-all?                         
                         #:lock-while-reading? lock-while-reading?]) 
 -> input-port
  text-editor : (is-a?/c text%)
  start-position : exact-nonnegative-integer? = 0
  end-position : (or/c exact-nonnegative-integer? 'end) = 'end
  snip-filter : ((is-a?/c snip%) . -> . any/c) = (lambda (s) s)
  port-name : any/c = text-editor
  expect-to-read-all? : any/c = #f
  lock-while-reading? : any/c = #f
procedure
(open-output-text-editor  text-editor                   
                         [start-position                
                          special-filter                
                          port-name                     
                          #:eventspace eventspace]) -> output-port
  text-editor : (is-a?/c text%)
  start-position : (or/c exact-nonnegative-integer? (one/of 'end))
                 = 'end
  special-filter : (any/c . -> . any/c) = (lambda (x) x)
  port-name : any/c = text-editor
  eventspace : (or/c eventspace? #f) = (current-eventspace)
procedure
(read-editor-global-footer in) -> boolean?
  in : (is-a?/c editor-stream-in%)
procedure
(read-editor-global-header in) -> boolean?
  in : (is-a?/c editor-stream-in%)
procedure
(read-editor-version  in                  
                      in-base             
                      parse-format?       
                     [raise-errors?]) -> boolean?
  in : (is-a?/c editor-stream-in%)
  in-base : (is-a?/c editor-stream-in-base%)
  parse-format? : any/c
  raise-errors? : any/c = #t
procedure
(text-editor-load-handler [filename]                 
                           expected-module-name) -> any/c
  filename : path = string
  expected-module-name : (or/c symbol? #f)
value
the-editor-wordbreak-map : (is-a?/c editor-wordbreak-map%)
value
the-style-list : (is-a?/c style-list%)
procedure
(write-editor-global-footer out) -> boolean?
  out : (is-a?/c editor-stream-out%)
procedure
(write-editor-global-header out) -> boolean?
  out : (is-a?/c editor-stream-out%)
procedure
(write-editor-version out out-base) -> boolean?
  out : (is-a?/c editor-stream-out%)
  out-base : (is-a?/c editor-stream-out-base%)
procedure
(is-wxme-stream? in) -> boolean?
  in : input-port?
procedure
(wxme-port->text-port in [close?]) -> input-port?
  in : input-port?
  close? : any/c = #t
procedure
(wxme-port->port in [close? snip-filter]) -> input-port?
  in : input-port?
  close? : any/c = #t
  snip-filter : (any/c . -> . any/c) = (lambda (x) x)
procedure
(extract-used-classes in) -> (listof string?) (listof string?)
  in : input-port?
procedure
(register-lib-mapping! str mod-path) -> void?
  str : string?
  mod-path : (cons/c 'lib (listof string?))
procedure
(string->lib-path str gui?) -> (cons/c 'lib (listof string?))
  str : string?
  gui? : any/c
parameter
(unknown-extensions-skip-enabled) -> boolean?
(unknown-extensions-skip-enabled skip?) -> void?
  skip? : any/c
parameter
(broken-wxme-big-endian?) -> boolean?
(broken-wxme-big-endian? big?) -> void?
  big? : any/c
procedure
(wxme-read in) -> any/c
  in : input-port?
procedure
(wxme-read-syntax source-v in) -> (or/c syntax? eof-object?)
  source-v : any/c
  in : input-port?
interface
snip-reader<%> : interface?
method
(send a-snip-reader read-header version     
                                stream) -> any
  version : exact-nonnegative-integer?
  stream : (is-a?/c stream<%>)
method
(send a-snip-reader read-snip text-only?     
                              version        
                              stream)    -> (if text-only?
                                                bytes?
                                                any/c)
  text-only? : boolean?
  version : exact-nonnegative-integer?
  stream : (is-a?/c stream<%>)
interface
readable<%> : interface?
method
(send a-readable read-special source        
                              line          
                              column        
                              position) -> any/c
  source : any/c
  line : (or/c exact-nonnegative-integer? #f)
  column : (or/c exact-nonnegative-integer? #f)
  position : (or/c exact-nonnegative-integer? #f)
interface
stream<%> : interface?
method
(send a-stream read-integer what) -> exact-integer?
  what : any/c
method
(send a-stream read-fixed-integer what) -> exact-integer?
  what : any/c
method
(send a-stream read-inexact what) -> (and/c real? inexact?)
  what : any/c
method
(send a-stream read-raw-bytes what) -> bytes?
  what : any/c
method
(send a-stream read-bytes what) -> bytes?
  what : any/c
method
(send a-stream read-editor what) -> input-port?
  what : any/c
procedure
(read-snip-from-port name who stream) -> bytes?
  name : string?
  who : any/c
  stream : (is-a?/c stream<%>)
class
editor% : class?
  superclass: object%
method
(send an-editor get-content-port) -> input-port?
class
image% : class?
  superclass: image-snip%
method
(send an-image get-data) -> (or/c bytes? #f)
method
(send an-image get-w) -> (or/c exact-nonnegative-integer? -1)
method
(send an-image get-h) -> (or/c exact-nonnegative-integer? -1)
method
(send an-image get-dx) -> exact-integer?
method
(send an-image get-dy) -> exact-integer?
value
reader : (is-a?/c snip-reader<%>)
class
comment-editor% : class?
  superclass: editor%
  extends: readable<%>
method
(send a-comment-editor get-data) -> #f
method
(send a-comment-editor read-special source        
                                    line          
                                    column        
                                    position) -> any/c
  source : any/c
  line : (or/c exact-nonnegative-integer? #f)
  column : (or/c exact-nonnegative-integer? #f)
  position : (or/c exact-nonnegative-integer? #f)
value
reader : (is-a?/c snip-reader<%>)
class
xml-editor% : class?
  superclass: editor%
  extends: readable<%>
method
(send a-xml-editor get-data) -> any/c
method
(send a-xml-editor read-special source        
                                line          
                                column        
                                position) -> any/c
  source : any/c
  line : (or/c exact-nonnegative-integer? #f)
  column : (or/c exact-nonnegative-integer? #f)
  position : (or/c exact-nonnegative-integer? #f)
value
reader : (is-a?/c snip-reader<%>)
class
racket-editor% : class?
  superclass: editor%
  extends: readable<%>
method
(send a-racket-editor get-data) -> any/c
method
(send a-racket-editor read-special source        
                                   line          
                                   column        
                                   position) -> any/c
  source : any/c
  line : (or/c exact-nonnegative-integer? #f)
  column : (or/c exact-nonnegative-integer? #f)
  position : (or/c exact-nonnegative-integer? #f)
value
reader : (is-a?/c snip-reader<%>)
class
text-editor% : class?
  superclass: editor%
  extends: readable<%>
method
(send a-text-editor get-data) -> #f
method
(send a-text-editor read-special source        
                                 line          
                                 column        
                                 position) -> any/c
  source : any/c
  line : (or/c exact-nonnegative-integer? #f)
  column : (or/c exact-nonnegative-integer? #f)
  position : (or/c exact-nonnegative-integer? #f)
value
reader : (is-a?/c snip-reader<%>)
value
reader : (is-a?/c snip-reader<%>)
class
cache-image% : class?
  superclass: object%
method
(send a-cache-image get-argb) -> (vectorof byte?)
method
(send a-cache-image get-width) -> exact-nonnegative-integer?
method
(send a-cache-image get-height) -> exact-nonnegative-integer?
method
(send a-cache-image get-pin-x) -> exact-integer?
method
(send a-cache-image get-pin-y) -> exact-integer?
value
reader : (is-a?/c snip-reader<%>)
class
test-case% : class?
  superclass: object%
method
(send a-test-case get-comment) -> (or/c #f input-port?)
method
(send a-test-case get-test) -> input-port?
method
(send a-test-case get-expected) -> input-port?
method
(send a-test-case get-should-raise) -> (or/c #f input-port?)
method
(send a-test-case get-error-message) -> (or/c #f input-port?)
method
(send a-test-case get-enabled?) -> boolean?
method
(send a-test-case get-collapsed?) -> boolean?
method
(send a-test-case get-error-box?) -> boolean?
procedure
(gui-available?) -> boolean?
procedure
(gui-dynamic-require sym) -> any
  sym : symbol?
