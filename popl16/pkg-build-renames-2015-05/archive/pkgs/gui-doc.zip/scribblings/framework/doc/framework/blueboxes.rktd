74672
((3) 0 () 106 ((q lib "framework/main.rkt") (c (? . 0) q frame:standard-menus<%>) (c (? . 0) q menu:can-restore-underscore<%>) (c (? . 0) q racket:text<%>) (c (? . 0) q mode:surrogate-text%) (c (? . 0) q frame:searchable-mixin) (q lib "framework/gui-utils.rkt") (c (? . 0) q color:text<%>) (c (? . 0) q text:delegate-mixin) (c (? . 0) q frame:editor-mixin) (c (? . 0) q group:%) (q lib "framework/splash.rkt") (c (? . 0) q mode:host-text-mixin) (c (? . 0) q text:autocomplete<%>) (c (? . 0) q text:ports<%>) (q lib "framework/test.rkt") (c (? . 0) q text:basic<%>) (c (? . 0) q frame:editor<%>) (c (? . 0) q editor:backup-autosave-mixin) (c (? . 0) q text:basic-mixin) (c (? . 0) q frame:info-mixin) (c (? . 0) q panel:dragable<%>) (c (? . 0) q text:return-mixin) (c (? . 0) q text:searching-mixin) (q lib "framework/preferences.rkt") (c (? . 0) q frame:status-line<%>) (c (? . 0) q color:text-mixin) (c (? . 0) q frame:searchable<%>) (c (? . 0) q panel:splitter-mixin) (c (? . 0) q editor-snip:decorated-mixin) (c (? . 0) q editor-snip:decorated<%>) (q lib "framework/decorated-editor-snip.rkt") (c (? . 0) q editor:basic-mixin) (c (? . 0) q frame:text-mixin) (c (? . 0) q text:1-pixel-tab-snip%) (c (? . 0) q frame:info<%>) (c (? . 0) q frame:focus-table-mixin) (c (? . 0) q text:normalize-paste-mixin) (c (? . 0) q editor:basic<%>) (c (? . 0) q text:delegate<%>) (c (? . 0) q frame:basic-mixin) (c (? . 0) q text:first-line<%>) (c (? . 0) q frame:searchable-text-mixin) (c (? . 0) q keymap:aug-keymap-mixin) (c (? . 0) q text:searching<%>) (c (? . 0) q text:ports-mixin) (c (? . 0) q editor:file-mixin) (c (? . 0) q text:column-guide-mixin) (c (? . 0) q text:file-mixin) (c (? . 0) q frame:size-pref-mixin) (c (? . 0) q canvas:wide-snip<%>) (c (? . 0) q mode:surrogate-text<%>) (c (? . 0) q frame:basic<%>) (c (? . 0) q frame:delegate<%>) (c (? . 0) q racket:text-mixin) (c (? . 0) q keymap:aug-keymap<%>) (c (? . 0) q text:info-mixin) (c (? . 0) q text:wide-snip<%>) (c (? . 0) q mode:host-text<%>) (c (? . 0) q autosave:autosavable<%>) (c (? . 0) q text:1-pixel-string-snip%) (c (? . 0) q text:file<%>) (c (? . 0) q text:nbsp->space-mixin) (c (? . 0) q comment-box:snip%) (c (? . 0) q panel:dragable-mixin) (c (? . 0) q editor:backup-autosave<%>) (c (? . 0) q panel:discrete-sizes<%>) (c (? . 0) q canvas:wide-snip-mixin) (c (? . 0) q text:line-numbers-mixin) (c (? . 0) q frame:text-info<%>) (c (? . 0) q text:input-box-mixin) (c (? . 0) q frame:register-group-mixin) (c (? . 0) q text:normalize-paste<%>) (c (? . 0) q panel:single<%>) (c (? . 0) q text:autocomplete-mixin) (c (? . 0) q text:line-numbers<%>) (c (? . 0) q racket:sexp-snip<%>) (c (? . 0) q text:clever-file-format-mixin) (c (? . 0) q racket:sexp-snip%) (c (? . 0) q menu:can-restore<%>) (c (? . 0) q editor:file<%>) (c (? . 0) q frame:text-info-mixin) (c (? . 0) q canvas:info-mixin) (c (? . 0) q number-snip:snip-class%) (c (? . 0) q panel:single-mixin) (c (? . 0) q editor-snip:decorated%) (c (? . 0) q text:crlf-line-endings-mixin) (c (? . 0) q text:first-line-mixin) (c (? . 0) q panel:discrete-child<%>) (c (? . 0) q editor-snip:decorated-snipclass%) (c (? . 0) q racket:text-mode-mixin) (c (? . 0) q frame:delegate-mixin) (q lib "framework/framework-sig.rkt") (c (? . 0) q text:foreground-color-mixin) (c (? . 0) q panel:vertical-dragable-mixin) (c (? . 0) q editor:keymap<%>) (c (? . 0) q editor:info-mixin) (c (? . 0) q color:text-mode-mixin) (c (? . 0) q frame:standard-menus-mixin) (c (? . 0) q panel:single-window-mixin) (c (? . 0) q canvas:delegate-mixin) (c (? . 0) q frame:pasteboard-mixin) (c (? . 0) q frame:size-pref<%>) (c (? . 0) q frame:status-line-mixin) (c (? . 0) q panel:horizontal-dragable-mixin) (c (? . 0) q text:hide-caret/selection-mixin)) () (h ! (equal) ((c def c (c (? . 0) q frame:searchable%)) q (73898 . 4)) ((c form c (c (? . 0) q scheme:sexp-snip<%>)) q (170346 . 2)) ((c meth c (c (? . 46) q set-filename)) q (23309 . 5)) ((c def c (? . 47)) q (139875 . 4)) ((c meth c (c (? . 7) q freeze-colorer)) q (10457 . 2)) ((c meth c (c (? . 16) q highlight-range)) q (130903 . 22)) ((c def c (c (? . 0) q preferences:add-to-warnings-checkbox-panel)) q (118361 . 3)) ((c meth c (c (? . 1) q edit-menu:preferences-help-string)) q (59766 . 3)) ((c def c (c (? . 0) q color-prefs:marshall-style-delta)) q (5589 . 3)) ((c meth c (c (? . 3) q insert-return)) q (125823 . 2)) ((c meth c (c (? . 1) q file-menu:save-on-demand)) q (43156 . 4)) ((c meth c (c (? . 2) q erase-underscores)) q (89265 . 2)) ((c def c (c (? . 0) q racket:set-mode-mixin)) q (129423 . 4)) ((c def c (? . 2)) q (89170 . 3)) ((c def c (c (? . 0) q preferences:add-check)) q (119202 . 11)) ((c meth c (c (? . 35) q determine-width)) q (36485 . 7)) ((c def c (c (? . 0) q racket:short-sym->style-name)) q (130474 . 3)) ((c meth c (c (? . 1) q edit-menu:get-select-all-item)) q (51484 . 3)) ((c meth c (c (? . 1) q edit-menu:get-replace-all-item)) q (57217 . 3)) ((c form c (c (? . 0) q scheme:get-wordbreak-map)) q (170373 . 2)) ((c meth c (c (? . 4) q on-insert)) q (96337 . 9)) ((c def c (c (? . 0) q frame:pasteboard<%>)) q (67759 . 3)) ((c meth c (c (? . 1) q file-menu:save-string)) q (43283 . 2)) ((c form c (c (? . 0) q scheme:setup-keymap)) q (170463 . 2)) ((c meth c (c (? . 69) q anchor-status-changed)) q (38052 . 2)) ((c meth c (c (? . 13) q get-autocomplete-selected-color)) q (159383 . 3)) ((c meth c (c (? . 1) q file-menu:create-save-as?)) q (43548 . 3)) ((c meth c (c (? . 55) q get-map-function-table)) q (84713 . 2)) ((c meth c (c (? . 3) q introduce-let-ans)) q (128327 . 3)) ((c meth c (c (? . 5) q edit-menu:create-find-again-backwards?)) q (71697 . 3)) ((c def c (c (? . 0) q editor:get-default-color-style-name)) q (26170 . 2)) ((c meth c (c (? . 14) q clear-box-input-port)) q (157305 . 2)) ((c def c (c (? . 0) q frame:text-info%)) q (73337 . 3)) ((c meth c (c (? . 44) q get-replace-search-hit)) q (142631 . 3)) ((c def c (? . 66)) q (114106 . 2)) ((c def c (c (? . 0) q editor:set-standard-style-list-delta)) q (26231 . 5)) ((c meth c (c (? . 9) q file-menu:revert-callback)) q (65664 . 5)) ((c meth c (c (? . 10) q frame-label-changed)) q (76157 . 3)) ((c def c (? . 1)) q (38811 . 3)) ((c def c (c (? . 0) q group:create-windows-menu)) q (77291 . 3)) ((c meth c (c (? . 12) q put-file)) q (108055 . 5)) ((c meth c (c (? . 4) q can-do-edit-operation?)) q (101010 . 17)) ((c meth c (c (? . 4) q after-delete)) q (97660 . 9)) ((c meth c (c (? . 1) q file-menu:get-quit-item)) q (46005 . 3)) ((c meth c (c (? . 1) q edit-menu:select-all-callback)) q (51681 . 7)) ((c def c (c (? . 0) q canvas:delegate<%>)) q (903 . 3)) ((c def c (c (? . 6) q gui-utils:unsaved-warning)) q (79853 . 14)) ((c meth c (c (? . 18) q on-save-file)) q (24181 . 5)) ((c meth c (c (? . 5) q edit-menu:find-again-callback)) q (71083 . 6)) ((c meth c (c (? . 1) q file-menu:revert-on-demand)) q (42328 . 4)) ((c meth c (c (? . 57) q add-tall-snip)) q (144511 . 3)) ((c meth c (c (? . 8) q on-paint)) q (151557 . 19)) ((c def c (c (? . 24) q exn:make-unknown-preference)) q (121161 . 6)) ((c def c (c (? . 6) q gui-utils:format-literal-label)) q (77897 . 8)) ((c meth c (c (? . 22) q on-local-char)) q (144245 . 3)) ((c meth c (c (? . 1) q edit-menu:between-clear-and-select-all)) q (51353 . 4)) ((c def c (c (? . 11) q shutdown-splash)) q (165055 . 2)) ((c meth c (c (? . 7) q get-spell-check-text)) q (11189 . 2)) ((c meth c (c (? . 54) q get-start-of-line)) q (128912 . 4)) ((c def c (c (? . 0) q finder:dialog-parent-parameter)) q (27218 . 5)) ((c def c (c (? . 0) q panel:horizontal-dragable<%>)) q (111413 . 3)) ((c meth c (c (? . 8) q highlight-range)) q (150299 . 14)) ((c meth c (c (? . 48) q can-delete?)) q (155591 . 4)) ((c meth c (c (? . 21) q get-default-percentages)) q (110501 . 4)) ((c def c (? . 28)) q (113294 . 5)) ((c def c (c (? . 0) q exit:on-exit)) q (27106 . 2)) ((c meth c (c (? . 9) q get-filename)) q (64987 . 2)) ((c meth c (c (? . 10) q clear)) q (76783 . 2)) ((c def c (c (? . 0) q group:get-the-frame-group)) q (77042 . 2)) ((c def c (c (? . 0) q preferences:put-preferences/gui)) q (116997 . 5)) ((c meth c (c (? . 1) q get-menu-item%)) q (39051 . 3)) ((c meth c (c (? . 23) q after-delete)) q (143657 . 5)) ((c def c (c (? . 11) q set-splash-progress-bar?!)) q (166184 . 3)) ((c meth c (c (? . 1) q edit-menu:find-next-help-string)) q (54659 . 3)) ((c meth c (c (? . 3) q get-tab-size)) q (128168 . 2)) ((c meth c (c (? . 1) q help-menu:after-about)) q (60790 . 4)) ((c meth c (c (? . 12) q on-edit-sequence)) q (103529 . 2)) ((c def c (c (? . 0) q keymap:region-click)) q (88696 . 5)) ((c meth c (c (? . 9) q set-label)) q (65309 . 3)) ((c meth c (c (? . 3) q compute-racket-amount-to-indent)) q (125552 . 4)) ((c def c (c (? . 0) q keymap:get-file)) q (86864 . 2)) ((c def c (c (? . 6) q gui-utils:get-choice)) q (80385 . 22)) ((c meth c (c (? . 1) q edit-menu:find-from-selection-string)) q (53768 . 3)) ((c def c (c (? . 0) q preferences:add-editor-checkbox-panel)) q (118114 . 2)) ((c def c (c (? . 0) q editor:set-current-preferred-font-size)) q (24951 . 3)) ((c meth c (c (? . 12) q on-load-file)) q (103740 . 5)) ((c def c (c (? . 0) q handler:edit-file)) q (82718 . 6)) ((c meth c (c (? . 17) q get-editor%)) q (61567 . 3)) ((c meth c (c (? . 3) q forward-sexp)) q (126703 . 3)) ((c def c (c (? . 0) q color-prefs:register-info-based-color-schemes)) q (7164 . 2)) ((c def c (c (? . 0) q panel:dragable-container-size)) q (114986 . 7)) ((c meth c (c (? . 1) q edit-menu:between-redo-and-cut)) q (48158 . 4)) ((c meth c (c (? . 39) q get-delegate)) q (144822 . 3)) ((c def c (c (? . 0) q text:autocomplete-limit)) q (163186 . 4)) ((c meth c (c (? . 1) q edit-menu:find-next-callback)) q (54148 . 7)) ((c def c (c (? . 11) q get-splash-paint-callback)) q (165533 . 7)) ((c meth c (c (? . 3) q select-down-sexp)) q (127910 . 2)) ((c def c (c (? . 15) q test:keystroke)) q (167982 . 6)) ((c def c (? . 98)) q (60904 . 4)) ((c meth c (c (? . 19) q put-file)) q (135972 . 5)) ((c meth c (c (? . 1) q edit-menu:copy-callback)) q (49254 . 6)) ((c meth c (c (? . 70) q on-default-char)) q (158932 . 3)) ((c meth c (c (? . 51) q on-disable-surrogate)) q (90071 . 3)) ((c meth c (c (? . 13) q get-all-words)) q (159621 . 2)) ((c meth c (c (? . 14) q submit-to-port?)) q (156861 . 3)) ((c def c (? . 53)) q (68192 . 4)) ((c meth c (c (? . 1) q edit-menu:create-find-from-selection?)) q (53205 . 3)) ((c meth c (c (? . 1) q edit-menu:find-next-on-demand)) q (54457 . 4)) ((c def c (c (? . 0) q racket:text%)) q (129577 . 4)) ((c def c (c (? . 0) q keymap:setup-editor)) q (87940 . 3)) ((c def c (c (? . 0) q icon:get-up/down-cursor)) q (84374 . 2)) ((c def c (c (? . 0) q canvas:color%)) q (2284 . 3)) ((c meth c (c (? . 38) q save-file/gui-error)) q (18946 . 9)) ((c def c (c (? . 15) q test:run-one)) q (169377 . 3)) ((c def c (c (? . 0) q preferences:add-panel)) q (117429 . 12)) ((c meth c (c (? . 102) q adjust-size-when-monitor-setup-changes?)) q (33544 . 3)) ((c meth c (c (? . 14) q send-eof-to-in-port)) q (157009 . 2)) ((c meth c (c (? . 4) q on-default-event)) q (91008 . 7)) ((c meth c (c (? . 3) q tabify-all)) q (125500 . 2)) ((c meth c (c (? . 16) q get-highlighted-ranges)) q (133225 . 3)) ((c meth c (c (? . 1) q help-menu:before-about)) q (59973 . 4)) ((c meth c (c (? . 17) q get-canvas<%>)) q (61492 . 2)) ((c meth c (c (? . 18) q on-close)) q (24435 . 2)) ((c def c (? . 27)) q (69331 . 3)) ((c meth c (c (? . 17) q save-as)) q (61985 . 4)) ((c form c (c (? . 0) q scheme:set-mode-mixin)) q (170292 . 2)) ((c meth c (c (? . 37) q after-insert)) q (141758 . 5)) ((c meth c (c (? . 71) q on-close)) q (35444 . 2)) ((c meth c (c (? . 25) q open-status-line)) q (35669 . 3)) ((c def c (c (? . 6) q gui-utils:get-clicked-clickback-delta)) q (81428 . 4)) ((c meth c (c (? . 40) q show)) q (32697 . 3)) ((c def c (c (? . 0) q icon:get-left/right-cursor)) q (84311 . 2)) ((c meth c (c (? . 9) q file-menu:create-print?)) q (66705 . 2)) ((c def c (c (? . 0) q color-prefs:set-current-color-scheme)) q (7233 . 3)) ((c def c (? . 73)) q (108847 . 3)) ((c meth c (c (? . 12) q on-default-event)) q (103385 . 3)) ((c def c (c (? . 0) q exit:user-oks-exit)) q (27173 . 2)) ((c meth c (c (? . 1) q edit-menu:select-all-on-demand)) q (51977 . 4)) ((c def c (? . 36)) q (33191 . 4)) ((c def c (c (? . 0) q color-prefs:unmarshall-style-delta)) q (5708 . 4)) ((c def c (c (? . 0) q frame:delegate%)) q (74017 . 3)) ((c meth c (c (? . 1) q edit-menu:find-on-demand)) q (52811 . 4)) ((c meth c (c (? . 1) q edit-menu:between-find-and-preferences)) q (58905 . 4)) ((c def c (c (? . 0) q frame:pasteboard%)) q (74108 . 3)) ((c form c (c (? . 0) q scheme:init-wordbreak-map)) q (170405 . 2)) ((c def c (c (? . 0) q pasteboard:basic%)) q (116167 . 3)) ((c def c (c (? . 0) q preferences:add-on-close-dialog-callback)) q (119016 . 3)) ((c meth c (c (? . 5) q edit-menu:create-find-again?)) q (71304 . 3)) ((c meth c (c (? . 50) q add-wide-snip)) q (1677 . 3)) ((c def c (c (? . 0) q preferences:add-font-panel)) q (118872 . 2)) ((c def c (c (? . 11) q set-splash-paint-callback)) q (165908 . 8)) ((c def c (c (? . 0) q editor:set-change-font-size-when-monitors-change?)) q (25865 . 3)) ((c def c (c (? . 0) q pasteboard:keymap%)) q (116371 . 3)) ((c meth c (c (? . 4) q on-delete)) q (95992 . 9)) ((c def c (c (? . 0) q frame:setup-size-pref)) q (74199 . 13)) ((c meth c (c (? . 52) q get-filename)) q (32355 . 3)) ((c form c (c (? . 0) q scheme:text-mode-mixin)) q (170237 . 2)) ((c meth c (c (? . 16) q get-styles-fixed)) q (133305 . 2)) ((c meth c (c (? . 12) q on-change)) q (103171 . 2)) ((c def c (c (? . 0) q text:clever-file-format<%>)) q (154200 . 3)) ((c meth c (c (? . 19) q on-insert)) q (135685 . 4)) ((c meth c (c (? . 1) q edit-menu:create-find-previous?)) q (54861 . 3)) ((c def c (c (? . 0) q icon:get-autowrap-bitmap)) q (84075 . 2)) ((c meth c (c (? . 10) q get-mdi-parent)) q (75997 . 3)) ((c def c (? . 20)) q (37384 . 4)) ((c meth c (c (? . 20) q on-close)) q (37767 . 2)) ((c def c (c (? . 0) q color-prefs:add-background-preferences-panel)) q (4696 . 2)) ((c meth c (c (? . 21) q after-percentage-change)) q (110433 . 2)) ((c meth c (c (? . 1) q file-menu:save-help-string)) q (43357 . 3)) ((c def c (? . 22)) q (143995 . 4)) ((c meth c (c (? . 23) q after-insert)) q (143461 . 5)) ((c def c (c (? . 24) q preferences:default-set?)) q (120555 . 3)) ((c def c (? . 3)) q (124723 . 5)) ((c meth c (c (? . 33) q get-editor<%>)) q (67701 . 2)) ((c form c (c (? . 0) q scheme:get-keymap)) q (170438 . 2)) ((c meth c (c (? . 97) q on-enable-surrogate)) q (15361 . 2)) ((c meth c (c (? . 41) q is-special-first-line?)) q (136707 . 3)) ((c def c (c (? . 0) q panel:single%)) q (110146 . 3)) ((c meth c (c (? . 1) q edit-menu:replace-all-help-string)) q (57947 . 3)) ((c def c (c (? . 0) q color-model:xyz->rgb)) q (3203 . 5)) ((c meth c (c (? . 1) q file-menu:new-callback)) q (39676 . 6)) ((c def c (? . 89)) q (17984 . 3)) ((c def c (c (? . 0) q racket:get-color-prefs-table)) q (130163 . 3)) ((c def c (? . 62)) q (139272 . 4)) ((c def c (c (? . 0) q color-prefs:lookup-in-color-scheme)) q (7593 . 6)) ((c def c (c (? . 0) q text:range-color)) q (162953 . 3)) ((c def c (c (? . 0) q frame:size-pref%)) q (73171 . 3)) ((c meth c (c (? . 1) q help-menu:about-callback)) q (60275 . 6)) ((c meth c (c (? . 4) q after-set-size-constraint)) q (98577 . 7)) ((c meth c (c (? . 1) q file-menu:save-as-string)) q (44061 . 3)) ((c def c (c (? . 0) q pasteboard:file%)) q (116478 . 3)) ((c meth c (c (? . 17) q get-entire-label)) q (61202 . 2)) ((c def c (c (? . 0) q color:text-mode<%>)) q (14562 . 2)) ((c meth c (c (? . 25) q update-status-line)) q (35844 . 5)) ((c meth c (c (? . 83) q read)) q (108298 . 4)) ((c meth c (c (? . 26) q after-insert)) q (14378 . 2)) ((c meth c (c (? . 1) q edit-menu:get-preferences-item)) q (59036 . 3)) ((c meth c (c (? . 10) q set-active-frame)) q (76491 . 3)) ((c def c (c (? . 15) q label-of-enabled/shown-button-in-top-level-window?)) q (169704 . 4)) ((c meth c (c (? . 42) q get-text-to-search)) q (72826 . 3)) ((c meth c (c (? . 29) q get-menu)) q (17333 . 3)) ((c form c (c (? . 31) q decorated-editor-snip-mixin)) q (16386 . 2)) ((c meth c (c (? . 1) q help-menu:create-about?)) q (60197 . 3)) ((c meth c (c (? . 12) q after-save-file)) q (106832 . 3)) ((c def c (c (? . 0) q text:delegate%)) q (160602 . 3)) ((c meth c (c (? . 30) q reset-min-sizes)) q (16915 . 2)) ((c meth c (c (? . 16) q get-start-of-line)) q (134630 . 4)) ((c meth c (c (? . 4) q on-focus)) q (91964 . 7)) ((c meth c (c (? . 68) q on-paint)) q (162211 . 2)) ((c meth c (c (? . 7) q is-stopped?)) q (10348 . 2)) ((c meth c (c (? . 12) q after-change-style)) q (106082 . 5)) ((c meth c (c (? . 14) q insert-before)) q (156756 . 3)) ((c def c (c (? . 0) q preferences:get-preference/gui)) q (117183 . 6)) ((c meth c (c (? . 9) q file-menu:save-as-callback)) q (66216 . 5)) ((c meth c (c (? . 26) q after-edit-sequence)) q (14137 . 2)) ((c meth c (c (? . 34) q split)) q (147833 . 7)) ((c def c (c (? . 11) q get-splash-height)) q (166768 . 2)) ((c meth c (c (? . 1) q edit-menu:cut-on-demand)) q (48678 . 4)) ((c meth c (c (? . 1) q edit-menu:find-previous-string)) q (55394 . 3)) ((c def c (c (? . 0) q editor:set-standard-style-list-pref-callbacks)) q (26413 . 2)) ((c meth c (c (? . 27) q replace-all)) q (69585 . 2)) ((c def c (c (? . 0) q editor:font-size-pref->current-font-size)) q (25151 . 16)) ((c meth c (c (? . 4) q after-save-file)) q (99356 . 7)) ((c meth c (c (? . 1) q file-menu:between-close-and-quit)) q (45880 . 4)) ((c meth c (c (? . 28) q collapse)) q (114010 . 3)) ((c def c (c (? . 0) q text:wide-snip%)) q (160692 . 3)) ((c meth c (c (? . 86) q after-load-file)) q (154918 . 4)) ((c def c (c (? . 0) q frame:status-line%)) q (73528 . 3)) ((c meth c (c (? . 32) q after-edit-sequence)) q (21020 . 2)) ((c meth c (c (? . 91) q get-editor<%>)) q (69190 . 2)) ((c meth c (c (? . 29) q get-color)) q (17241 . 3)) ((c def c (c (? . 0) q racket:add-coloring-preferences-panel)) q (130104 . 2)) ((c def c (? . 60)) q (145014 . 3)) ((c def c (c (? . 0) q icon:get-anchor-bitmap)) q (84252 . 2)) ((c meth c (c (? . 30) q get-color)) q (16634 . 3)) ((c def c (c (? . 0) q racket:add-preferences-panel)) q (129998 . 2)) ((c form c (c (? . 31) q decorated-editor-snipclass%)) q (16351 . 2)) ((c meth c (c (? . 56) q set-overwrite-mode)) q (153773 . 3)) ((c meth c (c (? . 32) q after-save-file)) q (20689 . 3)) ((c def c (c (? . 0) q handler:install-recent-items)) q (83348 . 3)) ((c def c (c (? . 0) q editor:keymap-mixin)) q (22361 . 4)) ((c meth c (c (? . 75) q show-line-numbers?)) q (161901 . 2)) ((c meth c (c (? . 1) q edit-menu:paste-on-demand)) q (50273 . 4)) ((c meth c (c (? . 7) q get-spell-check-strings)) q (11034 . 2)) ((c constructor c (? . 33)) q (67578 . 4)) ((c def c (c (? . 0) q color:text%)) q (14484 . 3)) ((c meth c (c (? . 34) q get-extent)) q (148203 . 22)) ((c def c (c (? . 0) q editor:set-default-font-color)) q (25962 . 5)) ((c meth c (c (? . 8) q unhighlight-range)) q (150977 . 12)) ((c def c (? . 59)) q (123 . 2)) ((c def c (? . 105)) q (138964 . 4)) ((c meth c (c (? . 4) q on-load-file)) q (92226 . 9)) ((c def c (? . 63)) q (15721 . 4)) ((c meth c (c (? . 14) q get-err-port)) q (157836 . 2)) ((c meth c (c (? . 1) q edit-menu:find-help-string)) q (53002 . 3)) ((c meth c (c (? . 16) q port-name-matches?)) q (134309 . 3)) ((c meth c (c (? . 12) q can-load-file?)) q (107719 . 5)) ((c meth c (c (? . 35) q lock-status-changed)) q (36746 . 2)) ((c def c (c (? . 0) q preferences:show-dialog)) q (118922 . 2)) ((c meth c (c (? . 36) q show)) q (33334 . 3)) ((c meth c (c (? . 14) q set-unread-start-point)) q (156396 . 3)) ((c meth c (c (? . 3) q mark-matching-parenthesis)) q (128060 . 3)) ((c def c (c (? . 24) q preferences:restore-defaults)) q (120917 . 2)) ((c meth c (c (? . 12) q on-focus)) q (103666 . 3)) ((c meth c (c (? . 23) q on-focus)) q (143853 . 3)) ((c meth c (c (? . 10) q for-each-frame)) q (76315 . 3)) ((c meth c (c (? . 1) q edit-menu:get-undo-item)) q (46812 . 3)) ((c meth c (c (? . 35) q hide-info)) q (37275 . 2)) ((c meth c (c (? . 12) q on-local-event)) q (103987 . 3)) ((c def c (? . 45)) q (158191 . 4)) ((c meth c (c (? . 37) q do-paste)) q (141367 . 5)) ((c meth c (c (? . 38) q load-file/gui-error)) q (19343 . 9)) ((c def c (c (? . 0) q keymap:send-map-function-meta)) q (87273 . 13)) ((c def c (? . 25)) q (35591 . 3)) ((c meth c (c (? . 16) q initial-autowrap-bitmap)) q (134136 . 3)) ((c meth c (c (? . 4) q on-new-tab-snip)) q (96885 . 5)) ((c def c (c (? . 0) q exit:set-exiting)) q (26800 . 3)) ((c meth c (c (? . 7) q reset-region)) q (10707 . 4)) ((c def c (c (? . 0) q menu:can-restore-underscore-mixin)) q (89418 . 4)) ((c meth c (c (? . 78) q get-extent)) q (123648 . 22)) ((c def c (? . 81)) q (38314 . 4)) ((c meth c (c (? . 1) q file-menu:between-open-and-revert)) q (41713 . 4)) ((c meth c (c (? . 14) q send-eof-to-box-in-port)) q (157069 . 2)) ((c meth c (c (? . 8) q after-change-style)) q (152979 . 5)) ((c def c (c (? . 0) q text:info<%>)) q (153448 . 3)) ((c meth c (c (? . 7) q forward-match)) q (12718 . 6)) ((c def c (c (? . 0) q text:get-completions/manuals)) q (163359 . 3)) ((c def c (c (? . 0) q number-snip:make-fraction-snip)) q (108619 . 6)) ((c meth c (c (? . 5) q on-close)) q (72445 . 2)) ((c def c (? . 43)) q (84877 . 4)) ((c meth c (c (? . 18) q set-modified)) q (24560 . 3)) ((c meth c (c (? . 1) q edit-menu:find-case-sensitive-help-string)) q (58810 . 3)) ((c meth c (c (? . 38) q on-close)) q (19743 . 2)) ((c def c (c (? . 0) q frame:basic%)) q (73068 . 3)) ((c def c (c (? . 15) q test:set-check-box!)) q (167486 . 4)) ((c def c (c (? . 0) q menu:can-restore-checkable-menu-item%)) q (89694 . 3)) ((c def c (c (? . 24) q preferences:low-level-get-preference)) q (121754 . 5)) ((c def c (c (? . 24) q preferences:unregister-save-callback)) q (121076 . 3)) ((c meth c (c (? . 17) q revert)) q (61777 . 2)) ((c meth c (c (? . 1) q edit-menu:find-previous-on-demand)) q (55268 . 4)) ((c meth c (c (? . 1) q edit-menu:copy-on-demand)) q (49471 . 4)) ((c def c (? . 88)) q (114333 . 2)) ((c meth c (c (? . 1) q file-menu:open-on-demand)) q (40718 . 4)) ((c def c (c (? . 0) q text:range-style)) q (162859 . 3)) ((c def c (? . 39)) q (144749 . 3)) ((c meth c (c (? . 1) q file-menu:quit-callback)) q (46190 . 6)) ((c def c (c (? . 0) q frame:pasteboard-info%)) q (73424 . 3)) ((c meth c (c (? . 1) q file-menu:create-save?)) q (42850 . 3)) ((c meth c (c (? . 2) q restore-underscores)) q (89340 . 3)) ((c def c (c (? . 0) q color-prefs:color-scheme-style-name?)) q (7505 . 3)) ((c def c (c (? . 0) q version:add-spec)) q (170004 . 4)) ((c meth c (c (? . 1) q edit-menu:undo-help-string)) q (47405 . 3)) ((c meth c (c (? . 1) q edit-menu:preferences-string)) q (59684 . 3)) ((c meth c (c (? . 40) q on-drop-file)) q (32962 . 3)) ((c meth c (c (? . 4) q can-save-file?)) q (102053 . 9)) ((c meth c (c (? . 4) q on-new-string-snip)) q (96682 . 6)) ((c meth c (c (? . 10) q get-frames)) q (76078 . 3)) ((c def c (c (? . 0) q handler:insert-format-handler)) q (82119 . 7)) ((c def c (? . 95)) q (22205 . 3)) ((c meth c (c (? . 21) q get-percentages)) q (111091 . 2)) ((c def c (c (? . 0) q panel:splitter<%>)) q (113251 . 2)) ((c meth c (c (? . 1) q edit-menu:find-from-selection-on-demand)) q (53636 . 4)) ((c meth c (c (? . 26) q after-set-position)) q (14197 . 2)) ((c meth c (c (? . 41) q first-line-currently-drawn-specially?)) q (136551 . 3)) ((c def c (c (? . 0) q exit:exiting?)) q (26760 . 2)) ((c meth c (c (? . 4) q after-edit-sequence)) q (98863 . 6)) ((c meth c (c (? . 12) q on-delete)) q (105694 . 4)) ((c meth c (c (? . 1) q file-menu:between-print-and-close)) q (45052 . 4)) ((c meth c (c (? . 14) q get-box-input-editor-snip%)) q (158017 . 3)) ((c meth c (c (? . 1) q edit-menu:get-clear-item)) q (50673 . 3)) ((c meth c (c (? . 1) q edit-menu:undo-callback)) q (46997 . 6)) ((c def c (c (? . 15) q test:get-active-top-level-window)) q (169603 . 3)) ((c def c (c (? . 0) q text:range-start)) q (162590 . 3)) ((c def c (c (? . 0) q frame:pasteboard-info-mixin)) q (38652 . 4)) ((c def c (? . 74)) q (159796 . 4)) ((c meth c (c (? . 27) q search-replace)) q (69521 . 2)) ((c def c (? . 5)) q (70780 . 4)) ((c def c (c (? . 15) q test:set-list-box!)) q (167806 . 4)) ((c def c (c (? . 0) q handler:set-recent-position)) q (83645 . 7)) ((c def c (? . 32)) q (20378 . 4)) ((c def c (? . 94)) q (112529 . 4)) ((c meth c (c (? . 38) q get-top-level-window)) q (18775 . 3)) ((c meth c (c (? . 1) q edit-menu:create-find-next?)) q (54066 . 3)) ((c def c (c (? . 24) q preferences:add-callback)) q (119817 . 5)) ((c def c (c (? . 0) q text:wide-snip-mixin)) q (144605 . 4)) ((c def c (c (? . 0) q group:can-close-check)) q (77149 . 2)) ((c meth c (c (? . 38) q close)) q (19852 . 2)) ((c def c (c (? . 0) q text:range?)) q (162529 . 3)) ((c meth c (c (? . 1) q edit-menu:get-find-item)) q (52397 . 3)) ((c def c (c (? . 0) q handler:size-recently-opened-files)) q (83868 . 3)) ((c def c (c (? . 0) q keymap:get-editor)) q (86810 . 2)) ((c meth c (c (? . 17) q make-editor)) q (61708 . 2)) ((c def c (c (? . 0) q racket:get-wordbreak-map)) q (130565 . 2)) ((c meth c (c (? . 1) q edit-menu:get-cut-item)) q (48281 . 3)) ((c meth c (c (? . 32) q on-edit-sequence)) q (20957 . 2)) ((c def c (c (? . 24) q preferences:snapshot?)) q (121968 . 3)) ((c def c (c (? . 0) q canvas:basic%)) q (2200 . 3)) ((c def c (c (? . 15) q test:use-focus-table)) q (169438 . 4)) ((c meth c (c (? . 10) q can-close-all?)) q (76877 . 2)) ((c def c (c (? . 0) q handler:handler-extension)) q (81852 . 4)) ((c def c (? . 42)) q (72616 . 5)) ((c meth c (c (? . 43) q chain-to-keymap)) q (85021 . 5)) ((c meth c (c (? . 8) q resized)) q (152414 . 5)) ((c meth c (c (? . 38) q get-pos/text-dc-location)) q (20139 . 7)) ((c meth c (c (? . 1) q file-menu:open-recent-string)) q (41544 . 3)) ((c def c (c (? . 0) q text:return<%>)) q (143932 . 3)) ((c def c (c (? . 0) q keymap:add-to-right-button-menu/before)) q (86309 . 5)) ((c meth c (c (? . 44) q get-search-hit-count)) q (142564 . 2)) ((c def c (c (? . 6) q gui-utils:ok/cancel-buttons)) q (78216 . 14)) ((c meth c (c (? . 45) q on-local-char)) q (158577 . 3)) ((c meth c (c (? . 4) q on-edit-sequence)) q (91497 . 5)) ((c meth c (c (? . 1) q file-menu:between-save-as-and-print)) q (44222 . 4)) ((c form c (c (? . 0) q scheme:sexp-snip%)) q (170321 . 2)) ((c def c (c (? . 0) q preferences:add-to-editor-checkbox-panel)) q (118617 . 3)) ((c meth c (c (? . 1) q file-menu:get-close-item)) q (45178 . 3)) ((c meth c (c (? . 12) q on-new-string-snip)) q (105898 . 2)) ((c meth c (c (? . 46) q get-keymaps)) q (23534 . 3)) ((c def c (c (? . 6) q gui-utils:quote-literal-label)) q (77618 . 7)) ((c meth c (c (? . 12) q on-event)) q (103588 . 3)) ((c meth c (c (? . 7) q backward-match)) q (12232 . 6)) ((c def c (c (? . 0) q frame:current-icon)) q (75321 . 10)) ((c meth c (c (? . 4) q on-snip-modified)) q (95245 . 9)) ((c meth c (c (? . 3) q find-up-sexp)) q (127218 . 4)) ((c meth c (c (? . 3) q tabify-on-return?)) q (125059 . 2)) ((c def c (c (? . 0) q color:misspelled-text-color-style-name)) q (15664 . 2)) ((c meth c (c (? . 12) q on-paint)) q (104518 . 19)) ((c def c (c (? . 6) q gui-utils:get-clickback-delta)) q (81567 . 4)) ((c def c (c (? . 0) q panel:single-pane%)) q (110250 . 3)) ((c def c (c (? . 11) q set-refresh-splash-on-gauge-change?!)) q (166530 . 5)) ((c def c (c (? . 0) q text:return%)) q (161089 . 3)) ((c def c (c (? . 0) q frame:pasteboard-info<%>)) q (38571 . 3)) ((c meth c (c (? . 9) q edit-menu:between-select-all-and-find)) q (66899 . 4)) ((c meth c (c (? . 7) q get-spell-suggestions)) q (11517 . 6)) ((c meth c (c (? . 7) q thaw-colorer)) q (10512 . 5)) ((c def c (c (? . 0) q icon:get-gc-off-bitmap)) q (84492 . 2)) ((c meth c (c (? . 47) q on-change)) q (140916 . 2)) ((c def c (c (? . 0) q keymap:canonicalize-keybinding-string)) q (86693 . 4)) ((c meth c (c (? . 34) q copy)) q (148136 . 2)) ((c def c (c (? . 6) q gui-utils:cursor-delay)) q (79089 . 4)) ((c meth c (c (? . 1) q file-menu:print-help-string)) q (44971 . 3)) ((c def c (c (? . 0) q panel:vertical-dragable<%>)) q (111326 . 3)) ((c def c (c (? . 0) q text:searching%)) q (161567 . 3)) ((c meth c (c (? . 9) q help-menu:about-callback)) q (67026 . 5)) ((c def c (c (? . 0) q racket:short-sym->pref-name)) q (130384 . 3)) ((c meth c (c (? . 16) q move/copy-to-edit)) q (133524 . 13)) ((c meth c (c (? . 1) q edit-menu:show/hide-replace-callback)) q (55778 . 7)) ((c def c (c (? . 0) q editor:standard-style-list-mixin)) q (22041 . 4)) ((c def c (? . 77)) q (154275 . 4)) ((c meth c (c (? . 4) q on-new-box)) q (93150 . 7)) ((c meth c (c (? . 46) q can-close?)) q (23478 . 2)) ((c def c (c (? . 0) q panel:horizontal-dragable%)) q (113126 . 4)) ((c meth c (c (? . 1) q edit-menu:create-select-all?)) q (51598 . 3)) ((c meth c (c (? . 21) q get-vertical?)) q (111163 . 2)) ((c meth c (c (? . 1) q edit-menu:preferences-callback)) q (59235 . 7)) ((c meth c (c (? . 3) q get-forward-sexp)) q (126498 . 4)) ((c def c (c (? . 0) q frame:register-group<%>)) q (35174 . 2)) ((c def c (c (? . 0) q racket:text-mode%)) q (129734 . 3)) ((c meth c (c (? . 3) q get-limit)) q (124856 . 3)) ((c constructor c (? . 49)) q (33780 . 16)) ((c meth c (c (? . 1) q edit-menu:show/hide-replace-help-string)) q (56339 . 3)) ((c meth c (c (? . 42) q get-editor%)) q (72989 . 3)) ((c meth c (c (? . 64) q on-subwindow-event)) q (111795 . 5)) ((c meth c (c (? . 48) q after-load-file)) q (155792 . 2)) ((c def c (? . 19)) q (134754 . 5)) ((c meth c (c (? . 1) q edit-menu:cut-callback)) q (48463 . 6)) ((c meth c (c (? . 1) q edit-menu:cut-help-string)) q (48867 . 3)) ((c def c (? . 12)) q (103075 . 3)) ((c def c (? . 14)) q (155847 . 2)) ((c meth c (c (? . 14) q get-value-style-delta)) q (157558 . 3)) ((c def c (c (? . 0) q text:line-spacing-mixin)) q (136242 . 4)) ((c meth c (c (? . 38) q has-focus?)) q (18448 . 2)) ((c meth c (c (? . 9) q help-menu:about-string)) q (67233 . 2)) ((c form c (c (? . 31) q decorated-editor-snip%)) q (16321 . 2)) ((c def c (c (? . 0) q text:hide-caret/selection<%>)) q (138879 . 3)) ((c def c (c (? . 0) q frame:remove-empty-menus)) q (75234 . 3)) ((c meth c (c (? . 1) q edit-menu:redo-on-demand)) q (47887 . 4)) ((c def c (c (? . 15) q test:close-top-level-window)) q (169070 . 3)) ((c meth c (c (? . 49) q on-size)) q (34818 . 5)) ((c def c (c (? . 0) q preferences:add-to-general-checkbox-panel)) q (118744 . 3)) ((c meth c (c (? . 43) q remove-chained-keymap)) q (85211 . 3)) ((c meth c (c (? . 5) q edit-menu:replace-all-on-demand)) q (71867 . 4)) ((c meth c (c (? . 29) q get-position)) q (17429 . 3)) ((c def c (c (? . 0) q keymap:setup-file)) q (88025 . 3)) ((c meth c (c (? . 42) q get-editor<%>)) q (72908 . 3)) ((c meth c (c (? . 3) q tabify-selection)) q (125252 . 5)) ((c meth c (c (? . 16) q get-port-name)) q (134226 . 3)) ((c meth c (c (? . 3) q box-comment-out-selection)) q (125878 . 6)) ((c meth c (c (? . 61) q get-read-write?)) q (155119 . 2)) ((c meth c (c (? . 21) q right-click-in-gap)) q (110673 . 7)) ((c meth c (c (? . 1) q get-help-menu)) q (39419 . 2)) ((c meth c (c (? . 1) q edit-menu:create-preferences?)) q (59151 . 3)) ((c meth c (c (? . 34) q draw)) q (149323 . 21)) ((c meth c (c (? . 72) q string-normalize)) q (141121 . 3)) ((c meth c (c (? . 8) q on-edit-sequence)) q (152291 . 2)) ((c meth c (c (? . 76) q get-saved-snips)) q (122261 . 3)) ((c def c (? . 50)) q (1540 . 3)) ((c meth c (c (? . 14) q on-submit)) q (156959 . 2)) ((c meth c (c (? . 1) q get-checkable-menu-item%)) q (39150 . 3)) ((c def c (? . 44)) q (141966 . 4)) ((c meth c (c (? . 9) q can-close?)) q (65202 . 2)) ((c meth c (c (? . 1) q file-menu:after-quit)) q (46700 . 3)) ((c meth c (c (? . 85) q make-snip)) q (17727 . 3)) ((c meth c (c (? . 51) q on-enable-surrogate)) q (89970 . 3)) ((c def c (c (? . 0) q color-prefs:add-color-scheme-preferences-panel)) q (7020 . 4)) ((c meth c (c (? . 4) q on-save-file)) q (94882 . 9)) ((c def c (c (? . 0) q finder:common-put-file)) q (27744 . 17)) ((c meth c (c (? . 1) q file-menu:get-open-recent-item)) q (40999 . 3)) ((c meth c (c (? . 1) q file-menu:create-quit?)) q (46113 . 3)) ((c def c (c (? . 0) q handler:current-create-new-window)) q (82997 . 5)) ((c def c (? . 38)) q (18380 . 3)) ((c meth c (c (? . 1) q edit-menu:create-clear?)) q (50782 . 3)) ((c meth c (c (? . 52) q editing-this-file?)) q (32259 . 3)) ((c def c (c (? . 0) q editor:get-change-font-size-when-monitors-change?)) q (25789 . 2)) ((c def c (c (? . 0) q color-prefs:set-in-color-scheme)) q (7819 . 7)) ((c meth c (c (? . 53) q set-delegated-text)) q (68400 . 3)) ((c meth c (c (? . 9) q help-menu:create-about?)) q (67299 . 2)) ((c meth c (c (? . 65) q autosave?)) q (23761 . 2)) ((c meth c (c (? . 14) q insert/io)) q (156004 . 4)) ((c def c (? . 54)) q (128529 . 7)) ((c meth c (c (? . 1) q edit-menu:paste-string)) q (50391 . 2)) ((c def c (c (? . 0) q icon:get-gc-on-bitmap)) q (84434 . 2)) ((c def c (c (? . 0) q handler:open-file)) q (83211 . 4)) ((c def c (c (? . 11) q get-splash-width)) q (166707 . 2)) ((c def c (c (? . 0) q editor:get-current-preferred-font-size)) q (25067 . 3)) ((c meth c (c (? . 12) q on-new-box)) q (104071 . 3)) ((c def c (c (? . 0) q editor:get-standard-style-list)) q (26480 . 2)) ((c meth c (c (? . 82) q on-focus)) q (1438 . 2)) ((c meth c (c (? . 1) q edit-menu:get-copy-item)) q (49069 . 3)) ((c meth c (c (? . 55) q get-chained-keymaps)) q (84622 . 3)) ((c def c (? . 21)) q (110330 . 4)) ((c meth c (c (? . 1) q edit-menu:find-case-sensitive-callback)) q (58249 . 7)) ((c meth c (c (? . 16) q get-edition-number)) q (134549 . 3)) ((c meth c (c (? . 58) q get-surrogate)) q (102833 . 3)) ((c meth c (c (? . 56) q set-anchor)) q (153700 . 3)) ((c meth c (c (? . 32) q put-file)) q (21751 . 5)) ((c def c (c (? . 0) q text:lookup-port-name)) q (163483 . 4)) ((c def c (c (? . 15) q test:top-level-focus-window-has?)) q (169169 . 3)) ((c meth c (c (? . 14) q get-in-box-port)) q (157714 . 2)) ((c meth c (c (? . 1) q edit-menu:replace-callback)) q (56623 . 7)) ((c meth c (c (? . 1) q edit-menu:undo-string)) q (47331 . 2)) ((c meth c (c (? . 12) q on-insert)) q (105796 . 4)) ((c def c (? . 57)) q (144343 . 3)) ((c meth c (c (? . 1) q file-menu:quit-string)) q (46546 . 2)) ((c meth c (c (? . 96) q lock)) q (24874 . 3)) ((c meth c (c (? . 1) q edit-menu:cut-string)) q (48794 . 2)) ((c meth c (c (? . 3) q transpose-sexp)) q (127968 . 3)) ((c meth c (c (? . 10) q locate-file)) q (76931 . 4)) ((c meth c (c (? . 20) q make-root-area-container)) q (37521 . 6)) ((c def c (? . 49)) q (33633 . 4)) ((c meth c (c (? . 14) q get-out-port)) q (157776 . 2)) ((c meth c (c (? . 9) q file-menu:create-save-as?)) q (66427 . 2)) ((c def c (? . 58)) q (102790 . 2)) ((c def c (c (? . 0) q color-prefs:add-color-scheme-entry)) q (5965 . 20)) ((c def c (c (? . 0) q pasteboard:info%)) q (116678 . 3)) ((c meth c (c (? . 1) q file-menu:print-string)) q (44896 . 2)) ((c meth c (c (? . 12) q on-set-size-constraint)) q (106017 . 2)) ((c meth c (c (? . 1) q file-menu:open-help-string)) q (40919 . 3)) ((c meth c (c (? . 12) q after-load-file)) q (106741 . 3)) ((c meth c (c (? . 59) q do-autosave)) q (172 . 2)) ((c meth c (c (? . 67) q on-size)) q (2019 . 5)) ((c meth c (c (? . 1) q edit-menu:create-redo?)) q (47593 . 3)) ((c meth c (c (? . 35) q is-info-hidden?)) q (37325 . 2)) ((c def c (c (? . 0) q autosave:restore-autosave-files/gui)) q (414 . 2)) ((c def c (? . 16)) q (130810 . 4)) ((c def c (? . 46)) q (23168 . 4)) ((c meth c (c (? . 52) q make-visible)) q (32477 . 3)) ((c meth c (c (? . 1) q edit-menu:paste-callback)) q (50054 . 6)) ((c def c (c (? . 0) q color-prefs:set-default/color-scheme)) q (3637 . 8)) ((c meth c (c (? . 44) q set-replace-start)) q (142713 . 3)) ((c def c (? . 79)) q (88861 . 3)) ((c def c (c (? . 0) q keymap:remove-user-keybindings-file)) q (85599 . 4)) ((c meth c (c (? . 26) q after-change-style)) q (14256 . 2)) ((c form c (c (? . 0) q scheme:text%)) q (170190 . 2)) ((c meth c (c (? . 14) q delete/io)) q (155886 . 4)) ((c def c (c (? . 0) q preferences:add-warnings-checkbox-panel)) q (118237 . 2)) ((c def c (c (? . 0) q frame:lookup-focus-table)) q (75792 . 4)) ((c meth c (c (? . 30) q get-menu)) q (16726 . 3)) ((c meth c (c (? . 1) q edit-menu:replace-all-callback)) q (57416 . 7)) ((c def c (c (? . 15) q test:run-interval)) q (168723 . 4)) ((c def c (c (? . 0) q preferences:add-to-scheme-checkbox-panel)) q (118490 . 3)) ((c def c (c (? . 0) q color-prefs:register-color-scheme-entry-change-callback)) q (8135 . 12)) ((c meth c (c (? . 58) q set-surrogate)) q (102937 . 3)) ((c meth c (c (? . 60) q copy)) q (145399 . 2)) ((c meth c (c (? . 61) q while-unlocked)) q (155177 . 3)) ((c def c (c (? . 0) q color-model:xyz-z)) q (3560 . 3)) ((c def c (c (? . 0) q canvas:wide-snip%)) q (2537 . 3)) ((c meth c (c (? . 62) q on-insert)) q (139412 . 5)) ((c meth c (c (? . 8) q after-delete)) q (152785 . 5)) ((c meth c (c (? . 63) q make-snip)) q (15896 . 2)) ((c meth c (c (? . 28) q split-vertical)) q (113492 . 7)) ((c def c (c (? . 0) q keymap:get-global)) q (86968 . 2)) ((c def c (c (? . 0) q text:line-spacing%)) q (160197 . 3)) ((c meth c (c (? . 12) q on-new-tab-snip)) q (105959 . 2)) ((c def c (c (? . 0) q color-prefs:known-color-scheme-name?)) q (7417 . 3)) ((c meth c (c (? . 64) q place-children)) q (112008 . 8)) ((c meth c (c (? . 32) q after-load-file)) q (20784 . 3)) ((c meth c (c (? . 44) q set-search-anchor)) q (142455 . 3)) ((c meth c (c (? . 50) q recalc-snips)) q (1618 . 2)) ((c meth c (c (? . 65) q remove-autosave)) q (23904 . 2)) ((c def c (c (? . 0) q keymap:get-user)) q (86916 . 2)) ((c meth c (c (? . 66) q get-orientation)) q (114264 . 2)) ((c meth c (c (? . 32) q on-new-box)) q (21083 . 3)) ((c def c (? . 67)) q (1869 . 4)) ((c def c (? . 68)) q (162069 . 4)) ((c def c (c (? . 11) q get-splash-bitmap)) q (165285 . 2)) ((c meth c (c (? . 1) q file-menu:get-save-as-item)) q (43437 . 3)) ((c def c (c (? . 0) q panel:single-window<%>)) q (109542 . 4)) ((c meth c (c (? . 1) q edit-menu:replace-help-string)) q (57134 . 3)) ((c meth c (c (? . 69) q overwrite-status-changed)) q (37982 . 2)) ((c def c (c (? . 0) q canvas:basic<%>)) q (473 . 3)) ((c meth c (c (? . 48) q after-save-file)) q (155737 . 2)) ((c meth c (c (? . 12) q on-local-char)) q (103904 . 3)) ((c def c (c (? . 0) q icon:get-paren-highlight-bitmap)) q (83951 . 2)) ((c def c (c (? . 0) q pasteboard:standard-style-list%)) q (116252 . 3)) ((c def c (? . 99)) q (109648 . 5)) ((c meth c (c (? . 17) q get-editor<%>)) q (61647 . 2)) ((c meth c (c (? . 4) q after-load-file)) q (99068 . 7)) ((c meth c (c (? . 4) q on-local-event)) q (92868 . 7)) ((c meth c (c (? . 45) q can-insert?)) q (158331 . 4)) ((c def c (? . 26)) q (13907 . 4)) ((c def c (? . 70)) q (158796 . 4)) ((c meth c (c (? . 47) q on-paint)) q (140017 . 21)) ((c def c (c (? . 0) q color-model:xyz-x)) q (3406 . 3)) ((c meth c (c (? . 7) q get-spell-current-dict)) q (11440 . 2)) ((c meth c (c (? . 13) q get-autocomplete-background-color)) q (159272 . 3)) ((c meth c (c (? . 9) q file-menu:revert-on-demand)) q (65595 . 2)) ((c def c (c (? . 0) q racket:init-wordbreak-map)) q (130640 . 3)) ((c def c (c (? . 0) q handler:set-recent-items-frame-superclass)) q (83436 . 3)) ((c meth c (c (? . 9) q file-menu:create-revert?)) q (65873 . 2)) ((c def c (c (? . 15) q enabled-shown-button?)) q (169811 . 3)) ((c meth c (c (? . 12) q can-set-size-constraint?)) q (107385 . 2)) ((c def c (? . 10)) q (75947 . 3)) ((c def c (c (? . 0) q keymap:setup-search)) q (88193 . 3)) ((c meth c (c (? . 30) q get-corner-bitmap)) q (16533 . 3)) ((c def c (c (? . 0) q keymap:setup-global)) q (88108 . 3)) ((c def c (c (? . 6) q gui-utils:trim-string)) q (77400 . 7)) ((c meth c (c (? . 43) q map-function)) q (85320 . 5)) ((c meth c (c (? . 7) q classify-position)) q (13449 . 4)) ((c meth c (c (? . 63) q get-corner-bitmap)) q (15971 . 3)) ((c form c (c (? . 0) q scheme:text<%>)) q (170143 . 2)) ((c meth c (c (? . 1) q file-menu:between-revert-and-save)) q (42616 . 4)) ((c def c (c (? . 0) q frame:add-snip-menu-items)) q (74859 . 7)) ((c meth c (c (? . 1) q help-menu:get-about-item)) q (60088 . 3)) ((c meth c (c (? . 17) q get-canvas)) q (62147 . 2)) ((c def c (? . 71)) q (35223 . 4)) ((c def c (? . 72)) q (140973 . 3)) ((c meth c (c (? . 73) q active-child)) q (108923 . 4)) ((c meth c (c (? . 74) q on-event)) q (160049 . 2)) ((c meth c (c (? . 1) q file-menu:open-recent-help-string)) q (41626 . 3)) ((c meth c (c (? . 1) q file-menu:close-string)) q (45724 . 2)) ((c meth c (c (? . 68) q show-line-numbers!)) q (162267 . 3)) ((c form c (c (? . 92) q framework^)) q (170758 . 2)) ((c meth c (c (? . 52) q get-area-container%)) q (31705 . 3)) ((c def c (? . 80)) q (22730 . 3)) ((c def c (c (? . 11) q close-splash)) q (165094 . 2)) ((c def c (? . 84)) q (109079 . 4)) ((c meth c (c (? . 16) q unhighlight-ranges)) q (132826 . 10)) ((c meth c (c (? . 65) q do-autosave)) q (23827 . 2)) ((c meth c (c (? . 38) q get-filename/untitled-name)) q (19904 . 2)) ((c meth c (c (? . 75) q set-line-numbers-color)) q (161970 . 3)) ((c def c (? . 76)) q (122216 . 2)) ((c meth c (c (? . 77) q on-save-file)) q (154429 . 6)) ((c def c (? . 7)) q (8753 . 3)) ((c def c (c (? . 0) q preferences:add-can-close-dialog-callback)) q (119107 . 3)) ((c def c (c (? . 0) q text:input-box%)) q (160895 . 3)) ((c meth c (c (? . 78) q get-text)) q (122466 . 7)) ((c def c (? . 8)) q (150157 . 4)) ((c meth c (c (? . 71) q can-close?)) q (35380 . 2)) ((c meth c (c (? . 3) q select-backward-sexp)) q (127792 . 2)) ((c meth c (c (? . 44) q get-search-bubbles)) q (142883 . 6)) ((c meth c (c (? . 17) q get-label-prefix)) q (61262 . 2)) ((c meth c (c (? . 17) q set-label-prefix)) q (61323 . 3)) ((c meth c (c (? . 79) q restore-keybinding)) q (88947 . 2)) ((c meth c (c (? . 57) q add-wide-snip)) q (144417 . 3)) ((c def c (c (? . 0) q finder:put-file)) q (30380 . 17)) ((c meth c (c (? . 4) q can-set-size-constraint?)) q (100727 . 7)) ((c meth c (c (? . 80) q get-can-close-parent)) q (22804 . 3)) ((c meth c (c (? . 1) q edit-menu:create-replace-all?)) q (57332 . 3)) ((c def c (c (? . 0) q frame:text%)) q (73819 . 3)) ((c meth c (c (? . 1) q edit-menu:copy-help-string)) q (49662 . 3)) ((c def c (c (? . 11) q get-splash-event-callback)) q (166453 . 2)) ((c def c (c (? . 24) q preferences:restore-prefs-snapshot)) q (122039 . 3)) ((c meth c (c (? . 1) q file-menu:save-callback)) q (42927 . 6)) ((c meth c (c (? . 1) q file-menu:close-callback)) q (45365 . 6)) ((c meth c (c (? . 1) q help-menu:about-help-string)) q (60709 . 3)) ((c def c (? . 30)) q (16453 . 3)) ((c meth c (c (? . 3) q flash-forward-sexp)) q (126793 . 3)) ((c def c (c (? . 0) q handler:handler-name)) q (81764 . 3)) ((c def c (c (? . 24) q preferences:set)) q (119720 . 4)) ((c def c (c (? . 6) q gui-utils:local-busy-cursor)) q (79581 . 7)) ((c meth c (c (? . 10) q get-active-frame)) q (76418 . 2)) ((q def ((lib "framework/framework-unit.rkt") framework@)) q (170834 . 2)) ((c def c (c (? . 0) q text:range-caret-space?)) q (162776 . 3)) ((c def c (c (? . 15) q test:button-push)) q (166868 . 7)) ((c meth c (c (? . 1) q edit-menu:create-replace?)) q (56543 . 3)) ((c meth c (c (? . 16) q set-port-unsaved-name)) q (134392 . 3)) ((c meth c (c (? . 26) q lock)) q (14043 . 2)) ((c meth c (c (? . 1) q help-menu:about-string)) q (60634 . 2)) ((c def c (c (? . 0) q preferences:hide-dialog)) q (118969 . 2)) ((c meth c (c (? . 56) q after-delete)) q (154056 . 4)) ((c meth c (c (? . 3) q comment-out-selection)) q (126134 . 5)) ((c meth c (c (? . 25) q close-status-line)) q (35756 . 3)) ((c def c (? . 69)) q (37816 . 3)) ((c form c (c (? . 0) q scheme:add-coloring-preferences-panel)) q (170526 . 2)) ((c def c (c (? . 0) q frame:standard-menus%)) q (73624 . 3)) ((c meth c (c (? . 81) q update-info)) q (38514 . 2)) ((c def c (c (? . 0) q finder:std-get-file)) q (29829 . 12)) ((c meth c (c (? . 7) q force-stop-colorer)) q (10259 . 3)) ((c meth c (c (? . 16) q set-styles-fixed)) q (133435 . 3)) ((c def c (c (? . 0) q exit:exit)) q (27142 . 2)) ((c meth c (c (? . 80) q user-saves-or-not-modified?)) q (23054 . 4)) ((c meth c (c (? . 12) q on-default-char)) q (103300 . 3)) ((c def c (c (? . 0) q keymap:make-meta-prefix-list)) q (87076 . 5)) ((c meth c (c (? . 1) q edit-menu:get-replace-item)) q (56432 . 3)) ((c meth c (c (? . 87) q on-event)) q (137695 . 3)) ((c def c (c (? . 0) q icon:get-unlock-bitmap)) q (84193 . 2)) ((c def c (? . 9)) q (62281 . 4)) ((c meth c (c (? . 52) q get-area-container)) q (31800 . 3)) ((c def c (c (? . 0) q editor:info<%>)) q (24661 . 3)) ((c meth c (c (? . 82) q set-editor)) q (1488 . 2)) ((c def c (c (? . 24) q exn:struct:unknown-preference)) q (121453 . 2)) ((c def c (c (? . 0) q keymap:set-chained-keymaps)) q (88278 . 5)) ((c meth c (c (? . 4) q on-change-style)) q (95623 . 9)) ((c def c (c (? . 24) q exn:unknown-preference?)) q (121380 . 3)) ((c def c (c (? . 11) q get-splash-eventspace)) q (165482 . 2)) ((c meth c (c (? . 14) q get-out-style-delta)) q (157366 . 3)) ((c meth c (c (? . 35) q get-info-editor)) q (37062 . 3)) ((c meth c (c (? . 12) q on-save-file)) q (105197 . 5)) ((c constructor c (? . 101)) q (67987 . 4)) ((c def c (c (? . 0) q panel:dragable-place-children)) q (115306 . 19)) ((c def c (? . 83)) q (108228 . 3)) ((c def c (c (? . 0) q menu:can-restore-underscore-menu%)) q (89812 . 3)) ((c meth c (c (? . 12) q can-save-file?)) q (107887 . 5)) ((c meth c (c (? . 13) q completion-mode-key-event?)) q (159492 . 4)) ((c meth c (c (? . 3) q select-forward-sexp)) q (127731 . 2)) ((c def c (c (? . 0) q exit:insert-on-callback)) q (26876 . 3)) ((c meth c (c (? . 1) q edit-menu:find-next-string)) q (54579 . 3)) ((c meth c (c (? . 56) q after-insert)) q (153912 . 4)) ((c meth c (c (? . 44) q set-searching-state)) q (142072 . 10)) ((c meth c (c (? . 13) q get-word-at)) q (159694 . 3)) ((c meth c (c (? . 84) q container-size)) q (109324 . 3)) ((c meth c (c (? . 85) q make-editor)) q (17818 . 3)) ((c meth c (c (? . 18) q on-change)) q (24497 . 2)) ((c meth c (c (? . 1) q edit-menu:create-undo?)) q (46920 . 3)) ((c meth c (c (? . 27) q unhide-search)) q (69972 . 7)) ((c def c (c (? . 0) q panel:horizontal-discrete-sizes%)) q (114782 . 3)) ((c meth c (c (? . 4) q can-change-style?)) q (99644 . 9)) ((c meth c (c (? . 63) q make-editor)) q (15827 . 2)) ((c meth c (c (? . 9) q on-close)) q (65151 . 2)) ((c def c (? . 56)) q (153517 . 5)) ((c meth c (c (? . 21) q set-orientation)) q (111224 . 3)) ((c def c (c (? . 0) q text:foreground-color<%>)) q (138379 . 4)) ((c def c (? . 86)) q (154766 . 4)) ((c meth c (c (? . 1) q file-menu:revert-help-string)) q (42534 . 3)) ((c meth c (c (? . 32) q on-new-image-snip)) q (21203 . 10)) ((c meth c (c (? . 1) q file-menu:save-as-callback)) q (43628 . 7)) ((c meth c (c (? . 54) q get-word-at)) q (128816 . 3)) ((c def c (c (? . 0) q handler:find-named-format-handler)) q (82456 . 4)) ((c def c (? . 87)) q (136805 . 4)) ((c meth c (c (? . 30) q get-position)) q (16822 . 3)) ((c meth c (c (? . 16) q unhighlight-range)) q (132175 . 12)) ((c meth c (c (? . 3) q flash-backward-sexp)) q (127014 . 3)) ((c meth c (c (? . 1) q file-menu:open-callback)) q (40489 . 6)) ((c def c (c (? . 0) q panel:vertical-discrete-sizes%)) q (114885 . 3)) ((c meth c (c (? . 14) q reset-input-box)) q (157133 . 2)) ((c meth c (c (? . 1) q edit-menu:get-find-previous-item)) q (54744 . 3)) ((c def c (? . 100)) q (980 . 4)) ((c form c (c (? . 0) q scheme:add-preferences-panel)) q (170490 . 2)) ((c meth c (c (? . 74) q on-paint)) q (159938 . 2)) ((c def c (c (? . 0) q color-model:xyz?)) q (3340 . 3)) ((c meth c (c (? . 52) q get-menu-bar%)) q (31884 . 2)) ((c meth c (c (? . 4) q on-default-char)) q (90723 . 7)) ((c def c (c (? . 6) q gui-utils:cancel-on-right?)) q (78163 . 2)) ((c meth c (c (? . 7) q set-spell-check-text)) q (11253 . 3)) ((c meth c (c (? . 12) q can-do-edit-operation?)) q (107452 . 7)) ((c def c (c (? . 0) q autosave:register)) q (235 . 4)) ((c def c (c (? . 0) q path-utils:generate-backup-name)) q (116909 . 3)) ((c meth c (c (? . 4) q put-file)) q (102424 . 9)) ((c def c (c (? . 0) q frame:searchable-text<%>)) q (72500 . 4)) ((c meth c (c (? . 1) q edit-menu:get-redo-item)) q (47485 . 3)) ((c meth c (c (? . 88) q get-discrete-heights)) q (114484 . 3)) ((c form c (c (? . 0) q scheme:text-mixin)) q (170165 . 2)) ((c meth c (c (? . 4) q on-change)) q (90273 . 5)) ((c meth c (c (? . 14) q get-box-input-text%)) q (158107 . 3)) ((c meth c (c (? . 1) q edit-menu:between-copy-and-paste)) q (49742 . 4)) ((c meth c (c (? . 1) q edit-menu:redo-help-string)) q (48078 . 3)) ((c meth c (c (? . 69) q editor-position-changed)) q (38119 . 2)) ((c meth c (c (? . 1) q edit-menu:find-from-selection-callback)) q (53297 . 7)) ((c def c (c (? . 15) q test:current-get-eventspaces)) q (168824 . 4)) ((c meth c (c (? . 10) q remove-frame)) q (76687 . 3)) ((c meth c (c (? . 1) q file-menu:print-callback)) q (44537 . 6)) ((c meth c (c (? . 4) q on-char)) q (90462 . 7)) ((c meth c (c (? . 27) q get-text-to-search)) q (69643 . 2)) ((c meth c (c (? . 87) q on-paint)) q (136943 . 19)) ((c meth c (c (? . 3) q tabify)) q (125121 . 3)) ((c meth c (c (? . 90) q on-enable-surrogate)) q (129357 . 2)) ((c def c (c (? . 0) q keymap:remove-chained-keymap)) q (88504 . 5)) ((c def c (c (? . 0) q keymap:aug-keymap%)) q (85512 . 3)) ((c meth c (c (? . 7) q reset-regions)) q (10866 . 3)) ((c def c (c (? . 11) q set-splash-event-callback)) q (166353 . 3)) ((c meth c (c (? . 74) q on-char)) q (159994 . 2)) ((c def c (? . 33)) q (67440 . 4)) ((c meth c (c (? . 71) q on-activate)) q (35503 . 3)) ((c meth c (c (? . 14) q clear-input-port)) q (157248 . 2)) ((c meth c (c (? . 1) q file-menu:get-revert-item)) q (41839 . 3)) ((c def c (c (? . 0) q color:text-mode%)) q (15426 . 3)) ((c meth c (c (? . 40) q after-new-child)) q (33051 . 2)) ((c meth c (c (? . 7) q on-lexer-valid)) q (13763 . 3)) ((c meth c (c (? . 23) q get-keymaps)) q (143381 . 3)) ((c def c (c (? . 6) q gui-utils:delay-action)) q (79350 . 7)) ((c meth c (c (? . 27) q search-hidden?)) q (69850 . 2)) ((c def c (c (? . 0) q keymap:add-to-right-button-menu)) q (85862 . 10)) ((c meth c (c (? . 50) q add-tall-snip)) q (1773 . 3)) ((c meth c (c (? . 14) q get-value-port)) q (157896 . 2)) ((c def c (? . 93)) q (138505 . 5)) ((c def c (c (? . 0) q racket:text-mode<%>)) q (129037 . 2)) ((c meth c (c (? . 1) q file-menu:new-on-demand)) q (39903 . 4)) ((c meth c (c (? . 1) q edit-menu:preferences-on-demand)) q (59550 . 4)) ((c def c (c (? . 0) q autosave:toc-path)) q (380 . 2)) ((c def c (c (? . 15) q test:mouse-click)) q (168369 . 8)) ((c meth c (c (? . 81) q on-close)) q (38460 . 2)) ((c def c (c (? . 0) q handler:handler?)) q (81698 . 3)) ((c def c (c (? . 0) q color-prefs:build-color-selection-panel)) q (4963 . 13)) ((c meth c (c (? . 1) q file-menu:open-string)) q (40845 . 2)) ((c def c (c (? . 15) q test:number-pending-actions)) q (169282 . 2)) ((c constructor c (? . 9)) q (62431 . 44)) ((c def c (c (? . 0) q keymap:call/text-keymap-initializer)) q (86591 . 3)) ((c meth c (c (? . 89) q read)) q (18224 . 4)) ((c meth c (c (? . 1) q edit-menu:create-show/hide-replace?)) q (55688 . 3)) ((c def c (c (? . 0) q color-model:rgb->xyz)) q (2628 . 5)) ((c def c (c (? . 11) q set-splash-bitmap)) q (165351 . 3)) ((c meth c (c (? . 16) q unhighlight-ranges/key)) q (132740 . 3)) ((c meth c (c (? . 1) q edit-menu:replace-on-demand)) q (56926 . 4)) ((c def c (c (? . 6) q gui-utils:next-untitled-name)) q (79035 . 2)) ((c def c (c (? . 15) q test:set-radio-box!)) q (167226 . 4)) ((c def c (c (? . 0) q icon:get-lock-bitmap)) q (84136 . 2)) ((c meth c (c (? . 35) q update-info)) q (36806 . 2)) ((c meth c (c (? . 1) q edit-menu:get-find-from-selection-item)) q (53082 . 3)) ((c meth c (c (? . 8) q after-insert)) q (152591 . 5)) ((c def c (c (? . 24) q preferences:set-default)) q (119970 . 13)) ((c meth c (c (? . 3) q backward-sexp)) q (127119 . 3)) ((c meth c (c (? . 7) q get-regions)) q (11788 . 3)) ((c meth c (c (? . 75) q show-line-numbers!)) q (161807 . 3)) ((c meth c (c (? . 27) q unhide-search-and-toggle-focus)) q (70427 . 4)) ((c meth c (c (? . 1) q edit-menu:find-case-sensitive-string)) q (58720 . 3)) ((c meth c (c (? . 4) q after-change-style)) q (97297 . 10)) ((c meth c (c (? . 12) q can-insert?)) q (107235 . 5)) ((c def c (c (? . 0) q frame:text<%>)) q (67368 . 3)) ((c meth c (c (? . 66) q set-orientation)) q (114155 . 4)) ((c meth c (c (? . 1) q file-menu:quit-on-demand)) q (46419 . 4)) ((c def c (? . 52)) q (31641 . 3)) ((c meth c (c (? . 7) q set-spell-current-dict)) q (11338 . 3)) ((c meth c (c (? . 3) q compute-amount-to-indent)) q (125691 . 4)) ((c def c (c (? . 0) q editor:autowrap-mixin)) q (22582 . 4)) ((c meth c (c (? . 41) q highlight-first-line)) q (136459 . 3)) ((c meth c (c (? . 90) q on-disable-surrogate)) q (129290 . 2)) ((c def c (c (? . 0) q text:basic%)) q (160105 . 3)) ((c meth c (c (? . 1) q edit-menu:clear-help-string)) q (51272 . 3)) ((c meth c (c (? . 1) q edit-menu:find-callback)) q (52582 . 6)) ((c meth c (c (? . 1) q edit-menu:paste-help-string)) q (50466 . 3)) ((c meth c (c (? . 14) q get-insertion-point)) q (156165 . 2)) ((c meth c (c (? . 5) q edit-menu:create-find-case-sensitive?)) q (72262 . 3)) ((c meth c (c (? . 5) q edit-menu:find-again-backwards-callback)) q (71383 . 7)) ((c meth c (c (? . 1) q edit-menu:show/hide-replace-on-demand)) q (56111 . 4)) ((c def c (c (? . 11) q set-splash-char-observer)) q (166255 . 3)) ((c meth c (c (? . 12) q after-set-position)) q (106550 . 2)) ((c meth c (c (? . 3) q select-up-sexp)) q (127854 . 2)) ((c def c (c (? . 0) q frame:reorder-menus)) q (75152 . 3)) ((c meth c (c (? . 9) q file-menu:between-save-as-and-print)) q (66774 . 4)) ((c meth c (c (? . 8) q after-edit-sequence)) q (152351 . 2)) ((c meth c (c (? . 1) q edit-menu:find-from-selection-help-string)) q (53858 . 3)) ((c meth c (c (? . 1) q edit-menu:replace-all-string)) q (57865 . 3)) ((c meth c (c (? . 37) q on-insert)) q (141556 . 5)) ((c meth c (c (? . 55) q get-map-function-table/ht)) q (84783 . 3)) ((c meth c (c (? . 27) q search-hits-changed)) q (70714 . 2)) ((c meth c (c (? . 80) q allow-close-with-no-filename?)) q (22979 . 2)) ((c def c (c (? . 0) q text:normalize-paste%)) q (160498 . 3)) ((c meth c (c (? . 1) q edit-menu:create-find-case-sensitive?)) q (58157 . 3)) ((c meth c (c (? . 16) q after-set-port-unsaved-name)) q (134481 . 2)) ((c meth c (c (? . 10) q frame-shown/hidden)) q (76260 . 2)) ((c meth c (c (? . 5) q edit-menu:find-case-sensitive-callback)) q (72056 . 3)) ((c def c (? . 91)) q (68772 . 5)) ((c def c (c (? . 0) q menu:can-restore-menu-item%)) q (89596 . 3)) ((c meth c (c (? . 60) q draw)) q (146902 . 21)) ((c meth c (c (? . 3) q up-sexp)) q (127338 . 3)) ((c meth c (c (? . 41) q get-first-line-height)) q (136638 . 2)) ((c meth c (c (? . 7) q insert-close-paren)) q (12949 . 11)) ((c meth c (c (? . 7) q start-colorer)) q (8823 . 22)) ((c def c (c (? . 0) q pasteboard:backup-autosave%)) q (116568 . 3)) ((c meth c (c (? . 7) q is-lexer-valid?)) q (13848 . 2)) ((c meth c (c (? . 8) q after-load-file)) q (153353 . 3)) ((c def c (c (? . 15) q test:reraise-error)) q (169335 . 2)) ((c def c (c (? . 0) q text:line-spacing<%>)) q (136165 . 3)) ((c meth c (c (? . 1) q file-menu:create-open?)) q (40412 . 3)) ((c def c (c (? . 0) q text:clever-file-format%)) q (161353 . 3)) ((c meth c (c (? . 5) q edit-menu:create-replace-all?)) q (71976 . 3)) ((c def c (c (? . 0) q editor:autowrap<%>)) q (22505 . 3)) ((c meth c (c (? . 3) q find-down-sexp)) q (127423 . 4)) ((c meth c (c (? . 19) q on-paint)) q (134930 . 21)) ((c def c (? . 104)) q (112765 . 4)) ((c meth c (c (? . 1) q file-menu:get-print-item)) q (44350 . 3)) ((c def c (c (? . 0) q panel:vertical-dragable%)) q (113005 . 4)) ((c meth c (c (? . 1) q edit-menu:create-paste?)) q (49976 . 3)) ((c meth c (c (? . 26) q on-set-size-constraint)) q (14315 . 2)) ((c meth c (c (? . 17) q get-canvas%)) q (61413 . 3)) ((c meth c (c (? . 1) q edit-menu:find-previous-callback)) q (54947 . 7)) ((c def c (c (? . 0) q racket:get-white-on-black-color-prefs-table)) q (130266 . 3)) ((c meth c (c (? . 1) q file-menu:get-new-item)) q (39494 . 3)) ((c meth c (c (? . 1) q file-menu:new-help-string)) q (40102 . 3)) ((c def c (? . 78)) q (122345 . 5)) ((c meth c (c (? . 3) q down-sexp)) q (127545 . 3)) ((c meth c (c (? . 1) q edit-menu:get-show/hide-replace-item)) q (55567 . 3)) ((c meth c (c (? . 52) q make-root-area-container)) q (31958 . 6)) ((c def c (c (? . 0) q canvas:color-mixin)) q (761 . 4)) ((c def c (c (? . 0) q color-prefs:add-to-preferences-panel)) q (4764 . 5)) ((c meth c (c (? . 1) q file-menu:open-recent-on-demand)) q (41420 . 4)) ((c meth c (c (? . 63) q get-position)) q (16049 . 3)) ((c def c (c (? . 0) q number-snip:make-repeating-decimal-snip)) q (108421 . 6)) ((c def c (c (? . 0) q group:on-close-action)) q (77104 . 2)) ((c meth c (c (? . 85) q copy)) q (17898 . 3)) ((c meth c (c (? . 1) q edit-menu:replace-all-on-demand)) q (57731 . 4)) ((c meth c (c (? . 14) q get-allow-edits)) q (156591 . 2)) ((c meth c (c (? . 35) q get-info-canvas)) q (36974 . 3)) ((c meth c (c (? . 1) q get-menu%)) q (38951 . 3)) ((c def c (c (? . 0) q handler:add-to-recent)) q (83567 . 3)) ((c meth c (c (? . 1) q edit-menu:between-paste-and-clear)) q (50547 . 4)) ((c meth c (c (? . 7) q backward-containing-sexp)) q (12465 . 6)) ((c def c (c (? . 0) q canvas:delegate%)) q (2448 . 3)) ((c def c (c (? . 11) q refresh-splash)) q (166830 . 2)) ((c meth c (c (? . 53) q hide-delegated-text)) q (68585 . 2)) ((c meth c (c (? . 1) q file-menu:between-new-and-open)) q (40181 . 4)) ((c def c (c (? . 0) q keymap:get-search)) q (87022 . 2)) ((c def c (? . 37)) q (141211 . 4)) ((c meth c (c (? . 1) q edit-menu:between-select-all-and-find)) q (52267 . 4)) ((c meth c (c (? . 1) q edit-menu:create-cut?)) q (48388 . 2)) ((c form c (c (? . 92) q framework-class^)) q (170793 . 2)) ((c meth c (c (? . 28) q split-horizontal)) q (113749 . 7)) ((c def c (c (? . 0) q handler:find-format-handler)) q (82587 . 4)) ((c def c (c (? . 0) q frame:editor%)) q (73728 . 3)) ((c meth c (c (? . 1) q edit-menu:create-find?)) q (52505 . 3)) ((c def c (c (? . 0) q text:autowrap%)) q (161169 . 3)) ((c meth c (c (? . 1) q file-menu:close-help-string)) q (45799 . 3)) ((c meth c (c (? . 4) q on-local-char)) q (92589 . 7)) ((c meth c (c (? . 10) q on-close-all)) q (76828 . 2)) ((c def c (? . 55)) q (84551 . 3)) ((c meth c (c (? . 10) q insert-frame)) q (76591 . 3)) ((c meth c (c (? . 38) q save-file-out-of-date?)) q (18877 . 2)) ((c def c (c (? . 15) q test:set-radio-box-item!)) q (167392 . 3)) ((c meth c (c (? . 93) q get-fixed-style)) q (138797 . 3)) ((c def c (c (? . 0) q exit:insert-can?-callback)) q (26968 . 3)) ((c def c (? . 65)) q (23613 . 3)) ((c def c (c (? . 0) q color-prefs:black-on-white)) q (5917 . 2)) ((c meth c (c (? . 14) q get-in-port)) q (157656 . 2)) ((c def c (c (? . 0) q frame:info%)) q (73259 . 3)) ((c def c (c (? . 0) q icon:get-eof-bitmap)) q (84019 . 2)) ((c meth c (c (? . 35) q set-info-canvas)) q (36858 . 3)) ((c def c (c (? . 0) q text:range-end)) q (162684 . 3)) ((c def c (c (? . 0) q text:column-guide<%>)) q (139806 . 3)) ((c meth c (c (? . 87) q scroll-editor-to)) q (137794 . 13)) ((c meth c (c (? . 4) q on-new-image-snip)) q (93419 . 14)) ((c meth c (c (? . 12) q after-delete)) q (106246 . 5)) ((c meth c (c (? . 1) q edit-menu:find-previous-help-string)) q (55478 . 3)) ((c def c (? . 23)) q (143188 . 5)) ((c meth c (c (? . 44) q finish-pending-search-work)) q (142812 . 2)) ((c meth c (c (? . 38) q can-close?)) q (19795 . 2)) ((c meth c (c (? . 4) q on-paint)) q (93979 . 23)) ((c def c (c (? . 0) q text:backup-autosave%)) q (161455 . 3)) ((c def c (c (? . 15) q button-in-top-level-focusd-window?)) q (169901 . 3)) ((c def c (c (? . 0) q text:autocomplete-append-after)) q (163055 . 4)) ((c meth c (c (? . 16) q get-fixed-style)) q (133365 . 2)) ((c meth c (c (? . 94) q get-vertical?)) q (112695 . 2)) ((c def c (c (? . 0) q editor:standard-style-list<%>)) q (21959 . 3)) ((c meth c (c (? . 9) q file-menu:create-save?)) q (66148 . 2)) ((c meth c (c (? . 95) q get-keymaps)) q (22280 . 3)) ((c meth c (c (? . 63) q get-text)) q (16138 . 2)) ((c def c (c (? . 0) q path-utils:generate-autosave-name)) q (116777 . 3)) ((c def c (c (? . 0) q group:add-to-windows-menu)) q (77197 . 3)) ((c def c (c (? . 24) q preferences:get-prefs-snapshot)) q (122146 . 2)) ((c def c (c (? . 24) q preferences:get)) q (119650 . 3)) ((c def c (? . 64)) q (111502 . 5)) ((c def c (c (? . 0) q canvas:basic-mixin)) q (546 . 4)) ((c meth c (c (? . 32) q can-save-file?)) q (20514 . 5)) ((c def c (c (? . 0) q finder:std-put-file)) q (29080 . 17)) ((c def c (c (? . 0) q finder:get-file)) q (31101 . 12)) ((c meth c (c (? . 40) q can-exit?)) q (32769 . 2)) ((c meth c (c (? . 1) q edit-menu:undo-on-demand)) q (47214 . 4)) ((c meth c (c (? . 27) q hide-search)) q (69914 . 2)) ((c meth c (c (? . 1) q get-file-menu)) q (39269 . 2)) ((c form c (c (? . 0) q scheme:get-color-prefs-table)) q (170571 . 2)) ((c meth c (c (? . 49) q on-move)) q (34997 . 5)) ((c meth c (c (? . 4) q on-set-size-constraint)) q (97086 . 6)) ((c form c (c (? . 0) q scheme:short-sym->style-name)) q (170693 . 2)) ((c meth c (c (? . 1) q edit-menu:get-find-next-item)) q (53953 . 3)) ((c meth c (c (? . 1) q edit-menu:clear-string)) q (51197 . 2)) ((c meth c (c (? . 89) q make-snip)) q (18063 . 4)) ((c meth c (c (? . 14) q get-err-style-delta)) q (157462 . 3)) ((c def c (? . 96)) q (24734 . 4)) ((c meth c (c (? . 97) q on-disable-surrogate)) q (15295 . 2)) ((c meth c (c (? . 1) q file-menu:open-recent-callback)) q (41198 . 6)) ((c meth c (c (? . 69) q add-line-number-menu-items)) q (38188 . 4)) ((c meth c (c (? . 1) q edit-menu:show/hide-replace-string)) q (56251 . 3)) ((c meth c (c (? . 7) q get-token-range)) q (13576 . 5)) ((c def c (? . 48)) q (155264 . 5)) ((c def c (? . 41)) q (136392 . 3)) ((c form c (c (? . 0) q scheme:text-mode<%>)) q (170210 . 2)) ((c meth c (c (? . 12) q on-display-size)) q (103471 . 2)) ((c meth c (c (? . 1) q file-menu:create-new?)) q (39601 . 2)) ((c meth c (c (? . 26) q on-focus)) q (14088 . 2)) ((c meth c (c (? . 1) q edit-menu:redo-string)) q (48004 . 2)) ((c meth c (c (? . 53) q show-delegated-text)) q (68649 . 2)) ((c meth c (c (? . 1) q edit-menu:between-cut-and-copy)) q (48946 . 4)) ((c meth c (c (? . 1) q file-menu:new-string)) q (40029 . 2)) ((c meth c (c (? . 5) q edit-menu:find-case-sensitive-on-demand)) q (72145 . 4)) ((c def c (c (? . 0) q text:input-box<%>)) q (158730 . 3)) ((c def c (? . 17)) q (61120 . 3)) ((c def c (? . 4)) q (90173 . 4)) ((c def c (c (? . 0) q text:keymap%)) q (160994 . 3)) ((c form c (c (? . 0) q scheme:text-mode%)) q (170267 . 2)) ((c meth c (c (? . 3) q move-sexp-out)) q (128430 . 3)) ((c meth c (c (? . 1) q file-menu:revert-callback)) q (42028 . 7)) ((c meth c (c (? . 14) q clear-output-ports)) q (157189 . 2)) ((c meth c (c (? . 40) q on-exit)) q (32823 . 2)) ((c meth c (c (? . 35) q get-info-panel)) q (37146 . 3)) ((c meth c (c (? . 12) q can-change-style?)) q (106923 . 5)) ((c meth c (c (? . 1) q on-close)) q (38892 . 2)) ((c meth c (c (? . 3) q balance-parens)) q (124952 . 3)) ((c def c (c (? . 6) q gui-utils:show-busy-cursor)) q (79206 . 4)) ((c def c (? . 90)) q (129082 . 5)) ((c meth c (c (? . 38) q get-pos/text)) q (19976 . 5)) ((c meth c (c (? . 69) q set-macro-recording)) q (37891 . 3)) ((c meth c (c (? . 12) q after-insert)) q (106398 . 5)) ((c def c (c (? . 11) q add-splash-icon)) q (165130 . 5)) ((c meth c (c (? . 1) q edit-menu:find-string)) q (52928 . 2)) ((c meth c (c (? . 45) q can-delete?)) q (158454 . 4)) ((c meth c (c (? . 5) q edit-menu:find-callback)) q (70938 . 2)) ((c def c (c (? . 0) q panel:discrete-sizes-mixin)) q (114587 . 5)) ((c meth c (c (? . 14) q do-submission)) q (156111 . 2)) ((c meth c (c (? . 98) q on-close)) q (61061 . 2)) ((c meth c (c (? . 4) q after-insert)) q (98017 . 9)) ((c meth c (c (? . 1) q edit-menu:get-paste-item)) q (49867 . 3)) ((c meth c (c (? . 1) q file-menu:create-revert?)) q (41949 . 3)) ((c meth c (c (? . 3) q remove-parens-forward)) q (127632 . 3)) ((c meth c (c (? . 12) q after-set-size-constraint)) q (106611 . 2)) ((c def c (c (? . 0) q text:file%)) q (161255 . 3)) ((c def c (c (? . 0) q editor:add-after-user-keymap)) q (26551 . 6)) ((c meth c (c (? . 4) q after-set-position)) q (98374 . 6)) ((c meth c (c (? . 78) q copy)) q (122733 . 2)) ((c def c (c (? . 0) q version:version)) q (170102 . 2)) ((c meth c (c (? . 1) q get-edit-menu)) q (39344 . 2)) ((c def c (c (? . 0) q racket:setup-keymap)) q (130725 . 3)) ((c meth c (c (? . 48) q can-insert?)) q (155445 . 4)) ((c meth c (c (? . 4) q on-event)) q (91700 . 7)) ((c meth c (c (? . 84) q place-children)) q (109407 . 3)) ((c meth c (c (? . 21) q set-percentages)) q (110972 . 3)) ((c meth c (c (? . 1) q edit-menu:clear-callback)) q (50860 . 6)) ((c meth c (c (? . 1) q edit-menu:copy-string)) q (49588 . 2)) ((c def c (? . 40)) q (32566 . 4)) ((c meth c (c (? . 38) q run-after-edit-sequence)) q (18572 . 5)) ((c meth c (c (? . 9) q file-menu:open-callback)) q (65390 . 5)) ((c meth c (c (? . 12) q on-snip-modified)) q (105361 . 5)) ((c meth c (c (? . 1) q file-menu:create-print?)) q (44459 . 3)) ((c def c (c (? . 0) q color-model:rgb-color-distance)) q (2746 . 13)) ((c meth c (c (? . 36) q on-close)) q (33412 . 2)) ((c meth c (c (? . 29) q get-corner-bitmap)) q (17140 . 3)) ((c meth c (c (? . 1) q file-menu:revert-string)) q (42457 . 3)) ((c def c (? . 29)) q (16983 . 4)) ((c meth c (c (? . 1) q file-menu:get-open-item)) q (40304 . 3)) ((c meth c (c (? . 68) q show-line-numbers?)) q (162361 . 2)) ((c def c (c (? . 0) q keymap:add-user-keybindings-file)) q (85716 . 4)) ((c meth c (c (? . 9) q file-menu:print-callback)) q (66498 . 5)) ((c def c (c (? . 0) q text:nbsp->space<%>)) q (139204 . 3)) ((c meth c (c (? . 4) q can-delete?)) q (100021 . 9)) ((c def c (c (? . 0) q canvas:info%)) q (2367 . 3)) ((c meth c (c (? . 1) q file-menu:print-on-demand)) q (44768 . 4)) ((c def c (c (? . 0) q text:nbsp->space%)) q (160402 . 3)) ((c def c (? . 18)) q (23973 . 5)) ((c meth c (c (? . 103) q make-root-area-container)) q (36187 . 6)) ((c meth c (c (? . 80) q update-frame-filename)) q (22915 . 2)) ((c meth c (c (? . 13) q auto-complete)) q (159104 . 2)) ((c meth c (c (? . 3) q get-backward-sexp)) q (126897 . 4)) ((c meth c (c (? . 27) q search)) q (69408 . 3)) ((c meth c (c (? . 99) q container-size)) q (109846 . 7)) ((c meth c (c (? . 60) q get-extent)) q (145469 . 22)) ((c meth c (c (? . 1) q edit-menu:replace-string)) q (57056 . 3)) ((c def c (? . 51)) q (89922 . 2)) ((c meth c (c (? . 72) q ask-normalize?)) q (141053 . 2)) ((c meth c (c (? . 40) q on-superwindow-show)) q (32872 . 3)) ((c def c (c (? . 0) q exit:can-exit?)) q (27065 . 2)) ((c meth c (c (? . 1) q edit-menu:create-copy?)) q (49177 . 3)) ((c def c (c (? . 0) q finder:default-extension)) q (27444 . 4)) ((c def c (c (? . 0) q comment-box:snipclass)) q (16266 . 2)) ((c constructor c (? . 97)) q (14761 . 10)) ((c meth c (c (? . 68) q set-line-numbers-color)) q (162430 . 3)) ((c def c (c (? . 24) q preferences:register-save-callback)) q (120969 . 3)) ((c meth c (c (? . 12) q on-char)) q (103223 . 3)) ((c def c (c (? . 0) q preferences:add-general-checkbox-panel)) q (118175 . 2)) ((c meth c (c (? . 100) q on-superwindow-show)) q (1128 . 3)) ((c def c (c (? . 15) q test:new-window)) q (168987 . 3)) ((c meth c (c (? . 78) q write)) q (122807 . 3)) ((c def c (c (? . 0) q preferences:add-scheme-checkbox-panel)) q (118300 . 2)) ((c meth c (c (? . 27) q get-case-sensitive-search?)) q (70637 . 3)) ((c def c (c (? . 24) q preferences:set-un/marshall)) q (120633 . 7)) ((c meth c (c (? . 1) q file-menu:save-as-help-string)) q (44139 . 3)) ((c meth c (c (? . 101) q get-editor<%>)) q (68128 . 2)) ((c meth c (c (? . 12) q can-delete?)) q (107085 . 5)) ((c def c (? . 102)) q (33468 . 3)) ((c meth c (c (? . 3) q remove-sexp)) q (126614 . 3)) ((c def c (? . 103)) q (36036 . 4)) ((c meth c (c (? . 1) q edit-menu:select-all-help-string)) q (52181 . 3)) ((c meth c (c (? . 62) q after-insert)) q (139606 . 5)) ((c def c (c (? . 0) q canvas:info<%>)) q (1225 . 3)) ((c def c (? . 61)) q (155020 . 4)) ((c meth c (c (? . 17) q get-editor)) q (62213 . 2)) ((c meth c (c (? . 5) q make-root-area-container)) q (72350 . 3)) ((c meth c (c (? . 14) q set-insertion-point)) q (156234 . 3)) ((c meth c (c (? . 93) q default-style-name)) q (138725 . 2)) ((c meth c (c (? . 4) q can-insert?)) q (100374 . 9)) ((c def c (c (? . 0) q text:crlf-line-endings<%>)) q (154692 . 3)) ((c meth c (c (? . 60) q split)) q (145087 . 7)) ((c def c (c (? . 0) q text:info%)) q (161662 . 3)) ((c form c (c (? . 31) q decorated-editor-snip<%>)) q (16421 . 2)) ((c meth c (c (? . 3) q set-tab-size)) q (128231 . 3)) ((c meth c (c (? . 12) q on-new-image-snip)) q (104149 . 9)) ((c meth c (c (? . 84) q after-new-child)) q (109223 . 3)) ((c def c (c (? . 24) q preferences:low-level-put-preferences)) q (121506 . 5)) ((c def c (c (? . 0) q text:standard-style-list%)) q (160784 . 3)) ((c def c (c (? . 0) q color-prefs:white-on-black)) q (5869 . 2)) ((c meth c (c (? . 35) q show-info)) q (37225 . 2)) ((c def c (? . 34)) q (147766 . 3)) ((c meth c (c (? . 1) q edit-menu:redo-callback)) q (47670 . 6)) ((c meth c (c (? . 7) q stop-colorer)) q (10151 . 3)) ((c meth c (c (? . 17) q save)) q (61826 . 4)) ((c def c (? . 101)) q (67837 . 4)) ((c def c (? . 13)) q (159035 . 3)) ((c meth c (c (? . 9) q editing-this-file?)) q (65054 . 3)) ((c meth c (c (? . 4) q can-load-file?)) q (101682 . 9)) ((c meth c (c (? . 78) q draw)) q (122920 . 21)) ((c meth c (c (? . 9) q get-label)) q (65255 . 2)) ((c def c (c (? . 0) q frame:focus-table<%>)) q (33108 . 3)) ((c constructor c (? . 85)) q (17622 . 3)) ((c meth c (c (? . 63) q get-menu)) q (16194 . 2)) ((c meth c (c (? . 14) q set-allow-edits)) q (156491 . 3)) ((c meth c (c (? . 104) q get-vertical?)) q (112933 . 2)) ((c meth c (c (? . 65) q backup?)) q (23697 . 2)) ((c meth c (c (? . 3) q uncomment-selection)) q (126318 . 5)) ((c meth c (c (? . 13) q get-autocomplete-border-color)) q (159165 . 3)) ((c def c (c (? . 0) q racket:text-balanced?)) q (129828 . 5)) ((c meth c (c (? . 5) q edit-menu:replace-all-callback)) q (71786 . 3)) ((c def c (c (? . 11) q get-splash-canvas)) q (165428 . 2)) ((c meth c (c (? . 7) q is-frozen?)) q (10403 . 2)) ((c def c (c (? . 0) q racket:get-keymap)) q (130050 . 2)) ((c meth c (c (? . 1) q edit-menu:clear-on-demand)) q (51079 . 4)) ((c meth c (c (? . 12) q after-edit-sequence)) q (106679 . 2)) ((c meth c (c (? . 12) q on-change-style)) q (105536 . 5)) ((c def c (c (? . 0) q color-prefs:get-current-color-scheme-name)) q (7320 . 3)) ((c def c (? . 85)) q (17522 . 3)) ((c def c (c (? . 0) q finder:common-get-file)) q (28514 . 12)) ((c meth c (c (? . 14) q after-io-insertion)) q (157958 . 2)) ((c meth c (c (? . 4) q on-display-size)) q (91296 . 5)) ((c meth c (c (? . 9) q file-menu:save-callback)) q (65943 . 5)) ((c def c (c (? . 0) q color-model:xyz-y)) q (3483 . 3)) ((c def c (c (? . 0) q finder:default-filters)) q (27569 . 4)) ((c meth c (c (? . 88) q get-discrete-widths)) q (114382 . 3)) ((c meth c (c (? . 19) q after-insert)) q (135827 . 4)) ((c meth c (c (? . 64) q after-new-child)) q (111692 . 3)) ((c meth c (c (? . 14) q get-unread-start-point)) q (156324 . 2)) ((c meth c (c (? . 32) q get-file)) q (21639 . 3)) ((c def c (? . 35)) q (36414 . 3)) ((c meth c (c (? . 56) q after-set-position)) q (153854 . 2)) ((c meth c (c (? . 39) q set-delegate)) q (144902 . 3)) ((c meth c (c (? . 1) q edit-menu:select-all-string)) q (52100 . 3)) ((c meth c (c (? . 64) q container-size)) q (112360 . 4)) ((c def c (c (? . 0) q color-prefs:get-color-scheme-names)) q (8690 . 2)) ((c meth c (c (? . 1) q edit-menu:find-case-sensitive-on-demand)) q (58588 . 4)) ((c form c (c (? . 0) q scheme:text-balanced?)) q (170729 . 2)) ((c meth c (c (? . 32) q on-focus)) q (20879 . 3)) ((c def c (c (? . 0) q color-prefs:register-color-preference)) q (4003 . 13)) ((c meth c (c (? . 91) q get-editor%)) q (69252 . 3)) ((c meth c (c (? . 53) q delegate-moved)) q (68713 . 2)) ((c def c (c (? . 0) q menu:can-restore-mixin)) q (89012 . 4)) ((c def c (c (? . 0) q text:hide-caret/selection%)) q (160288 . 3)) ((c meth c (c (? . 45) q on-display-size)) q (158674 . 2)) ((c meth c (c (? . 26) q after-delete)) q (14431 . 2)) ((c meth c (c (? . 1) q file-menu:save-as-on-demand)) q (43931 . 4)) ((c def c (c (? . 15) q test:set-choice!)) q (167627 . 4)) ((c meth c (c (? . 1) q file-menu:create-close?)) q (45287 . 3)) ((c meth c (c (? . 14) q insert-between)) q (156650 . 3)) ((c meth c (c (? . 53) q delegated-text-shown?)) q (68516 . 2)) ((c meth c (c (? . 8) q on-load-file)) q (153185 . 5)) ((c def c (? . 97)) q (14606 . 4)) ((c def c (c (? . 15) q test:menu-select)) q (168258 . 4)) ((c form c (c (? . 0) q scheme:get-white-on-black-color-prefs-table)) q (170607 . 2)) ((c meth c (c (? . 7) q set-spell-check-strings)) q (11101 . 3)) ((c meth c (c (? . 5) q edit-menu:create-find?)) q (71011 . 2)) ((c meth c (c (? . 1) q help-menu:about-on-demand)) q (60506 . 4)) ((c def c (c (? . 0) q application:current-app-name)) q (0 . 4)) ((c meth c (c (? . 1) q edit-menu:after-preferences)) q (59853 . 4)) ((c form c (c (? . 0) q scheme:short-sym->pref-name)) q (170658 . 2)) ((c meth c (c (? . 105) q after-set-position)) q (139130 . 2)) ((c meth c (c (? . 1) q file-menu:get-save-item)) q (42742 . 3)) ((c meth c (c (? . 60) q insert)) q (146616 . 7)) ((c meth c (c (? . 1) q file-menu:close-on-demand)) q (45596 . 4)) ((c def c (c (? . 0) q canvas:color<%>)) q (687 . 3)) ((c def c (? . 82)) q (1298 . 4)) ((c meth c (c (? . 38) q local-edit-sequence?)) q (18505 . 2)) ((c meth c (c (? . 27) q set-text-to-search)) q (69719 . 3)) ((c def c (c (? . 0) q color:get-parenthesis-colors-table)) q (15522 . 3)) ((c meth c (c (? . 1) q file-menu:quit-help-string)) q (46620 . 3)) ((c meth c (c (? . 1) q edit-menu:get-find-case-sensitive-item)) q (58034 . 3)) ((c constructor c (? . 22)) q (144125 . 4)) ((c meth c (c (? . 1) q file-menu:create-open-recent?)) q (41114 . 3)) ((c def c (? . 75)) q (161761 . 2)) ((c meth c (c (? . 53) q get-delegated-text)) q (68302 . 3)) ((c meth c (c (? . 7) q skip-whitespace)) q (11924 . 8)) ((c meth c (c (? . 52) q close)) q (32212 . 2)) ((c meth c (c (? . 91) q make-root-area-container)) q (68969 . 6)) ((c def c (c (? . 11) q start-splash)) q (163600 . 24)) ((c def c (c (? . 0) q handler:handler-handler)) q (81991 . 4))))
parameter
(application:current-app-name) -> string?
(application:current-app-name name) -> void?
  name : string?
interface
autosave:autosavable<%> : interface?
method
(send an-autosave:autosavable do-autosave) -> void?
procedure
(autosave:register obj) -> void?
  obj : (and/c (is-a?/c autosave:autosavable<%>)
               (is-a?/c editor<%>))
value
autosave:toc-path : path?
procedure
(autosave:restore-autosave-files/gui) -> void?
interface
canvas:basic<%> : interface?
  implements: editor-canvas%
mixin
canvas:basic-mixin : (class? . -> . class?)
  argument extends/implements: editor-canvas%
  result implements: canvas:basic<%>
interface
canvas:color<%> : interface?
  implements: canvas:basic<%>
mixin
canvas:color-mixin : (class? . -> . class?)
  argument extends/implements: canvas:basic<%>
  result implements: canvas:color<%>
interface
canvas:delegate<%> : interface?
  implements: canvas:basic<%>
mixin
canvas:delegate-mixin : (class? . -> . class?)
  argument extends/implements: canvas:basic<%>
  result implements: canvas:delegate<%>
method
(send a-canvas:delegate on-superwindow-show shown?) -> void?
  shown? : boolean?
interface
canvas:info<%> : interface?
  implements: canvas:basic<%>
mixin
canvas:info-mixin : (class? . -> . class?)
  argument extends/implements: canvas:basic<%>
  result implements: canvas:info<%>
method
(send a-canvas:info on-focus) -> void?
method
(send a-canvas:info set-editor) -> void?
interface
canvas:wide-snip<%> : interface?
  implements: canvas:basic<%>
method
(send a-canvas:wide-snip recalc-snips) -> void?
method
(send a-canvas:wide-snip add-wide-snip snip) -> void?
  snip : (is-a?/c snip%)
method
(send a-canvas:wide-snip add-tall-snip snip) -> void?
  snip : (is-a?/c snip%)
mixin
canvas:wide-snip-mixin : (class? . -> . class?)
  argument extends/implements: canvas:basic<%>
  result implements: canvas:wide-snip<%>
method
(send a-canvas:wide-snip on-size width       
                                 height) -> void?
  width : dimension-integer?
  height : dimension-integer?
class
canvas:basic% : class?
  superclass: (canvas:basic-mixin editor-canvas%)
class
canvas:color% : class?
  superclass: (canvas:color-mixin canvas:basic%)
class
canvas:info% : class?
  superclass: (canvas:info-mixin canvas:basic%)
class
canvas:delegate% : class?
  superclass: (canvas:delegate-mixin canvas:basic%)
class
canvas:wide-snip% : class?
  superclass: (canvas:wide-snip-mixin canvas:basic%)
procedure
(color-model:rgb->xyz r g b) -> color-model:xyz?
  r : number?
  g : number?
  b : number?
procedure
(color-model:rgb-color-distance red-a       
                                green-a     
                                blue-a      
                                red-b       
                                green-b     
                                blue-b) -> number?
  red-a : number?
  green-a : number?
  blue-a : number?
  red-b : number?
  green-b : number?
  blue-b : number?
procedure
(color-model:xyz->rgb x y z) -> (list/c number? number? number?)
  x : number?
  y : number?
  z : number?
procedure
(color-model:xyz? val) -> boolean?
  val : any/c
procedure
(color-model:xyz-x xyz) -> number?
  xyz : color-model:xyz?
procedure
(color-model:xyz-y xyz) -> number?
  xyz : color-model:xyz?
procedure
(color-model:xyz-z xyz) -> number?
  xyz : color-model:xyz?
procedure
(color-prefs:set-default/color-scheme pref-sym              
                                      black-on-white-color  
                                      white-on-black-color) 
 -> void?
  pref-sym : symbol?
  black-on-white-color : (or/c (is-a?/c color%) string?)
  white-on-black-color : (or/c (is-a?/c color%) string?)
procedure
(color-prefs:register-color-preference                            
                                        pref-name                 
                                        style-name                
                                        color/sd                  
                                       [white-on-black-color      
                                        #:background background]) 
 -> void?
  pref-name : symbol?
  style-name : string?
  color/sd : (or/c (is-a?/c color%) (is-a?/c style-delta%))
  white-on-black-color : (or/c string? (is-a?/c color%) #f) = #f
  background : (or/c (is-a?/c color%) #f) = #f
procedure
(color-prefs:add-background-preferences-panel) -> void?
procedure
(color-prefs:add-to-preferences-panel name      
                                      func) -> void?
  name : string?
  func : ((is-a?/c vertical-panel%) . -> . void?)
procedure
(color-prefs:build-color-selection-panel                              
                                          parent                      
                                          pref-sym                    
                                          style-name                  
                                          example-text                
                                         [#:background? background?]) 
 -> void?
  parent : (is-a?/c area-container<%>)
  pref-sym : symbol?
  style-name : string?
  example-text : string?
  background? : boolean? = #f
procedure
(color-prefs:marshall-style-delta style-delta) -> printable/c
  style-delta : (is-a?/c style-delta%)
procedure
(color-prefs:unmarshall-style-delta marshalled-style-delta)
 -> (or/c false/c (is-a?/c style-delta%))
  marshalled-style-delta : printable/c
procedure
(color-prefs:white-on-black) -> any
procedure
(color-prefs:black-on-white) -> any
procedure
(color-prefs:add-color-scheme-entry  name                      
                                     black-on-white-color      
                                     white-on-black-color      
                                    [#:style style             
                                     #:bold? bold?             
                                     #:underline? underline?   
                                     #:italic? italic?         
                                     #:background background]) 
 -> void?
  name : symbol?
  black-on-white-color : (or/c string? (is-a?/c color%))
  white-on-black-color : (or/c string? (is-a?/c color%))
  style : (or/c #f string?) = #f
  bold? : (if style boolean? #f) = #f
  underline? : (if style boolean? #f) = #f
  italic? : (if style boolean? #f) = #f
  background : (if style                              = #f
                   (or/c #f string? (is-a?/c color%))
                   #f)
procedure
(color-prefs:add-color-scheme-preferences-panel [#:extras extras])
 -> void?
  extras : (-> (is-a?/c panel%) any) = void
procedure
(color-prefs:register-info-based-color-schemes) -> void?
procedure
(color-prefs:set-current-color-scheme name) -> void?
  name : symbol?
procedure
(color-prefs:get-current-color-scheme-name)
 -> color-prefs:color-scheme-style-name?
procedure
(color-prefs:known-color-scheme-name? name) -> boolean?
  name : any/c
procedure
(color-prefs:color-scheme-style-name? name) -> boolean?
  name : any/c
procedure
(color-prefs:lookup-in-color-scheme name)
 -> (if (color-prefs:color-scheme-style-name? name)
        (is-a?/c style-delta%)
        (is-a?/c color%))
  name : color-prefs:known-color-scheme-name?
procedure
(color-prefs:set-in-color-scheme name         
                                 new-val) -> void?
  name : color-prefs:known-color-scheme-name?
  new-val : (if (color-prefs:color-scheme-style-name? name)
                (is-a?/c style-delta%)
                (is-a?/c color%))
procedure
(color-prefs:register-color-scheme-entry-change-callback          
                                                          name    
                                                          fn      
                                                         [weak?]) 
 -> void?
  name : color-prefs:known-color-scheme-name?
  fn : (-> (if (color-prefs:color-scheme-style-name? name)
               (is-a?/c style-delta%)
               (is-a?/c color%))
           any)
  weak? : boolean? = #f
procedure
(color-prefs:get-color-scheme-names) -> set? set?
interface
color:text<%> : interface?
  implements: text:basic<%>
method
(send a-color:text start-colorer token-sym->style     
                                 get-token            
                                 pairs)           -> void?
  token-sym->style : (-> symbol? string?)
  get-token : (or/c (-> input-port?
                        (values any/c
                                symbol?
                                (or/c symbol? #f)
                                (or/c exact-positive-integer? #f)
                                (or/c exact-positive-integer? #f)))
                    (-> input-port?
                        exact-nonnegative-integer?
                        (not/c dont-stop?)
                        (values any/c
                                symbol?
                                (or/c symbol? #f)
                                (or/c exact-positive-integer? #f)
                                (or/c exact-positive-integer? #f)
                                exact-nonnegative-integer?
                                any/c)))
  pairs : (listof (list/c symbol? symbol?))
method
(send a-color:text stop-colorer [clear-colors?]) -> void?
  clear-colors? : boolean? = #t
method
(send a-color:text force-stop-colorer stop?) -> void?
  stop? : boolean?
method
(send a-color:text is-stopped?) -> boolean?
method
(send a-color:text is-frozen?) -> boolean?
method
(send a-color:text freeze-colorer) -> void?
method
(send a-color:text thaw-colorer [recolor?          
                                 retokenize?]) -> void?
  recolor? : boolean? = #t
  retokenize? : boolean? = #f
method
(send a-color:text reset-region start end) -> void?
  start : exact-nonnegative-integer?
  end : (or/c exact-nonnegative-integer? 'end)
method
(send a-color:text reset-regions regions) -> void?
  regions : (listof (list/c exact-nonnegative-integer? (or/c exact-nonnegative-integer? 'end)))
method
(send a-color:text get-spell-check-strings) -> boolean?
method
(send a-color:text set-spell-check-strings b?) -> void?
  b? : boolean?
method
(send a-color:text get-spell-check-text) -> boolean?
method
(send a-color:text set-spell-check-text b?) -> void?
  b? : boolean?
method
(send a-color:text set-spell-current-dict dict) -> void?
  dict : (or/c string? #f)
method
(send a-color:text get-spell-current-dict) -> (or/c string? #f)
method
(send a-color:text get-spell-suggestions pos)
 -> (or/c #f (list/c exact-nonnegative-integer?
                     exact-nonnegative-integer?
                     (listof string?)))
  pos : exact-nonnegative-integer?
method
(send a-color:text get-regions)
 -> (listof (list/c exact-nonnegative-integer? (or/c exact-nonnegative-integer? 'end)))
method
(send a-color:text skip-whitespace position   
                                   direction  
                                   comments?) 
 -> exact-nonnegative-integer?
  position : exact-nonnegative-integer?
  direction : (or/c 'forward 'backward)
  comments? : boolean?
method
(send a-color:text backward-match position 
                                  cutoff)  
 -> (or/c exact-nonnegative-integer? #f)
  position : exact-nonnegative-integer?
  cutoff : exact-nonnegative-integer?
method
(send a-color:text backward-containing-sexp position 
                                            cutoff)  
 -> (or/c exact-nonnegative-integer? #f)
  position : exact-nonnegative-integer?
  cutoff : exact-nonnegative-integer?
method
(send a-color:text forward-match position 
                                 cutoff)  
 -> (or/c exact-nonnegative-integer? #f)
  position : exact-nonnegative-integer?
  cutoff : exact-nonnegative-integer?
method
(send a-color:text insert-close-paren  position          
                                       char              
                                       flash?            
                                       fixup?            
                                      [smart-skip?]) -> void?
  position : exact-nonnegative-integer?
  char : char?
  flash? : boolean?
  fixup? : boolean?
  smart-skip? : (or/c #f 'adjacent 'forward) = #f
method
(send a-color:text classify-position position)
 -> (or/c symbol? #f)
  position : exact-nonnegative-integer?
method
(send a-color:text get-token-range position)
 -> (or/c #f exact-nonnegative-integer?)
    (or/c #f exact-nonnegative-integer?)
  position : exact-nonnegative-integer?
method
(send a-color:text on-lexer-valid valid?) -> any
  valid? : boolean?
method
(send a-color:text is-lexer-valid?) -> boolean?
mixin
color:text-mixin : (class? . -> . class?)
  argument extends/implements: text:basic<%>
  result implements: color:text<%>
method
(send a-color:text lock) -> void?
method
(send a-color:text on-focus) -> void?
method
(send a-color:text after-edit-sequence) -> void?
method
(send a-color:text after-set-position) -> void?
method
(send a-color:text after-change-style) -> void?
method
(send a-color:text on-set-size-constraint) -> void?
method
(send a-color:text after-insert) -> void?
method
(send a-color:text after-delete) -> void?
class
color:text% : class?
  superclass: (color:text-mixin text:keymap%)
interface
color:text-mode<%> : interface?
mixin
color:text-mode-mixin : (class? . -> . class?)
  argument extends/implements: mode:surrogate-text<%>
  result implements: color:text-mode<%>
constructor
(new color:text-mode-mixin                                      
                           [[get-token get-token]               
                            [token-sym->style token-sym->style] 
                            [matches matches]])                 
 -> (is-a?/c color:text-mode-mixin)
  get-token : lexer = default-lexer
  token-sym->style : (symbol? . -> . string?)
                   = (λ (x) "Standard")
  matches : (listof (list/c symbol? symbol?)) = null
method
(send a-color:text-mode on-disable-surrogate) -> void?
method
(send a-color:text-mode on-enable-surrogate) -> void?
class
color:text-mode% : class?
  superclass: (color:text-mode-mixin mode:surrogate-text%)
procedure
(color:get-parenthesis-colors-table)
 -> (listof (list/c symbol? string? (vectorof (is-a?/c color%)) (or/c 'low 'high)))
value
color:misspelled-text-color-style-name : string?
class
comment-box:snip% : class?
  superclass: editor-snip:decorated%
  extends: readable-snip<%>
method
(send a-comment-box:snip make-editor) -> (is-a?/c text%)
method
(send a-comment-box:snip make-snip) -> (is-a?/c comment-snip%)
method
(send a-comment-box:snip get-corner-bitmap)
 -> (is-a?/c bitmap%)
method
(send a-comment-box:snip get-position)
 -> (symbols 'left-top  'top-right)
method
(send a-comment-box:snip get-text) -> string
method
(send a-comment-box:snip get-menu) -> (is-a?/c popup-menu%)
value
comment-box:snipclass : (is-a?/c snip-class%)
syntax
decorated-editor-snip%
syntax
decorated-editor-snipclass%
syntax
decorated-editor-snip-mixin
syntax
decorated-editor-snip<%>
interface
editor-snip:decorated<%> : interface?
  implements: editor-snip%
method
(send an-editor-snip:decorated get-corner-bitmap)
 -> (or/c false/c (is-a?/c bitmap%))
method
(send an-editor-snip:decorated get-color)
 -> (or/c string? (is-a?/c color%))
method
(send an-editor-snip:decorated get-menu)
 -> (or/c false/c (is-a?/c popup-menu%))
method
(send an-editor-snip:decorated get-position)
 -> (symbols 'top-right 'left-top)
method
(send an-editor-snip:decorated reset-min-sizes) -> void?
mixin
editor-snip:decorated-mixin : (class? . -> . class?)
  argument extends/implements: editor-snip%
  result implements: editor-snip:decorated<%>
method
(send an-editor-snip:decorated get-corner-bitmap)
 -> (or/c false/c (is-a?/c bitmap%))
method
(send an-editor-snip:decorated get-color)
 -> (or/c string? (is-a?/c color%))
method
(send an-editor-snip:decorated get-menu)
 -> (or/c false/c (is-a?/c popup-menu%))
method
(send an-editor-snip:decorated get-position)
 -> (symbols 'top-right 'left-top)
class
editor-snip:decorated% : class?
  superclass: (editor-snip:decorated-mixin editor-snip%)
constructor
(new editor-snip:decorated% ...superclass-args...)
 -> (is-a?/c editor-snip:decorated%)
method
(send an-editor-snip:decorated make-snip)
 -> (is-a?/c editor-snip:decorated%)
method
(send an-editor-snip:decorated make-editor)
 -> (is-a?/c editor<%>)
method
(send an-editor-snip:decorated copy)
 -> (is-a?/c editor-snip:decorated%)
class
editor-snip:decorated-snipclass% : class?
  superclass: snip-class%
method
(send an-editor-snip:decorated-snipclass make-snip stream-in)
 -> (is-a?/c editor-snip:decorated<%>)
  stream-in : (is-a?/c editor-stream-in%)
method
(send an-editor-snip:decorated-snipclass read stream-in)
 -> (is-a?/c editor-snip:decorated<%>)
  stream-in : (is-a?/c editor-stream-in%)
interface
editor:basic<%> : interface?
  implements: editor<%>
method
(send an-editor:basic has-focus?) -> boolean?
method
(send an-editor:basic local-edit-sequence?) -> boolean?
method
(send an-editor:basic run-after-edit-sequence  thunk     
                                              [tag]) -> void?
  thunk : (-> void?)
  tag : (or/c symbol? #f) = #f
method
(send an-editor:basic get-top-level-window)
 -> (or/c #f (is-a?/c top-level-window<%>))
method
(send an-editor:basic save-file-out-of-date?) -> boolean?
method
(send an-editor:basic save-file/gui-error [filename       
                                           format         
                                           show-errors?]) 
 -> boolean?
  filename : (or/c path? #f) = #f
  format : (or/c 'guess  'standard  'text  'text-force-cr  'same  'copy)
         = 'same
  show-errors? : boolean? = #t
method
(send an-editor:basic load-file/gui-error [filename       
                                           format         
                                           show-errors?]) 
 -> boolean?
  filename : (or/c string? #f) = #f
  format : (or/c 'guess  'standard  'text  'text-force-cr  'same  'copy)
         = 'guess
  show-errors? : boolean? = #t
method
(send an-editor:basic on-close) -> void?
method
(send an-editor:basic can-close?) -> boolean?
method
(send an-editor:basic close) -> boolean?
method
(send an-editor:basic get-filename/untitled-name) -> string?
method
(send an-editor:basic get-pos/text event)
 -> (or/c false/c number?)
    (or/c false/c (is-a?/c editor<%>))
  event : (is-a?/c mouse-event%)
method
(send an-editor:basic get-pos/text-dc-location x  
                                               y) 
 -> (or/c false/c number?)
    (or/c false/c (is-a?/c editor<%>))
  x : exact-integer?
  y : exact-integer?
mixin
editor:basic-mixin : (class? . -> . class?)
  argument extends/implements: editor<%>
  result implements: editor:basic<%>
method
(send an-editor:basic can-save-file? filename     
                                     format)  -> boolean?
  filename : string?
  format : symbol?
method
(send an-editor:basic after-save-file success?) -> void?
  success? : boolean?
method
(send an-editor:basic after-load-file success?) -> void?
  success? : boolean?
method
(send an-editor:basic on-focus on?) -> void?
  on? : boolean?
method
(send an-editor:basic on-edit-sequence) -> boolean?
method
(send an-editor:basic after-edit-sequence) -> void?
method
(send an-editor:basic on-new-box type) -> (is-a?/c editor-snip%)
  type : (or/c 'pasteboard  'text)
method
(send an-editor:basic on-new-image-snip filename       
                                        kind           
                                        relative-path? 
                                        inline?)       
 -> (is-a?/c image-snip%)
  filename : (or/c path? false/c)
  kind : (one-of/c 'unknown 'gif 'jpeg 'xbm 'xpm 'bmp 'pict)
  relative-path? : any/c
  inline? : any/c
method
(send an-editor:basic get-file directory) -> string
  directory : (or/c path-string? false/c)
method
(send an-editor:basic put-file directory         
                               default-name) -> string
  directory : (or/c path? false/c)
  default-name : (or/c path? false/c)
interface
editor:standard-style-list<%> : interface?
  implements: editor<%>
mixin
editor:standard-style-list-mixin : (class? . -> . class?)
  argument extends/implements: editor<%>
  result implements: editor:standard-style-list<%>
interface
editor:keymap<%> : interface?
  implements: editor:basic<%>
method
(send an-editor:keymap get-keymaps)
 -> (list-of (is-a?/c keymap%))
mixin
editor:keymap-mixin : (class? . -> . class?)
  argument extends/implements: editor:basic<%>
  result implements: editor:keymap<%>
interface
editor:autowrap<%> : interface?
  implements: editor:basic<%>
mixin
editor:autowrap-mixin : (class? . -> . class?)
  argument extends/implements: editor:basic<%>
  result implements: editor:autowrap<%>
interface
editor:file<%> : interface?
  implements: editor:keymap<%>
method
(send an-editor:file get-can-close-parent)
 -> (or/c false (is-a?/c frame%) (is-a?/c dialog%))
method
(send an-editor:file update-frame-filename) -> void?
method
(send an-editor:file allow-close-with-no-filename?) -> boolean?
method
(send an-editor:file user-saves-or-not-modified? allow-cancel?)
 -> boolean?
  allow-cancel? : #t
mixin
editor:file-mixin : (class? . -> . class?)
  argument extends/implements: editor:keymap<%>
  result implements: editor:file<%>
method
(send an-editor:file set-filename  name        
                                  [temp?]) -> void?
  name : string?
  temp? : boolean? = #f
method
(send an-editor:file can-close?) -> boolean?
method
(send an-editor:file get-keymaps)
 -> (list-of (is-a?/c keymap%))
interface
editor:backup-autosave<%> : interface?
  implements: editor:basic<%>
method
(send an-editor:backup-autosave backup?) -> boolean?
method
(send an-editor:backup-autosave autosave?) -> boolean?
method
(send an-editor:backup-autosave do-autosave) -> (or/c #f path?)
method
(send an-editor:backup-autosave remove-autosave) -> void?
mixin
editor:backup-autosave-mixin : (class? . -> . class?)
  argument extends/implements: editor:basic<%>
  result implements: editor:backup-autosave<%>
                     autosave:autosavable<%>
method
(send an-editor:backup-autosave on-save-file filename     
                                             format)  -> bool
  filename : path?
  format : (one-of/c 'guess  'standard  'text  'text-force-cr  'same  'copy)
method
(send an-editor:backup-autosave on-close) -> void?
method
(send an-editor:backup-autosave on-change) -> void?
method
(send an-editor:backup-autosave set-modified modified?) -> void?
  modified? : any/c
interface
editor:info<%> : interface?
  implements: editor:basic<%>
mixin
editor:info-mixin : (class? . -> . class?)
  argument extends/implements: editor:basic<%>
  result implements: editor:info<%>
method
(send an-editor:info lock lock?) -> void?
  lock? : boolean?
procedure
(editor:set-current-preferred-font-size new-size) -> void?
  new-size : exact-nonnegative-integer?
procedure
(editor:get-current-preferred-font-size)
 -> exact-nonnegative-integer?
procedure
(editor:font-size-pref->current-font-size font-preference)
 -> exact-nonnegative-integer?
  font-preference : (vector/c
                     
                     (hash/c
                     
                      (non-empty-listof (list/c exact-nonnegative-integer?
                                                exact-nonnegative-integer?))
                     
                      exact-nonnegative-integer?
                      #:flat? #t)
                     
                     
                     exact-nonnegative-integer?
                     #:flat? #t)
procedure
(editor:get-change-font-size-when-monitors-change?) -> boolean?
procedure
(editor:set-change-font-size-when-monitors-change? b?) -> void?
  b? : boolean?
procedure
(editor:set-default-font-color  fg-color       
                               [bg-color]) -> void?
  fg-color : (is-a?/c color%)
  bg-color : (or/c #f (is-a?/c color%)) = #f
procedure
(editor:get-default-color-style-name) -> string?
procedure
(editor:set-standard-style-list-delta name       
                                      delta) -> void?
  name : string?
  delta : (is-a?/c style-delta%)
procedure
(editor:set-standard-style-list-pref-callbacks) -> any
procedure
(editor:get-standard-style-list) -> (is-a?/c style-list%)
procedure
(editor:add-after-user-keymap keymap   
                              keymaps) 
 -> (listof (is-a?/c keymap%))
  keymap : (is-a?/c keymap%)
  keymaps : (listof (is-a?/c keymap%))
procedure
(exit:exiting?) -> boolean?
procedure
(exit:set-exiting exiting?) -> void?
  exiting? : boolean?
procedure
(exit:insert-on-callback callback) -> (-> void?)
  callback : (-> void?)
procedure
(exit:insert-can?-callback callback) -> (-> void?)
  callback : (-> boolean?)
procedure
(exit:can-exit?) -> boolean?
procedure
(exit:on-exit) -> void?
procedure
(exit:exit) -> any
procedure
(exit:user-oks-exit) -> boolean?
parameter
(finder:dialog-parent-parameter)
 -> (or/c false/c (is-a?/c dialog%) (is-a?/c frame%))
(finder:dialog-parent-parameter parent) -> void?
  parent : (or/c false/c (is-a?/c dialog%) (is-a?/c frame%))
parameter
(finder:default-extension) -> string?
(finder:default-extension extension) -> void?
  extension : string?
parameter
(finder:default-filters) -> (listof (list/c string? string?))
(finder:default-filters filters) -> void?
  filters : (listof (list/c string? string?))
procedure
(finder:common-put-file [name           
                         directory      
                         replace?       
                         prompt         
                         filter         
                         filter-msg     
                         parent])   -> (or/c false/c path?)
  name : string? = "Untitled"
  directory : (or/c false/c path?) = #f
  replace? : boolean? = #f
  prompt : string? = "Select File"
  filter : (or/c false/c byte-regexp?) = #f
  filter-msg : string?
             = "That filename does not have the right form."
  parent : (or/c (is-a?/c top-level-window<%>) false/c)
         = (finder:dialog-parent-parameter)
procedure
(finder:common-get-file [directory      
                         prompt         
                         filter         
                         filter-msg     
                         parent])   -> (or/c path? false/c)
  directory : (or/c path? false/c) = #f
  prompt : string? = "Select File"
  filter : (or/c byte-regexp? false/c) = #f
  filter-msg : string?
             = "That filename does not have the right form."
  parent : (or/c false/c (is-a?/c top-level-window<%>)) = #f
procedure
(finder:std-put-file [name           
                      directory      
                      replace?       
                      prompt         
                      filter         
                      filter-msg     
                      parent])   -> (or/c false/c path?)
  name : string? = "Untitled"
  directory : (or/c false/c path?) = #f
  replace? : boolean? = #f
  prompt : string? = "Select File"
  filter : (or/c false/c byte-regexp?) = #f
  filter-msg : string?
             = "That filename does not have the right form."
  parent : (or/c (is-a?/c top-level-window<%>) false/c)
         = (finder:dialog-parent-parameter)
procedure
(finder:std-get-file [directory      
                      prompt         
                      filter         
                      filter-msg     
                      parent])   -> (or/c path? false/c)
  directory : (or/c path? false/c) = #f
  prompt : string? = "Select File"
  filter : (or/c byte-regexp? false/c) = #f
  filter-msg : string?
             = "That filename does not have the right form."
  parent : (or/c false/c (is-a?/c top-level-window<%>)) = #f
procedure
(finder:put-file [name           
                  directory      
                  replace?       
                  prompt         
                  filter         
                  filter-msg     
                  parent])   -> (or/c false/c path?)
  name : string? = "Untitled"
  directory : (or/c false/c path?) = #f
  replace? : boolean? = #f
  prompt : string? = "Select File"
  filter : (or/c false/c byte-regexp?) = #f
  filter-msg : string?
             = "That filename does not have the right form."
  parent : (or/c (is-a?/c top-level-window<%>) false/c)
         = (finder:dialog-parent-parameter)
procedure
(finder:get-file [directory      
                  prompt         
                  filter         
                  filter-msg     
                  parent])   -> (or/c path? false/c)
  directory : (or/c path? false/c) = #f
  prompt : string? = "Select File"
  filter : (or/c byte-regexp? string? false/c) = #f
  filter-msg : string?
             = "That filename does not have the right form."
  parent : (or/c false/c (is-a?/c top-level-window<%>)) = #f
interface
frame:basic<%> : interface?
  implements: frame%
method
(send a-frame:basic get-area-container%)
 -> (implementation?/c area-container<%>)
method
(send a-frame:basic get-area-container)
 -> (is-a?/c area-container<%>)
method
(send a-frame:basic get-menu-bar%) -> (subclass?/c menu-bar%)
method
(send a-frame:basic make-root-area-container class   
                                             parent) 
 -> (is-a?/c area-container<%>)
  class : (implementation?/c area-container<%>)
  parent : (is-a?/c area-container<%>)
method
(send a-frame:basic close) -> void?
method
(send a-frame:basic editing-this-file? filename) -> boolean?
  filename : path?
method
(send a-frame:basic get-filename [temp]) -> (or/c #f path?)
  temp : (or/c #f (box boolean?)) = #f
method
(send a-frame:basic make-visible filename) -> void?
  filename : string?
mixin
frame:basic-mixin : (class? . -> . class?)
  argument extends/implements: frame%
  result implements: frame:basic<%>
method
(send a-frame:basic show on?) -> void?
  on? : boolean?
method
(send a-frame:basic can-exit?) -> boolean?
method
(send a-frame:basic on-exit) -> void?
method
(send a-frame:basic on-superwindow-show shown?) -> void?
  shown? : any/c
method
(send a-frame:basic on-drop-file pathname) -> void?
  pathname : string?
method
(send a-frame:basic after-new-child) -> void?
interface
frame:focus-table<%> : interface?
  implements: top-level-window<%>
mixin
frame:focus-table-mixin : (class? . -> . class?)
  argument extends/implements: frame%
  result implements: frame:focus-table<%>
method
(send a-frame:focus-table show on?) -> void?
  on? : boolean?
method
(send a-frame:focus-table on-close) -> void?
interface
frame:size-pref<%> : interface?
  implements: frame:basic<%>
method
(send a-frame:size-pref adjust-size-when-monitor-setup-changes?)
 -> boolean?
mixin
frame:size-pref-mixin : (class? . -> . class?)
  argument extends/implements: frame:basic<%>
  result implements: frame:size-pref<%>
constructor
(new frame:size-pref-mixin                                                      
                            [size-preferences-key size-preferences-key]         
                           [[position-preferences-key position-preferences-key] 
                            [width width]                                       
                            [height height]                                     
                            [x x]                                               
                            [y y]]                                              
                            ...superclass-args...)                              
 -> (is-a?/c frame:size-pref-mixin)
  size-preferences-key : symbol?
  position-preferences-key : (or/c symbol? #f) = #f
  width : (or/c dimension-integer? #f) = #f
  height : (or/c dimension-integer? #f) = #f
  x : (or/c position-integer? #f) = #f
  y : (or/c position-integer? #f) = #f
method
(send a-frame:size-pref on-size width       
                                height) -> void?
  width : dimension-integer?
  height : dimension-integer?
method
(send a-frame:size-pref on-move width       
                                height) -> void?
  width : position-integer?
  height : position-integer?
interface
frame:register-group<%> : interface?
mixin
frame:register-group-mixin : (class? . -> . class?)
  argument extends/implements: frame:basic<%>
  result implements: frame:register-group<%>
method
(send a-frame:register-group can-close?) -> boolean?
method
(send a-frame:register-group on-close) -> void?
method
(send a-frame:register-group on-activate on?) -> void?
  on? : boolean?
interface
frame:status-line<%> : interface?
  implements: frame:basic<%>
method
(send a-frame:status-line open-status-line id) -> void?
  id : symbol?
method
(send a-frame:status-line close-status-line id) -> void?
  id : symbol?
method
(send a-frame:status-line update-status-line id          
                                             status) -> void?
  id : symbol?
  status : (or/c #f string?)
mixin
frame:status-line-mixin : (class? . -> . class?)
  argument extends/implements: frame:basic<%>
  result implements: frame:status-line<%>
method
(send a-frame:status-line make-root-area-container class   
                                                   parent) 
 -> (is-a?/c panel%)
  class : (subclass?/c panel%)
  parent : (is-a?/c panel%)
interface
frame:info<%> : interface?
  implements: frame:basic<%>
method
(send a-frame:info determine-width str        
                                   canvas     
                                   text)  -> integer
  str : string
  canvas : (is-a?/c editor-canvas%)
  text : (is-a?/c text%)
method
(send a-frame:info lock-status-changed) -> void?
method
(send a-frame:info update-info) -> void?
method
(send a-frame:info set-info-canvas canvas) -> void?
  canvas : (or/c (is-a?/c canvas:basic%) #f)
method
(send a-frame:info get-info-canvas)
 -> (or/c (is-a?/c canvas:basic%) #f)
method
(send a-frame:info get-info-editor)
 -> (or/c #f (is-a?/c editor<%>))
method
(send a-frame:info get-info-panel)
 -> (is-a?/c horizontal-panel%)
method
(send a-frame:info show-info) -> void?
method
(send a-frame:info hide-info) -> void?
method
(send a-frame:info is-info-hidden?) -> boolean?
mixin
frame:info-mixin : (class? . -> . class?)
  argument extends/implements: frame:basic<%>
  result implements: frame:info<%>
method
(send a-frame:info make-root-area-container class   
                                            parent) 
 -> (is-a?/c area-container<%>)
  class : (subclass?/c area-container<%>)
  parent : (is-a?/c area-container<%>)
method
(send a-frame:info on-close) -> void?
interface
frame:text-info<%> : interface?
  implements: frame:info<%>
method
(send a-frame:text-info set-macro-recording on?) -> void?
  on? : boolean?
method
(send a-frame:text-info overwrite-status-changed) -> void?
method
(send a-frame:text-info anchor-status-changed) -> void?
method
(send a-frame:text-info editor-position-changed) -> void?
method
(send a-frame:text-info add-line-number-menu-items menu)
 -> void?
  menu : (is-a?/c menu-item-container<%>)
mixin
frame:text-info-mixin : (class? . -> . class?)
  argument extends/implements: frame:info<%>
  result implements: frame:text-info<%>
method
(send a-frame:text-info on-close) -> void?
method
(send a-frame:text-info update-info) -> void?
interface
frame:pasteboard-info<%> : interface?
  implements: frame:info<%>
mixin
frame:pasteboard-info-mixin : (class? . -> . class?)
  argument extends/implements: frame:basic<%>
  result implements: frame:pasteboard-info<%>
interface
frame:standard-menus<%> : interface?
  implements: frame:basic<%>
method
(send a-frame:standard-menus on-close) -> void?
method
(send a-frame:standard-menus get-menu%)
 -> (is-a?/c menu:can-restore-underscore-menu%)
method
(send a-frame:standard-menus get-menu-item%)
 -> (is-a?/c menu:can-restore-menu-item%)
method
(send a-frame:standard-menus get-checkable-menu-item%)
 -> (is-a?/c menu:can-restore-checkable-menu-item%)
method
(send a-frame:standard-menus get-file-menu) -> (is-a?/c menu%)
method
(send a-frame:standard-menus get-edit-menu) -> (is-a?/c menu%)
method
(send a-frame:standard-menus get-help-menu) -> (is-a?/c menu%)
method
(send a-frame:standard-menus file-menu:get-new-item)
 -> (or/c false/c (is-a?/c menu-item%))
method
(send a-frame:standard-menus file-menu:create-new?) -> boolean?
method
(send a-frame:standard-menus file-menu:new-callback item     
                                                    control) 
 -> void?
  item : (is-a?/c menu-item%)
  control : (is-a?/c control-event%)
method
(send a-frame:standard-menus file-menu:new-on-demand menu-item)
 -> void?
  menu-item : (is-a?/c menu-item%)
method
(send a-frame:standard-menus file-menu:new-string) -> string?
method
(send a-frame:standard-menus file-menu:new-help-string)
 -> string?
method
(send a-frame:standard-menus file-menu:between-new-and-open menu)
 -> void?
  menu : (is-a?/c menu-item%)
method
(send a-frame:standard-menus file-menu:get-open-item)
 -> (or/c false/c (is-a?/c menu-item%))
method
(send a-frame:standard-menus file-menu:create-open?)
 -> boolean?
method
(send a-frame:standard-menus file-menu:open-callback item     
                                                     control) 
 -> void?
  item : (is-a?/c menu-item%)
  control : (is-a?/c control-event%)
method
(send a-frame:standard-menus file-menu:open-on-demand menu-item)
 -> void?
  menu-item : (is-a?/c menu-item%)
method
(send a-frame:standard-menus file-menu:open-string) -> string?
method
(send a-frame:standard-menus file-menu:open-help-string)
 -> string?
method
(send a-frame:standard-menus file-menu:get-open-recent-item)
 -> (or/c false/c (is-a?/c menu-item%))
method
(send a-frame:standard-menus file-menu:create-open-recent?)
 -> boolean?
method
(send a-frame:standard-menus file-menu:open-recent-callback x  
                                                            y) 
 -> void?
  x : (is-a?/c menu-item%)
  y : (is-a?/c control-event%)
method
(send a-frame:standard-menus file-menu:open-recent-on-demand menu)
 -> void?
  menu : (is-a?/c menu-item%)
method
(send a-frame:standard-menus file-menu:open-recent-string)
 -> string?
method
(send a-frame:standard-menus file-menu:open-recent-help-string)
 -> string?
method
(send a-frame:standard-menus file-menu:between-open-and-revert menu)
 -> void?
  menu : (is-a?/c menu-item%)
method
(send a-frame:standard-menus file-menu:get-revert-item)
 -> (or/c false/c (is-a?/c menu-item%))
method
(send a-frame:standard-menus file-menu:create-revert?)
 -> boolean?
method
(send a-frame:standard-menus file-menu:revert-callback          
                                                       item     
                                                       control) 
 -> void?
  item : (is-a?/c menu-item%)
  control : (is-a?/c control-event%)
method
(send a-frame:standard-menus file-menu:revert-on-demand menu-item)
 -> void?
  menu-item : (is-a?/c menu-item%)
method
(send a-frame:standard-menus file-menu:revert-string)
 -> string?
method
(send a-frame:standard-menus file-menu:revert-help-string)
 -> string?
method
(send a-frame:standard-menus file-menu:between-revert-and-save menu)
 -> void?
  menu : (is-a?/c menu-item%)
method
(send a-frame:standard-menus file-menu:get-save-item)
 -> (or/c false/c (is-a?/c menu-item%))
method
(send a-frame:standard-menus file-menu:create-save?)
 -> boolean?
method
(send a-frame:standard-menus file-menu:save-callback item     
                                                     control) 
 -> void?
  item : (is-a?/c menu-item%)
  control : (is-a?/c control-event%)
method
(send a-frame:standard-menus file-menu:save-on-demand menu-item)
 -> void?
  menu-item : (is-a?/c menu-item%)
method
(send a-frame:standard-menus file-menu:save-string) -> string?
method
(send a-frame:standard-menus file-menu:save-help-string)
 -> string?
method
(send a-frame:standard-menus file-menu:get-save-as-item)
 -> (or/c false/c (is-a?/c menu-item%))
method
(send a-frame:standard-menus file-menu:create-save-as?)
 -> boolean?
method
(send a-frame:standard-menus file-menu:save-as-callback          
                                                        item     
                                                        control) 
 -> void?
  item : (is-a?/c menu-item%)
  control : (is-a?/c control-event%)
method
(send a-frame:standard-menus file-menu:save-as-on-demand menu-item)
 -> void?
  menu-item : (is-a?/c menu-item%)
method
(send a-frame:standard-menus file-menu:save-as-string)
 -> string?
method
(send a-frame:standard-menus file-menu:save-as-help-string)
 -> string?
method
(send a-frame:standard-menus file-menu:between-save-as-and-print menu)
 -> void?
  menu : (is-a?/c menu-item%)
method
(send a-frame:standard-menus file-menu:get-print-item)
 -> (or/c false/c (is-a?/c menu-item%))
method
(send a-frame:standard-menus file-menu:create-print?)
 -> boolean?
method
(send a-frame:standard-menus file-menu:print-callback item     
                                                      control) 
 -> void?
  item : (is-a?/c menu-item%)
  control : (is-a?/c control-event%)
method
(send a-frame:standard-menus file-menu:print-on-demand menu-item)
 -> void?
  menu-item : (is-a?/c menu-item%)
method
(send a-frame:standard-menus file-menu:print-string) -> string?
method
(send a-frame:standard-menus file-menu:print-help-string)
 -> string?
method
(send a-frame:standard-menus file-menu:between-print-and-close menu)
 -> void?
  menu : (is-a?/c menu-item%)
method
(send a-frame:standard-menus file-menu:get-close-item)
 -> (or/c false/c (is-a?/c menu-item%))
method
(send a-frame:standard-menus file-menu:create-close?)
 -> boolean?
method
(send a-frame:standard-menus file-menu:close-callback item     
                                                      control) 
 -> void?
  item : (is-a?/c menu-item%)
  control : (is-a?/c control-event%)
method
(send a-frame:standard-menus file-menu:close-on-demand menu-item)
 -> void?
  menu-item : (is-a?/c menu-item%)
method
(send a-frame:standard-menus file-menu:close-string) -> string?
method
(send a-frame:standard-menus file-menu:close-help-string)
 -> string?
method
(send a-frame:standard-menus file-menu:between-close-and-quit menu)
 -> void?
  menu : (is-a?/c menu-item%)
method
(send a-frame:standard-menus file-menu:get-quit-item)
 -> (or/c false/c (is-a?/c menu-item%))
method
(send a-frame:standard-menus file-menu:create-quit?)
 -> boolean?
method
(send a-frame:standard-menus file-menu:quit-callback item     
                                                     control) 
 -> void?
  item : (is-a?/c menu-item%)
  control : (is-a?/c control-event%)
method
(send a-frame:standard-menus file-menu:quit-on-demand menu-item)
 -> void?
  menu-item : (is-a?/c menu-item%)
method
(send a-frame:standard-menus file-menu:quit-string) -> string?
method
(send a-frame:standard-menus file-menu:quit-help-string)
 -> string?
method
(send a-frame:standard-menus file-menu:after-quit menu) -> void?
  menu : (is-a?/c menu-item%)
method
(send a-frame:standard-menus edit-menu:get-undo-item)
 -> (or/c false/c (is-a?/c menu-item%))
method
(send a-frame:standard-menus edit-menu:create-undo?)
 -> boolean?
method
(send a-frame:standard-menus edit-menu:undo-callback menu 
                                                     evt) 
 -> void?
  menu : (is-a?/c menu-item%)
  evt : (is-a?/c control-event%)
method
(send a-frame:standard-menus edit-menu:undo-on-demand item)
 -> void?
  item : (is-a?/c menu-item%)
method
(send a-frame:standard-menus edit-menu:undo-string) -> string?
method
(send a-frame:standard-menus edit-menu:undo-help-string)
 -> string?
method
(send a-frame:standard-menus edit-menu:get-redo-item)
 -> (or/c false/c (is-a?/c menu-item%))
method
(send a-frame:standard-menus edit-menu:create-redo?)
 -> boolean?
method
(send a-frame:standard-menus edit-menu:redo-callback menu 
                                                     evt) 
 -> void?
  menu : (is-a?/c menu-item%)
  evt : (is-a?/c control-event%)
method
(send a-frame:standard-menus edit-menu:redo-on-demand item)
 -> void?
  item : (is-a?/c menu-item%)
method
(send a-frame:standard-menus edit-menu:redo-string) -> string?
method
(send a-frame:standard-menus edit-menu:redo-help-string)
 -> string?
method
(send a-frame:standard-menus edit-menu:between-redo-and-cut menu)
 -> void?
  menu : (is-a?/c menu-item%)
method
(send a-frame:standard-menus edit-menu:get-cut-item)
 -> (or/c false/c (is-a?/c menu-item%))
method
(send a-frame:standard-menus edit-menu:create-cut?) -> boolean?
method
(send a-frame:standard-menus edit-menu:cut-callback menu 
                                                    evt) 
 -> void?
  menu : (is-a?/c menu-item%)
  evt : (is-a?/c control-event%)
method
(send a-frame:standard-menus edit-menu:cut-on-demand item)
 -> void?
  item : (is-a?/c menu-item%)
method
(send a-frame:standard-menus edit-menu:cut-string) -> string?
method
(send a-frame:standard-menus edit-menu:cut-help-string)
 -> string?
method
(send a-frame:standard-menus edit-menu:between-cut-and-copy menu)
 -> void?
  menu : (is-a?/c menu-item%)
method
(send a-frame:standard-menus edit-menu:get-copy-item)
 -> (or/c false/c (is-a?/c menu-item%))
method
(send a-frame:standard-menus edit-menu:create-copy?)
 -> boolean?
method
(send a-frame:standard-menus edit-menu:copy-callback menu 
                                                     evt) 
 -> void?
  menu : (is-a?/c menu-item%)
  evt : (is-a?/c control-event%)
method
(send a-frame:standard-menus edit-menu:copy-on-demand item)
 -> void?
  item : (is-a?/c menu-item%)
method
(send a-frame:standard-menus edit-menu:copy-string) -> string?
method
(send a-frame:standard-menus edit-menu:copy-help-string)
 -> string?
method
(send a-frame:standard-menus edit-menu:between-copy-and-paste menu)
 -> void?
  menu : (is-a?/c menu-item%)
method
(send a-frame:standard-menus edit-menu:get-paste-item)
 -> (or/c false/c (is-a?/c menu-item%))
method
(send a-frame:standard-menus edit-menu:create-paste?)
 -> boolean?
method
(send a-frame:standard-menus edit-menu:paste-callback menu 
                                                      evt) 
 -> void?
  menu : (is-a?/c menu-item%)
  evt : (is-a?/c control-event%)
method
(send a-frame:standard-menus edit-menu:paste-on-demand item)
 -> void?
  item : (is-a?/c menu-item%)
method
(send a-frame:standard-menus edit-menu:paste-string) -> string?
method
(send a-frame:standard-menus edit-menu:paste-help-string)
 -> string?
method
(send a-frame:standard-menus edit-menu:between-paste-and-clear menu)
 -> void?
  menu : (is-a?/c menu-item%)
method
(send a-frame:standard-menus edit-menu:get-clear-item)
 -> (or/c false/c (is-a?/c menu-item%))
method
(send a-frame:standard-menus edit-menu:create-clear?)
 -> boolean?
method
(send a-frame:standard-menus edit-menu:clear-callback menu 
                                                      evt) 
 -> void?
  menu : (is-a?/c menu-item%)
  evt : (is-a?/c control-event%)
method
(send a-frame:standard-menus edit-menu:clear-on-demand item)
 -> void?
  item : (is-a?/c menu-item%)
method
(send a-frame:standard-menus edit-menu:clear-string) -> string?
method
(send a-frame:standard-menus edit-menu:clear-help-string)
 -> string?
method
(send a-frame:standard-menus edit-menu:between-clear-and-select-all menu)
 -> void?
  menu : (is-a?/c menu-item%)
method
(send a-frame:standard-menus edit-menu:get-select-all-item)
 -> (or/c false/c (is-a?/c menu-item%))
method
(send a-frame:standard-menus edit-menu:create-select-all?)
 -> boolean?
method
(send a-frame:standard-menus edit-menu:select-all-callback      
                                                           menu 
                                                           evt) 
 -> void?
  menu : (is-a?/c menu-item%)
  evt : (is-a?/c control-event%)
method
(send a-frame:standard-menus edit-menu:select-all-on-demand item)
 -> void?
  item : (is-a?/c menu-item%)
method
(send a-frame:standard-menus edit-menu:select-all-string)
 -> string?
method
(send a-frame:standard-menus edit-menu:select-all-help-string)
 -> string?
method
(send a-frame:standard-menus edit-menu:between-select-all-and-find menu)
 -> void?
  menu : (is-a?/c menu-item%)
method
(send a-frame:standard-menus edit-menu:get-find-item)
 -> (or/c false/c (is-a?/c menu-item%))
method
(send a-frame:standard-menus edit-menu:create-find?)
 -> boolean?
method
(send a-frame:standard-menus edit-menu:find-callback item     
                                                     control) 
 -> void?
  item : (is-a?/c menu-item%)
  control : (is-a?/c control-event%)
method
(send a-frame:standard-menus edit-menu:find-on-demand item)
 -> void?
  item : (is-a?/c menu-item%)
method
(send a-frame:standard-menus edit-menu:find-string) -> string?
method
(send a-frame:standard-menus edit-menu:find-help-string)
 -> string?
method
(send a-frame:standard-menus edit-menu:get-find-from-selection-item)
 -> (or/c false/c (is-a?/c menu-item%))
method
(send a-frame:standard-menus edit-menu:create-find-from-selection?)
 -> boolean?
method
(send a-frame:standard-menus edit-menu:find-from-selection-callback          
                                                                    item     
                                                                    control) 
 -> void?
  item : (is-a?/c menu-item%)
  control : (is-a?/c control-event%)
method
(send a-frame:standard-menus edit-menu:find-from-selection-on-demand item)
 -> void?
  item : (is-a?/c menu-item%)
method
(send a-frame:standard-menus edit-menu:find-from-selection-string)
 -> string?
method
(send a-frame:standard-menus edit-menu:find-from-selection-help-string)
 -> string?
method
(send a-frame:standard-menus edit-menu:get-find-next-item)
 -> (or/c false/c (is-a?/c menu-item%))
method
(send a-frame:standard-menus edit-menu:create-find-next?)
 -> boolean?
method
(send a-frame:standard-menus edit-menu:find-next-callback          
                                                          item     
                                                          control) 
 -> void?
  item : (is-a?/c menu-item%)
  control : (is-a?/c control-event%)
method
(send a-frame:standard-menus edit-menu:find-next-on-demand item)
 -> void?
  item : (is-a?/c menu-item%)
method
(send a-frame:standard-menus edit-menu:find-next-string)
 -> string?
method
(send a-frame:standard-menus edit-menu:find-next-help-string)
 -> string?
method
(send a-frame:standard-menus edit-menu:get-find-previous-item)
 -> (or/c false/c (is-a?/c menu-item%))
method
(send a-frame:standard-menus edit-menu:create-find-previous?)
 -> boolean?
method
(send a-frame:standard-menus edit-menu:find-previous-callback          
                                                              item     
                                                              control) 
 -> void?
  item : (is-a?/c menu-item%)
  control : (is-a?/c control-event%)
method
(send a-frame:standard-menus edit-menu:find-previous-on-demand item)
 -> void?
  item : (is-a?/c menu-item%)
method
(send a-frame:standard-menus edit-menu:find-previous-string)
 -> string?
method
(send a-frame:standard-menus edit-menu:find-previous-help-string)
 -> string?
method
(send a-frame:standard-menus edit-menu:get-show/hide-replace-item)
 -> (or/c false/c (is-a?/c menu-item%))
method
(send a-frame:standard-menus edit-menu:create-show/hide-replace?)
 -> boolean?
method
(send a-frame:standard-menus edit-menu:show/hide-replace-callback          
                                                                  item     
                                                                  control) 
 -> void?
  item : (is-a?/c menu-item%)
  control : (is-a?/c control-event%)
method
(send a-frame:standard-menus edit-menu:show/hide-replace-on-demand menu-item)
 -> void?
  menu-item : (is-a?/c menu-item%)
method
(send a-frame:standard-menus edit-menu:show/hide-replace-string)
 -> string?
method
(send a-frame:standard-menus edit-menu:show/hide-replace-help-string)
 -> string?
method
(send a-frame:standard-menus edit-menu:get-replace-item)
 -> (or/c false/c (is-a?/c menu-item%))
method
(send a-frame:standard-menus edit-menu:create-replace?)
 -> boolean?
method
(send a-frame:standard-menus edit-menu:replace-callback          
                                                        item     
                                                        control) 
 -> void?
  item : (is-a?/c menu-item%)
  control : (is-a?/c control-event%)
method
(send a-frame:standard-menus edit-menu:replace-on-demand menu-item)
 -> void?
  menu-item : (is-a?/c menu-item%)
method
(send a-frame:standard-menus edit-menu:replace-string)
 -> string?
method
(send a-frame:standard-menus edit-menu:replace-help-string)
 -> string?
method
(send a-frame:standard-menus edit-menu:get-replace-all-item)
 -> (or/c false/c (is-a?/c menu-item%))
method
(send a-frame:standard-menus edit-menu:create-replace-all?)
 -> boolean?
method
(send a-frame:standard-menus edit-menu:replace-all-callback          
                                                            item     
                                                            control) 
 -> void?
  item : (is-a?/c menu-item%)
  control : (is-a?/c control-event%)
method
(send a-frame:standard-menus edit-menu:replace-all-on-demand menu-item)
 -> void?
  menu-item : (is-a?/c menu-item%)
method
(send a-frame:standard-menus edit-menu:replace-all-string)
 -> string?
method
(send a-frame:standard-menus edit-menu:replace-all-help-string)
 -> string?
method
(send a-frame:standard-menus edit-menu:get-find-case-sensitive-item)
 -> (or/c false/c (is-a?/c menu-item%))
method
(send a-frame:standard-menus edit-menu:create-find-case-sensitive?)
 -> boolean?
method
(send a-frame:standard-menus edit-menu:find-case-sensitive-callback          
                                                                    item     
                                                                    control) 
 -> void?
  item : (is-a?/c menu-item%)
  control : (is-a?/c control-event%)
method
(send a-frame:standard-menus edit-menu:find-case-sensitive-on-demand item)
 -> void?
  item : (is-a?/c menu-item%)
method
(send a-frame:standard-menus edit-menu:find-case-sensitive-string)
 -> string?
method
(send a-frame:standard-menus edit-menu:find-case-sensitive-help-string)
 -> string?
method
(send a-frame:standard-menus edit-menu:between-find-and-preferences menu)
 -> void?
  menu : (is-a?/c menu-item%)
method
(send a-frame:standard-menus edit-menu:get-preferences-item)
 -> (or/c false/c (is-a?/c menu-item%))
method
(send a-frame:standard-menus edit-menu:create-preferences?)
 -> boolean?
method
(send a-frame:standard-menus edit-menu:preferences-callback          
                                                            item     
                                                            control) 
 -> void?
  item : (is-a?/c menu-item%)
  control : (is-a?/c control-event%)
method
(send a-frame:standard-menus edit-menu:preferences-on-demand menu-item)
 -> void?
  menu-item : (is-a?/c menu-item%)
method
(send a-frame:standard-menus edit-menu:preferences-string)
 -> string?
method
(send a-frame:standard-menus edit-menu:preferences-help-string)
 -> string?
method
(send a-frame:standard-menus edit-menu:after-preferences menu)
 -> void?
  menu : (is-a?/c menu-item%)
method
(send a-frame:standard-menus help-menu:before-about menu)
 -> void?
  menu : (is-a?/c menu-item%)
method
(send a-frame:standard-menus help-menu:get-about-item)
 -> (or/c false/c (is-a?/c menu-item%))
method
(send a-frame:standard-menus help-menu:create-about?)
 -> boolean?
method
(send a-frame:standard-menus help-menu:about-callback item     
                                                      control) 
 -> void?
  item : (is-a?/c menu-item%)
  control : (is-a?/c control-event%)
method
(send a-frame:standard-menus help-menu:about-on-demand menu-item)
 -> void?
  menu-item : (is-a?/c menu-item%)
method
(send a-frame:standard-menus help-menu:about-string) -> string?
method
(send a-frame:standard-menus help-menu:about-help-string)
 -> string?
method
(send a-frame:standard-menus help-menu:after-about menu)
 -> void?
  menu : (is-a?/c menu-item%)
mixin
frame:standard-menus-mixin : (class? . -> . class?)
  argument extends/implements: frame:basic<%>
  result implements: frame:standard-menus<%>
method
(send a-frame:standard-menus on-close) -> void?
interface
frame:editor<%> : interface?
  implements: frame:standard-menus<%>
method
(send a-frame:editor get-entire-label) -> string
method
(send a-frame:editor get-label-prefix) -> string?
method
(send a-frame:editor set-label-prefix prefix) -> void?
  prefix : string?
method
(send a-frame:editor get-canvas%)
 -> (subclass?/c editor-canvas%)
method
(send a-frame:editor get-canvas<%>) -> (is-a?/c canvas:basic%)
method
(send a-frame:editor get-editor%)
 -> (implementation?/c editor<%>)
method
(send a-frame:editor get-editor<%>) -> interface?
method
(send a-frame:editor make-editor) -> (is-a?/c editor<%>)
method
(send a-frame:editor revert) -> void?
method
(send a-frame:editor save [format]) -> boolean?
  format : (or/c 'guess 'standard 'text 'text-force-cr 'same 'copy)
         = 'same
method
(send a-frame:editor save-as [format]) -> boolean?
  format : (or/c 'guess 'standard 'text 'text-force-cr 'same 'copy)
         = 'same
method
(send a-frame:editor get-canvas) -> (is-a?/c canvas%)
method
(send a-frame:editor get-editor) -> (is-a?/c editor<%>)
mixin
frame:editor-mixin : (class? . -> . class?)
  argument extends/implements: frame:standard-menus<%>
  result implements: frame:editor<%>
constructor
(new frame:editor-mixin                                            
                         [filename filename]                       
                         [editor% editor%]                         
                        [[parent parent]                           
                         [width width]                             
                         [height height]                           
                         [x x]                                     
                         [y y]                                     
                         [style style]                             
                         [enabled enabled]                         
                         [border border]                           
                         [spacing spacing]                         
                         [alignment alignment]                     
                         [min-width min-width]                     
                         [min-height min-height]                   
                         [stretchable-width stretchable-width]     
                         [stretchable-height stretchable-height]]) 
 -> (is-a?/c frame:editor-mixin)
  filename : string?
  editor% : (implementation?/c editor:basic<%>)
  parent : (or/c (is-a?/c frame%) false/c) = #f
  width : (or/c dimension-integer? false/c) = #f
  height : (or/c dimension-integer? false/c) = #f
  x : (or/c position-integer? false/c) = #f
  y : (or/c position-integer? false/c) = #f
  style : (listof (or/c 'no-resize-border = null
                        'no-caption
                        'no-system-menu
                        'hide-menu-bar
                        'mdi-parent
                        'mdi-child
                        'toolbar-button
                        'float
                        'metal))
  enabled : any/c = #t
  border : spacing-integer? = 0
  spacing : spacing-integer? = 0
  alignment : (list/c (or/c 'left 'center 'right) (or/c 'top 'center 'bottom))
            = '(center top)
  min-width : dimension-integer? = graphical-minimum-width
  min-height : dimension-integer? = graphical-minimum-height
  stretchable-width : any/c = #t
  stretchable-height : any/c = #t
method
(send a-frame:editor get-filename) -> (or/c #f path?)
method
(send a-frame:editor editing-this-file? filename) -> boolean?
  filename : path?
method
(send a-frame:editor on-close) -> void?
method
(send a-frame:editor can-close?) -> void?
method
(send a-frame:editor get-label) -> string?
method
(send a-frame:editor set-label label) -> void?
  label : string?
method
(send a-frame:editor file-menu:open-callback item     
                                             evt) -> void?
  item : (is-a?/c menu-item<%>)
  evt : (is-a?/c mouse-event%)
method
(send a-frame:editor file-menu:revert-on-demand) -> void?
method
(send a-frame:editor file-menu:revert-callback item     
                                               evt) -> void?
  item : (is-a?/c menu-item%)
  evt : (is-a?/c control-event%)
method
(send a-frame:editor file-menu:create-revert?) -> boolean?
method
(send a-frame:editor file-menu:save-callback item     
                                             evt) -> void?
  item : (is-a?/c menu-item%)
  evt : (is-a?/c control-event%)
method
(send a-frame:editor file-menu:create-save?) -> boolean?
method
(send a-frame:editor file-menu:save-as-callback item     
                                                evt) -> void?
  item : (is-a?/c menu-item%)
  evt : (is-a?/c control-event%)
method
(send a-frame:editor file-menu:create-save-as?) -> boolean?
method
(send a-frame:editor file-menu:print-callback item     
                                              evt) -> void?
  item : (is-a?/c menu-item%)
  evt : (is-a?/c control-event%)
method
(send a-frame:editor file-menu:create-print?) -> boolean?
method
(send a-frame:editor file-menu:between-save-as-and-print file-menu)
 -> void?
  file-menu : (is-a?/c menu%)
method
(send a-frame:editor edit-menu:between-select-all-and-find edit-menu)
 -> void?
  edit-menu : (is-a?/c menu%)
method
(send a-frame:editor help-menu:about-callback item     
                                              evt) -> void?
  item : (is-a?/c menu-item%)
  evt : (is-a?/c control-event%)
method
(send a-frame:editor help-menu:about-string) -> string
method
(send a-frame:editor help-menu:create-about?) -> boolean?
interface
frame:text<%> : interface?
  implements: frame:editor<%>
mixin
frame:text-mixin : (class? . -> . class?)
  argument extends/implements: frame:editor<%>
  result implements: frame:text<%>
constructor
(new frame:text-mixin [editor% editor%])
 -> (is-a?/c frame:text-mixin)
  editor% : (extends text%)
method
(send a-frame:text get-editor<%>) -> interface
interface
frame:pasteboard<%> : interface?
  implements: frame:editor<%>
mixin
frame:pasteboard-mixin : (class? . -> . class?)
  argument extends/implements: frame:editor<%>
  result implements: frame:pasteboard<%>
constructor
(new frame:pasteboard-mixin [editor% editor%])
 -> (is-a?/c frame:pasteboard-mixin)
  editor% : (extends pasteboard%)
method
(send a-frame:pasteboard get-editor<%>) -> interface
interface
frame:delegate<%> : interface?
  implements: frame:status-line<%>
              frame:text<%>
method
(send a-frame:delegate get-delegated-text)
 -> (or/c #f (is-a?/c text:delegate<%>))
method
(send a-frame:delegate set-delegated-text d) -> void?
  d : (or/c #f (is-a?/c text:delegate<%>))
method
(send a-frame:delegate delegated-text-shown?) -> boolean?
method
(send a-frame:delegate hide-delegated-text) -> void?
method
(send a-frame:delegate show-delegated-text) -> void?
method
(send a-frame:delegate delegate-moved) -> void?
mixin
frame:delegate-mixin : (class? . -> . class?)
  argument extends/implements: frame:status-line<%>
                               frame:text<%>
  result implements: frame:delegate<%>
method
(send a-frame:delegate make-root-area-container class   
                                                parent) 
 -> (is-a?/c panel%)
  class : (subclass?/c panel%)
  parent : (is-a?/c panel%)
method
(send a-frame:delegate get-editor<%>) -> interface
method
(send a-frame:delegate get-editor%)
 -> (is-a?/c text:delegate<%>)
interface
frame:searchable<%> : interface?
  implements: frame:basic<%>
method
(send a-frame:searchable search direction) -> void?
  direction : (symbols 'forward 'backward)
method
(send a-frame:searchable search-replace) -> boolean?
method
(send a-frame:searchable replace-all) -> void?
method
(send a-frame:searchable get-text-to-search) -> (is-a?/c text%)
method
(send a-frame:searchable set-text-to-search txt) -> void?
  txt : (or/c false/c (is-a?/c (subclass?/c text%)))
method
(send a-frame:searchable search-hidden?) -> boolean?
method
(send a-frame:searchable hide-search) -> void?
method
(send a-frame:searchable unhide-search                                                                          
                                        move-focus?                                                             
                                       [#:new-search-string-from-selection? new-search-string-from-selection?]) 
 -> void?
  move-focus? : boolean?
  new-search-string-from-selection? : boolean? = #f
method
(send a-frame:searchable unhide-search-and-toggle-focus [#:new-search-string-from-selection? new-search-string-from-selection?])
 -> void?
  new-search-string-from-selection? : boolean? = #f
method
(send a-frame:searchable get-case-sensitive-search?)
 -> boolean?
method
(send a-frame:searchable search-hits-changed) -> void?
mixin
frame:searchable-mixin : (class? . -> . class?)
  argument extends/implements: frame:standard-menus<%>
  result implements: frame:searchable<%>
method
(send a-frame:searchable edit-menu:find-callback) -> boolean?
method
(send a-frame:searchable edit-menu:create-find?) -> boolean?
method
(send a-frame:searchable edit-menu:find-again-callback item 
                                                       evt) 
 -> void?
  item : (is-a?/c menu-item%)
  evt : (is-a?/c control-event%)
method
(send a-frame:searchable edit-menu:create-find-again?)
 -> boolean?
method
(send a-frame:searchable edit-menu:find-again-backwards-callback      
                                                                 item 
                                                                 evt) 
 -> void?
  item : (is-a?/c menu-item%)
  evt : (is-a?/c control-event%)
method
(send a-frame:searchable edit-menu:create-find-again-backwards?)
 -> boolean?
method
(send a-frame:searchable edit-menu:replace-all-callback)
 -> boolean?
method
(send a-frame:searchable edit-menu:replace-all-on-demand item)
 -> void?
  item : menu-item%
method
(send a-frame:searchable edit-menu:create-replace-all?)
 -> boolean?
method
(send a-frame:searchable edit-menu:find-case-sensitive-callback)
 -> boolean?
method
(send a-frame:searchable edit-menu:find-case-sensitive-on-demand item)
 -> void?
  item : menu-item%
method
(send a-frame:searchable edit-menu:create-find-case-sensitive?)
 -> boolean?
method
(send a-frame:searchable make-root-area-container)
 -> (is-a?/c area-container<%>)
method
(send a-frame:searchable on-close) -> void?
interface
frame:searchable-text<%> : interface?
  implements: frame:searchable<%>
              frame:text<%>
mixin
frame:searchable-text-mixin : (class? . -> . class?)
  argument extends/implements: frame:text<%>
                               frame:searchable<%>
  result implements: frame:searchable-text<%>
method
(send a-frame:searchable-text get-text-to-search)
 -> (is-a?/c text%)
method
(send a-frame:searchable-text get-editor<%>)
 -> (is-a?/c editor<%>)
method
(send a-frame:searchable-text get-editor%)
 -> (is-a?/c editor<%>)
class
frame:basic% : class?
  superclass: (frame:register-group-mixin (frame:basic-mixin frame%))
class
frame:size-pref% : class?
  superclass: (frame:size-pref-mixin frame:basic%)
class
frame:info% : class?
  superclass: (frame:info-mixin frame:basic%)
class
frame:text-info% : class?
  superclass: (frame:text-info-mixin frame:info%)
class
frame:pasteboard-info% : class?
  superclass: (frame:pasteboard-info-mixin frame:text-info%)
class
frame:status-line% : class?
  superclass: (frame:status-line-mixin frame:text-info%)
class
frame:standard-menus% : class?
  superclass: (frame:standard-menus-mixin frame:status-line%)
class
frame:editor% : class?
  superclass: (frame:editor-mixin frame:standard-menus%)
class
frame:text% : class?
  superclass: (frame:text-mixin frame:editor%)
class
frame:searchable% : class?
  superclass: (frame:searchable-text-mixin (frame:searchable-mixin
frame:text%))
class
frame:delegate% : class?
  superclass: (frame:delegate-mixin frame:searchable%)
class
frame:pasteboard% : class?
  superclass: (frame:pasteboard-mixin frame:editor%)
procedure
(frame:setup-size-pref                                                    
                        size-pref-sym                                     
                        width                                             
                        height                                            
                       [#:maximized? maximized?                           
                        #:position-preferences position-preferences-sym]) 
 -> void?
  size-pref-sym : symbol?
  width : number?
  height : number?
  maximized? : boolean? = #f
  position-preferences-sym : (or/c #f symbol?) = #f
procedure
(frame:add-snip-menu-items  menu           
                            menu-item%     
                           [func])     -> void?
  menu : (is-a?/c menu%)
  menu-item% : (subclass?/c menu-item%)
  func : (-> (is-a?/c menu-item%) void?) = void
procedure
(frame:reorder-menus frame) -> void?
  frame : (is-a?/c frame%)
procedure
(frame:remove-empty-menus frame) -> void?
  frame : (is-a?/c frame%)
parameter
(frame:current-icon) -> (or/c #f
                              (is-a?/c bitmap%)
                              (cons/c (is-a?/c bitmap%)
                                      (is-a?/c bitmap%)))
(frame:current-icon icon-spec) -> void?
  icon-spec : (or/c #f
                    (is-a?/c bitmap%)
                    (cons/c (is-a?/c bitmap%)
                            (is-a?/c bitmap%)))
procedure
(frame:lookup-focus-table [eventspace])
 -> (listof (is-a?/c frame:focus-table<%>))
  eventspace : eventspace? = (current-eventspace)
class
group:% : class?
  superclass: object%
method
(send a-group: get-mdi-parent)
 -> (or/c false/c (is-a?/c frame%))
method
(send a-group: get-frames)
 -> (list-of (is-a?/c frame:basic<%>))
method
(send a-group: frame-label-changed frame) -> void?
  frame : (is-a?/c frame:basic<%>)
method
(send a-group: frame-shown/hidden) -> void?
method
(send a-group: for-each-frame f) -> void?
  f : ((is-a?/c frame:basic<%>) -> void?)
method
(send a-group: get-active-frame) -> (is-a?/c frame:basic<%>)
method
(send a-group: set-active-frame frame) -> void?
  frame : (is-a?/c frame:basic<%>)
method
(send a-group: insert-frame frame) -> void?
  frame : (is-a?/c frame:basic<%>)
method
(send a-group: remove-frame frame) -> void?
  frame : (is-a?/c frame:basic<%>)
method
(send a-group: clear) -> boolean?
method
(send a-group: on-close-all) -> void?
method
(send a-group: can-close-all?) -> boolean?
method
(send a-group: locate-file name)
 -> (or/c false/c (is-a?/c frame:basic<%>))
  name : path?
procedure
(group:get-the-frame-group) -> (is-a?/c group:%)
procedure
(group:on-close-action) -> void?
procedure
(group:can-close-check) -> boolean?
procedure
(group:add-to-windows-menu proc) -> any
  proc : (-> (is-a?/c menu%) any)
procedure
(group:create-windows-menu mb) -> (is-a?/c menu%)
  mb : (is-a?/c menu-item-container<%>)
procedure
(gui-utils:trim-string str size)
 -> (and/c string?
           (λ (str)
             ((string-length str) . <= . size)))
  str : string?
  size : (and/c number? positive?)
procedure
(gui-utils:quote-literal-label  string                    
                               [#:quote-amp? quote-amp?]) 
 -> (and/c string?
           (λ (str) ((string-length str) . <= . 200)))
  string : string?
  quote-amp? : any/c = #t
procedure
(gui-utils:format-literal-label str       
                                rest ...) 
 -> (and/c string?
           (lambda (str)
             ((string-length str) . <= . 200)))
  str : string?
  rest : (listof any/c)
procedure
(gui-utils:cancel-on-right?) -> boolean?
procedure
(gui-utils:ok/cancel-buttons  parent                          
                              confirm-callback                
                              cancel-callback                 
                             [confirm-label                   
                              cancel-label                    
                              #:confirm-style confirm-style]) 
 -> (is-a?/c button%) (is-a?/c button%)
  parent : (is-a?/c area-container<%>)
  confirm-callback : ((is-a?/c button%) (is-a?/c event%) . -> . any)
  cancel-callback : ((is-a?/c button%) (is-a?/c event%) . -> . any)
  confirm-label : string? = (string-constant ok)
  cancel-label : string? = (string-constant cancel)
  confirm-style : (listof symbol?) = '(border)
procedure
(gui-utils:next-untitled-name) -> string?
procedure
(gui-utils:cursor-delay) -> real?
(gui-utils:cursor-delay new-delay) -> void?
  new-delay : real?
procedure
(gui-utils:show-busy-cursor thunk [delay]) -> any/c
  thunk : (-> any/c)
  delay : integer? = (gui-utils:cursor-delay)
procedure
(gui-utils:delay-action delay-time     
                        open           
                        close)     -> (-> void?)
  delay-time : real?
  open : (-> void?)
  close : (-> void?)
procedure
(gui-utils:local-busy-cursor  window      
                              thunk       
                             [delay]) -> any/c
  window : (is-a?/c window<%>)
  thunk : (-> any/c)
  delay : integer? = (gui-utils:cursor-delay)
procedure
(gui-utils:unsaved-warning  filename      
                            action        
                           [can-save-now? 
                            parent        
                            cancel?])     
 -> (symbols 'continue 'save 'cancel)
  filename : string?
  action : string?
  can-save-now? : boolean? = #f
  parent : (or/c false/c            = #f
                 (is-a?/c frame%)
                 (is-a?/c dialog%))
  cancel? : boolean? = #t
procedure
(gui-utils:get-choice  message              
                       true-choice          
                       false-choice         
                      [title                
                       default-result       
                       parent               
                       style                
                       checkbox-proc        
                       checkbox-label]) -> any/c
  message : string?
  true-choice : string?
  false-choice : string?
  title : string? = (string-constant warning)
  default-result : any/c = 'disallow-close
  parent : (or/c false/c (is-a?/c frame%) (is-a?/c dialog%))
         = #f
  style : (symbols 'app 'caution 'stop) = 'app
  checkbox-proc : (or/c false/c (case-> (boolean? . -> . void?)
                                        (-> boolean?)))
                = #f
  checkbox-label : string? = (string-constant dont-ask-again)
procedure
(gui-utils:get-clicked-clickback-delta [white-on-black?])
 -> (is-a?/c style-delta%)
  white-on-black? : boolean? = #f
procedure
(gui-utils:get-clickback-delta [white-on-black?])
 -> (is-a?/c style-delta%)
  white-on-black? : boolean? = #f
procedure
(handler:handler? obj) -> boolean?
  obj : any/c
procedure
(handler:handler-name handler) -> string?
  handler : handler:handler?
procedure
(handler:handler-extension handler)
 -> (or/c (path? . -> . boolean?) (listof string?))
  handler : handler:handler?
procedure
(handler:handler-handler handler)
 -> (path? . -> . (is-a?/c frame:editor<%>))
  handler : handler:handler?
procedure
(handler:insert-format-handler name         
                               pred         
                               handler) -> void?
  name : string?
  pred : (or/c string? (listof string?) (path? . -> . boolean?))
  handler : (path? . -> . (or/c false/c (is-a?/c frame:editor<%>)))
procedure
(handler:find-named-format-handler name)
 -> (or/c #f (-> path? (is-a?/c frame:editor<%>)))
  name : string?
procedure
(handler:find-format-handler filename)
 -> (or/c #f (-> path? (is-a?/c frame:editor<%>)))
  filename : path?
procedure
(handler:edit-file filename [make-default])
 -> (or/c false/c (is-a?/c frame:editor<%>))
  filename : (or/c path? false/c)
  make-default : (-> (is-a?/c frame:editor<%>))
               = (λ () ((handler:current-create-new-window) filename))
parameter
(handler:current-create-new-window)
 -> (-> (or/c false/c path?) (is-a?/c frame%))
(handler:current-create-new-window proc) -> void?
  proc : (-> (or/c false/c path?) (is-a?/c frame%))
procedure
(handler:open-file [dir])
 -> (or/c false/c (is-a?/c frame:basic<%>))
  dir : (or/c false/c path? string?) = #f
procedure
(handler:install-recent-items menu) -> void?
  menu : (is-a?/c menu%)
procedure
(handler:set-recent-items-frame-superclass frame) -> void?
  frame : (implementation?/c frame:standard-menus<%>)
procedure
(handler:add-to-recent filename) -> void?
  filename : path?
procedure
(handler:set-recent-position filename     
                             start        
                             end)     -> void?
  filename : path?
  start : number?
  end : number?
procedure
(handler:size-recently-opened-files num) -> void?
  num : number?
procedure
(icon:get-paren-highlight-bitmap) -> (is-a?/c bitmap%)
procedure
(icon:get-eof-bitmap) -> (is-a?/c bitmap%)
procedure
(icon:get-autowrap-bitmap) -> (is-a?/c bitmap%)
procedure
(icon:get-lock-bitmap) -> (is-a?/c bitmap%)
procedure
(icon:get-unlock-bitmap) -> (is-a?/c bitmap%)
procedure
(icon:get-anchor-bitmap) -> (is-a?/c bitmap%)
procedure
(icon:get-left/right-cursor) -> (is-a?/c cursor%)
procedure
(icon:get-up/down-cursor) -> (is-a?/c cursor%)
procedure
(icon:get-gc-on-bitmap) -> (is-a?/c bitmap%)
procedure
(icon:get-gc-off-bitmap) -> (is-a?/c bitmap%)
interface
keymap:aug-keymap<%> : interface?
  implements: keymap%
method
(send a-keymap:aug-keymap get-chained-keymaps)
 -> (listof (is-a?/c keymap%))
method
(send a-keymap:aug-keymap get-map-function-table) -> hash?
method
(send a-keymap:aug-keymap get-map-function-table/ht ht) -> hash?
  ht : hash?
mixin
keymap:aug-keymap-mixin : (class? . -> . class?)
  argument extends/implements: keymap%
  result implements: keymap:aug-keymap<%>
method
(send a-keymap:aug-keymap chain-to-keymap next         
                                          prefix?) -> void
  next : (is-a?/c keymap%)
  prefix? : boolean?
method
(send a-keymap:aug-keymap remove-chained-keymap keymap) -> void
  keymap : (is-a?/c keymap)
method
(send a-keymap:aug-keymap map-function key-name           
                                       function-name) -> void
  key-name : string
  function-name : string
class
keymap:aug-keymap% : class?
  superclass: (keymap:aug-keymap-mixin keymap%)
procedure
(keymap:remove-user-keybindings-file user-keybindings-path)
 -> any
  user-keybindings-path : any/c
procedure
(keymap:add-user-keybindings-file user-keybindings-path-or-require-spec)
 -> any
  user-keybindings-path-or-require-spec : any/c
parameter
(keymap:add-to-right-button-menu) -> (-> (is-a?/c popup-menu%)
                                         (is-a?/c editor<%>)
                                         (is-a?/c event%)
                                         void?)
(keymap:add-to-right-button-menu proc) -> void?
  proc : (-> (is-a?/c popup-menu%)
             (is-a?/c editor<%>)
             (is-a?/c event%)
             void?)
parameter
(keymap:add-to-right-button-menu/before)
 -> (-> (is-a?/c popup-menu%) (is-a?/c editor<%>) (is-a?/c event%) void?)
(keymap:add-to-right-button-menu/before proc) -> void?
  proc : (-> (is-a?/c popup-menu%) (is-a?/c editor<%>) (is-a?/c event%) void?)
procedure
(keymap:call/text-keymap-initializer thunk-proc) -> any/c
  thunk-proc : (-> any/c)
procedure
(keymap:canonicalize-keybinding-string keybinding-string)
 -> string?
  keybinding-string : string?
procedure
(keymap:get-editor) -> (is-a?/c keymap%)
procedure
(keymap:get-file) -> (is-a?/c keymap%)
procedure
(keymap:get-user) -> (is-a?/c keymap%)
procedure
(keymap:get-global) -> (is-a?/c keymap%)
procedure
(keymap:get-search) -> (is-a?/c keymap%)
procedure
(keymap:make-meta-prefix-list  key                 
                              [mask-control?]) -> (listof string?)
  key : string?
  mask-control? : boolean? = #f
procedure
(keymap:send-map-function-meta                                            
                                keymap                                    
                                key                                       
                                func                                      
                               [mask-control?                             
                                #:alt-as-meta-keymap alt-as-meta-keymap]) 
 -> void?
  keymap : (is-a?/c keymap%)
  key : string?
  func : string?
  mask-control? : boolean? = #f
  alt-as-meta-keymap : (or/c (is-a?/c keymap%) #f) = #f
procedure
(keymap:setup-editor keymap) -> void?
  keymap : (is-a?/c keymap%)
procedure
(keymap:setup-file keymap) -> void?
  keymap : (is-a?/c keymap%)
procedure
(keymap:setup-global keymap) -> void?
  keymap : (is-a?/c keymap%)
procedure
(keymap:setup-search keymap) -> void?
  keymap : (is-a?/c keymap%)
procedure
(keymap:set-chained-keymaps keymap                
                            children-keymaps) -> void?
  keymap : (is-a?/c keymap:aug-keymap<%>)
  children-keymaps : (listof (is-a?/c keymap%))
procedure
(keymap:remove-chained-keymap editor      
                              keymap) -> void?
  editor : (is-a?/c editor<%>)
  keymap : (is-a?/c keymap:aug-keymap<%>)
procedure
(keymap:region-click text mouse-event f) -> any
  text : any/c
  mouse-event : any/c
  f : (-> number? boolean? number? number? any)
interface
menu:can-restore<%> : interface?
  implements: selectable-menu-item<%>
method
(send a-menu:can-restore restore-keybinding) -> void?
mixin
menu:can-restore-mixin : (class? . -> . class?)
  argument extends/implements: selectable-menu-item<%>
  result implements: menu:can-restore<%>
interface
menu:can-restore-underscore<%> : interface?
  implements: labelled-menu-item<%>
method
(send a-menu:can-restore-underscore erase-underscores) -> void?
method
(send a-menu:can-restore-underscore restore-underscores)
 -> void?
mixin
menu:can-restore-underscore-mixin : (class? . -> . class?)
  argument extends/implements: labelled-menu-item<%>
  result implements: menu:can-restore-underscore<%>
class
menu:can-restore-menu-item% : class?
  superclass: (menu:can-restore-mixin menu-item%)
class
menu:can-restore-checkable-menu-item% : class?
  superclass: (menu:can-restore-mixin checkable-menu-item%)
class
menu:can-restore-underscore-menu% : class?
  superclass: (menu:can-restore-underscore-mixin menu%)
interface
mode:surrogate-text<%> : interface?
method
(send a-mode:surrogate-text on-enable-surrogate txt) -> any
  txt : (is-a?/c text%)
method
(send a-mode:surrogate-text on-disable-surrogate txt) -> any
  txt : (is-a?/c text%)
class
mode:surrogate-text% : class?
  superclass: object%
  extends: mode:surrogate-text<%>
method
(send a-mode:surrogate-text on-change orig            
                                      call-inner) -> any
  orig : (is-a?/c text%)
  call-inner : (-> any)
method
(send a-mode:surrogate-text on-char orig           
                                    call-super     
                                    event)     -> any
  orig : (is-a?/c text%)
  call-super : (-> any)
  event : any/c
method
(send a-mode:surrogate-text on-default-char orig           
                                            call-super     
                                            event)     -> any
  orig : (is-a?/c text%)
  call-super : (-> any)
  event : any/c
method
(send a-mode:surrogate-text on-default-event orig           
                                             call-super     
                                             event)     -> any
  orig : (is-a?/c text%)
  call-super : (-> any)
  event : any/c
method
(send a-mode:surrogate-text on-display-size orig            
                                            call-inner) -> any
  orig : (is-a?/c text%)
  call-inner : (-> any)
method
(send a-mode:surrogate-text on-edit-sequence orig            
                                             call-inner) -> any
  orig : (is-a?/c text%)
  call-inner : (-> any)
method
(send a-mode:surrogate-text on-event orig           
                                     call-super     
                                     event)     -> any
  orig : (is-a?/c text%)
  call-super : (-> any)
  event : any/c
method
(send a-mode:surrogate-text on-focus orig           
                                     call-super     
                                     on?)       -> any
  orig : (is-a?/c text%)
  call-super : (-> any)
  on? : any/c
method
(send a-mode:surrogate-text on-load-file orig           
                                         call-inner     
                                         filename       
                                         format)    -> any
  orig : (is-a?/c text%)
  call-inner : (-> any)
  filename : any/c
  format : any/c
method
(send a-mode:surrogate-text on-local-char orig           
                                          call-super     
                                          event)     -> any
  orig : (is-a?/c text%)
  call-super : (-> any)
  event : any/c
method
(send a-mode:surrogate-text on-local-event orig           
                                           call-super     
                                           event)     -> any
  orig : (is-a?/c text%)
  call-super : (-> any)
  event : any/c
method
(send a-mode:surrogate-text on-new-box orig           
                                       call-super     
                                       type)      -> any
  orig : (is-a?/c text%)
  call-super : (-> any)
  type : any/c
method
(send a-mode:surrogate-text on-new-image-snip orig           
                                              call-super     
                                              filename       
                                              kind           
                                              relative-path? 
                                              inline?)       
 -> any
  orig : (is-a?/c text%)
  call-super : (-> any)
  filename : any/c
  kind : any/c
  relative-path? : any/c
  inline? : any/c
method
(send a-mode:surrogate-text on-paint orig            
                                     call-super      
                                     before?         
                                     dc              
                                     left            
                                     top             
                                     right           
                                     bottom          
                                     dx              
                                     dy              
                                     draw-caret) -> any
  orig : (is-a?/c text%)
  call-super : (-> any)
  before? : any/c
  dc : any/c
  left : any/c
  top : any/c
  right : any/c
  bottom : any/c
  dx : any/c
  dy : any/c
  draw-caret : any/c
method
(send a-mode:surrogate-text on-save-file orig           
                                         call-inner     
                                         filename       
                                         format)    -> any
  orig : (is-a?/c text%)
  call-inner : (-> any)
  filename : any/c
  format : any/c
method
(send a-mode:surrogate-text on-snip-modified orig           
                                             call-inner     
                                             snip           
                                             modified?) -> any
  orig : (is-a?/c text%)
  call-inner : (-> any)
  snip : any/c
  modified? : any/c
method
(send a-mode:surrogate-text on-change-style orig           
                                            call-inner     
                                            start          
                                            len)       -> any
  orig : (is-a?/c text%)
  call-inner : (-> any)
  start : any/c
  len : any/c
method
(send a-mode:surrogate-text on-delete orig           
                                      call-inner     
                                      start          
                                      len)       -> any
  orig : (is-a?/c text%)
  call-inner : (-> any)
  start : any/c
  len : any/c
method
(send a-mode:surrogate-text on-insert orig           
                                      call-inner     
                                      start          
                                      len)       -> any
  orig : (is-a?/c text%)
  call-inner : (-> any)
  start : any/c
  len : any/c
method
(send a-mode:surrogate-text on-new-string-snip orig        
                                               call-super) 
 -> any
  orig : (is-a?/c text%)
  call-super : (-> any)
method
(send a-mode:surrogate-text on-new-tab-snip orig            
                                            call-super) -> any
  orig : (is-a?/c text%)
  call-super : (-> any)
method
(send a-mode:surrogate-text on-set-size-constraint orig        
                                                   call-inner) 
 -> any
  orig : (is-a?/c text%)
  call-inner : (-> any)
method
(send a-mode:surrogate-text after-change-style orig       
                                               call-inner 
                                               start      
                                               len)       
 -> any
  orig : (is-a?/c text%)
  call-inner : (-> any)
  start : any/c
  len : any/c
method
(send a-mode:surrogate-text after-delete orig           
                                         call-inner     
                                         start          
                                         len)       -> any
  orig : (is-a?/c text%)
  call-inner : (-> any)
  start : any/c
  len : any/c
method
(send a-mode:surrogate-text after-insert orig           
                                         call-inner     
                                         start          
                                         len)       -> any
  orig : (is-a?/c text%)
  call-inner : (-> any)
  start : any/c
  len : any/c
method
(send a-mode:surrogate-text after-set-position orig        
                                               call-inner) 
 -> any
  orig : (is-a?/c text%)
  call-inner : (-> any)
method
(send a-mode:surrogate-text after-set-size-constraint             
                                                      orig        
                                                      call-inner) 
 -> any
  orig : (is-a?/c text%)
  call-inner : (-> any)
method
(send a-mode:surrogate-text after-edit-sequence orig        
                                                call-inner) 
 -> any
  orig : (is-a?/c text%)
  call-inner : (-> any)
method
(send a-mode:surrogate-text after-load-file orig           
                                            call-inner     
                                            success?)  -> any
  orig : (is-a?/c text%)
  call-inner : (-> any)
  success? : any/c
method
(send a-mode:surrogate-text after-save-file orig           
                                            call-inner     
                                            success?)  -> any
  orig : (is-a?/c text%)
  call-inner : (-> any)
  success? : any/c
method
(send a-mode:surrogate-text can-change-style? orig           
                                              call-inner     
                                              start          
                                              len)       -> any
  orig : (is-a?/c text%)
  call-inner : (-> any)
  start : any/c
  len : any/c
method
(send a-mode:surrogate-text can-delete? orig           
                                        call-inner     
                                        start          
                                        len)       -> any
  orig : (is-a?/c text%)
  call-inner : (-> any)
  start : any/c
  len : any/c
method
(send a-mode:surrogate-text can-insert? orig           
                                        call-inner     
                                        start          
                                        len)       -> any
  orig : (is-a?/c text%)
  call-inner : (-> any)
  start : any/c
  len : any/c
method
(send a-mode:surrogate-text can-set-size-constraint?             
                                                     orig        
                                                     call-inner) 
 -> any
  orig : (is-a?/c text%)
  call-inner : (-> any)
method
(send a-mode:surrogate-text can-do-edit-operation? orig       
                                                   call-super 
                                                   op)        
 -> any
  orig : (is-a?/c text%)
  call-super : (-> any)
  op : any/c
(send a-mode:surrogate-text can-do-edit-operation? orig        
                                                   call-super  
                                                   op          
                                                   recursive?) 
 -> any
  orig : (is-a?/c text%)
  call-super : (-> any)
  op : any/c
  recursive? : any/c
method
(send a-mode:surrogate-text can-load-file? orig           
                                           call-inner     
                                           filename       
                                           format)    -> any
  orig : (is-a?/c text%)
  call-inner : (-> any)
  filename : any/c
  format : any/c
method
(send a-mode:surrogate-text can-save-file? orig           
                                           call-inner     
                                           filename       
                                           format)    -> any
  orig : (is-a?/c text%)
  call-inner : (-> any)
  filename : any/c
  format : any/c
method
(send a-mode:surrogate-text put-file orig              
                                     call-super        
                                     directory         
                                     default-name) -> any
  orig : (is-a?/c text%)
  call-super : (-> any)
  directory : any/c
  default-name : any/c
interface
mode:host-text<%> : interface?
method
(send a-mode:host-text get-surrogate)
 -> (or/c false/c (is-a?/c mode:surrogate-text<%>))
method
(send a-mode:host-text set-surrogate surrogate) -> void?
  surrogate : (or/c false/c (is-a?/c mode:surrogate-text<%>))
mixin
mode:host-text-mixin : (class? . -> . class?)
  result implements: mode:host-text<%>
method
(send a-mode:host-text on-change) -> any
method
(send a-mode:host-text on-char event) -> any
  event : any/c
method
(send a-mode:host-text on-default-char event) -> any
  event : any/c
method
(send a-mode:host-text on-default-event event) -> any
  event : any/c
method
(send a-mode:host-text on-display-size) -> any
method
(send a-mode:host-text on-edit-sequence) -> any
method
(send a-mode:host-text on-event event) -> any
  event : any/c
method
(send a-mode:host-text on-focus on?) -> any
  on? : any/c
method
(send a-mode:host-text on-load-file filename     
                                    format)  -> any
  filename : any/c
  format : any/c
method
(send a-mode:host-text on-local-char event) -> any
  event : any/c
method
(send a-mode:host-text on-local-event event) -> any
  event : any/c
method
(send a-mode:host-text on-new-box type) -> any
  type : any/c
method
(send a-mode:host-text on-new-image-snip filename           
                                         kind               
                                         relative-path?     
                                         inline?)       -> any
  filename : any/c
  kind : any/c
  relative-path? : any/c
  inline? : any/c
method
(send a-mode:host-text on-paint before?         
                                dc              
                                left            
                                top             
                                right           
                                bottom          
                                dx              
                                dy              
                                draw-caret) -> any
  before? : any/c
  dc : any/c
  left : any/c
  top : any/c
  right : any/c
  bottom : any/c
  dx : any/c
  dy : any/c
  draw-caret : any/c
method
(send a-mode:host-text on-save-file filename     
                                    format)  -> any
  filename : any/c
  format : any/c
method
(send a-mode:host-text on-snip-modified snip           
                                        modified?) -> any
  snip : any/c
  modified? : any/c
method
(send a-mode:host-text on-change-style start     
                                       len)  -> any
  start : any/c
  len : any/c
method
(send a-mode:host-text on-delete start len) -> any
  start : any/c
  len : any/c
method
(send a-mode:host-text on-insert start len) -> any
  start : any/c
  len : any/c
method
(send a-mode:host-text on-new-string-snip) -> any
method
(send a-mode:host-text on-new-tab-snip) -> any
method
(send a-mode:host-text on-set-size-constraint) -> any
method
(send a-mode:host-text after-change-style start     
                                          len)  -> any
  start : any/c
  len : any/c
method
(send a-mode:host-text after-delete start     
                                    len)  -> any
  start : any/c
  len : any/c
method
(send a-mode:host-text after-insert start     
                                    len)  -> any
  start : any/c
  len : any/c
method
(send a-mode:host-text after-set-position) -> any
method
(send a-mode:host-text after-set-size-constraint) -> any
method
(send a-mode:host-text after-edit-sequence) -> any
method
(send a-mode:host-text after-load-file success?) -> any
  success? : any/c
method
(send a-mode:host-text after-save-file success?) -> any
  success? : any/c
method
(send a-mode:host-text can-change-style? start     
                                         len)  -> any
  start : any/c
  len : any/c
method
(send a-mode:host-text can-delete? start     
                                   len)  -> any
  start : any/c
  len : any/c
method
(send a-mode:host-text can-insert? start     
                                   len)  -> any
  start : any/c
  len : any/c
method
(send a-mode:host-text can-set-size-constraint?) -> any
method
(send a-mode:host-text can-do-edit-operation? op) -> any
  op : any/c
(send a-mode:host-text can-do-edit-operation? op              
                                              recursive?) -> any
  op : any/c
  recursive? : any/c
method
(send a-mode:host-text can-load-file? filename     
                                      format)  -> any
  filename : any/c
  format : any/c
method
(send a-mode:host-text can-save-file? filename     
                                      format)  -> any
  filename : any/c
  format : any/c
method
(send a-mode:host-text put-file directory         
                                default-name) -> any
  directory : any/c
  default-name : any/c
class
number-snip:snip-class% : class?
  superclass: snip-class%
method
(send a-number-snip:snip-class read f)
 -> (or/c (is-a?/c snip%) #f)
  f : (is-a?/c editor-stream-in%)
procedure
(number-snip:make-repeating-decimal-snip num           
                                         show-prefix?) 
 -> (is-a?/c snip%)
  num : real?
  show-prefix? : boolean?
procedure
(number-snip:make-fraction-snip num                           
                                show-prefix-in-decimal-view?) 
 -> (is-a?/c snip%)
  num : real?
  show-prefix-in-decimal-view? : boolean?
interface
panel:single<%> : interface?
  implements: area-container<%>
method
(send a-panel:single active-child child) -> void?
  child : (is-a?/c area<%>)
(send a-panel:single active-child) -> (is-a?/c area<%>)
mixin
panel:single-mixin : (class? . -> . class?)
  argument extends/implements: area-container<%>
  result implements: panel:single<%>
method
(send a-panel:single after-new-child child) -> void?
  child : (is-a?/c subarea<%>)
method
(send a-panel:single container-size)
 -> exact-integer? exact-integer?
method
(send a-panel:single place-children)
 -> (listof (list/c exact-integer? exact-integer? exact-integer? exact-integer?))
interface
panel:single-window<%> : interface?
  implements: panel:single<%>
              window<%>
mixin
panel:single-window-mixin : (class? . -> . class?)
  argument extends/implements: panel:single<%>
                               window<%>
  result implements: panel:single-window<%>
method
(send a-panel:single-window container-size info)
 -> exact-integer? exact-integer?
  info : (listof (list/c exact-integer?
                         exact-integer?
                         boolean?
                         boolean?))
class
panel:single% : class?
  superclass: (panel:single-window-mixin (panel:single-mixin panel%))
class
panel:single-pane% : class?
  superclass: (panel:single-mixin pane%)
interface
panel:dragable<%> : interface?
  implements: window<%>
              area-container<%>
method
(send a-panel:dragable after-percentage-change) -> void?
method
(send a-panel:dragable get-default-percentages subwindow-count)
 -> (listof (and/c real? (between/c 0 1)))
  subwindow-count : exact-positive-integer?
method
(send a-panel:dragable right-click-in-gap evt        
                                          before     
                                          after) -> void?
  evt : (is-a?/c mouse-event%)
  before : (is-a?/c subarea<%>)
  after : (is-a?/c subarea<%>)
method
(send a-panel:dragable set-percentages new-percentages) -> void?
  new-percentages : (listof number?)
method
(send a-panel:dragable get-percentages) -> (listof number?)
method
(send a-panel:dragable get-vertical?) -> boolean?
method
(send a-panel:dragable set-orientation horizontal?) -> void?
  horizontal? : boolean?
interface
panel:vertical-dragable<%> : interface?
  implements: panel:dragable<%>
interface
panel:horizontal-dragable<%> : interface?
  implements: panel:dragable<%>
mixin
panel:dragable-mixin : (class? . -> . class?)
  argument extends/implements: window<%>
                               area-container<%>
  result implements: panel:dragable<%>
method
(send a-panel:dragable after-new-child child) -> void?
  child : (is-a?/c subarea<%>)
method
(send a-panel:dragable on-subwindow-event receiver     
                                          event)   -> boolean?
  receiver : (is-a?/c window<%>)
  event : (is-a?/c mouse-event%)
method
(send a-panel:dragable place-children info 
                                      w    
                                      h)   
 -> (listof (list/c exact-integer? exact-integer? exact-integer? exact-integer?))
  info : (listof (list/c exact-integer? exact-integer?))
  w : exact-integer?
  h : exact-integer?
method
(send a-panel:dragable container-size info)
 -> exact-integer? exact-integer?
  info : (listof (list/c exact-integer? exact-integer? any/c any/c))
mixin
panel:vertical-dragable-mixin : (class? . -> . class?)
  argument extends/implements: panel:dragable<%>
  result implements: panel:vertical-dragable<%>
method
(send a-panel:vertical-dragable get-vertical?) -> boolean?
mixin
panel:horizontal-dragable-mixin : (class? . -> . class?)
  argument extends/implements: panel:dragable<%>
  result implements: panel:vertical-dragable<%>
method
(send a-panel:horizontal-dragable get-vertical?) -> boolean?
class
panel:vertical-dragable% : class?
  superclass: (panel:vertical-dragable-mixin (panel:dragable-mixin
panel%))
class
panel:horizontal-dragable% : class?
  superclass: (panel:horizontal-dragable-mixin (panel:dragable-mixin
panel%))
interface
panel:splitter<%> : interface?
mixin
panel:splitter-mixin : (class? . -> . class?)
  argument extends/implements: area-container<%>
                               panel:dragable<%>
  result implements: panel:splitter<%>
method
(send a-panel:splitter split-vertical canvas 
                                      maker) 
 -> (is-a?/c canvas<%>)
  canvas : (is-a?/c canvas<%>)
  maker : (-> (is-a?/c panel:splitter<%>)
              (is-a?/c canvas<%>))
method
(send a-panel:splitter split-horizontal canvas 
                                        maker) 
 -> (is-a?/c canvas<%>)
  canvas : (is-a?/c canvas<%>)
  maker : (-> (is-a?/c panel:splitter<%>)
              (is-a?/c canvas<%>))
method
(send a-panel:splitter collapse canvas) -> void
  canvas : (is-a?/c canvas<%>)
interface
panel:discrete-sizes<%> : interface?
method
(send a-panel:discrete-sizes set-orientation horizontal?)
 -> void?
  horizontal? : boolean?
method
(send a-panel:discrete-sizes get-orientation) -> boolean?
interface
panel:discrete-child<%> : interface?
method
(send a-panel:discrete-child get-discrete-widths)
 -> (listof exact-nonnegative-integer?)
method
(send a-panel:discrete-child get-discrete-heights)
 -> (listof exact-nonnegative-integer?)
mixin
panel:discrete-sizes-mixin : (class? . -> . class?)
  argument extends/implements: panel%
  result implements: panel:discrete-sizes<%>
                     panel:discrete-child<%>
class
panel:horizontal-discrete-sizes% : class?
  superclass: (panel:discrete-sizes-mixin panel%)
class
panel:vertical-discrete-sizes% : class?
  superclass: (panel:discrete-sizes-mixin panel%)
procedure
(panel:dragable-container-size container-info     
                               bar-thickness      
                               vertical?)     -> real? real?
  container-info : (listof (list/c real? real? boolean? boolean?))
  bar-thickness : real?
  vertical? : boolean?
procedure
(panel:dragable-place-children container-info 
                               width          
                               height         
                               percentages    
                               bar-thickness  
                               vertical?)     
 -> (listof (list/c (integer-in 0 10000)
                    (integer-in 0 10000)
                    (integer-in 0 10000)
                    (integer-in 0 10000)))
    (listof (list/c (integer-in 0 10000)
                    (integer-in 0 10000)))
  container-info : (listof (list/c real? real? boolean? boolean?))
  width : real?
  height : real?
  percentages : (listof (between/c 0 1))
  bar-thickness : real?
  vertical? : boolean?
class
pasteboard:basic% : class?
  superclass: (editor:basic-mixin pasteboard%)
class
pasteboard:standard-style-list% : class?
  superclass: (editor:standard-style-list-mixin pasteboard:basic%)
class
pasteboard:keymap% : class?
  superclass: (editor:keymap-mixin pasteboard:standard-style-list%)
class
pasteboard:file% : class?
  superclass: (editor:file-mixin pasteboard:keymap%)
class
pasteboard:backup-autosave% : class?
  superclass: (editor:backup-autosave-mixin pasteboard:file%)
class
pasteboard:info% : class?
  superclass: (editor:info-mixin pasteboard:backup-autosave%)
procedure
(path-utils:generate-autosave-name filename) -> path?
  filename : (or/c #f path-string? path-for-some-system?)
procedure
(path-utils:generate-backup-name filename) -> path?
  filename : path?
procedure
(preferences:put-preferences/gui name-list     
                                 val-list) -> any
  name-list : (listof symbol?)
  val-list : (listof any/c)
procedure
(preferences:get-preference/gui  sym           
                                [default]) -> any/c
  sym : symbol?
  default : (-> void?)
          = (λ () (error 'get-preference/gui "unknown pref ~s" sym))
procedure
(preferences:add-panel labels f) -> void?
  labels : (or/c string? (cons/c string? (listof string?)))
  f : (->i ([parent (is-a?/c area-container-window<%>)])
           ()
           [_ (parent)
              (let ([old-children (send parent get-children)])
                (and/c (is-a?/c area-container-window<%>)
                       (λ (child)
                         (andmap eq?
                                 (append old-children (list child))
                                 (send parent get-children)))))])
procedure
(preferences:add-editor-checkbox-panel) -> void?
procedure
(preferences:add-general-checkbox-panel) -> void?
procedure
(preferences:add-warnings-checkbox-panel) -> void?
procedure
(preferences:add-scheme-checkbox-panel) -> void?
procedure
(preferences:add-to-warnings-checkbox-panel proc) -> void?
  proc : ((is-a?/c vertical-panel%) . -> . void?)
procedure
(preferences:add-to-scheme-checkbox-panel proc) -> void?
  proc : ((is-a?/c vertical-panel%) . -> . void?)
procedure
(preferences:add-to-editor-checkbox-panel proc) -> void?
  proc : ((is-a?/c vertical-panel%) . -> . void?)
procedure
(preferences:add-to-general-checkbox-panel proc) -> void?
  proc : ((is-a?/c vertical-panel%) . -> . void?)
procedure
(preferences:add-font-panel) -> void?
procedure
(preferences:show-dialog) -> void?
procedure
(preferences:hide-dialog) -> void?
procedure
(preferences:add-on-close-dialog-callback cb) -> void?
  cb : (-> void?)
procedure
(preferences:add-can-close-dialog-callback cb) -> void?
  cb : (-> boolean?)
procedure
(preferences:add-check  parent           
                        pref-key         
                        label            
                       [from-boolean     
                        to-boolean]) -> void?
  parent : (is-a?/c area-container<%>)
  pref-key : symbol?
  label : string?
  from-boolean : (-> boolean? any/c) = values
  to-boolean : (-> any/c boolean?) = values
procedure
(preferences:get symbol) -> any/c
  symbol : symbol?
procedure
(preferences:set symbol value) -> void?
  symbol : symbol?
  value : any/c
procedure
(preferences:add-callback p f [weak?]) -> (-> void?)
  p : symbol?
  f : (-> symbol? any/c any)
  weak? : boolean? = #f
procedure
(preferences:set-default  symbol                              
                          value                               
                          test                                
                         [#:aliases aliases                   
                          #:rewrite-aliases rewrite-aliases]) 
 -> void?
  symbol : symbol?
  value : any/c
  test : (any/c . -> . any)
  aliases : (listof symbol?) = '()
  rewrite-aliases : (listof (-> any/c any))
                  = (map (lambda (x) values) aliases)
procedure
(preferences:default-set? pref) -> boolean?
  pref : symbol?
procedure
(preferences:set-un/marshall symbol          
                             marshall        
                             unmarshall) -> void?
  symbol : symbol?
  marshall : (any/c . -> . printable/c)
  unmarshall : (printable/c . -> . any/c)
procedure
(preferences:restore-defaults) -> void?
procedure
(preferences:register-save-callback callback) -> symbol?
  callback : (-> boolean? any)
procedure
(preferences:unregister-save-callback key) -> void?
  key : symbol?
procedure
(exn:make-unknown-preference message             
                             continuation-marks) 
 -> exn:unknown-preference?
  message : string?
  continuation-marks : continuation-mark-set?
procedure
(exn:unknown-preference? exn) -> boolean?
  exn : any/c
value
exn:struct:unknown-preference : struct-type?
parameter
(preferences:low-level-put-preferences)
 -> ((listof symbol?) (listof any/c) . -> . any)
(preferences:low-level-put-preferences put-preferences) -> void?
  put-preferences : ((listof symbol?) (listof any/c) . -> . any)
parameter
(preferences:low-level-get-preference)
 -> (->* (symbol?) [(-> any)] any)
(preferences:low-level-get-preference get-preference) -> void?
  get-preference : (->* (symbol?) [(-> any)] any)
procedure
(preferences:snapshot? arg) -> boolean?
  arg : any/c
procedure
(preferences:restore-prefs-snapshot snapshot) -> void?
  snapshot : preferences:snapshot?
procedure
(preferences:get-prefs-snapshot) -> preferences:snapshot?
interface
racket:sexp-snip<%> : interface?
method
(send a-racket:sexp-snip get-saved-snips)
 -> (listof (is-a?/c snip%))
class
racket:sexp-snip% : class?
  superclass: snip%
  extends: racket:sexp-snip<%>
           readable-snip<%>
method
(send a-racket:sexp-snip get-text  offset           
                                   num              
                                  [flattened?]) -> string?
  offset : number?
  num : number?
  flattened? : boolean? = #f
method
(send a-racket:sexp-snip copy) -> (is-a?/c racket:sexp-snip%)
method
(send a-racket:sexp-snip write stream-out) -> void?
  stream-out : (is-a?/c editor-stream-out%)
method
(send a-racket:sexp-snip draw dc              
                              x               
                              y               
                              left            
                              top             
                              right           
                              bottom          
                              dx              
                              dy              
                              draw-caret) -> void?
  dc : dc<%>
  x : real?
  y : real?
  left : real?
  top : real?
  right : real?
  bottom : real?
  dx : real?
  dy : real?
  draw-caret : symbol?
method
(send a-racket:sexp-snip get-extent  dc           
                                     x            
                                     y            
                                    [w            
                                     h            
                                     descent      
                                     space        
                                     lspace       
                                     rspace]) -> void?
  dc : (is-a?/c dc<%>)
  x : real?
  y : real?
  w : (or/c (box/c (and/c real? (not/c negative?))) #f) = #f
  h : (or/c (box/c (and/c real? (not/c negative?))) #f) = #f
  descent : (or/c (box/c (and/c real? (not/c negative?))) #f)
          = #f
  space : (or/c (box/c (and/c real? (not/c negative?))) #f) = #f
  lspace : (or/c (box/c (and/c real? (not/c negative?))) #f)
         = #f
  rspace : (or/c (box/c (and/c real? (not/c negative?))) #f)
         = #f
interface
racket:text<%> : interface?
  implements: text:basic<%>
              mode:host-text<%>
              color:text<%>
method
(send a-racket:text get-limit start) -> exact-integer?
  start : exact-integer?
method
(send a-racket:text balance-parens key-event) -> void?
  key-event : (is-a?/c key-event%)
method
(send a-racket:text tabify-on-return?) -> boolean?
method
(send a-racket:text tabify [start-pos]) -> void?
  start-pos : exact-integer? = (send this get-start-position)
method
(send a-racket:text tabify-selection [start     
                                      end]) -> void?
  start : exact-integer? = (send this get-start-position)
  end : exact-integer? = (send this get-end-position)
method
(send a-racket:text tabify-all) -> void?
method
(send a-racket:text compute-racket-amount-to-indent pos)
 -> exact-nonnegative-integer?
  pos : exact-nonnegative-integer?
method
(send a-racket:text compute-amount-to-indent pos)
 -> exact-nonnegative-integer?
  pos : exact-nonnegative-integer?
method
(send a-racket:text insert-return) -> void?
method
(send a-racket:text box-comment-out-selection start-pos 
                                              end-pos)  
 -> void?
  start-pos : (or/c (symbols 'start) exact-integer?)
  end-pos : (or/c (symbols 'end) exact-integer?)
method
(send a-racket:text comment-out-selection start     
                                          end)  -> void?
  start : exact-integer?
  end : exact-integer?
method
(send a-racket:text uncomment-selection start     
                                        end)  -> void?
  start : exact-integer?
  end : exact-integer?
method
(send a-racket:text get-forward-sexp start)
 -> (or/c #f exact-integer?)
  start : exact-integer?
method
(send a-racket:text remove-sexp start) -> void?
  start : exact-integer?
method
(send a-racket:text forward-sexp start) -> void?
  start : exact-integer?
method
(send a-racket:text flash-forward-sexp start-pos) -> void?
  start-pos : exact-integer?
method
(send a-racket:text get-backward-sexp start)
 -> (or/c exact-integer? #f)
  start : exact-integer?
method
(send a-racket:text flash-backward-sexp start-pos) -> void?
  start-pos : exact-integer?
method
(send a-racket:text backward-sexp start-pos) -> void?
  start-pos : exact-integer?
method
(send a-racket:text find-up-sexp start-pos)
 -> (or/c #f exact-integer?)
  start-pos : exact-integer?
method
(send a-racket:text up-sexp start) -> void?
  start : exact-integer?
method
(send a-racket:text find-down-sexp start-pos)
 -> (or/c #f exact-integer?)
  start-pos : exact-integer?
method
(send a-racket:text down-sexp start) -> void?
  start : exact-integer?
method
(send a-racket:text remove-parens-forward start) -> void?
  start : exact-integer?
method
(send a-racket:text select-forward-sexp) -> void?
method
(send a-racket:text select-backward-sexp) -> void?
method
(send a-racket:text select-up-sexp) -> void?
method
(send a-racket:text select-down-sexp) -> void?
method
(send a-racket:text transpose-sexp start) -> void?
  start : exact-integer?
method
(send a-racket:text mark-matching-parenthesis pos) -> void?
  pos : exact-positive-integer?
method
(send a-racket:text get-tab-size) -> exact-integer?
method
(send a-racket:text set-tab-size new-size) -> void?
  new-size : exact-integer?
method
(send a-racket:text introduce-let-ans start-pos) -> void?
  start-pos : exact-integer?
method
(send a-racket:text move-sexp-out start-pos) -> void?
  start-pos : exact-integer?
mixin
racket:text-mixin : (class? . -> . class?)
  argument extends/implements: text:basic<%>
                               mode:host-text<%>
                               color:text<%>
                               text:autocomplete<%>
  result implements: racket:text<%>
method
(send a-racket:text get-word-at pos) -> string?
  pos : exact-positive-integer?
method
(send a-racket:text get-start-of-line pos)
 -> exact-nonnegative-integer?
  pos : exact-nonnegative-integer?
interface
racket:text-mode<%> : interface?
mixin
racket:text-mode-mixin : (class? . -> . class?)
  argument extends/implements: color:text-mode<%>
                               mode:surrogate-text<%>
  result implements: racket:text-mode<%>
method
(send a-racket:text-mode on-disable-surrogate) -> void?
method
(send a-racket:text-mode on-enable-surrogate) -> void?
mixin
racket:set-mode-mixin : (class? . -> . class?)
  argument extends/implements: racket:text<%>
                               mode:host-text<%>
class
racket:text% : class?
  superclass: (racket:set-mode-mixin  (racket:text-mixin
  (text:autocomplete-mixin (mode:host-text-mixin color:text%))))
class
racket:text-mode% : class?
  superclass: (racket:text-mode-mixin color:text-mode%)
procedure
(racket:text-balanced? text [start end]) -> boolean?
  text : (is-a?/c text%)
  start : number? = 0
  end : (or/c false/c number?) = #f
procedure
(racket:add-preferences-panel) -> void?
procedure
(racket:get-keymap) -> (is-a?/c keymap%)
procedure
(racket:add-coloring-preferences-panel) -> any
procedure
(racket:get-color-prefs-table)
 -> (listof (list/c symbol? (is-a?/c color%) string?))
procedure
(racket:get-white-on-black-color-prefs-table)
 -> (listof (list/c symbol? (is-a?/c color%) string?))
procedure
(racket:short-sym->pref-name short-sym) -> symbol?
  short-sym : symbol?
procedure
(racket:short-sym->style-name short-sym) -> string?
  short-sym : symbol?
procedure
(racket:get-wordbreak-map) -> (is-a?/c editor-wordbreak-map%)
procedure
(racket:init-wordbreak-map key) -> void?
  key : (is-a?/c keymap%)
procedure
(racket:setup-keymap keymap) -> void?
  keymap : (is-a?/c keymap%)
interface
text:basic<%> : interface?
  implements: editor:basic<%>
              text%
method
(send a-text:basic highlight-range                                                    
                                    start                                             
                                    end                                               
                                    color                                             
                                   [caret-space                                       
                                    priority                                          
                                    style                                             
                                    #:adjust-on-insert/delete adjust-on-insert/delete 
                                    #:key key])                                       
 -> (if adjust-on-insert/delete
        void?
        (-> void?))
  start : exact-nonnegative-integer?
  end : exact-nonnegative-integer?
  color : (or/c string? (is-a?/c color%))
  caret-space : boolean? = #f
  priority : (or/c 'high 'low) = 'low
  style : (or/c 'rectangle 'ellipse 'hollow-ellipse 'dot)
        = 'rectangle
  adjust-on-insert/delete : boolean? = #f
  key : any/c = #f
method
(send a-text:basic unhighlight-range  start           
                                      end             
                                      color           
                                     [caret-space     
                                      style])     -> void?
  start : exact-nonnegative-integer?
  end : exact-nonnegative-integer?
  color : (or/c string? (is-a?/c color%))
  caret-space : boolean? = #f
  style : (or/c 'rectangle 'ellipse 'hollow-ellipse)
        = 'rectangle
method
(send a-text:basic unhighlight-ranges/key key) -> void?
  key : any/c
method
(send a-text:basic unhighlight-ranges pred?) -> void?
  pred? : (-> exact-nonnegative-integer?
              exact-nonnegative-integer?
              (is-a?/c color%)
              boolean?
              (or/c 'rectangle 'ellipse 'hollow-ellipse)
              (or/c boolean? exact-nonnegative-integer?)
              any/c
              boolean?)
method
(send a-text:basic get-highlighted-ranges)
 -> (listof text:range?)
method
(send a-text:basic get-styles-fixed) -> boolean?
method
(send a-text:basic get-fixed-style) -> (is-a?/c style<%>)
method
(send a-text:basic set-styles-fixed fixed?) -> void?
  fixed? : boolean?
method
(send a-text:basic move/copy-to-edit                                
                                      dest-text                     
                                      start                         
                                      end                           
                                      dest-pos                      
                                     [#:try-to-move? try-to-move?]) 
 -> void?
  dest-text : (is-a?/c text%)
  start : exact-integer?
  end : exact-integer?
  dest-pos : exact-integer?
  try-to-move? : boolean? = #t
method
(send a-text:basic initial-autowrap-bitmap)
 -> (or/c #f (is-a?/c bitmap%))
method
(send a-text:basic get-port-name)
 -> (or/c path-string? symbol? #f)
method
(send a-text:basic port-name-matches? id) -> boolean?
  id : any/c
method
(send a-text:basic set-port-unsaved-name name) -> void?
  name : string?
method
(send a-text:basic after-set-port-unsaved-name) -> any/c
method
(send a-text:basic get-edition-number)
 -> exact-nonnegative-integer?
method
(send a-text:basic get-start-of-line pos)
 -> exact-nonnegative-integer?
  pos : exact-nonnegative-integer?
mixin
text:basic-mixin : (class? . -> . class?)
  argument extends/implements: editor:basic<%>
                               text%
  result implements: text:basic<%>
method
(send a-text:basic on-paint before?         
                            dc              
                            left            
                            top             
                            right           
                            bottom          
                            dx              
                            dy              
                            draw-caret) -> void?
  before? : any/c
  dc : (is-a?/c dc<%>)
  left : real?
  top : real?
  right : real?
  bottom : real?
  dx : real?
  dy : real?
  draw-caret : (or/c 'no-caret
                     'show-inactive-caret
                     'show-caret)
method
(send a-text:basic on-insert start end) -> void?
  start : exact-nonnegative-integer?
  end : exact-nonnegative-integer?
method
(send a-text:basic after-insert start len) -> void?
  start : exact-nonnegative-integer?
  len : exact-nonnegative-integer?
method
(send a-text:basic put-file directory         
                            default-name) -> (or/c path? #f)
  directory : (or/c path? #f)
  default-name : string?
interface
text:line-spacing<%> : interface?
  implements: text:basic<%>
mixin
text:line-spacing-mixin : (class? . -> . class?)
  argument extends/implements: text:basic<%>
  result implements: text:line-spacing<%>
interface
text:first-line<%> : interface?
  implements: text%
method
(send a-text:first-line highlight-first-line on?) -> void?
  on? : boolean?
method
(send a-text:first-line first-line-currently-drawn-specially?)
 -> boolean?
method
(send a-text:first-line get-first-line-height) -> number?
method
(send a-text:first-line is-special-first-line? line) -> boolean?
  line : string?
mixin
text:first-line-mixin : (class? . -> . class?)
  argument extends/implements: text%
  result implements: text:first-line<%>
method
(send a-text:first-line on-paint before?         
                                 dc              
                                 left            
                                 top             
                                 right           
                                 bottom          
                                 dx              
                                 dy              
                                 draw-caret) -> void?
  before? : any/c
  dc : (is-a?/c dc<%>)
  left : real?
  top : real?
  right : real?
  bottom : real?
  dx : real?
  dy : real?
  draw-caret : (one-of/c 'no-caret 'show-inactive-caret 'show-caret)
method
(send a-text:first-line on-event event) -> void?
  event : (is-a?/c mouse-event%)
method
(send a-text:first-line scroll-editor-to localx       
                                         localy       
                                         width        
                                         height       
                                         refresh?     
                                         bias)    -> void?
  localx : real?
  localy : real?
  width : (and/c real? (not/c negative?))
  height : (and/c real? (not/c negative?))
  refresh? : any/c
  bias : (one-of/c 'start 'end 'none)
interface
text:foreground-color<%> : interface?
  implements: text:basic<%>
              editor:standard-style-list<%>
mixin
text:foreground-color-mixin : (class? . -> . class?)
  argument extends/implements: text:basic<%>
                               editor:standard-style-list<%>
  result implements: text:foreground-color<%>
method
(send a-text:foreground-color default-style-name) -> string?
method
(send a-text:foreground-color get-fixed-style)
 -> (is-a?/c style<%>)
interface
text:hide-caret/selection<%> : interface?
  implements: text:basic<%>
mixin
text:hide-caret/selection-mixin : (class? . -> . class?)
  argument extends/implements: text:basic<%>
  result implements: text:hide-caret/selection<%>
method
(send a-text:hide-caret/selection after-set-position) -> void?
interface
text:nbsp->space<%> : interface?
  implements: text%
mixin
text:nbsp->space-mixin : (class? . -> . class?)
  argument extends/implements: text%
  result implements: text:nbsp->space<%>
method
(send a-text:nbsp->space on-insert start     
                                   end)  -> void?
  start : exact-nonnegative-integer?
  end : exact-nonnegative-integer?
method
(send a-text:nbsp->space after-insert start     
                                      len)  -> void?
  start : exact-nonnegative-integer?
  len : exact-nonnegative-integer?
interface
text:column-guide<%> : interface?
  implements: text%
mixin
text:column-guide-mixin : (class? . -> . class?)
  argument extends/implements: text%
  result implements: text:column-guide<%>
method
(send a-text:column-guide on-paint before?         
                                   dc              
                                   left            
                                   top             
                                   right           
                                   bottom          
                                   dx              
                                   dy              
                                   draw-caret) -> void?
  before? : any/
  dc : (is-a?/c dc<%>)
  left : real?
  top : real?
  right : real?
  bottom : real?
  dx : real?
  dy : real?
  draw-caret : (or/c 'no-caret 'show-inactive-caret 'show-caret
                     (cons/c exact-nonnegative-integer?
                             exact-nonnegative-integer?))
method
(send a-text:column-guide on-change) -> void?
interface
text:normalize-paste<%> : interface?
  implements: text:basic<%>
method
(send a-text:normalize-paste ask-normalize?) -> boolean?
method
(send a-text:normalize-paste string-normalize s) -> string?
  s : string?
mixin
text:normalize-paste-mixin : (class? . -> . class?)
  argument extends/implements: text:basic<%>
  result implements: text:normalize-paste<%>
method
(send a-text:normalize-paste do-paste start     
                                      time) -> void?
  start : exact-nonnegative-integer?
  time : exact-integer?
method
(send a-text:normalize-paste on-insert start     
                                       len)  -> void?
  start : exact-nonnegative-integer?
  len : exact-nonnegative-integer?
method
(send a-text:normalize-paste after-insert start     
                                          len)  -> void?
  start : exact-nonnegative-integer?
  len : exact-nonnegative-integer?
interface
text:searching<%> : interface?
  implements: editor:keymap<%>
              text:basic<%>
method
(send a-text:searching set-searching-state str            
                                           cs?            
                                           replace-mode?  
                                           notify-frame?) 
 -> void?
  str : (or/c #f string?)
  cs? : boolean?
  replace-mode? : boolean?
  notify-frame? : boolean?
method
(send a-text:searching set-search-anchor position) -> void?
  position : (or/c #f number?)
method
(send a-text:searching get-search-hit-count) -> number?
method
(send a-text:searching get-replace-search-hit)
 -> (or/c number? #f)
method
(send a-text:searching set-replace-start pos) -> void?
  pos : (or/c number? #f)
method
(send a-text:searching finish-pending-search-work) -> void?
method
(send a-text:searching get-search-bubbles)
 -> (listof (list/c (cons/c number? number?)
                    (or/c 'normal-search-color
                          'dark-search-color
                          'light-search-color)))
mixin
text:searching-mixin : (class? . -> . class?)
  argument extends/implements: editor:keymap<%>
                               text:basic<%>
  result implements: text:searching<%>
method
(send a-text:searching get-keymaps)
 -> (listof (is-a?/c keymap%))
method
(send a-text:searching after-insert start     
                                    len)  -> void?
  start : exact-nonnegative-integer?
  len : exact-nonnegative-integer?
method
(send a-text:searching after-delete start     
                                    len)  -> void?
  start : exact-nonnegative-integer?
  len : exact-nonnegative-integer?
method
(send a-text:searching on-focus on?) -> void?
  on? : boolean?
interface
text:return<%> : interface?
  implements: text%
mixin
text:return-mixin : (class? . -> . class?)
  argument extends/implements: text%
  result implements: text:return<%>
constructor
(new text:return-mixin [return return])
 -> (is-a?/c text:return-mixin)
  return : (-> boolean?)
method
(send a-text:return on-local-char event) -> void?
  event : (is-a?/c key-event%)
interface
text:wide-snip<%> : interface?
  implements: text:basic<%>
method
(send a-text:wide-snip add-wide-snip snip) -> void?
  snip : (is-a?/c snip%)
method
(send a-text:wide-snip add-tall-snip snip) -> void?
  snip : (is-a?/c snip%)
mixin
text:wide-snip-mixin : (class? . -> . class?)
  argument extends/implements: text:basic<%>
  result implements: text:wide-snip<%>
interface
text:delegate<%> : interface?
  implements: text:basic<%>
method
(send a-text:delegate get-delegate)
 -> (or/c #f (is-a?/c text%))
method
(send a-text:delegate set-delegate delegate) -> void?
  delegate : (or/c #f (is-a?/c text%))
class
text:1-pixel-string-snip% : class?
  superclass: string-snip%
method
(send a-text:1-pixel-string-snip split position     
                                       first        
                                       second)  -> void?
  position : exact-nonnegative-integer?
  first : (box/c (is-a?/c snip%))
  second : (box/c (is-a?/c snip%))
method
(send a-text:1-pixel-string-snip copy) -> (is-a?/c snip%)
method
(send a-text:1-pixel-string-snip get-extent  dc           
                                             x            
                                             y            
                                            [w            
                                             h            
                                             descent      
                                             space        
                                             lspace       
                                             rspace]) -> void?
  dc : (is-a?/c dc<%>)
  x : real?
  y : real?
  w : (or/c (box/c (and/c real? (not/c negative?))) #f) = #f
  h : (or/c (box/c (and/c real? (not/c negative?))) #f) = #f
  descent : (or/c (box/c (and/c real? (not/c negative?))) #f)
          = #f
  space : (or/c (box/c (and/c real? (not/c negative?))) #f) = #f
  lspace : (or/c (box/c (and/c real? (not/c negative?))) #f)
         = #f
  rspace : (or/c (box/c (and/c real? (not/c negative?))) #f)
         = #f
method
(send a-text:1-pixel-string-snip insert  s         
                                         len       
                                        [pos]) -> void?
  s : string?
  len : exact-nonnegative-integer?
  pos : exact-nonnegative-integer? = 0
method
(send a-text:1-pixel-string-snip draw dc              
                                      x               
                                      y               
                                      left            
                                      top             
                                      right           
                                      bottom          
                                      dx              
                                      dy              
                                      draw-caret) -> void?
  dc : (is-a?/c dc<%>)
  x : real?
  y : real?
  left : real?
  top : real?
  right : real?
  bottom : real?
  dx : real?
  dy : real?
  draw-caret : (or/c 'no-caret 'show-inactive-caret 'show-caret)
class
text:1-pixel-tab-snip% : class?
  superclass: tab-snip%
method
(send a-text:1-pixel-tab-snip split position     
                                    first        
                                    second)  -> void?
  position : exact-nonnegative-integer?
  first : (box/c (is-a?/c snip%))
  second : (box/c (is-a?/c snip%))
method
(send a-text:1-pixel-tab-snip copy) -> (is-a?/c snip%)
method
(send a-text:1-pixel-tab-snip get-extent  dc           
                                          x            
                                          y            
                                         [w            
                                          h            
                                          descent      
                                          space        
                                          lspace       
                                          rspace]) -> void?
  dc : (is-a?/c dc<%>)
  x : real?
  y : real?
  w : (or/c (box/c (and/c real? (not/c negative?)) #f)) = #f
  h : (or/c (box/c (and/c real? (not/c negative?)) #f)) = #f
  descent : (or/c (box/c (and/c real? (not/c negative?)) #f))
          = #f
  space : (or/c (box/c (and/c real? (not/c negative?)) #f)) = #f
  lspace : (or/c (box/c (and/c real? (not/c negative?)) #f))
         = #f
  rspace : (or/c (box/c (and/c real? (not/c negative?)) #f))
         = #f
method
(send a-text:1-pixel-tab-snip draw dc              
                                   x               
                                   y               
                                   left            
                                   top             
                                   right           
                                   bottom          
                                   dx              
                                   dy              
                                   draw-caret) -> void?
  dc : (is-a?/c dc<%>)
  x : real?
  y : real?
  left : real?
  top : real?
  right : real?
  bottom : real?
  dx : real?
  dy : real?
  draw-caret : (or/c 'no-caret 'show-inactive-caret 'show-caret)
mixin
text:delegate-mixin : (class? . -> . class?)
  argument extends/implements: text:basic<%>
  result implements: text:delegate<%>
method
(send a-text:delegate highlight-range  start           
                                       end             
                                       color           
                                      [caret-space     
                                       priority        
                                       style])     -> (-> void?)
  start : exact-integer?
  end : exact-nonnegative-integer?
  color : (or/c string? (is-a?/c color%))
  caret-space : boolean? = #f
  priority : (or/c 'high 'low) = 'low
  style : (or/c 'rectangle 'ellipse 'hollow-ellipse 'dot)
        = 'rectangle
method
(send a-text:delegate unhighlight-range  start           
                                         end             
                                         color           
                                        [caret-space     
                                         style])     -> void?
  start : exact-nonnegative-integer?
  end : exact-nonnegative-integer?
  color : (or/c string? (is-a?/c color%))
  caret-space : boolean? = #f
  style : (or/c 'rectangle 'ellipse 'hollow-ellipse)
        = 'rectangle
method
(send a-text:delegate on-paint before?         
                               dc              
                               left            
                               top             
                               right           
                               bottom          
                               dx              
                               dy              
                               draw-caret) -> void?
  before? : any/c
  dc : (is-a?/c dc<%>)
  left : real?
  top : real?
  right : real?
  bottom : real?
  dx : real?
  dy : real?
  draw-caret : (one-of/c 'no-caret 'show-inactive-caret 'show-caret)
method
(send a-text:delegate on-edit-sequence) -> void?
method
(send a-text:delegate after-edit-sequence) -> void?
method
(send a-text:delegate resized snip             
                              redraw-now?) -> void?
  snip : (is-a?/c snip%)
  redraw-now? : boolean?
method
(send a-text:delegate after-insert start     
                                   len)  -> void?
  start : exact-nonnegative-integer?
  len : exact-nonnegative-integer?
method
(send a-text:delegate after-delete start     
                                   len)  -> void?
  start : exact-nonnegative-integer?
  len : exact-nonnegative-integer?
method
(send a-text:delegate after-change-style start     
                                         len)  -> void?
  start : exact-nonnegative-integer?
  len : exact-nonnegative-integer?
method
(send a-text:delegate on-load-file filename     
                                   format)  -> void?
  filename : string?
  format : symbol?
method
(send a-text:delegate after-load-file success?) -> void?
  success? : boolean?
interface
text:info<%> : interface?
  implements: text:basic<%>
mixin
text:info-mixin : (class? . -> . class?)
  argument extends/implements: editor:keymap<%>
                               text:basic<%>
  result implements: text:info<%>
method
(send a-text:info set-anchor on?) -> void?
  on? : any/c
method
(send a-text:info set-overwrite-mode on?) -> void?
  on? : any/c
method
(send a-text:info after-set-position) -> void?
method
(send a-text:info after-insert start len) -> void?
  start : exact-nonnegative-integer?
  len : exact-nonnegative-integer?
method
(send a-text:info after-delete start len) -> void?
  start : exact-nonnegative-integer?
  len : exact-nonnegative-integer?
interface
text:clever-file-format<%> : interface?
  implements: text%
mixin
text:clever-file-format-mixin : (class? . -> . class?)
  argument extends/implements: text%
  result implements: text:clever-file-format<%>
method
(send a-text:clever-file-format on-save-file filename     
                                             format)  -> void?
  filename : path?
  format : (or/c 'guess 'standard 'text
                 'text-force-cr 'same 'copy)
interface
text:crlf-line-endings<%> : interface?
  implements: text%
mixin
text:crlf-line-endings-mixin : (class? . -> . class?)
  argument extends/implements: text%
  result implements: text:crlf-line-endings<%>
method
(send a-text:crlf-line-endings after-load-file success?)
 -> void?
  success? : any/c
interface
text:file<%> : interface?
  implements: editor:file<%>
              text:basic<%>
method
(send a-text:file get-read-write?) -> boolean?
method
(send a-text:file while-unlocked thunk) -> any/c
  thunk : (-> any/c)
mixin
text:file-mixin : (class? . -> . class?)
  argument extends/implements: editor:file<%>
                               text:basic<%>
  result implements: text:file<%>
method
(send a-text:file can-insert? start len) -> boolean?
  start : exact-nonnegative-integer?
  len : exact-nonnegative-integer?
method
(send a-text:file can-delete? start len) -> boolean?
  start : exact-nonnegative-integer?
  len : exact-nonnegative-integer?
method
(send a-text:file after-save-file) -> void?
method
(send a-text:file after-load-file) -> void?
interface
text:ports<%> : interface?
method
(send a-text:ports delete/io start end) -> void?
  start : exact-integer?
  end : exact-integer?
method
(send a-text:ports insert/io str pos) -> void?
  str : string?
  pos : exact-integer?
method
(send a-text:ports do-submission) -> void?
method
(send a-text:ports get-insertion-point) -> exact-integer?
method
(send a-text:ports set-insertion-point ip) -> void?
  ip : exact-integer?
method
(send a-text:ports get-unread-start-point) -> exact-integer?
method
(send a-text:ports set-unread-start-point usp) -> void?
  usp : exact-integer?
method
(send a-text:ports set-allow-edits allow-edits?) -> void?
  allow-edits? : boolean?
method
(send a-text:ports get-allow-edits) -> boolean?
method
(send a-text:ports insert-between str) -> void?
  str : (or/c (is-a?/c snip%) string?)
method
(send a-text:ports insert-before str) -> void?
  str : (or/c (is-a?/c snip%) string?)
method
(send a-text:ports submit-to-port? key) -> boolean?
  key : (is-a?/c key-event%)
method
(send a-text:ports on-submit) -> void?
method
(send a-text:ports send-eof-to-in-port) -> void?
method
(send a-text:ports send-eof-to-box-in-port) -> void?
method
(send a-text:ports reset-input-box) -> void?
method
(send a-text:ports clear-output-ports) -> void?
method
(send a-text:ports clear-input-port) -> void?
method
(send a-text:ports clear-box-input-port) -> void?
method
(send a-text:ports get-out-style-delta)
 -> (or/c (is-a?/c style-delta%) string?)
method
(send a-text:ports get-err-style-delta)
 -> (or/c (is-a?/c style-delta%) string?)
method
(send a-text:ports get-value-style-delta)
 -> (or/c (is-a?/c style-delta%) string?)
method
(send a-text:ports get-in-port) -> input-port?
method
(send a-text:ports get-in-box-port) -> input-port?
method
(send a-text:ports get-out-port) -> output-port?
method
(send a-text:ports get-err-port) -> output-port?
method
(send a-text:ports get-value-port) -> output-port?
method
(send a-text:ports after-io-insertion) -> void?
method
(send a-text:ports get-box-input-editor-snip%)
 -> (subclass?/c editor-snip%)
method
(send a-text:ports get-box-input-text%)
 -> (is-a?/c text:input-box<%>)
mixin
text:ports-mixin : (class? . -> . class?)
  argument extends/implements: text:wide-snip<%>
  result implements: text:ports<%>
method
(send a-text:ports can-insert? start len) -> boolean?
  start : exact-integer?
  len : exact-integer?
method
(send a-text:ports can-delete? start len) -> boolean?
  start : exact-integer?
  len : exact-integer?
method
(send a-text:ports on-local-char event) -> void?
  event : (is-a?/c key-event%)
method
(send a-text:ports on-display-size) -> void?
interface
text:input-box<%> : interface?
  implements: text%
mixin
text:input-box-mixin : (class? . -> . class?)
  argument extends/implements: text%
  result implements: text:input-box<%>
method
(send a-text:input-box on-default-char event) -> void?
  event : (is-a?/c key-event%)
interface
text:autocomplete<%> : interface?
  implements: text%
method
(send a-text:autocomplete auto-complete) -> void?
method
(send a-text:autocomplete get-autocomplete-border-color)
 -> (or/c string? (is-a?/c color%))
method
(send a-text:autocomplete get-autocomplete-background-color)
 -> (or/c string? (is-a?/c color%))
method
(send a-text:autocomplete get-autocomplete-selected-color)
 -> (or/c string? (is-a?/c color%))
method
(send a-text:autocomplete completion-mode-key-event? key-event)
 -> boolean?
  key-event : (is-a?/c key-event%)
method
(send a-text:autocomplete get-all-words) -> (listof string?)
method
(send a-text:autocomplete get-word-at pos) -> string?
  pos : exact-positive-integer?
mixin
text:autocomplete-mixin : (class? . -> . class?)
  argument extends/implements: text%
  result implements: text:autocomplete<%>
method
(send a-text:autocomplete on-paint) -> void?
method
(send a-text:autocomplete on-char) -> void?
method
(send a-text:autocomplete on-event) -> void?
class
text:basic% : class?
  superclass: (text:basic-mixin (editor:basic-mixin text%))
class
text:line-spacing% : class?
  superclass: (text:line-spacing-mixin text:basic%)
class
text:hide-caret/selection% : class?
  superclass: (text:hide-caret/selection-mixin text:line-spacing%)
class
text:nbsp->space% : class?
  superclass: (text:nbsp->space-mixin text:line-spacing%)
class
text:normalize-paste% : class?
  superclass: (text:normalize-paste-mixin text:line-spacing%)
class
text:delegate% : class?
  superclass: (text:delegate-mixin text:line-spacing%)
class
text:wide-snip% : class?
  superclass: (text:wide-snip-mixin text:line-spacing%)
class
text:standard-style-list% : class?
  superclass: (editor:standard-style-list-mixin text:wide-snip%)
class
text:input-box% : class?
  superclass: (text:input-box-mixin text:standard-style-list%)
class
text:keymap% : class?
  superclass: (editor:keymap-mixin text:standard-style-list%)
class
text:return% : class?
  superclass: (text:return-mixin text:keymap%)
class
text:autowrap% : class?
  superclass: (editor:autowrap-mixin text:keymap%)
class
text:file% : class?
  superclass: (text:file-mixin (editor:file-mixin text:autowrap%))
class
text:clever-file-format% : class?
  superclass: (text:clever-file-format-mixin text:file%)
class
text:backup-autosave% : class?
  superclass: (editor:backup-autosave-mixin text:clever-file-format%)
class
text:searching% : class?
  superclass: (text:searching-mixin text:backup-autosave%)
class
text:info% : class?
  superclass: (text:info-mixin (editor:info-mixin text:searching%))
interface
text:line-numbers<%> : interface?
method
(send a-text:line-numbers show-line-numbers! show) -> void?
  show : boolean?
method
(send a-text:line-numbers show-line-numbers?) -> boolean?
method
(send a-text:line-numbers set-line-numbers-color color) -> void?
  color : string?
mixin
text:line-numbers-mixin : (class? . -> . class?)
  argument extends/implements: text%
  result implements: text:line-numbers<%>
method
(send a-text:line-numbers on-paint) -> void?
method
(send a-text:line-numbers show-line-numbers! show) -> void?
  show : boolean?
method
(send a-text:line-numbers show-line-numbers?) -> boolean?
method
(send a-text:line-numbers set-line-numbers-color color) -> void?
  color : string?
procedure
(text:range? arg) -> boolean?
  arg : any/c
procedure
(text:range-start range) -> exact-nonnegative-integer?
  range : text:range?
procedure
(text:range-end range) -> exact-nonnegative-integer?
  range : text:range?
procedure
(text:range-caret-space? range) -> boolean?
  range : text:range?
procedure
(text:range-style range) -> exact-nonnegative-integer?
  range : text:range?
procedure
(text:range-color range) -> (or/c string? (is-a?/c color%))
  range : text:range?
parameter
(text:autocomplete-append-after) -> string?
(text:autocomplete-append-after suffix) -> void?
  suffix : string?
parameter
(text:autocomplete-limit) -> (and/c integer? exact? positive?)
(text:autocomplete-limit count) -> void?
  count : (and/c integer? exact? positive?)
procedure
(text:get-completions/manuals manuals) -> (listof string?)
  manuals : (or/c false/c (listof symbol?))
procedure
(text:lookup-port-name manuals)
 -> (or/c (is-a?/c editor:basic<%>) false/c)
  manuals : symbol?
procedure
(start-splash  draw-spec                       
               splash-title                    
               width-default                   
              [#:allow-funny? allow-funny?     
               #:frame-icon frame-icon])   -> void?
  draw-spec : (or/c path-string?
                    (is-a?/c bitmap%)
                    (vector/c (or/c (-> (is-a?/c dc<%>) void?)
                                    (-> (is-a?/c dc<%>)
                                        exact-nonnegative-integer?
                                        exact-nonnegative-integer?
                                        exact-nonnegative-integer?
                                        exact-nonnegative-integer?
                                        void?))
                              exact-nonnegative-integer?
                              exact-nonnegative-integer?))
  splash-title : string?
  width-default : exact-nonnegative-integer?
  allow-funny? : boolean? = #f
  frame-icon : (or/c #f                          = #f
                     (is-a?/c bitmap%)
                     (cons/c (is-a?/c bitmap%)
                             (is-a?/c bitmap%)))
procedure
(shutdown-splash) -> void?
procedure
(close-splash) -> void?
procedure
(add-splash-icon bmp x y) -> void?
  bmp : (is-a?/c bitmap%)
  x : exact-nonnegative-integer?
  y : exact-nonnegative-integer?
procedure
(get-splash-bitmap) -> (or/c #f (is-a?/c bitmap%))
procedure
(set-splash-bitmap bmp) -> void?
  bmp : (is-a?/c bitmap%)
procedure
(get-splash-canvas) -> (is-a?/c canvas%)
procedure
(get-splash-eventspace) -> eventspace?
procedure
(get-splash-paint-callback) -> (-> (is-a?/c dc<%>)
                                   exact-nonnegative-integer?
                                   exact-nonnegative-integer?
                                   exact-nonnegative-integer?
                                   exact-nonnegative-integer?
                                   void?)
procedure
(set-splash-paint-callback cb) -> void?
  cb : (-> (is-a?/c dc<%>)
           exact-nonnegative-integer?
           exact-nonnegative-integer?
           exact-nonnegative-integer?
           exact-nonnegative-integer?
           void?)
procedure
(set-splash-progress-bar?! b) -> void?
  b : boolean?
procedure
(set-splash-char-observer obs) -> void?
  obs : (-> (is-a?/c key-event%) any)
procedure
(set-splash-event-callback obj) -> void?
  obj : (-> (is-?/c mouse-event%) any)
procedure
(get-splash-event-callback) -> (-> (is-?/c mouse-event%) any)
procedure
(set-refresh-splash-on-gauge-change?! proc) -> void?
  proc : (-> exact-nonnegative-integer?
             exact-nonnegative-integer?
             any)
procedure
(get-splash-width) -> exact-nonnegative-integer?
procedure
(get-splash-height) -> exact-nonnegative-integer?
procedure
(refresh-splash) -> void?
procedure
(test:button-push button) -> void?
  button : (or/c (and/c string?
                        label-of-enabled/shown-button-in-top-level-window?)
                 (and/c (is-a?/c button%)
                        enabled-shown-button?
                        button-in-top-level-focusd-window?))
procedure
(test:set-radio-box! radio-box state) -> void?
  radio-box : (or/c string? regexp? (is-a?/c radio-box%))
  state : (or/c string? number?)
procedure
(test:set-radio-box-item! entry) -> void?
  entry : (or/c string? regexp?)
procedure
(test:set-check-box! check-box state) -> void?
  check-box : (or/c string? (is-a?/c check-box%))
  state : boolean?
procedure
(test:set-choice! choice str) -> void?
  choice : (or/c string? (is-a?/c choice%))
  str : (or/c string? (and/c number? exact? integer? positive?))
procedure
(test:set-list-box! choice str/index) -> void?
  choice : (or/c string? (is-a?/c list-box%))
  str/index : (or/c string? exact-nonnegative-integer?)
procedure
(test:keystroke key [modifier-list]) -> void?
  key : (or/c char? symbol?)
  modifier-list : (listof (or/c 'alt 'control 'meta 'shift
                                'noalt 'nocontrol 'nometa 'noshift))
                = null
procedure
(test:menu-select menu items ...) -> void?
  menu : string?
  items : (listof string?)
procedure
(test:mouse-click button x y [modifiers]) -> void?
  button : (or/c 'left 'middle 'right)
  x : (and/c exact? integer?)
  y : (and/c exact? integer?)
  modifiers : (listof (or/c 'alt 'control 'meta 'shift 'noalt
                            'nocontrol 'nometa 'noshift))
            = null
procedure
(test:run-interval msec) -> void?
  msec : number?
(test:run-interval) -> number?
parameter
(test:current-get-eventspaces) -> (-> (listof eventspace?))
(test:current-get-eventspaces func) -> void?
  func : (-> (listof eventspace?))
procedure
(test:new-window window) -> void?
  window : (is-a?/c window<%>)
procedure
(test:close-top-level-window tlw) -> void?
  tlw : (is-a?/c top-level-window<%>)
procedure
(test:top-level-focus-window-has? test) -> boolean?
  test : (-> (is-a?/c area<%>) boolean?)
procedure
(test:number-pending-actions) -> number?
procedure
(test:reraise-error) -> void?
procedure
(test:run-one f) -> void?
  f : (-> void?)
parameter
(test:use-focus-table) -> (or/c boolean? 'debug)
(test:use-focus-table use-focus-table?) -> void?
  use-focus-table? : (or/c boolean? 'debug)
procedure
(test:get-active-top-level-window)
 -> (or/c (is-a?/c frame%) (is-a?/c dialog%) #f)
procedure
(label-of-enabled/shown-button-in-top-level-window? label)
 -> boolean?
  label : string?
procedure
(enabled-shown-button? button) -> boolean?
  button : (is-a?/c button%)
procedure
(button-in-top-level-focusd-window? button) -> boolean?
  button : (is-a?/c button%)
procedure
(version:add-spec spec revision) -> void?
  spec : any/c
  revision : any/c
procedure
(version:version) -> string?
syntax
scheme:text<%>
syntax
scheme:text-mixin
syntax
scheme:text%
syntax
scheme:text-mode<%>
syntax
scheme:text-mode-mixin
syntax
scheme:text-mode%
syntax
scheme:set-mode-mixin
syntax
scheme:sexp-snip%
syntax
scheme:sexp-snip<%>
syntax
scheme:get-wordbreak-map
syntax
scheme:init-wordbreak-map
syntax
scheme:get-keymap
syntax
scheme:setup-keymap
syntax
scheme:add-preferences-panel
syntax
scheme:add-coloring-preferences-panel
syntax
scheme:get-color-prefs-table
syntax
scheme:get-white-on-black-color-prefs-table
syntax
scheme:short-sym->pref-name
syntax
scheme:short-sym->style-name
syntax
scheme:text-balanced?
signature
framework^ : signature
signature
framework-class^ : signature
value
framework@ : unit?
