#lang racket/base
(require racket/format)
(require racket/date)
(date-display-format 'iso-8601)

(define (format-log lvl str . args)
  (define dt (current-date))
  (define hours (date-hour dt))
  (define minutes (date-minute dt))
  (define seconds (date-second dt))
  (define millisec
    (quotient (date*-nanosecond dt) 1000000))
  (format "~a ~a:~a:~a.~a >>> ~a ::: ~a"
          (date->string dt)
          (~a hours #:width 2 #:align 'right #:pad-string "0")
          (~a minutes #:width 2 #:align 'right #:pad-string "0")
          (~a seconds #:width 2 #:align 'right #:pad-string "0")
          (~a millisec #:width 3 #:align 'right #:pad-string "0")
          (string-upcase (symbol->string lvl))
          (apply format (cons str args))))

(define lk (make-semaphore 1))

(define print-log
  (lambda x
    (dynamic-wind
     (lambda() (semaphore-wait lk))
     (lambda () (displayln (apply format-log x)))
     (lambda () (semaphore-post lk)))))

(define (PANIC str . args)
  ;; Hang the system
  ;(start-atomic)
  ;; Print like Racket does
  (apply print-log (cons 'fatal (cons str args)))
  (exit 42))

(provide (all-defined-out))