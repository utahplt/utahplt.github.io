182
((3) 0 () 1 ((q lib "contract-profile/main.rkt")) () (h ! (equal) ((c def c (c (? . 0) q contract-profile-thunk)) q (37 . 3)) ((c form c (c (? . 0) q contract-profile)) q (0 . 2))))
syntax
(contract-profile body ...)
procedure
(contract-profile-thunk thunk) -> any
  thunk : (-> any)
