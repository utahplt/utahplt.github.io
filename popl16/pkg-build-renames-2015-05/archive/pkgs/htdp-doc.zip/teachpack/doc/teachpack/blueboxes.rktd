22131
((3) 0 () 29 ((q lib "2htdp/image.rkt") (q lib "teachpack/2htdp/abstraction.rkt") (q 39300 . 9) (q lib "htdp/image.rkt") (q lib "2htdp/universe.rkt") (q lib "htdp/docs.rkt") (q lib "2htdp/planetcute.rkt") (q lib "htdp/dir.rkt") (q lib "htdp/matrix.rkt") (q lib "2htdp/batch-io.rkt") (q 10303 . 6) (q lib "htdp/big-draw.rkt") (q 10465 . 6) (q lib "htdp/world.rkt") (q 39868 . 8) (q lib "htdp/convert.rkt") (q 4310 . 7) (q 126 . 6) (q lib "htdp/arrow-gui.rkt") (q lib "htdp/gui.rkt") (q lib "htdp/arrow.rkt") (q 38999 . 7) (q lib "teachpack/2htdp/image.rkt") (q 44931 . 3) (q lib "htdp/guess-gui.rkt") (q lib "htdp/hangman.rkt") (q lib "htdp/graphing.rkt") (q lib "htdp/lkup-gui.rkt") (q lib "htdp/guess.rkt")) () (h ! (equal) ((c form c (c (? . 1) q for/string)) q (48768 . 2)) ((c def c (c (? . 0) q place-images)) q (35202 . 5)) ((c def c (c (? . 0) q scene+polygon)) q (31938 . 6)) ((c def c (c (? . 3) q alpha-color-list->image)) q (4712 . 7)) ((c form c (c (? . 1) q for*/sum)) q (48521 . 2)) ((c def c (c (? . 0) q pulled-point-lpull)) c (? . 2)) ((c form c (c (? . 4) q shift)) q (44325 . 4)) ((c def c (c (? . 0) q overlay/pinhole)) q (40661 . 5)) ((c def c (c (? . 19) q choice-index)) q (11594 . 3)) ((c def c (c (? . 5) q end-annotation)) q (10174 . 3)) ((c def c (c (? . 0) q pulled-point-langle)) c (? . 2)) ((c def c (c (? . 3) q find-image)) q (2530 . 4)) ((c form c (c (? . 4) q left)) q (44087 . 4)) ((c def c (c (? . 0) q radial-star)) q (28830 . 21)) ((q def ((lib "htdp/elevator.rkt") run)) q (11871 . 3)) ((c def c (c (? . 6) q roof-north)) q (50867 . 2)) ((c def c (c (? . 0) q color)) c (? . 21)) ((c def c (c (? . 3) q color?)) c (? . 17)) ((c def c (c (? . 7) q struct:file)) c (? . 12)) ((c def c (c (? . 3) q image-width)) q (1558 . 3)) ((c def c (c (? . 0) q x-place?)) q (39585 . 3)) ((c def c (c (? . 0) q beside)) q (33898 . 5)) ((c def c (c (? . 5) q annotation?)) q (10117 . 3)) ((c def c (c (? . 15) q convert-gui)) q (6409 . 3)) ((c def c (c (? . 0) q text)) q (18060 . 5)) ((c form c (c (? . 1) q for/or)) q (48126 . 2)) ((c def c (c (? . 3) q overlay)) q (2172 . 5)) ((c def c (c (? . 0) q overlay/align)) q (32203 . 7)) ((c form c (c (? . 4) q to-string)) q (47507 . 4)) ((c def c (c (? . 6) q character-horn-girl)) q (49760 . 2)) ((c def c (c (? . 3) q image-color?)) q (368 . 3)) ((c form c (c (? . 4) q on-receive)) q (45529 . 4)) ((c form c (c (? . 4) q pad-handler)) q (43717 . 9)) ((c def c (c (? . 25) q hangman-list)) q (9190 . 6)) ((c def c (c (? . 0) q flip-vertical)) q (36858 . 3)) ((c def c (c (? . 3) q rectangle)) q (424 . 6)) ((c def c (c (? . 0) q mode?)) q (38890 . 3)) ((c def c (c (? . 3) q scene?)) q (3257 . 3)) ((c def c (c (? . 8) q build-matrix)) q (12929 . 7)) ((c def c (c (? . 3) q image->color-list)) q (4030 . 3)) ((q def ((lib "htdp/hangman-play.rkt") go)) q (9450 . 3)) ((c def c (c (? . 7) q struct:dir)) c (? . 10)) ((c def c (c (? . 9) q read-xexpr/web)) q (15349 . 3)) ((c def c (c (? . 0) q make-pen)) c (? . 14)) ((c def c (c (? . 4) q key-event?)) q (43167 . 3)) ((c def c (c (? . 4) q iworld-name)) q (45756 . 3)) ((c def c (c (? . 0) q overlay/offset)) q (32380 . 6)) ((q def ((lib "htdp/show-queen.rkt") show-queen)) q (12403 . 3)) ((c def c (c (? . 11) q draw-circle)) q (7430 . 5)) ((c def c (c (? . 8) q rectangle->matrix)) q (12675 . 3)) ((c form c (c (? . 4) q right)) q (44165 . 4)) ((c def c (c (? . 4) q run-movie)) q (41674 . 4)) ((c def c (c (? . 9) q read-csv-file/rows)) q (14845 . 4)) ((c def c (c (? . 0) q flip-horizontal)) q (36790 . 3)) ((c def c (c (? . 7) q dir-name)) c (? . 10)) ((c def c (c (? . 0) q bitmap/url)) q (37719 . 3)) ((c def c (c (? . 0) q real-valued-posn?)) q (39805 . 3)) ((c def c (c (? . 3) q shrink)) q (3088 . 7)) ((c def c (c (? . 9) q url-html-neighbors)) q (15646 . 3)) ((c def c (c (? . 11) q stop)) q (7403 . 2)) ((c def c (c (? . 11) q sleep-for-a-while)) q (7959 . 3)) ((c def c (c (? . 9) q read-words)) q (14307 . 3)) ((c def c (c (? . 0) q star)) q (27705 . 9)) ((c def c (c (? . 0) q step-count?)) q (39748 . 3)) ((c def c (c (? . 0) q triangle/ass)) q (21576 . 21)) ((c def c (c (? . 7) q dir-files)) c (? . 10)) ((c form c (c (? . 4) q on-release)) q (43391 . 4)) ((c def c (c (? . 11) q draw-solid-disk)) q (7527 . 5)) ((c def c (c (? . 3) q alpha-color)) c (? . 16)) ((c def c (c (? . 3) q triangle)) q (912 . 5)) ((c def c (c (? . 0) q struct:pulled-point)) c (? . 2)) ((c form c (c (? . 1) q for*/list)) q (48045 . 2)) ((c def c (c (? . 1) q in-range)) q (48933 . 7)) ((c def c (c (? . 4) q animate)) q (41451 . 3)) ((c form c (c (? . 1) q for/and)) q (48283 . 2)) ((c def c (c (? . 6) q gem-orange)) q (50367 . 2)) ((c def c (c (? . 3) q text)) q (1449 . 5)) ((c form c (c (? . 4) q register)) q (45412 . 4)) ((c def c (c (? . 7) q make-file)) c (? . 12)) ((c def c (c (? . 8) q matrix-set)) q (13335 . 6)) ((c def c (c (? . 6) q rock)) q (50439 . 2)) ((c def c (c (? . 0) q square)) q (26298 . 9)) ((c def c (c (? . 6) q water-block)) q (50172 . 2)) ((c def c (c (? . 3) q empty-scene)) q (3309 . 4)) ((c def c (c (? . 6) q wall-block-tall)) q (50111 . 2)) ((c form c (c (? . 4) q record?)) q (45061 . 4)) ((c def c (c (? . 0) q underlay/align)) q (33098 . 7)) ((c def c (c (? . 3) q circle)) q (607 . 5)) ((c def c (c (? . 6) q shadow-south)) q (51278 . 2)) ((c def c (c (? . 13) q key-event?)) q (5615 . 3)) ((c def c (c (? . 20) q control)) q (9845 . 7)) ((c def c (c (? . 0) q place-images/align)) q (35344 . 11)) ((c def c (c (? . 13) q big-bang)) q (5187 . 12)) ((c def c (c (? . 8) q matrix-minor)) q (13712 . 5)) ((c def c (c (? . 6) q character-boy)) q (49693 . 2)) ((c def c (c (? . 4) q make-bundle)) q (45962 . 5)) ((c def c (c (? . 0) q pen-color)) c (? . 14)) ((c def c (c (? . 0) q above)) q (34142 . 5)) ((c def c (c (? . 0) q pen?)) c (? . 14)) ((c def c (c (? . 18) q view)) q (11696 . 3)) ((c def c (c (? . 3) q add-line)) q (2008 . 8)) ((c form c (c (? . 4) q check-with)) q (44985 . 4)) ((c def c (c (? . 6) q shadow-north-west)) q (51109 . 2)) ((c form c (c (? . 4) q space)) q (44245 . 4)) ((c def c (c (? . 6) q roof-south-east)) q (50895 . 2)) ((c def c (c (? . 15) q convert-file)) q (6574 . 5)) ((c def c (c (? . 22) q struct:stop-with)) c (? . 23)) ((c def c (c (? . 0) q angle?)) q (39639 . 3)) ((c def c (c (? . 0) q place-image)) q (34708 . 6)) ((c def c (c (? . 4) q iworld1)) q (45831 . 2)) ((c def c (c (? . 8) q matrix-render)) q (13650 . 3)) ((c form c (c (? . 1) q for/product)) q (48601 . 2)) ((c form c (c (? . 1) q match)) q (49214 . 8)) ((c def c (c (? . 0) q isosceles-triangle)) q (20026 . 17)) ((c def c (c (? . 11) q clear-solid-line)) q (8363 . 5)) ((c def c (c (? . 13) q on-key-event)) q (5749 . 3)) ((c def c (c (? . 11) q draw-solid-string)) q (7879 . 4)) ((c def c (c (? . 4) q run-simulation)) q (41559 . 3)) ((c def c (c (? . 0) q empty-scene)) q (34384 . 8)) ((c def c (c (? . 4) q launch-many-worlds/proc)) q (47739 . 4)) ((c def c (c (? . 6) q shadow-south-west)) q (51243 . 2)) ((c def c (c (? . 4) q iworld3)) q (45883 . 2)) ((c def c (c (? . 3) q image-height)) q (1616 . 3)) ((c def c (c (? . 4) q sexp?)) q (45202 . 3)) ((c def c (c (? . 0) q triangle/ssa)) q (23218 . 21)) ((c def c (c (? . 6) q character-pink-girl)) q (49797 . 2)) ((c form c (c (? . 1) q for*/string)) q (48850 . 2)) ((c def c (c (? . 27) q connect)) q (12076 . 3)) ((c def c (c (? . 3) q alpha-color-green)) c (? . 16)) ((c def c (c (? . 0) q scene+line)) q (35684 . 8)) ((c def c (c (? . 8) q make-matrix)) q (12807 . 5)) ((c def c (c (? . 3) q make-color)) c (? . 17)) ((c def c (c (? . 9) q read-xexpr)) q (15007 . 3)) ((c def c (c (? . 6) q window-tall)) q (51016 . 2)) ((c def c (c (? . 6) q chest-lid)) q (50259 . 2)) ((c def c (c (? . 6) q ramp-west)) q (50681 . 2)) ((c def c (c (? . 6) q shadow-side-west)) q (51174 . 2)) ((c def c (c (? . 8) q matrix-rows)) q (12541 . 3)) ((c form c (c (? . 4) q up)) q (43935 . 4)) ((c def c (c (? . 18) q control)) q (11663 . 2)) ((c def c (c (? . 4) q make-package)) q (45307 . 4)) ((c def c (c (? . 3) q color-red)) c (? . 17)) ((c def c (c (? . 3) q color)) c (? . 17)) ((c def c (c (? . 0) q add-polygon)) q (31778 . 6)) ((q def ((lib "htdp/master.rkt") master)) q (7043 . 3)) ((c def c (c (? . 11) q draw-solid-line)) q (7770 . 5)) ((c def c (c (? . 0) q color-list->bitmap)) q (37923 . 5)) ((c def c (c (? . 3) q alpha-color-red)) c (? . 16)) ((c def c (c (? . 0) q pen-width)) c (? . 14)) ((c def c (c (? . 0) q scene+curve)) q (35893 . 21)) ((c def c (c (? . 6) q yellow-star)) q (50569 . 2)) ((c form c (c (? . 4) q launch-many-worlds)) q (47694 . 2)) ((c def c (c (? . 0) q side-count?)) q (39691 . 3)) ((c def c (c (? . 7) q file-content)) c (? . 12)) ((c def c (c (? . 9) q read-plain-xexpr/web)) q (15409 . 3)) ((c def c (c (? . 9) q read-lines)) q (14187 . 3)) ((c def c (c (? . 0) q beside/align)) q (34000 . 6)) ((c def c (c (? . 7) q file-name)) c (? . 12)) ((c def c (c (? . 6) q chest-closed)) q (50229 . 2)) ((c form c (c (? . 0) q bitmap)) q (37640 . 5)) ((c def c (c (? . 13) q run-movie)) q (4903 . 4)) ((c def c (c (? . 6) q door-tall-closed)) q (50708 . 2)) ((c def c (c (? . 7) q create-dir)) q (10627 . 3)) ((c def c (c (? . 7) q make-dir)) c (? . 10)) ((c def c (c (? . 3) q put-pinhole)) q (1787 . 5)) ((c def c (c (? . 8) q snip-class)) q (13899 . 2)) ((c def c (c (? . 19) q make-choice)) q (11513 . 3)) ((c def c (c (? . 11) q end-of-time)) q (8945 . 2)) ((c form c (c (? . 1) q define-type)) q (49412 . 10)) ((c def c (c (? . 20) q control-up-down)) q (9675 . 6)) ((c def c (c (? . 0) q right-triangle)) q (19321 . 17)) ((c def c (c (? . 0) q center-pinhole)) q (40268 . 3)) ((c def c (c (? . 1) q in-naturals)) q (49137 . 3)) ((c def c (c (? . 8) q matrix-ref)) q (13152 . 5)) ((c def c (c (? . 9) q read-words/line)) q (14427 . 3)) ((c def c (c (? . 15) q convert-repl)) q (6491 . 3)) ((c def c (c (? . 3) q color-green)) c (? . 17)) ((c form c (c (? . 4) q on-mouse)) q (44547 . 6)) ((c def c (c (? . 6) q ramp-south)) q (50653 . 2)) ((c def c (c (? . 6) q chest-open)) q (50286 . 2)) ((c def c (c (? . 6) q selector)) q (50461 . 2)) ((c def c (c (? . 19) q window?)) q (10970 . 3)) ((c def c (c (? . 0) q triangle/aas)) q (24039 . 21)) ((c def c (c (? . 0) q pen-join?)) q (40213 . 3)) ((c def c (c (? . 0) q underlay/xy)) q (33780 . 6)) ((c def c (c (? . 6) q grass-block)) q (49990 . 2)) ((c def c (c (? . 3) q pinhole-y)) q (1731 . 3)) ((c def c (c (? . 6) q shadow-north-east)) q (51074 . 2)) ((c def c (c (? . 0) q add-solid-curve)) q (17498 . 21)) ((c def c (c (? . 6) q tree-short)) q (50487 . 2)) ((c def c (c (? . 3) q color-blue)) c (? . 17)) ((c form c (c (? . 9) q simulate-file)) q (15721 . 2)) ((c def c (c (? . 0) q struct:pen)) c (? . 14)) ((c def c (c (? . 6) q stone-block)) q (50082 . 2)) ((c def c (c (? . 6) q tree-ugly)) q (50542 . 2)) ((c def c (c (? . 6) q speech-bubble)) q (49902 . 2)) ((c def c (c (? . 24) q connect)) q (12316 . 3)) ((c def c (c (? . 3) q shrink-br)) q (2970 . 5)) ((c def c (c (? . 3) q struct:color)) c (? . 17)) ((c def c (c (? . 3) q place-image)) q (3423 . 6)) ((c form c (c (? . 4) q on-disconnect)) q (47330 . 4)) ((c def c (c (? . 0) q save-image)) q (40884 . 7)) ((c def c (c (? . 3) q line)) q (1359 . 5)) ((c form c (c (? . 4) q on-new)) q (46648 . 4)) ((c def c (c (? . 18) q connect)) q (11761 . 6)) ((c def c (c (? . 3) q List-of-color)) q (4000 . 2)) ((c def c (c (? . 11) q start/cartesian-plane)) q (7299 . 4)) ((c def c (c (? . 7) q dir-dirs)) c (? . 10)) ((c def c (c (? . 7) q file)) c (? . 12)) ((c def c (c (? . 11) q big-bang)) q (8689 . 4)) ((c def c (c (? . 6) q ramp-north)) q (50625 . 2)) ((c def c (c (? . 0) q frame)) q (37470 . 3)) ((c def c (c (? . 0) q triangle/sas)) q (22397 . 21)) ((c def c (c (? . 11) q start)) q (7211 . 4)) ((c def c (c (? . 11) q wait-for-mouse-click)) q (8586 . 2)) ((c def c (c (? . 0) q scale)) q (36516 . 4)) ((c def c (c (? . 6) q shadow-north)) q (51144 . 2)) ((c def c (c (? . 0) q empty-image)) q (18873 . 2)) ((c def c (c (? . 6) q gem-green)) q (50340 . 2)) ((c def c (c (? . 0) q star-polygon)) q (28059 . 21)) ((c def c (c (? . 3) q shrink-tl)) q (2616 . 5)) ((c def c (c (? . 9) q read-csv-file)) q (14714 . 3)) ((c def c (c (? . 6) q shadow-south-east)) q (51208 . 2)) ((c def c (c (? . 0) q ellipse)) q (16115 . 11)) ((c def c (c (? . 6) q brown-block)) q (49933 . 2)) ((c def c (c (? . 0) q line)) q (16565 . 5)) ((c def c (c (? . 0) q underlay/align/offset)) q (33398 . 13)) ((c def c (c (? . 0) q color?)) c (? . 21)) ((c def c (c (? . 0) q pulled-point?)) c (? . 2)) ((c def c (c (? . 0) q image?)) q (38838 . 3)) ((c def c (c (? . 0) q make-pulled-point)) c (? . 2)) ((c def c (c (? . 3) q pinhole-x)) q (1675 . 3)) ((c def c (c (? . 4) q package?)) q (45253 . 3)) ((c def c (c (? . 6) q roof-north-east)) q (50801 . 2)) ((c def c (c (? . 6) q character-cat-girl)) q (49724 . 2)) ((c form c (c (? . 4) q on-tick)) q (42754 . 4)) ((c def c (c (? . 11) q clear-all)) q (8554 . 2)) ((c def c (c (? . 0) q pinhole-x)) q (40443 . 3)) ((c def c (c (? . 0) q image-width)) q (38549 . 3)) ((c def c (c (? . 9) q read-plain-xexpr)) q (15116 . 3)) ((c def c (c (? . 8) q matrix-cols)) q (12608 . 3)) ((c form c (c (? . 4) q on-pad)) q (43627 . 4)) ((c def c (c (? . 22) q stop-with-w)) c (? . 23)) ((c def c (c (? . 24) q view)) q (12245 . 3)) ((c def c (c (? . 9) q read-1strings)) q (14063 . 3)) ((c def c (c (? . 3) q shrink-bl)) q (2852 . 5)) ((c form c (c (? . 4) q on-key)) q (43301 . 4)) ((c def c (c (? . 6) q gem-blue)) q (50314 . 2)) ((c def c (c (? . 0) q pen-style)) c (? . 14)) ((c def c (c (? . 0) q underlay/offset)) q (33276 . 6)) ((c def c (c (? . 3) q overlay/xy)) q (2285 . 6)) ((c def c (c (? . 11) q on-tick-event)) q (8863 . 3)) ((c def c (c (? . 0) q circle)) q (15763 . 9)) ((c def c (c (? . 5) q atom?)) q (10066 . 3)) ((c def c (c (? . 26) q graph-fun)) q (10687 . 4)) ((c def c (c (? . 0) q rectangle)) q (26658 . 14)) ((c def c (c (? . 0) q pen-style?)) q (40103 . 3)) ((c def c (c (? . 4) q LOCALHOST)) q (45384 . 2)) ((c def c (c (? . 4) q stop-with)) c (? . 23)) ((c def c (c (? . 0) q pulled-point-rangle)) c (? . 2)) ((c def c (c (? . 0) q pen-cap)) c (? . 14)) ((c def c (c (? . 3) q shrink-tr)) q (2734 . 5)) ((c def c (c (? . 6) q ramp-east)) q (50598 . 2)) ((c def c (c (? . 6) q heart)) q (50395 . 2)) ((c def c (c (? . 11) q clear-solid-string)) q (8473 . 4)) ((c def c (c (? . 0) q image->color-list)) q (37843 . 3)) ((c def c (c (? . 0) q bitmap/file)) q (37779 . 3)) ((c def c (c (? . 4) q mouse=?)) q (44461 . 4)) ((c form c (c (? . 4) q to-draw)) q (42500 . 4)) ((c form c (c (? . 4) q name)) q (45131 . 4)) ((c form c (c (? . 4) q stop-when)) q (44707 . 4)) ((c def c (c (? . 3) q image=?)) q (52 . 4)) ((c def c (c (? . 4) q bundle?)) q (45909 . 3)) ((c form c (c (? . 1) q for*/or)) q (48204 . 2)) ((c def c (c (? . 3) q nw:rectangle)) q (3545 . 9)) ((c def c (c (? . 0) q above/align)) q (34243 . 6)) ((c def c (c (? . 0) q triangle/saa)) q (25545 . 21)) ((c def c (c (? . 3) q alpha-color?)) c (? . 16)) ((c def c (c (? . 9) q read-words-and-numbers/line)) q (14562 . 3)) ((c def c (c (? . 0) q underlay/pinhole)) q (40772 . 5)) ((c def c (c (? . 0) q add-curve)) q (16905 . 21)) ((c def c (c (? . 3) q alpha-color-blue)) c (? . 16)) ((c def c (c (? . 0) q image-color?)) q (38941 . 3)) ((c def c (c (? . 4) q iworld2)) q (45857 . 2)) ((c def c (c (? . 0) q pen-join)) c (? . 14)) ((c def c (c (? . 9) q xexpr?)) q (15534 . 3)) ((c def c (c (? . 25) q hangman)) q (8984 . 5)) ((c def c (c (? . 9) q xexpr-as-string)) q (15585 . 3)) ((c form c (c (? . 4) q big-bang)) q (41787 . 21)) ((c def c (c (? . 0) q regular-polygon)) q (29684 . 17)) ((c def c (c (? . 3) q move-pinhole)) q (1885 . 5)) ((c def c (c (? . 6) q key)) q (50418 . 2)) ((c def c (c (? . 0) q color-red)) c (? . 21)) ((c def c (c (? . 3) q struct:alpha-color)) c (? . 16)) ((c def c (c (? . 0) q crop/align)) q (37133 . 11)) ((c def c (c (? . 0) q pinhole-y)) q (40519 . 3)) ((c def c (c (? . 0) q rhombus)) q (27207 . 14)) ((c form c (c (? . 4) q port)) q (45466 . 4)) ((c def c (c (? . 19) q make-text)) q (11391 . 3)) ((c def c (c (? . 0) q image-baseline)) q (38740 . 3)) ((c def c (c (? . 11) q clear-solid-disk)) q (8118 . 5)) ((c def c (c (? . 11) q clear-circle)) q (8020 . 5)) ((c def c (c (? . 0) q underlay)) q (32994 . 5)) ((c def c (c (? . 11) q clear-solid-rect)) q (8220 . 6)) ((c def c (c (? . 0) q color-frame)) q (37528 . 4)) ((c form c (c (? . 4) q universe)) q (46236 . 13)) ((c def c (c (? . 6) q tree-tall)) q (50515 . 2)) ((c def c (c (? . 20) q control-left-right)) q (9502 . 6)) ((c def c (c (? . 0) q image-height)) q (38644 . 3)) ((c def c (c (? . 0) q triangle/sss)) q (20687 . 21)) ((c def c (c (? . 6) q roof-north-west)) q (50834 . 2)) ((c def c (c (? . 4) q iworld?)) q (45626 . 3)) ((c def c (c (? . 6) q enemy-bug)) q (49875 . 2)) ((c def c (c (? . 3) q regular-polygon)) q (1208 . 7)) ((c def c (c (? . 26) q graph-line)) q (10786 . 4)) ((c def c (c (? . 6) q stone-block-tall)) q (50048 . 2)) ((c def c (c (? . 0) q pen-cap?)) q (40159 . 3)) ((c def c (c (? . 6) q dirt-block)) q (49962 . 2)) ((c def c (c (? . 19) q hide-window)) q (11077 . 3)) ((c def c (c (? . 0) q save-svg-image)) q (41167 . 7)) ((c def c (c (? . 19) q make-message)) q (11249 . 3)) ((c def c (c (? . 13) q on-redraw)) q (5963 . 3)) ((c def c (c (? . 6) q character-princess-girl)) q (49834 . 2)) ((c def c (c (? . 0) q rotate)) q (36429 . 4)) ((q def ((lib "htdp/master-play.rkt") go)) q (7159 . 3)) ((c def c (c (? . 3) q make-alpha-color)) c (? . 16)) ((c def c (c (? . 11) q get-key-event)) q (8630 . 2)) ((c def c (c (? . 0) q color-green)) c (? . 21)) ((c def c (c (? . 0) q pulled-point-x)) c (? . 2)) ((c def c (c (? . 28) q guess-with-gui)) q (6705 . 3)) ((c def c (c (? . 0) q pen)) c (? . 14)) ((c def c (c (? . 6) q roof-south-west)) q (50928 . 2)) ((c def c (c (? . 7) q file?)) c (? . 12)) ((c def c (c (? . 8) q matrix->rectangle)) q (12741 . 3)) ((c def c (c (? . 13) q key=?)) q (5669 . 4)) ((c def c (c (? . 8) q matrix?)) q (12488 . 3)) ((c def c (c (? . 11) q draw-solid-rect)) q (7628 . 6)) ((c def c (c (? . 9) q write-file)) q (15231 . 4)) ((c def c (c (? . 0) q overlay/xy)) q (32877 . 6)) ((c def c (c (? . 19) q make-button)) q (11131 . 4)) ((c def c (c (? . 0) q place-image/align)) q (34838 . 13)) ((c form c (c (? . 4) q down)) q (44009 . 4)) ((c def c (c (? . 0) q polygon)) q (31384 . 9)) ((c def c (c (? . 6) q roof-east)) q (50774 . 2)) ((c def c (c (? . 0) q pulled-point)) c (? . 2)) ((c def c (c (? . 13) q stop-when)) q (6041 . 3)) ((c def c (c (? . 4) q make-mail)) q (46149 . 4)) ((c def c (c (? . 4) q key=?)) q (43221 . 4)) ((c def c (c (? . 0) q pulled-point-rpull)) c (? . 2)) ((c def c (c (? . 6) q door-tall-open)) q (50742 . 2)) ((c def c (c (? . 0) q add-line)) q (16698 . 8)) ((c def c (c (? . 4) q mouse-event?)) q (44405 . 3)) ((c def c (c (? . 0) q color-alpha)) c (? . 21)) ((c def c (c (? . 0) q triangle/asa)) q (24792 . 21)) ((c def c (c (? . 6) q roof-west)) q (50989 . 2)) ((c def c (c (? . 0) q y-place?)) q (39531 . 3)) ((c def c (c (? . 19) q draw-message)) q (11313 . 4)) ((c def c (c (? . 13) q run-simulation)) q (5004 . 6)) ((c def c (c (? . 0) q clear-pinhole)) q (40595 . 3)) ((c form c (c (? . 1) q for*/product)) q (48684 . 2)) ((c def c (c (? . 0) q color-blue)) c (? . 21)) ((c form c (c (? . 4) q state)) q (45110 . 2)) ((c def c (c (? . 19) q show-window)) q (11023 . 3)) ((c def c (c (? . 0) q pulled-point-y)) c (? . 2)) ((c def c (c (? . 6) q shadow-east)) q (51045 . 2)) ((c def c (c (? . 3) q image-inside?)) q (2438 . 4)) ((c def c (c (? . 11) q on-key-event)) q (8764 . 3)) ((c def c (c (? . 0) q pulled-regular-polygon)) q (30341 . 25)) ((c def c (c (? . 0) q struct:color)) c (? . 21)) ((c def c (c (? . 27) q view)) q (12005 . 3)) ((c def c (c (? . 27) q control)) q (11935 . 3)) ((c def c (c (? . 7) q file-size)) c (? . 12)) ((c def c (c (? . 6) q wood-block)) q (50201 . 2)) ((c def c (c (? . 0) q scale/xy)) q (36623 . 5)) ((c def c (c (? . 0) q freeze)) q (38126 . 13)) ((c def c (c (? . 3) q star)) q (1003 . 7)) ((c def c (c (? . 0) q make-color)) c (? . 21)) ((c def c (c (? . 3) q alpha-color-alpha)) c (? . 16)) ((c def c (c (? . 13) q on-mouse-event)) q (5838 . 3)) ((c def c (c (? . 6) q wall-block)) q (50144 . 2)) ((c form c (c (? . 4) q on-msg)) q (46755 . 4)) ((c def c (c (? . 5) q write-file)) q (10241 . 3)) ((c def c (c (? . 4) q pad=?)) q (43547 . 4)) ((c def c (c (? . 3) q image?)) q (0 . 3)) ((c def c (c (? . 9) q read-file)) q (13954 . 3)) ((c def c (c (? . 0) q crop)) q (36924 . 7)) ((c def c (c (? . 0) q text/font)) q (18217 . 18)) ((c def c (c (? . 4) q mail?)) q (46098 . 3)) ((c def c (c (? . 6) q shadow-west)) q (51308 . 2)) ((c def c (c (? . 8) q matrix-where?)) q (13539 . 4)) ((c def c (c (? . 7) q dir?)) c (? . 10)) ((c def c (c (? . 28) q guess-with-gui-3)) q (6807 . 3)) ((c def c (c (? . 28) q guess-with-gui-list)) q (6926 . 3)) ((c def c (c (? . 19) q text-contents)) q (11452 . 3)) ((c form c (c (? . 1) q for/sum)) q (48442 . 2)) ((c def c (c (? . 6) q roof-south)) q (50961 . 2)) ((c def c (c (? . 4) q pad-event?)) q (43493 . 3)) ((c def c (c (? . 3) q ellipse)) q (731 . 6)) ((c def c (c (? . 0) q overlay/align/offset)) q (32501 . 13)) ((c def c (c (? . 24) q control)) q (12175 . 3)) ((c def c (c (? . 0) q triangle)) q (18902 . 11)) ((c def c (c (? . 22) q stop-with?)) c (? . 23)) ((c form c (c (? . 1) q for/list)) q (47917 . 4)) ((c form c (c (? . 1) q for*/and)) q (48362 . 2)) ((c form c (c (? . 1) q type-case)) q (49616 . 2)) ((c def c (c (? . 3) q color-list->image)) q (4103 . 7)) ((c def c (c (? . 19) q create-window)) q (10890 . 3)) ((c def c (c (? . 7) q dir)) c (? . 10)) ((c def c (c (? . 6) q plain-block)) q (50019 . 2)) ((c def c (c (? . 9) q url-exists?)) q (15475 . 3)) ((c def c (c (? . 4) q iworld=?)) q (45679 . 4)) ((c def c (c (? . 3) q scene+line)) q (3834 . 8)) ((c def c (c (? . 13) q on-tick-event)) q (5541 . 3)) ((c def c (c (? . 0) q put-pinhole)) q (40335 . 5)) ((c def c (c (? . 0) q overlay)) q (32100 . 5)) ((c def c (c (? . 3) q image->alpha-color-list)) q (4623 . 3))))
procedure
(image? x) -> boolean?
  x : any/c
procedure
(image=? x y) -> boolean?
  x : image?
  y : image?
struct
(struct color (red green blue)
    #:extra-constructor-name make-color)
  red : (and/c natural-number/c (<=/c 255))
  green : (and/c natural-number/c (<=/c 255))
  blue : (and/c natural-number/c (<=/c 255))
procedure
(image-color? x) -> boolean?
  x : any
procedure
(rectangle w h m c) -> image?
  w : (and/c number? (or/c zero? positive?))
  h : (and/c number? (or/c zero? positive?))
  m : Mode
  c : Color
procedure
(circle r m c) -> image?
  r : (and/c number? (or/c zero? positive?))
  m : Mode
  c : Color
procedure
(ellipse w h m c) -> image?
  w : (and/c number? (or/c zero? positive?))
  h : (and/c number? (or/c zero? positive?))
  m : Mode
  c : Color
procedure
(triangle s m c) -> image?
  s : number?
  m : Mode
  c : Color
procedure
(star n outer inner m c) -> image?
  n : (and/c number? (>=/c 2))
  outer : (and/c number? (>=/c 1))
  inner : (and/c number? (>=/c 1))
  m : Mode
  c : Color
procedure
(regular-polygon s r m c [angle]) -> image?
  s : side
  r : number?
  m : Mode
  c : Color
  angle : real? = 0
procedure
(line x y c) -> image?
  x : number?
  y : number?
  c : Color
procedure
(text s f c) -> Image
  s : string?
  f : (and/c number? positive?)
  c : Color
procedure
(image-width i) -> integer?
  i : image?
procedure
(image-height i) -> integer?
  i : image?
procedure
(pinhole-x i) -> integer?
  i : image?
procedure
(pinhole-y i) -> integer?
  i : image?
procedure
(put-pinhole i x y) -> image?
  i : image?
  x : number?
  y : number?
procedure
(move-pinhole i delta-x delta-y) -> image?
  i : image?
  delta-x : number?
  delta-y : number?
procedure
(add-line i x1 y1 x2 y2 c) -> image?
  i : image?
  x1 : number?
  y1 : number?
  x2 : number?
  y2 : number?
  c : Color
procedure
(overlay img img2 img* ...) -> image?
  img : image?
  img2 : image?
  img* : image?
procedure
(overlay/xy img delta-x delta-y other) -> image?
  img : image?
  delta-x : number?
  delta-y : number?
  other : image?
procedure
(image-inside? img other) -> boolean?
  img : image?
  other : image?
procedure
(find-image img other) -> posn?
  img : image?
  other : image?
procedure
(shrink-tl img width height) -> image?
  img : image?
  width : number?
  height : number?
procedure
(shrink-tr img width height) -> image?
  img : image?
  width : number?
  height : number?
procedure
(shrink-bl img width height) -> image?
  img : image?
  width : number?
  height : number?
procedure
(shrink-br img width height) -> image?
  img : image?
  width : number?
  height : number?
procedure
(shrink img left above right below) -> image?
  img : image?
  left : number?
  above : number?
  right : number?
  below : number?
procedure
(scene? x) -> boolean?
  x : any/c
procedure
(empty-scene width height) -> scene?
  width : natural-number/c
  height : natural-number/c
procedure
(place-image img x y s) -> scene?
  img : image?
  x : number?
  y : number?
  s : scene?
procedure
(nw:rectangle width                
              height               
              solid-or-outline     
              c)               -> image?
  width : natural-number/c
  height : natural-number/c
  solid-or-outline : Mode
  c : Color
procedure
(scene+line s x0 y0 x1 y1 c) -> scene?
  s : scene?
  x0 : number?
  y0 : number?
  x1 : number?
  y1 : number?
  c : Color
value
List-of-color : list?
procedure
(image->color-list img) -> List-of-color
  img : image?
procedure
(color-list->image l width height x y) -> image?
  l : List-of-color
  width : natural-number/c
  height : natural-number/c
  x : natural-number/c
  y : natural-number/c
struct
(struct alpha-color (alpha red green blue)
    #:extra-constructor-name make-alpha-color)
  alpha : (and/c natural-number/c (<=/c 255))
  red : (and/c natural-number/c (<=/c 255))
  green : (and/c natural-number/c (<=/c 255))
  blue : (and/c natural-number/c (<=/c 255))
procedure
(image->alpha-color-list img) -> (list-of alpha-color?)
  img : image?
procedure
(alpha-color-list->image l width height x y) -> image?
  l : (list-of alpha-color?)
  width : integer?
  height : integer?
  x : integer?
  y : integer?
procedure
(run-movie r m) -> true
  r : (and/c real? positive?)
  m : [Listof image?]
procedure
(run-simulation w h r create-image) -> true
  w : natural-number/c
  h : natural-number/c
  r : number?
  create-image : (-> natural-number/c scene)
procedure
(big-bang width height r world0) -> true
  width : natural-number/c
  height : natural-number/c
  r : number?
  world0 : World
(big-bang width height r world0 animated-gif?) -> true
  width : natural-number/c
  height : natural-number/c
  r : number?
  world0 : World
  animated-gif? : boolean?
procedure
(on-tick-event tock) -> true
  tock : (-> World World)
procedure
(key-event? x) -> boolean?
  x : any
procedure
(key=? x y) -> boolean?
  x : key-event?
  y : key-event?
procedure
(on-key-event change) -> true
  change : (-> World key-event? World)
procedure
(on-mouse-event clack) -> true
  clack : (-> World natural-number/c natural-number/c MouseEvent World)
procedure
(on-redraw to-scene) -> true
  to-scene : (-> World Scene)
procedure
(stop-when last-world?) -> true
  last-world? : (-> World boolean?)

given statedesired state
’locked    ’locked
’closed    ’closed
’open      ’closed

given stategiven keyeventdesired state
’locked    #\u           ’closed
’closed    #\l           ’locked
’closed    #\space       ’open
’open      —             ’open
procedure
(convert-gui convert) -> true
  convert : (-> number? number?)
procedure
(convert-repl convert) -> true
  convert : (-> number? number?)
procedure
(convert-file in convert out) -> true
  in : string?
  convert : (-> number? number?)
  out : string?
procedure
(guess-with-gui check-guess) -> true
  check-guess : (-> number? number? symbol?)
procedure
(guess-with-gui-3 check-guess) -> true
  check-guess : (-> digit? digit? digit? number? symbol?)
procedure
(guess-with-gui-list check-guess) -> true
  check-guess : (-> (list-of digit?) number? symbol?)
procedure
(master check-guess) -> symbol?
  check-guess : (-> symbol? symbol? symbol? symbol? boolean?)
procedure
(go name) -> true
  name : symbol?
procedure
(start width height) -> true
  width : number?
  height : number?
procedure
(start/cartesian-plane width height) -> true
  width : number?
  height : number?
procedure
(stop) -> true
procedure
(draw-circle p r c) -> true
  p : posn?
  r : number?
  c : DrawColor
procedure
(draw-solid-disk p r c) -> true
  p : posn?
  r : number?
  c : DrawColor
procedure
(draw-solid-rect ul width height c) -> true
  ul : posn?
  width : number?
  height : number?
  c : DrawColor
procedure
(draw-solid-line strt end c) -> true
  strt : posn?
  end : posn?
  c : DrawColor
procedure
(draw-solid-string p s) -> true
  p : posn?
  s : string?
procedure
(sleep-for-a-while s) -> true
  s : number?
procedure
(clear-circle p r c) -> true
  p : posn?
  r : number?
  c : DrawColor
procedure
(clear-solid-disk p r c) -> true
  p : posn?
  r : number?
  c : DrawColor
procedure
(clear-solid-rect ul width height c) -> true
  ul : posn?
  width : number?
  height : number?
  c : DrawColor
procedure
(clear-solid-line strt end c) -> true
  strt : posn?
  end : posn?
  c : DrawColor
procedure
(clear-solid-string p s) -> true
  p : posn?
  s : string?
procedure
(clear-all) -> true
procedure
(wait-for-mouse-click) -> posn?
procedure
(get-key-event) -> (or/c false DrawKeyEvent)
procedure
(big-bang n w) -> true
  n : number?
  w : DrawWorld
procedure
(on-key-event change) -> true
  change : (-> DrawKeyEvent DrawWorld DrawWorld)
procedure
(on-tick-event tock) -> true
  tock : (-> DrawWorld DrawWorld)
procedure
(end-of-time) -> DrawWorld
procedure
(hangman make-word reveal draw-next-part) -> true
  make-word : (-> symbol? symbol? symbol? word?)
  reveal : (-> word? word? word?)
  draw-next-part : (-> symbol? true)
procedure
(hangman-list reveal-for-list     
              draw-next-part) -> true
  reveal-for-list : (-> symbol? (list-of symbol?) (list-of symbol?)
                        (list-of symbol?))
  draw-next-part : (-> symbol? true)
procedure
(go name) -> true
  name : symbol?
procedure
(control-left-right shape n move draw) -> true
  shape : Shape
  n : number?
  move : (-> number? Shape Shape)
  draw : (-> Shape true)
procedure
(control-up-down shape n move draw) -> true
  shape : Shape
  n : number?
  move : (-> number? Shape Shape)
  draw : (-> Shape true)
procedure
(control shape n move-lr move-ud draw) -> true
  shape : Shape
  n : number?
  move-lr : (-> number? Shape Shape)
  move-ud : (-> number? Shape Shape)
  draw : (-> Shape true)
procedure
(atom? x) -> boolean?
  x : any/c
procedure
(annotation? x) -> boolean?
  x : any/c
procedure
(end-annotation x) -> Annotation
  x : Annotation
procedure
(write-file l) -> true
  l : (list-of atom)
struct
(struct dir (name dirs files)
    #:extra-constructor-name make-dir)
  name : symbol?
  dirs : (listof dir?)
  files : (listof file?)
struct
(struct file (name size content)
    #:extra-constructor-name make-file)
  name : symbol?
  size : integer?
  content : (listof char?)
procedure
(create-dir path) -> dir?
  path : symbol?
procedure
(graph-fun f color) -> true
  f : (-> number?  number?)
  color : symbol?
procedure
(graph-line line color) -> true
  line : (-> number? number?)
  color : symbol?
procedure
(create-window g) -> Window
  g : (listof (listof GUI-ITEM))
procedure
(window? x) -> boolean?
  x : any/c
procedure
(show-window w) -> true
  w : Window
procedure
(hide-window w) -> true
  w : window
procedure
(make-button label callback) -> GUI-ITEM
  label : string>
  callback : (-> event%  boolean)
procedure
(make-message msg) -> GUI-ITEM
  msg : string?
procedure
(draw-message g m) -> true
  g : GUI-ITEM
  m : string?
procedure
(make-text txt) -> GUI-ITEM
  txt : string?
procedure
(text-contents g) -> string?
  g : GUI-ITEM
procedure
(make-choice choices) -> GUI-ITEM
  choices : (listof string?)
procedure
(choice-index g) -> natural-number/c
  g : GUI-ITEM
procedure
(control) -> symbol?
procedure
(view s) -> true
  s : (or/c string? symbol?)
procedure
(connect l r u d) -> true
  l : modelT
  r : modelT
  u : modelT
  d : modelT
procedure
(run NextFloor) -> any/c
  NextFloor : number?
procedure
(control index) -> symbol?
  index : natural-number?
procedure
(view msg) -> true/c
  msg : (or/c string? symbol?)
procedure
(connect event-handler) -> true/c
  event-handler : (-> button% event% true/c)
procedure
(control index) -> symbol?
  index : natural-number?
procedure
(view msg) -> true/c
  msg : (or/c string? symbol?)
procedure
(connect handler) -> true/c
  handler : (-> button% event% true/c)
procedure
(show-queen board) -> true
  board : (list-of (list-of boolean?))
procedure
(matrix? o) -> boolean?
  o : any/c
procedure
(matrix-rows m) -> natural-number/c
  m : matrix?
procedure
(matrix-cols m) -> natural-number/c
  m : matrix?
procedure
(rectangle->matrix r) -> matrix?
  r : Rectangle
procedure
(matrix->rectangle m) -> Rectangle
  m : matrix?
procedure
(make-matrix n m l) -> matrix?
  n : natural-number/c
  m : natural-number/c
  l : (Listof X)
procedure
(build-matrix n m f) -> matrix?
  n : natural-number/c
  m : natural-number/c
  f : (-> (and/c natural-number/c (</c m))
          (and/c natural-number/c (</c n))
          any/c)
procedure
(matrix-ref m i j) -> any/c
  m : matrix?
  i : (and/c natural-number/c (</c (matrix-rows m)))
  j : (and/c natural-number/c (</c (matrix-rows m)))
procedure
(matrix-set m i j x) -> matrix?
  m : matrix?
  i : (and/c natural-number/c (</c (matrix-rows m)))
  j : (and/c natural-number/c (</c (matrix-rows m)))
  x : any/c
procedure
(matrix-where? m pred?) -> (listof posn?)
  m : matrix?
  pred? : (-> any/c boolean?)
procedure
(matrix-render m) -> Rectangle
  m : matrix?
procedure
(matrix-minor m i j) -> matrix?
  m : matrix?
  i : (and/c natural-number/c (</c (matrix-rows m)))
  j : (and/c natural-number/c (</c (matrix-rows m)))
value
snip-class : (instance/of matrix-snip-class%)
procedure
(read-file f) -> string?
  f : (or/c 'standard-in 'stdin (and/c string? file-exists?))
procedure
(read-1strings f) -> (listof 1string?)
  f : (or/c 'standard-in 'stdin (and/c string? file-exists?))
procedure
(read-lines f) -> (listof string?)
  f : (or/c 'standard-in 'stdin (and/c string? file-exists?))
procedure
(read-words f) -> (listof string?)
  f : (or/c 'standard-in 'stdin (and/c string? file-exists?))
procedure
(read-words/line f) -> (listof (listof string?))
  f : (or/c 'standard-in 'stdin (and/c string? file-exists?))
procedure
(read-words-and-numbers/line f) -> (listof (or number? string?))
  f : (or/c 'standard-in 'stdin (and/c string? file-exists?))
procedure
(read-csv-file f) -> (listof (listof any/c))
  f : (or/c 'standard-in 'stdin (and/c string? file-exists?))
procedure
(read-csv-file/rows f s) -> (listof X?)
  f : (or/c 'standard-in 'stdin (and/c string? file-exists?))
  s : (-> (listof any/c) X?)
procedure
(read-xexpr f) -> xexpr?
  f : (or/c 'standard-in 'stdin (and/c string? file-exists?))
procedure
(read-plain-xexpr f) -> xexpr?
  f : (or/c 'standard-in 'stdin (and/c string? file-exists?))
procedure
(write-file f cntnt) -> string?
  f : (or/c 'standard-out 'stdout string?)
  cntnt : string?
procedure
(read-xexpr/web u) -> xexpr?
  u : string?
procedure
(read-plain-xexpr/web u) -> xexpr?
  u : string?
procedure
(url-exists? u) -> boolean?
  u : string?
procedure
(xexpr? u) -> boolean?
  u : any?
procedure
(xexpr-as-string x) -> string?
  x : xexpr?
procedure
(url-html-neighbors u) -> (listof string?)
  u : string?
syntax
(simulate-file process str ...)
procedure
(circle radius mode color) -> image?
  radius : (and/c real? (not/c negative?))
  mode : mode?
  color : image-color?
(circle radius outline-mode pen-or-color) -> image?
  radius : (and/c real? (not/c negative?))
  outline-mode : (or/c 'outline "outline")
  pen-or-color : (or/c pen? image-color?)
procedure
(ellipse width height mode color) -> image?
  width : (and/c real? (not/c negative?))
  height : (and/c real? (not/c negative?))
  mode : mode?
  color : image-color?
(ellipse width height mode pen-or-color) -> image?
  width : (and/c real? (not/c negative?))
  height : (and/c real? (not/c negative?))
  mode : (or/c 'outline "outline")
  pen-or-color : (or/c image-color? pen?)
procedure
(line x1 y1 pen-or-color) -> image?
  x1 : real?
  y1 : real?
  pen-or-color : (or/c pen? image-color?)
procedure
(add-line image x1 y1 x2 y2 pen-or-color) -> image?
  image : image?
  x1 : real?
  y1 : real?
  x2 : real?
  y2 : real?
  pen-or-color : (or/c pen? image-color?)
procedure
(add-curve image             
           x1                
           y1                
           angle1            
           pull1             
           x2                
           y2                
           angle2            
           pull2             
           pen-or-color) -> image?
  image : image?
  x1 : real?
  y1 : real?
  angle1 : angle?
  pull1 : real?
  x2 : real?
  y2 : real?
  angle2 : angle?
  pull2 : real?
  pen-or-color : (or/c pen? image-color?)
procedure
(add-solid-curve image      
                 x1         
                 y1         
                 angle1     
                 pull1      
                 x2         
                 y2         
                 angle2     
                 pull2      
                 color) -> image?
  image : image?
  x1 : real?
  y1 : real?
  angle1 : angle?
  pull1 : real?
  x2 : real?
  y2 : real?
  angle2 : angle?
  pull2 : real?
  color : image-color?
procedure
(text string font-size color) -> image?
  string : string?
  font-size : (and/c integer? (<=/c 1 255))
  color : image-color?
procedure
(text/font string          
           font-size       
           color           
           face            
           family          
           style           
           weight          
           underline?) -> image?
  string : string?
  font-size : (and/c integer? (<=/c 1 255))
  color : image-color?
  face : (or/c string? #f)
  family : (or/c 'default 'decorative 'roman 'script
                 'swiss 'modern 'symbol 'system)
  style : (or/c 'normal 'italic 'slant)
  weight : (or/c 'normal 'bold 'light)
  underline? : any/c
value
empty-image : image?
procedure
(triangle side-length mode color) -> image?
  side-length : (and/c real? (not/c negative?))
  mode : mode?
  color : image-color?
(triangle side-length       
          outline-mode      
          pen-or-color) -> image?
  side-length : (and/c real? (not/c negative?))
  outline-mode : (or/c 'outline "outline")
  pen-or-color : (or/c pen? image-color?)
procedure
(right-triangle side-length1     
                side-length2     
                mode             
                color)       -> image?
  side-length1 : (and/c real? (not/c negative?))
  side-length2 : (and/c real? (not/c negative?))
  mode : mode?
  color : image-color?
(right-triangle side-length1      
                side-length2      
                outline-mode      
                pen-or-color) -> image?
  side-length1 : (and/c real? (not/c negative?))
  side-length2 : (and/c real? (not/c negative?))
  outline-mode : (or/c 'outline "outline")
  pen-or-color : (or/c pen? image-color?)
procedure
(isosceles-triangle side-length     
                    angle           
                    mode            
                    color)      -> image?
  side-length : (and/c real? (not/c negative?))
  angle : angle?
  mode : mode?
  color : image-color?
(isosceles-triangle side-length       
                    angle             
                    outline-mode      
                    pen-or-color) -> image?
  side-length : (and/c real? (not/c negative?))
  angle : angle?
  outline-mode : (or/c 'outline "outline")
  pen-or-color : (or/c pen? image-color?)
procedure
(triangle/sss side-length-a     
              side-length-b     
              side-length-c     
              mode              
              color)        -> image?
  side-length-a : (and/c real? (not/c negative?))
  side-length-b : (and/c real? (not/c negative?))
  side-length-c : (and/c real? (not/c negative?))
  mode : mode?
  color : image-color?
(triangle/sss side-length-a     
              side-length-b     
              side-length-c     
              outline-mode      
              pen-or-color) -> image?
  side-length-a : (and/c real? (not/c negative?))
  side-length-b : (and/c real? (not/c negative?))
  side-length-c : (and/c real? (not/c negative?))
  outline-mode : (or/c 'outline "outline")
  pen-or-color : (or/c pen? image-color?)
procedure
(triangle/ass angle-a           
              side-length-b     
              side-length-c     
              mode              
              color)        -> image?
  angle-a : angle?
  side-length-b : (and/c real? (not/c negative?))
  side-length-c : (and/c real? (not/c negative?))
  mode : mode?
  color : image-color?
(triangle/ass angle-a           
              side-length-b     
              side-length-c     
              outline-mode      
              pen-or-color) -> image?
  angle-a : angle?
  side-length-b : (and/c real? (not/c negative?))
  side-length-c : (and/c real? (not/c negative?))
  outline-mode : (or/c 'outline "outline")
  pen-or-color : (or/c pen? image-color?)
procedure
(triangle/sas side-length-a     
              angle-b           
              side-length-c     
              mode              
              color)        -> image?
  side-length-a : (and/c real? (not/c negative?))
  angle-b : angle?
  side-length-c : (and/c real? (not/c negative?))
  mode : mode?
  color : image-color?
(triangle/sas side-length-a     
              angle-b           
              side-length-c     
              outline-mode      
              pen-or-color) -> image?
  side-length-a : (and/c real? (not/c negative?))
  angle-b : angle?
  side-length-c : (and/c real? (not/c negative?))
  outline-mode : (or/c 'outline "outline")
  pen-or-color : (or/c pen? image-color?)
procedure
(triangle/ssa side-length-a     
              side-length-b     
              angle-c           
              mode              
              color)        -> image?
  side-length-a : (and/c real? (not/c negative?))
  side-length-b : (and/c real? (not/c negative?))
  angle-c : angle?
  mode : mode?
  color : image-color?
(triangle/ssa side-length-a     
              side-length-b     
              angle-c           
              outline-mode      
              pen-or-color) -> image?
  side-length-a : (and/c real? (not/c negative?))
  side-length-b : (and/c real? (not/c negative?))
  angle-c : angle?
  outline-mode : (or/c 'outline "outline")
  pen-or-color : (or/c pen? image-color?)
procedure
(triangle/aas angle-a           
              angle-b           
              side-length-c     
              mode              
              color)        -> image?
  angle-a : angle?
  angle-b : angle?
  side-length-c : (and/c real? (not/c negative?))
  mode : mode?
  color : image-color?
(triangle/aas angle-a           
              angle-b           
              side-length-c     
              outline-mode      
              pen-or-color) -> image?
  angle-a : angle?
  angle-b : angle?
  side-length-c : (and/c real? (not/c negative?))
  outline-mode : (or/c 'outline "outline")
  pen-or-color : (or/c pen? image-color?)
procedure
(triangle/asa angle-a           
              side-length-b     
              angle-c           
              mode              
              color)        -> image?
  angle-a : angle?
  side-length-b : (and/c real? (not/c negative?))
  angle-c : angle?
  mode : mode?
  color : image-color?
(triangle/asa angle-a           
              side-length-b     
              angle-c           
              outline-mode      
              pen-or-color) -> image?
  angle-a : angle?
  side-length-b : (and/c real? (not/c negative?))
  angle-c : angle?
  outline-mode : (or/c 'outline "outline")
  pen-or-color : (or/c pen? image-color?)
procedure
(triangle/saa side-length-a     
              angle-b           
              angle-c           
              mode              
              color)        -> image?
  side-length-a : (and/c real? (not/c negative?))
  angle-b : angle?
  angle-c : angle?
  mode : mode?
  color : image-color?
(triangle/saa side-length-a     
              angle-b           
              angle-c           
              outline-mode      
              pen-or-color) -> image?
  side-length-a : (and/c real? (not/c negative?))
  angle-b : angle?
  angle-c : angle?
  outline-mode : (or/c 'outline "outline")
  pen-or-color : (or/c pen? image-color?)
procedure
(square side-len mode color) -> image?
  side-len : (and/c real? (not/c negative?))
  mode : mode?
  color : image-color?
(square side-len outline-mode pen-or-color) -> image?
  side-len : (and/c real? (not/c negative?))
  outline-mode : (or/c 'outline "outline")
  pen-or-color : (or/c pen? image-color?)
procedure
(rectangle width height mode color) -> image?
  width : (and/c real? (not/c negative?))
  height : (and/c real? (not/c negative?))
  mode : mode?
  color : image-color?
(rectangle width             
           height            
           outline-mode      
           pen-or-color) -> image?
  width : (and/c real? (not/c negative?))
  height : (and/c real? (not/c negative?))
  outline-mode : (or/c 'outline "outline")
  pen-or-color : (or/c pen? image-color?)
procedure
(rhombus side-length angle mode color) -> image?
  side-length : (and/c real? (not/c negative?))
  angle : angle?
  mode : mode?
  color : image-color?
(rhombus side-length       
         angle             
         outline-mode      
         pen-or-color) -> image?
  side-length : (and/c real? (not/c negative?))
  angle : angle?
  outline-mode : (or/c 'outline "outline")
  pen-or-color : (or/c pen? image-color?)
procedure
(star side-length mode color) -> image?
  side-length : (and/c real? (not/c negative?))
  mode : mode?
  color : image-color?
(star side-length outline-mode color) -> image?
  side-length : (and/c real? (not/c negative?))
  outline-mode : (or/c 'outline "outline")
  color : (or/c pen? image-color?)
procedure
(star-polygon side-length     
              side-count      
              step-count      
              mode            
              color)      -> image?
  side-length : (and/c real? (not/c negative?))
  side-count : side-count?
  step-count : step-count?
  mode : mode?
  color : image-color?
(star-polygon side-length       
              side-count        
              step-count        
              outline-mode      
              pen-or-color) -> image?
  side-length : (and/c real? (not/c negative?))
  side-count : side-count?
  step-count : step-count?
  outline-mode : (or/c 'outline "outline")
  pen-or-color : (or/c pen? image-color?)
procedure
(radial-star point-count      
             inner-radius     
             outer-radius     
             mode             
             color)       -> image?
  point-count : (and/c integer? (>=/c 2))
  inner-radius : (and/c real? (not/c negative?))
  outer-radius : (and/c real? (not/c negative?))
  mode : mode?
  color : image-color?
(radial-star point-count       
             inner-radius      
             outer-radius      
             outline-mode      
             pen-or-color) -> image?
  point-count : (and/c integer? (>=/c 2))
  inner-radius : (and/c real? (not/c negative?))
  outer-radius : (and/c real? (not/c negative?))
  outline-mode : (or/c 'outline "outline")
  pen-or-color : (or/c pen? image-color?)
procedure
(regular-polygon side-length     
                 side-count      
                 mode            
                 color)      -> image?
  side-length : (and/c real? (not/c negative?))
  side-count : side-count?
  mode : mode?
  color : image-color?
(regular-polygon side-length       
                 side-count        
                 outline-mode      
                 pen-or-color) -> image?
  side-length : (and/c real? (not/c negative?))
  side-count : side-count?
  outline-mode : (or/c 'outline "outline")
  pen-or-color : (or/c pen? image-color?)
procedure
(pulled-regular-polygon side-length     
                        side-count      
                        pull            
                        angle           
                        mode            
                        color)      -> image?
  side-length : (and/c real? (not/c negative?))
  side-count : side-count?
  pull : (and/c real? (not/c negative?))
  angle : angle?
  mode : mode?
  color : image-color?
(pulled-regular-polygon side-length       
                        side-count        
                        pull              
                        angle             
                        outline-mode      
                        pen-or-color) -> image?
  side-length : (and/c real? (not/c negative?))
  side-count : side-count?
  pull : (and/c real? (not/c negative?))
  angle : angle?
  outline-mode : (or/c 'outline "outline")
  pen-or-color : (or/c pen? image-color?)
procedure
(polygon vertices mode color) -> image?
  vertices : (listof (or/c real-valued-posn? pulled-point?))
  mode : mode?
  color : image-color?
(polygon vertices outline-mode pen-or-color) -> image?
  vertices : (listof (or/c real-valued-posn? pulled-point?))
  outline-mode : (or/c 'outline "outline")
  pen-or-color : (or/c pen? image-color?)
procedure
(add-polygon image posns mode color) -> image?
  image : image?
  posns : (listof posn?)
  mode : mode?
  color : image-color?
procedure
(scene+polygon image posns mode color) -> image?
  image : image?
  posns : (listof posn?)
  mode : mode?
  color : image-color?
procedure
(overlay i1 i2 is ...) -> image?
  i1 : image?
  i2 : image?
  is : image?
procedure
(overlay/align x-place y-place i1 i2 is ...) -> image?
  x-place : x-place?
  y-place : y-place?
  i1 : image?
  i2 : image?
  is : image?
procedure
(overlay/offset i1 x y i2) -> image?
  i1 : image?
  x : real?
  y : real?
  i2 : image?
procedure
(overlay/align/offset x-place     
                      y-place     
                      i1          
                      x           
                      y           
                      i2)     -> image?
  x-place : x-place?
  y-place : y-place?
  i1 : image?
  x : real?
  y : real?
  i2 : image?
procedure
(overlay/xy i1 x y i2) -> image?
  i1 : image?
  x : real?
  y : real?
  i2 : image?
procedure
(underlay i1 i2 is ...) -> image?
  i1 : image?
  i2 : image?
  is : image?
procedure
(underlay/align x-place y-place i1 i2 is ...) -> image?
  x-place : x-place?
  y-place : y-place?
  i1 : image?
  i2 : image?
  is : image?
procedure
(underlay/offset i1 x y i2) -> image?
  i1 : image?
  x : real?
  y : real?
  i2 : image?
procedure
(underlay/align/offset x-place     
                       y-place     
                       i1          
                       x           
                       y           
                       i2)     -> image?
  x-place : x-place?
  y-place : y-place?
  i1 : image?
  x : real?
  y : real?
  i2 : image?
procedure
(underlay/xy i1 x y i2) -> image?
  i1 : image?
  x : real?
  y : real?
  i2 : image?
procedure
(beside i1 i2 is ...) -> image?
  i1 : image?
  i2 : image?
  is : image?
procedure
(beside/align y-place i1 i2 is ...) -> image?
  y-place : y-place?
  i1 : image?
  i2 : image?
  is : image?
procedure
(above i1 i2 is ...) -> image?
  i1 : image?
  i2 : image?
  is : image?
procedure
(above/align x-place i1 i2 is ...) -> image?
  x-place : x-place?
  i1 : image?
  i2 : image?
  is : image?
procedure
(empty-scene width height) -> image?
  width : (and/c real? (not/c negative?))
  height : (and/c real? (not/c negative?))
(empty-scene width height color) -> image?
  width : (and/c real? (not/c negative?))
  height : (and/c real? (not/c negative?))
  color : image-color?
procedure
(place-image image x y scene) -> image?
  image : image?
  x : real?
  y : real?
  scene : image?
procedure
(place-image/align image       
                   x           
                   y           
                   x-place     
                   y-place     
                   scene)  -> image?
  image : image?
  x : real?
  y : real?
  x-place : x-place?
  y-place : y-place?
  scene : image?
procedure
(place-images images posns scene) -> image?
  images : (listof image?)
  posns : (listof posn?)
  scene : image?
procedure
(place-images/align images      
                    posns       
                    x-place     
                    y-place     
                    scene)  -> image?
  images : (listof image?)
  posns : (listof posn?)
  x-place : x-place?
  y-place : y-place?
  scene : image?
procedure
(scene+line scene x1 y1 x2 y2 pen-or-color) -> image?
  scene : image?
  x1 : real?
  y1 : real?
  x2 : real?
  y2 : real?
  pen-or-color : (or/c pen? image-color?)
procedure
(scene+curve scene      
             x1         
             y1         
             angle1     
             pull1      
             x2         
             y2         
             angle2     
             pull2      
             color) -> image?
  scene : image?
  x1 : real?
  y1 : real?
  angle1 : angle?
  pull1 : real?
  x2 : real?
  y2 : real?
  angle2 : angle?
  pull2 : real?
  color : (or/c pen? image-color?)
procedure
(rotate angle image) -> image?
  angle : angle?
  image : image?
procedure
(scale factor image) -> image?
  factor : (and/c real? positive?)
  image : image?
procedure
(scale/xy x-factor y-factor image) -> image?
  x-factor : (and/c real? positive?)
  y-factor : (and/c real? positive?)
  image : image?
procedure
(flip-horizontal image) -> image?
  image : image?
procedure
(flip-vertical image) -> image?
  image : image?
procedure
(crop x y width height image) -> image?
  x : real?
  y : real?
  width : (and/c real? (not/c negative?))
  height : (and/c real? (not/c negative?))
  image : image?
procedure
(crop/align x-place     
            y-place     
            width       
            height      
            image)  -> image?
  x-place : x-place?
  y-place : y-place?
  width : (and/c real? (not/c negative?))
  height : (and/c real? (not/c negative?))
  image : image?
procedure
(frame image) -> image?
  image : image?
procedure
(color-frame color image) -> image?
  color : (or/c pen? image-color?)
  image : image?
syntax
(bitmap bitmap-spec)
 
bitmap-spec = rel-string
            | id
procedure
(bitmap/url url) -> image?
  url : string?
procedure
(bitmap/file ps) -> image?
  ps : path-string?
procedure
(image->color-list image) -> (listof color?)
  image : image?
procedure
(color-list->bitmap colors width height) -> image?
  colors : (listof image-color?)
  width : (and/c real? (not/c negative?))
  height : (and/c real? (not/c negative?))
procedure
(freeze image) -> image?
  image : image?
(freeze width height image) -> image?
  width : (and/c real? (not/c negative?))
  height : (and/c real? (not/c negative?))
  image : image?
(freeze x y width height image) -> image?
  x : real?
  y : real?
  width : (and/c real? (not/c negative?))
  height : (and/c real? (not/c negative?))
  image : image?
procedure
(image-width i) -> (and/c integer? (not/c negative?) exact?)
  i : image?
procedure
(image-height i) -> (and/c integer? (not/c negative?) exact?)
  i : image?
procedure
(image-baseline i) -> (and/c integer? (not/c negative?) exact?)
  i : image?
procedure
(image? x) -> boolean?
  x : any/c
procedure
(mode? x) -> boolean?
  x : any/c
procedure
(image-color? x) -> boolean?
  x : any/c
struct
(struct color (red green blue alpha)
    #:extra-constructor-name make-color)
  red : (and/c natural-number/c (<=/c 255))
  green : (and/c natural-number/c (<=/c 255))
  blue : (and/c natural-number/c (<=/c 255))
  alpha : (and/c natural-number/c (<=/c 255))
struct
(struct pulled-point (lpull langle x y rpull rangle)
    #:extra-constructor-name make-pulled-point)
  lpull : real?
  langle : angle?
  x : real?
  y : real?
  rpull : real?
  rangle : angle?
procedure
(y-place? x) -> boolean?
  x : any/c
procedure
(x-place? x) -> boolean?
  x : any/c
procedure
(angle? x) -> boolean?
  x : any/c
procedure
(side-count? x) -> boolean?
  x : any/c
procedure
(step-count? x) -> boolean?
  x : any/c
procedure
(real-valued-posn? x) -> boolean?
  x : any/c
struct
(struct pen (color width style cap join)
    #:extra-constructor-name make-pen)
  color : image-color?
  width : (and/c real? (<=/c 0 255))
  style : pen-style?
  cap : pen-cap?
  join : pen-join?
procedure
(pen-style? x) -> boolean?
  x : any/c
procedure
(pen-cap? x) -> boolean?
  x : any/c
procedure
(pen-join? x) -> boolean?
  x : any/c
procedure
(center-pinhole image) -> image?
  image : image?
procedure
(put-pinhole x y image) -> image?
  x : integer?
  y : integer?
  image : image?
procedure
(pinhole-x image) -> (or/c integer? #f)
  image : image?
procedure
(pinhole-y image) -> (or/c integer? #f)
  image : image?
procedure
(clear-pinhole image) -> image?
  image : image?
procedure
(overlay/pinhole i1 i2 is ...) -> image?
  i1 : image?
  i2 : image?
  is : image?
procedure
(underlay/pinhole i1 i2 is ...) -> image?
  i1 : image?
  i2 : image?
  is : image?
procedure
(save-image image filename [width height]) -> boolean?
  image : image?
  filename : path-string?
  width : (and/c real? (not/c negative?)) = (image-width image)
  height : (and/c real? (not/c negative?))
         = (image-height image)
procedure
(save-svg-image image filename [width height]) -> void?
  image : image?
  filename : path-string?
  width : (and/c real? (not/c negative?)) = (image-width image)
  height : (and/c real? (not/c negative?))
         = (image-height image)
procedure
(animate create-image) -> natural-number/c
  create-image : (-> natural-number/c scene?)
procedure
(run-simulation create-image) -> natural-number/c
  create-image : (-> natural-number/c scene?)
procedure
(run-movie r m) -> [Listof image?]
  r : (and/c real? positive?)
  m : [Listof image?]
syntax
(big-bang state-expr clause ...)
 
clause = (on-tick tick-expr)
       | (on-tick tick-expr rate-expr)
       | (on-tick tick-expr rate-expr limit-expr)
       | (on-key key-expr)
       | (on-pad pad-expr)
       | (on-release release-expr)
       | (on-mouse mouse-expr)
       | (to-draw draw-expr)
       | (to-draw draw-expr width-expr height-expr)
       | (stop-when stop-expr)
       | (stop-when stop-expr last-scene-expr)
       | (check-with world?-expr)
       | (record? r-expr)
       | (state expr)
       | (on-receive rec-expr)
       | (register IP-expr)
       | (port Port-expr)
       | (name name-expr)
syntax
(to-draw render-expr)
 
  render-expr : (-> WorldState scene?)
syntax
(to-draw render-expr width-expr height-expr)
 
  render-expr : (-> WorldState scene?)
  width-expr : natural-number/c
  height-expr : natural-number/c
syntax
(on-tick tick-expr)
 
  tick-expr : (-> WorldState HandlerResult)
syntax
(on-tick tick-expr rate-expr)
 
  tick-expr : (-> WorldState HandlerResult)
  rate-expr : (and/c real? positive?)
syntax
(on-tick tick-expr rate-expr limit-expr)
 
  tick-expr : (-> WorldState HandlerResult)
  rate-expr : (and/c real? positive?)
  limit-expr : (and/c integer? positive?)
procedure
(key-event? x) -> boolean?
  x : any
procedure
(key=? x y) -> boolean?
  x : key-event?
  y : key-event?
syntax
(on-key key-expr)
 
  key-expr : (-> WorldState key-event? HandlerResult)
syntax
(on-release release-expr)
 
  release-expr : (-> WorldState key-event? HandlerResult)
procedure
(pad-event? x) -> boolean?
  x : any
procedure
(pad=? x y) -> boolean?
  x : pad-event?
  y : pad-event?
syntax
(on-pad pad-expr)
 
  pad-expr : (-> WorldState pad-event? HandlerResult)
syntax
(pad-handler clause ...)
 
clause = (up up-expr)
       | (down down-expr)
       | (left left-expr)
       | (right right-expr)
       | (space space-expr)
       | (shift shift-expr)
syntax
(up up-expr)
 
  tick-expr : (-> WorldState HandlerResult)
syntax
(down down-expr)
 
  tick-expr : (-> WorldState HandlerResult)
syntax
(left left-expr)
 
  tick-expr : (-> WorldState HandlerResult)
syntax
(right right-expr)
 
  tick-expr : (-> WorldState HandlerResult)
syntax
(space space-expr)
 
  tick-expr : (-> WorldState HandlerResult)
syntax
(shift shift-expr)
 
  tick-expr : (-> WorldState HandlerResult)
procedure
(mouse-event? x) -> boolean?
  x : any
procedure
(mouse=? x y) -> boolean?
  x : mouse-event?
  y : mouse-event?
syntax
(on-mouse mouse-expr)
 
  mouse-expr : (-> WorldState
                   integer? integer? MouseEvent
                   HandlerResult)
syntax
(stop-when last-world?)
 
  last-world? : (-> WorldState boolean?)
syntax
(stop-when last-world? last-picture)
 
  last-world? : (-> WorldState boolean?)
  last-picture : (-> WorldState scene?)
struct
(struct stop-with (w))
  w : HandlerResult
syntax
(check-with world-expr?)
 
  world-expr? : (-> Any boolean?)
syntax
(record? r-expr)
 
  r-expr : any/c
syntax
(state expr)
syntax
(name name-expr)
 
  name-expr : (or/c symbol? string?)
procedure
(sexp? x) -> boolean?
  x : any/c
procedure
(package? x) -> boolean?
  x : any/c
procedure
(make-package w m) -> package?
  w : any/c
  m : sexp?
value
LOCALHOST : string?
syntax
(register ip-expr)
 
  ip-expr : string?
syntax
(port port-expr)
 
  port-expr : natural-number/c
syntax
(on-receive receive-expr)
 
  receive-expr : (-> WorldState sexp? HandlerResult)
procedure
(iworld? x) -> boolean?
  x : any/c
procedure
(iworld=? u v) -> boolean?
  u : iworld?
  v : iworld?
procedure
(iworld-name w) -> (or/c symbol? string?)
  w : iworld?
value
iworld1 : iworld?
value
iworld2 : iworld?
value
iworld3 : iworld?
procedure
(bundle? x) -> boolean?
  x : any/c
procedure
(make-bundle state mails low) -> bundle?
  state : any/c
  mails : (listof mail?)
  low : (listof iworld?)
procedure
(mail? x) -> boolean?
  x : any/c
procedure
(make-mail to content) -> mail?
  to : iworld?
  content : sexp?
syntax
(universe state-expr clause ...)
 
clause = (on-new new-expr)
       | (on-msg msg-expr)
       | (on-tick tick-expr)
       | (on-tick tick-expr rate-expr)
       | (on-tick tick-expr rate-expr limit-expr)
       | (on-disconnect dis-expr)
       | (state expr)
       | (to-string render-expr)
       | (port port-expr)
       | (check-with universe?-expr)
syntax
(on-new new-expr)
 
  new-expr : (-> UniverseState iworld? (or/c UniverseState bundle?))
syntax
(on-msg msg-expr)
 
  msg-expr : (-> UniverseState iworld? sexp? (or/c UniverseState bundle?))
syntax
(on-tick tick-expr)
 
  tick-expr : (-> UniverseState (or/c UniverseState bundle?))
syntax
(on-tick tick-expr rate-expr)
 
  tick-expr : (-> UniverseState (or/c UniverseState bundle?))
  rate-expr : (and/c real? positive?)
syntax
(on-tick tick-expr rate-expr)
 
  tick-expr : (-> UniverseState (or/c UniverseState bundle?))
  rate-expr : (and/c real? positive?)
  limit-expr : (and/c integer? positive?)
syntax
(on-disconnect dis-expr)
 
  dis-expr : (-> UniverseState iworld? (or/c UniverseState bundle?))
syntax
(port port-expr)
 
  port-expr : natural-number/c
syntax
(to-string render-expr)
 
  render-expr : (-> UniverseState string?)
syntax
(check-with universe?-expr)
 
  universe?-expr : (-> Any boolean?)
syntax
(state expr)
syntax
(launch-many-worlds expression ...)
procedure
(launch-many-worlds/proc thunk-that-runs-a-world     
                         ...)                    -> any ...
  thunk-that-runs-a-world : (-> any/c)
syntax
(for/list (comprehension-clause comprehension-clause ...) body-expr)
 
comprehension-clause = (name clause-expr)
syntax
(for*/list (comprehension-clause comprehension-clause ...) body-expr)
syntax
(for/or (comprehension-clause comprehension-clause ...) body-expr)
syntax
(for*/or (comprehension-clause comprehension-clause ...) body-expr)
syntax
(for/and (comprehension-clause comprehension-clause ...) body-expr)
syntax
(for*/and (comprehension-clause comprehension-clause ...) body-expr)
syntax
(for/sum (comprehension-clause comprehension-clause ...) body-expr)
syntax
(for*/sum (comprehension-clause comprehension-clause ...) body-expr)
syntax
(for/product (comprehension-clause comprehension-clause ...) body-expr)
syntax
(for*/product (comprehension-clause comprehension-clause ...) body-expr)
syntax
(for/string (comprehension-clause comprehension-clause ...) body-expr)
syntax
(for*/string (comprehension-clause comprehension-clause ...) body-expr)
procedure
(in-range start end step) -> sequence?
  start : natural-number/c
  end : natural-number/c
  step : natural-number/c
(in-range end) -> sequence?
  end : natural-number/c
procedure
(in-naturals start) -> sequence?
  start : natural-number/c
syntax
(match case-expr (pattern body-expr) ...)
 
pattern = name
        | literal-constant
        | (cons pattern pattern)
        | (name pattern ...)
        | (? name)
syntax
(define-type type (variant (field predicate) ...) ...)
 
     type = name
             
  variant = name
             
    field = name
             
predicate = name
syntax
(type-case type case-expr (variant (field ...) body-expr) ...)
value
character-boy : image?
value
character-cat-girl : image?
value
character-horn-girl : image?
value
character-pink-girl : image?
value
character-princess-girl : image?
value
enemy-bug : image?
value
speech-bubble : image?
value
brown-block : image?
value
dirt-block : image?
value
grass-block : image?
value
plain-block : image?
value
stone-block-tall : image?
value
stone-block : image?
value
wall-block-tall : image?
value
wall-block : image?
value
water-block : image?
value
wood-block : image?
value
chest-closed : image?
value
chest-lid : image?
value
chest-open : image?
value
gem-blue : image?
value
gem-green : image?
value
gem-orange : image?
value
heart : image?
value
key : image?
value
rock : image?
value
selector : image?
value
tree-short : image?
value
tree-tall : image?
value
tree-ugly : image?
value
yellow-star : image?
value
ramp-east : image?
value
ramp-north : image?
value
ramp-south : image?
value
ramp-west : image?
value
door-tall-closed : image?
value
door-tall-open : image?
value
roof-east : image?
value
roof-north-east : image?
value
roof-north-west : image?
value
roof-north : image?
value
roof-south-east : image?
value
roof-south-west : image?
value
roof-south : image?
value
roof-west : image?
value
window-tall : image?
value
shadow-east : image?
value
shadow-north-east : image?
value
shadow-north-west : image?
value
shadow-north : image?
value
shadow-side-west : image?
value
shadow-south-east : image?
value
shadow-south-west : image?
value
shadow-south : image?
value
shadow-west : image?

World Style           Universe Style
  (require htdp/world)  (require 2htdp/universe)
                        (require htdp/image)

World Style           Universe Style
  (require htdp/world)  (require 2htdp/universe)
                        (require htdp/image)

World Style                        Universe Style
  ; Number -> Scene                  ; Number -> Scene
  (define (create-UFO-scene height)  (define (create-UFO-scene height)
    (htdp:place-image                  (htdp:place-image
      UFO                                UFO
      50 height                          50 height
      (htdp:empty-scene 100 100)))       (htdp:empty-scene 100 100)))

World Style               Universe Style
  ; Scene                   ; Scene
  (define UFO               (define UFO
    (htdp:overlay             (htdp:overlay
      (htdp:circle              (htdp:circle
       10 'solid 'red)           10 "solid" "red")
      (htdp:rectangle           (htdp:rectangle
       40 4 'solid 'red)))       40 4 "solid" "red")))

World Style                        Universe Style
  (htdp:big-bang 100 100 (/1 28) 0)  (2htdp:big-bang
  (htdp:on-tick-event add1)            0
  (htdp:on-redraw create-UFO-scene)    (on-tick add1)
                                       (on-draw create-UFO-scene))

World Style                      Universe Style
  (define (change w a-key-event)   (define (change w a-key-event)
    (cond                            (cond
      [(key=? a-key-event 'left)       [(key=? a-key-event "left")
       (world-go w -DELTA)]             (world-go w -DELTA)]
      [(key=? a-key-event 'right)      [(key=? a-key-event "right")
       (world-go w +DELTA)]             (world-go w +DELTA)]
      [(char? a-key-event)             [(= (string-length a-key-event) 1)
       w]                               w]
      [(key=? a-key-event 'up)         [(key=? a-key-event "up")
       (world-go w -DELTA)]             (world-go w -DELTA)]
      [(key=? a-key-event 'down)       [(key=? a-key-event "down")
       (world-go w +DELTA)]             (world-go w +DELTA)]
      [else                            [else
       w]))                             w]))

World Style           Universe Style
  (require htdp/image)  (require 2htdp/image)

World Style           Universe Style
  (require htdp/world)  (require 2htdp/universe)
                        (require 2htdp/image)

World Style               Universe Style
  (htdp:overlay             (2htdp:underlay
   (htdp:rectangle           (2htdp:rectangle
    10 20 "solid" "red")      10 20 "solid" "red")
   (htdp:rectangle           (2htdp:rectangle
    20 10 "solid" "blue"))    20 10 "solid" "blue"))

World Style                              Universe Style
  (htdp:overlay                            (2htdp:underlay/align
   (htdp:put-pinhole                        "left"
    (htdp:rectangle 10 20 "solid" "red")    "top"
    0 0)                                    (2htdp:rectangle
   (htdp:put-pinhole                         10 20 "solid" "red")
    (htdp:rectangle 20 10 "solid" "blue")   (2htdp:rectangle
    0 0))                                    20 10 "solid" "blue"))

World Style                Universe Style
  (htdp:rectangle            (2htdp:rectangle
   11 11 "outline" "black")   10 10 "outline" "black")
