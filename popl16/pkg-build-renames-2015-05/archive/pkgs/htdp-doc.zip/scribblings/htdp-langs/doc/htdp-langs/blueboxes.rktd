58443
((3) 0 () 5 ((q lib "lang/htdp-intermediate.rkt") (q lib "lang/htdp-intermediate-lambda.rkt") (q lib "lang/htdp-beginner.rkt") (q lib "lang/htdp-advanced.rkt") (q lib "lang/htdp-beginner-abbr.rkt")) () (h ! (equal) ((c form c (c (? . 4) q check-within)) q (14589 . 2)) ((c def c (c (? . 0) q add1)) q (29608 . 3)) ((c def c (c (? . 0) q inexact->exact)) q (30636 . 3)) ((c def c (c (? . 1) q fifth)) q (49597 . 3)) ((c def c (c (? . 1) q char<=?)) q (52181 . 5)) ((c def c (c (? . 2) q char<=?)) q (9422 . 5)) ((c def c (c (? . 0) q string?)) q (39791 . 3)) ((c def c (c (? . 2) q /)) q (1692 . 5)) ((c form c (c (? . 2) q check-range)) q (1138 . 2)) ((c def c (c (? . 0) q =~)) q (40078 . 5)) ((c def c (c (? . 1) q assq)) q (48584 . 4)) ((c def c (c (? . 1) q argmax)) q (56615 . 4)) ((c def c (c (? . 2) q string-lower-case?)) q (11635 . 3)) ((c def c (c (? . 3) q argmax)) q (73063 . 4)) ((c def c (c (? . 3) q string<?)) q (70966 . 5)) ((c def c (c (? . 4) q acos)) q (15932 . 3)) ((c def c (c (? . 0) q e)) q (30160 . 2)) ((c form c (c (? . 0) q check-satisfied)) q (28441 . 2)) ((c def c (c (? . 4) q list-ref)) q (20877 . 4)) ((c def c (c (? . 0) q denominator)) q (30100 . 3)) ((c def c (c (? . 2) q cos)) q (2673 . 3)) ((c def c (c (? . 0) q length)) q (34299 . 3)) ((c def c (c (? . 0) q ceiling)) q (29803 . 3)) ((c def c (c (? . 0) q false)) q (27147 . 2)) ((c def c (c (? . 1) q eof)) q (55621 . 2)) ((c def c (c (? . 1) q exact?)) q (45732 . 3)) ((c def c (c (? . 0) q string-contains?)) q (38672 . 4)) ((c def c (c (? . 2) q string->list)) q (10512 . 3)) ((c def c (c (? . 0) q cddar)) q (33747 . 3)) ((c def c (c (? . 4) q list*)) q (20805 . 4)) ((c form c (c (? . 1) q λ)) q (42689 . 2)) ((c def c (c (? . 4) q pi)) q (18110 . 2)) ((c def c (c (? . 1) q exit)) q (56068 . 2)) ((c def c (c (? . 2) q error)) q (13256 . 3)) ((c def c (c (? . 1) q car)) q (49001 . 3)) ((c def c (c (? . 2) q list*)) q (7143 . 4)) ((c def c (c (? . 1) q make-string)) q (52995 . 4)) ((c def c (c (? . 3) q *)) q (72645 . 3)) ((c def c (c (? . 3) q empty)) q (57945 . 2)) ((c def c (c (? . 1) q string->int)) q (53214 . 3)) ((c def c (c (? . 4) q cons?)) q (20397 . 3)) ((c def c (c (? . 4) q complex?)) q (16227 . 3)) ((c def c (c (? . 3) q char-alphabetic?)) q (67429 . 3)) ((c def c (c (? . 4) q string-ci<=?)) q (24501 . 5)) ((c def c (c (? . 0) q image?)) q (40026 . 3)) ((c def c (c (? . 4) q remainder)) q (18471 . 4)) ((c def c (c (? . 0) q first)) q (34202 . 3)) ((c def c (c (? . 0) q string->list)) q (37828 . 3)) ((c def c (c (? . 2) q char-alphabetic?)) q (8537 . 3)) ((c def c (c (? . 0) q char<=?)) q (36738 . 5)) ((c def c (c (? . 4) q string-ci>=?)) q (24811 . 5)) ((c def c (c (? . 1) q string?)) q (55234 . 3)) ((c def c (c (? . 0) q eqv?)) q (40503 . 4)) ((c def c (c (? . 0) q map)) q (41964 . 4)) ((c def c (c (? . 4) q equal?)) q (26675 . 4)) ((c def c (c (? . 0) q number?)) q (31574 . 3)) ((c form c (c (? . 0) q check-member-of)) q (28634 . 2)) ((c def c (c (? . 1) q integer->char)) q (46193 . 3)) ((c def c (c (? . 0) q make-posn)) q (35583 . 4)) ((c def c (c (? . 3) q map)) q (73855 . 4)) ((c def c (c (? . 3) q hash-update!)) q (77011 . 5)) ((c def c (c (? . 3) q error)) q (72200 . 3)) ((c def c (c (? . 1) q null)) q (50489 . 2)) ((c def c (c (? . 4) q sub1)) q (18870 . 3)) ((c def c (c (? . 3) q string->symbol)) q (69544 . 3)) ((c def c (c (? . 3) q -)) q (60319 . 4)) ((c def c (c (? . 2) q identity)) q (13336 . 3)) ((c form c (c (? . 3) q check-member-of)) q (59952 . 2)) ((c def c (c (? . 3) q lcm)) q (62245 . 4)) ((c def c (c (? . 1) q string>=?)) q (55033 . 5)) ((c def c (c (? . 0) q char-ci>?)) q (36296 . 5)) ((c def c (c (? . 1) q e)) q (45603 . 2)) ((c def c (c (? . 0) q real-part)) q (31995 . 3)) ((c def c (c (? . 2) q floor)) q (3170 . 3)) ((c def c (c (? . 3) q eof-object?)) q (71832 . 3)) ((c def c (c (? . 4) q string?)) q (26137 . 3)) ((c def c (c (? . 4) q string->int)) q (24117 . 3)) ((c def c (c (? . 2) q exact->inexact)) q (2941 . 3)) ((c def c (c (? . 0) q struct?)) q (40701 . 3)) ((c def c (c (? . 4) q string-ith)) q (25157 . 4)) ((c def c (c (? . 3) q string<=?)) q (70865 . 5)) ((c def c (c (? . 4) q not)) q (19205 . 3)) ((c def c (c (? . 4) q cdaar)) q (19999 . 3)) ((c form c (c (? . 3) q local)) q (58924 . 2)) ((c form c (c (? . 2) q or)) q (716 . 2)) ((c def c (c (? . 2) q char<?)) q (9515 . 5)) ((c form c (c (? . 3) q when)) q (58826 . 2)) ((c def c (c (? . 3) q with-input-from-string)) q (74750 . 4)) ((c form c (c (? . 0) q require)) q (28766 . 2)) ((c def c (c (? . 0) q posn-x)) q (35653 . 3)) ((c def c (c (? . 2) q eqv?)) q (13187 . 4)) ((c def c (c (? . 0) q quicksort)) q (42301 . 4)) ((c def c (c (? . 3) q posn-x)) q (67090 . 3)) ((c def c (c (? . 1) q random)) q (47330 . 3)) ((c def c (c (? . 4) q image=?)) q (26300 . 4)) ((c def c (c (? . 1) q build-list)) q (56771 . 4)) ((c form c (c (? . 3) q check-within)) q (59807 . 2)) ((c def c (c (? . 3) q string-ref)) q (70654 . 4)) ((c def c (c (? . 4) q memq)) q (21173 . 4)) ((c def c (c (? . 1) q char<?)) q (52274 . 5)) ((c def c (c (? . 3) q compose)) q (73385 . 4)) ((c def c (c (? . 2) q struct?)) q (13385 . 3)) ((c def c (c (? . 4) q char-upcase)) q (22910 . 3)) ((c def c (c (? . 4) q =)) q (15620 . 5)) ((c form c (c (? . 3) q λ)) q (58122 . 2)) ((c def c (c (? . 3) q add1)) q (60926 . 3)) ((c def c (c (? . 4) q string>?)) q (26037 . 5)) ((c def c (c (? . 2) q exact?)) q (3000 . 3)) ((c def c (c (? . 4) q equal~?)) q (26746 . 5)) ((c def c (c (? . 3) q string-ith)) q (70387 . 4)) ((c form c (c (? . 4) q require)) q (14866 . 2)) ((c def c (c (? . 0) q integer?)) q (30873 . 3)) ((c def c (c (? . 0) q seventh)) q (35437 . 3)) ((c def c (c (? . 3) q exact?)) q (61607 . 3)) ((c def c (c (? . 4) q char-ci<=?)) q (22260 . 5)) ((c form c (c (? . 3) q .....)) q (58050 . 2)) ((c def c (c (? . 4) q >=)) q (15800 . 5)) ((c form c (c (? . 3) q or)) q (59596 . 2)) ((c def c (c (? . 3) q sgn)) q (63542 . 3)) ((c def c (c (? . 4) q zero?)) q (18967 . 3)) ((c def c (c (? . 1) q char-ci>=?)) q (51643 . 5)) ((c def c (c (? . 4) q string-ci=?)) q (24708 . 5)) ((c def c (c (? . 4) q caaar)) q (19618 . 3)) ((c def c (c (? . 0) q random)) q (31887 . 3)) ((c def c (c (? . 4) q memv)) q (21312 . 4)) ((c def c (c (? . 0) q memv)) q (34966 . 4)) ((c def c (c (? . 1) q log)) q (46446 . 3)) ((c def c (c (? . 1) q remainder)) q (47541 . 4)) ((c def c (c (? . 1) q cadr)) q (48954 . 3)) ((c def c (c (? . 1) q abs)) q (44958 . 3)) ((c def c (c (? . 2) q char->integer)) q (8480 . 3)) ((c def c (c (? . 1) q char-ci<?)) q (51453 . 5)) ((c def c (c (? . 1) q compose)) q (56937 . 4)) ((c def c (c (? . 3) q vector)) q (75266 . 3)) ((c def c (c (? . 3) q not)) q (64150 . 3)) ((c def c (c (? . 0) q make-string)) q (37552 . 4)) ((c def c (c (? . 0) q sqrt)) q (32448 . 3)) ((c def c (c (? . 3) q range)) q (66554 . 5)) ((c def c (c (? . 4) q string-upper-case?)) q (25505 . 3)) ((c def c (c (? . 0) q string-numeric?)) q (39016 . 3)) ((c def c (c (? . 0) q caddr)) q (33463 . 3)) ((c def c (c (? . 0) q sub1)) q (32497 . 3)) ((c def c (c (? . 2) q char>?)) q (9792 . 5)) ((c def c (c (? . 4) q char?)) q (23546 . 3)) ((c def c (c (? . 1) q zero?)) q (48037 . 3)) ((c form c (c (? . 3) q ......)) q (58063 . 2)) ((c def c (c (? . 0) q string>=?)) q (39590 . 5)) ((c def c (c (? . 3) q string-lower-case?)) q (70527 . 3)) ((c def c (c (? . 1) q string)) q (53159 . 3)) ((c def c (c (? . 0) q negative?)) q (31459 . 3)) ((c form c (c (? . 3) q check-error)) q (59869 . 3)) ((c form c (c (? . 1) q define)) q (43027 . 2)) ((c def c (c (? . 1) q member)) q (50127 . 4)) ((c def c (c (? . 2) q abs)) q (2226 . 3)) ((c def c (c (? . 1) q format)) q (52756 . 4)) ((c def c (c (? . 0) q boolean=?)) q (32646 . 4)) ((c def c (c (? . 4) q cdar)) q (20095 . 3)) ((c def c (c (? . 3) q substring)) q (71420 . 5)) ((c def c (c (? . 3) q cdaar)) q (65019 . 3)) ((c def c (c (? . 2) q image?)) q (12710 . 3)) ((c def c (c (? . 2) q string>?)) q (12375 . 5)) ((c def c (c (? . 2) q e)) q (2871 . 2)) ((c def c (c (? . 4) q e)) q (16533 . 2)) ((c def c (c (? . 3) q display)) q (74393 . 3)) ((c def c (c (? . 2) q max)) q (3962 . 4)) ((c def c (c (? . 3) q set-posn-y!)) q (67303 . 4)) ((c def c (c (? . 4) q atan)) q (16127 . 3)) ((c def c (c (? . 2) q char-ci>=?)) q (8884 . 5)) ((c def c (c (? . 3) q abs)) q (60833 . 3)) ((c def c (c (? . 3) q false)) q (57992 . 2)) ((c def c (c (? . 4) q string-copy)) q (25101 . 3)) ((c def c (c (? . 0) q empty?)) q (34102 . 3)) ((c def c (c (? . 1) q cosh)) q (45453 . 3)) ((c def c (c (? . 2) q member)) q (7368 . 4)) ((c form c (c (? . 3) q set!)) q (58366 . 2)) ((c def c (c (? . 3) q /)) q (72747 . 4)) ((c def c (c (? . 1) q third)) q (50978 . 3)) ((c def c (c (? . 0) q >=)) q (29427 . 5)) ((c def c (c (? . 0) q char>?)) q (37108 . 5)) ((c def c (c (? . 0) q string=?)) q (39490 . 5)) ((c def c (c (? . 4) q string-alphabetic?)) q (24373 . 3)) ((c form c (c (? . 4) q unquote-splicing)) q (13792 . 2)) ((c def c (c (? . 4) q +)) q (15192 . 5)) ((c def c (c (? . 3) q void?)) q (72596 . 3)) ((c def c (c (? . 2) q string-ci>=?)) q (11149 . 5)) ((c def c (c (? . 1) q real?)) q (47490 . 3)) ((c def c (c (? . 2) q pi)) q (4448 . 2)) ((c def c (c (? . 2) q posn?)) q (8429 . 3)) ((c def c (c (? . 3) q foldl)) q (73562 . 5)) ((c def c (c (? . 3) q char-numeric?)) q (68082 . 3)) ((c def c (c (? . 2) q tan)) q (5257 . 3)) ((c def c (c (? . 1) q posn-y)) q (51142 . 3)) ((c def c (c (? . 1) q argmin)) q (56693 . 4)) ((c def c (c (? . 3) q with-input-from-file)) q (74665 . 4)) ((c def c (c (? . 3) q string->list)) q (69404 . 3)) ((c def c (c (? . 3) q set-box!)) q (75766 . 4)) ((c def c (c (? . 4) q round)) q (18548 . 3)) ((c form c (c (? . 3) q check-satisfied)) q (59759 . 2)) ((c def c (c (? . 3) q list-ref)) q (65919 . 4)) ((c def c (c (? . 3) q make-string)) q (69128 . 4)) ((c def c (c (? . 0) q ormap)) q (42159 . 4)) ((c def c (c (? . 0) q null)) q (35046 . 2)) ((c def c (c (? . 3) q cons)) q (65351 . 4)) ((c form c (c (? . 0) q check-range)) q (28700 . 2)) ((c form c (c (? . 4) q quasiquote)) q (13672 . 2)) ((c def c (c (? . 1) q char->integer)) q (51239 . 3)) ((c def c (c (? . 1) q char-ci<=?)) q (51357 . 5)) ((c def c (c (? . 0) q modulo)) q (31385 . 4)) ((c def c (c (? . 0) q caaar)) q (33223 . 3)) ((c def c (c (? . 1) q eighth)) q (49496 . 3)) ((c def c (c (? . 4) q length)) q (20694 . 3)) ((c def c (c (? . 1) q imag-part)) q (46027 . 3)) ((c def c (c (? . 2) q list)) q (7091 . 3)) ((c def c (c (? . 1) q posn?)) q (51188 . 3)) ((c def c (c (? . 4) q posn-y)) q (22045 . 3)) ((c def c (c (? . 1) q string<?)) q (54833 . 5)) ((c def c (c (? . 1) q length)) q (49742 . 3)) ((c def c (c (? . 0) q fifth)) q (34154 . 3)) ((c def c (c (? . 3) q char<?)) q (68407 . 5)) ((c def c (c (? . 1) q char>=?)) q (52458 . 5)) ((c def c (c (? . 2) q caar)) q (6052 . 3)) ((c def c (c (? . 3) q remove)) q (66661 . 4)) ((c def c (c (? . 4) q reverse)) q (21685 . 3)) ((c def c (c (? . 1) q cadar)) q (48809 . 3)) ((c def c (c (? . 3) q odd?)) q (63003 . 3)) ((c def c (c (? . 0) q round)) q (32175 . 3)) ((c def c (c (? . 2) q equal~?)) q (13084 . 5)) ((c def c (c (? . 4) q numerator)) q (18000 . 3)) ((c def c (c (? . 2) q imag-part)) q (3295 . 3)) ((c def c (c (? . 4) q empty)) q (13438 . 2)) ((c form c (c (? . 4) q if)) q (14261 . 2)) ((c def c (c (? . 2) q string-ci<=?)) q (10839 . 5)) ((c def c (c (? . 3) q char-ci>=?)) q (67776 . 5)) ((c form c (c (? . 1) q cond)) q (43440 . 5)) ((c def c (c (? . 0) q make-polar)) q (31103 . 4)) ((c def c (c (? . 2) q magnitude)) q (3762 . 3)) ((c def c (c (? . 2) q <=)) q (1870 . 5)) ((c def c (c (? . 1) q append)) q (48514 . 3)) ((c def c (c (? . 4) q list->string)) q (23842 . 3)) ((c def c (c (? . 0) q string-whitespace?)) q (39224 . 3)) ((c def c (c (? . 3) q string?)) q (71367 . 3)) ((c def c (c (? . 4) q char>?)) q (23454 . 5)) ((c def c (c (? . 3) q null?)) q (66503 . 3)) ((c def c (c (? . 3) q sinh)) q (63669 . 3)) ((c def c (c (? . 0) q foldl)) q (41671 . 5)) ((c def c (c (? . 4) q string-contains?)) q (25018 . 4)) ((c form c (c (? . 0) q local)) q (27232 . 2)) ((c def c (c (? . 0) q current-seconds)) q (30059 . 2)) ((c form c (c (? . 1) q check-expect)) q (43774 . 2)) ((c def c (c (? . 0) q eq?)) q (40261 . 4)) ((c def c (c (? . 3) q fourth)) q (65673 . 3)) ((c form c (c (? . 3) q letrec)) q (58970 . 2)) ((c def c (c (? . 2) q third)) q (8219 . 3)) ((c def c (c (? . 1) q boolean?)) q (48169 . 3)) ((c def c (c (? . 3) q tan)) q (63864 . 3)) ((c def c (c (? . 4) q conjugate)) q (16281 . 3)) ((c form c (c (? . 0) q define)) q (27730 . 2)) ((c def c (c (? . 0) q sgn)) q (32224 . 3)) ((c def c (c (? . 1) q sin)) q (47746 . 3)) ((c def c (c (? . 0) q append)) q (33071 . 3)) ((c def c (c (? . 2) q string-whitespace?)) q (11908 . 3)) ((c def c (c (? . 3) q expt)) q (61708 . 4)) ((c def c (c (? . 1) q char-whitespace?)) q (52120 . 3)) ((c form c (c (? . 1) q require)) q (44209 . 2)) ((c def c (c (? . 1) q eqv?)) q (55946 . 4)) ((c def c (c (? . 0) q char-ci<?)) q (36010 . 5)) ((c def c (c (? . 0) q rational?)) q (31940 . 3)) ((c def c (c (? . 3) q inexact?)) q (62013 . 3)) ((c def c (c (? . 3) q reverse)) q (66776 . 3)) ((c def c (c (? . 2) q cadddr)) q (6147 . 3)) ((c def c (c (? . 4) q imag-part)) q (16957 . 3)) ((c form c (c (? . 1) q quote)) q (43152 . 2)) ((c def c (c (? . 1) q make-rectangular)) q (46617 . 4)) ((c def c (c (? . 3) q empty?)) q (65525 . 3)) ((c def c (c (? . 1) q posn)) q (56370 . 2)) ((c def c (c (? . 2) q string-copy)) q (11439 . 3)) ((c def c (c (? . 2) q string>=?)) q (12274 . 5)) ((c form c (c (? . 3) q define-datatype)) q (58200 . 2)) ((c def c (c (? . 3) q force)) q (72280 . 3)) ((c def c (c (? . 4) q string-whitespace?)) q (25570 . 3)) ((c def c (c (? . 3) q string-ci<=?)) q (69731 . 5)) ((c def c (c (? . 3) q list)) q (65781 . 3)) ((c def c (c (? . 3) q string-alphabetic?)) q (69603 . 3)) ((c def c (c (? . 2) q -)) q (1621 . 4)) ((c def c (c (? . 4) q format)) q (23659 . 4)) ((c form c (c (? . 3) q define-struct)) q (59257 . 2)) ((c def c (c (? . 4) q lcm)) q (17300 . 4)) ((c def c (c (? . 4) q remove)) q (21570 . 4)) ((c form c (c (? . 4) q check-member-of)) q (14734 . 2)) ((c def c (c (? . 3) q member)) q (66121 . 4)) ((c def c (c (? . 0) q eof-object?)) q (40204 . 3)) ((c def c (c (? . 4) q <)) q (15445 . 5)) ((c form c (c (? . 3) q let*)) q (59027 . 2)) ((c def c (c (? . 4) q cadddr)) q (19809 . 3)) ((c def c (c (? . 3) q make-rectangular)) q (62492 . 4)) ((c def c (c (? . 3) q current-milliseconds)) q (71754 . 2)) ((c def c (c (? . 0) q conjugate)) q (29908 . 3)) ((c def c (c (? . 2) q min)) q (4029 . 4)) ((c def c (c (? . 4) q cddar)) q (20142 . 3)) ((c def c (c (? . 3) q promise?)) q (72405 . 3)) ((c def c (c (? . 2) q char-ci<=?)) q (8598 . 5)) ((c form c (c (? . 0) q ......)) q (27218 . 2)) ((c def c (c (? . 3) q <)) q (60390 . 5)) ((c def c (c (? . 0) q cdr)) q (33890 . 3)) ((c def c (c (? . 2) q caadr)) q (6004 . 3)) ((c def c (c (? . 3) q struct?)) q (72515 . 3)) ((c def c (c (? . 0) q procedure?)) q (42247 . 3)) ((c def c (c (? . 2) q log)) q (3714 . 3)) ((c def c (c (? . 0) q /)) q (40856 . 4)) ((c def c (c (? . 1) q char-alphabetic?)) q (51296 . 3)) ((c form c (c (? . 3) q if)) q (59479 . 2)) ((c def c (c (? . 0) q second)) q (35388 . 3)) ((c def c (c (? . 2) q string-ref)) q (11762 . 4)) ((c def c (c (? . 1) q floor)) q (45902 . 3)) ((c def c (c (? . 4) q string-length)) q (25242 . 3)) ((c def c (c (? . 1) q memq?)) q (50339 . 4)) ((c def c (c (? . 0) q remove)) q (35224 . 4)) ((c def c (c (? . 0) q magnitude)) q (31051 . 3)) ((c def c (c (? . 1) q integer-sqrt)) q (46257 . 3)) ((c def c (c (? . 2) q complex?)) q (2565 . 3)) ((c def c (c (? . 4) q sqrt)) q (18821 . 3)) ((c def c (c (? . 0) q argmin)) q (41250 . 4)) ((c def c (c (? . 3) q append)) q (64389 . 3)) ((c def c (c (? . 3) q gcd)) q (61826 . 4)) ((c def c (c (? . 1) q *)) q (56197 . 3)) ((c def c (c (? . 3) q string)) q (69292 . 3)) ((c def c (c (? . 3) q hash-remove!)) q (76644 . 4)) ((c form c (c (? . 3) q delay)) q (58402 . 2)) ((c def c (c (? . 0) q char-downcase)) q (36391 . 3)) ((c def c (c (? . 4) q third)) q (21881 . 3)) ((c def c (c (? . 0) q char-whitespace?)) q (36677 . 3)) ((c def c (c (? . 4) q true)) q (13461 . 2)) ((c def c (c (? . 3) q member?)) q (66192 . 4)) ((c def c (c (? . 2) q range)) q (7801 . 5)) ((c def c (c (? . 0) q max)) q (31251 . 4)) ((c def c (c (? . 1) q string-length)) q (54339 . 3)) ((c def c (c (? . 3) q string>?)) q (71267 . 5)) ((c def c (c (? . 1) q boolean=?)) q (48089 . 4)) ((c def c (c (? . 2) q true)) q (23 . 2)) ((c form c (c (? . 4) q check-random)) q (14486 . 2)) ((c def c (c (? . 1) q string->number)) q (53336 . 3)) ((c def c (c (? . 4) q string-append)) q (24438 . 3)) ((c def c (c (? . 0) q string-copy)) q (38755 . 3)) ((c def c (c (? . 3) q e)) q (61478 . 2)) ((c def c (c (? . 0) q char-upper-case?)) q (36616 . 3)) ((c def c (c (? . 2) q implode)) q (10072 . 3)) ((c def c (c (? . 1) q angle)) q (45100 . 3)) ((c form c (c (? . 4) q or)) q (14378 . 2)) ((c def c (c (? . 2) q sub1)) q (5208 . 3)) ((c def c (c (? . 3) q false?)) q (64098 . 3)) ((c def c (c (? . 3) q sort)) q (74295 . 4)) ((c form c (c (? . 3) q begin0)) q (58321 . 2)) ((c def c (c (? . 4) q negative?)) q (17832 . 3)) ((c def c (c (? . 0) q string)) q (37716 . 3)) ((c def c (c (? . 0) q string->int)) q (37771 . 3)) ((c def c (c (? . 3) q eq?)) q (71889 . 4)) ((c def c (c (? . 2) q memq?)) q (7580 . 4)) ((c def c (c (? . 0) q empty)) q (27100 . 2)) ((c def c (c (? . 3) q make-vector)) q (75188 . 4)) ((c def c (c (? . 1) q denominator)) q (45543 . 3)) ((c def c (c (? . 0) q char-upcase)) q (36564 . 3)) ((c def c (c (? . 4) q rational?)) q (18313 . 3)) ((c form c (c (? . 3) q unless)) q (58874 . 2)) ((c def c (c (? . 4) q denominator)) q (16473 . 3)) ((c form c (c (? . 0) q ...)) q (27182 . 2)) ((c form c (c (? . 3) q match)) q (58771 . 2)) ((c def c (c (? . 4) q angle)) q (16030 . 3)) ((c def c (c (? . 2) q angle)) q (2368 . 3)) ((c def c (c (? . 2) q symbol?)) q (5729 . 3)) ((c form c (c (? . 0) q let*)) q (27335 . 2)) ((c def c (c (? . 4) q >)) q (15713 . 5)) ((c def c (c (? . 0) q make-rectangular)) q (31174 . 4)) ((c def c (c (? . 2) q char-whitespace?)) q (9361 . 3)) ((c def c (c (? . 0) q image=?)) q (39954 . 4)) ((c def c (c (? . 1) q range)) q (50560 . 5)) ((c def c (c (? . 1) q int->string)) q (52882 . 3)) ((c def c (c (? . 0) q sinh)) q (32351 . 3)) ((c def c (c (? . 0) q list)) q (34358 . 3)) ((c form c (c (? . 3) q check-range)) q (60018 . 2)) ((c def c (c (? . 1) q rational?)) q (47383 . 3)) ((c def c (c (? . 0) q abs)) q (29515 . 3)) ((c def c (c (? . 4) q char-lower-case?)) q (22791 . 3)) ((c form c (c (? . 3) q define)) q (59162 . 2)) ((c def c (c (? . 1) q eq?)) q (55704 . 4)) ((c form c (c (? . 4) q ..)) q (13510 . 2)) ((c def c (c (? . 3) q hash-ref)) q (76407 . 4)) ((c def c (c (? . 3) q make-immutable-hash)) q (77285 . 2)) ((c def c (c (? . 2) q assq)) q (5874 . 4)) ((c def c (c (? . 2) q gcd)) q (3219 . 4)) ((c def c (c (? . 2) q >)) q (2051 . 5)) ((c def c (c (? . 1) q image?)) q (55469 . 3)) ((c def c (c (? . 3) q char-downcase)) q (67967 . 3)) ((c def c (c (? . 2) q boolean?)) q (5437 . 3)) ((c def c (c (? . 2) q rest)) q (7976 . 3)) ((c form c (c (? . 4) q define)) q (13830 . 2)) ((c def c (c (? . 3) q char-ci<?)) q (67586 . 5)) ((c def c (c (? . 3) q list?)) q (65992 . 3)) ((c form c (c (? . 4) q check-error)) q (14651 . 3)) ((c def c (c (? . 4) q fifth)) q (20549 . 3)) ((c def c (c (? . 4) q eof-object?)) q (26550 . 3)) ((c def c (c (? . 4) q string>=?)) q (25936 . 5)) ((c def c (c (? . 2) q first)) q (6935 . 3)) ((c def c (c (? . 1) q >)) q (44783 . 5)) ((c def c (c (? . 1) q error)) q (56015 . 3)) ((c def c (c (? . 0) q char-ci=?)) q (36105 . 5)) ((c form c (c (? . 2) q ......)) q (118 . 2)) ((c form c (c (? . 1) q let*)) q (42892 . 2)) ((c def c (c (? . 1) q char-downcase)) q (51834 . 3)) ((c def c (c (? . 0) q cadar)) q (33366 . 3)) ((c def c (c (? . 1) q fourth)) q (49693 . 3)) ((c def c (c (? . 1) q string-ci<?)) q (53702 . 5)) ((c def c (c (? . 0) q sin)) q (32303 . 3)) ((c def c (c (? . 0) q inexact?)) q (30695 . 3)) ((c def c (c (? . 2) q integer-sqrt)) q (3525 . 3)) ((c def c (c (? . 3) q real-part)) q (63313 . 3)) ((c def c (c (? . 3) q cddr)) q (65258 . 3)) ((c def c (c (? . 1) q member?)) q (50198 . 4)) ((c def c (c (? . 1) q string-ci<=?)) q (53598 . 5)) ((c def c (c (? . 1) q /)) q (56299 . 4)) ((c def c (c (? . 2) q integer?)) q (3584 . 3)) ((c def c (c (? . 4) q struct?)) q (27047 . 3)) ((c def c (c (? . 4) q cadr)) q (19906 . 3)) ((c def c (c (? . 0) q sort)) q (42404 . 4)) ((c def c (c (? . 1) q sqrt)) q (47891 . 3)) ((c def c (c (? . 2) q *)) q (1439 . 5)) ((c def c (c (? . 3) q char-upcase)) q (68140 . 3)) ((c def c (c (? . 1) q string->symbol)) q (53411 . 3)) ((c def c (c (? . 1) q string-upper-case?)) q (54602 . 3)) ((c def c (c (? . 3) q quotient)) q (63129 . 4)) ((c def c (c (? . 3) q cddar)) q (65162 . 3)) ((c def c (c (? . 2) q string<?)) q (12074 . 5)) ((c def c (c (? . 0) q =)) q (29247 . 5)) ((c form c (c (? . 0) q .....)) q (27205 . 2)) ((c def c (c (? . 1) q remove)) q (50667 . 4)) ((c def c (c (? . 0) q string->symbol)) q (37968 . 3)) ((c def c (c (? . 2) q real-part)) q (4706 . 3)) ((c def c (c (? . 0) q reverse)) q (35339 . 3)) ((c def c (c (? . 4) q boolean?)) q (19099 . 3)) ((c def c (c (? . 2) q string-alphabetic?)) q (10711 . 3)) ((c def c (c (? . 4) q char-upper-case?)) q (22962 . 3)) ((c def c (c (? . 3) q pi)) q (63055 . 2)) ((c def c (c (? . 1) q memf)) q (57499 . 4)) ((c def c (c (? . 4) q modulo)) q (17758 . 4)) ((c def c (c (? . 1) q cdddr)) q (49238 . 3)) ((c def c (c (? . 2) q acos)) q (2270 . 3)) ((c def c (c (? . 0) q assq)) q (33141 . 4)) ((c form c (c (? . 3) q time)) q (59136 . 2)) ((c def c (c (? . 4) q *)) q (15101 . 5)) ((c def c (c (? . 4) q eighth)) q (20448 . 3)) ((c def c (c (? . 3) q third)) q (66972 . 3)) ((c def c (c (? . 3) q hash-update)) q (76904 . 5)) ((c def c (c (? . 4) q symbol=?)) q (19316 . 4)) ((c def c (c (? . 4) q char<?)) q (23177 . 5)) ((c form c (c (? . 1) q check-member-of)) q (44077 . 2)) ((c def c (c (? . 3) q hash-for-each)) q (76144 . 4)) ((c def c (c (? . 3) q denominator)) q (61418 . 3)) ((c def c (c (? . 4) q max)) q (17624 . 4)) ((c def c (c (? . 4) q even?)) q (16550 . 3)) ((c def c (c (? . 1) q -)) q (44444 . 4)) ((c def c (c (? . 2) q integer->char)) q (3461 . 3)) ((c def c (c (? . 3) q positive?)) q (63073 . 3)) ((c def c (c (? . 3) q memq?)) q (66333 . 4)) ((c def c (c (? . 2) q char>=?)) q (9699 . 5)) ((c def c (c (? . 0) q sqr)) q (32400 . 3)) ((c def c (c (? . 4) q string)) q (24062 . 3)) ((c def c (c (? . 3) q random)) q (63205 . 3)) ((c def c (c (? . 1) q struct?)) q (56144 . 3)) ((c def c (c (? . 2) q exp)) q (3053 . 3)) ((c def c (c (? . 0) q string-alphabetic?)) q (38027 . 3)) ((c def c (c (? . 4) q integer-sqrt)) q (17187 . 3)) ((c def c (c (? . 2) q positive?)) q (4466 . 3)) ((c def c (c (? . 2) q char-ci>?)) q (8980 . 5)) ((c form c (c (? . 1) q let)) q (42947 . 2)) ((c def c (c (? . 3) q string-contains?)) q (70248 . 4)) ((c def c (c (? . 0) q string-length)) q (38896 . 3)) ((c def c (c (? . 0) q argmax)) q (41172 . 4)) ((c def c (c (? . 3) q exact->inexact)) q (61548 . 3)) ((c def c (c (? . 2) q even?)) q (2888 . 3)) ((c def c (c (? . 2) q string-length)) q (11580 . 3)) ((c def c (c (? . 4) q char-numeric?)) q (22852 . 3)) ((c def c (c (? . 2) q cons?)) q (6735 . 3)) ((c def c (c (? . 4) q symbol?)) q (19391 . 3)) ((c form c (c (? . 1) q check-random)) q (43829 . 2)) ((c def c (c (? . 4) q ceiling)) q (16176 . 3)) ((c def c (c (? . 0) q explode)) q (37251 . 3)) ((c def c (c (? . 1) q identity)) q (56095 . 3)) ((c form c (c (? . 0) q or)) q (28278 . 2)) ((c def c (c (? . 2) q string-append)) q (10776 . 3)) ((c def c (c (? . 0) q min)) q (31318 . 4)) ((c def c (c (? . 0) q exact->inexact)) q (30230 . 3)) ((c def c (c (? . 1) q string-ref)) q (54521 . 4)) ((c def c (c (? . 3) q hash-remove)) q (76561 . 4)) ((c def c (c (? . 3) q implode)) q (68964 . 3)) ((c def c (c (? . 4) q fourth)) q (20645 . 3)) ((c def c (c (? . 3) q sub1)) q (63815 . 3)) ((c def c (c (? . 4) q string-numeric?)) q (25362 . 3)) ((c def c (c (? . 4) q number?)) q (17947 . 3)) ((c def c (c (? . 3) q build-list)) q (73219 . 4)) ((c def c (c (? . 1) q number->string)) q (46958 . 3)) ((c def c (c (? . 2) q fifth)) q (6887 . 3)) ((c def c (c (? . 0) q cdar)) q (33700 . 3)) ((c def c (c (? . 3) q symbol->string)) q (64202 . 3)) ((c def c (c (? . 3) q sqr)) q (63718 . 3)) ((c def c (c (? . 4) q magnitude)) q (17424 . 3)) ((c def c (c (? . 1) q string-lower-case?)) q (54394 . 3)) ((c def c (c (? . 3) q make-immutable-hasheq)) q (77335 . 2)) ((c def c (c (? . 0) q integer-sqrt)) q (30814 . 3)) ((c def c (c (? . 2) q list-ref)) q (7215 . 4)) ((c def c (c (? . 3) q rest)) q (66729 . 3)) ((c def c (c (? . 2) q string-ci>?)) q (11253 . 5)) ((c def c (c (? . 4) q string<=?)) q (25635 . 5)) ((c def c (c (? . 2) q not)) q (5543 . 3)) ((c def c (c (? . 4) q char>=?)) q (23361 . 5)) ((c def c (c (? . 4) q make-string)) q (23898 . 4)) ((c def c (c (? . 3) q hash-copy)) q (75879 . 3)) ((c def c (c (? . 3) q caar)) q (64734 . 3)) ((c def c (c (? . 0) q caadr)) q (33271 . 3)) ((c def c (c (? . 3) q char-whitespace?)) q (68253 . 3)) ((c form c (c (? . 3) q begin)) q (58277 . 2)) ((c def c (c (? . 3) q hash-set)) q (76720 . 5)) ((c def c (c (? . 4) q eof)) q (26524 . 2)) ((c def c (c (? . 2) q lcm)) q (3638 . 4)) ((c def c (c (? . 4) q posn?)) q (22091 . 3)) ((c def c (c (? . 2) q false?)) q (5491 . 3)) ((c def c (c (? . 1) q symbol?)) q (48461 . 3)) ((c def c (c (? . 0) q string-ci=?)) q (38362 . 5)) ((c def c (c (? . 0) q remainder)) q (32098 . 4)) ((c def c (c (? . 0) q quotient)) q (31811 . 4)) ((c def c (c (? . 0) q equal?)) q (40329 . 4)) ((c def c (c (? . 4) q char-alphabetic?)) q (22199 . 3)) ((c def c (c (? . 0) q char>=?)) q (37015 . 5)) ((c form c (c (? . 4) q .....)) q (13543 . 2)) ((c def c (c (? . 1) q pi)) q (47180 . 2)) ((c def c (c (? . 3) q =~)) q (71654 . 5)) ((c def c (c (? . 2) q symbol->string)) q (5595 . 3)) ((c def c (c (? . 2) q remainder)) q (4809 . 4)) ((c def c (c (? . 1) q string-ci>?)) q (54012 . 5)) ((c def c (c (? . 1) q list->string)) q (52939 . 3)) ((c def c (c (? . 2) q memq)) q (7511 . 4)) ((c def c (c (? . 3) q make-polar)) q (62421 . 4)) ((c def c (c (? . 1) q integer?)) q (46316 . 3)) ((c def c (c (? . 1) q symbol->string)) q (48327 . 3)) ((c def c (c (? . 4) q exp)) q (16715 . 3)) ((c def c (c (? . 2) q eof)) q (12862 . 2)) ((c form c (c (? . 3) q require)) q (60084 . 2)) ((c def c (c (? . 2) q format)) q (9997 . 4)) ((c def c (c (? . 2) q cdddr)) q (6528 . 3)) ((c def c (c (? . 3) q atan)) q (61072 . 3)) ((c def c (c (? . 0) q log)) q (31003 . 3)) ((c def c (c (? . 3) q list*)) q (65833 . 4)) ((c def c (c (? . 3) q char>=?)) q (68591 . 5)) ((c def c (c (? . 3) q string>=?)) q (71166 . 5)) ((c def c (c (? . 3) q posn-y)) q (67136 . 3)) ((c def c (c (? . 2) q sgn)) q (4935 . 3)) ((c def c (c (? . 0) q error)) q (40572 . 3)) ((c def c (c (? . 1) q eof-object?)) q (55647 . 3)) ((c def c (c (? . 4) q asin)) q (16078 . 3)) ((c def c (c (? . 3) q char>?)) q (68684 . 5)) ((c def c (c (? . 2) q number?)) q (4285 . 3)) ((c def c (c (? . 4) q memq?)) q (21242 . 4)) ((c def c (c (? . 1) q <=)) q (44602 . 5)) ((c def c (c (? . 1) q list?)) q (49998 . 3)) ((c def c (c (? . 1) q magnitude)) q (46494 . 3)) ((c def c (c (? . 2) q cdr)) q (6623 . 3)) ((c def c (c (? . 3) q current-seconds)) q (61377 . 2)) ((c def c (c (? . 3) q zero?)) q (63912 . 3)) ((c def c (c (? . 1) q foldr)) q (57212 . 5)) ((c def c (c (? . 1) q first)) q (49645 . 3)) ((c def c (c (? . 2) q sqr)) q (5111 . 3)) ((c form c (c (? . 1) q define-struct)) q (43382 . 2)) ((c def c (c (? . 1) q make-posn)) q (51026 . 4)) ((c def c (c (? . 4) q string=?)) q (25836 . 5)) ((c def c (c (? . 3) q posn)) q (72818 . 2)) ((c def c (c (? . 3) q int->string)) q (69015 . 3)) ((c def c (c (? . 1) q string-contains?)) q (54115 . 4)) ((c def c (c (? . 3) q build-vector)) q (75032 . 4)) ((c def c (c (? . 2) q rational?)) q (4651 . 3)) ((c def c (c (? . 0) q list*)) q (34410 . 4)) ((c def c (c (? . 3) q char-ci>?)) q (67872 . 5)) ((c def c (c (? . 0) q list->string)) q (37496 . 3)) ((c def c (c (? . 0) q cadr)) q (33511 . 3)) ((c def c (c (? . 2) q string)) q (10400 . 3)) ((c def c (c (? . 3) q equal?)) q (71957 . 4)) ((c def c (c (? . 0) q list-ref)) q (34482 . 4)) ((c form c (c (? . 2) q ..)) q (72 . 2)) ((c def c (c (? . 4) q /)) q (15354 . 5)) ((c def c (c (? . 1) q round)) q (47618 . 3)) ((c def c (c (? . 0) q string-ci>=?)) q (38465 . 5)) ((c def c (c (? . 2) q append)) q (5782 . 5)) ((c def c (c (? . 4) q empty?)) q (20497 . 3)) ((c def c (c (? . 4) q cdr)) q (20285 . 3)) ((c def c (c (? . 3) q make-posn)) q (67020 . 4)) ((c def c (c (? . 1) q cos)) q (45405 . 3)) ((c def c (c (? . 3) q list->string)) q (69072 . 3)) ((c def c (c (? . 3) q integer->char)) q (62068 . 3)) ((c def c (c (? . 4) q caar)) q (19714 . 3)) ((c def c (c (? . 2) q empty)) q (0 . 2)) ((c def c (c (? . 0) q posn-y)) q (35699 . 3)) ((c def c (c (? . 1) q inexact->exact)) q (46079 . 3)) ((c def c (c (? . 1) q real-part)) q (47438 . 3)) ((c def c (c (? . 3) q imag-part)) q (61902 . 3)) ((c def c (c (? . 4) q string-ci<?)) q (24605 . 5)) ((c def c (c (? . 0) q imag-part)) q (30584 . 3)) ((c def c (c (? . 0) q <=)) q (29159 . 5)) ((c def c (c (? . 3) q string=?)) q (71066 . 5)) ((c def c (c (? . 2) q eq?)) q (12945 . 4)) ((c def c (c (? . 3) q <=)) q (60477 . 5)) ((c def c (c (? . 2) q char-ci<?)) q (8694 . 5)) ((c def c (c (? . 2) q negative?)) q (4170 . 3)) ((c def c (c (? . 2) q cddr)) q (6576 . 3)) ((c def c (c (? . 4) q false?)) q (19153 . 3)) ((c def c (c (? . 3) q hash-eqv?)) q (76091 . 3)) ((c def c (c (? . 3) q true)) q (57968 . 2)) ((c def c (c (? . 1) q list*)) q (49853 . 4)) ((c def c (c (? . 0) q char-alphabetic?)) q (35853 . 3)) ((c def c (c (? . 0) q asin)) q (29705 . 3)) ((c form c (c (? . 1) q ....)) q (42595 . 2)) ((c def c (c (? . 1) q min)) q (46761 . 4)) ((c def c (c (? . 1) q gcd)) q (45951 . 4)) ((c def c (c (? . 0) q *)) q (40754 . 3)) ((c def c (c (? . 2) q substring)) q (12528 . 5)) ((c def c (c (? . 3) q first)) q (65625 . 3)) ((c def c (c (? . 2) q explode)) q (9935 . 3)) ((c def c (c (? . 2) q car)) q (6291 . 3)) ((c def c (c (? . 4) q make-polar)) q (17476 . 4)) ((c def c (c (? . 1) q caadr)) q (48714 . 3)) ((c def c (c (? . 3) q symbol?)) q (64336 . 3)) ((c def c (c (? . 3) q exp)) q (61660 . 3)) ((c def c (c (? . 0) q int->string)) q (37439 . 3)) ((c def c (c (? . 3) q make-immutable-hasheqv)) q (77387 . 2)) ((c def c (c (? . 4) q char->integer)) q (22142 . 3)) ((c def c (c (? . 0) q string-ref)) q (39078 . 4)) ((c def c (c (? . 4) q cddr)) q (20238 . 3)) ((c def c (c (? . 0) q string>?)) q (39691 . 5)) ((c def c (c (? . 1) q atan)) q (45197 . 3)) ((c def c (c (? . 3) q char->integer)) q (67372 . 3)) ((c def c (c (? . 3) q foldr)) q (73660 . 5)) ((c def c (c (? . 0) q compose)) q (41494 . 4)) ((c def c (c (? . 2) q char-ci=?)) q (8789 . 5)) ((c form c (c (? . 3) q check-random)) q (59704 . 2)) ((c form c (c (? . 2) q if)) q (599 . 2)) ((c def c (c (? . 0) q string-lower-case?)) q (38951 . 3)) ((c def c (c (? . 3) q read)) q (74638 . 2)) ((c def c (c (? . 2) q char-upper-case?)) q (9300 . 3)) ((c def c (c (? . 4) q exit)) q (26971 . 2)) ((c def c (c (? . 1) q map)) q (57407 . 4)) ((c form c (c (? . 0) q check-expect)) q (28331 . 2)) ((c def c (c (? . 2) q atan)) q (2465 . 3)) ((c def c (c (? . 1) q char-ci=?)) q (51548 . 5)) ((c def c (c (? . 0) q cadddr)) q (33414 . 3)) ((c def c (c (? . 3) q replicate)) q (69210 . 4)) ((c def c (c (? . 0) q exp)) q (30342 . 3)) ((c def c (c (? . 2) q seventh)) q (8121 . 3)) ((c def c (c (? . 1) q acos)) q (45002 . 3)) ((c def c (c (? . 1) q string-ci=?)) q (53805 . 5)) ((c def c (c (? . 1) q complex?)) q (45297 . 3)) ((c def c (c (? . 0) q third)) q (35535 . 3)) ((c def c (c (? . 0) q even?)) q (30177 . 3)) ((c form c (c (? . 0) q unquote)) q (27643 . 2)) ((c def c (c (? . 3) q cdadr)) q (65067 . 3)) ((c def c (c (? . 4) q image?)) q (26372 . 3)) ((c def c (c (? . 4) q =~)) q (26424 . 5)) ((c def c (c (? . 1) q =~)) q (55521 . 5)) ((c def c (c (? . 4) q first)) q (20597 . 3)) ((c def c (c (? . 1) q string-copy)) q (54198 . 3)) ((c def c (c (? . 1) q cddr)) q (49286 . 3)) ((c def c (c (? . 3) q assq)) q (64556 . 4)) ((c def c (c (? . 4) q char=?)) q (23269 . 5)) ((c def c (c (? . 3) q pretty-print)) q (74470 . 3)) ((c def c (c (? . 3) q quicksort)) q (74192 . 4)) ((c def c (c (? . 4) q eqv?)) q (26849 . 4)) ((c def c (c (? . 4) q sgn)) q (18597 . 3)) ((c def c (c (? . 3) q caddr)) q (64878 . 3)) ((c def c (c (? . 2) q member?)) q (7439 . 4)) ((c def c (c (? . 0) q char?)) q (37200 . 3)) ((c def c (c (? . 3) q argmin)) q (73141 . 4)) ((c def c (c (? . 2) q random)) q (4598 . 3)) ((c def c (c (? . 1) q =)) q (44690 . 5)) ((c def c (c (? . 4) q log)) q (17376 . 3)) ((c def c (c (? . 2) q caddr)) q (6196 . 3)) ((c def c (c (? . 0) q number->string)) q (31515 . 3)) ((c def c (c (? . 0) q string-ci<=?)) q (38155 . 5)) ((c def c (c (? . 3) q angle)) q (60975 . 3)) ((c def c (c (? . 3) q hash?)) q (77112 . 3)) ((c def c (c (? . 3) q string->number)) q (69469 . 3)) ((c def c (c (? . 4) q char<=?)) q (23084 . 5)) ((c form c (c (? . 1) q letrec)) q (42835 . 2)) ((c def c (c (? . 3) q caadr)) q (64686 . 3)) ((c def c (c (? . 0) q exit)) q (40625 . 2)) ((c def c (c (? . 0) q foldr)) q (41769 . 5)) ((c def c (c (? . 2) q conjugate)) q (2619 . 3)) ((c def c (c (? . 2) q round)) q (4886 . 3)) ((c form c (c (? . 1) q check-satisfied)) q (43884 . 2)) ((c def c (c (? . 1) q exact->inexact)) q (45673 . 3)) ((c def c (c (? . 3) q newline)) q (74440 . 2)) ((c def c (c (? . 2) q make-posn)) q (8267 . 4)) ((c def c (c (? . 0) q eof)) q (40178 . 2)) ((c def c (c (? . 4) q cdadr)) q (20047 . 3)) ((c def c (c (? . 0) q cons)) q (33936 . 4)) ((c def c (c (? . 2) q ceiling)) q (2514 . 3)) ((c def c (c (? . 3) q round)) q (63493 . 3)) ((c def c (c (? . 4) q random)) q (18260 . 3)) ((c def c (c (? . 3) q eof)) q (71806 . 2)) ((c def c (c (? . 4) q string-ref)) q (25424 . 4)) ((c def c (c (? . 2) q quotient)) q (4522 . 4)) ((c def c (c (? . 4) q error)) q (26918 . 3)) ((c def c (c (? . 0) q cosh)) q (30010 . 3)) ((c def c (c (? . 0) q char-lower-case?)) q (36445 . 3)) ((c def c (c (? . 3) q list->vector)) q (75119 . 3)) ((c form c (c (? . 3) q recur)) q (58484 . 2)) ((c form c (c (? . 4) q check-satisfied)) q (14541 . 2)) ((c form c (c (? . 2) q cond)) q (435 . 5)) ((c def c (c (? . 2) q current-seconds)) q (2770 . 2)) ((c def c (c (? . 1) q string-ci>=?)) q (53908 . 5)) ((c def c (c (? . 3) q cons?)) q (65425 . 3)) ((c def c (c (? . 2) q make-list)) q (7288 . 4)) ((c def c (c (? . 4) q range)) q (21463 . 5)) ((c def c (c (? . 4) q char-ci>=?)) q (22546 . 5)) ((c form c (c (? . 1) q ...)) q (42584 . 2)) ((c def c (c (? . 2) q make-string)) q (10236 . 4)) ((c def c (c (? . 3) q write)) q (74987 . 3)) ((c form c (c (? . 1) q check-within)) q (43932 . 2)) ((c def c (c (? . 4) q make-rectangular)) q (17547 . 4)) ((c def c (c (? . 2) q null?)) q (7750 . 3)) ((c def c (c (? . 3) q cosh)) q (61328 . 3)) ((c def c (c (? . 0) q identity)) q (40652 . 3)) ((c form c (c (? . 3) q let)) q (59082 . 2)) ((c form c (c (? . 0) q define-struct)) q (27896 . 2)) ((c form c (c (? . 1) q local)) q (42789 . 2)) ((c def c (c (? . 1) q cdr)) q (49333 . 3)) ((c def c (c (? . 2) q list->string)) q (10180 . 3)) ((c def c (c (? . 3) q sixth)) q (66924 . 3)) ((c def c (c (? . 4) q real-part)) q (18368 . 3)) ((c form c (c (? . 4) q cond)) q (14097 . 5)) ((c def c (c (? . 1) q list-ref)) q (49925 . 4)) ((c def c (c (? . 1) q make-polar)) q (46546 . 4)) ((c def c (c (? . 1) q number?)) q (47017 . 3)) ((c def c (c (? . 1) q equal~?)) q (55843 . 5)) ((c def c (c (? . 4) q exact->inexact)) q (16603 . 3)) ((c def c (c (? . 1) q string-whitespace?)) q (54667 . 3)) ((c def c (c (? . 0) q member)) q (34684 . 4)) ((c def c (c (? . 3) q make-hash)) q (77160 . 2)) ((c def c (c (? . 3) q =)) q (60565 . 5)) ((c def c (c (? . 2) q number->string)) q (4226 . 3)) ((c def c (c (? . 4) q list)) q (20753 . 3)) ((c def c (c (? . 4) q caddr)) q (19858 . 3)) ((c def c (c (? . 0) q symbol->string)) q (32884 . 3)) ((c def c (c (? . 3) q >)) q (60658 . 5)) ((c def c (c (? . 2) q cddar)) q (6480 . 3)) ((c def c (c (? . 0) q car)) q (33558 . 3)) ((c def c (c (? . 4) q number->string)) q (17888 . 3)) ((c def c (c (? . 0) q string-append)) q (38092 . 3)) ((c def c (c (? . 3) q floor)) q (61777 . 3)) ((c def c (c (? . 3) q box?)) q (75716 . 3)) ((c def c (c (? . 1) q foldl)) q (57114 . 5)) ((c def c (c (? . 1) q string=?)) q (54933 . 5)) ((c def c (c (? . 2) q replicate)) q (10318 . 4)) ((c form c (c (? . 2) q check-error)) q (989 . 3)) ((c def c (c (? . 0) q expt)) q (30390 . 4)) ((c def c (c (? . 3) q acos)) q (60877 . 3)) ((c def c (c (? . 3) q ceiling)) q (61121 . 3)) ((c def c (c (? . 1) q modulo)) q (46828 . 4)) ((c def c (c (? . 1) q lcm)) q (46370 . 4)) ((c form c (c (? . 1) q check-error)) q (43994 . 3)) ((c def c (c (? . 3) q string-ci<?)) q (69835 . 5)) ((c def c (c (? . 1) q string-append)) q (53535 . 3)) ((c def c (c (? . 1) q cons)) q (49379 . 4)) ((c def c (c (? . 2) q symbol=?)) q (5654 . 4)) ((c def c (c (? . 1) q string-numeric?)) q (54459 . 3)) ((c form c (c (? . 1) q ......)) q (42620 . 2)) ((c def c (c (? . 4) q gcd)) q (16881 . 4)) ((c def c (c (? . 2) q string-ith)) q (11495 . 4)) ((c def c (c (? . 4) q car)) q (19953 . 3)) ((c def c (c (? . 3) q cdar)) q (65115 . 3)) ((c form c (c (? . 1) q if)) q (43604 . 2)) ((c def c (c (? . 3) q string-whitespace?)) q (70800 . 3)) ((c def c (c (? . 3) q eqv?)) q (72131 . 4)) ((c def c (c (? . 1) q equal?)) q (55772 . 4)) ((c def c (c (? . 3) q char-lower-case?)) q (68021 . 3)) ((c def c (c (? . 0) q true)) q (27123 . 2)) ((c def c (c (? . 2) q +)) q (1530 . 5)) ((c def c (c (? . 2) q reverse)) q (8023 . 3)) ((c def c (c (? . 3) q string-ci>?)) q (70145 . 5)) ((c def c (c (? . 1) q andmap)) q (56402 . 4)) ((c form c (c (? . 4) q define-struct)) q (13996 . 2)) ((c def c (c (? . 1) q max)) q (46694 . 4)) ((c def c (c (? . 2) q caaar)) q (5956 . 3)) ((c def c (c (? . 0) q string<?)) q (39390 . 5)) ((c def c (c (? . 3) q memf)) q (73947 . 4)) ((c def c (c (? . 3) q andmap)) q (72850 . 4)) ((c form c (c (? . 1) q lambda)) q (42634 . 2)) ((c def c (c (? . 4) q substring)) q (26190 . 5)) ((c def c (c (? . 3) q cdr)) q (65305 . 3)) ((c def c (c (? . 3) q make-list)) q (66041 . 4)) ((c def c (c (? . 2) q >=)) q (2138 . 5)) ((c def c (c (? . 3) q cdddr)) q (65210 . 3)) ((c def c (c (? . 4) q expt)) q (16763 . 4)) ((c def c (c (? . 2) q string-ci=?)) q (11046 . 5)) ((c def c (c (? . 0) q sixth)) q (35487 . 3)) ((c def c (c (? . 4) q char-ci<?)) q (22356 . 5)) ((c form c (c (? . 3) q lambda)) q (58077 . 2)) ((c def c (c (? . 1) q list)) q (49801 . 3)) ((c def c (c (? . 1) q implode)) q (52831 . 3)) ((c def c (c (? . 1) q seventh)) q (50880 . 3)) ((c def c (c (? . 2) q cons)) q (6669 . 4)) ((c def c (c (? . 3) q build-string)) q (73302 . 4)) ((c def c (c (? . 2) q sin)) q (5014 . 3)) ((c def c (c (? . 1) q even?)) q (45620 . 3)) ((c def c (c (? . 3) q format)) q (68889 . 4)) ((c def c (c (? . 0) q eighth)) q (34053 . 3)) ((c def c (c (? . 4) q cadar)) q (19761 . 3)) ((c def c (c (? . 2) q <)) q (1783 . 5)) ((c def c (c (? . 3) q filter)) q (73469 . 4)) ((c def c (c (? . 3) q char?)) q (68776 . 3)) ((c def c (c (? . 1) q caaar)) q (48666 . 3)) ((c def c (c (? . 4) q char-downcase)) q (22737 . 3)) ((c def c (c (? . 4) q replicate)) q (23980 . 4)) ((c def c (c (? . 2) q posn-y)) q (8383 . 3)) ((c def c (c (? . 0) q char-ci<=?)) q (35914 . 5)) ((c form c (c (? . 0) q time)) q (27444 . 2)) ((c def c (c (? . 0) q posn?)) q (35745 . 3)) ((c def c (c (? . 2) q sqrt)) q (5159 . 3)) ((c def c (c (? . 0) q complex?)) q (29854 . 3)) ((c form c (c (? . 0) q if)) q (28161 . 2)) ((c def c (c (? . 2) q image=?)) q (12638 . 4)) ((c def c (c (? . 4) q sinh)) q (18724 . 3)) ((c def c (c (? . 1) q char-upcase)) q (52007 . 3)) ((c def c (c (? . 3) q string-length)) q (70472 . 3)) ((c def c (c (? . 1) q asin)) q (45148 . 3)) ((c def c (c (? . 4) q min)) q (17691 . 4)) ((c def c (c (? . 4) q abs)) q (15888 . 3)) ((c def c (c (? . 2) q eof-object?)) q (12888 . 3)) ((c def c (c (? . 0) q cdaar)) q (33604 . 3)) ((c def c (c (? . 4) q inexact->exact)) q (17009 . 3)) ((c def c (c (? . 3) q number->string)) q (62833 . 3)) ((c def c (c (? . 1) q replicate)) q (53077 . 4)) ((c def c (c (? . 3) q number?)) q (62892 . 3)) ((c def c (c (? . 0) q range)) q (35117 . 5)) ((c def c (c (? . 1) q +)) q (56248 . 3)) ((c def c (c (? . 3) q car)) q (64973 . 3)) ((c def c (c (? . 1) q explode)) q (52694 . 3)) ((c def c (c (? . 0) q string-ith)) q (38811 . 4)) ((c def c (c (? . 4) q cdddr)) q (20190 . 3)) ((c def c (c (? . 0) q caar)) q (33319 . 3)) ((c def c (c (? . 0) q cos)) q (29962 . 3)) ((c def c (c (? . 3) q exit)) q (72253 . 2)) ((c def c (c (? . 1) q ormap)) q (57602 . 4)) ((c def c (c (? . 2) q exit)) q (13309 . 2)) ((c def c (c (? . 1) q <)) q (44515 . 5)) ((c def c (c (? . 1) q null?)) q (50509 . 3)) ((c def c (c (? . 4) q string-lower-case?)) q (25297 . 3)) ((c def c (c (? . 0) q string->number)) q (37893 . 3)) ((c def c (c (? . 2) q cdar)) q (6433 . 3)) ((c def c (c (? . 3) q remainder)) q (63416 . 4)) ((c form c (c (? . 0) q let)) q (27390 . 2)) ((c def c (c (? . 1) q for-each)) q (57310 . 4)) ((c def c (c (? . 0) q exact?)) q (30289 . 3)) ((c def c (c (? . 4) q real?)) q (18420 . 3)) ((c def c (c (? . 0) q for-each)) q (41867 . 4)) ((c def c (c (? . 2) q modulo)) q (4096 . 4)) ((c def c (c (? . 1) q string<=?)) q (54732 . 5)) ((c def c (c (? . 2) q string-ci<?)) q (10943 . 5)) ((c form c (c (? . 1) q or)) q (43721 . 2)) ((c def c (c (? . 1) q cddar)) q (49190 . 3)) ((c def c (c (? . 3) q memv)) q (66403 . 4)) ((c def c (c (? . 3) q sin)) q (63621 . 3)) ((c def c (c (? . 4) q false)) q (13485 . 2)) ((c def c (c (? . 1) q make-list)) q (50047 . 4)) ((c def c (c (? . 3) q real?)) q (63365 . 3)) ((c form c (c (? . 4) q check-expect)) q (14431 . 2)) ((c def c (c (? . 4) q sin)) q (18676 . 3)) ((c def c (c (? . 2) q make-polar)) q (3814 . 4)) ((c def c (c (? . 3) q make-hasheq)) q (77200 . 2)) ((c def c (c (? . 1) q posn-x)) q (51096 . 3)) ((c def c (c (? . 4) q quotient)) q (18184 . 4)) ((c def c (c (? . 1) q odd?)) q (47128 . 3)) ((c def c (c (? . 0) q +)) q (40805 . 3)) ((c def c (c (? . 4) q identity)) q (26998 . 3)) ((c def c (c (? . 0) q cons?)) q (34002 . 3)) ((c def c (c (? . 0) q cdddr)) q (33795 . 3)) ((c def c (c (? . 0) q replicate)) q (37634 . 4)) ((c def c (c (? . 3) q caaar)) q (64638 . 3)) ((c def c (c (? . 1) q memv)) q (50409 . 4)) ((c def c (c (? . 2) q string->int)) q (10455 . 3)) ((c def c (c (? . 3) q null)) q (66483 . 2)) ((c def c (c (? . 0) q string-upper-case?)) q (39159 . 3)) ((c def c (c (? . 1) q tan)) q (47989 . 3)) ((c def c (c (? . 3) q vector-set!)) q (75528 . 5)) ((c def c (c (? . 0) q posn)) q (40927 . 2)) ((c def c (c (? . 4) q second)) q (21734 . 3)) ((c def c (c (? . 3) q magnitude)) q (62369 . 3)) ((c def c (c (? . 4) q seventh)) q (21783 . 3)) ((c def c (c (? . 0) q char<?)) q (36831 . 5)) ((c def c (c (? . 0) q format)) q (37313 . 4)) ((c def c (c (? . 3) q hash-ref!)) q (76476 . 5)) ((c def c (c (? . 0) q substring)) q (39844 . 5)) ((c def c (c (? . 0) q boolean?)) q (32726 . 3)) ((c form c (c (? . 3) q shared)) q (58429 . 2)) ((c def c (c (? . 1) q >=)) q (44870 . 5)) ((c def c (c (? . 2) q cdadr)) q (6385 . 3)) ((c def c (c (? . 3) q procedure?)) q (74138 . 3)) ((c def c (c (? . 1) q cadddr)) q (48857 . 3)) ((c def c (c (? . 2) q posn-x)) q (8337 . 3)) ((c def c (c (? . 1) q substring)) q (55287 . 5)) ((c def c (c (? . 0) q memq)) q (34827 . 4)) ((c def c (c (? . 4) q positive?)) q (18128 . 3)) ((c def c (c (? . 2) q asin)) q (2416 . 3)) ((c def c (c (? . 0) q gcd)) q (30508 . 4)) ((c def c (c (? . 3) q boolean=?)) q (63964 . 4)) ((c def c (c (? . 0) q symbol=?)) q (32943 . 4)) ((c def c (c (? . 0) q atan)) q (29754 . 3)) ((c def c (c (? . 3) q string-ci>=?)) q (70041 . 5)) ((c def c (c (? . 4) q sixth)) q (21833 . 3)) ((c def c (c (? . 3) q numerator)) q (62945 . 3)) ((c form c (c (? . 2) q ...)) q (82 . 2)) ((c def c (c (? . 1) q apply)) q (56491 . 5)) ((c def c (c (? . 0) q build-string)) q (41411 . 4)) ((c def c (c (? . 3) q string-append)) q (69668 . 3)) ((c def c (c (? . 3) q for-each)) q (73758 . 4)) ((c def c (c (? . 3) q assoc)) q (64459 . 4)) ((c def c (c (? . 1) q sort)) q (57847 . 4)) ((c def c (c (? . 4) q cons)) q (20331 . 4)) ((c def c (c (? . 1) q sqr)) q (47843 . 3)) ((c def c (c (? . 1) q ceiling)) q (45246 . 3)) ((c def c (c (? . 2) q inexact->exact)) q (3347 . 3)) ((c def c (c (? . 3) q +)) q (72696 . 3)) ((c def c (c (? . 2) q cosh)) q (2721 . 3)) ((c def c (c (? . 3) q with-output-to-string)) q (74921 . 3)) ((c def c (c (? . 4) q string-ci>?)) q (24915 . 5)) ((c form c (c (? . 4) q quote)) q (13600 . 2)) ((c def c (c (? . 0) q floor)) q (30459 . 3)) ((c def c (c (? . 3) q explode)) q (68827 . 3)) ((c def c (c (? . 4) q string->list)) q (24174 . 3)) ((c form c (c (? . 4) q unquote)) q (13743 . 2)) ((c def c (c (? . 1) q memq)) q (50270 . 4)) ((c def c (c (? . 3) q string-ci=?)) q (69938 . 5)) ((c def c (c (? . 3) q even?)) q (61495 . 3)) ((c def c (c (? . 4) q inexact?)) q (17068 . 3)) ((c form c (c (? . 0) q check-random)) q (28386 . 2)) ((c form c (c (? . 2) q and)) q (662 . 2)) ((c form c (c (? . 2) q check-expect)) q (769 . 2)) ((c def c (c (? . 2) q zero?)) q (5305 . 3)) ((c def c (c (? . 2) q =~)) q (12762 . 5)) ((c form c (c (? . 4) q and)) q (14324 . 2)) ((c def c (c (? . 1) q procedure?)) q (57690 . 3)) ((c def c (c (? . 1) q sgn)) q (47667 . 3)) ((c def c (c (? . 1) q char?)) q (52643 . 3)) ((c def c (c (? . 0) q andmap)) q (40959 . 4)) ((c def c (c (? . 0) q cddr)) q (33843 . 3)) ((c def c (c (? . 2) q string?)) q (12475 . 3)) ((c def c (c (? . 3) q apply)) q (72939 . 5)) ((c def c (c (? . 3) q second)) q (66825 . 3)) ((c form c (c (? . 1) q unquote-splicing)) q (43344 . 2)) ((c def c (c (? . 3) q unbox)) q (75834 . 3)) ((c def c (c (? . 0) q fourth)) q (34250 . 3)) ((c def c (c (? . 0) q implode)) q (37388 . 3)) ((c def c (c (? . 3) q make-hasheqv)) q (77242 . 2)) ((c def c (c (? . 2) q int->string)) q (10123 . 3)) ((c def c (c (? . 3) q asin)) q (61023 . 3)) ((c def c (c (? . 0) q memf)) q (42056 . 4)) ((c def c (c (? . 4) q null)) q (21392 . 2)) ((c def c (c (? . 0) q tan)) q (32546 . 3)) ((c def c (c (? . 4) q -)) q (15283 . 4)) ((c form c (c (? . 2) q check-satisfied)) q (879 . 2)) ((c def c (c (? . 1) q cdadr)) q (49095 . 3)) ((c form c (c (? . 2) q .....)) q (105 . 2)) ((c def c (c (? . 4) q sqr)) q (18773 . 3)) ((c form c (c (? . 2) q check-random)) q (824 . 2)) ((c def c (c (? . 4) q boolean=?)) q (19019 . 4)) ((c def c (c (? . 0) q symbol?)) q (33018 . 3)) ((c def c (c (? . 1) q char-upper-case?)) q (52059 . 3)) ((c def c (c (? . 1) q false?)) q (48223 . 3)) ((c def c (c (? . 3) q char-ci=?)) q (67681 . 5)) ((c def c (c (? . 3) q negative?)) q (62777 . 3)) ((c def c (c (? . 0) q char-ci>=?)) q (36200 . 5)) ((c def c (c (? . 0) q string<=?)) q (39289 . 5)) ((c def c (c (? . 4) q tan)) q (18919 . 3)) ((c def c (c (? . 3) q cadar)) q (64781 . 3)) ((c def c (c (? . 1) q char-lower-case?)) q (51888 . 3)) ((c def c (c (? . 0) q real?)) q (32047 . 3)) ((c def c (c (? . 4) q null?)) q (21412 . 3)) ((c def c (c (? . 0) q list?)) q (34555 . 3)) ((c def c (c (? . 1) q string->list)) q (53271 . 3)) ((c def c (c (? . 0) q integer->char)) q (30750 . 3)) ((c def c (c (? . 3) q rational?)) q (63258 . 3)) ((c def c (c (? . 0) q numerator)) q (31627 . 3)) ((c def c (c (? . 4) q eq?)) q (26607 . 4)) ((c def c (c (? . 1) q empty)) q (42502 . 2)) ((c def c (c (? . 2) q odd?)) q (4396 . 3)) ((c def c (c (? . 4) q string<?)) q (25736 . 5)) ((c def c (c (? . 3) q symbol=?)) q (64261 . 4)) ((c form c (c (? . 2) q check-within)) q (927 . 2)) ((c def c (c (? . 3) q eighth)) q (65476 . 3)) ((c form c (c (? . 4) q ...)) q (13520 . 2)) ((c def c (c (? . 2) q =)) q (1958 . 5)) ((c def c (c (? . 3) q hash-equal?)) q (76035 . 3)) ((c form c (c (? . 0) q and)) q (28224 . 2)) ((c def c (c (? . 1) q string-ith)) q (54254 . 4)) ((c def c (c (? . 2) q second)) q (8072 . 3)) ((c def c (c (? . 3) q string->int)) q (69347 . 3)) ((c def c (c (? . 1) q caddr)) q (48906 . 3)) ((c def c (c (? . 3) q cadr)) q (64926 . 3)) ((c def c (c (? . 0) q pi)) q (31737 . 2)) ((c def c (c (? . 2) q string-contains?)) q (11356 . 4)) ((c form c (c (? . 0) q letrec)) q (27278 . 2)) ((c def c (c (? . 2) q sinh)) q (5062 . 3)) ((c def c (c (? . 4) q string->number)) q (24239 . 3)) ((c def c (c (? . 2) q char?)) q (9884 . 3)) ((c def c (c (? . 2) q string->symbol)) q (10652 . 3)) ((c def c (c (? . 4) q member)) q (21030 . 4)) ((c def c (c (? . 2) q memv)) q (7650 . 4)) ((c def c (c (? . 3) q hash-set!)) q (76815 . 5)) ((c def c (c (? . 4) q cos)) q (16335 . 3)) ((c def c (c (? . 3) q vector-length)) q (75396 . 3)) ((c def c (c (? . 2) q make-rectangular)) q (3885 . 4)) ((c def c (c (? . 1) q char-ci>?)) q (51739 . 5)) ((c def c (c (? . 1) q sub1)) q (47940 . 3)) ((c def c (c (? . 3) q image=?)) q (71530 . 4)) ((c def c (c (? . 2) q false)) q (47 . 2)) ((c def c (c (? . 3) q char<=?)) q (68314 . 5)) ((c def c (c (? . 2) q cadr)) q (6244 . 3)) ((c def c (c (? . 4) q cosh)) q (16383 . 3)) ((c def c (c (? . 1) q filter)) q (57021 . 4)) ((c def c (c (? . 4) q append)) q (19444 . 5)) ((c def c (c (? . 3) q string-numeric?)) q (70592 . 3)) ((c form c (c (? . 1) q and)) q (43667 . 2)) ((c form c (c (? . 2) q ....)) q (93 . 2)) ((c def c (c (? . 3) q complex?)) q (61172 . 3)) ((c def c (c (? . 1) q cons?)) q (49445 . 3)) ((c def c (c (? . 3) q conjugate)) q (61226 . 3)) ((c def c (c (? . 4) q odd?)) q (18058 . 3)) ((c def c (c (? . 0) q angle)) q (29657 . 3)) ((c def c (c (? . 0) q false?)) q (32780 . 3)) ((c def c (c (? . 1) q build-string)) q (56854 . 4)) ((c def c (c (? . 2) q sixth)) q (8171 . 3)) ((c def c (c (? . 3) q fifth)) q (65577 . 3)) ((c def c (c (? . 3) q length)) q (65722 . 3)) ((c def c (c (? . 3) q >=)) q (60745 . 5)) ((c def c (c (? . 3) q vector->list)) q (75327 . 3)) ((c def c (c (? . 3) q memq)) q (66264 . 4)) ((c form c (c (? . 3) q ...)) q (58027 . 2)) ((c def c (c (? . 2) q cdaar)) q (6337 . 3)) ((c form c (c (? . 0) q quote)) q (27500 . 2)) ((c def c (c (? . 1) q inexact?)) q (46138 . 3)) ((c form c (c (? . 0) q ..)) q (27172 . 2)) ((c def c (c (? . 4) q exact?)) q (16662 . 3)) ((c def c (c (? . 3) q char-upper-case?)) q (68192 . 3)) ((c def c (c (? . 1) q rest)) q (50735 . 3)) ((c def c (c (? . 3) q max)) q (62569 . 4)) ((c def c (c (? . 1) q negative?)) q (46902 . 3)) ((c def c (c (? . 0) q build-list)) q (41328 . 4)) ((c def c (c (? . 2) q empty?)) q (6835 . 3)) ((c def c (c (? . 2) q cadar)) q (6099 . 3)) ((c form c (c (? . 1) q quasiquote)) q (43224 . 2)) ((c def c (c (? . 0) q acos)) q (29559 . 3)) ((c def c (c (? . 1) q char-numeric?)) q (51949 . 3)) ((c def c (c (? . 0) q zero?)) q (32594 . 3)) ((c def c (c (? . 4) q string->symbol)) q (24314 . 3)) ((c def c (c (? . 1) q true)) q (42525 . 2)) ((c def c (c (? . 0) q rest)) q (35292 . 3)) ((c def c (c (? . 3) q string-copy)) q (70331 . 3)) ((c def c (c (? . 1) q exp)) q (45785 . 3)) ((c def c (c (? . 3) q posn?)) q (67182 . 3)) ((c def c (c (? . 4) q int->string)) q (23785 . 3)) ((c def c (c (? . 1) q char=?)) q (52366 . 5)) ((c def c (c (? . 1) q numerator)) q (47070 . 3)) ((c def c (c (? . 2) q eighth)) q (6786 . 3)) ((c def c (c (? . 0) q null?)) q (35066 . 3)) ((c def c (c (? . 2) q add1)) q (2319 . 3)) ((c def c (c (? . 0) q string-ci>?)) q (38569 . 5)) ((c def c (c (? . 3) q min)) q (62636 . 4)) ((c def c (c (? . 4) q rest)) q (21638 . 3)) ((c def c (c (? . 4) q member?)) q (21101 . 4)) ((c form c (c (? . 1) q ..)) q (42574 . 2)) ((c def c (c (? . 3) q string-upper-case?)) q (70735 . 3)) ((c def c (c (? . 1) q expt)) q (45833 . 4)) ((c def c (c (? . 3) q log)) q (62321 . 3)) ((c form c (c (? . 2) q check-member-of)) q (1072 . 2)) ((c def c (c (? . 2) q string=?)) q (12174 . 5)) ((c def c (c (? . 2) q char-downcase)) q (9075 . 3)) ((c def c (c (? . 3) q integer?)) q (62191 . 3)) ((c def c (c (? . 1) q not)) q (48275 . 3)) ((c def c (c (? . 4) q symbol->string)) q (19257 . 3)) ((c form c (c (? . 2) q quote)) q (313 . 2)) ((c def c (c (? . 3) q sleep)) q (72457 . 3)) ((c def c (c (? . 0) q member?)) q (34755 . 4)) ((c def c (c (? . 1) q cdar)) q (49143 . 3)) ((c def c (c (? . 2) q length)) q (7032 . 3)) ((c def c (c (? . 0) q make-list)) q (34604 . 4)) ((c def c (c (? . 3) q vector?)) q (75621 . 3)) ((c def c (c (? . 3) q sqrt)) q (63766 . 3)) ((c def c (c (? . 2) q equal?)) q (13013 . 4)) ((c def c (c (? . 4) q integer->char)) q (17123 . 3)) ((c def c (c (? . 3) q set-posn-x!)) q (67233 . 4)) ((c form c (c (? . 2) q define-struct)) q (334 . 2)) ((c def c (c (? . 4) q floor)) q (16832 . 3)) ((c def c (c (? . 4) q explode)) q (23597 . 3)) ((c def c (c (? . 4) q <=)) q (15532 . 5)) ((c form c (c (? . 0) q check-within)) q (28489 . 2)) ((c def c (c (? . 1) q current-seconds)) q (45502 . 2)) ((c def c (c (? . 0) q -)) q (29001 . 4)) ((c def c (c (? . 0) q >)) q (29340 . 5)) ((c def c (c (? . 0) q char=?)) q (36923 . 5)) ((c def c (c (? . 4) q char-ci=?)) q (22451 . 5)) ((c def c (c (? . 2) q real?)) q (4758 . 3)) ((c def c (c (? . 0) q equal~?)) q (40400 . 5)) ((c form c (c (? . 3) q cond)) q (59315 . 5)) ((c def c (c (? . 1) q sinh)) q (47794 . 3)) ((c def c (c (? . 3) q printf)) q (74567 . 4)) ((c def c (c (? . 1) q image=?)) q (55397 . 4)) ((c def c (c (? . 0) q apply)) q (41048 . 5)) ((c form c (c (? . 2) q define)) q (132 . 2)) ((c form c (c (? . 4) q check-range)) q (14800 . 2)) ((c def c (c (? . 1) q conjugate)) q (45351 . 3)) ((c def c (c (? . 1) q cdaar)) q (49047 . 3)) ((c def c (c (? . 2) q char=?)) q (9607 . 5)) ((c def c (c (? . 4) q make-list)) q (20950 . 4)) ((c def c (c (? . 2) q remove)) q (7908 . 4)) ((c form c (c (? . 3) q ....)) q (58038 . 2)) ((c def c (c (? . 0) q lcm)) q (30927 . 4)) ((c form c (c (? . 0) q unquote-splicing)) q (27692 . 2)) ((c def c (c (? . 3) q integer-sqrt)) q (62132 . 3)) ((c def c (c (? . 2) q string-numeric?)) q (11700 . 3)) ((c form c (c (? . 0) q ....)) q (27193 . 2)) ((c def c (c (? . 1) q sixth)) q (50930 . 3)) ((c def c (c (? . 2) q char-numeric?)) q (9190 . 3)) ((c form c (c (? . 4) q ......)) q (13556 . 2)) ((c def c (c (? . 1) q add1)) q (45051 . 3)) ((c def c (c (? . 1) q second)) q (50831 . 3)) ((c def c (c (? . 0) q odd?)) q (31685 . 3)) ((c def c (c (? . 3) q print)) q (74522 . 3)) ((c form c (c (? . 3) q and)) q (59542 . 2)) ((c form c (c (? . 3) q ..)) q (58017 . 2)) ((c def c (c (? . 2) q denominator)) q (2811 . 3)) ((c def c (c (? . 2) q fourth)) q (6983 . 3)) ((c form c (c (? . 0) q check-error)) q (28551 . 3)) ((c def c (c (? . 3) q cos)) q (61280 . 3)) ((c def c (c (? . 3) q boolean?)) q (64044 . 3)) ((c def c (c (? . 4) q make-posn)) q (21929 . 4)) ((c def c (c (? . 3) q vector-ref)) q (75456 . 4)) ((c def c (c (? . 2) q string-upper-case?)) q (11843 . 3)) ((c def c (c (? . 3) q gensym)) q (72324 . 2)) ((c def c (c (? . 3) q ormap)) q (74050 . 4)) ((c def c (c (? . 4) q char-ci>?)) q (22642 . 5)) ((c def c (c (? . 1) q false)) q (42549 . 2)) ((c def c (c (? . 4) q caadr)) q (19666 . 3)) ((c def c (c (? . 1) q char>?)) q (52551 . 5)) ((c def c (c (? . 3) q box)) q (75671 . 3)) ((c def c (c (? . 3) q hash-has-key?)) q (76236 . 4)) ((c def c (c (? . 0) q char->integer)) q (35796 . 3)) ((c def c (c (? . 3) q hash-eq?)) q (75983 . 3)) ((c def c (c (? . 4) q integer?)) q (17246 . 3)) ((c def c (c (? . 3) q inexact->exact)) q (61954 . 3)) ((c def c (c (? . 3) q hash-count)) q (75929 . 3)) ((c form c (c (? . 1) q unquote)) q (43295 . 2)) ((c def c (c (? . 1) q empty?)) q (49545 . 3)) ((c form c (c (? . 1) q time)) q (43001 . 2)) ((c def c (c (? . 1) q caar)) q (48762 . 3)) ((c def c (c (? . 3) q modulo)) q (62703 . 4)) ((c def c (c (? . 2) q expt)) q (3101 . 4)) ((c def c (c (? . 2) q string<=?)) q (11973 . 5)) ((c form c (c (? . 1) q .....)) q (42607 . 2)) ((c form c (c (? . 4) q ....)) q (13531 . 2)) ((c def c (c (? . 3) q char=?)) q (68499 . 5)) ((c def c (c (? . 1) q quicksort)) q (57744 . 4)) ((c def c (c (? . 0) q not)) q (32832 . 3)) ((c def c (c (? . 0) q filter)) q (41578 . 4)) ((c def c (c (? . 0) q <)) q (29072 . 5)) ((c def c (c (? . 1) q string-alphabetic?)) q (53470 . 3)) ((c def c (c (? . 4) q implode)) q (23734 . 3)) ((c def c (c (? . 1) q positive?)) q (47198 . 3)) ((c def c (c (? . 2) q inexact?)) q (3406 . 3)) ((c def c (c (? . 4) q add1)) q (15981 . 3)) ((c form c (c (? . 2) q require)) q (1204 . 2)) ((c def c (c (? . 1) q string>?)) q (55134 . 5)) ((c def c (c (? . 3) q seventh)) q (66874 . 3)) ((c def c (c (? . 1) q symbol=?)) q (48386 . 4)) ((c def c (c (? . 4) q char-whitespace?)) q (23023 . 3)) ((c def c (c (? . 1) q reverse)) q (50782 . 3)) ((c def c (c (? . 4) q assq)) q (19536 . 4)) ((c def c (c (? . 3) q cadddr)) q (64829 . 3)) ((c def c (c (? . 2) q string->number)) q (10577 . 3)) ((c def c (c (? . 3) q hash-map)) q (76316 . 4)) ((c def c (c (? . 3) q with-output-to-file)) q (74837 . 4)) ((c form c (c (? . 0) q cond)) q (27997 . 5)) ((c def c (c (? . 0) q string-ci<?)) q (38259 . 5)) ((c def c (c (? . 0) q char-numeric?)) q (36506 . 3)) ((c def c (c (? . 0) q positive?)) q (31755 . 3)) ((c def c (c (? . 4) q posn-x)) q (21999 . 3)) ((c def c (c (? . 2) q numerator)) q (4338 . 3)) ((c def c (c (? . 2) q char-lower-case?)) q (9129 . 3)) ((c def c (c (? . 4) q current-seconds)) q (16432 . 2)) ((c def c (c (? . 1) q quotient)) q (47254 . 4)) ((c def c (c (? . 3) q image?)) q (71602 . 3)) ((c def c (c (? . 0) q cdadr)) q (33652 . 3)) ((c form c (c (? . 3) q case)) q (58602 . 2)) ((c form c (c (? . 1) q check-range)) q (44143 . 2)) ((c form c (c (? . 3) q check-expect)) q (59649 . 2)) ((c def c (c (? . 2) q char-upcase)) q (9248 . 3)) ((c form c (c (? . 0) q quasiquote)) q (27572 . 2)) ((c def c (c (? . 3) q equal~?)) q (72028 . 5)) ((c def c (c (? . 3) q void)) q (72568 . 2)) ((c def c (c (? . 2) q null)) q (7730 . 2)) ((c def c (c (? . 0) q memq?)) q (34896 . 4)) ((c def c (c (? . 2) q boolean=?)) q (5357 . 4)) ((c def c (c (? . 3) q identity)) q (72356 . 3)) ((c def c (c (? . 3) q char-ci<=?)) q (67490 . 5))))
value
empty : empty?
value
true : boolean?
value
false : boolean?
syntax
..
syntax
...
syntax
....
syntax
.....
syntax
......
syntax
(define (name variable variable ...) expression)
syntax
(define name expression)
syntax
(define name (lambda (variable variable ...) expression))
syntax
’name
syntax
(quote name)
syntax
(define-struct structure-name (field-name ...))
syntax
(name expression expression ...)
syntax
(cond [question-expression answer-expression] ...)
(cond [question-expression answer-expression]
      ...
      [else answer-expression])
syntax
(if test-expression then-expression else-expression)
syntax
(and expression expression expression ...)
syntax
(or expression expression expression ...)
syntax
(check-expect expression expected-expression)
syntax
(check-random expression expected-expression)
syntax
(check-satisfied expression predicate)
syntax
(check-within expression expected-expression delta)
syntax
(check-error expression expected-error-message)
(check-error expression)
syntax
(check-member-of expression expression expression ...)
syntax
(check-range expression low-expression high-expression)
syntax
(require string)
syntax
(require module-name)
syntax
(require (lib string string ...))
syntax
(require (planet string (string string number number)))
syntax
(require (planet id))
syntax
(require (planet string))
procedure
(* x y z ...) -> number
  x : number
  y : number
  z : number
procedure
(+ x y z ...) -> number
  x : number
  y : number
  z : number
procedure
(- x y ...) -> number
  x : number
  y : number
procedure
(/ x y z ...) -> number
  x : number
  y : number
  z : number
procedure
(< x y z ...) -> boolean?
  x : real
  y : real
  z : real
procedure
(<= x y z ...) -> boolean?
  x : real
  y : real
  z : real
procedure
(= x y z ...) -> boolean?
  x : number
  y : number
  z : number
procedure
(> x y z ...) -> boolean?
  x : real
  y : real
  z : real
procedure
(>= x y z ...) -> boolean?
  x : real
  y : real
  z : real
procedure
(abs x) -> real
  x : real
procedure
(acos x) -> number
  x : number
procedure
(add1 x) -> number
  x : number
procedure
(angle x) -> real
  x : number
procedure
(asin x) -> number
  x : number
procedure
(atan x) -> number
  x : number
procedure
(ceiling x) -> integer
  x : real
procedure
(complex? x) -> boolean?
  x : any/c
procedure
(conjugate x) -> number
  x : number
procedure
(cos x) -> number
  x : number
procedure
(cosh x) -> number
  x : number
procedure
(current-seconds) -> integer
procedure
(denominator x) -> integer
  x : rational?
value
e : real
procedure
(even? x) -> boolean?
  x : integer
procedure
(exact->inexact x) -> number
  x : number
procedure
(exact? x) -> boolean?
  x : number
procedure
(exp x) -> number
  x : number
procedure
(expt x y) -> number
  x : number
  y : number
procedure
(floor x) -> integer
  x : real
procedure
(gcd x y ...) -> integer
  x : integer
  y : integer
procedure
(imag-part x) -> real
  x : number
procedure
(inexact->exact x) -> number
  x : number
procedure
(inexact? x) -> boolean?
  x : number
procedure
(integer->char x) -> char
  x : exact-integer?
procedure
(integer-sqrt x) -> complex
  x : integer
procedure
(integer? x) -> boolean?
  x : any/c
procedure
(lcm x y ...) -> integer
  x : integer
  y : integer
procedure
(log x) -> number
  x : number
procedure
(magnitude x) -> real
  x : number
procedure
(make-polar x y) -> number
  x : real
  y : real
procedure
(make-rectangular x y) -> number
  x : real
  y : real
procedure
(max x y ...) -> real
  x : real
  y : real
procedure
(min x y ...) -> real
  x : real
  y : real
procedure
(modulo x y) -> integer
  x : integer
  y : integer
procedure
(negative? x) -> boolean?
  x : number
procedure
(number->string x) -> string
  x : number
procedure
(number? n) -> boolean?
  n : any/c
procedure
(numerator x) -> integer
  x : rational?
procedure
(odd? x) -> boolean?
  x : integer
value
pi : real
procedure
(positive? x) -> boolean?
  x : number
procedure
(quotient x y) -> integer
  x : integer
  y : integer
procedure
(random x) -> natural
  x : natural
procedure
(rational? x) -> boolean?
  x : any/c
procedure
(real-part x) -> real
  x : number
procedure
(real? x) -> boolean?
  x : any/c
procedure
(remainder x y) -> integer
  x : integer
  y : integer
procedure
(round x) -> integer
  x : real
procedure
(sgn x) -> (union 1 #i1.0 0 #i0.0 -1 #i-1.0)
  x : real
procedure
(sin x) -> number
  x : number
procedure
(sinh x) -> number
  x : number
procedure
(sqr x) -> number
  x : number
procedure
(sqrt x) -> number
  x : number
procedure
(sub1 x) -> number
  x : number
procedure
(tan x) -> number
  x : number
procedure
(zero? x) -> boolean?
  x : number
procedure
(boolean=? x y) -> boolean?
  x : boolean?
  y : boolean?
procedure
(boolean? x) -> boolean?
  x : any/c
procedure
(false? x) -> boolean?
  x : any/c
procedure
(not x) -> boolean?
  x : boolean?
procedure
(symbol->string x) -> string
  x : symbol
procedure
(symbol=? x y) -> boolean?
  x : symbol
  y : symbol
procedure
(symbol? x) -> boolean?
  x : any/c
procedure
(append x y z ...) -> list?
  x : list?
  y : list?
  z : list?
procedure
(assq x l) -> (union false cons?)
  x : any/c
  l : list?
procedure
(caaar x) -> any/c
  x : list?
procedure
(caadr x) -> any/c
  x : list?
procedure
(caar x) -> any/c
  x : list?
procedure
(cadar x) -> any/c
  x : list?
procedure
(cadddr x) -> any/c
  x : list?
procedure
(caddr x) -> any/c
  x : list?
procedure
(cadr x) -> any/c
  x : list?
procedure
(car x) -> any/c
  x : cons?
procedure
(cdaar x) -> any/c
  x : list?
procedure
(cdadr x) -> any/c
  x : list?
procedure
(cdar x) -> list?
  x : list?
procedure
(cddar x) -> any/c
  x : list?
procedure
(cdddr x) -> any/c
  x : list?
procedure
(cddr x) -> list?
  x : list?
procedure
(cdr x) -> any/c
  x : cons?
procedure
(cons x y) -> list?
  x : any/x
  y : list?
procedure
(cons? x) -> boolean?
  x : any/c
procedure
(eighth x) -> any/c
  x : list?
procedure
(empty? x) -> boolean?
  x : any/c
procedure
(fifth x) -> any/c
  x : list?
procedure
(first x) -> any/c
  x : cons?
procedure
(fourth x) -> any/c
  x : list?
procedure
(length l) -> natural-number?
  l : list?
procedure
(list x ...) -> list?
  x : any/c
procedure
(list* x ... l) -> list?
  x : any/c
  l : list?
procedure
(list-ref x i) -> any/c
  x : list?
  i : natural?
procedure
(make-list i x) -> list?
  i : natural-number
  x : any/c
procedure
(member x l) -> boolean?
  x : any/c
  l : list?
procedure
(member? x l) -> boolean?
  x : any/c
  l : list?
procedure
(memq x l) -> boolean?
  x : any/c
  l : list?
procedure
(memq? x l) -> boolean?
  x : any/c
  l : list?
procedure
(memv x l) -> (or/c false list)
  x : any/c
  l : list?
value
null : list
procedure
(null? x) -> boolean?
  x : any/c
procedure
(range start end step) -> list?
  start : number
  end : number
  step : number
procedure
(remove x l) -> list?
  x : any/c
  l : list?
procedure
(rest x) -> any/c
  x : cons?
procedure
(reverse l) -> list
  l : list?
procedure
(second x) -> any/c
  x : list?
procedure
(seventh x) -> any/c
  x : list?
procedure
(sixth x) -> any/c
  x : list?
procedure
(third x) -> any/c
  x : list?
procedure
(make-posn x y) -> posn
  x : any/c
  y : any/c
procedure
(posn-x p) -> any
  p : posn
procedure
(posn-y p) -> any
  p : posn
procedure
(posn? x) -> boolean?
  x : any/c
procedure
(char->integer c) -> integer
  c : char
procedure
(char-alphabetic? c) -> boolean?
  c : char
procedure
(char-ci<=? c d e ...) -> boolean?
  c : char
  d : char
  e : char
procedure
(char-ci<? c d e ...) -> boolean?
  c : char
  d : char
  e : char
procedure
(char-ci=? c d e ...) -> boolean?
  c : char
  d : char
  e : char
procedure
(char-ci>=? c d e ...) -> boolean?
  c : char
  d : char
  e : char
procedure
(char-ci>? c d e ...) -> boolean?
  c : char
  d : char
  e : char
procedure
(char-downcase c) -> char
  c : char
procedure
(char-lower-case? c) -> boolean?
  c : char
procedure
(char-numeric? c) -> boolean?
  c : char
procedure
(char-upcase c) -> char
  c : char
procedure
(char-upper-case? c) -> boolean?
  c : char
procedure
(char-whitespace? c) -> boolean?
  c : char
procedure
(char<=? c d e ...) -> boolean?
  c : char
  d : char
  e : char
procedure
(char<? x d e ...) -> boolean?
  x : char
  d : char
  e : char
procedure
(char=? c d e ...) -> boolean?
  c : char
  d : char
  e : char
procedure
(char>=? c d e ...) -> boolean?
  c : char
  d : char
  e : char
procedure
(char>? c d e ...) -> boolean?
  c : char
  d : char
  e : char
procedure
(char? x) -> boolean?
  x : any/c
procedure
(explode s) -> (listof string)
  s : string
procedure
(format f x ...) -> string
  f : string
  x : any/c
procedure
(implode l) -> string
  l : list?
procedure
(int->string i) -> string
  i : integer
procedure
(list->string l) -> string
  l : list?
procedure
(make-string i c) -> string
  i : natural-number
  c : char
procedure
(replicate i s) -> string
  i : natural-number
  s : string
procedure
(string c ...) -> string?
  c : char
procedure
(string->int s) -> integer
  s : string
procedure
(string->list s) -> (listof char)
  s : string
procedure
(string->number s) -> (union number false)
  s : string
procedure
(string->symbol s) -> symbol
  s : string
procedure
(string-alphabetic? s) -> boolean?
  s : string
procedure
(string-append s ...) -> string
  s : string
procedure
(string-ci<=? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string-ci<? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string-ci=? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string-ci>=? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string-ci>? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string-contains? s t) -> boolean?
  s : string
  t : string
procedure
(string-copy s) -> string
  s : string
procedure
(string-ith s i) -> 1string?
  s : string
  i : natural-number
procedure
(string-length s) -> nat
  s : string
procedure
(string-lower-case? s) -> boolean?
  s : string
procedure
(string-numeric? s) -> boolean?
  s : string
procedure
(string-ref s i) -> char
  s : string
  i : natural-number
procedure
(string-upper-case? s) -> boolean?
  s : string
procedure
(string-whitespace? s) -> boolean?
  s : string
procedure
(string<=? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string<? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string=? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string>=? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string>? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string? x) -> boolean?
  x : any/c
procedure
(substring s i j) -> string
  s : string
  i : natural-number
  j : natural-number
procedure
(image=? i j) -> boolean?
  i : image
  j : image
procedure
(image? x) -> boolean?
  x : any/c
procedure
(=~ x y z) -> boolean?
  x : number
  y : number
  z : non-negative-real
value
eof : eof-object?
procedure
(eof-object? x) -> boolean?
  x : any/c
procedure
(eq? x y) -> boolean?
  x : any/c
  y : any/c
procedure
(equal? x y) -> boolean?
  x : any/c
  y : any/c
procedure
(equal~? x y z) -> boolean?
  x : any/c
  y : any/c
  z : non-negative-real
procedure
(eqv? x y) -> boolean?
  x : any/c
  y : any/c
procedure
(error x ...) -> void?
  x : any/c
procedure
(exit) -> void
procedure
(identity x) -> any
  x : any/c
procedure
(struct? x) -> boolean?
  x : any/c
value
empty : empty?
value
true : boolean?
value
false : boolean?
syntax
..
syntax
...
syntax
....
syntax
.....
syntax
......
syntax
’name
syntax
’part
syntax
(quote name)
syntax
(quote part)
syntax
‘name
syntax
‘part
syntax
(quasiquote name)
syntax
(quasiquote part)
syntax
,expression
syntax
(unquote expression)
syntax
,@expression
syntax
(unquote-splicing expression)
syntax
(define (name variable variable ...) expression)
syntax
(define name expression)
syntax
(define name (lambda (variable variable ...) expression))
syntax
(define-struct structure-name (field-name ...))
syntax
(name expression expression ...)
syntax
(cond [question-expression answer-expression] ...)
(cond [question-expression answer-expression]
      ...
      [else answer-expression])
syntax
(if test-expression then-expression else-expression)
syntax
(and expression expression expression ...)
syntax
(or expression expression expression ...)
syntax
(check-expect expression expected-expression)
syntax
(check-random expression expected-expression)
syntax
(check-satisfied expression predicate)
syntax
(check-within expression expected-expression delta)
syntax
(check-error expression expected-error-message)
(check-error expression)
syntax
(check-member-of expression expression expression ...)
syntax
(check-range expression low-expression high-expression)
syntax
(require string)
syntax
(require module-name)
syntax
(require (lib string string ...))
syntax
(require (planet string (string string number number)))
syntax
(require (planet id))
syntax
(require (planet string))
procedure
(* x y z ...) -> number
  x : number
  y : number
  z : number
procedure
(+ x y z ...) -> number
  x : number
  y : number
  z : number
procedure
(- x y ...) -> number
  x : number
  y : number
procedure
(/ x y z ...) -> number
  x : number
  y : number
  z : number
procedure
(< x y z ...) -> boolean?
  x : real
  y : real
  z : real
procedure
(<= x y z ...) -> boolean?
  x : real
  y : real
  z : real
procedure
(= x y z ...) -> boolean?
  x : number
  y : number
  z : number
procedure
(> x y z ...) -> boolean?
  x : real
  y : real
  z : real
procedure
(>= x y z ...) -> boolean?
  x : real
  y : real
  z : real
procedure
(abs x) -> real
  x : real
procedure
(acos x) -> number
  x : number
procedure
(add1 x) -> number
  x : number
procedure
(angle x) -> real
  x : number
procedure
(asin x) -> number
  x : number
procedure
(atan x) -> number
  x : number
procedure
(ceiling x) -> integer
  x : real
procedure
(complex? x) -> boolean?
  x : any/c
procedure
(conjugate x) -> number
  x : number
procedure
(cos x) -> number
  x : number
procedure
(cosh x) -> number
  x : number
procedure
(current-seconds) -> integer
procedure
(denominator x) -> integer
  x : rational?
value
e : real
procedure
(even? x) -> boolean?
  x : integer
procedure
(exact->inexact x) -> number
  x : number
procedure
(exact? x) -> boolean?
  x : number
procedure
(exp x) -> number
  x : number
procedure
(expt x y) -> number
  x : number
  y : number
procedure
(floor x) -> integer
  x : real
procedure
(gcd x y ...) -> integer
  x : integer
  y : integer
procedure
(imag-part x) -> real
  x : number
procedure
(inexact->exact x) -> number
  x : number
procedure
(inexact? x) -> boolean?
  x : number
procedure
(integer->char x) -> char
  x : exact-integer?
procedure
(integer-sqrt x) -> complex
  x : integer
procedure
(integer? x) -> boolean?
  x : any/c
procedure
(lcm x y ...) -> integer
  x : integer
  y : integer
procedure
(log x) -> number
  x : number
procedure
(magnitude x) -> real
  x : number
procedure
(make-polar x y) -> number
  x : real
  y : real
procedure
(make-rectangular x y) -> number
  x : real
  y : real
procedure
(max x y ...) -> real
  x : real
  y : real
procedure
(min x y ...) -> real
  x : real
  y : real
procedure
(modulo x y) -> integer
  x : integer
  y : integer
procedure
(negative? x) -> boolean?
  x : number
procedure
(number->string x) -> string
  x : number
procedure
(number? n) -> boolean?
  n : any/c
procedure
(numerator x) -> integer
  x : rational?
procedure
(odd? x) -> boolean?
  x : integer
value
pi : real
procedure
(positive? x) -> boolean?
  x : number
procedure
(quotient x y) -> integer
  x : integer
  y : integer
procedure
(random x) -> natural
  x : natural
procedure
(rational? x) -> boolean?
  x : any/c
procedure
(real-part x) -> real
  x : number
procedure
(real? x) -> boolean?
  x : any/c
procedure
(remainder x y) -> integer
  x : integer
  y : integer
procedure
(round x) -> integer
  x : real
procedure
(sgn x) -> (union 1 #i1.0 0 #i0.0 -1 #i-1.0)
  x : real
procedure
(sin x) -> number
  x : number
procedure
(sinh x) -> number
  x : number
procedure
(sqr x) -> number
  x : number
procedure
(sqrt x) -> number
  x : number
procedure
(sub1 x) -> number
  x : number
procedure
(tan x) -> number
  x : number
procedure
(zero? x) -> boolean?
  x : number
procedure
(boolean=? x y) -> boolean?
  x : boolean?
  y : boolean?
procedure
(boolean? x) -> boolean?
  x : any/c
procedure
(false? x) -> boolean?
  x : any/c
procedure
(not x) -> boolean?
  x : boolean?
procedure
(symbol->string x) -> string
  x : symbol
procedure
(symbol=? x y) -> boolean?
  x : symbol
  y : symbol
procedure
(symbol? x) -> boolean?
  x : any/c
procedure
(append x y z ...) -> list?
  x : list?
  y : list?
  z : list?
procedure
(assq x l) -> (union false cons?)
  x : any/c
  l : list?
procedure
(caaar x) -> any/c
  x : list?
procedure
(caadr x) -> any/c
  x : list?
procedure
(caar x) -> any/c
  x : list?
procedure
(cadar x) -> any/c
  x : list?
procedure
(cadddr x) -> any/c
  x : list?
procedure
(caddr x) -> any/c
  x : list?
procedure
(cadr x) -> any/c
  x : list?
procedure
(car x) -> any/c
  x : cons?
procedure
(cdaar x) -> any/c
  x : list?
procedure
(cdadr x) -> any/c
  x : list?
procedure
(cdar x) -> list?
  x : list?
procedure
(cddar x) -> any/c
  x : list?
procedure
(cdddr x) -> any/c
  x : list?
procedure
(cddr x) -> list?
  x : list?
procedure
(cdr x) -> any/c
  x : cons?
procedure
(cons x y) -> list?
  x : any/x
  y : list?
procedure
(cons? x) -> boolean?
  x : any/c
procedure
(eighth x) -> any/c
  x : list?
procedure
(empty? x) -> boolean?
  x : any/c
procedure
(fifth x) -> any/c
  x : list?
procedure
(first x) -> any/c
  x : cons?
procedure
(fourth x) -> any/c
  x : list?
procedure
(length l) -> natural-number?
  l : list?
procedure
(list x ...) -> list?
  x : any/c
procedure
(list* x ... l) -> list?
  x : any/c
  l : list?
procedure
(list-ref x i) -> any/c
  x : list?
  i : natural?
procedure
(make-list i x) -> list?
  i : natural-number
  x : any/c
procedure
(member x l) -> boolean?
  x : any/c
  l : list?
procedure
(member? x l) -> boolean?
  x : any/c
  l : list?
procedure
(memq x l) -> boolean?
  x : any/c
  l : list?
procedure
(memq? x l) -> boolean?
  x : any/c
  l : list?
procedure
(memv x l) -> (or/c false list)
  x : any/c
  l : list?
value
null : list
procedure
(null? x) -> boolean?
  x : any/c
procedure
(range start end step) -> list?
  start : number
  end : number
  step : number
procedure
(remove x l) -> list?
  x : any/c
  l : list?
procedure
(rest x) -> any/c
  x : cons?
procedure
(reverse l) -> list
  l : list?
procedure
(second x) -> any/c
  x : list?
procedure
(seventh x) -> any/c
  x : list?
procedure
(sixth x) -> any/c
  x : list?
procedure
(third x) -> any/c
  x : list?
procedure
(make-posn x y) -> posn
  x : any/c
  y : any/c
procedure
(posn-x p) -> any
  p : posn
procedure
(posn-y p) -> any
  p : posn
procedure
(posn? x) -> boolean?
  x : any/c
procedure
(char->integer c) -> integer
  c : char
procedure
(char-alphabetic? c) -> boolean?
  c : char
procedure
(char-ci<=? c d e ...) -> boolean?
  c : char
  d : char
  e : char
procedure
(char-ci<? c d e ...) -> boolean?
  c : char
  d : char
  e : char
procedure
(char-ci=? c d e ...) -> boolean?
  c : char
  d : char
  e : char
procedure
(char-ci>=? c d e ...) -> boolean?
  c : char
  d : char
  e : char
procedure
(char-ci>? c d e ...) -> boolean?
  c : char
  d : char
  e : char
procedure
(char-downcase c) -> char
  c : char
procedure
(char-lower-case? c) -> boolean?
  c : char
procedure
(char-numeric? c) -> boolean?
  c : char
procedure
(char-upcase c) -> char
  c : char
procedure
(char-upper-case? c) -> boolean?
  c : char
procedure
(char-whitespace? c) -> boolean?
  c : char
procedure
(char<=? c d e ...) -> boolean?
  c : char
  d : char
  e : char
procedure
(char<? x d e ...) -> boolean?
  x : char
  d : char
  e : char
procedure
(char=? c d e ...) -> boolean?
  c : char
  d : char
  e : char
procedure
(char>=? c d e ...) -> boolean?
  c : char
  d : char
  e : char
procedure
(char>? c d e ...) -> boolean?
  c : char
  d : char
  e : char
procedure
(char? x) -> boolean?
  x : any/c
procedure
(explode s) -> (listof string)
  s : string
procedure
(format f x ...) -> string
  f : string
  x : any/c
procedure
(implode l) -> string
  l : list?
procedure
(int->string i) -> string
  i : integer
procedure
(list->string l) -> string
  l : list?
procedure
(make-string i c) -> string
  i : natural-number
  c : char
procedure
(replicate i s) -> string
  i : natural-number
  s : string
procedure
(string c ...) -> string?
  c : char
procedure
(string->int s) -> integer
  s : string
procedure
(string->list s) -> (listof char)
  s : string
procedure
(string->number s) -> (union number false)
  s : string
procedure
(string->symbol s) -> symbol
  s : string
procedure
(string-alphabetic? s) -> boolean?
  s : string
procedure
(string-append s ...) -> string
  s : string
procedure
(string-ci<=? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string-ci<? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string-ci=? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string-ci>=? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string-ci>? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string-contains? s t) -> boolean?
  s : string
  t : string
procedure
(string-copy s) -> string
  s : string
procedure
(string-ith s i) -> 1string?
  s : string
  i : natural-number
procedure
(string-length s) -> nat
  s : string
procedure
(string-lower-case? s) -> boolean?
  s : string
procedure
(string-numeric? s) -> boolean?
  s : string
procedure
(string-ref s i) -> char
  s : string
  i : natural-number
procedure
(string-upper-case? s) -> boolean?
  s : string
procedure
(string-whitespace? s) -> boolean?
  s : string
procedure
(string<=? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string<? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string=? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string>=? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string>? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string? x) -> boolean?
  x : any/c
procedure
(substring s i j) -> string
  s : string
  i : natural-number
  j : natural-number
procedure
(image=? i j) -> boolean?
  i : image
  j : image
procedure
(image? x) -> boolean?
  x : any/c
procedure
(=~ x y z) -> boolean?
  x : number
  y : number
  z : non-negative-real
value
eof : eof-object?
procedure
(eof-object? x) -> boolean?
  x : any/c
procedure
(eq? x y) -> boolean?
  x : any/c
  y : any/c
procedure
(equal? x y) -> boolean?
  x : any/c
  y : any/c
procedure
(equal~? x y z) -> boolean?
  x : any/c
  y : any/c
  z : non-negative-real
procedure
(eqv? x y) -> boolean?
  x : any/c
  y : any/c
procedure
(error x ...) -> void?
  x : any/c
procedure
(exit) -> void
procedure
(identity x) -> any
  x : any/c
procedure
(struct? x) -> boolean?
  x : any/c
value
empty : empty?
value
true : boolean?
value
false : boolean?
syntax
..
syntax
...
syntax
....
syntax
.....
syntax
......
syntax
(local [definition ...] expression)
syntax
(letrec ([name expr-for-let] ...) expression)
syntax
(let* ([name expr-for-let] ...) expression)
syntax
(let ([name expr-for-let] ...) expression)
syntax
(time expression)
syntax
’name
syntax
’part
syntax
(quote name)
syntax
(quote part)
syntax
‘name
syntax
‘part
syntax
(quasiquote name)
syntax
(quasiquote part)
syntax
,expression
syntax
(unquote expression)
syntax
,@expression
syntax
(unquote-splicing expression)
syntax
(define (name variable variable ...) expression)
syntax
(define name expression)
syntax
(define name (lambda (variable variable ...) expression))
syntax
(define-struct structure-name (field-name ...))
syntax
(name expression expression ...)
syntax
(cond [question-expression answer-expression] ...)
(cond [question-expression answer-expression]
      ...
      [else answer-expression])
syntax
(if test-expression then-expression else-expression)
syntax
(and expression expression expression ...)
syntax
(or expression expression expression ...)
syntax
(check-expect expression expected-expression)
syntax
(check-random expression expected-expression)
syntax
(check-satisfied expression predicate)
syntax
(check-within expression expected-expression delta)
syntax
(check-error expression expected-error-message)
(check-error expression)
syntax
(check-member-of expression expression expression ...)
syntax
(check-range expression low-expression high-expression)
syntax
(require string)
syntax
(require module-name)
syntax
(require (lib string string ...))
syntax
(require (planet string (string string number number)))
syntax
(require (planet id))
syntax
(require (planet string))
procedure
(- x y ...) -> number
  x : number
  y : number
procedure
(< x y z ...) -> boolean?
  x : real
  y : real
  z : real
procedure
(<= x y z ...) -> boolean?
  x : real
  y : real
  z : real
procedure
(= x y z ...) -> boolean?
  x : number
  y : number
  z : number
procedure
(> x y z ...) -> boolean?
  x : real
  y : real
  z : real
procedure
(>= x y z ...) -> boolean?
  x : real
  y : real
  z : real
procedure
(abs x) -> real
  x : real
procedure
(acos x) -> number
  x : number
procedure
(add1 x) -> number
  x : number
procedure
(angle x) -> real
  x : number
procedure
(asin x) -> number
  x : number
procedure
(atan x) -> number
  x : number
procedure
(ceiling x) -> integer
  x : real
procedure
(complex? x) -> boolean?
  x : any/c
procedure
(conjugate x) -> number
  x : number
procedure
(cos x) -> number
  x : number
procedure
(cosh x) -> number
  x : number
procedure
(current-seconds) -> integer
procedure
(denominator x) -> integer
  x : rational?
value
e : real
procedure
(even? x) -> boolean?
  x : integer
procedure
(exact->inexact x) -> number
  x : number
procedure
(exact? x) -> boolean?
  x : number
procedure
(exp x) -> number
  x : number
procedure
(expt x y) -> number
  x : number
  y : number
procedure
(floor x) -> integer
  x : real
procedure
(gcd x y ...) -> integer
  x : integer
  y : integer
procedure
(imag-part x) -> real
  x : number
procedure
(inexact->exact x) -> number
  x : number
procedure
(inexact? x) -> boolean?
  x : number
procedure
(integer->char x) -> char
  x : exact-integer?
procedure
(integer-sqrt x) -> complex
  x : integer
procedure
(integer? x) -> boolean?
  x : any/c
procedure
(lcm x y ...) -> integer
  x : integer
  y : integer
procedure
(log x) -> number
  x : number
procedure
(magnitude x) -> real
  x : number
procedure
(make-polar x y) -> number
  x : real
  y : real
procedure
(make-rectangular x y) -> number
  x : real
  y : real
procedure
(max x y ...) -> real
  x : real
  y : real
procedure
(min x y ...) -> real
  x : real
  y : real
procedure
(modulo x y) -> integer
  x : integer
  y : integer
procedure
(negative? x) -> boolean?
  x : number
procedure
(number->string x) -> string
  x : number
procedure
(number? n) -> boolean?
  n : any/c
procedure
(numerator x) -> integer
  x : rational?
procedure
(odd? x) -> boolean?
  x : integer
value
pi : real
procedure
(positive? x) -> boolean?
  x : number
procedure
(quotient x y) -> integer
  x : integer
  y : integer
procedure
(random x) -> natural
  x : natural
procedure
(rational? x) -> boolean?
  x : any/c
procedure
(real-part x) -> real
  x : number
procedure
(real? x) -> boolean?
  x : any/c
procedure
(remainder x y) -> integer
  x : integer
  y : integer
procedure
(round x) -> integer
  x : real
procedure
(sgn x) -> (union 1 #i1.0 0 #i0.0 -1 #i-1.0)
  x : real
procedure
(sin x) -> number
  x : number
procedure
(sinh x) -> number
  x : number
procedure
(sqr x) -> number
  x : number
procedure
(sqrt x) -> number
  x : number
procedure
(sub1 x) -> number
  x : number
procedure
(tan x) -> number
  x : number
procedure
(zero? x) -> boolean?
  x : number
procedure
(boolean=? x y) -> boolean?
  x : boolean?
  y : boolean?
procedure
(boolean? x) -> boolean?
  x : any/c
procedure
(false? x) -> boolean?
  x : any/c
procedure
(not x) -> boolean?
  x : boolean?
procedure
(symbol->string x) -> string
  x : symbol
procedure
(symbol=? x y) -> boolean?
  x : symbol
  y : symbol
procedure
(symbol? x) -> boolean?
  x : any/c
procedure
(append l ...) -> (listof any)
  l : (listof any)
procedure
(assq x l) -> (union false cons?)
  x : any/c
  l : list?
procedure
(caaar x) -> any/c
  x : list?
procedure
(caadr x) -> any/c
  x : list?
procedure
(caar x) -> any/c
  x : list?
procedure
(cadar x) -> any/c
  x : list?
procedure
(cadddr x) -> any/c
  x : list?
procedure
(caddr x) -> any/c
  x : list?
procedure
(cadr x) -> any/c
  x : list?
procedure
(car x) -> any/c
  x : cons?
procedure
(cdaar x) -> any/c
  x : list?
procedure
(cdadr x) -> any/c
  x : list?
procedure
(cdar x) -> list?
  x : list?
procedure
(cddar x) -> any/c
  x : list?
procedure
(cdddr x) -> any/c
  x : list?
procedure
(cddr x) -> list?
  x : list?
procedure
(cdr x) -> any/c
  x : cons?
procedure
(cons x y) -> list?
  x : any/x
  y : list?
procedure
(cons? x) -> boolean?
  x : any/c
procedure
(eighth x) -> any/c
  x : list?
procedure
(empty? x) -> boolean?
  x : any/c
procedure
(fifth x) -> any/c
  x : list?
procedure
(first x) -> any/c
  x : cons?
procedure
(fourth x) -> any/c
  x : list?
procedure
(length l) -> natural-number?
  l : list?
procedure
(list x ...) -> list?
  x : any/c
procedure
(list* x ... l) -> list?
  x : any/c
  l : list?
procedure
(list-ref x i) -> any/c
  x : list?
  i : natural?
procedure
(list? x) -> boolean?
  x : any
procedure
(make-list i x) -> list?
  i : natural-number
  x : any/c
procedure
(member x l) -> boolean?
  x : any/c
  l : list?
procedure
(member? x l) -> boolean?
  x : any/c
  l : list?
procedure
(memq x l) -> boolean?
  x : any/c
  l : list?
procedure
(memq? x l) -> boolean?
  x : any/c
  l : list?
procedure
(memv x l) -> (or/c false list)
  x : any/c
  l : list?
value
null : list
procedure
(null? x) -> boolean?
  x : any/c
procedure
(range start end step) -> list?
  start : number
  end : number
  step : number
procedure
(remove x l) -> list?
  x : any/c
  l : list?
procedure
(rest x) -> any/c
  x : cons?
procedure
(reverse l) -> list
  l : list?
procedure
(second x) -> any/c
  x : list?
procedure
(seventh x) -> any/c
  x : list?
procedure
(sixth x) -> any/c
  x : list?
procedure
(third x) -> any/c
  x : list?
procedure
(make-posn x y) -> posn
  x : any/c
  y : any/c
procedure
(posn-x p) -> any
  p : posn
procedure
(posn-y p) -> any
  p : posn
procedure
(posn? x) -> boolean?
  x : any/c
procedure
(char->integer c) -> integer
  c : char
procedure
(char-alphabetic? c) -> boolean?
  c : char
procedure
(char-ci<=? c d e ...) -> boolean?
  c : char
  d : char
  e : char
procedure
(char-ci<? c d e ...) -> boolean?
  c : char
  d : char
  e : char
procedure
(char-ci=? c d e ...) -> boolean?
  c : char
  d : char
  e : char
procedure
(char-ci>=? c d e ...) -> boolean?
  c : char
  d : char
  e : char
procedure
(char-ci>? c d e ...) -> boolean?
  c : char
  d : char
  e : char
procedure
(char-downcase c) -> char
  c : char
procedure
(char-lower-case? c) -> boolean?
  c : char
procedure
(char-numeric? c) -> boolean?
  c : char
procedure
(char-upcase c) -> char
  c : char
procedure
(char-upper-case? c) -> boolean?
  c : char
procedure
(char-whitespace? c) -> boolean?
  c : char
procedure
(char<=? c d e ...) -> boolean?
  c : char
  d : char
  e : char
procedure
(char<? x d e ...) -> boolean?
  x : char
  d : char
  e : char
procedure
(char=? c d e ...) -> boolean?
  c : char
  d : char
  e : char
procedure
(char>=? c d e ...) -> boolean?
  c : char
  d : char
  e : char
procedure
(char>? c d e ...) -> boolean?
  c : char
  d : char
  e : char
procedure
(char? x) -> boolean?
  x : any/c
procedure
(explode s) -> (listof string)
  s : string
procedure
(format f x ...) -> string
  f : string
  x : any/c
procedure
(implode l) -> string
  l : list?
procedure
(int->string i) -> string
  i : integer
procedure
(list->string l) -> string
  l : list?
procedure
(make-string i c) -> string
  i : natural-number
  c : char
procedure
(replicate i s) -> string
  i : natural-number
  s : string
procedure
(string c ...) -> string?
  c : char
procedure
(string->int s) -> integer
  s : string
procedure
(string->list s) -> (listof char)
  s : string
procedure
(string->number s) -> (union number false)
  s : string
procedure
(string->symbol s) -> symbol
  s : string
procedure
(string-alphabetic? s) -> boolean?
  s : string
procedure
(string-append s ...) -> string
  s : string
procedure
(string-ci<=? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string-ci<? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string-ci=? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string-ci>=? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string-ci>? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string-contains? s t) -> boolean?
  s : string
  t : string
procedure
(string-copy s) -> string
  s : string
procedure
(string-ith s i) -> 1string?
  s : string
  i : natural-number
procedure
(string-length s) -> nat
  s : string
procedure
(string-lower-case? s) -> boolean?
  s : string
procedure
(string-numeric? s) -> boolean?
  s : string
procedure
(string-ref s i) -> char
  s : string
  i : natural-number
procedure
(string-upper-case? s) -> boolean?
  s : string
procedure
(string-whitespace? s) -> boolean?
  s : string
procedure
(string<=? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string<? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string=? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string>=? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string>? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string? x) -> boolean?
  x : any/c
procedure
(substring s i j) -> string
  s : string
  i : natural-number
  j : natural-number
procedure
(image=? i j) -> boolean?
  i : image
  j : image
procedure
(image? x) -> boolean?
  x : any/c
procedure
(=~ x y z) -> boolean?
  x : number
  y : number
  z : non-negative-real
value
eof : eof-object?
procedure
(eof-object? x) -> boolean?
  x : any/c
procedure
(eq? x y) -> boolean?
  x : any/c
  y : any/c
procedure
(equal? x y) -> boolean?
  x : any/c
  y : any/c
procedure
(equal~? x y z) -> boolean?
  x : any/c
  y : any/c
  z : non-negative-real
procedure
(eqv? x y) -> boolean?
  x : any/c
  y : any/c
procedure
(error x ...) -> void?
  x : any/c
procedure
(exit) -> void
procedure
(identity x) -> any
  x : any/c
procedure
(struct? x) -> boolean?
  x : any/c
procedure
(* x ...) -> number
  x : number
procedure
(+ x ...) -> number
  x : number
procedure
(/ x y ...) -> number
  x : number
  y : number
procedure
(posn) -> signature
procedure
(andmap p? l) -> boolean
  p? : (X -> boolean)
  l : (listof X)
procedure
(apply f x-1 ... l) -> Y
  f : (X-1 ... X-N -> Y)
  x-1 : X-1
  l : (list X-i+1 ... X-N)
procedure
(argmax f l) -> X
  f : (X -> real)
  l : (listof X)
procedure
(argmin f l) -> X
  f : (X -> real)
  l : (listof X)
procedure
(build-list n f) -> (listof X)
  n : nat
  f : (nat -> X)
procedure
(build-string n f) -> string
  n : nat
  f : (nat -> char)
procedure
(compose f g) -> (X -> Z)
  f : (Y -> Z)
  g : (X -> Y)
procedure
(filter p? l) -> (listof X)
  p? : (X -> boolean)
  l : (listof X)
procedure
(foldl f base l) -> Y
  f : (X Y -> Y)
  base : Y
  l : (listof X)
procedure
(foldr f base l) -> Y
  f : (X Y -> Y)
  base : Y
  l : (listof X)
procedure
(for-each f l ...) -> void?
  f : (any ... -> any)
  l : (listof any)
procedure
(map f l ...) -> (listof Z)
  f : (X ... -> Z)
  l : (listof X)
procedure
(memf p? l) -> (union false (listof X))
  p? : (X -> any)
  l : (listof X)
procedure
(ormap p? l) -> boolean
  p? : (X -> boolean)
  l : (listof X)
procedure
(procedure? x) -> boolean?
  x : any
procedure
(quicksort l comp) -> (listof X)
  l : (listof X)
  comp : (X X -> boolean)
procedure
(sort l comp) -> (listof X)
  l : (listof X)
  comp : (X X -> boolean)
value
empty : empty?
value
true : boolean?
value
false : boolean?
syntax
..
syntax
...
syntax
....
syntax
.....
syntax
......
syntax
(lambda (variable variable ...) expression)
syntax
(λ (variable variable ...) expression)
syntax
(expression expression expression ...)
syntax
(local [definition ...] expression)
syntax
(letrec ([name expr-for-let] ...) expression)
syntax
(let* ([name expr-for-let] ...) expression)
syntax
(let ([name expr-for-let] ...) expression)
syntax
(time expression)
syntax
(define (name variable variable ...) expression)
syntax
(define name expression)
syntax
’name
syntax
’part
syntax
(quote name)
syntax
(quote part)
syntax
‘name
syntax
‘part
syntax
(quasiquote name)
syntax
(quasiquote part)
syntax
,expression
syntax
(unquote expression)
syntax
,@expression
syntax
(unquote-splicing expression)
syntax
(define-struct structure-name (field-name ...))
syntax
(cond [question-expression answer-expression] ...)
(cond [question-expression answer-expression]
      ...
      [else answer-expression])
syntax
(if test-expression then-expression else-expression)
syntax
(and expression expression expression ...)
syntax
(or expression expression expression ...)
syntax
(check-expect expression expected-expression)
syntax
(check-random expression expected-expression)
syntax
(check-satisfied expression predicate)
syntax
(check-within expression expected-expression delta)
syntax
(check-error expression expected-error-message)
(check-error expression)
syntax
(check-member-of expression expression expression ...)
syntax
(check-range expression low-expression high-expression)
syntax
(require string)
syntax
(require module-name)
syntax
(require (lib string string ...))
syntax
(require (planet string (string string number number)))
syntax
(require (planet id))
syntax
(require (planet string))
procedure
(- x y ...) -> number
  x : number
  y : number
procedure
(< x y z ...) -> boolean?
  x : real
  y : real
  z : real
procedure
(<= x y z ...) -> boolean?
  x : real
  y : real
  z : real
procedure
(= x y z ...) -> boolean?
  x : number
  y : number
  z : number
procedure
(> x y z ...) -> boolean?
  x : real
  y : real
  z : real
procedure
(>= x y z ...) -> boolean?
  x : real
  y : real
  z : real
procedure
(abs x) -> real
  x : real
procedure
(acos x) -> number
  x : number
procedure
(add1 x) -> number
  x : number
procedure
(angle x) -> real
  x : number
procedure
(asin x) -> number
  x : number
procedure
(atan x) -> number
  x : number
procedure
(ceiling x) -> integer
  x : real
procedure
(complex? x) -> boolean?
  x : any/c
procedure
(conjugate x) -> number
  x : number
procedure
(cos x) -> number
  x : number
procedure
(cosh x) -> number
  x : number
procedure
(current-seconds) -> integer
procedure
(denominator x) -> integer
  x : rational?
value
e : real
procedure
(even? x) -> boolean?
  x : integer
procedure
(exact->inexact x) -> number
  x : number
procedure
(exact? x) -> boolean?
  x : number
procedure
(exp x) -> number
  x : number
procedure
(expt x y) -> number
  x : number
  y : number
procedure
(floor x) -> integer
  x : real
procedure
(gcd x y ...) -> integer
  x : integer
  y : integer
procedure
(imag-part x) -> real
  x : number
procedure
(inexact->exact x) -> number
  x : number
procedure
(inexact? x) -> boolean?
  x : number
procedure
(integer->char x) -> char
  x : exact-integer?
procedure
(integer-sqrt x) -> complex
  x : integer
procedure
(integer? x) -> boolean?
  x : any/c
procedure
(lcm x y ...) -> integer
  x : integer
  y : integer
procedure
(log x) -> number
  x : number
procedure
(magnitude x) -> real
  x : number
procedure
(make-polar x y) -> number
  x : real
  y : real
procedure
(make-rectangular x y) -> number
  x : real
  y : real
procedure
(max x y ...) -> real
  x : real
  y : real
procedure
(min x y ...) -> real
  x : real
  y : real
procedure
(modulo x y) -> integer
  x : integer
  y : integer
procedure
(negative? x) -> boolean?
  x : number
procedure
(number->string x) -> string
  x : number
procedure
(number? n) -> boolean?
  n : any/c
procedure
(numerator x) -> integer
  x : rational?
procedure
(odd? x) -> boolean?
  x : integer
value
pi : real
procedure
(positive? x) -> boolean?
  x : number
procedure
(quotient x y) -> integer
  x : integer
  y : integer
procedure
(random x) -> natural
  x : natural
procedure
(rational? x) -> boolean?
  x : any/c
procedure
(real-part x) -> real
  x : number
procedure
(real? x) -> boolean?
  x : any/c
procedure
(remainder x y) -> integer
  x : integer
  y : integer
procedure
(round x) -> integer
  x : real
procedure
(sgn x) -> (union 1 #i1.0 0 #i0.0 -1 #i-1.0)
  x : real
procedure
(sin x) -> number
  x : number
procedure
(sinh x) -> number
  x : number
procedure
(sqr x) -> number
  x : number
procedure
(sqrt x) -> number
  x : number
procedure
(sub1 x) -> number
  x : number
procedure
(tan x) -> number
  x : number
procedure
(zero? x) -> boolean?
  x : number
procedure
(boolean=? x y) -> boolean?
  x : boolean?
  y : boolean?
procedure
(boolean? x) -> boolean?
  x : any/c
procedure
(false? x) -> boolean?
  x : any/c
procedure
(not x) -> boolean?
  x : boolean?
procedure
(symbol->string x) -> string
  x : symbol
procedure
(symbol=? x y) -> boolean?
  x : symbol
  y : symbol
procedure
(symbol? x) -> boolean?
  x : any/c
procedure
(append l ...) -> (listof any)
  l : (listof any)
procedure
(assq x l) -> (union false cons?)
  x : any/c
  l : list?
procedure
(caaar x) -> any/c
  x : list?
procedure
(caadr x) -> any/c
  x : list?
procedure
(caar x) -> any/c
  x : list?
procedure
(cadar x) -> any/c
  x : list?
procedure
(cadddr x) -> any/c
  x : list?
procedure
(caddr x) -> any/c
  x : list?
procedure
(cadr x) -> any/c
  x : list?
procedure
(car x) -> any/c
  x : cons?
procedure
(cdaar x) -> any/c
  x : list?
procedure
(cdadr x) -> any/c
  x : list?
procedure
(cdar x) -> list?
  x : list?
procedure
(cddar x) -> any/c
  x : list?
procedure
(cdddr x) -> any/c
  x : list?
procedure
(cddr x) -> list?
  x : list?
procedure
(cdr x) -> any/c
  x : cons?
procedure
(cons x y) -> list?
  x : any/x
  y : list?
procedure
(cons? x) -> boolean?
  x : any/c
procedure
(eighth x) -> any/c
  x : list?
procedure
(empty? x) -> boolean?
  x : any/c
procedure
(fifth x) -> any/c
  x : list?
procedure
(first x) -> any/c
  x : cons?
procedure
(fourth x) -> any/c
  x : list?
procedure
(length l) -> natural-number?
  l : list?
procedure
(list x ...) -> list?
  x : any/c
procedure
(list* x ... l) -> list?
  x : any/c
  l : list?
procedure
(list-ref x i) -> any/c
  x : list?
  i : natural?
procedure
(list? x) -> boolean?
  x : any
procedure
(make-list i x) -> list?
  i : natural-number
  x : any/c
procedure
(member x l) -> boolean?
  x : any/c
  l : list?
procedure
(member? x l) -> boolean?
  x : any/c
  l : list?
procedure
(memq x l) -> boolean?
  x : any/c
  l : list?
procedure
(memq? x l) -> boolean?
  x : any/c
  l : list?
procedure
(memv x l) -> (or/c false list)
  x : any/c
  l : list?
value
null : list
procedure
(null? x) -> boolean?
  x : any/c
procedure
(range start end step) -> list?
  start : number
  end : number
  step : number
procedure
(remove x l) -> list?
  x : any/c
  l : list?
procedure
(rest x) -> any/c
  x : cons?
procedure
(reverse l) -> list
  l : list?
procedure
(second x) -> any/c
  x : list?
procedure
(seventh x) -> any/c
  x : list?
procedure
(sixth x) -> any/c
  x : list?
procedure
(third x) -> any/c
  x : list?
procedure
(make-posn x y) -> posn
  x : any/c
  y : any/c
procedure
(posn-x p) -> any
  p : posn
procedure
(posn-y p) -> any
  p : posn
procedure
(posn? x) -> boolean?
  x : any/c
procedure
(char->integer c) -> integer
  c : char
procedure
(char-alphabetic? c) -> boolean?
  c : char
procedure
(char-ci<=? c d e ...) -> boolean?
  c : char
  d : char
  e : char
procedure
(char-ci<? c d e ...) -> boolean?
  c : char
  d : char
  e : char
procedure
(char-ci=? c d e ...) -> boolean?
  c : char
  d : char
  e : char
procedure
(char-ci>=? c d e ...) -> boolean?
  c : char
  d : char
  e : char
procedure
(char-ci>? c d e ...) -> boolean?
  c : char
  d : char
  e : char
procedure
(char-downcase c) -> char
  c : char
procedure
(char-lower-case? c) -> boolean?
  c : char
procedure
(char-numeric? c) -> boolean?
  c : char
procedure
(char-upcase c) -> char
  c : char
procedure
(char-upper-case? c) -> boolean?
  c : char
procedure
(char-whitespace? c) -> boolean?
  c : char
procedure
(char<=? c d e ...) -> boolean?
  c : char
  d : char
  e : char
procedure
(char<? x d e ...) -> boolean?
  x : char
  d : char
  e : char
procedure
(char=? c d e ...) -> boolean?
  c : char
  d : char
  e : char
procedure
(char>=? c d e ...) -> boolean?
  c : char
  d : char
  e : char
procedure
(char>? c d e ...) -> boolean?
  c : char
  d : char
  e : char
procedure
(char? x) -> boolean?
  x : any/c
procedure
(explode s) -> (listof string)
  s : string
procedure
(format f x ...) -> string
  f : string
  x : any/c
procedure
(implode l) -> string
  l : list?
procedure
(int->string i) -> string
  i : integer
procedure
(list->string l) -> string
  l : list?
procedure
(make-string i c) -> string
  i : natural-number
  c : char
procedure
(replicate i s) -> string
  i : natural-number
  s : string
procedure
(string c ...) -> string?
  c : char
procedure
(string->int s) -> integer
  s : string
procedure
(string->list s) -> (listof char)
  s : string
procedure
(string->number s) -> (union number false)
  s : string
procedure
(string->symbol s) -> symbol
  s : string
procedure
(string-alphabetic? s) -> boolean?
  s : string
procedure
(string-append s ...) -> string
  s : string
procedure
(string-ci<=? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string-ci<? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string-ci=? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string-ci>=? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string-ci>? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string-contains? s t) -> boolean?
  s : string
  t : string
procedure
(string-copy s) -> string
  s : string
procedure
(string-ith s i) -> 1string?
  s : string
  i : natural-number
procedure
(string-length s) -> nat
  s : string
procedure
(string-lower-case? s) -> boolean?
  s : string
procedure
(string-numeric? s) -> boolean?
  s : string
procedure
(string-ref s i) -> char
  s : string
  i : natural-number
procedure
(string-upper-case? s) -> boolean?
  s : string
procedure
(string-whitespace? s) -> boolean?
  s : string
procedure
(string<=? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string<? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string=? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string>=? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string>? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string? x) -> boolean?
  x : any/c
procedure
(substring s i j) -> string
  s : string
  i : natural-number
  j : natural-number
procedure
(image=? i j) -> boolean?
  i : image
  j : image
procedure
(image? x) -> boolean?
  x : any/c
procedure
(=~ x y z) -> boolean?
  x : number
  y : number
  z : non-negative-real
value
eof : eof-object?
procedure
(eof-object? x) -> boolean?
  x : any/c
procedure
(eq? x y) -> boolean?
  x : any/c
  y : any/c
procedure
(equal? x y) -> boolean?
  x : any/c
  y : any/c
procedure
(equal~? x y z) -> boolean?
  x : any/c
  y : any/c
  z : non-negative-real
procedure
(eqv? x y) -> boolean?
  x : any/c
  y : any/c
procedure
(error x ...) -> void?
  x : any/c
procedure
(exit) -> void
procedure
(identity x) -> any
  x : any/c
procedure
(struct? x) -> boolean?
  x : any/c
procedure
(* x ...) -> number
  x : number
procedure
(+ x ...) -> number
  x : number
procedure
(/ x y ...) -> number
  x : number
  y : number
procedure
(posn) -> signature
procedure
(andmap p? l) -> boolean
  p? : (X -> boolean)
  l : (listof X)
procedure
(apply f x-1 ... l) -> Y
  f : (X-1 ... X-N -> Y)
  x-1 : X-1
  l : (list X-i+1 ... X-N)
procedure
(argmax f l) -> X
  f : (X -> real)
  l : (listof X)
procedure
(argmin f l) -> X
  f : (X -> real)
  l : (listof X)
procedure
(build-list n f) -> (listof X)
  n : nat
  f : (nat -> X)
procedure
(build-string n f) -> string
  n : nat
  f : (nat -> char)
procedure
(compose f g) -> (X -> Z)
  f : (Y -> Z)
  g : (X -> Y)
procedure
(filter p? l) -> (listof X)
  p? : (X -> boolean)
  l : (listof X)
procedure
(foldl f base l) -> Y
  f : (X Y -> Y)
  base : Y
  l : (listof X)
procedure
(foldr f base l) -> Y
  f : (X Y -> Y)
  base : Y
  l : (listof X)
procedure
(for-each f l ...) -> void?
  f : (any ... -> any)
  l : (listof any)
procedure
(map f l ...) -> (listof Z)
  f : (X ... -> Z)
  l : (listof X)
procedure
(memf p? l) -> (union false (listof X))
  p? : (X -> any)
  l : (listof X)
procedure
(ormap p? l) -> boolean
  p? : (X -> boolean)
  l : (listof X)
procedure
(procedure? x) -> boolean?
  x : any
procedure
(quicksort l comp) -> (listof X)
  l : (listof X)
  comp : (X X -> boolean)
procedure
(sort l comp) -> (listof X)
  l : (listof X)
  comp : (X X -> boolean)
value
empty : empty?
value
true : boolean?
value
false : boolean?
syntax
..
syntax
...
syntax
....
syntax
.....
syntax
......
syntax
(lambda (variable ...) expression)
syntax
(λ (variable ...) expression)
syntax
(expression expression ...)
syntax
(define-datatype dataype-name [variant-name field-name ...] ...)
syntax
(begin expression expression ...)
syntax
(begin0 expression expression ...)
syntax
(set! variable expression)
syntax
(delay expression)
syntax
(shared ([name expression] ...) expression)
syntax
(recur name ([name expression] ...) expression)
syntax
(let name ([name expression] ...) expression)
syntax
(case expression [(choice ...) expression] ... [(choice ...) expression])
syntax
(case expression [(choice ...) expression] ... [else expression])
syntax
(match expression [pattern expression] ...)
syntax
(when test-expression body-expression)
syntax
(unless test-expression body-expression)
syntax
(local [definition ...] expression)
syntax
(letrec ([name expr-for-let] ...) expression)
syntax
(let* ([name expr-for-let] ...) expression)
syntax
(let ([name expr-for-let] ...) expression)
syntax
(time expression)
syntax
(define (name variable variable ...) expression)
syntax
(define name expression)
syntax
(define-struct structure-name (field-name ...))
syntax
(cond [question-expression answer-expression] ...)
(cond [question-expression answer-expression]
      ...
      [else answer-expression])
syntax
(if test-expression then-expression else-expression)
syntax
(and expression expression expression ...)
syntax
(or expression expression expression ...)
syntax
(check-expect expression expected-expression)
syntax
(check-random expression expected-expression)
syntax
(check-satisfied expression predicate)
syntax
(check-within expression expected-expression delta)
syntax
(check-error expression expected-error-message)
(check-error expression)
syntax
(check-member-of expression expression expression ...)
syntax
(check-range expression low-expression high-expression)
syntax
(require string)
syntax
(require module-name)
syntax
(require (lib string string ...))
syntax
(require (planet string (string string number number)))
syntax
(require (planet id))
syntax
(require (planet string))
procedure
(- x y ...) -> number
  x : number
  y : number
procedure
(< x y z ...) -> boolean?
  x : real
  y : real
  z : real
procedure
(<= x y z ...) -> boolean?
  x : real
  y : real
  z : real
procedure
(= x y z ...) -> boolean?
  x : number
  y : number
  z : number
procedure
(> x y z ...) -> boolean?
  x : real
  y : real
  z : real
procedure
(>= x y z ...) -> boolean?
  x : real
  y : real
  z : real
procedure
(abs x) -> real
  x : real
procedure
(acos x) -> number
  x : number
procedure
(add1 x) -> number
  x : number
procedure
(angle x) -> real
  x : number
procedure
(asin x) -> number
  x : number
procedure
(atan x) -> number
  x : number
procedure
(ceiling x) -> integer
  x : real
procedure
(complex? x) -> boolean?
  x : any/c
procedure
(conjugate x) -> number
  x : number
procedure
(cos x) -> number
  x : number
procedure
(cosh x) -> number
  x : number
procedure
(current-seconds) -> integer
procedure
(denominator x) -> integer
  x : rational?
value
e : real
procedure
(even? x) -> boolean?
  x : integer
procedure
(exact->inexact x) -> number
  x : number
procedure
(exact? x) -> boolean?
  x : number
procedure
(exp x) -> number
  x : number
procedure
(expt x y) -> number
  x : number
  y : number
procedure
(floor x) -> integer
  x : real
procedure
(gcd x y ...) -> integer
  x : integer
  y : integer
procedure
(imag-part x) -> real
  x : number
procedure
(inexact->exact x) -> number
  x : number
procedure
(inexact? x) -> boolean?
  x : number
procedure
(integer->char x) -> char
  x : exact-integer?
procedure
(integer-sqrt x) -> complex
  x : integer
procedure
(integer? x) -> boolean?
  x : any/c
procedure
(lcm x y ...) -> integer
  x : integer
  y : integer
procedure
(log x) -> number
  x : number
procedure
(magnitude x) -> real
  x : number
procedure
(make-polar x y) -> number
  x : real
  y : real
procedure
(make-rectangular x y) -> number
  x : real
  y : real
procedure
(max x y ...) -> real
  x : real
  y : real
procedure
(min x y ...) -> real
  x : real
  y : real
procedure
(modulo x y) -> integer
  x : integer
  y : integer
procedure
(negative? x) -> boolean?
  x : number
procedure
(number->string x) -> string
  x : number
procedure
(number? n) -> boolean?
  n : any/c
procedure
(numerator x) -> integer
  x : rational?
procedure
(odd? x) -> boolean?
  x : integer
value
pi : real
procedure
(positive? x) -> boolean?
  x : number
procedure
(quotient x y) -> integer
  x : integer
  y : integer
procedure
(random x) -> natural
  x : natural
procedure
(rational? x) -> boolean?
  x : any/c
procedure
(real-part x) -> real
  x : number
procedure
(real? x) -> boolean?
  x : any/c
procedure
(remainder x y) -> integer
  x : integer
  y : integer
procedure
(round x) -> integer
  x : real
procedure
(sgn x) -> (union 1 #i1.0 0 #i0.0 -1 #i-1.0)
  x : real
procedure
(sin x) -> number
  x : number
procedure
(sinh x) -> number
  x : number
procedure
(sqr x) -> number
  x : number
procedure
(sqrt x) -> number
  x : number
procedure
(sub1 x) -> number
  x : number
procedure
(tan x) -> number
  x : number
procedure
(zero? x) -> boolean?
  x : number
procedure
(boolean=? x y) -> boolean?
  x : boolean?
  y : boolean?
procedure
(boolean? x) -> boolean?
  x : any/c
procedure
(false? x) -> boolean?
  x : any/c
procedure
(not x) -> boolean?
  x : boolean?
procedure
(symbol->string x) -> string
  x : symbol
procedure
(symbol=? x y) -> boolean?
  x : symbol
  y : symbol
procedure
(symbol? x) -> boolean?
  x : any/c
procedure
(append l ...) -> (listof any)
  l : (listof any)
procedure
(assoc x l) -> (union (listof any) false)
  x : any
  l : (listof any)
procedure
(assq x l) -> (union false cons?)
  x : any/c
  l : list?
procedure
(caaar x) -> any/c
  x : list?
procedure
(caadr x) -> any/c
  x : list?
procedure
(caar x) -> any/c
  x : list?
procedure
(cadar x) -> any/c
  x : list?
procedure
(cadddr x) -> any/c
  x : list?
procedure
(caddr x) -> any/c
  x : list?
procedure
(cadr x) -> any/c
  x : list?
procedure
(car x) -> any/c
  x : cons?
procedure
(cdaar x) -> any/c
  x : list?
procedure
(cdadr x) -> any/c
  x : list?
procedure
(cdar x) -> list?
  x : list?
procedure
(cddar x) -> any/c
  x : list?
procedure
(cdddr x) -> any/c
  x : list?
procedure
(cddr x) -> list?
  x : list?
procedure
(cdr x) -> any/c
  x : cons?
procedure
(cons x l) -> (listof X)
  x : X
  l : (listof X)
procedure
(cons? x) -> boolean?
  x : any/c
procedure
(eighth x) -> any/c
  x : list?
procedure
(empty? x) -> boolean?
  x : any/c
procedure
(fifth x) -> any/c
  x : list?
procedure
(first x) -> any/c
  x : cons?
procedure
(fourth x) -> any/c
  x : list?
procedure
(length l) -> natural-number?
  l : list?
procedure
(list x ...) -> list?
  x : any/c
procedure
(list* x ... l) -> (listof any)
  x : any
  l : (listof any)
procedure
(list-ref x i) -> any/c
  x : list?
  i : natural?
procedure
(list? x) -> boolean?
  x : any
procedure
(make-list i x) -> list?
  i : natural-number
  x : any/c
procedure
(member x l) -> boolean?
  x : any/c
  l : list?
procedure
(member? x l) -> boolean?
  x : any/c
  l : list?
procedure
(memq x l) -> boolean?
  x : any/c
  l : list?
procedure
(memq? x l) -> boolean?
  x : any/c
  l : list?
procedure
(memv x l) -> (or/c false list)
  x : any/c
  l : list?
value
null : list
procedure
(null? x) -> boolean?
  x : any/c
procedure
(range start end step) -> list?
  start : number
  end : number
  step : number
procedure
(remove x l) -> list?
  x : any/c
  l : list?
procedure
(rest x) -> any/c
  x : cons?
procedure
(reverse l) -> list
  l : list?
procedure
(second x) -> any/c
  x : list?
procedure
(seventh x) -> any/c
  x : list?
procedure
(sixth x) -> any/c
  x : list?
procedure
(third x) -> any/c
  x : list?
procedure
(make-posn x y) -> posn
  x : any/c
  y : any/c
procedure
(posn-x p) -> any
  p : posn
procedure
(posn-y p) -> any
  p : posn
procedure
(posn? x) -> boolean?
  x : any/c
procedure
(set-posn-x! p x) -> void?
  p : posn
  x : any
procedure
(set-posn-y! p x) -> void
  p : posn
  x : any
procedure
(char->integer c) -> integer
  c : char
procedure
(char-alphabetic? c) -> boolean?
  c : char
procedure
(char-ci<=? c d e ...) -> boolean?
  c : char
  d : char
  e : char
procedure
(char-ci<? c d e ...) -> boolean?
  c : char
  d : char
  e : char
procedure
(char-ci=? c d e ...) -> boolean?
  c : char
  d : char
  e : char
procedure
(char-ci>=? c d e ...) -> boolean?
  c : char
  d : char
  e : char
procedure
(char-ci>? c d e ...) -> boolean?
  c : char
  d : char
  e : char
procedure
(char-downcase c) -> char
  c : char
procedure
(char-lower-case? c) -> boolean?
  c : char
procedure
(char-numeric? c) -> boolean?
  c : char
procedure
(char-upcase c) -> char
  c : char
procedure
(char-upper-case? c) -> boolean?
  c : char
procedure
(char-whitespace? c) -> boolean?
  c : char
procedure
(char<=? c d e ...) -> boolean?
  c : char
  d : char
  e : char
procedure
(char<? x d e ...) -> boolean?
  x : char
  d : char
  e : char
procedure
(char=? c d e ...) -> boolean?
  c : char
  d : char
  e : char
procedure
(char>=? c d e ...) -> boolean?
  c : char
  d : char
  e : char
procedure
(char>? c d e ...) -> boolean?
  c : char
  d : char
  e : char
procedure
(char? x) -> boolean?
  x : any/c
procedure
(explode s) -> (listof string)
  s : string
procedure
(format f x ...) -> string
  f : string
  x : any/c
procedure
(implode l) -> string
  l : list?
procedure
(int->string i) -> string
  i : integer
procedure
(list->string l) -> string
  l : list?
procedure
(make-string i c) -> string
  i : natural-number
  c : char
procedure
(replicate i s) -> string
  i : natural-number
  s : string
procedure
(string c ...) -> string?
  c : char
procedure
(string->int s) -> integer
  s : string
procedure
(string->list s) -> (listof char)
  s : string
procedure
(string->number s) -> (union number false)
  s : string
procedure
(string->symbol s) -> symbol
  s : string
procedure
(string-alphabetic? s) -> boolean?
  s : string
procedure
(string-append s ...) -> string
  s : string
procedure
(string-ci<=? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string-ci<? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string-ci=? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string-ci>=? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string-ci>? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string-contains? s t) -> boolean?
  s : string
  t : string
procedure
(string-copy s) -> string
  s : string
procedure
(string-ith s i) -> 1string?
  s : string
  i : natural-number
procedure
(string-length s) -> nat
  s : string
procedure
(string-lower-case? s) -> boolean?
  s : string
procedure
(string-numeric? s) -> boolean?
  s : string
procedure
(string-ref s i) -> char
  s : string
  i : natural-number
procedure
(string-upper-case? s) -> boolean?
  s : string
procedure
(string-whitespace? s) -> boolean?
  s : string
procedure
(string<=? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string<? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string=? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string>=? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string>? s t x ...) -> boolean?
  s : string
  t : string
  x : string
procedure
(string? x) -> boolean?
  x : any/c
procedure
(substring s i j) -> string
  s : string
  i : natural-number
  j : natural-number
procedure
(image=? i j) -> boolean?
  i : image
  j : image
procedure
(image? x) -> boolean?
  x : any/c
procedure
(=~ x y z) -> boolean?
  x : number
  y : number
  z : non-negative-real
procedure
(current-milliseconds) -> exact-integer
value
eof : eof-object?
procedure
(eof-object? x) -> boolean?
  x : any/c
procedure
(eq? x y) -> boolean?
  x : any/c
  y : any/c
procedure
(equal? x y) -> boolean?
  x : any/c
  y : any/c
procedure
(equal~? x y z) -> boolean?
  x : any/c
  y : any/c
  z : non-negative-real
procedure
(eqv? x y) -> boolean?
  x : any/c
  y : any/c
procedure
(error x ...) -> void?
  x : any/c
procedure
(exit) -> void
procedure
(force v) -> any
  v : any
procedure
(gensym) -> symbol?
procedure
(identity x) -> any
  x : any/c
procedure
(promise? x) -> boolean?
  x : any
procedure
(sleep sec) -> void
  sec : positive-num
procedure
(struct? x) -> boolean?
  x : any/c
procedure
(void) -> void?
procedure
(void? x) -> boolean?
  x : any
procedure
(* x ...) -> number
  x : number
procedure
(+ x ...) -> number
  x : number
procedure
(/ x y ...) -> number
  x : number
  y : number
procedure
(posn) -> signature
procedure
(andmap p? l) -> boolean
  p? : (X -> boolean)
  l : (listof X)
procedure
(apply f x-1 ... l) -> Y
  f : (X-1 ... X-N -> Y)
  x-1 : X-1
  l : (list X-i+1 ... X-N)
procedure
(argmax f l) -> X
  f : (X -> real)
  l : (listof X)
procedure
(argmin f l) -> X
  f : (X -> real)
  l : (listof X)
procedure
(build-list n f) -> (listof X)
  n : nat
  f : (nat -> X)
procedure
(build-string n f) -> string
  n : nat
  f : (nat -> char)
procedure
(compose f g) -> (X -> Z)
  f : (Y -> Z)
  g : (X -> Y)
procedure
(filter p? l) -> (listof X)
  p? : (X -> boolean)
  l : (listof X)
procedure
(foldl f base l) -> Y
  f : (X Y -> Y)
  base : Y
  l : (listof X)
procedure
(foldr f base l) -> Y
  f : (X Y -> Y)
  base : Y
  l : (listof X)
procedure
(for-each f l ...) -> void?
  f : (any ... -> any)
  l : (listof any)
procedure
(map f l ...) -> (listof Z)
  f : (X ... -> Z)
  l : (listof X)
procedure
(memf p? l) -> (union false (listof X))
  p? : (X -> any)
  l : (listof X)
procedure
(ormap p? l) -> boolean
  p? : (X -> boolean)
  l : (listof X)
procedure
(procedure? x) -> boolean?
  x : any
procedure
(quicksort l comp) -> (listof X)
  l : (listof X)
  comp : (X X -> boolean)
procedure
(sort l comp) -> (listof X)
  l : (listof X)
  comp : (X X -> boolean)
procedure
(display x) -> void
  x : any
procedure
(newline) -> void
procedure
(pretty-print x) -> void
  x : any
procedure
(print x) -> void
  x : any
procedure
(printf f x ...) -> void
  f : string
  x : any
procedure
(read) -> sexp
procedure
(with-input-from-file f p) -> any
  f : string
  p : (-> any)
procedure
(with-input-from-string s p) -> any
  s : string
  p : (-> any)
procedure
(with-output-to-file f p) -> any
  f : string
  p : (-> any)
procedure
(with-output-to-string p) -> any
  p : (-> any)
procedure
(write x) -> void
  x : any
procedure
(build-vector n f) -> (vectorof X)
  n : nat
  f : (nat -> X)
procedure
(list->vector l) -> (vectorof X)
  l : (listof X)
procedure
(make-vector n x) -> (vectorof X)
  n : number
  x : X
procedure
(vector x ...) -> (vector X ...)
  x : X
procedure
(vector->list v) -> (listof X)
  v : (vectorof X)
procedure
(vector-length v) -> nat
  v : (vector X)
procedure
(vector-ref v n) -> X
  v : (vector X)
  n : nat
procedure
(vector-set! v n x) -> void
  v : (vectorof X)
  n : nat
  x : X
procedure
(vector? x) -> boolean
  x : any
procedure
(box x) -> box?
  x : any/c
procedure
(box? x) -> boolean?
  x : any/c
procedure
(set-box! b x) -> void
  b : box?
  x : any/c
procedure
(unbox b) -> any
  b : box?
procedure
(hash-copy h) -> hash
  h : hash
procedure
(hash-count h) -> integer
  h : hash
procedure
(hash-eq? h) -> boolean
  h : hash
procedure
(hash-equal? h) -> boolean
  h : hash?
procedure
(hash-eqv? h) -> boolean
  h : hash
procedure
(hash-for-each h f) -> void?
  h : (hash X Y)
  f : (X Y -> any)
procedure
(hash-has-key? h x) -> boolean
  h : (hash X Y)
  x : X
procedure
(hash-map h f) -> (listof Z)
  h : (hash X Y)
  f : (X Y -> Z)
procedure
(hash-ref h k) -> Y
  h : (hash X Y)
  k : X
procedure
(hash-ref! h k v) -> Y
  h : (hash X Y)
  k : X
  v : Y
procedure
(hash-remove h k) -> (hash X Y)
  h : (hash X Y)
  k : X
procedure
(hash-remove! h x) -> void
  h : (hash X Y)
  x : X
procedure
(hash-set h k v) -> (hash X Y)
  h : (hash X Y)
  k : X
  v : Y
procedure
(hash-set! h k v) -> void?
  h : (hash X Y)
  k : X
  v : Y
procedure
(hash-update h k f) -> (hash X Y)
  h : (hash X Y)
  k : X
  f : (Y -> Y)
procedure
(hash-update! h k f) -> void?
  h : (hash X Y)
  k : X
  f : (Y -> Y)
procedure
(hash? x) -> boolean
  x : any
procedure
(make-hash) -> (hash X Y)
procedure
(make-hasheq) -> (hash X Y)
procedure
(make-hasheqv) -> (hash X Y)
procedure
(make-immutable-hash) -> (hash X Y)
procedure
(make-immutable-hasheq) -> (hash X Y)
procedure
(make-immutable-hasheqv) -> (hash X Y)
