2921
((3) 0 () 8 ((q lib "htdp/error.rkt") (q lib "lang/prim.rkt") (q lib "htdp/color-structs.rkt") (q 4091 . 6) (q lib "lang/posn.rkt") (q 3602 . 5) (q lib "test-engine/racket-tests.rkt") (q 4234 . 7)) () (h ! (equal) ((c def c (c (? . 0) q check-dependencies)) q (2767 . 6)) ((c def c (c (? . 0) q check-list-list)) q (2141 . 6)) ((c form c (c (? . 1) q provide-primitives)) q (3887 . 2)) ((c def c (c (? . 2) q color-green)) c (? . 3)) ((c form c (c (? . 1) q provide-higher-order-primitive)) q (3988 . 2)) ((c def c (c (? . 2) q color-red)) c (? . 3)) ((c def c (c (? . 4) q make-posn)) c (? . 5)) ((c def c (c (? . 6) q scheme-test-data)) q (3479 . 2)) ((q def ((lib "htdp/testing.rkt") generate-report)) q (3563 . 2)) ((c def c (c (? . 4) q posn?)) c (? . 5)) ((c def c (c (? . 0) q natural?)) q (2602 . 3)) ((c def c (c (? . 6) q get-test-engine)) q (3372 . 2)) ((c def c (c (? . 2) q alpha-color-green)) c (? . 7)) ((c form c (c (? . 1) q define-higher-order-primitive)) q (3924 . 2)) ((c def c (c (? . 0) q tp-exn?)) q (3075 . 3)) ((c def c (c (? . 2) q color?)) c (? . 3)) ((c def c (c (? . 2) q struct:color)) c (? . 3)) ((c def c (c (? . 4) q posn-y)) c (? . 5)) ((c def c (c (? . 0) q check-arity)) q (1521 . 5)) ((c def c (c (? . 4) q posn-x)) c (? . 5)) ((c def c (c (? . 4) q struct:posn)) c (? . 5)) ((c def c (c (? . 2) q color-blue)) c (? . 3)) ((c def c (c (? . 0) q number->ord)) q (3128 . 3)) ((c def c (c (? . 6) q build-test-engine)) q (3187 . 2)) ((c def c (c (? . 6) q run-tests)) q (3446 . 2)) ((c def c (c (? . 0) q check-result)) q (1935 . 6)) ((c def c (c (? . 2) q alpha-color-red)) c (? . 7)) ((c def c (c (? . 6) q exn:fail:wish)) q (3335 . 2)) ((c def c (c (? . 2) q alpha-color-blue)) c (? . 7)) ((c def c (c (? . 0) q check-arg)) q (1285 . 7)) ((c def c (c (? . 0) q tp-error)) q (2939 . 5)) ((c def c (c (? . 2) q make-alpha-color)) c (? . 7)) ((c def c (c (? . 0) q check-color)) q (2320 . 5)) ((c form c (c (? . 1) q define-primitive)) q (3817 . 2)) ((q def ((lib "lang/imageeq.rkt") image=?)) q (3707 . 4)) ((c def c (c (? . 6) q error-handler)) q (3298 . 2)) ((c def c (c (? . 0) q find-non)) q (2656 . 4)) ((c def c (c (? . 4) q posn)) c (? . 5)) ((c def c (c (? . 6) q display-results)) q (3259 . 2)) ((c def c (c (? . 2) q make-color)) c (? . 3)) ((c form c (c (? . 1) q first-order->higher-order)) q (4044 . 2)) ((c def c (c (? . 2) q struct:alpha-color)) c (? . 7)) ((c def c (c (? . 6) q builder)) q (3228 . 2)) ((c def c (c (? . 0) q check-fun-res)) q (2454 . 5)) ((c def c (c (? . 2) q color)) c (? . 3)) ((c def c (c (? . 2) q alpha-color)) c (? . 7)) ((c def c (c (? . 6) q reset-tests)) q (3411 . 2)) ((c def c (c (? . 2) q alpha-color-alpha)) c (? . 7)) ((c def c (c (? . 0) q check-proc)) q (1698 . 7)) ((c def c (c (? . 2) q alpha-color?)) c (? . 7)) ((c form c (c (? . 1) q provide-primitive)) q (3856 . 2)) ((c def c (c (? . 6) q signature-test-info%)) q (3519 . 2))))

function      variable argument  function body
expression    part     clause    top level
structure nametype namefield namebinding

Instead of                                                         Use
procedure, primitive name, primitive operator, predicate, selector,“function””
constructor
s-expression                                                       “expression”
identifier                                                         “argument” or “variable”, depending on the use in the program
defined name                                                       “function” or “variable”
sequence                                                           “at least one (in parentheses)”
function header                                                    “after define”, “after the name”, “after the first argument”, ...
keyword                                                            mention the construct directly by name, such as “expected a variable but
                                                                   found a cond”
built-in                                                           Nothing — avoid this term
macro                                                              Nothing — avoid this term
procedure
(check-arg name chk expected position given) -> void?
  name : (or/c symbol? string?)
  chk : boolean?
  expected : any/c
  position : (or/c (and/c positive? integer?) string?)
  given : any/c
procedure
(check-arity name [arg#] args) -> void?
  name : (or/c symbol? string?)
  arg# : (or/c (and/c positive? integer?) string?) = ?
  args : list?
procedure
(check-proc name proc expected arg# arg-err) -> void?
  name : (or/c symbol? string?)
  proc : any/c
  expected : natural?
  arg# : (or/c (and/c positive? integer?) string?)
  arg-err : string?
procedure
(check-result name pred? kind returned ...+) -> void?
  name : (or/c symbol? string?)
  pred? : (-> any/c boolean?)
  kind : (or/c symbol? string?)
  returned : any/c
procedure
(check-list-list name chk pred? given) -> void?
  name : (or/c symbol? string?)
  chk : (or/c string? false/c)
  pred? : any/c
  given : any/c
procedure
(check-color name arg# given) -> void?
  name : (or/c symbol? string?)
  arg# : natural?
  given : any/c
procedure
(check-fun-res f pred? type) -> void?
  f : procedure?
  pred? : (-> any/c boolean?)
  type : (or/c symbol? string?)
procedure
(natural? o) -> boolean?
  o : any/c
procedure
(find-non pred? l) -> (or/c any/c false/c)
  pred? : (-> any/c boolean?)
  l : list?
procedure
(check-dependencies name chk fmt arg ...) -> void?
  name : (or/c symbol? string?)
  chk : boolean?
  fmt : format-string?
  arg : any/c
procedure
(tp-error name fmt arg ...) -> void?
  name : (or/c symbol? string?)
  fmt : format-string?
  arg : any/c
procedure
(tp-exn? o) -> boolean?
  o : any/c
procedure
(number->ord n) -> string?
  n : natural?
procedure
(build-test-engine) -> void?
procedure
(builder) -> void?
procedure
(display-results) -> void?
procedure
(error-handler) -> void?
procedure
(exn:fail:wish) -> void?
procedure
(get-test-engine) -> void?
procedure
(reset-tests) -> void?
procedure
(run-tests) -> void?
procedure
(scheme-test-data) -> void?
procedure
(signature-test-info%) -> void?
procedure
(generate-report) -> void?
struct
(struct posn (x y)
    #:extra-constructor-name make-posn)
  x : any/c
  y : any/c
procedure
(image=? i1 i2) -> boolean?
  i1 : (is-a?/c image-snip%)
  i2 : (is-a?/c image-snip%)
syntax
(define-primitive id proc-id)
syntax
(provide-primitive id)
syntax
(provide-primitives id ...)
syntax
(define-higher-order-primitive id proc-id (arg ...))
syntax
(provide-higher-order-primitive id (arg ...))
syntax
(first-order->higher-order expression)
struct
(struct color (red green blue)
    #:extra-constructor-name make-color)
  red : any/c
  green : any/c
  blue : any/c
struct
(struct alpha-color (alpha red green blue)
    #:extra-constructor-name make-alpha-color)
  alpha : any/c
  red : any/c
  green : any/c
  blue : any/c
