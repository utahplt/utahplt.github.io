#lang setup/infotab

(define collection 'multi)

(define deps '("plai-typed"))
