11006
((3) 0 () 20 ((q lib "pict/main.rkt") (q 15360 . 46) (q 9732 . 25) (q lib "pict/code.rkt") (q 455 . 10) (q lib "pict/tree-layout.rkt") (q lib "pict/convert.rkt") (q 1928 . 15) (q 10400 . 31) (q 0 . 18) (q 3843 . 13) (q lib "pict/flash.rkt") (q lib "pict/balloon.rkt") (q 1328 . 9) (q lib "pict/face.rkt") (q 4133 . 108) (q 2761 . 19) (q 20918 . 13) (q 3679 . 7) (q 2442 . 10)) () (h ! (equal) ((c def c (c (? . 0) q standard-fish)) q (17043 . 13)) ((c def c (c (? . 0) q pict->argb-pixels)) q (31965 . 4)) ((c def c (c (? . 0) q child-pict)) c (? . 4)) ((c def c (c (? . 0) q lift-above-baseline)) q (14786 . 4)) ((c def c (c (? . 5) q tree-edge?)) q (29489 . 3)) ((c def c (c (? . 0) q lt-find)) c (? . 1)) ((c def c (c (? . 0) q rc-find)) c (? . 1)) ((c def c (c (? . 6) q prop:pict-convertible)) q (33275 . 2)) ((c def c (c (? . 0) q pin-arrows-line)) c (? . 15)) ((c def c (c (? . 0) q hb-append)) c (? . 2)) ((c def c (c (? . 3) q code-italic-underscore-enabled)) q (26210 . 4)) ((c def c (c (? . 0) q cbl-superimpose)) c (? . 8)) ((c def c (c (? . 0) q make-pict-drawer)) q (32234 . 4)) ((c def c (c (? . 0) q vc-append)) c (? . 2)) ((c def c (c (? . 0) q disk)) c (? . 7)) ((c def c (c (? . 3) q code-colorize-enabled)) q (25986 . 4)) ((c def c (c (? . 0) q child-sxy)) c (? . 4)) ((c def c (c (? . 0) q filled-rectangle)) c (? . 19)) ((c def c (c (? . 0) q pip-arrows-line)) c (? . 10)) ((c def c (c (? . 5) q naive-layered)) q (29545 . 7)) ((c def c (c (? . 12) q wrap-balloon)) q (19234 . 13)) ((c def c (c (? . 3) q current-reader-forms)) q (25318 . 4)) ((c def c (c (? . 0) q pict-height)) c (? . 9)) ((c def c (c (? . 0) q vr-append)) c (? . 2)) ((c def c (c (? . 0) q baseless)) q (14966 . 3)) ((c def c (c (? . 0) q jack-o-lantern)) q (17637 . 7)) ((c form c (c (? . 3) q define-code)) q (26438 . 3)) ((c def c (c (? . 6) q prop:pict-convertible?)) q (33329 . 2)) ((c def c (c (? . 0) q filled-ellipse)) c (? . 7)) ((c def c (c (? . 14) q face)) q (21470 . 4)) ((c def c (c (? . 0) q cc-find)) c (? . 1)) ((c def c (c (? . 11) q filled-flash)) q (22976 . 11)) ((c def c (c (? . 0) q child-sy)) c (? . 4)) ((c def c (c (? . 0) q lt-superimpose)) c (? . 8)) ((c def c (c (? . 0) q cellophane)) q (13691 . 4)) ((c def c (c (? . 0) q fast-middle)) q (28585 . 3)) ((c def c (c (? . 0) q make-pict)) c (? . 9)) ((c def c (c (? . 0) q rb-superimpose)) c (? . 8)) ((c def c (c (? . 0) q drop-below-ascent)) q (14877 . 4)) ((c def c (c (? . 0) q pip-arrow-line)) c (? . 10)) ((c def c (c (? . 0) q fast-end)) q (28425 . 3)) ((c def c (c (? . 0) q current-expected-text-scale)) q (33120 . 4)) ((c def c (c (? . 0) q ct-find)) c (? . 1)) ((c def c (c (? . 0) q rtl-superimpose)) c (? . 8)) ((c def c (c (? . 0) q slide-pict/center)) q (27923 . 7)) ((c def c (c (? . 0) q lbl-superimpose)) c (? . 8)) ((c def c (c (? . 3) q current-base-color)) q (25159 . 4)) ((c def c (c (? . 0) q split-phase)) q (28667 . 3)) ((c def c (c (? . 3) q current-literal-color)) q (24833 . 4)) ((c def c (c (? . 0) q ctl-superimpose)) c (? . 8)) ((c def c (c (? . 0) q vline)) c (? . 13)) ((c def c (c (? . 5) q binary-tree-layout?)) q (29424 . 3)) ((c def c (c (? . 11) q outline-flash)) q (23358 . 11)) ((c def c (c (? . 6) q pict-convert)) q (33447 . 3)) ((c def c (c (? . 0) q lbl-find)) c (? . 1)) ((c def c (c (? . 0) q sequence-animations)) q (28095 . 3)) ((c def c (c (? . 3) q keyword-color)) q (27055 . 2)) ((c def c (c (? . 12) q balloon-enable-3d)) q (21309 . 4)) ((c def c (c (? . 0) q pict-descent)) c (? . 9)) ((c def c (c (? . 0) q hline)) c (? . 13)) ((c def c (c (? . 0) q inset)) q (14398 . 14)) ((c def c (c (? . 3) q current-keyword-list)) q (25504 . 4)) ((c def c (c (? . 0) q fade-around-pict)) q (27616 . 5)) ((c def c (c (? . 0) q pict-last)) c (? . 9)) ((c def c (c (? . 0) q scale-to-fit)) q (12784 . 8)) ((c def c (c (? . 0) q cc-superimpose)) c (? . 8)) ((c def c (c (? . 12) q balloon-pict)) c (? . 17)) ((c def c (c (? . 0) q child-syx)) c (? . 4)) ((c def c (c (? . 0) q hbl-append)) c (? . 2)) ((c def c (c (? . 3) q current-code-tt)) q (23945 . 4)) ((c def c (c (? . 0) q rb-find)) c (? . 1)) ((c def c (c (? . 0) q desktop-machine)) q (18028 . 4)) ((c def c (c (? . 0) q angel-wing)) q (17929 . 5)) ((c def c (c (? . 14) q default-face-color)) q (21407 . 2)) ((c def c (c (? . 0) q pict-width)) c (? . 9)) ((c def c (c (? . 5) q tree-edge)) q (28939 . 9)) ((c def c (c (? . 0) q pict-panbox)) c (? . 9)) ((c def c (c (? . 0) q use-last*)) q (15264 . 4)) ((c def c (c (? . 0) q ht-append)) c (? . 2)) ((c def c (c (? . 0) q pict)) c (? . 9)) ((c def c (c (? . 0) q convert-bounds-padding)) q (31470 . 5)) ((c def c (c (? . 0) q hc-append)) c (? . 2)) ((c def c (c (? . 0) q linestyle)) q (13212 . 7)) ((c def c (c (? . 3) q comment-color)) q (26996 . 2)) ((c def c (c (? . 3) q code-colorize-quote-enabled)) q (26092 . 4)) ((c def c (c (? . 0) q inset/clip)) q (13843 . 14)) ((c def c (c (? . 0) q child-dx)) c (? . 4)) ((c def c (c (? . 5) q tree-layout)) q (28770 . 4)) ((c def c (c (? . 3) q get-current-code-font-size)) q (24076 . 4)) ((c def c (c (? . 0) q refocus)) q (15023 . 4)) ((c def c (c (? . 0) q circle)) c (? . 7)) ((c def c (c (? . 0) q colorize)) q (13526 . 5)) ((c def c (c (? . 0) q dc-for-text-size)) q (31333 . 4)) ((c def c (c (? . 0) q pict?)) c (? . 9)) ((c def c (c (? . 0) q lc-find)) c (? . 1)) ((c def c (c (? . 3) q pict->code-pict)) q (27314 . 4)) ((c def c (c (? . 3) q current-const-color)) q (24998 . 4)) ((c def c (c (? . 3) q prop:code-transformer)) q (26709 . 2)) ((c def c (c (? . 0) q rbl-superimpose)) c (? . 8)) ((c def c (c (? . 0) q pin-over)) q (11286 . 11)) ((c def c (c (? . 0) q lb-find)) c (? . 1)) ((c def c (c (? . 0) q rounded-rectangle)) c (? . 16)) ((c def c (c (? . 0) q child-sx)) c (? . 4)) ((c def c (c (? . 0) q struct:child)) c (? . 4)) ((c def c (c (? . 0) q pin-line)) c (? . 15)) ((c def c (c (? . 3) q make-code-transformer)) q (26536 . 4)) ((c def c (c (? . 0) q child?)) c (? . 4)) ((c def c (c (? . 0) q filled-rounded-rectangle)) c (? . 16)) ((c def c (c (? . 12) q balloon-color)) q (21250 . 2)) ((c def c (c (? . 0) q ellipse)) c (? . 7)) ((c def c (c (? . 0) q bitmap-draft-mode)) q (9634 . 4)) ((c def c (c (? . 0) q pict-draw)) c (? . 9)) ((c def c (c (? . 0) q rbl-find)) c (? . 1)) ((c def c (c (? . 3) q literal-color)) q (27168 . 2)) ((c form c (c (? . 3) q define-exec-code)) q (26826 . 3)) ((c def c (c (? . 0) q htl-append)) c (? . 2)) ((c def c (c (? . 0) q use-last)) q (15169 . 4)) ((c def c (c (? . 0) q pict-children)) c (? . 9)) ((c def c (c (? . 3) q current-literal-list)) q (25758 . 4)) ((c def c (c (? . 5) q tree-layout?)) q (29366 . 3)) ((c def c (c (? . 0) q fade-pict)) q (27421 . 6)) ((c def c (c (? . 0) q ltl-find)) c (? . 1)) ((c def c (c (? . 0) q blank)) q (851 . 15)) ((c def c (c (? . 0) q ct-superimpose)) c (? . 8)) ((c def c (c (? . 0) q rt-find)) c (? . 1)) ((c def c (c (? . 0) q arrow)) c (? . 18)) ((c def c (c (? . 0) q scale)) q (12591 . 8)) ((c def c (c (? . 12) q balloon)) q (20592 . 9)) ((c def c (c (? . 0) q scale-color)) q (30598 . 4)) ((c def c (c (? . 12) q pin-balloon)) q (20269 . 11)) ((c def c (c (? . 0) q bitmap)) q (3530 . 5)) ((c def c (c (? . 0) q draw-pict)) q (31678 . 6)) ((c def c (c (? . 0) q fast-edges)) q (28504 . 3)) ((c def c (c (? . 0) q show-pict)) q (32342 . 15)) ((c def c (c (? . 0) q lb-superimpose)) c (? . 8)) ((c def c (c (? . 0) q ghost)) q (13069 . 3)) ((c def c (c (? . 0) q reverse-animations)) q (28220 . 3)) ((c def c (c (? . 12) q balloon-point-y)) c (? . 17)) ((c def c (c (? . 0) q launder)) q (16677 . 3)) ((c def c (c (? . 3) q code-align)) q (25445 . 3)) ((c def c (c (? . 0) q cb-find)) c (? . 1)) ((c def c (c (? . 3) q current-code-font)) q (23832 . 4)) ((c def c (c (? . 0) q ctl-find)) c (? . 1)) ((c def c (c (? . 0) q arrowhead)) c (? . 18)) ((c def c (c (? . 0) q cloud)) q (16733 . 5)) ((c def c (c (? . 0) q text)) q (1141 . 6)) ((c def c (c (? . 0) q color-series)) q (30729 . 17)) ((c def c (c (? . 3) q current-comment-color)) q (24348 . 4)) ((c def c (c (? . 0) q linewidth)) q (13123 . 4)) ((c def c (c (? . 12) q pip-wrap-balloon)) q (19741 . 13)) ((c def c (c (? . 3) q current-id-color)) q (24678 . 4)) ((c def c (c (? . 0) q pin-under)) q (11593 . 11)) ((c def c (c (? . 0) q clip)) q (13791 . 3)) ((c def c (c (? . 0) q rectangle)) c (? . 19)) ((c form c (c (? . 3) q define-exec-code/scale)) q (26902 . 3)) ((c def c (c (? . 0) q make-child)) c (? . 4)) ((c def c (c (? . 0) q slide-pict)) q (27758 . 7)) ((c def c (c (? . 3) q code-scripts-enabled)) q (26334 . 4)) ((c def c (c (? . 0) q hyperlinkize)) q (30537 . 3)) ((c def c (c (? . 0) q rotate)) q (12987 . 4)) ((c def c (c (? . 12) q balloon?)) c (? . 17)) ((c def c (c (? . 3) q racket/base-const-list)) q (25887 . 2)) ((c def c (c (? . 0) q cbl-find)) c (? . 1)) ((c def c (c (? . 0) q pip-line)) c (? . 10)) ((c def c (c (? . 0) q rc-superimpose)) c (? . 8)) ((c def c (c (? . 0) q thermometer)) q (18144 . 20)) ((c def c (c (? . 0) q pict-path?)) q (16621 . 3)) ((c def c (c (? . 0) q argb-pixels->pict)) q (32117 . 4)) ((c def c (c (? . 0) q pict-ascent)) c (? . 9)) ((c def c (c (? . 12) q balloon-point-x)) c (? . 17)) ((c def c (c (? . 3) q code-transformer?)) q (26763 . 3)) ((c def c (c (? . 3) q id-color)) q (27114 . 2)) ((c def c (c (? . 5) q hv-alternating)) q (30202 . 7)) ((c def c (c (? . 0) q clip-descent)) q (14725 . 3)) ((c def c (c (? . 0) q vl-append)) c (? . 2)) ((c def c (c (? . 0) q rtl-find)) c (? . 1)) ((c def c (c (? . 14) q face*)) q (21605 . 30)) ((c def c (c (? . 0) q text-style/c)) q (9601 . 2)) ((c def c (c (? . 0) q cb-superimpose)) c (? . 8)) ((c def c (c (? . 0) q struct:pict)) c (? . 9)) ((c def c (c (? . 0) q rt-superimpose)) c (? . 8)) ((c def c (c (? . 3) q code-pict-bottom-line-pict)) q (27227 . 3)) ((c def c (c (? . 0) q fast-start)) q (28344 . 3)) ((c def c (c (? . 3) q mzscheme-const-list)) q (25938 . 2)) ((c def c (c (? . 3) q typeset-code)) q (23745 . 3)) ((c def c (c (? . 0) q pin-arrow-line)) c (? . 15)) ((c def c (c (? . 12) q make-balloon)) c (? . 17)) ((c form c (c (? . 3) q code)) q (23806 . 2)) ((c def c (c (? . 0) q table)) q (11892 . 15)) ((c form c (c (? . 0) q scale/improve-new-text)) q (14185 . 3)) ((c def c (c (? . 0) q dc)) q (674 . 7)) ((c def c (c (? . 0) q file-icon)) q (16869 . 6)) ((c def c (c (? . 5) q binary-tidier)) q (29870 . 7)) ((c def c (c (? . 0) q panorama)) q (15112 . 3)) ((c def c (c (? . 0) q child-dy)) c (? . 4)) ((c def c (c (? . 6) q pict-convertible?)) q (33384 . 3)) ((c def c (c (? . 3) q current-code-line-sep)) q (24245 . 4)) ((c def c (c (? . 0) q lc-superimpose)) c (? . 8)) ((c def c (c (? . 0) q ltl-superimpose)) c (? . 8)) ((c def c (c (? . 0) q child)) c (? . 4)) ((c def c (c (? . 0) q frame)) q (1590 . 9)) ((c def c (c (? . 3) q current-keyword-color)) q (24513 . 4)) ((c def c (c (? . 3) q current-const-list)) q (25633 . 4)) ((c def c (c (? . 0) q pict->bitmap)) q (31806 . 4)) ((c def c (c (? . 0) q black-and-white)) q (14304 . 4))))
struct
(struct pict (draw
              width
              height
              ascent
              descent
              children
              panbox
              last)
    #:extra-constructor-name make-pict)
  draw : any/c
  width : real?
  height : real?
  ascent : real?
  descent : real?
  children : (listof child?)
  panbox : (or/c #f any/c)
  last : (or/c #f pict-path?)
struct
(struct child (pict dx dy sx sy sxy syx)
    #:extra-constructor-name make-child)
  pict : pict?
  dx : real?
  dy : real?
  sx : real?
  sy : real?
  sxy : real?
  syx : real?
procedure
(dc draw w h [a d]) -> pict?
  draw : (-> (is-a?/c dc<%>) real? real? any)
  w : real?
  h : real?
  a : real? = h
  d : real? = 0
procedure
(blank [size]) -> pict?
  size : real? = 0
(blank w h) -> pict?
  w : real?
  h : real?
(blank w a d) -> pict?
  w : real?
  a : real?
  d : real?
(blank w h a d) -> pict?
  w : real?
  h : real?
  a : real?
  d : real?
procedure
(text content [style size angle]) -> pict?
  content : string?
  style : text-style/c = null
  size : (integer-in 1 1024) = 12
  angle : real? = 0
procedure
(hline w h [#:segment seg-length]) -> pict?
  w : real?
  h : real?
  seg-length : (or/c #f real?) = #f
(vline w h [#:segment seg-length]) -> pict?
  w : real?
  h : real?
  seg-length : (or/c #f real?) = #f
procedure
(frame  pict                     
       [#:segment seg-length     
        #:color color            
        #:line-width width]) -> pict?
  pict : pict?
  seg-length : (or/c #f real?) = #f
  color : (or/c #f string? (is-a?/c color<%>)) = #f
  width : (or/c #f real?) = #f
procedure
(ellipse w h) -> pict?
  w : real?
  h : real?
(circle diameter) -> pict?
  diameter : real?
(filled-ellipse  w                                 
                 h                                 
                [#:draw-border? draw-border?]) -> pict?
  w : real?
  h : real?
  draw-border? : any/c = #t
(disk diameter [#:draw-border? draw-border?]) -> pict?
  diameter : (and/c rational? (not/c negative?))
  draw-border? : any/c = #t
procedure
(rectangle w h) -> pict?
  w : real?
  h : real?
(filled-rectangle  w                                 
                   h                                 
                  [#:draw-border? draw-border?]) -> pict?
  w : real?
  h : real?
  draw-border? : any/c = #t
procedure
(rounded-rectangle  w                   
                    h                   
                   [corner-radius       
                    #:angle angle]) -> pict?
  w : real?
  h : real?
  corner-radius : real? = -0.25
  angle : real? = 0
(filled-rounded-rectangle  w                                 
                           h                                 
                          [corner-radius                     
                           #:angle angle                     
                           #:draw-border? draw-border?]) -> pict?
  w : real?
  h : real?
  corner-radius : real? = -0.25
  angle : real? = 0
  draw-border? : any/c = #t
procedure
(bitmap img) -> pict
  img : (or/c path-string?
              (is-a?/c bitmap%)
              (is-a?/c image-snip%))
procedure
(arrow size radians) -> pict?
  size : real?
  radians : real?
(arrowhead size radians) -> pict?
  size : real?
  radians : real?
procedure
(pip-line dx dy size) -> pict?
  dx : real?
  dy : real?
  size : real?
(pip-arrow-line dx dy size) -> pict?
  dx : real?
  dy : real?
  size : real?
(pip-arrows-line dx dy size) -> pict?
  dx : real?
  dy : real?
  size : real?
procedure
(pin-line  pict                          
           src                           
           find-src                      
           dest                          
           find-dest                     
          [#:start-angle start-angle     
           #:end-angle end-angle         
           #:start-pull start-pull       
           #:end-pull end-pull           
           #:line-width line-width       
           #:color color                 
           #:alpha alpha                 
           #:style style                 
           #:under? under?])         -> pict?
  pict : pict?
  src : pict-path?
  find-src : (pict? pict-path? . -> . (values real? real?))
  dest : pict-path?
  find-dest : (pict? pict-path? . -> . (values real? real?))
  start-angle : (or/c real? #f) = #f
  end-angle : (or/c real? #f) = #f
  start-pull : real? = 1/4
  end-pull : real? = 1/4
  line-width : (or/c #f real?) = #f
  color : (or/c #f string? (is-a?/c color%)) = #f
  alpha : (real-in 0.0 1.0) = #f
  style : (one-of/c 'transparent 'solid 'xor 'hilite
                    'dot 'long-dash 'short-dash 'dot-dash
                    'xor-dot 'xor-long-dash 'xor-short-dash
                    'xor-dot-dash)
        = 'solid
  under? : any/c = #f
(pin-arrow-line  arrow-size                              
                 pict                                    
                 src                                     
                 find-src                                
                 dest                                    
                 find-dest                               
                [#:start-angle start-angle               
                 #:end-angle end-angle                   
                 #:start-pull start-pull                 
                 #:end-pull end-pull                     
                 #:line-width line-width                 
                 #:color color                           
                 #:alpha alpha                           
                 #:style style                           
                 #:under? under?                         
                 #:solid? solid?                         
                 #:hide-arrowhead? hide-arrowhead?]) -> pict?
  arrow-size : real?
  pict : pict?
  src : pict-path?
  find-src : (pict? pict-path? . -> . (values real? real?))
  dest : pict-path?
  find-dest : (pict? pict-path? . -> . (values real? real?))
  start-angle : (or/c real? #f) = #f
  end-angle : (or/c real? #f) = #f
  start-pull : real? = 1/4
  end-pull : real? = 1/4
  line-width : (or/c #f real?) = #f
  color : (or/c #f string? (is-a?/c color%)) = #f
  alpha : (real-in 0.0 1.0) = #f
  style : (one-of/c 'transparent 'solid 'xor 'hilite
                    'dot 'long-dash 'short-dash 'dot-dash
                    'xor-dot 'xor-long-dash 'xor-short-dash
                    'xor-dot-dash)
        = 'solid
  under? : any/c = #f
  solid? : any/c = #t
  hide-arrowhead? : any/c = #f
(pin-arrows-line  arrow-size                              
                  pict                                    
                  src                                     
                  find-src                                
                  dest                                    
                  find-dest                               
                 [#:start-angle start-angle               
                  #:end-angle end-angle                   
                  #:start-pull start-pull                 
                  #:end-pull end-pull                     
                  #:line-width line-width                 
                  #:color color                           
                  #:alpha alpha]                          
                  #:style style                           
                 [#:under? under?                         
                  #:solid? solid?                         
                  #:hide-arrowhead? hide-arrowhead?]) -> pict?
  arrow-size : real?
  pict : pict?
  src : pict-path?
  find-src : (pict? pict-path? . -> . (values real? real?))
  dest : pict-path?
  find-dest : (pict? pict-path? . -> . (values real? real?))
  start-angle : (or/c real? #f) = #f
  end-angle : (or/c real? #f) = #f
  start-pull : real? = 1/4
  end-pull : real? = 1/4
  line-width : (or/c #f real?) = #f
  color : (or/c #f string? (is-a?/c color%)) = #f
  alpha : (real-in 0.0 1.0) = #f
  style : (one-of/c 'transparent 'solid 'xor 'hilite
                    'dot 'long-dash 'short-dash 'dot-dash
                    'xor-dot 'xor-long-dash 'xor-short-dash
                    'xor-dot-dash)
  under? : any/c = #f
  solid? : any/c = #t
  hide-arrowhead? : any/c = #f
value
text-style/c : contract?
parameter
(bitmap-draft-mode) -> boolean?
(bitmap-draft-mode on?) -> void?
  on? : any/c
procedure
(vl-append [d] pict ...) -> pict?
  d : real? = 0.0
  pict : pict?
(vc-append [d] pict ...) -> pict?
  d : real? = 0.0
  pict : pict?
(vr-append [d] pict ...) -> pict?
  d : real? = 0.0
  pict : pict?
(ht-append [d] pict ...) -> pict?
  d : real? = 0.0
  pict : pict?
(htl-append [d] pict ...) -> pict?
  d : real? = 0.0
  pict : pict?
(hc-append [d] pict ...) -> pict?
  d : real? = 0.0
  pict : pict?
(hbl-append [d] pict ...) -> pict?
  d : real? = 0.0
  pict : pict?
(hb-append [d] pict ...) -> pict?
  d : real? = 0.0
  pict : pict?
procedure
(lt-superimpose pict ...) -> pict?
  pict : pict?
(ltl-superimpose pict ...) -> pict?
  pict : pict?
(lc-superimpose pict ...) -> pict?
  pict : pict?
(lbl-superimpose pict ...) -> pict?
  pict : pict?
(lb-superimpose pict ...) -> pict?
  pict : pict?
(ct-superimpose pict ...) -> pict?
  pict : pict?
(ctl-superimpose pict ...) -> pict?
  pict : pict?
(cc-superimpose pict ...) -> pict?
  pict : pict?
(cbl-superimpose pict ...) -> pict?
  pict : pict?
(cb-superimpose pict ...) -> pict?
  pict : pict?
(rt-superimpose pict ...) -> pict?
  pict : pict?
(rtl-superimpose pict ...) -> pict?
  pict : pict?
(rc-superimpose pict ...) -> pict?
  pict : pict?
(rbl-superimpose pict ...) -> pict?
  pict : pict?
(rb-superimpose pict ...) -> pict?
  pict : pict?
procedure
(pin-over base dx dy pict) -> pict?
  base : pict?
  dx : real?
  dy : real?
  pict : pict?
(pin-over base find-pict find pict) -> pict?
  base : pict?
  find-pict : pict-path?
  find : (pict? pict-path? . -> . (values real? real?))
  pict : pict?
procedure
(pin-under base dx dy pict) -> pict?
  base : pict?
  dx : real?
  dy : real?
  pict : pict?
(pin-under base find-pict find pict) -> pict?
  base : pict?
  find-pict : pict?
  find : (pict? pict? . -> . (values real? real?))
  pict : pict?
procedure
(table ncols          
       picts          
       col-aligns     
       row-aligns     
       col-seps       
       row-seps)  -> pict?
  ncols : exact-positive-integer?
  picts : (non-empty-listof pict?)
  col-aligns : (or/c (list*of (->* () #:rest (listof pict?) pict?))
                     (listof (->* () #:rest (listof pict?) pict?)))
  row-aligns : (or/c (list*of (->* () #:rest (listof pict?) pict?))
                     (listof (->* () #:rest (listof pict?) pict?)))
  col-seps : (or/c (list*of real?) (listof real?))
  row-seps : (or/c (list*of real?) (listof real?))
procedure
(scale pict factor) -> pict?
  pict : pict?
  factor : real?
(scale pict w-factor h-factor) -> pict?
  pict : pict?
  w-factor : real?
  h-factor : real?
procedure
(scale-to-fit pict size-pict) -> pict?
  pict : pict?
  size-pict : pict?
(scale-to-fit pict width height) -> pict?
  pict : pict?
  width : real?
  height : real?
procedure
(rotate pict theta) -> pict?
  pict : pict?
  theta : real?
procedure
(ghost pict) -> pict?
  pict : pict?
procedure
(linewidth w pict) -> pict?
  w : (or/c real? #f)
  pict : pict?
procedure
(linestyle style pict) -> pict?
  style : (one-of/c 'transparent 'solid 'xor 'hilite
                    'dot 'long-dash 'short-dash 'dot-dash
                    'xor-dot 'xor-long-dash 'xor-short-dash
                    'xor-dot-dash)
  pict : pict?
procedure
(colorize pict color) -> pict?
  pict : pict?
  color : (or/c string? (is-a?/c color%)
                (list/c byte? byte? byte?))
procedure
(cellophane pict opacity) -> pict?
  pict : pict?
  opacity : (real-in 0 1)
procedure
(clip pict) -> pict
  pict : pict?
procedure
(inset/clip pict amt) -> pict?
  pict : pict?
  amt : real?
(inset/clip pict h-amt v-amt) -> pict?
  pict : pict?
  h-amt : real?
  v-amt : real?
(inset/clip pict l-amt t-amt r-amt b-amt) -> pict?
  pict : pict?
  l-amt : real?
  t-amt : real?
  r-amt : real?
  b-amt : real?
syntax
(scale/improve-new-text pict-expr scale-expr)
(scale/improve-new-text pict-expr x-scale-expr y-scale-expr)
parameter
(black-and-white) -> boolean?
(black-and-white on?) -> void?
  on? : any/c
procedure
(inset pict amt) -> pict?
  pict : pict?
  amt : real?
(inset pict h-amt v-amt) -> pict?
  pict : pict?
  h-amt : real?
  v-amt : real?
(inset pict l-amt t-amt r-amt b-amt) -> pict?
  pict : pict?
  l-amt : real?
  t-amt : real?
  r-amt : real?
  b-amt : real?
procedure
(clip-descent pict) -> pict?
  pict : pict?
procedure
(lift-above-baseline pict amt) -> pict?
  pict : pict?
  amt : real?
procedure
(drop-below-ascent pict amt) -> pict?
  pict : pict?
  amt : real?
procedure
(baseless pict) -> pict?
  pict : pict?
procedure
(refocus pict sub-pict) -> pict?
  pict : pict?
  sub-pict : pict?
procedure
(panorama pict) -> pict?
  pict : pict?
procedure
(use-last pict sub-pict) -> pict?
  pict : pict?
  sub-pict : pict-path?
procedure
(use-last* pict sub-pict) -> pict?
  pict : pict?
  sub-pict : pict-path?
procedure
(lt-find pict find) -> real? real?
  pict : pict?
  find : pict-path?
(ltl-find pict find) -> real? real?
  pict : pict?
  find : pict-path?
(lc-find pict find) -> real? real?
  pict : pict?
  find : pict-path?
(lbl-find pict find) -> real? real?
  pict : pict?
  find : pict-path?
(lb-find pict find) -> real? real?
  pict : pict?
  find : pict-path?
(ct-find pict find) -> real? real?
  pict : pict?
  find : pict-path?
(ctl-find pict find) -> real? real?
  pict : pict?
  find : pict-path?
(cc-find pict find) -> real? real?
  pict : pict?
  find : pict-path?
(cbl-find pict find) -> real? real?
  pict : pict?
  find : pict-path?
(cb-find pict find) -> real? real?
  pict : pict?
  find : pict-path?
(rt-find pict find) -> real? real?
  pict : pict?
  find : pict-path?
(rtl-find pict find) -> real? real?
  pict : pict?
  find : pict-path?
(rc-find pict find) -> real? real?
  pict : pict?
  find : pict-path?
(rbl-find pict find) -> real? real?
  pict : pict?
  find : pict-path?
(rb-find pict find) -> real? real?
  pict : pict?
  find : pict-path?
procedure
(pict-path? v) -> boolean?
  v : any/c
procedure
(launder pict) -> pict?
  pict : pict?
procedure
(cloud w h [color]) -> pict?
  w : real?
  h : real?
  color : (or/c string? (is-a?/c color%)) = "gray"
procedure
(file-icon w h color [shaded?]) -> pict?
  w : real?
  h : real?
  color : (or/c string? (is-a?/c color%) any/c)
  shaded? : any/c = #f
procedure
(standard-fish  w                             
                h                             
               [#:direction direction         
                #:color color                 
                #:eye-color eye-color         
                #:open-mouth open-mouth]) -> pict?
  w : real?
  h : real?
  direction : (or/c 'left 'right) = 'left
  color : (or/c string? (is-a?/c color%)) = "blue"
  eye-color : (or/c string? (is-a?/c color%) #f) = "black"
  open-mouth : (or/c boolean? real?) = #f
procedure
(jack-o-lantern  size              
                [pumpkin-color     
                 face-color])  -> pict?
  size : real?
  pumpkin-color : (or/c string? (is-a?/c color%)) = "orange"
  face-color : (or/c string? (is-a?/c color%)) = "black"
procedure
(angel-wing w h left?) -> pict?
  w : real?
  h : real?
  left? : any/c
procedure
(desktop-machine scale [style]) -> pict?
  scale : real?
  style : (listof symbol?) = null
procedure
(thermometer [#:height-% height-%                             
              #:color-% color-%                               
              #:ticks ticks                                   
              #:start-color start-color                       
              #:end-color end-color                           
              #:top-circle-diameter top-circle-diameter       
              #:bottom-circle-diameter bottom-circle-diameter 
              #:stem-height stem-height                       
              #:mercury-inset mercury-inset])                 
 -> pict?
  height-% : (between/c 0 1) = 1
  color-% : (between/c 0 1) = height-%
  ticks : non-exact-negative-integer? = 4
  start-color : (or/c string? (is-a?/c color%)) = "lightblue"
  end-color : (or/c string? (is-a?/c color%)) = "lightcoral"
  top-circle-diameter : positive-real? = 40
  bottom-circle-diameter : positive-real? = 80
  stem-height : positive-real? = 180
  mercury-inset : positive-real? = 8
procedure
(wrap-balloon  pict                
               spike               
               dx                  
               dy                  
              [color               
               corner-radius]) -> balloon?
  pict : pict?
  spike : (or/c 'n 's 'e 'w 'ne 'se 'sw 'nw)
  dx : real?
  dy : real?
  color : (or/c string? (is-a?/c color%)) = balloon-color
  corner-radius : (and/c real? (not/c negative?)) = 32
procedure
(pip-wrap-balloon  pict                
                   spike               
                   dx                  
                   dy                  
                  [color               
                   corner-radius]) -> pict?
  pict : pict?
  spike : (or/c 'n 's 'e 'w 'ne 'se 'sw 'nw)
  dx : real?
  dy : real?
  color : (or/c string? (is-a?/c color%)) = balloon-color
  corner-radius : (and/c real? (not/c negative?)) = 32
procedure
(pin-balloon balloon base x y) -> pict?
  balloon : balloon?
  base : pict?
  x : real?
  y : real?
(pin-balloon balloon base at-pict find) -> pict?
  balloon : balloon?
  base : pict?
  at-pict : pict-path?
  find : (pict? pict-path? . -> . (values real? real?))
procedure
(balloon w h corner-radius spike dx dy [color]) -> balloon?
  w : real?
  h : real?
  corner-radius : (and/c real? (not/c negative?))
  spike : (or/c 'n 's 'e 'w 'ne 'se 'sw 'nw)
  dx : real?
  dy : real?
  color : (or/c string? (is-a?/c color%)) = balloon-color
procedure
(balloon? v) -> boolean?
  v : any/c
(make-balloon pict x y) -> balloon?
  pict : pict?
  x : real?
  y : real?
(balloon-pict balloon) -> pict?
  balloon : balloon?
(balloon-point-x balloon) -> real?
  balloon : balloon?
(balloon-point-y balloon) -> real?
  balloon : balloon?
value
balloon-color : (or/c string? (is-a?/c color%))
parameter
(balloon-enable-3d) -> boolean?
(balloon-enable-3d on?) -> void?
  on? : any/c
value
default-face-color : (or/c string (is-a?/c color%))
procedure
(face mood [color]) -> pict?
  mood : symbol?
  color : (or/c string (is-a?/c color%)) = default-face-color
procedure
(face*  eyebrow-kind                               
        mouth-kind                                 
        frown?                                     
        color                                      
        eye-inset                                  
        eyebrow-dy                                 
        pupil-dx                                   
        pupil-dy                                   
       [#:eyebrow-shading? eyebrow-on?             
        #:mouth-shading? mouth-on?                 
        #:eye-shading? eye-on?                     
        #:tongue-shading? tongue-on?               
        #:face-background-shading? face-bg-on?     
        #:teeth? teeth-on?])                   -> pict?
  eyebrow-kind : (or/c 'none 'normal 'worried 'angry)
  mouth-kind : (or/c 'plain 'smaller 'narrow 'medium 'large
                     'huge 'grimace 'oh 'tongue)
  frown? : any/c
  color : (or/c string (is-a?/c color%))
  eye-inset : real?
  eyebrow-dy : real?
  pupil-dx : real?
  pupil-dy : real?
  eyebrow-on? : any/c = #t
  mouth-on? : any/c = #t
  eye-on? : any/c = #t
  tongue-on? : any/c = #t
  face-bg-on? : any/c = #t
  teeth-on? : any/c = #t
procedure
(filled-flash  width              
               height             
              [n-points           
               spike-fraction     
               rotation])     -> pict?
  width : real?
  height : real?
  n-points : exact-positive-integer? = 10
  spike-fraction : (real-in 0 1) = 0.25
  rotation : real? = 0
procedure
(outline-flash  width              
                height             
               [n-points           
                spike-fraction     
                rotation])     -> pict?
  width : real?
  height : real?
  n-points : exact-positive-integer? = 10
  spike-fraction : (real-in 0 1) = 0.25
  rotation : real? = 0
procedure
(typeset-code stx) -> pict?
  stx : syntax?
syntax
(code datum ...)
parameter
(current-code-font) -> text-style/c
(current-code-font style) -> void?
  style : text-style/c
parameter
(current-code-tt) -> (string? . -> . pict?)
(current-code-tt proc) -> void?
  proc : (string? . -> . pict?)
parameter
(get-current-code-font-size) -> (-> exact-nonnegative-integer?)
(get-current-code-font-size proc) -> void?
  proc : (-> exact-nonnegative-integer?)
parameter
(current-code-line-sep) -> real?
(current-code-line-sep amt) -> void?
  amt : real?
parameter
(current-comment-color) -> (or/c string? (is-a?/c color%))
(current-comment-color color) -> void?
  color : (or/c string? (is-a?/c color%))
parameter
(current-keyword-color) -> (or/c string? (is-a?/c color%))
(current-keyword-color color) -> void?
  color : (or/c string? (is-a?/c color%))
parameter
(current-id-color) -> (or/c string? (is-a?/c color%))
(current-id-color color) -> void?
  color : (or/c string? (is-a?/c color%))
parameter
(current-literal-color) -> (or/c string? (is-a?/c color%))
(current-literal-color color) -> void?
  color : (or/c string? (is-a?/c color%))
parameter
(current-const-color) -> (or/c string? (is-a?/c color%))
(current-const-color color) -> void?
  color : (or/c string? (is-a?/c color%))
parameter
(current-base-color) -> (or/c string? (is-a?/c color%))
(current-base-color color) -> void?
  color : (or/c string? (is-a?/c color%))
parameter
(current-reader-forms) -> (listof symbol?)
(current-reader-forms syms) -> void?
  syms : (listof symbol?)
procedure
(code-align pict) -> pict?
  pict : pict?
parameter
(current-keyword-list) -> (listof string?)
(current-keyword-list names) -> void?
  names : (listof string?)
parameter
(current-const-list) -> (listof string?)
(current-const-list names) -> void?
  names : (listof string?)
parameter
(current-literal-list) -> (listof string?)
(current-literal-list names) -> void?
  names : (listof string?)
value
racket/base-const-list : (listof string?)
value
mzscheme-const-list : (listof string?)
parameter
(code-colorize-enabled) -> boolean?
(code-colorize-enabled on?) -> void?
  on? : any/c
parameter
(code-colorize-quote-enabled) -> boolean?
(code-colorize-quote-enabled on?) -> void?
  on? : any/c
parameter
(code-italic-underscore-enabled) -> boolean?
(code-italic-underscore-enabled on?) -> void?
  on? : any/c
parameter
(code-scripts-enabled) -> boolean?
(code-scripts-enabled on?) -> void?
  on? : any/c
syntax
(define-code code-id typeset-code-id)
(define-code code-id typeset-code-id escape-id)
procedure
(make-code-transformer proc-or-stx) -> code-transformer?
  proc-or-stx : (or/c (syntax? . -> . (or/c syntax? #f))
                      syntax?)
value
prop:code-transformer : struct-type-property?
procedure
(code-transformer? v) -> boolean?
  v : any/c
syntax
(define-exec-code (pict-id runnable-id string-id)
  datum ...)
syntax
(define-exec-code/scale scale-expr (pict-id runnable-id string-id)
  datum ...)
value
comment-color : (or/c string? (is-a?/c color%))
value
keyword-color : (or/c string? (is-a?/c color%))
value
id-color : (or/c string? (is-a?/c color%))
value
literal-color : (or/c string? (is-a?/c color%))
procedure
(code-pict-bottom-line-pict pict) -> (or/c pict? #f)
  pict : pict?
procedure
(pict->code-pict pict bl-pict) -> pict?
  pict : pict?
  bl-pict : (or/c pict? #f)
procedure
(fade-pict n p1 p2 [#:combine combine]) -> pict?
  n : (real-in 0.0 1.0)
  p1 : pict?
  p2 : pict?
  combine : (pict? pict? . -> . pict?) = cc-superimpose
procedure
(fade-around-pict n p1 make-p2) -> pict?
  n : (real-in 0.0 1.0)
  p1 : pict?
  make-p2 : (pict? . -> . pict?)
procedure
(slide-pict base p p-from p-to n) -> pict?
  base : pict?
  p : pict?
  p-from : pict?
  p-to : pict?
  n : (real-in 0.0 1.0)
procedure
(slide-pict/center base p p-from p-to n) -> pict?
  base : pict?
  p : pict?
  p-from : pict?
  p-to : pict?
  n : (real-in 0.0 1.0)
procedure
(sequence-animations gen ...) -> (-> (real-in 0.0 1.0) pict?)
  gen : (-> (real-in 0.0 1.0) pict?)
procedure
(reverse-animations gen ...) -> (-> (real-in 0.0 1.0) pict?)
  gen : (-> (real-in 0.0 1.0) pict?)
procedure
(fast-start n) -> (real-in 0.0 1.0)
  n : (real-in 0.0 1.0)
procedure
(fast-end n) -> (real-in 0.0 1.0)
  n : (real-in 0.0 1.0)
procedure
(fast-edges n) -> (real-in 0.0 1.0)
  n : (real-in 0.0 1.0)
procedure
(fast-middle n) -> (real-in 0.0 1.0)
  n : (real-in 0.0 1.0)
procedure
(split-phase n) -> (real-in 0.0 1.0) (real-in 0.0 1.0)
  n : (real-in 0.0 1.0)
procedure
(tree-layout [#:pict node-pict] child ...) -> tree-layout?
  node-pict : (or/c #f pict?) = #f
  child : (or/c tree-layout? tree-edge? #f)
procedure
(tree-edge  node                          
           [#:edge-color edge-color       
            #:edge-width edge-width]) -> tree-edge?
  node : tree-layout?
  edge-color : (or/c string?                     = "gray"
                     (is-a?/c color%)
                     (list/c byte? byte? byte?))
  edge-width : (or/c 'unspecified real? #f) = 'unspecified
procedure
(tree-layout? v) -> boolean?
  v : any/c
procedure
(binary-tree-layout? v) -> boolean?
  v : any/c
procedure
(tree-edge? v) -> boolean?
  v : any/c
procedure
(naive-layered  tree-layout                 
               [#:x-spacing x-spacing       
                #:y-spacing y-spacing]) -> pict?
  tree-layout : tree-layout?
  x-spacing : (or/c (and/c real? positive?) #f) = #f
  y-spacing : (or/c (and/c real? positive?) #f) = #f
procedure
(binary-tidier  tree-layout                 
               [#:x-spacing x-spacing       
                #:y-spacing y-spacing]) -> pict?
  tree-layout : binary-tree-layout?
  x-spacing : (or/c (and/c real? positive?) #f) = #f
  y-spacing : (or/c (and/c real? positive?) #f) = #f
procedure
(hv-alternating  tree-layout                 
                [#:x-spacing x-spacing       
                 #:y-spacing y-spacing]) -> pict?
  tree-layout : binary-tree-layout?
  x-spacing : (or/c (and/c real? positive?) #f) = #f
  y-spacing : (or/c (and/c real? positive?) #f) = #f
procedure
(hyperlinkize pict) -> pict?
  pict : pict?
procedure
(scale-color factor color) -> (is-a?/c color%)
  factor : real?
  color : (or/c string (is-a?/c color%))
procedure
(color-series dc              
              max-step        
              step-delta      
              start           
              end             
              proc            
              set-pen?        
              set-brush?) -> void?
  dc : (is-a?/c dc<%>)
  max-step : exact-nonnegative-integer?
  step-delta : (and/c exact? positive?)
  start : (or/c string? (is-a?/c color%))
  end : (or/c string? (is-a?/c color%))
  proc : (exact? . -> . any)
  set-pen? : any/c
  set-brush? : any/c
parameter
(dc-for-text-size) -> (or/c #f (is-a?/c dc<%>))
(dc-for-text-size dc) -> void?
  dc : (or/c #f (is-a?/c dc<%>))
parameter
(convert-bounds-padding)
 -> (list/c (>=/c 0) (>=/c 0) (>=/c 0) (>=/c 0))
(convert-bounds-padding padding) -> void?
  padding : (list/c (>=/c 0) (>=/c 0) (>=/c 0) (>=/c 0))
procedure
(draw-pict pict dc x y) -> void?
  pict : pict?
  dc : (is-a?/c dc<%>)
  x : real?
  y : real?
procedure
(pict->bitmap pict [smoothing]) -> (is-a?/c bitmap%)
  pict : pict?
  smoothing : (or/c 'unsmoothed 'smoothed 'aligned) = 'aligned
procedure
(pict->argb-pixels pict [smoothing]) -> bytes?
  pict : pict?
  smoothing : (or/c 'unsmoothed 'smoothed 'aligned) = 'aligned
procedure
(argb-pixels->pict bytes width) -> pict?
  bytes : bytes?
  width : exact-nonnegative-integer?
procedure
(make-pict-drawer pict)
 -> ((is-a?/c dc<%>) real? real? . -> . void?)
  pict : pict?
procedure
(show-pict  pict                           
           [w                              
            h]                             
            #:frame-x frame-x              
            #:frame-y frame-y              
            #:frame-style frame-style) -> void?
  pict : pict?
  w : (or/c #f exact-nonnegative-integer?) = #f
  h : (or/c #f exact-nonnegative-integer?) = #f
  frame-x : (or/c (integer-in -10000 10000) #f)
  frame-y : (or/c (integer-in -10000 10000) #f)
  frame-style : (listof (or/c 'no-resize-border 'no-caption
                              'no-system-menu 'hide-menu-bar
                              'toolbar-button 'float 'metal))
parameter
(current-expected-text-scale) -> (list/c real? real?)
(current-expected-text-scale scales) -> void?
  scales : (list/c real? real?)
value
prop:pict-convertible : struct-type-property?
value
prop:pict-convertible? : struct-type-property?
procedure
(pict-convertible? v) -> boolean?
  v : any/c
procedure
(pict-convert v) -> pict?
  v : pict-convertible?
