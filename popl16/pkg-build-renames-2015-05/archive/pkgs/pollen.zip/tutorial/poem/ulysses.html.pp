#lang pollen

<<<<<<< HEAD
<html>

<body>
<pre>

=======
>>>>>>> squash! earnest
"Ulysses" by Alfred Tennyson

It little profits that an idle king, 
By this still hearth, among these barren crags, 
Match'd with an aged wife, I mete and dole 
Unequal laws unto a savage race, 
That hoard, and sleep, and feed, and know not me. 

I cannot rest from travel: I will drink 
Life to the lees; all times I have enjoy'd 
Greatly, have suffer'd greatly, both with those 
That loved me, and alone; on shore, and when 
Thro' scudding drifts the rainy Hyades 
Vext the dim sea: I am become a name; 
For always roaming with a hungry heart 
Much have I seen and known; cities of men 
And manners, climates, councils, governments, 
Myself not least, but honour'd of them all; 
And drunk delight of battle with my peers, 
Far on the ringing plains of windy Troy, 
I am a part of all that I have met; 
Yet all experience is an arch wherethro' 
Gleams that untravell'd world, whose margin fades 
For ever and for ever when I move. 
How dull it is to pause, to make an end, 
To rust unburnish'd, not to shine in use! 
As tho' to breathe were life. Life piled on life 
Were all too little, and of one to me 
Little remains: but every hour is saved 
From that eternal silence, something more, 
A bringer of new things; and vile it were 
For some three suns to store and hoard myself, 
And this gray spirit yearning in desire 
To follow knowledge like a sinking star, 
Beyond the utmost bound of human thought. 

   This is my son, mine own Telemachus, 
To whom I leave the scepter and the isle— 
Well-loved of me, discerning to fulfil 
This labour, by slow prudence to make mild 
A rugged people, and thro' soft degrees 
Subdue them to the useful and the good. 
Most blameless is he, centred in the sphere 
Of common duties, decent not to fail 
In offices of tenderness, and pay 
Meet adoration to my household gods, 
When I am gone. He works his work, I mine. 

   There lies the port; the vessel puffs her sail: 
There gloom the dark broad seas. My mariners, 
Souls that have toil'd, and wrought, and thought with me— 
That ever with a frolic welcome took 
The thunder and the sunshine, and opposed 
Free hearts, free foreheads—you and I are old; 
Old age hath yet his honour and his toil; 
Death closes all: but something ere the end, 
Some work of noble note, may yet be done, 
Not unbecoming men that strove with Gods. 
The lights begin to twinkle from the rocks: 
The long day wanes: the slow moon climbs: the deep 
Moans round with many voices. Come, my friends, 
'Tis not too late to seek a newer world. 
Push off, and sitting well in order smite 
The sounding furrows; for my purpose holds 
To sail beyond the sunset, and the baths 
Of all the western stars, until I die. 
It may be that the gulfs will wash us down: 
It may be we shall touch the Happy Isles, 
And see the great Achilles, whom we knew. 
Tho' much is taken, much abides; and tho' 
We are not now that strength which in old days 
Moved earth and heaven; that which we are, we are; 
One equal temper of heroic hearts, 
Made weak by time and fate, but strong in will 
<<<<<<< HEAD
To strive, to seek, to find, and not to yield. 
=======
To strive, to seek, to find, and not to yield. 
>>>>>>> squash! earnest
