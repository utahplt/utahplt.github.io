13615
((3) 0 () 11 ((q lib "redex/pict.rkt") (q lib "redex/reduction-semantics.rkt") (q 35098 . 20) (q lib "redex/gui.rkt") (q 266 . 5) (q 8093 . 6) (q 13219 . 5) (q lib "redex/benchmark.rkt") (q 13354 . 5) (q 37270 . 5) (q 37770 . 3)) () (h ! (equal) ((c def c (c (? . 0) q rule-pict-info->side-condition-pict)) q (28583 . 5)) ((c def c (c (? . 0) q label-font-size)) q (32442 . 4)) ((c form c (c (? . 1) q define-relation)) q (8294 . 10)) ((c def c (c (? . 0) q rule-pict-info-label)) q (28349 . 3)) ((c def c (c (? . 3) q term-node-children)) q (21525 . 3)) ((c form c (c (? . 1) q ::=)) q (1848 . 2)) ((c def c (c (? . 1) q derivation-name)) c (? . 5)) ((c def c (c (? . 0) q render-lw)) q (36128 . 4)) ((c def c (c (? . 0) q arrow-space)) q (28796 . 4)) ((c form c (c (? . 1) q term-let)) q (738 . 8)) ((c def c (c (? . 0) q grammar-style)) q (31522 . 4)) ((c def c (c (? . 1) q apply-reduction-relation/tag-with-names)) q (4304 . 6)) ((c def c (c (? . 7) q run-gen-and-check/mods)) q (37409 . 9)) ((c def c (c (? . 1) q counterexample)) c (? . 6)) ((c def c (c (? . 0) q non-terminal-gap-space)) q (26934 . 4)) ((c def c (c (? . 0) q metafunction-pict-style)) q (29014 . 17)) ((c def c (c (? . 1) q coverage?)) q (10027 . 3)) ((c def c (c (? . 1) q make-exn:fail:redex:test)) c (? . 8)) ((c form c (c (? . 0) q judgment-form->pict)) q (26728 . 2)) ((c form c (c (? . 0) q metafunctions->pict)) q (26436 . 2)) ((c def c (c (? . 0) q set-lw-line!)) c (? . 2)) ((c form c (c (? . 0) q to-lw)) q (36052 . 2)) ((c form c (c (? . 1) q hole)) q (711 . 2)) ((c def c (c (? . 1) q plug)) q (1246 . 4)) ((c form c (c (? . 1) q redex-match?)) q (70 . 3)) ((c def c (c (? . 0) q set-lw-column!)) c (? . 2)) ((c def c (c (? . 0) q to-lw/stx)) q (36072 . 3)) ((c def c (c (? . 3) q dark-pen-color)) q (23022 . 4)) ((c form c (c (? . 1) q judgment-holds)) q (7939 . 5)) ((c form c (c (? . 1) q define-judgment-form)) q (6437 . 49)) ((c def c (c (? . 0) q render-language-nts)) q (26777 . 4)) ((c def c (c (? . 0) q language->pict)) q (25285 . 5)) ((c def c (c (? . 0) q current-text)) q (33337 . 4)) ((c def c (c (? . 0) q default-font-size)) q (32837 . 4)) ((c def c (c (? . 1) q default-attempt-size)) q (14571 . 3)) ((c def c (c (? . 0) q set-lw-e!)) c (? . 2)) ((c form c (c (? . 1) q reduction-relation)) q (2408 . 36)) ((c def c (c (? . 3) q term-node-set-color!)) q (21785 . 4)) ((c def c (c (? . 0) q reduction-rule-style/c)) q (27950 . 2)) ((c form c (c (? . 1) q O)) q (8285 . 2)) ((c def c (c (? . 3) q term-node-set-position!)) q (22181 . 5)) ((c def c (c (? . 0) q just-after)) q (36490 . 4)) ((c def c (c (? . 1) q bind?)) c (? . 4)) ((c form c (c (? . 1) q test-predicate)) q (9742 . 2)) ((c def c (c (? . 1) q caching-enabled?)) q (383 . 4)) ((c def c (c (? . 0) q render-term/pretty-write)) q (24389 . 9)) ((q def ((lib "redex/benchmark/models/all-info.rkt") all-mods)) q (38176 . 3)) ((c form c (c (? . 0) q relation->pict)) q (26689 . 2)) ((c def c (c (? . 0) q default-style)) q (32337 . 4)) ((c form c (c (? . 1) q term-match/single)) q (1181 . 2)) ((c def c (c (? . 3) q light-brush-color)) q (23493 . 4)) ((c def c (c (? . 1) q bind-name)) c (? . 4)) ((c def c (c (? . 1) q redex-pseudo-random-generator)) q (14793 . 4)) ((c form c (c (? . 1) q define-union-language)) q (2137 . 5)) ((c def c (c (? . 3) q term-node-expr)) q (22119 . 3)) ((c def c (c (? . 3) q term-node-labels)) q (21690 . 3)) ((c def c (c (? . 0) q rule-pict-info-arrow)) q (28054 . 3)) ((c def c (c (? . 1) q derivation-term)) c (? . 5)) ((c def c (c (? . 1) q language-nts)) q (2266 . 3)) ((c form c (c (? . 0) q render-metafunction)) q (25953 . 2)) ((c form c (c (? . 1) q test-->>)) q (8920 . 11)) ((c def c (c (? . 3) q term-node-color)) q (21920 . 3)) ((c def c (c (? . 0) q metafunction-font-size)) q (32601 . 6)) ((c form c (c (? . 1) q -->)) q (5040 . 2)) ((c def c (c (? . 1) q struct:counterexample)) c (? . 6)) ((c def c (c (? . 3) q traces/ps)) q (17389 . 45)) ((c form c (c (? . 1) q fresh)) q (5051 . 2)) ((c form c (c (? . 1) q extend-reduction-relation)) q (3725 . 2)) ((c form c (c (? . 0) q metafunction->pict)) q (26372 . 2)) ((c def c (c (? . 1) q check-redudancy)) q (558 . 4)) ((c def c (c (? . 0) q lw-unq?)) c (? . 2)) ((c form c (c (? . 1) q I)) q (8276 . 2)) ((c form c (c (? . 7) q define-rewrite/compose)) q (36749 . 2)) ((c def c (c (? . 1) q relation-coverage)) q (10082 . 4)) ((c form c (c (? . 1) q build-derivations)) q (8056 . 2)) ((c form c (c (? . 1) q redex-let)) q (941 . 2)) ((c def c (c (? . 3) q stepper/seed)) q (20039 . 7)) ((c form c (c (? . 0) q with-unquote-rewriter)) q (34597 . 2)) ((c def c (c (? . 0) q build-lw)) q (35683 . 10)) ((c def c (c (? . 1) q exn:fail:redex:test-source)) c (? . 8)) ((c def c (c (? . 3) q term-node-parents)) q (21608 . 3)) ((c def c (c (? . 0) q where-combine)) q (34432 . 4)) ((c def c (c (? . 0) q make-lw)) c (? . 2)) ((c def c (c (? . 3) q stepper)) q (19787 . 7)) ((c def c (c (? . 1) q covered-cases)) q (10213 . 3)) ((c form c (c (? . 1) q in-domain?)) q (6385 . 2)) ((c def c (c (? . 3) q term-node-width)) q (22454 . 3)) ((c def c (c (? . 0) q lw-line-span)) c (? . 2)) ((c def c (c (? . 1) q match?)) q (142 . 3)) ((c def c (c (? . 1) q exn:fail:redex:test?)) c (? . 8)) ((c def c (c (? . 0) q lw-column-span)) c (? . 2)) ((c def c (c (? . 3) q reduction-steps-cutoff)) q (22641 . 4)) ((c def c (c (? . 0) q metafunction-style)) q (31833 . 4)) ((c def c (c (? . 3) q dark-brush-color)) q (23177 . 4)) ((c def c (c (? . 1) q struct:derivation)) c (? . 5)) ((c form c (c (? . 1) q define-term)) q (1084 . 2)) ((c form c (c (? . 1) q with)) q (5064 . 2)) ((c def c (c (? . 1) q make-counterexample)) c (? . 6)) ((c def c (c (? . 0) q render-reduction-relation)) q (25469 . 8)) ((c form c (c (? . 1) q check-reduction-relation)) q (13525 . 15)) ((c def c (c (? . 0) q render-reduction-relation-rules)) q (27325 . 11)) ((c def c (c (? . 0) q extend-language-show-extended-order)) q (27174 . 4)) ((c def c (c (? . 1) q exn:fail:redex:generation-failure?)) q (14962 . 3)) ((c def c (c (? . 0) q lw-e)) c (? . 2)) ((c def c (c (? . 0) q horizontal-bar-spacing)) q (33893 . 5)) ((c def c (c (? . 0) q white-square-bracket)) q (30004 . 4)) ((c form c (c (? . 1) q define-metafunction/extension)) q (6243 . 5)) ((c def c (c (? . 1) q reduction-relation->rule-names)) q (3902 . 3)) ((c def c (c (? . 1) q test-results)) q (9773 . 2)) ((c def c (c (? . 1) q struct:exn:fail:redex:test)) c (? . 8)) ((c def c (c (? . 3) q light-pen-color)) q (23336 . 4)) ((c def c (c (? . 0) q set-lw-line-span!)) c (? . 2)) ((c def c (c (? . 1) q depth-dependent-order?)) q (12827 . 5)) ((c def c (c (? . 3) q traces)) q (15042 . 45)) ((c form c (c (? . 0) q with-compound-rewriter)) q (34819 . 4)) ((c def c (c (? . 7) q run-results-tries)) c (? . 9)) ((c def c (c (? . 0) q curly-quotes-for-strings)) q (33222 . 4)) ((c def c (c (? . 3) q dark-text-color)) q (23654 . 4)) ((c def c (c (? . 7) q run-results)) c (? . 9)) ((c def c (c (? . 7) q struct:bmark-log-data)) c (? . 10)) ((c def c (c (? . 7) q run-results-time)) c (? . 9)) ((c form c (c (? . 1) q check-metafunction)) q (14034 . 15)) ((c def c (c (? . 0) q render-language)) q (25025 . 6)) ((c def c (c (? . 3) q light-text-color)) q (23811 . 4)) ((c def c (c (? . 3) q show-derivations)) q (20329 . 11)) ((c form c (c (? . 1) q redex-generator)) q (13009 . 7)) ((c form c (c (? . 1) q compatible-closure)) q (4001 . 2)) ((c def c (c (? . 1) q apply-reduction-relation*)) q (4514 . 10)) ((c def c (c (? . 0) q term->pict/pretty-write)) q (24703 . 9)) ((c def c (c (? . 0) q non-terminal-superscript-style)) q (32198 . 4)) ((c def c (c (? . 1) q variables-not-in)) q (1425 . 4)) ((c def c (c (? . 0) q linebreaks)) q (30346 . 4)) ((c def c (c (? . 7) q bmark-log-data)) c (? . 10)) ((c def c (c (? . 0) q reduction-relation-rule-separation)) q (33000 . 5)) ((c form c (c (? . 1) q redex-let*)) q (1012 . 2)) ((c def c (c (? . 1) q derivation?)) c (? . 5)) ((c def c (c (? . 1) q bind)) c (? . 4)) ((c form c (c (? . 1) q make-coverage)) q (9940 . 5)) ((c def c (c (? . 1) q default-equiv)) q (9809 . 4)) ((c def c (c (? . 7) q benchmark-logging-to)) q (37827 . 4)) ((c def c (c (? . 0) q lw-column)) c (? . 2)) ((c def c (c (? . 3) q pretty-print-parameters)) q (23970 . 4)) ((c form c (c (? . 1) q define-extended-language)) q (1859 . 7)) ((c def c (c (? . 1) q reduction-relation?)) q (4129 . 3)) ((c def c (c (? . 0) q rule-pict-style)) q (27821 . 4)) ((c def c (c (? . 1) q make-bind)) c (? . 4)) ((c def c (c (? . 0) q rule-pict-info-computed-label)) q (28462 . 4)) ((c form c (c (? . 1) q define-language)) q (1594 . 7)) ((c def c (c (? . 0) q literal-style)) q (31728 . 4)) ((c form c (c (? . 1) q redex-match)) q (0 . 3)) ((c def c (c (? . 1) q counterexample?)) c (? . 6)) ((c def c (c (? . 1) q make-derivation)) c (? . 5)) ((c def c (c (? . 0) q set-lw-column-span!)) c (? . 2)) ((c def c (c (? . 0) q set-lw-metafunction?!)) c (? . 2)) ((c form c (c (? . 1) q generate-term)) q (10313 . 35)) ((c form c (c (? . 1) q test-->>E)) q (9725 . 2)) ((c def c (c (? . 7) q bmark-log-data-data)) c (? . 10)) ((c def c (c (? . 0) q delimit-ellipsis-arguments?)) q (29879 . 4)) ((c def c (c (? . 3) q term-node-height)) q (22519 . 3)) ((c def c (c (? . 1) q match-bindings)) q (198 . 3)) ((c def c (c (? . 1) q bind-exp)) c (? . 4)) ((c def c (c (? . 1) q default-check-attempts)) q (14656 . 4)) ((c def c (c (? . 0) q rule-pict-info-lhs)) q (28155 . 3)) ((c def c (c (? . 3) q derivation/ps)) q (20911 . 13)) ((c def c (c (? . 1) q derivation-subs)) c (? . 5)) ((c def c (c (? . 1) q derivation)) c (? . 5)) ((c def c (c (? . 3) q initial-font-size)) q (22756 . 4)) ((c form c (c (? . 0) q render-relation)) q (26489 . 2)) ((c form c (c (? . 1) q term-match)) q (1123 . 2)) ((c def c (c (? . 1) q exn:fail:redex?)) q (1533 . 3)) ((c def c (c (? . 0) q set-arrow-pict!)) q (33564 . 4)) ((c def c (c (? . 1) q current-traced-metafunctions)) q (8588 . 4)) ((c def c (c (? . 7) q bmark-log-data?)) c (? . 10)) ((c def c (c (? . 0) q label-space)) q (28905 . 4)) ((c def c (c (? . 1) q struct:bind)) c (? . 4)) ((c form c (c (? . 7) q define-rewrite)) q (36594 . 6)) ((c def c (c (? . 0) q rule-pict-info?)) q (27993 . 3)) ((c def c (c (? . 3) q term-node?)) q (22585 . 3)) ((c def c (c (? . 1) q exn:fail:redex:test)) c (? . 8)) ((c def c (c (? . 0) q reduction-relation->pict)) q (25795 . 4)) ((c def c (c (? . 0) q default-white-square-bracket)) q (30264 . 3)) ((c def c (c (? . 0) q non-terminal-style)) q (31948 . 4)) ((c def c (c (? . 0) q metafunction-cases)) q (30483 . 9)) ((c def c (c (? . 0) q lw->pict)) q (36257 . 4)) ((c form c (c (? . 1) q test-equal)) q (8791 . 7)) ((c form c (c (? . 1) q context-closure)) q (4069 . 2)) ((c def c (c (? . 1) q set-cache-size!)) q (482 . 3)) ((c def c (c (? . 1) q compiled-lang?)) q (2348 . 3)) ((c def c (c (? . 3) q default-pretty-printer)) q (24111 . 6)) ((c def c (c (? . 3) q term-node-y)) q (22393 . 3)) ((c form c (c (? . 1) q in-hole)) q (723 . 2)) ((c def c (c (? . 0) q label-style)) q (31421 . 4)) ((c def c (c (? . 0) q metafunction-up/down-indent)) q (29750 . 4)) ((c def c (c (? . 3) q term-node-x)) q (22332 . 3)) ((c form c (c (? . 0) q render-judgment-form)) q (26579 . 2)) ((c form c (c (? . 0) q term->pict)) q (24357 . 2)) ((c def c (c (? . 1) q union-reduction-relations)) q (3801 . 3)) ((c def c (c (? . 0) q lw-line)) c (? . 2)) ((c def c (c (? . 1) q counterexample-term)) c (? . 6)) ((c def c (c (? . 0) q lw?)) c (? . 2)) ((c def c (c (? . 0) q relation-clauses-combine)) q (34075 . 5)) ((c def c (c (? . 7) q run-results?)) c (? . 9)) ((c form c (c (? . 0) q render-metafunctions)) q (26091 . 9)) ((c form c (c (? . 1) q define-extended-judgment-form)) q (7842 . 4)) ((c form c (c (? . 1) q redex-check)) q (11900 . 26)) ((c form c (c (? . 1) q test-->)) q (9191 . 9)) ((c def c (c (? . 0) q struct:lw)) c (? . 2)) ((c def c (c (? . 0) q lw-metafunction?)) c (? . 2)) ((c def c (c (? . 7) q struct:run-results)) c (? . 9)) ((c form c (c (? . 1) q define-metafunction)) q (5076 . 30)) ((c def c (c (? . 3) q initial-char-width)) q (22857 . 4)) ((c def c (c (? . 0) q lw)) c (? . 2)) ((c def c (c (? . 0) q just-before)) q (36385 . 4)) ((c form c (c (? . 1) q term)) q (661 . 3)) ((c def c (c (? . 1) q variable-not-in)) q (1340 . 4)) ((c form c (c (? . 0) q with-atomic-rewriter)) q (34646 . 4)) ((c form c (c (? . 7) q include/rewrite)) q (36797 . 2)) ((c def c (c (? . 0) q homemade-white-square-bracket)) q (30181 . 3)) ((c def c (c (? . 0) q extend-language-show-union)) q (27051 . 4)) ((c def c (c (? . 0) q set-lw-unq?!)) c (? . 2)) ((c def c (c (? . 0) q judgment-form-cases)) q (30945 . 11)) ((c def c (c (? . 0) q rule-pict-info-rhs)) q (28252 . 3)) ((c def c (c (? . 0) q where-make-prefix-pict)) q (34269 . 4)) ((c def c (c (? . 0) q white-bracket-sizing)) q (33663 . 5)) ((c def c (c (? . 1) q apply-reduction-relation)) q (4194 . 4)) ((c def c (c (? . 7) q run-results-cexps)) c (? . 9)) ((c def c (c (? . 1) q current-cache-all?)) q (4923 . 4)) ((c form c (c (? . 0) q with-compound-rewriters)) q (34976 . 3)) ((c def c (c (? . 3) q term-node-set-red!)) q (22023 . 4)) ((c def c (c (? . 0) q non-terminal-subscript-style)) q (32063 . 4)) ((c form c (c (? . 0) q render-term)) q (24292 . 3)) ((c form c (c (? . 1) q test-->>∃)) q (9416 . 10)) ((c def c (c (? . 7) q run-gen-and-check)) q (36853 . 11)) ((c def c (c (? . 7) q bmark-log-directory)) q (37939 . 6)) ((c def c (c (? . 0) q arrow->pict)) q (33500 . 3)) ((c def c (c (? . 0) q paren-style)) q (31627 . 4)) ((c def c (c (? . 1) q exn:fail:redex:test-term)) c (? . 8))))
syntax
(redex-match lang pattern any)
(redex-match lang pattern)
syntax
(redex-match? lang pattern any)
(redex-match? lang pattern)
procedure
(match? val) -> boolean?
  val : any/c
procedure
(match-bindings m) -> (listof bind?)
  m : match?
struct
(struct bind (name exp)
    #:extra-constructor-name make-bind)
  name : symbol?
  exp : any/c
parameter
(caching-enabled?) -> boolean?
(caching-enabled? on?) -> void?
  on? : boolean?
procedure
(set-cache-size! size) -> void?
  size : positive-integer?
parameter
(check-redudancy) -> boolean?
(check-redudancy check?) -> void?
  check? : boolean?
syntax
(term term)
(term term #:lang lang-id)
syntax
hole
syntax
in-hole
syntax
(term-let ([tl-pat expr] ...) body)
 
    tl-pat = identifier
           | (tl-pat-ele ...)
              
tl-pat-ele = tl-pat
           | tl-pat ... ; a literal ellipsis
syntax
(redex-let language ([pattern expression] ...) body ...+)
syntax
(redex-let* language ([pattern expression] ...) body ...+)
syntax
(define-term identifier term)
syntax
(term-match language [pattern expression] ...)
syntax
(term-match/single language [pattern expression] ...)
procedure
(plug context expression) -> any
  context : any/c
  expression : any/c
procedure
(variable-not-in t var) -> symbol?
  t : any/c
  var : symbol?
procedure
(variables-not-in t vars) -> (listof symbol?)
  t : any/c
  vars : (listof symbol?)
procedure
(exn:fail:redex? v) -> boolean?
  v : any/c
syntax
(define-language lang-name
  non-terminal-def ...)
 
non-terminal-def = (non-terminal-name ...+ ::= pattern ...+)
                 | (non-terminal-name pattern ...+)
                 | ((non-terminal-name ...+) pattern ...+)
syntax
::=
syntax
(define-extended-language extended-lang base-lang
  non-terminal-def ...)
 
non-terminal-def = (non-terminal-name ...+ ::= pattern ...+)
                 | (non-terminal-name pattern ...+)
                 | ((non-terminal-name ...+) pattern ...+)
syntax
(define-union-language L base/prefix-lang ...)
 
base/prefix-lang = lang-id
                 | (prefix lang-id)
procedure
(language-nts lang) -> (listof symbol?)
  lang : compiled-lang?
procedure
(compiled-lang? l) -> boolean?
  l : any/c
syntax
(reduction-relation language domain base-arrow
                    reduction-case ...
                    shortcuts)
 
        domain = 
               | #:domain pattern
                  
    base-arrow = 
               | #:arrow base-arrow-name
                  
reduction-case = (arrow-name pattern term red-extras ...)
                  
    red-extras = rule-name
               | (fresh fresh-clause ...)
               | (side-condition racket-expression)
               | (where pattern term)
               | (judgment-holds (judgment-form-id pat/term ...))
               | (side-condition/hidden racket-expression)
               | (where/hidden pattern term)
                  
     shortcuts = 
               | with shortcut ...
                  
      shortcut = [(old-arrow-name pattern term)
                  (new-arrow-name identifier identifier)]
                  
     rule-name = identifier
               | string
               | (computed-name racket-expression)
                  
  fresh-clause = var
               | ((var1 ...) (var2 ...))
                  
      pat/term = pattern
               | term
syntax
(extend-reduction-relation reduction-relation language more ...)
procedure
(union-reduction-relations r ...) -> reduction-relation?
  r : reduction-relation?
procedure
(reduction-relation->rule-names r) -> (listof symbol?)
  r : reduction-relation?
syntax
(compatible-closure reduction-relation lang non-terminal)
syntax
(context-closure reduction-relation lang pattern)
procedure
(reduction-relation? v) -> boolean?
  v : any/c
procedure
(apply-reduction-relation r t) -> (listof any/c)
  r : reduction-relation?
  t : any/c
procedure
(apply-reduction-relation/tag-with-names r  
                                         t) 
 -> (listof (list/c (union false/c string?) any/c))
  r : reduction-relation?
  t : any/c
procedure
(apply-reduction-relation*  r                       
                            t                       
                           [#:cache-all? cache-all? 
                            #:stop-when stop-when]) 
 -> (listof any/c)
  r : reduction-relation?
  t : any/c
  cache-all? : boolean? = (current-cache-all?)
  stop-when : (-> any/c any) = (λ (x) #f)
parameter
(current-cache-all?) -> boolean?
(current-cache-all? cache-all?) -> void?
  cache-all? : boolean?
syntax
-->
syntax
fresh
syntax
with
syntax
(define-metafunction language
  metafunction-contract
  [(name pattern ...) term metafunction-extras ...]
  ...)
 
metafunction-contract = 
                      | id : pattern-sequence ... -> range
                        maybe-pre-condition
                        maybe-post-condition
                         
  maybe-pre-condition = #:pre term
                      | 
                         
 maybe-post-condition = #:post term
                      | 
                         
                range = pattern
                      | pattern or range
                      | pattern ∨ range
                      | pattern ∪ range
                         
  metafunction-extras = (side-condition racket-expression)
                      | (side-condition/hidden racket-expression)
                      | (where pat term)
                      | (where/hidden pat term)
                      | (judgment-holds
                         (judgment-form-id pat/term ...))
                      | (clause-name name)
                      | or term
syntax
(define-metafunction/extension f language
  metafunction-contract
  [(g pattern ...) term metafunction-extras ...]
  ...)
syntax
(in-domain? (metafunction-name term ...))
syntax
(define-judgment-form language
  mode-spec
  contract-spec
  invariant-spec
  rule rule ...)
 
     mode-spec = #:mode (form-id pos-use ...)
                  
 contract-spec = 
               | #:contract (form-id pattern-sequence ...)
                  
invariant-spec = #:inv term
               | 
                  
       pos-use = I
               | O
                  
          rule = [premise
                  ...
                  dashes rule-name
                  conclusion]
               | [conclusion
                  premise
                  ...
                  rule-name]
                  
    conclusion = (form-id pat/term ...)
                  
       premise = (judgment-form-id pat/term ...) maybe-ellipsis
               | (where pattern term)
               | (where/hidden pattern term)
               | (side-condition term)
               | (side-condition/hidden term)
                  
     rule-name = 
               | string
               | non-ellipsis-non-hypens-var
                  
      pat/term = pattern
               | term
                  
maybe-ellipsis = 
               | ...
                  
        dashes = ---
               | ----
               | -----
               | etc.
syntax
(define-extended-judgment-form language judgment-form-id
  option ...
  rule ...)
syntax
(judgment-holds judgment)
(judgment-holds judgment term)
 
judgment = (judgment-form-id pat/term ...)
syntax
(build-derivations judgment)
struct
(struct derivation (term name subs)
    #:extra-constructor-name make-derivation)
  term : any/c
  name : (or/c string? #f)
  subs : (listof derivation?)
syntax
I
syntax
O
syntax
(define-relation language
  relation-contract
  [(name pattern ...)
   term ...
   metafunction-extras ...] ...)
 
relation-contract = 
                  | form-id ⊂ pattern x ... x pattern
                  | form-id ⊆ pattern × ... × pattern
parameter
(current-traced-metafunctions) -> (or/c 'all (listof symbol?))
(current-traced-metafunctions traced-metafunctions) -> void?
  traced-metafunctions : (or/c 'all (listof symbol?))
syntax
(test-equal e1 e2 option)
 
option = #:equiv pred-expr
       | 
 
  pred-expr : (-> any/c any/c any/c)
syntax
(test-->> rel-expr option ... e1-expr e2-expr ...)
 
option = #:cycles-ok
       | #:equiv pred-expr
       | #:pred pred-expr
 
  rel-expr : reduction-relation?
  pred-expr : (--> any/c any)
  e1-expr : any/c
  e2-expr : any/c
syntax
(test--> rel-expr option ... e1-expr e2-expr ...)
 
option = #:equiv pred-expr
 
  rel-expr : reduction-relation?
  pred-expr : (--> any/c any/c any/c)
  e1-expr : any/c
  e2-expr : any/c
syntax
(test-->>∃ option ... rel-expr start-expr goal-expr)
 
option = #:steps steps-expr
 
  rel-expr : reduction-relation?
  start-expr : any/c
  goal-expr : (or/c (-> any/c any/c)
                    (not/c procedure?))
  steps-expr : (or/c natural-number/c +inf.0)
syntax
test-->>E
syntax
(test-predicate p? e)
procedure
(test-results) -> void?
parameter
(default-equiv) -> (-> any/c any/c any/c)
(default-equiv equiv) -> void?
  equiv : (-> any/c any/c any/c)
syntax
(make-coverage subject)
 
subject = metafunction
        | relation-expr
procedure
(coverage? v) -> boolean?
  v : any/c
parameter
(relation-coverage) -> (listof coverage?)
(relation-coverage tracked) -> void?
  tracked : (listof coverage?)
procedure
(covered-cases c) -> (listof (cons/c string? natural-number/c))
  c : coverage?
syntax
(generate-term from-pattern)
(generate-term from-judgment-form)
(generate-term from-metafunction)
(generate-term from-reduction-relation)
 
           from-pattern = language pattern size-expr kw-args ...
                        | language pattern
                        | language pattern #:i-th index-expr
                        | language pattern #:i-th
                           
     from-judgment-form = language #:satisfying
                          (judgment-form-id pattern ...)
                        | language #:satisfying
                          (judgment-form-id pattern ...)
                          size-expr
                           
      from-metafunction = language #:satisfying
                          (metafunction-id pattern ...) = pattern
                        | language #:satisfying
                          (metafunction-id pattern ...) = pattern
                          size-expr
                        | #:source metafunction size-expr kw-args
                        | #:source metafunction
                           
from-reduction-relation = #:source reduction-relation-expr
                          size-expr kw-args ...
                        | #:source reduction-relation-expr
                           
                kw-args = #:attempt-num attempts-expr
                        | #:retries retries-expr
 
  size-expr : natural-number/c
  attempt-num-expr : natural-number/c
  retries-expr : natural-number/c
syntax
(redex-check template property-expr kw-arg ...)
 
template = language pattern
         | language pattern #:enum
         | language #:satisfying
           (judgment-form-id pattern ...)
         | language #:satisfying
           (metafunction-id pattern ...) = pattern
            
  kw-arg = #:attempts attempts-expr
         | #:source metafunction
         | #:source relation-expr
         | #:retries retries-expr
         | #:print? print?-expr
         | #:attempt-size attempt-size-expr
         | #:prepare prepare-expr
         | #:keep-going? keep-going?-expr
 
  property-expr : any/c
  attempts-expr : natural-number/c
  relation-expr : reduction-relation?
  retries-expr : natural-number/c
  print?-expr : any/c
  attempt-size-expr : (-> natural-number/c natural-number/c)
  prepare-expr : (-> any/c any/c)
parameter
(depth-dependent-order?) -> (or/c boolean? 'random)
(depth-dependent-order? depth-dependent) -> void?
  depth-dependent : (or/c boolean? 'random)
 = 'random
syntax
(redex-generator language-id satisfying size-expr)
 
satisfying = (judgment-form-id pattern ...)
           | (metafunction-id pattern ...) = pattern
 
  size-expr : natural-number/c
struct
(struct counterexample (term)
    #:extra-constructor-name make-counterexample
    #:transparent)
  term : any/c
struct
(struct exn:fail:redex:test exn:fail:redex (source term)
    #:extra-constructor-name make-exn:fail:redex:test)
  source : exn:fail?
  term : any/c
syntax
(check-reduction-relation relation property kw-args ...)
 
kw-arg = #:attempts attempts-expr
       | #:retries retries-expr
       | #:print? print?-expr
       | #:attempt-size attempt-size-expr
       | #:prepare prepare-expr
 
  property : (-> any/c any/c)
  attempts-expr : natural-number/c
  retries-expr : natural-number/c
  print?-expr : any/c
  attempt-size-expr : (-> natural-number/c natural-number/c)
  prepare-expr : (-> any/c any/c)
syntax
(check-metafunction metafunction property kw-args ...)
 
kw-arg = #:attempts attempts-expr
       | #:retries retries-expr
       | #:print? print?-expr
       | #:attempt-size attempt-size-expr
       | #:prepare prepare-expr
 
  property : (-> (listof any/c) any/c)
  attempts-expr : natural-number/c
  retries-expr : natural-number/c
  print?-expr : any/c
  attempt-size-expr : (-> natural-number/c natural-number/c)
  prepare-expr : (-> (listof any/c) (listof any/c))
procedure
(default-attempt-size n) -> natural-number/c
  n : natural-number/c
parameter
(default-check-attempts) -> natural-number/c
(default-check-attempts attempts) -> void?
  attempts : natural-number/c
parameter
(redex-pseudo-random-generator) -> pseudo-random-generator?
(redex-pseudo-random-generator generator) -> void?
  generator : pseudo-random-generator?
procedure
(exn:fail:redex:generation-failure? v) -> boolean?
  v : any/c
procedure
(traces  reductions                                        
         expr                                              
        [#:multiple? multiple?                             
         #:reduce reduce                                   
         #:pred pred                                       
         #:pp pp                                           
         #:colors colors                                   
         #:racket-colors? racket-colors?                   
         #:scheme-colors? scheme-colors?                   
         #:filter term-filter                              
         #:x-spacing x-spacing                             
         #:y-spacing y-spacing                             
         #:layout layout                                   
         #:edge-labels? edge-labels?                       
         #:edge-label-font edge-label-font                 
         #:graph-pasteboard-mixin graph-pasteboard-mixin]) 
 -> void?
  reductions : reduction-relation?
  expr : (or/c any/c (listof any/c))
  multiple? : boolean? = #f
  reduce : (-> reduction-relation? any/c
               (listof (list/c (union false/c string?) any/c)))
         = apply-reduction-relation/tag-with-names
  pred : (or/c (-> sexp any)             = (λ (x) #t)
               (-> sexp term-node? any))
  pp : (or/c (any -> string)
             (any output-port number (is-a?/c text%) -> void))
     = default-pretty-printer
  colors : (listof
            (cons/c string?
                    (and/c (listof (or/c string? (is-a?/c color%)))
                           (λ (x) (<= 0 (length x) 6)))))
         = '()
  racket-colors? : boolean? = #t
  scheme-colors? : boolean? = racket-colors?
  term-filter : (-> any/c (or/c #f string?) any/c)
              = (λ (x y) #t)
  x-spacing : real? = 15
  y-spacing : real? = 15
  layout : (-> (listof term-node?) void?) = void
  edge-labels? : boolean? = #t
  edge-label-font : (or/c #f (is-a?/c font%)) = #f
  graph-pasteboard-mixin : (make-mixin-contract graph-pasteboard<%>)
                         = values
procedure
(traces/ps  reductions                                       
            expr                                             
            file                                             
           [#:multiple? multiple?                            
            #:reduce reduce                                  
            #:pred pred                                      
            #:pp pp                                          
            #:colors colors                                  
            #:filter term-filter                             
            #:layout layout                                  
            #:x-spacing x-spacing                            
            #:y-spacing y-spacing                            
            #:edge-labels? edge-labels?                      
            #:edge-label-font edge-label-font                
            #:graph-pasteboard-mixin graph-pasteboard-mixin] 
            #:post-process post-process)                     
 -> void?
  reductions : reduction-relation?
  expr : (or/c any/c (listof any/c))
  file : (or/c path-string? path?)
  multiple? : boolean? = #f
  reduce : (-> reduction-relation? any/c
               (listof (list/c (union false/c string?) any/c)))
         = apply-reduction-relation/tag-with-names
  pred : (or/c (-> sexp any)             = (λ (x) #t)
               (-> sexp term-node? any))
  pp : (or/c (any -> string)
             (any output-port number (is-a?/c text%) -> void))
     = default-pretty-printer
  colors : (listof
            (cons/c string?
                    (and/c (listof (or/c string? (is-a?/c color%)))
                           (λ (x) (<= 0 (length x) 6)))))
         = '()
  term-filter : (-> any/c (or/c #f string?) any/c)
              = (λ (x y) #t)
  layout : (-> (listof term-node?) void?) = void
  x-spacing : number? = 15
  y-spacing : number? = 15
  edge-labels? : boolean? = #t
  edge-label-font : (or/c #f (is-a?/c font%)) = #f
  graph-pasteboard-mixin : (make-mixin-contract graph-pasteboard<%>)
                         = values
  post-process : (-> (is-a?/c graph-pasteboard<%>) any/c)
procedure
(stepper reductions t [pp]) -> void?
  reductions : reduction-relation?
  t : any/c
  pp : (or/c (any -> string)
             (any output-port number (is-a?/c text%) -> void))
     = default-pretty-printer
procedure
(stepper/seed reductions seed [pp]) -> void?
  reductions : reduction-relation?
  seed : (cons/c any/c (listof any/c))
  pp : (or/c (any -> string)
             (any output-port number (is-a?/c text%) -> void))
     = default-pretty-printer
procedure
(show-derivations  derivations                             
                  [#:pp pp                                 
                   #:racket-colors? racket-colors?         
                   #:init-derivation init-derivation]) -> any
  derivations : (cons/c derivation? (listof derivation?))
  pp : (or/c (any -> string)
             (any output-port number (is-a?/c text%) -> void))
     = default-pretty-printer
  racket-colors? : boolean? = #f
  init-derivation : exact-nonnegative-integer? = 0
procedure
(derivation/ps  derivation                           
                filename                             
               [#:pp pp                              
                #:racket-colors? racket-colors?]     
                #:post-process post-process)     -> void?
  derivation : derivation?
  filename : path-string?
  pp : (or/c (any -> string)
             (any output-port number (is-a?/c text%) -> void))
     = default-pretty-printer
  racket-colors? : boolean? = #f
  post-process : (-> (is-a?/c pasteboard%) any)
procedure
(term-node-children tn) -> (listof term-node?)
  tn : term-node?
procedure
(term-node-parents tn) -> (listof term-node?)
  tn : term-node?
procedure
(term-node-labels tn) -> (listof (or/c false/c string?))
  tn : term-node?
procedure
(term-node-set-color! tn color) -> void?
  tn : term-node?
  color : (or/c string? (is-a?/c color%) false/c)
procedure
(term-node-color tn) -> (or/c string? (is-a?/c color%) false/c)
  tn : term-node?
procedure
(term-node-set-red! tn red?) -> void?
  tn : term-node?
  red? : boolean?
procedure
(term-node-expr tn) -> any
  tn : term-node?
procedure
(term-node-set-position! tn x y) -> void?
  tn : term-node?
  x : (and/c real? positive?)
  y : (and/c real? positive?)
procedure
(term-node-x tn) -> real?
  tn : term-node?
procedure
(term-node-y tn) -> real?
  tn : term-node?
procedure
(term-node-width tn) -> real?
  tn : term-node?
procedure
(term-node-height tn) -> real?
  tn : term-node?
procedure
(term-node? v) -> boolean?
  v : any/c
parameter
(reduction-steps-cutoff) -> number?
(reduction-steps-cutoff cutoff) -> void?
  cutoff : number?
parameter
(initial-font-size) -> number?
(initial-font-size size) -> void?
  size : number?
parameter
(initial-char-width) -> (or/c number? (-> any/c number?))
(initial-char-width width) -> void?
  width : (or/c number? (-> any/c number?))
parameter
(dark-pen-color) -> (or/c string? (is-a?/c color<%>))
(dark-pen-color color) -> void?
  color : (or/c string? (is-a?/c color<%>))
parameter
(dark-brush-color) -> (or/c string? (is-a?/c color<%>))
(dark-brush-color color) -> void?
  color : (or/c string? (is-a?/c color<%>))
parameter
(light-pen-color) -> (or/c string? (is-a?/c color<%>))
(light-pen-color color) -> void?
  color : (or/c string? (is-a?/c color<%>))
parameter
(light-brush-color) -> (or/c string? (is-a?/c color<%>))
(light-brush-color color) -> void?
  color : (or/c string? (is-a?/c color<%>))
parameter
(dark-text-color) -> (or/c string? (is-a?/c color<%>))
(dark-text-color color) -> void?
  color : (or/c string? (is-a?/c color<%>))
parameter
(light-text-color) -> (or/c string? (is-a?/c color<%>))
(light-text-color color) -> void?
  color : (or/c string? (is-a?/c color<%>))
parameter
(pretty-print-parameters) -> (-> (-> any/c) any/c)
(pretty-print-parameters f) -> void?
  f : (-> (-> any/c) any/c)
procedure
(default-pretty-printer v port width text) -> void?
  v : any/c
  port : output-port?
  width : exact-nonnegative-integer?
  text : (is-a?/c text%)
syntax
(render-term lang term)
(render-term lang term file)
syntax
(term->pict lang term)
procedure
(render-term/pretty-write lang               
                          term               
                          filename           
                          #:width width) -> void?
  lang : compiled-lang?
  term : any/c
  filename : path-string?
  width : #f
procedure
(term->pict/pretty-write lang               
                         term               
                         filename           
                         #:width width) -> pict?
  lang : compiled-lang?
  term : any/c
  filename : (or/c path-string? #f)
  width : #f
procedure
(render-language lang [file #:nts nts]) -> (if file void? pict?)
  lang : compiled-lang?
  file : (or/c false/c path-string?) = #f
  nts : (or/c false/c (listof (or/c string? symbol?)))
      = (render-language-nts)
procedure
(language->pict lang [#:nts nts]) -> pict?
  lang : compiled-lang?
  nts : (or/c false/c (listof (or/c string? symbol?)))
      = (render-language-nts)
procedure
(render-reduction-relation  rel             
                           [file            
                            #:style style]) 
 -> (if file void? pict?)
  rel : reduction-relation?
  file : (or/c false/c path-string?) = #f
  style : reduction-rule-style/c = (rule-pict-style)
procedure
(reduction-relation->pict r [#:style style]) -> pict?
  r : reduction-relation?
  style : reduction-rule-style/c = (rule-pict-style)
syntax
(render-metafunction metafunction-name maybe-contract)
syntax
(render-metafunction metafunction-name filename maybe-contract)
syntax
(render-metafunctions metafunction-name ...
                      maybe-filename maybe-contract)
 
 maybe-filename = 
                | #:file filename
                   
maybe-contract? = 
                | #:contract? bool-expr
syntax
(metafunction->pict metafunction-name maybe-contract?)
syntax
(metafunctions->pict metafunction-name ...)
syntax
(render-relation relation-name)
syntax
(render-relation relation-name filename)
syntax
(render-judgment-form judgment-form-name)
syntax
(render-judgment-form judgment-form-name filename)
syntax
(relation->pict relation-name)
syntax
(judgment-form->pict judgment-form-name)
parameter
(render-language-nts) -> (or/c false/c (listof symbol?))
(render-language-nts nts) -> void?
  nts : (or/c false/c (listof symbol?))
parameter
(non-terminal-gap-space) -> real?
(non-terminal-gap-space gap-space) -> void?
  gap-space : real?
parameter
(extend-language-show-union) -> boolean?
(extend-language-show-union show?) -> void?
  show? : boolean?
parameter
(extend-language-show-extended-order) -> boolean?
(extend-language-show-extended-order ext-order?) -> void?
  ext-order? : boolean?
parameter
(render-reduction-relation-rules)
 -> (or/c false/c
          (listof (or/c symbol?
                        string?
                        exact-nonnegative-integer?)))
(render-reduction-relation-rules rules) -> void?
  rules : (or/c false/c
                (listof (or/c symbol?
                              string?
                              exact-nonnegative-integer?)))
parameter
(rule-pict-style) -> reduction-rule-style/c
(rule-pict-style style) -> void?
  style : reduction-rule-style/c
value
reduction-rule-style/c : contract?
procedure
(rule-pict-info? x) -> boolean?
  x : any/c
procedure
(rule-pict-info-arrow rule-pict-info) -> symbol?
  rule-pict-info : rule-pict-info?
procedure
(rule-pict-info-lhs rule-pict-info) -> pict?
  rule-pict-info : rule-pict-info?
procedure
(rule-pict-info-rhs rule-pict-info) -> pict?
  rule-pict-info : rule-pict-info?
procedure
(rule-pict-info-label rule-pict-info) -> (or/c symbol? #f)
  rule-pict-info : rule-pict-info?
procedure
(rule-pict-info-computed-label rule-pict-info)
 -> (or/c pict? #f)
  rule-pict-info : rule-pict-info?
procedure
(rule-pict-info->side-condition-pict  rule-pict-info     
                                     [max-width])    -> pict?
  rule-pict-info : rule-pict-info?
  max-width : real? = +inf.0
parameter
(arrow-space) -> natural-number/c
(arrow-space space) -> void?
  space : natural-number/c
parameter
(label-space) -> natural-number/c
(label-space space) -> void?
  space : natural-number/c
parameter
(metafunction-pict-style)
 -> (or/c 'left-right
          'up-down
          'left-right/vertical-side-conditions
          'up-down/vertical-side-conditions
          'left-right/compact-side-conditions
          'up-down/compact-side-conditions
          'left-right/beside-side-conditions)
(metafunction-pict-style style) -> void?
  style : (or/c 'left-right
                'up-down
                'left-right/vertical-side-conditions
                'up-down/vertical-side-conditions
                'left-right/compact-side-conditions
                'up-down/compact-side-conditions
                'left-right/beside-side-conditions)
parameter
(metafunction-up/down-indent) -> (>=/c 0)
(metafunction-up/down-indent indent) -> void?
  indent : (>=/c 0)
parameter
(delimit-ellipsis-arguments?) -> any/c
(delimit-ellipsis-arguments? delimit?) -> void?
  delimit? : any/c
parameter
(white-square-bracket) -> (-> boolean? pict?)
(white-square-bracket make-white-square-bracket) -> void?
  make-white-square-bracket : (-> boolean? pict?)
procedure
(homemade-white-square-bracket open?) -> pict?
  open? : boolean?
procedure
(default-white-square-bracket open?) -> pict?
  open? : boolean?
parameter
(linebreaks) -> (or/c #f (listof boolean?))
(linebreaks breaks) -> void?
  breaks : (or/c #f (listof boolean?))
parameter
(metafunction-cases)
 -> (or/c #f (and/c (listof (or/c exact-nonnegative-integer?
                                  string?))
                    pair?))
(metafunction-cases cases) -> void?
  cases : (or/c #f (and/c (listof (or/c exact-nonnegative-integer?
                                        string?))
                          pair?))
parameter
(judgment-form-cases)
 -> (or/c #f
          (and/c (listof (or/c exact-nonnegative-integer?
                               string?))
                 pair?))
(judgment-form-cases cases) -> void?
  cases : (or/c #f
                (and/c (listof (or/c exact-nonnegative-integer?
                                     string?))
                       pair?))
parameter
(label-style) -> text-style/c
(label-style style) -> void?
  style : text-style/c
parameter
(grammar-style) -> text-style/c
(grammar-style style) -> void?
  style : text-style/c
parameter
(paren-style) -> text-style/c
(paren-style style) -> void?
  style : text-style/c
parameter
(literal-style) -> text-style/c
(literal-style style) -> void?
  style : text-style/c
parameter
(metafunction-style) -> text-style/c
(metafunction-style style) -> void?
  style : text-style/c
parameter
(non-terminal-style) -> text-style/c
(non-terminal-style style) -> void?
  style : text-style/c
parameter
(non-terminal-subscript-style) -> text-style/c
(non-terminal-subscript-style style) -> void?
  style : text-style/c
parameter
(non-terminal-superscript-style) -> text-style/c
(non-terminal-superscript-style style) -> void?
  style : text-style/c
parameter
(default-style) -> text-style/c
(default-style style) -> void?
  style : text-style/c
parameter
(label-font-size) -> (and/c (between/c 1 255) integer?)
(label-font-size size) -> void?
  size : (and/c (between/c 1 255) integer?)
parameter
(metafunction-font-size) -> (and/c (between/c 1 255)
                                   integer?)
(metafunction-font-size size) -> void?
  size : (and/c (between/c 1 255)
                integer?)
parameter
(default-font-size) -> (and/c (between/c 1 255) integer?)
(default-font-size size) -> void?
  size : (and/c (between/c 1 255) integer?)
parameter
(reduction-relation-rule-separation)
 -> (parameter/c (and/c integer? positive? exact?))
(reduction-relation-rule-separation sep) -> void?
  sep : (parameter/c (and/c integer? positive? exact?))
parameter
(curly-quotes-for-strings) -> boolean?
(curly-quotes-for-strings on?) -> void?
  on? : boolean?
parameter
(current-text) -> (-> string? text-style/c number? pict?)
(current-text proc) -> void?
  proc : (-> string? text-style/c number? pict?)
procedure
(arrow->pict arrow) -> pict?
  arrow : symbol?
procedure
(set-arrow-pict! arrow proc) -> void?
  arrow : symbol?
  proc : (-> pict?)
parameter
(white-bracket-sizing)
 -> (-> string? number? (values number? number? number? number?))
(white-bracket-sizing proc) -> void?
  proc : (-> string? number? (values number? number? number? number?))
parameter
(horizontal-bar-spacing)
 -> (parameter/c exact-nonnegative-integer?)
(horizontal-bar-spacing space) -> void?
  space : (parameter/c exact-nonnegative-integer?)
parameter
(relation-clauses-combine)
 -> (parameter/c (-> (listof pict?) pict?))
(relation-clauses-combine combine) -> void?
  combine : (parameter/c (-> (listof pict?) pict?))
parameter
(where-make-prefix-pict) -> (parameter/c (-> pict?))
(where-make-prefix-pict make-prefix) -> void?
  make-prefix : (parameter/c (-> pict?))
parameter
(where-combine) -> (parameter/c (-> pict? pict? pict?))
(where-combine combine) -> void?
  combine : (parameter/c (-> pict? pict? pict?))
syntax
(with-unquote-rewriter proc expression)
syntax
(with-atomic-rewriter name-symbol
                      string-or-thunk-returning-pict
                      expression)
syntax
(with-compound-rewriter name-symbol
                        proc
                        expression)
syntax
(with-compound-rewriters ([name-symbol proc] ...)
                         expression)
struct
(struct lw (e
            line
            line-span
            column
            column-span
            unq?
            metafunction?)
    #:extra-constructor-name make-lw
    #:mutable)
  e : (or/c string?
            symbol?
            pict?
            (listof (or/c (symbols 'spring) lw?)))
  line : exact-positive-integer?
  line-span : exact-positive-integer?
  column : exact-positive-integer?
  column-span : exact-positive-integer?
  unq? : boolean?
  metafunction? : boolean?
procedure
(build-lw e line line-span column column-span) -> lw?
  e : (or/c string?
            symbol?
            pict?
            (listof (or/c (symbols 'spring) lw?)))
  line : exact-positive-integer?
  line-span : exact-positive-integer?
  column : exact-positive-integer?
  column-span : exact-positive-integer?
syntax
(to-lw arg)
procedure
(to-lw/stx stx) -> lw?
  stx : syntax?
procedure
(render-lw language/nts lw) -> pict?
  language/nts : (or/c (listof symbol?) compiled-lang?)
  lw : lw?
procedure
(lw->pict language/ntw lw) -> pict?
  language/ntw : (or/c (listof symbol?) compiled-lang?)
  lw : lw?
procedure
(just-before stuff lw) -> lw?
  stuff : (or/c pict? string? symbol?)
  lw : lw?
procedure
(just-after stuff lw) -> lw?
  stuff : (or/c pict? string? symbol?)
  lw : lw?
syntax
(define-rewrite id from ==> to
  [#:context (context-id ...)
   #:variables (variable-id ...)
   #:once-only
   #:exactly-once])
syntax
(define-rewrite/compose id rw-id ...)
syntax
(include/rewrite path-spec mod-id rw-id ...)
procedure
(run-gen-and-check  get-gen           
                    check             
                    seconds           
                   [#:name name       
                    #:type type]) -> run-results?
  get-gen : (-> (-> any/c))
  check : (-> any/c boolean?)
  seconds : natural-number/c
  name : string? = "unknown"
  type : symbol? = 'unknown
struct
(struct run-results (tries time cexps))
  tries : natural-number/c
  time : natural-number/c
  cexps : natural-number/c
procedure
(run-gen-and-check/mods  gen-mod-path       
                         check-mod-path     
                         seconds            
                        [#:name name])  -> run-results?
  gen-mod-path : module-path?
  check-mod-path : module-path?
  seconds : natural-number/c
  name : string? = "unknown"
struct
(struct bmark-log-data (data))
  data : any/c
procedure
(benchmark-logging-to filename thunk) -> any/c
  filename : string?
  thunk : (-> any/c)
parameter
(bmark-log-directory)
 -> (or/c path-string? path-for-some-system? 'up 'same)
(bmark-log-directory directory) -> void?
  directory : (or/c path-string? path-for-some-system? 'up 'same)
 = (current-directory)
procedure
(all-mods)
 -> (listof (list/c string? module-path? module-path?))
