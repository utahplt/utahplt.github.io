1764
((3) 0 () 6 ((q lib "syntax-color/token-tree.rkt") (q lib "syntax-color/lexer-contract.rkt") (c (? . 0) q token-tree%) (q 82 . 3) (q lib "syntax-color/racket-lexer.rkt") (q lib "syntax-color/scribble-lexer.rkt")) () (h ! (equal) ((c constructor c (? . 2)) q (2710 . 5)) ((c def c (c (? . 1) q lexer/c)) q (54 . 2)) ((c def c (c (? . 5) q scribble-inside-lexer)) q (2169 . 12)) ((q def ((lib "syntax-color/default-lexer.rkt") default-lexer)) q (941 . 7)) ((c def c (c (? . 4) q racket-lexer)) q (132 . 7)) ((c def c (c (? . 0) q insert-first!)) q (3419 . 4)) ((c def c (c (? . 1) q dont-stop?)) c (? . 3)) ((c meth c (c (? . 2) q search!)) q (2932 . 3)) ((c def c (c (? . 1) q dont-stop)) c (? . 3)) ((c meth c (c (? . 2) q get-root)) q (2871 . 2)) ((c def c (c (? . 0) q node-token-length)) q (3083 . 3)) ((q def ((lib "syntax-color/paren-tree.rkt") paren-tree%)) q (0 . 3)) ((c def c (c (? . 0) q node?)) q (3032 . 3)) ((c def c (c (? . 4) q racket-nobar-lexer/status)) q (712 . 9)) ((c def c (c (? . 5) q make-scribble-inside-lexer)) q (2557 . 3)) ((c def c (c (? . 0) q node-token-data)) q (3154 . 3)) ((c def c (c (? . 0) q node-right)) q (3354 . 3)) ((c def c (? . 2)) q (2656 . 3)) ((c def c (c (? . 1) q dont-stop-val)) c (? . 3)) ((c def c (c (? . 5) q scribble-lexer)) q (1695 . 11)) ((c def c (c (? . 0) q node-left)) q (3290 . 3)) ((c def c (c (? . 0) q insert-last!)) q (3544 . 4)) ((c def c (c (? . 0) q insert-last-spec!)) q (3668 . 5)) ((c def c (c (? . 5) q make-scribble-lexer)) q (2465 . 3)) ((q def ((lib "syntax-color/module-lexer.rkt") module-lexer)) q (1184 . 16)) ((c def c (c (? . 1) q struct:dont-stop)) c (? . 3)) ((c def c (c (? . 4) q racket-lexer/status)) q (370 . 8)) ((c def c (c (? . 0) q node-left-subtree-length)) q (3212 . 3))))
class
paren-tree% : class?
  superclass: object%
value
lexer/c : contract?
struct
(struct dont-stop (val))
  val : any/c
procedure
(racket-lexer in) -> (or/c string? eof-object?)
                     symbol?
                     (or/c symbol? #f)
                     (or/c number? #f)
                     (or/c number? #f)
  in : input-port?
procedure
(racket-lexer/status in) -> (or/c string? eof-object?)
                            symbol?
                            (or/c symbol? #f)
                            (or/c number? #f)
                            (or/c number? #f)
                            (or/c 'datum 'open 'close 'continue)
  in : input-port?
procedure
(racket-nobar-lexer/status in)
 -> (or/c string? eof-object?)
    symbol?
    (or/c symbol? #f)
    (or/c number? #f)
    (or/c number? #f)
    (or/c 'datum 'open 'close 'continue)
  in : input-port?
procedure
(default-lexer in) -> (or/c string? eof-object?)
                      symbol?
                      (or/c symbol? #f)
                      (or/c number? #f)
                      (or/c number? #f)
  in : input-port?
procedure
(module-lexer in offset mode)
 -> (or/c string? eof-object?)
    symbol?
    (or/c symbol? #f)
    (or/c number? #f)
    (or/c number? #f)
    exact-nonnegative-integer?
    (or/c #f
          (-> input-port? any)
          (cons/c (-> input-port? any/c any) any/c))
  in : input-port?
  offset : exact-nonnegative-integer?
  mode : (or/c #f
               (-> input-port? any)
               (cons/c (-> input-port? any/c any) any/c))
procedure
(scribble-lexer in offset mode) -> (or/c string? eof-object?)
                                   symbol?
                                   (or/c symbol? #f)
                                   (or/c number? #f)
                                   (or/c number? #f)
                                   exact-nonnegative-integer?
                                   any/c
  in : input-port?
  offset : exact-nonnegative-integer?
  mode : any/c
procedure
(scribble-inside-lexer in offset mode)
 -> (or/c string? eof-object?)
    symbol?
    (or/c symbol? #f)
    (or/c number? #f)
    (or/c number? #f)
    exact-nonnegative-integer?
    any/c
  in : input-port?
  offset : exact-nonnegative-integer?
  mode : any/c
procedure
(make-scribble-lexer [#:command-char at]) -> lexer/c
  at : char? = #\@
procedure
(make-scribble-inside-lexer [#:command-char at]) -> lexer/c
  at : char? = #\@
class
token-tree% : class?
  superclass: object%
constructor
(new token-tree% [len len] [data data])
 -> (is-a?/c token-tree%)
  len : (or/c exact-nonnegative-integer? fasle/c)
  data : any/c
method
(send a-token-tree get-root) -> (or/c node? #f)
method
(send a-token-tree search! key-position) -> void?
  key-position : natural-number/c
procedure
(node? v) -> boolean?
  v : any/c
procedure
(node-token-length n) -> natural-number/c
  n : node?
procedure
(node-token-data n) -> any/c
  n : node?
procedure
(node-left-subtree-length n) -> natural-number/c
  n : node?
procedure
(node-left n) -> (or/c node? #f)
  n : node?
procedure
(node-right n) -> (or/c node? #f)
  n : node?
procedure
(insert-first! tree1 tree2) -> void?
  tree1 : (is-a?/c token-tree%)
  tree2 : (is-a?/c token-tree%)
procedure
(insert-last! tree1 tree2) -> void?
  tree1 : (is-a?/c token-tree%)
  tree2 : (is-a?/c token-tree%)
procedure
(insert-last-spec! tree n v) -> void?
  tree : (is-a?/c token-tree%)
  n : natural-number/c
  v : any/c
