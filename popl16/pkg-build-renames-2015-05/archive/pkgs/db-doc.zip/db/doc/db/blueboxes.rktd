12194
((3) 0 () 26 ((q lib "db/util/datetime.rkt") (q lib "db/util/geometry.rkt") (q 22640 . 3) (q lib "db/base.rkt") (q lib "db/util/postgresql.rkt") (q 24003 . 4) (q lib "db/main.rkt") (q 19210 . 7) (q 20077 . 15) (q 24168 . 4) (q 14382 . 4) (q 22717 . 3) (q 23776 . 6) (q 19478 . 17) (q 17933 . 5) (q 23164 . 9) (q 22239 . 4) (q 22482 . 3) (q 6431 . 6) (q 22299 . 3) (q 19074 . 5) (q 22368 . 4) (q 22555 . 3) (q 14297 . 3) (q 24070 . 4) (q 23742 . 2)) () (h ! (equal) ((c def c (c (? . 0) q srfi-date->sql-time)) q (21821 . 3)) ((c def c (c (? . 1) q multi-polygon-elements)) c (? . 2)) ((c def c (c (? . 0) q srfi-date->sql-timestamp)) q (21966 . 3)) ((c def c (c (? . 3) q virtual-statement?)) q (16545 . 3)) ((c def c (c (? . 1) q multi-polygon)) c (? . 2)) ((c def c (c (? . 3) q list->sql-bits)) q (21497 . 3)) ((c def c (c (? . 3) q prepared-statement?)) q (15876 . 3)) ((c def c (c (? . 3) q sql-date-month)) c (? . 20)) ((c def c (c (? . 6) q odbc-connect)) q (3694 . 18)) ((c def c (c (? . 1) q multi-polygon?)) c (? . 2)) ((c def c (c (? . 4) q pg-range-lb)) c (? . 12)) ((c def c (c (? . 3) q postgresql-data-source)) q (7452 . 23)) ((c def c (c (? . 3) q rows->dict)) q (15137 . 11)) ((c def c (c (? . 3) q sql-time-minute)) c (? . 7)) ((c def c (c (? . 3) q simple-result-info)) c (? . 23)) ((c def c (c (? . 3) q prepared-statement-parameter-types)) q (15941 . 4)) ((c def c (c (? . 3) q odbc-data-source)) q (10478 . 17)) ((c def c (c (? . 3) q sql-time->sql-interval)) q (20819 . 3)) ((c def c (c (? . 1) q geometry->wkb)) q (22969 . 4)) ((c def c (c (? . 3) q query)) q (14488 . 6)) ((c def c (c (? . 1) q multi-point)) c (? . 17)) ((c def c (c (? . 3) q query-list)) q (12820 . 5)) ((c def c (c (? . 4) q pg-box)) c (? . 5)) ((c def c (c (? . 0) q srfi-date->sql-timestamp-tz)) q (22047 . 3)) ((c def c (c (? . 3) q get-dsn)) q (7085 . 6)) ((c def c (c (? . 4) q pg-box-ne)) c (? . 5)) ((c def c (c (? . 4) q pg-box-sw)) c (? . 5)) ((c def c (c (? . 3) q rows-result-headers)) c (? . 10)) ((c def c (c (? . 3) q dbsystem-supported-types)) q (11881 . 3)) ((c def c (c (? . 3) q group-rows)) q (14650 . 9)) ((c def c (c (? . 3) q current-dsn-file)) q (6982 . 4)) ((c def c (c (? . 3) q sql-interval-seconds)) c (? . 8)) ((c def c (c (? . 3) q needs-rollback?)) q (17291 . 3)) ((c def c (c (? . 6) q mysql-connect)) q (1818 . 22)) ((c def c (c (? . 3) q exn:fail:sql-info)) c (? . 14)) ((c def c (c (? . 6) q odbc-driver-connect)) q (4661 . 14)) ((c def c (c (? . 3) q sql-time-tz)) c (? . 7)) ((c def c (c (? . 4) q pg-circle?)) c (? . 9)) ((c def c (c (? . 3) q sql-interval-nanoseconds)) c (? . 8)) ((c def c (c (? . 3) q sql-timestamp-minute)) c (? . 13)) ((c def c (c (? . 3) q table-exists?)) q (18319 . 10)) ((c def c (c (? . 3) q connection-pool-lease)) q (6079 . 4)) ((c def c (c (? . 3) q connection?)) q (11456 . 3)) ((c def c (c (? . 1) q geometry-collection-elements)) c (? . 11)) ((c def c (c (? . 4) q pg-circle)) c (? . 9)) ((c def c (c (? . 3) q statement-binding?)) q (16368 . 3)) ((c def c (c (? . 4) q pg-array?)) c (? . 15)) ((c def c (c (? . 3) q rows-result-rows)) c (? . 10)) ((c def c (c (? . 1) q point-x)) c (? . 16)) ((c def c (c (? . 1) q struct:line-string)) c (? . 19)) ((c def c (c (? . 3) q sql-time)) c (? . 7)) ((c def c (c (? . 4) q struct:pg-circle)) c (? . 9)) ((c def c (c (? . 6) q odbc-data-sources)) q (5459 . 2)) ((c def c (c (? . 1) q geometry-collection?)) c (? . 11)) ((c def c (c (? . 3) q sql-time?)) c (? . 7)) ((c def c (c (? . 4) q pg-range-includes-ub?)) c (? . 12)) ((c def c (c (? . 3) q start-transaction)) q (16609 . 11)) ((c def c (c (? . 1) q struct:multi-line-string)) c (? . 22)) ((c def c (c (? . 3) q sql-timestamp?)) c (? . 13)) ((c def c (c (? . 3) q kill-safe-connection)) q (6356 . 3)) ((c def c (c (? . 3) q put-dsn)) q (7279 . 5)) ((c def c (c (? . 3) q sql-interval->sql-time)) q (20669 . 4)) ((c def c (c (? . 3) q exn:fail:sql-sqlstate)) c (? . 14)) ((c def c (c (? . 3) q sql-interval-days)) c (? . 8)) ((c def c (c (? . 3) q sql-null->false)) q (18958 . 3)) ((c def c (c (? . 4) q struct:pg-array)) c (? . 15)) ((c def c (c (? . 3) q connection-dbsystem)) q (11670 . 3)) ((c def c (c (? . 3) q data-source?)) c (? . 18)) ((c def c (c (? . 3) q sql-timestamp-nanosecond)) c (? . 13)) ((c def c (c (? . 4) q pg-array)) c (? . 15)) ((c def c (c (? . 4) q list->pg-array)) q (23677 . 3)) ((c def c (c (? . 1) q struct:point)) c (? . 16)) ((c def c (c (? . 3) q sql-null?)) q (18903 . 3)) ((c def c (c (? . 3) q query-row)) q (12955 . 5)) ((c def c (c (? . 4) q pg-array->list)) q (23612 . 3)) ((c def c (c (? . 3) q sql-timestamp-day)) c (? . 13)) ((c def c (c (? . 1) q polygon-interior)) c (? . 21)) ((c def c (c (? . 6) q sqlite3-available?)) q (3649 . 2)) ((c def c (c (? . 1) q multi-point?)) c (? . 17)) ((c def c (c (? . 3) q make-exn:fail:sql)) c (? . 14)) ((c def c (c (? . 4) q pg-path?)) c (? . 24)) ((c def c (c (? . 3) q mysql-data-source)) q (8887 . 18)) ((c def c (c (? . 1) q geometry2d?)) q (22803 . 3)) ((c def c (c (? . 3) q query-value)) q (13245 . 5)) ((c def c (c (? . 4) q pg-array-dimensions)) c (? . 15)) ((c def c (c (? . 1) q geometry-collection)) c (? . 11)) ((c def c (c (? . 4) q pg-array-dimension-lengths)) c (? . 15)) ((c def c (c (? . 3) q sql-interval-years)) c (? . 8)) ((c def c (c (? . 3) q prepared-statement-result-types)) q (16088 . 4)) ((c def c (c (? . 3) q sqlite3-data-source)) q (9766 . 14)) ((c def c (c (? . 3) q sql-interval)) c (? . 8)) ((c def c (c (? . 3) q data-source-connector)) c (? . 18)) ((c def c (c (? . 3) q struct:sql-interval)) c (? . 8)) ((c def c (c (? . 3) q query-exec)) q (12024 . 5)) ((c def c (c (? . 3) q query-rows)) q (12159 . 14)) ((c def c (c (? . 6) q postgresql-guess-socket-path)) q (1759 . 2)) ((c def c (c (? . 4) q pg-range-ub)) c (? . 12)) ((c def c (c (? . 3) q data-source-extensions)) c (? . 18)) ((c def c (c (? . 3) q struct:sql-time)) c (? . 7)) ((c def c (c (? . 4) q pg-range?)) c (? . 12)) ((c def c (c (? . 4) q pg-circle-radius)) c (? . 9)) ((c def c (c (? . 3) q disconnect)) q (11513 . 3)) ((c def c (c (? . 3) q sql-bits-ref)) q (21134 . 4)) ((c def c (c (? . 3) q prepare)) q (15733 . 4)) ((c def c (c (? . 1) q line-string?)) c (? . 19)) ((c def c (c (? . 3) q rollback-transaction)) q (17155 . 3)) ((c def c (c (? . 3) q set-data-source-extensions!)) c (? . 18)) ((c def c (c (? . 3) q dsn-connect)) q (6643 . 9)) ((c def c (c (? . 3) q sql-date-day)) c (? . 20)) ((c def c (c (? . 3) q sql-timestamp-second)) c (? . 13)) ((c def c (c (? . 1) q polygon)) c (? . 21)) ((c def c (c (? . 4) q struct:pg-range)) c (? . 12)) ((c def c (c (? . 3) q sql-bits->list)) q (21358 . 3)) ((c def c (c (? . 3) q query-maybe-row)) q (13091 . 5)) ((c def c (c (? . 6) q odbc-drivers)) q (5531 . 2)) ((c def c (c (? . 3) q sql-interval?)) c (? . 8)) ((c def c (c (? . 0) q sql-datetime->srfi-date)) q (21640 . 3)) ((c def c (c (? . 1) q struct:polygon)) c (? . 21)) ((c def c (c (? . 6) q postgresql-connect)) q (0 . 30)) ((c def c (c (? . 4) q pg-range-or-empty?)) q (23939 . 3)) ((c def c (c (? . 3) q dbsystem?)) q (11760 . 3)) ((c def c (c (? . 3) q prop:statement)) q (18768 . 3)) ((c def c (c (? . 3) q struct:rows-result)) c (? . 10)) ((c def c (c (? . 1) q struct:multi-polygon)) c (? . 2)) ((c def c (c (? . 3) q sql-time-second)) c (? . 7)) ((c def c (c (? . 3) q sql-bits->string)) q (21432 . 3)) ((c def c (c (? . 4) q pg-empty-range?)) c (? . 25)) ((c def c (c (? . 3) q bind-prepared-statement)) q (16232 . 4)) ((c def c (c (? . 3) q struct:sql-timestamp)) c (? . 13)) ((c def c (c (? . 1) q point?)) c (? . 16)) ((c def c (c (? . 0) q srfi-date->sql-date)) q (21750 . 3)) ((c def c (c (? . 1) q line?)) q (22860 . 3)) ((c def c (c (? . 3) q string->sql-bits)) q (21575 . 3)) ((c def c (c (? . 1) q multi-line-string?)) c (? . 22)) ((c def c (c (? . 1) q multi-line-string)) c (? . 22)) ((c def c (c (? . 3) q sql-time-nanosecond)) c (? . 7)) ((c def c (c (? . 3) q simple-result?)) c (? . 23)) ((c def c (c (? . 3) q sql-date)) c (? . 20)) ((c def c (c (? . 3) q in-query)) q (13535 . 16)) ((c def c (c (? . 3) q dbsystem-name)) q (11815 . 3)) ((c def c (c (? . 1) q linear-ring?)) q (22911 . 3)) ((c def c (c (? . 4) q pg-range)) c (? . 12)) ((c def c (c (? . 4) q pg-path-points)) c (? . 24)) ((c def c (c (? . 3) q commit-transaction)) q (17088 . 3)) ((c def c (c (? . 3) q sql-date-year)) c (? . 20)) ((c def c (c (? . 1) q struct:geometry-collection)) c (? . 11)) ((q def ((lib "db/util/testing.rkt") high-latency-connection)) q (24253 . 8)) ((c def c (c (? . 1) q multi-line-string-elements)) c (? . 22)) ((c def c (c (? . 3) q sql-time-hour)) c (? . 7)) ((c def c (c (? . 3) q exn:fail:sql?)) c (? . 14)) ((c def c (c (? . 3) q query-maybe-value)) q (13381 . 5)) ((c def c (c (? . 4) q struct:pg-box)) c (? . 5)) ((c def c (c (? . 4) q pg-array-dimension-lower-bounds)) c (? . 15)) ((c def c (c (? . 1) q struct:multi-point)) c (? . 17)) ((c def c (c (? . 3) q sql-timestamp-year)) c (? . 13)) ((c def c (c (? . 3) q rows-result?)) c (? . 10)) ((c def c (c (? . 1) q point)) c (? . 16)) ((c def c (c (? . 6) q mysql-guess-socket-path)) q (2942 . 2)) ((c def c (c (? . 3) q data-source-args)) c (? . 18)) ((c def c (c (? . 3) q false->sql-null)) q (19016 . 3)) ((c def c (c (? . 3) q struct:exn:fail:sql)) c (? . 14)) ((c def c (c (? . 3) q sql-year-month-interval?)) q (20531 . 3)) ((c def c (c (? . 4) q struct:pg-path)) c (? . 24)) ((c def c (c (? . 1) q polygon?)) c (? . 21)) ((c def c (c (? . 1) q point-y)) c (? . 16)) ((c def c (c (? . 4) q struct:pg-empty-range)) c (? . 25)) ((c def c (c (? . 0) q srfi-date->sql-time-tz)) q (21892 . 3)) ((c def c (c (? . 3) q sql-timestamp-tz)) c (? . 13)) ((c def c (c (? . 3) q set-data-source-args!)) c (? . 18)) ((c def c (c (? . 3) q list-tables)) q (18132 . 5)) ((c def c (c (? . 3) q struct:simple-result)) c (? . 23)) ((c def c (c (? . 3) q virtual-statement)) q (16432 . 3)) ((c def c (c (? . 3) q in-transaction?)) q (17224 . 3)) ((c def c (c (? . 3) q sql-date?)) c (? . 20)) ((c def c (c (? . 3) q simple-result)) c (? . 23)) ((c def c (c (? . 6) q sqlite3-connect)) q (2996 . 13)) ((c def c (c (? . 1) q multi-point-elements)) c (? . 17)) ((c def c (c (? . 3) q sql-interval-hours)) c (? . 8)) ((c def c (c (? . 3) q rows-result)) c (? . 10)) ((c def c (c (? . 3) q struct:sql-date)) c (? . 20)) ((c def c (c (? . 3) q data-source)) c (? . 18)) ((c def c (c (? . 4) q pg-circle-center)) c (? . 9)) ((c def c (c (? . 3) q sql-interval-months)) c (? . 8)) ((c def c (c (? . 3) q sql-bits?)) q (20996 . 3)) ((c def c (c (? . 1) q line-string-points)) c (? . 19)) ((c def c (c (? . 1) q wkb->geometry)) q (23101 . 3)) ((c def c (c (? . 3) q sql-timestamp-month)) c (? . 13)) ((c def c (c (? . 3) q call-with-transaction)) q (17358 . 13)) ((c def c (c (? . 4) q pg-array-ref)) q (23507 . 4)) ((c def c (c (? . 3) q sql-bits-length)) q (21051 . 3)) ((c def c (c (? . 4) q pg-path-closed?)) c (? . 24)) ((c def c (c (? . 3) q sql-timestamp-hour)) c (? . 13)) ((c def c (c (? . 3) q set-data-source-connector!)) c (? . 18)) ((c def c (c (? . 4) q pg-path)) c (? . 24)) ((c def c (c (? . 3) q sql-timestamp)) c (? . 13)) ((c def c (c (? . 1) q line-string)) c (? . 19)) ((c def c (c (? . 3) q connection-pool)) q (5596 . 8)) ((c def c (c (? . 3) q connected?)) q (11590 . 3)) ((c def c (c (? . 4) q pg-array-contents)) c (? . 15)) ((c def c (c (? . 3) q make-sql-bits)) q (20911 . 3)) ((c def c (c (? . 4) q pg-empty-range)) c (? . 25)) ((c def c (c (? . 3) q sql-null)) q (18874 . 2)) ((c def c (c (? . 3) q struct:data-source)) c (? . 18)) ((c def c (c (? . 3) q sql-interval-minutes)) c (? . 8)) ((c def c (c (? . 4) q pg-box?)) c (? . 5)) ((c def c (c (? . 1) q polygon-exterior)) c (? . 21)) ((c def c (c (? . 3) q sql-day-time-interval?)) q (20601 . 3)) ((c def c (c (? . 4) q pg-range-includes-lb?)) c (? . 12)) ((c def c (c (? . 3) q virtual-connection)) q (6239 . 3)) ((c def c (c (? . 3) q connection-pool?)) q (6017 . 3)) ((c def c (c (? . 3) q sql-bits-set!)) q (21236 . 5)) ((c def c (c (? . 0) q sql-day-time-interval->seconds)) q (22131 . 3)) ((c def c (c (? . 3) q statement?)) q (11968 . 3)) ((c def c (c (? . 3) q exn:fail:sql)) c (? . 14))))
procedure
(postgresql-connect                                                        
                     #:user user                                           
                     #:database database                                   
                    [#:server server                                       
                     #:port port                                           
                     #:socket socket                                       
                     #:password password                                   
                     #:allow-cleartext-password? allow-cleartext-password? 
                     #:ssl ssl                                             
                     #:ssl-context ssl-context                             
                     #:notice-handler notice-handler                       
                     #:notification-handler notification-handler])         
 -> connection?
  user : string?
  database : string?
  server : string? = "localhost"
  port : exact-positive-integer? = 5432
  socket : (or/c path-string? 'guess #f) = #f
  password : (or/c string? #f) = #f
  allow-cleartext-password? : boolean? = #f
  ssl : (or/c 'yes 'optional 'no) = 'no
  ssl-context : ssl-client-context?
              = (ssl-make-client-context 'sslv3)
  notice-handler : (or/c 'output 'error output-port? = void
                         (-> string? string? any))
  notification-handler : (or/c 'output 'error output-port?
                               (-> string? any)
                               (-> string? string? any))
                       = void
procedure
(postgresql-guess-socket-path) -> path-string?
procedure
(mysql-connect  #:user user                           
               [#:database database                   
                #:server server                       
                #:port port                           
                #:socket socket                       
                #:ssl ssl                             
                #:ssl-context ssl-context             
                #:password password                   
                #:notice-handler notice-handler]) -> connection?
  user : string?
  database : (or/c string? #f) = #f
  server : string? = "localhost"
  port : exact-positive-integer? = 3306
  socket : (or/c path-string? #f) = #f
  ssl : (or/c 'yes 'optional 'no) = 'no
  ssl-context : ssl-client-context?
              = (ssl-make-client-context 'tls)
  password : (or/c string? #f) = #f
  notice-handler : (or/c 'output 'error output-port?
                         (-> exact-nonnegative-integer? string? any))
                 = void
procedure
(mysql-guess-socket-path) -> path-string?
procedure
(sqlite3-connect  #:database database                 
                 [#:mode mode                         
                  #:busy-retry-limit busy-retry-limit 
                  #:busy-retry-delay busy-retry-delay 
                  #:use-place use-place])             
 -> connection?
  database : (or/c path-string? 'memory 'temporary)
  mode : (or/c 'read-only 'read/write 'create) = 'read/write
  busy-retry-limit : (or/c exact-nonnegative-integer? +inf.0)
                   = 10
  busy-retry-delay : (and/c rational? (not/c negative?)) = 0.1
  use-place : boolean? = #f
procedure
(sqlite3-available?) -> boolean?
procedure
(odbc-connect                                                    
               #:dsn dsn                                         
              [#:user user                                       
               #:password password                               
               #:notice-handler notice-handler                   
               #:strict-parameter-types? strict-parameter-types? 
               #:character-mode character-mode                   
               #:use-place use-place])                           
 -> connection?
  dsn : string?
  user : (or/c string? #f) = #f
  password : (or/c string? #f) = #f
  notice-handler : (or/c output-port? 'output 'error = void
                         (-> string? string? any))
  strict-parameter-types? : boolean? = #f
  character-mode : (or/c 'wchar 'utf-8 'latin-1) = 'wchar
  use-place : boolean? = #f
procedure
(odbc-driver-connect                                                    
                      connection-string                                 
                     [#:notice-handler notice-handler                   
                      #:strict-parameter-types? strict-parameter-types? 
                      #:character-mode character-mode                   
                      #:use-place use-place])                           
 -> connection?
  connection-string : string?
  notice-handler : (or/c output-port? 'output 'error = void
                         (-> string? string? any))
  strict-parameter-types? : boolean? = #f
  character-mode : (or/c 'wchar 'utf-8 'latin-1) = 'wchar
  use-place : boolean? = #f
procedure
(odbc-data-sources) -> (listof (list/c string? string?))
procedure
(odbc-drivers) -> (listof (cons/c string? any/c))
procedure
(connection-pool  connect                                       
                 [#:max-connections max-connections             
                  #:max-idle-connections max-idle-connections]) 
 -> connection-pool?
  connect : (-> connection?)
  max-connections : (or/c (integer-in 1 10000) +inf.0) = +inf.0
  max-idle-connections : (or/c (integer-in 1 10000) +inf.0) = 10
procedure
(connection-pool? x) -> boolean?
  x : any/c
procedure
(connection-pool-lease pool [release]) -> connection?
  pool : connection-pool?
  release : (or/c evt? custodian?) = (current-thread)
procedure
(virtual-connection connect) -> connection?
  connect : (or/c (-> connection?) connection-pool?)
procedure
(kill-safe-connection c) -> connection?
  c : connection?
struct
(struct data-source (connector args extensions)
    #:mutable)
  connector : (or/c 'postgresql 'mysql 'sqlite3 'odbc)
  args : list?
  extensions : (listof (list/c symbol? any/c))
procedure
(dsn-connect  dsn                      
             [#:dsn-file dsn-file]     
              arg ...                  
              #:<kw> kw-arg ...)   -> connection?
  dsn : (or/c symbol? data-source?)
  dsn-file : path-string? = (current-dsn-file)
  arg : any/c
  kw-arg : any/c
parameter
(current-dsn-file) -> path-string?
(current-dsn-file x) -> void?
  x : path-string?
procedure
(get-dsn dsn [default #:dsn-file dsn-file])
 -> (or/c data-source? any/c)
  dsn : symbol?
  default : any/c = #f
  dsn-file : path-string? = (current-dsn-file)
procedure
(put-dsn dsn ds [#:dsn-file dsn-file]) -> void?
  dsn : symbol?
  ds : (or/c data-source? #f)
  dsn-file : path-string? = (current-dsn-file)
procedure
(postgresql-data-source                                                        
                        [#:user user                                           
                         #:database database                                   
                         #:server server                                       
                         #:port port                                           
                         #:socket socket                                       
                         #:password password                                   
                         #:allow-cleartext-password? allow-cleartext-password? 
                         #:ssl ssl                                             
                         #:notice-handler notice-handler                       
                         #:notification-handler notification-handler])         
 -> data-source?
  user : string? = absent
  database : string? = absent
  server : string? = absent
  port : exact-positive-integer? = absent
  socket : (or/c path-string? 'guess #f) = absent
  password : (or/c string? #f) = absent
  allow-cleartext-password? : boolean? = absent
  ssl : (or/c 'yes 'optional 'no) = absent
  notice-handler : (or/c 'output 'error) = absent
  notification-handler : (or/c 'output 'error) = absent
procedure
(mysql-data-source [#:user user                       
                    #:database database               
                    #:server server                   
                    #:port port                       
                    #:socket socket                   
                    #:ssl ssl                         
                    #:password password               
                    #:notice-handler notice-handler]) 
 -> data-source?
  user : string? = absent
  database : (or/c string? #f) = absent
  server : string? = absent
  port : exact-positive-integer? = absent
  socket : (or/c path-string? 'guess #f) = absent
  ssl : (or/c 'yes 'optional 'no) = absent
  password : (or/c string? #f) = absent
  notice-handler : (or/c 'output 'error) = absent
procedure
(sqlite3-data-source [#:database database                 
                      #:mode mode                         
                      #:busy-retry-limit busy-retry-limit 
                      #:busy-retry-delay busy-retry-delay 
                      #:use-place use-place])             
 -> data-source?
  database : (or/c path-string? 'memory 'temporary) = absent
  mode : (or/c 'read-only 'read/write 'create) = absent
  busy-retry-limit : (or/c exact-nonnegative-integer? +inf.0)
                   = absent
  busy-retry-delay : (and/c rational? (not/c negative?))
                   = absent
  use-place : boolean? = absent
procedure
(odbc-data-source                                                    
                  [#:dsn dsn                                         
                   #:database database                               
                   #:user user                                       
                   #:password password                               
                   #:notice-handler notice-handler                   
                   #:strict-parameter-types? strict-parameter-types? 
                   #:character-mode character-mode])                 
 -> data-source?
  dsn : (or/c string? #f) = absent
  database : (or/c string? #f) = absent
  user : (or/c string? #f) = absent
  password : (or/c string? #f) = absent
  notice-handler : (or/c 'output 'error) = absent
  strict-parameter-types? : boolean? = absent
  character-mode : (or/c 'wchar 'utf-8 'latin-1) = absent
procedure
(connection? x) -> boolean?
  x : any/c
procedure
(disconnect connection) -> void?
  connection : connection?
procedure
(connected? connection) -> boolean?
  connection : connection?
procedure
(connection-dbsystem connection) -> dbsystem?
  connection : connection?
procedure
(dbsystem? x) -> boolean?
  x : any/c
procedure
(dbsystem-name sys) -> symbol?
  sys : dbsystem?
procedure
(dbsystem-supported-types sys) -> (listof symbol?)
  sys : dbsystem?
procedure
(statement? x) -> boolean?
  x : any/c
procedure
(query-exec connection stmt arg ...) -> void?
  connection : connection?
  stmt : statement?
  arg : any/c
procedure
(query-rows  connection                    
             stmt                          
             arg ...                       
            [#:group groupings             
             #:group-mode group-mode]) -> (listof vector?)
  connection : connection?
  stmt : statement?
  arg : any/c
  groupings : (let* ([field/c (or/c string? exact-nonnegative-integer?)]
                     [grouping/c (or/c field/c (vectorof field/c))])
                (or/c grouping/c (listof grouping/c)))
            = null
  group-mode : (listof (or/c 'preserve-null 'list)) = null
procedure
(query-list connection stmt arg ...) -> list?
  connection : connection?
  stmt : statement?
  arg : any/c
procedure
(query-row connection stmt arg ...) -> vector?
  connection : connection?
  stmt : statement?
  arg : any/c
procedure
(query-maybe-row connection stmt arg ...) -> (or/c vector? #f)
  connection : connection?
  stmt : statement?
  arg : any/c
procedure
(query-value connection stmt arg ...) -> any/c
  connection : connection?
  stmt : statement?
  arg : any/c
procedure
(query-maybe-value connection stmt arg ...) -> (or/c any/c #f)
  connection : connection?
  stmt : statement?
  arg : any/c
procedure
(in-query  connection                    
           stmt                          
           arg ...                       
          [#:fetch fetch-size            
           #:group groupings             
           #:group-mode group-mode]) -> sequence?
  connection : connection?
  stmt : statement?
  arg : any/c
  fetch-size : (or/c exact-positive-integer? +inf.0) = +inf.0
  groupings : (let* ([field/c (or/c string? exact-nonnegative-integer?)]
                     [grouping/c (or/c field/c (vectorof field/c))])
                (or/c grouping/c (listof grouping/c)))
            = null
  group-mode : (listof (or/c 'preserve-null 'list)) = null
struct
(struct simple-result (info))
  info : (listof (cons/c symbol? any/c))
struct
(struct rows-result (headers rows))
  headers : (listof any/c)
  rows : (listof vector?)
procedure
(query connection stmt arg ...)
 -> (or/c simple-result? rows-result?)
  connection : connection?
  stmt : statement?
  arg : any/c
procedure
(group-rows  result                        
             #:group groupings             
            [#:group-mode group-mode]) -> rows-result?
  result : rows-result?
  groupings : (let* ([field/c (or/c string? exact-nonnegative-integer?)]
                     [grouping/c (or/c field/c (vectorof field/c))])
                (or/c grouping/c (listof grouping/c)))
  group-mode : (listof (or/c 'preserve-null 'list)) = null
procedure
(rows->dict  result                        
             #:key key-field/s             
             #:value value-field/s         
            [#:value-mode value-mode]) -> dict?
  result : rows-result?
  key-field/s : (let ([field/c (or/c string? exact-nonnegative-integer?)])
                  (or/c field/c (vectorof field/c)))
  value-field/s : (let ([field/c (or/c string? exact-nonnegative-integer?)])
                    (or/c field/c (vectorof field/c)))
  value-mode : (listof (or/c 'list 'preserve-null)) = null
procedure
(prepare connection stmt) -> prepared-statement?
  connection : connection?
  stmt : (or/c string? virtual-statement?)
procedure
(prepared-statement? x) -> boolean?
  x : any/c
procedure
(prepared-statement-parameter-types pst)
 -> (listof (list/c boolean? (or/c symbol? #f) any/c))
  pst : prepared-statement?
procedure
(prepared-statement-result-types pst)
 -> (listof (list/c boolean? (or/c symbol? #f) any/c))
  pst : prepared-statement?
procedure
(bind-prepared-statement pst params) -> statement-binding?
  pst : prepared-statement?
  params : (listof any/c)
procedure
(statement-binding? x) -> boolean?
  x : any/c
procedure
(virtual-statement gen) -> virtual-statement?
  gen : (or/c string? (-> dbsystem? string?))
procedure
(virtual-statement? x) -> boolean?
  x : any/c
procedure
(start-transaction  c                               
                   [#:isolation isolation-level     
                    #:option option])           -> void?
  c : connection?
  isolation-level : (or/c 'serializable     = #f
                          'repeatable-read
                          'read-committed
                          'read-uncommitted
                          #f)
  option : any/c = #f
procedure
(commit-transaction c) -> void?
  c : connection?
procedure
(rollback-transaction c) -> void?
  c : connection?
procedure
(in-transaction? c) -> boolean?
  c : connection?
procedure
(needs-rollback? c) -> boolean?
  c : connection?
procedure
(call-with-transaction  c                               
                        proc                            
                       [#:isolation isolation-level     
                        #:option option])           -> any
  c : connection?
  proc : (-> any)
  isolation-level : (or/c 'serializable     = #f
                          'repeatable-read
                          'read-committed
                          'read-uncommitted
                          #f)
  option : any/c = #f
struct
(struct exn:fail:sql exn:fail (sqlstate info)
    #:extra-constructor-name make-exn:fail:sql)
  sqlstate : (or/c string? symbol?)
  info : (listof (cons/c symbol? any/c))
procedure
(list-tables c [#:schema schema]) -> (listof string?)
  c : connection?
  schema : (or/c 'search-or-current 'search 'current)
         = 'search-or-current
procedure
(table-exists?  c                                       
                table-name                              
               [#:schema schema                         
                #:case-sensitive? case-sensitive?]) -> boolean?
  c : connection?
  table-name : string?
  schema : (or/c 'search-or-current 'search 'current)
         = 'search-or-current
  case-sensitive? : any/c = #f
value
prop:statement : (struct-type-property/c
                  (-> any/c connection? statement?))
value
sql-null : sql-null?
procedure
(sql-null? x) -> boolean?
  x : any/c
procedure
(sql-null->false x) -> any/c
  x : any/c
procedure
(false->sql-null x) -> any/c
  x : any/c
struct
(struct sql-date (year month day))
  year : exact-integer?
  month : (integer-in 0 12)
  day : (integer-in 0 31)
struct
(struct sql-time (hour minute second nanosecond tz))
  hour : exact-nonnegative-integer?
  minute : exact-nonnegative-integer?
  second : exact-nonnegative-integer?
  nanosecond : exact-nonnegative-integer?
  tz : (or/c exact-integer? #f)
struct
(struct sql-timestamp (year
                       month
                       day
                       hour
                       minute
                       second
                       nanosecond
                       tz))
  year : exact-nonnegative-integer?
  month : exact-nonnegative-integer?
  day : exact-nonnegative-integer?
  hour : exact-nonnegative-integer?
  minute : exact-nonnegative-integer?
  second : exact-nonnegative-integer?
  nanosecond : exact-nonnegative-integer?
  tz : (or/c exact-integer? #f)
struct
(struct sql-interval (years
                      months
                      days
                      hours
                      minutes
                      seconds
                      nanoseconds))
  years : exact-integer?
  months : exact-integer?
  days : exact-integer?
  hours : exact-integer?
  minutes : exact-integer?
  seconds : exact-integer?
  nanoseconds : exact-integer?
procedure
(sql-year-month-interval? x) -> boolean?
  x : any/c
procedure
(sql-day-time-interval? x) -> boolean?
  x : any/c
procedure
(sql-interval->sql-time interval [failure]) -> any
  interval : sql-interval?
  failure : any/c = (lambda () (error ....))
procedure
(sql-time->sql-interval time) -> sql-day-time-interval?
  time : sql-time?
procedure
(make-sql-bits len) -> sql-bits?
  len : exact-nonnegative-integer?
procedure
(sql-bits? v) -> boolean?
  v : any/c
procedure
(sql-bits-length b) -> exact-nonnegative-integer?
  b : sql-bits?
procedure
(sql-bits-ref b i) -> boolean?
  b : sql-bits?
  i : exact-nonnegative-integer?
procedure
(sql-bits-set! b i v) -> void?
  b : sql-bits?
  i : exact-nonnegative-integer?
  v : boolean?
procedure
(sql-bits->list b) -> (listof boolean?)
  b : sql-bits?
procedure
(sql-bits->string b) -> string?
  b : sql-bits?
procedure
(list->sql-bits lst) -> sql-bits?
  lst : (listof boolean?)
procedure
(string->sql-bits s) -> sql-bits?
  s : string?
procedure
(sql-datetime->srfi-date t) -> srfi:date?
  t : (or/c sql-date? sql-time? sql-timestamp?)
procedure
(srfi-date->sql-date d) -> sql-date?
  d : srfi:date?
procedure
(srfi-date->sql-time d) -> sql-time?
  d : srfi:date?
procedure
(srfi-date->sql-time-tz d) -> sql-time?
  d : srfi:date?
procedure
(srfi-date->sql-timestamp d) -> sql-timestamp?
  d : srfi:date?
procedure
(srfi-date->sql-timestamp-tz d) -> sql-timestamp?
  d : srfi:date?
procedure
(sql-day-time-interval->seconds interval) -> rational?
  interval : sql-day-time-interval?
struct
(struct point (x y))
  x : real?
  y : real?
struct
(struct line-string (points))
  points : (listof point?)
struct
(struct polygon (exterior interior))
  exterior : linear-ring?
  interior : (listof linear-ring?)
struct
(struct multi-point (elements))
  elements : (listof point?)
struct
(struct multi-line-string (elements))
  elements : (listof line-string?)
struct
(struct multi-polygon (elements))
  elements : (listof polygon?)
struct
(struct geometry-collection (elements))
  elements : (listof geometry2d?)
procedure
(geometry2d? x) -> boolean?
  x : any/c
procedure
(line? x) -> boolean?
  x : any/c
procedure
(linear-ring? x) -> boolean?
  x : any/c
procedure
(geometry->wkb g #:big-endian? big-endian?) -> bytes?
  g : geometry2d?
  big-endian? : (system-big-endian?)
procedure
(wkb->geometry b) -> geometry2d?
  b : bytes?
struct
(struct pg-array (dimensions
                  dimension-lengths
                  dimension-lower-bounds
                  contents))
  dimensions : exact-nonnegative-integer?
  dimension-lengths : (listof exact-positive-integer?)
  dimension-lower-bounds : (listof exact-integer?)
  contents : vector?
procedure
(pg-array-ref arr index ...+) -> any/c
  arr : pg-array?
  index : exact-integer?
procedure
(pg-array->list arr) -> list?
  arr : pg-array?
procedure
(list->pg-array lst) -> pg-array?
  lst : list?
struct
(struct pg-empty-range ())
struct
(struct pg-range (lb includes-lb? ub includes-ub?))
  lb : range-type
  includes-lb? : boolean?
  ub : range-type
  includes-ub? : boolean?
procedure
(pg-range-or-empty? v) -> boolean?
  v : any/c
struct
(struct pg-box (ne sw))
  ne : point?
  sw : point?
struct
(struct pg-path (closed? points))
  closed? : boolean?
  points : (listof point?)
struct
(struct pg-circle (center radius))
  center : point?
  radius : real?
procedure
(high-latency-connection  connection                      
                          latency                         
                         [#:sleep-atomic? sleep-atomic?]) 
 -> connection?
  connection : connection?
  latency : (>=/c 0)
  sleep-atomic? : any/c = #f
