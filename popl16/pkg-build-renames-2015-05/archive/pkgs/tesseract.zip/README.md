# Tesseracket
Racket bindings for Google's tesseract-ocr

Example usage:
``` lisp
> (image->string "lorem.png")
"Lorem ipsum..."
> (image->string "lorem.png" #:out-base "foo" #:config "-nobatch numbers")
> (system "cat foo.txt")
1037 10 129
```

## Requirements
*Tesseracket was written in Racket 6.1.1*

- Install tesseract (http://code.google.com/p/tesseract-ocr/).
You must be able to invoke tesseract at the shell, e.g. `user@host:~$ tesseract`
