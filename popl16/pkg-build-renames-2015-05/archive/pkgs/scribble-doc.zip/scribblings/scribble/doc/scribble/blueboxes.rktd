54085
((3) 0 () 115 ((q lib "scribble/base.rkt") (q lib "scribble/core.rkt") (q lib "scribble/sigplan.rkt") (q 60473 . 6) (q lib "scribble/html-properties.rkt") (q lib "scribble/manual.rkt") (q lib "scribble/racket.rkt") (q lib "scribble/eval.rkt") (q lib "scribble/decode.rkt") (q lib "scribble/srcdoc.rkt") (q 61590 . 20) (q 59511 . 4) (q 55448 . 5) (q lib "scribble/struct.rkt") (q 55912 . 5) (q lib "scribble/manual-struct.rkt") (q lib "scribble/lncs/lang.rkt") (q 58511 . 6) (q 59623 . 4) (q 57825 . 4) (q 56060 . 5) (q 58190 . 5) (q lib "scribble/tag.rkt") (q lib "scribble/latex-properties.rkt") (q 75592 . 8) (q 60834 . 5) (q 37820 . 5) (q 60213 . 4) (q lib "scribble/base-render.rkt") (q 58738 . 6) (q 64977 . 7) (q 52504 . 6) (q lib "scribble/xref.rkt") (q lib "scribble/bnf.rkt") (q 35288 . 3) (c (? . 28) q render<%>) (q 56365 . 4) (q 56522 . 5) (q 38204 . 4) (q lib "scribble/jfp.rkt") (q 67033 . 6) (q 56931 . 4) (q 75321 . 8) (q 64056 . 4) (q 59879 . 4) (q 76015 . 4) (q 57440 . 6) (q 55587 . 5) (q 56665 . 7) (q 67244 . 9) (q 65708 . 4) (q 52366 . 5) (q 61121 . 3) (q 60347 . 4) (q 66400 . 4) (q 64446 . 4) (q 54996 . 16) (q 60035 . 4) (q 65947 . 9) (q 57164 . 4) (q 64740 . 7) (q 66673 . 4) (q 64187 . 4) (q 34933 . 3) (q 37702 . 4) (q 76175 . 4) (q 34406 . 5) (q 58363 . 4) (q 57940 . 7) (q 59278 . 6) (c (? . 91) q render-mixin) (q 64339 . 4) (q 52192 . 5) (q 55751 . 5) (q 57692 . 4) (q 63918 . 4) (q lib "scribble/blueboxes.rkt") (q lib "scribble/basic.rkt") (q 58963 . 4) (q 34695 . 3) (q 56223 . 4) (q 62178 . 7) (q 66791 . 4) (q 34818 . 3) (q 65461 . 7) (q 35050 . 3) (q 67699 . 4) (q 65226 . 7) (q 34582 . 3) (q 35165 . 3) (q 59754 . 4) (q lib "scribble/html-render.rkt") (q 35403 . 6) (q 76283 . 4) (q 79445 . 7) (q 37955 . 4) (q 65811 . 4) (q 64561 . 5) (q lib "scribble/reader.rkt") (q lib "scribble/contract-render.rkt") (q 57050 . 3) (c (? . 28) q render%) (q lib "scribble/lp.rkt") (q 75844 . 5) (q lib "scribble/extract.rkt") (q 35643 . 4) (q 34300 . 3) (c (? . 99) q override-render-mixin-single) (q 66909 . 4) (q 59115 . 4) (c (? . 99) q override-render-mixin-multi) (q 57324 . 3) (q 38065 . 5) (q 66509 . 4) (c (? . 91) q render-multi-mixin)) () (h ! (equal) ((c form c (c (? . 5) q racketid)) q (13651 . 2)) ((c def c (c (? . 4) q hover-property)) c (? . 55)) ((c def c (c (? . 0) q other-doc)) q (7956 . 7)) ((c def c (c (? . 1) q toc-target2-element?)) c (? . 59)) ((c def c (c (? . 0) q title)) q (0 . 13)) ((c def c (c (? . 2) q conferenceinfo)) q (9813 . 4)) ((c def c (c (? . 1) q collect-info-parents)) c (? . 10)) ((c def c (c (? . 1) q box-mode?)) c (? . 3)) ((c def c (c (? . 15) q make-mixin-index-desc)) c (? . 34)) ((c meth c (c (? . 35) q serialize-info)) q (70623 . 3)) ((c def c (c (? . 2) q subtitle)) q (9580 . 3)) ((c def c (c (? . 1) q make-paragraph)) c (? . 12)) ((c def c (c (? . 6) q make-variable-id)) q (38557 . 3)) ((c def c (c (? . 1) q box-mode-top-name)) c (? . 3)) ((c def c (c (? . 1) q page-target-element?)) c (? . 111)) ((c def c (c (? . 1) q delayed-element?)) c (? . 17)) ((c def c (c (? . 1) q compound-paragraph-style)) c (? . 20)) ((c def c (c (? . 4) q html-defaults)) c (? . 58)) ((c def c (c (? . 0) q item)) q (3568 . 3)) ((c form c (c (? . 5) q defmodulereader*)) q (18263 . 2)) ((c def c (c (? . 5) q cite)) q (32102 . 3)) ((c def c (c (? . 1) q target-element-_tag)) c (? . 41)) ((c def c (c (? . 1) q element?)) c (? . 37)) ((c form c (c (? . 5) q schemeid)) q (14115 . 2)) ((c form c (c (? . 9) q thing-doc)) q (43255 . 2)) ((c form c (c (? . 7) q defexamples)) q (40145 . 2)) ((c def c (c (? . 6) q block-color)) q (39235 . 2)) ((c form c (c (? . 5) q schemeblock)) q (13695 . 2)) ((c def c (c (? . 8) q part-collect-decl?)) c (? . 45)) ((c def c (c (? . 33) q kleeneplus)) q (45716 . 3)) ((c def c (c (? . 16) q abstract)) q (11201 . 3)) ((c def c (c (? . 5) q racketvalfont)) q (14607 . 3)) ((c def c (c (? . 6) q shaped-parens-shape)) c (? . 26)) ((c form c (c (? . 5) q racketmod)) q (13253 . 8)) ((c form c (c (? . 7) q examples)) q (40089 . 2)) ((c def c (c (? . 1) q make-target-url)) c (? . 11)) ((c def c (c (? . 4) q js-style-addition)) c (? . 84)) ((q def ((lib "scribble/text-render.rkt") render-mixin)) q (72762 . 3)) ((c def c (c (? . 8) q decode-flow)) q (74781 . 3)) ((c def c (c (? . 98) q read)) q (53310 . 3)) ((c def c (c (? . 1) q part-relative-element-sizer)) c (? . 29)) ((c def c (c (? . 4) q url-anchor)) c (? . 71)) ((c def c (c (? . 4) q struct:render-convertible-as)) c (? . 113)) ((c def c (c (? . 1) q background-color-property?)) c (? . 57)) ((c form c (c (? . 7) q interaction)) q (39299 . 8)) ((c form c (c (? . 9) q require/doc)) q (44932 . 2)) ((c def c (c (? . 4) q css-style-addition?)) c (? . 30)) ((c def c (c (? . 5) q racketplainfont)) q (14514 . 3)) ((c def c (c (? . 1) q make-color-property)) c (? . 44)) ((c def c (c (? . 5) q bib-entry?)) q (32895 . 3)) ((c def c (c (? . 1) q redirect-target-element)) c (? . 46)) ((c def c (c (? . 1) q collect-info-ext-ht)) c (? . 10)) ((c def c (c (? . 1) q target-url?)) c (? . 11)) ((c def c (c (? . 0) q verbatim)) q (4487 . 4)) ((c def c (c (? . 0) q margin-note)) q (3132 . 4)) ((c def c (c (? . 1) q nested-flow-style)) c (? . 14)) ((c def c (c (? . 1) q traverse-block-block)) q (63566 . 4)) ((c def c (c (? . 1) q link-element?)) c (? . 19)) ((c def c (c (? . 1) q paragraph-style)) c (? . 12)) ((c def c (c (? . 8) q clean-up-index-string)) q (76451 . 3)) ((c def c (c (? . 2) q category)) q (10211 . 9)) ((c def c (c (? . 23) q struct:latex-defaults)) c (? . 49)) ((c def c (c (? . 5) q t)) q (33136 . 3)) ((c def c (c (? . 5) q aux-elem)) q (28598 . 3)) ((c def c (c (? . 13) q omitable-paragraph?)) q (48399 . 3)) ((c def c (c (? . 1) q make-multiarg-element)) c (? . 21)) ((c form c (c (? . 2) q nocopyright)) q (9388 . 2)) ((c def c (c (? . 6) q variable-id?)) q (38499 . 3)) ((c def c (c (? . 13) q styled-paragraph-style)) q (48245 . 3)) ((c def c (c (? . 0) q ?-)) q (6215 . 2)) ((c def c (c (? . 8) q decode-content)) q (75036 . 3)) ((c def c (c (? . 1) q table-cells?)) c (? . 27)) ((c form c (c (? . 5) q schemegrammar)) q (26334 . 2)) ((c def c (c (? . 4) q part-link-redirect-url)) c (? . 61)) ((c def c (c (? . 1) q content->string)) q (61209 . 8)) ((c def c (c (? . 6) q var-id-sym)) c (? . 64)) ((c def c (c (? . 13) q image-file?)) c (? . 31)) ((c def c (c (? . 1) q collect-info)) c (? . 10)) ((c def c (c (? . 13) q make-paragraph)) q (47935 . 3)) ((c def c (c (? . 1) q struct:nested-flow)) c (? . 14)) ((c def c (c (? . 15) q make-procedure-index-desc)) c (? . 79)) ((c def c (c (? . 4) q make-body-id)) c (? . 50)) ((c def c (c (? . 1) q document-version?)) c (? . 18)) ((c def c (c (? . 0) q index)) q (8597 . 4)) ((c form c (c (? . 5) q specsubform)) q (22492 . 3)) ((c form c (c (? . 5) q defproc)) q (18596 . 33)) ((c def c (c (? . 1) q make-delayed-block)) c (? . 36)) ((c form c (c (? . 16) q author)) q (11522 . 2)) ((c def c (c (? . 4) q make-script-property)) c (? . 97)) ((c form c (c (? . 5) q defidform)) q (22068 . 2)) ((c def c (c (? . 22) q module-path-index->taglet)) q (80873 . 3)) ((c def c (c (? . 1) q delayed-element-resolve)) c (? . 17)) ((c def c (c (? . 1) q image-element)) c (? . 48)) ((c def c (c (? . 0) q Secref)) q (7086 . 9)) ((c def c (c (? . 1) q make-document-version)) c (? . 18)) ((c def c (c (? . 8) q title-decl)) c (? . 42)) ((c def c (c (? . 1) q struct:link-element)) c (? . 19)) ((c def c (c (? . 8) q part-start-tags)) c (? . 24)) ((c form c (c (? . 5) q racketblock0)) q (12753 . 2)) ((c def c (c (? . 1) q make-itemization)) c (? . 73)) ((c def c (c (? . 1) q target-url-addr)) c (? . 11)) ((c def c (c (? . 1) q plain)) q (60988 . 2)) ((c def c (c (? . 13) q make-versioned-part)) q (46621 . 17)) ((c def c (c (? . 1) q compound-paragraph)) c (? . 20)) ((c def c (c (? . 1) q multiarg-element-style)) c (? . 21)) ((c def c (c (? . 22) q make-module-language-tag)) q (80357 . 3)) ((c def c (c (? . 2) q doi)) q (10098 . 3)) ((c def c (c (? . 15) q struct:exported-index-desc)) c (? . 66)) ((c def c (c (? . 4) q make-head-extra)) c (? . 54)) ((c def c (c (? . 23) q command-extras-arguments)) c (? . 86)) ((c def c (c (? . 13) q styled-paragraph?)) q (48182 . 3)) ((c form c (c (? . 5) q defform*/subs)) q (22809 . 5)) ((c form c (c (? . 5) q definterface)) q (26906 . 2)) ((c def c (c (? . 1) q struct:generated-tag)) c (? . 52)) ((c form c (c (? . 9) q parameter-doc)) q (43311 . 2)) ((c def c (c (? . 4) q struct:alt-tag)) c (? . 43)) ((c def c (c (? . 15) q make-struct-index-desc)) c (? . 63)) ((c form c (c (? . 9) q proc-doc/names)) q (42048 . 15)) ((c def c (c (? . 8) q part-start)) c (? . 24)) ((c def c (c (? . 6) q error-color)) q (39072 . 2)) ((c def c (c (? . 39) q author)) q (10799 . 3)) ((c def c (c (? . 2) q copyrightyear)) q (9936 . 3)) ((c def c (c (? . 5) q indexed-envvar)) q (32010 . 3)) ((c def c (c (? . 4) q css-addition-path)) c (? . 60)) ((c def c (c (? . 5) q envvar)) q (29132 . 3)) ((c def c (c (? . 8) q decode-paragraph)) q (74951 . 3)) ((c def c (c (? . 1) q style-name)) c (? . 25)) ((c def c (c (? . 15) q module-path-index-desc?)) c (? . 106)) ((c def c (c (? . 13) q make-link-element)) q (50937 . 5)) ((c form c (c (? . 5) q schemeresult)) q (14067 . 2)) ((c def c (c (? . 4) q make-column-attributes)) c (? . 62)) ((c def c (c (? . 1) q style)) c (? . 25)) ((c def c (c (? . 13) q make-itemization)) q (48740 . 3)) ((c meth c (c (? . 70) q set-external-tag-path)) q (73032 . 3)) ((c def c (c (? . 32) q xref-tag->index-entry)) q (78556 . 4)) ((c form c (c (? . 9) q proc-doc)) q (42551 . 16)) ((c def c (c (? . 6) q shaped-parens-val)) c (? . 26)) ((c def c (c (? . 6) q make-element-id-transformer)) q (38384 . 3)) ((c def c (c (? . 1) q struct:style)) c (? . 25)) ((c def c (c (? . 13) q make-script-element)) q (51900 . 9)) ((c def c (c (? . 1) q table-cells-styless)) c (? . 27)) ((c def c (c (? . 1) q resolve-info-undef)) c (? . 81)) ((c def c (c (? . 5) q schemeidfont)) q (16221 . 3)) ((c form c (c (? . 102) q chunk)) q (53220 . 2)) ((c form c (c (? . 5) q defproc*)) q (20110 . 6)) ((c def c (c (? . 1) q link-element)) c (? . 19)) ((c def c (? . 101)) q (71575 . 4)) ((c def c (c (? . 1) q part-relative-element-resolve)) c (? . 29)) ((c def c (c (? . 1) q make-index-element)) c (? . 68)) ((c form c (c (? . 7) q with-eval-preserve-source-locations)) q (41956 . 2)) ((c def c (c (? . 6) q reader-color)) q (38775 . 2)) ((c def c (c (? . 1) q struct:delayed-element)) c (? . 17)) ((c def c (c (? . 8) q make-part-start)) c (? . 24)) ((c def c (c (? . 4) q struct:css-style-addition)) c (? . 30)) ((c def c (c (? . 5) q schemeoutput)) q (16862 . 3)) ((c def c (c (? . 0) q subscript)) q (5026 . 3)) ((c def c (c (? . 13) q target-url?)) c (? . 51)) ((c form c (c (? . 5) q defmodule*)) q (18110 . 2)) ((c def c (c (? . 13) q image-file)) c (? . 31)) ((c def c (c (? . 0) q elem)) q (4622 . 4)) ((c def c (c (? . 23) q tex-addition-path)) c (? . 40)) ((c def c (c (? . 5) q void-const)) q (33336 . 2)) ((c form c (c (? . 5) q schememodname)) q (15831 . 3)) ((c def c (c (? . 5) q racketmodfont)) q (15522 . 3)) ((c def c (c (? . 32) q xref-transfer-info)) q (79231 . 5)) ((c def c (c (? . 5) q racketfont)) q (14426 . 3)) ((c def c (c (? . 0) q tabular)) q (3689 . 13)) ((c def c (c (? . 33) q kleenestar)) q (45635 . 3)) ((c def c (c (? . 1) q make-delayed-element)) c (? . 17)) ((c def c (c (? . 15) q mixin-index-desc)) c (? . 34)) ((c def c (c (? . 6) q literal-syntax-stx)) c (? . 38)) ((c meth c (c (? . 35) q get-defineds)) q (71234 . 6)) ((c def c (c (? . 13) q make-with-attributes)) c (? . 72)) ((c def c (c (? . 1) q collect-info-ext-demand)) c (? . 10)) ((c def c (c (? . 1) q compound-paragraph-blocks)) c (? . 20)) ((c form c (c (? . 5) q RACKETBLOCK)) q (12706 . 2)) ((c def c (c (? . 15) q class-index-desc)) c (? . 85)) ((c def c (c (? . 33) q BNF-seq-lines)) q (45393 . 3)) ((c def c (c (? . 13) q make-part)) q (46010 . 15)) ((c def c (c (? . 1) q table?)) c (? . 47)) ((c def c (c (? . 1) q delayed-block?)) c (? . 36)) ((c def c (c (? . 6) q to-element)) q (37155 . 9)) ((c def c (c (? . 15) q interface-index-desc)) c (? . 89)) ((c def c (c (? . 0) q elemref)) q (8343 . 7)) ((c form c (c (? . 5) q defstruct*)) q (24562 . 4)) ((c def c (c (? . 0) q tt)) q (4946 . 3)) ((c def c (c (? . 1) q table-columns)) c (? . 53)) ((c def c (c (? . 1) q element-style)) c (? . 37)) ((c def c (c (? . 6) q literal-syntax?)) c (? . 38)) ((c form c (c (? . 16) q authors)) q (11324 . 8)) ((c form c (c (? . 5) q defform*)) q (21754 . 4)) ((c def c (c (? . 1) q block-width)) q (61514 . 3)) ((c def c (c (? . 39) q author/short)) q (10867 . 4)) ((c def c (c (? . 23) q make-tex-addition)) c (? . 40)) ((c def c (? . 35)) q (69858 . 2)) ((c form c (c (? . 5) q defmethod)) q (27540 . 17)) ((c def c (c (? . 5) q onscreen)) q (28769 . 3)) ((c def c (c (? . 6) q element-id-transformer?)) q (38315 . 3)) ((c def c (c (? . 8) q part-start?)) c (? . 24)) ((c def c (c (? . 5) q techlink)) q (31159 . 12)) ((c form c (c (? . 5) q specform)) q (22401 . 3)) ((c def c (c (? . 1) q make-element)) c (? . 37)) ((c def c (c (? . 1) q target-element)) c (? . 41)) ((c def c (c (? . 13) q make-toc-element)) q (49675 . 5)) ((c def c (c (? . 5) q other-manual)) q (30109 . 5)) ((c def c (c (? . 8) q title-decl-style)) c (? . 42)) ((c def c (c (? . 4) q make-alt-tag)) c (? . 43)) ((q def ((lib "scribble/markdown-render.rkt") render-mixin)) q (72852 . 3)) ((c def c (c (? . 1) q target-url)) c (? . 11)) ((c def c (c (? . 1) q struct:color-property)) c (? . 44)) ((c form c (c (? . 16) q institute)) q (11638 . 2)) ((c def c (c (? . 5) q signature-desc)) q (28489 . 3)) ((c form c (c (? . 5) q RACKETRESULTBLOCK0)) q (13009 . 2)) ((c def c (c (? . 6) q meta-color)) q (38926 . 2)) ((c def c (c (? . 33) q optional)) q (45556 . 3)) ((c form c (c (? . 5) q deftogether)) q (25654 . 2)) ((c def c (c (? . 5) q racketmetafont)) q (15246 . 3)) ((c def c (c (? . 8) q part-collect-decl-element)) c (? . 45)) ((c form c (c (? . 5) q defclass/title)) q (26828 . 2)) ((c def c (c (? . 33) q BNF)) q (45143 . 3)) ((c def c (c (? . 13) q part-flow)) q (46497 . 3)) ((c def c (c (? . 77) q itemize)) q (53054 . 4)) ((c def c (c (? . 1) q redirect-target-element-alt-anchor)) c (? . 46)) ((c def c (c (? . 1) q make-traverse-element)) c (? . 67)) ((c def c (c (? . 1) q table)) c (? . 47)) ((c def c (c (? . 1) q block-traverse-procedure/c)) q (63822 . 2)) ((c form c (c (? . 0) q include-section)) q (2380 . 2)) ((c def c (c (? . 5) q DFlag)) q (29298 . 3)) ((c def c (c (? . 1) q paragraph-content)) c (? . 12)) ((c def c (c (? . 8) q decode-string)) q (75193 . 3)) ((c def c (c (? . 4) q document-source)) c (? . 96)) ((c def c (c (? . 1) q struct:image-element)) c (? . 48)) ((c def c (c (? . 13) q part-title-content)) q (46560 . 3)) ((c def c (c (? . 1) q part-blocks)) c (? . 56)) ((c form c (c (? . 5) q defidform/inline)) q (22130 . 3)) ((c def c (c (? . 23) q latex-defaults-prefix)) c (? . 49)) ((c def c (c (? . 4) q struct:body-id)) c (? . 50)) ((c form c (c (? . 7) q interaction/no-prompt)) q (39553 . 2)) ((c def c (c (? . 13) q auxiliary-table?)) q (49388 . 3)) ((c def c (c (? . 0) q para)) q (2736 . 4)) ((c def c (c (? . 8) q pre-content?)) q (74350 . 3)) ((c form c (c (? . 5) q racketmodname)) q (14159 . 6)) ((c def c (c (? . 13) q target-url)) c (? . 51)) ((c def c (c (? . 23) q latex-defaults)) c (? . 49)) ((c def c (c (? . 13) q make-toc-target-element)) q (49952 . 5)) ((c def c (c (? . 32) q entry-words)) c (? . 94)) ((c def c (c (? . 0) q local-table-of-contents)) q (9245 . 3)) ((c def c (c (? . 6) q input-color)) q (38680 . 2)) ((c def c (c (? . 1) q make-generated-tag)) c (? . 52)) ((c form c (c (? . 5) q racketgrammar*)) q (25915 . 2)) ((c def c (c (? . 1) q make-collect-element)) c (? . 78)) ((c def c (c (? . 1) q nested-flow?)) c (? . 14)) ((c form c (c (? . 5) q defstruct)) q (24722 . 23)) ((c def c (c (? . 5) q math)) q (33658 . 3)) ((c def c (c (? . 1) q struct:element)) c (? . 37)) ((c def c (c (? . 22) q method-tag?)) q (81523 . 3)) ((c def c (c (? . 0) q subsubsection)) q (1459 . 9)) ((c def c (c (? . 13) q make-image-file)) c (? . 31)) ((c def c (c (? . 39) q abstract)) q (10676 . 3)) ((c def c (c (? . 1) q struct:table-columns)) c (? . 53)) ((c def c (c (? . 4) q head-extra?)) c (? . 54)) ((c form c (c (? . 9) q struct-doc)) q (43742 . 6)) ((c def c (c (? . 4) q hover-property-text)) c (? . 55)) ((c def c (c (? . 1) q collected-info-info)) c (? . 69)) ((c form c (c (? . 5) q defmodulereader*/no-declare)) q (18511 . 2)) ((c def c (c (? . 6) q to-paragraph)) q (36007 . 11)) ((c def c (c (? . 6) q symbol-color)) q (38983 . 2)) ((c def c (c (? . 8) q part-tag-decl-tag)) c (? . 65)) ((c def c (c (? . 1) q struct:collect-info)) c (? . 10)) ((c def c (c (? . 1) q part-title-content)) c (? . 56)) ((c def c (c (? . 15) q make-method-index-desc)) c (? . 92)) ((c def c (c (? . 0) q centered)) q (3051 . 3)) ((c def c (c (? . 1) q background-color-property)) c (? . 57)) ((c form c (c (? . 5) q codeblock0)) q (12267 . 2)) ((c def c (c (? . 4) q attributes)) c (? . 75)) ((c form c (c (? . 104) q include-previously-extracted)) q (45084 . 2)) ((c def c (c (? . 6) q just-context?)) c (? . 112)) ((c def c (c (? . 5) q schemevalfont)) q (16036 . 3)) ((c def c (c (? . 1) q traverse-block?)) c (? . 80)) ((c def c (c (? . 4) q html-defaults-style)) c (? . 58)) ((c def c (c (? . 6) q module-link-color)) q (39200 . 2)) ((c def c (c (? . 5) q schemevarfont)) q (16311 . 3)) ((c def c (c (? . 5) q pidefterm)) q (31833 . 3)) ((c def c (c (? . 1) q struct:toc-target2-element)) c (? . 59)) ((c def c (c (? . 8) q part-start-depth)) c (? . 24)) ((c def c (c (? . 1) q compound-paragraph?)) c (? . 20)) ((c def c (c (? . 4) q css-addition?)) c (? . 60)) ((c def c (c (? . 4) q make-part-link-redirect)) c (? . 61)) ((c def c (c (? . 4) q column-attributes)) c (? . 62)) ((q def ((lib "scribble/pdf-render.rkt") render-mixin)) q (73494 . 3)) ((c def c (c (? . 15) q struct-index-desc?)) c (? . 63)) ((c def c (c (? . 13) q paragraph-content)) q (48009 . 3)) ((c form c (c (? . 9) q for-doc)) q (42012 . 2)) ((c def c (c (? . 6) q to-element/no-color)) q (37448 . 7)) ((c def c (c (? . 6) q var-id?)) c (? . 64)) ((c def c (c (? . 15) q thing-index-desc?)) c (? . 83)) ((c def c (c (? . 1) q collect-info?)) c (? . 10)) ((c def c (c (? . 15) q form-index-desc)) c (? . 88)) ((c def c (c (? . 8) q part-tag-decl)) c (? . 65)) ((c def c (c (? . 15) q exported-index-desc-name)) c (? . 66)) ((c def c (c (? . 1) q toc-element)) c (? . 74)) ((c def c (c (? . 13) q make-auxiliary-table)) q (49225 . 4)) ((c form c (c (? . 5) q indexed-scheme)) q (31711 . 2)) ((c def c (c (? . 5) q undefined-const)) q (33366 . 2)) ((c form c (c (? . 5) q racketresult)) q (13603 . 2)) ((c def c (c (? . 1) q struct:document-version)) c (? . 18)) ((c def c (c (? . 13) q table-flowss)) q (48617 . 4)) ((c def c (c (? . 22) q taglet?)) q (80431 . 3)) ((c def c (c (? . 1) q traverse-element)) c (? . 67)) ((c def c (c (? . 13) q target-url-addr)) c (? . 51)) ((c def c (c (? . 22) q definition-tag->class/interface-tag)) q (81016 . 4)) ((c def c (c (? . 4) q alt-tag?)) c (? . 43)) ((c def c (c (? . 1) q struct:document-date)) c (? . 90)) ((c def c (c (? . 1) q index-element-tag)) c (? . 68)) ((c def c (c (? . 1) q collected-info-parent)) c (? . 69)) ((c meth c (c (? . 70) q set-external-root-url)) q (73115 . 3)) ((c def c (c (? . 13) q make-element)) q (49578 . 4)) ((c def c (c (? . 4) q make-url-anchor)) c (? . 71)) ((c def c (c (? . 76) q fetch-blueboxes-method-tags)) q (81913 . 7)) ((c def c (c (? . 13) q struct:with-attributes)) c (? . 72)) ((c def c (c (? . 1) q itemization-style)) c (? . 73)) ((c def c (c (? . 6) q make-literal-syntax)) c (? . 38)) ((c def c (c (? . 13) q element->string)) q (52709 . 8)) ((c def c (c (? . 1) q toc-element-toc-content)) c (? . 74)) ((c form c (c (? . 5) q defconstructor/auto-super)) q (27466 . 2)) ((c def c (c (? . 32) q load-xref)) q (76574 . 13)) ((c def c (c (? . 4) q attributes?)) c (? . 75)) ((c def c (c (? . 1) q make-image-element)) c (? . 48)) ((c def c (c (? . 1) q part)) c (? . 56)) ((c def c (c (? . 76) q make-blueboxes-cache)) q (82260 . 6)) ((c form c (c (? . 5) q racketinput)) q (13063 . 2)) ((c def c (c (? . 5) q schemefont)) q (15948 . 3)) ((c def c (c (? . 8) q part-start-style)) c (? . 24)) ((c def c (c (? . 1) q render-element)) c (? . 109)) ((c def c (c (? . 0) q index-section)) q (9096 . 3)) ((c def c (c (? . 13) q target-url-style)) c (? . 51)) ((c def c (c (? . 1) q element-style?)) q (61011 . 3)) ((c def c (c (? . 1) q element-content)) c (? . 37)) ((c def c (c (? . 77) q span-class)) q (52934 . 4)) ((c form c (c (? . 5) q RACKETBLOCK0)) q (12801 . 2)) ((c def c (c (? . 1) q multiarg-element)) c (? . 21)) ((c def c (c (? . 1) q collect-element?)) c (? . 78)) ((c form c (c (? . 7) q defs+int)) q (40009 . 2)) ((c form c (c (? . 5) q defparam)) q (23571 . 5)) ((c def c (c (? . 4) q body-id?)) c (? . 50)) ((c def c (c (? . 6) q struct:long-boolean)) c (? . 95)) ((c def c (c (? . 15) q procedure-index-desc?)) c (? . 79)) ((c form c (c (? . 5) q defmixin/title)) q (27098 . 2)) ((c def c (c (? . 1) q box-mode*)) q (60664 . 3)) ((c def c (c (? . 5) q procedure)) q (15703 . 3)) ((c form c (c (? . 7) q interaction-eval)) q (39617 . 2)) ((c def c (c (? . 4) q link-resource)) c (? . 82)) ((c def c (c (? . 1) q struct:compound-paragraph)) c (? . 20)) ((c def c (c (? . 13) q make-unnumbered-part)) q (47309 . 15)) ((c def c (c (? . 1) q traverse-block-traverse)) c (? . 80)) ((c def c (c (? . 1) q multiarg-element?)) c (? . 21)) ((c def c (c (? . 22) q doc-prefix)) q (80484 . 8)) ((c def c (c (? . 15) q make-constructor-index-desc)) c (? . 105)) ((c def c (c (? . 5) q centerline)) q (33575 . 3)) ((c form c (c (? . 5) q specform/subs)) q (22943 . 5)) ((c def c (c (? . 1) q part-to-collect)) c (? . 56)) ((c def c (c (? . 13) q unnumbered-part?)) q (47873 . 3)) ((c def c (c (? . 1) q resolve-info-ci)) c (? . 81)) ((c def c (c (? . 1) q color-property)) c (? . 44)) ((c form c (c (? . 5) q defform)) q (20389 . 26)) ((c def c (c (? . 8) q make-splice)) c (? . 93)) ((c def c (c (? . 4) q js-addition?)) c (? . 87)) ((c form c (c (? . 5) q xmethod)) q (28305 . 2)) ((c def c (c (? . 4) q struct:link-resource)) c (? . 82)) ((c def c (c (? . 1) q table-columns-styles)) c (? . 53)) ((c def c (c (? . 1) q traverse-element?)) c (? . 67)) ((c form c (c (? . 2) q notimes)) q (9424 . 2)) ((c def c (c (? . 13) q element-style)) q (51601 . 3)) ((c def c (c (? . 76) q blueboxes-cache?)) q (82507 . 3)) ((c def c (c (? . 1) q element)) c (? . 37)) ((c def c (c (? . 1) q table-cells)) c (? . 27)) ((c def c (c (? . 0) q as-index)) q (8924 . 3)) ((c def c (c (? . 6) q to-paragraph/prefix)) q (36442 . 17)) ((c def c (c (? . 4) q html-defaults-prefix)) c (? . 58)) ((c def c (c (? . 1) q redirect-target-element?)) c (? . 46)) ((c def c (c (? . 8) q title-decl?)) c (? . 42)) ((c def c (c (? . 1) q make-table)) c (? . 47)) ((c def c (c (? . 5) q filebox)) q (33733 . 4)) ((c def c (c (? . 13) q make-page-target-element)) q (50407 . 6)) ((c def c (c (? . 5) q link)) q (29747 . 10)) ((c def c (c (? . 8) q part-index-decl)) c (? . 103)) ((c def c (c (? . 39) q affiliation-mark)) q (11079 . 3)) ((c def c (c (? . 15) q make-thing-index-desc)) c (? . 83)) ((c form c (c (? . 5) q defsubform*)) q (22298 . 4)) ((c def c (c (? . 4) q make-js-style-addition)) c (? . 84)) ((c def c (c (? . 1) q toc-target2-element)) c (? . 59)) ((c def c (c (? . 4) q make-attributes)) c (? . 75)) ((c def c (c (? . 4) q link-resource?)) c (? . 82)) ((c form c (c (? . 5) q defconstructor)) q (27176 . 5)) ((c def c (c (? . 15) q struct:class-index-desc)) c (? . 85)) ((c form c (c (? . 5) q SCHEMEBLOCK0)) q (13837 . 2)) ((c def c (c (? . 13) q struct:image-file)) c (? . 31)) ((c def c (c (? . 0) q items/c)) q (3535 . 2)) ((c def c (c (? . 23) q tex-addition?)) c (? . 40)) ((c def c (c (? . 13) q make-compound-paragraph)) q (49450 . 4)) ((c def c (c (? . 8) q part-collect-decl)) c (? . 45)) ((c def c (c (? . 4) q js-style-addition-path)) c (? . 84)) ((c def c (c (? . 8) q spliceof)) q (76378 . 3)) ((c def c (c (? . 1) q collected-info?)) c (? . 69)) ((c def c (c (? . 5) q racketerror)) q (15433 . 3)) ((c def c (c (? . 8) q decode-elements)) q (75114 . 3)) ((c def c (c (? . 23) q command-extras?)) c (? . 86)) ((c def c (c (? . 4) q js-addition-path)) c (? . 87)) ((c form c (c (? . 5) q racketinput0)) q (13157 . 2)) ((c def c (c (? . 1) q toc-target2-element-toc-content)) c (? . 59)) ((c def c (c (? . 32) q data+root+doc-id?)) q (79813 . 3)) ((c def c (c (? . 1) q collect-info-ht)) c (? . 10)) ((c form c (c (? . 9) q generate-delayed-documents)) q (44896 . 2)) ((c def c (c (? . 1) q delayed-element-plain)) c (? . 17)) ((c form c (c (? . 16) q email)) q (11655 . 2)) ((c def c (c (? . 15) q make-form-index-desc)) c (? . 88)) ((c def c (c (? . 0) q section-index)) q (9016 . 3)) ((c def c (c (? . 1) q struct:box-mode)) c (? . 3)) ((c form c (c (? . 5) q schemeinput)) q (13885 . 2)) ((c def c (c (? . 1) q table-style)) c (? . 47)) ((c def c (c (? . 1) q part-relative-element)) c (? . 29)) ((c meth c (c (? . 110) q render)) q (73689 . 7)) ((c def c (c (? . 33) q kleenerange)) q (45797 . 5)) ((c form c (c (? . 5) q specsubform/subs)) q (23071 . 5)) ((c def c (c (? . 1) q toc-target-element)) c (? . 100)) ((c def c (c (? . 1) q index-element-plain-seq)) c (? . 68)) ((c def c (c (? . 1) q resolve-get/tentative)) q (63110 . 5)) ((c def c (c (? . 1) q make-table-cells)) c (? . 27)) ((c def c (c (? . 76) q fetch-blueboxes-strs)) q (81642 . 6)) ((c def c (c (? . 6) q value-color)) q (38954 . 2)) ((c def c (c (? . 1) q content-width)) q (61434 . 3)) ((c def c (c (? . 2) q keywords)) q (10598 . 3)) ((c form c (c (? . 5) q defsignature/splice)) q (28424 . 2)) ((c def c (c (? . 15) q form-index-desc?)) c (? . 88)) ((c def c (c (? . 1) q collect-element-collect)) c (? . 78)) ((c def c (c (? . 15) q struct:interface-index-desc)) c (? . 89)) ((c def c (c (? . 1) q paragraph)) c (? . 12)) ((c def c (c (? . 8) q make-part-collect-decl)) c (? . 45)) ((c def c (c (? . 6) q paren-color)) q (38897 . 2)) ((c def c (c (? . 1) q redirect-target-element-alt-path)) c (? . 46)) ((c form c (c (? . 5) q schemelink)) q (29705 . 2)) ((c def c (c (? . 1) q make-link-element)) c (? . 19)) ((c def c (c (? . 0) q linebreak)) q (5975 . 2)) ((c def c (c (? . 33) q BNF-etc)) q (45984 . 2)) ((c def c (c (? . 1) q document-date-text)) c (? . 90)) ((c def c (c (? . 5) q DPFlag)) q (29464 . 3)) ((c form c (c (? . 5) q defsignature)) q (28366 . 2)) ((c def c (c (? . 4) q part-link-redirect?)) c (? . 61)) ((c meth c (c (? . 114) q set-directory-depth)) q (73294 . 3)) ((c def c (c (? . 13) q with-attributes-style)) c (? . 72)) ((c def c (c (? . 5) q PFlag)) q (29381 . 3)) ((c form c (c (? . 5) q racketgrammar)) q (25779 . 5)) ((c def c (c (? . 6) q struct:var-id)) c (? . 64)) ((c def c (c (? . 15) q struct:method-index-desc)) c (? . 92)) ((c def c (c (? . 1) q resolve-get/ext?)) q (62661 . 5)) ((c def c (c (? . 4) q head-extra)) c (? . 54)) ((c def c (c (? . 23) q latex-defaults-extra-files)) c (? . 49)) ((c def c (c (? . 8) q pre-flow?)) q (74408 . 3)) ((c form c (c (? . 7) q racketblock+eval)) q (39740 . 2)) ((c def c (c (? . 0) q index*)) q (8742 . 5)) ((c def c (c (? . 8) q struct:splice)) c (? . 93)) ((c def c (c (? . 32) q make-entry)) c (? . 94)) ((c def c (c (? . 6) q long-boolean?)) c (? . 95)) ((c def c (c (? . 1) q collect-info-fp)) c (? . 10)) ((c def c (c (? . 8) q title-decl-version)) c (? . 42)) ((c def c (c (? . 4) q make-link-resource)) c (? . 82)) ((c def c (c (? . 5) q menuitem)) q (28855 . 4)) ((c def c (c (? . 1) q paragraph?)) c (? . 12)) ((c def c (c (? . 13) q struct:target-url)) c (? . 51)) ((c def c (c (? . 5) q defidentifier)) q (25986 . 9)) ((c def c (c (? . 5) q PLaneT)) q (33240 . 2)) ((c def c (c (? . 0) q table-of-contents)) q (9195 . 2)) ((c def c (c (? . 1) q image-element-path)) c (? . 48)) ((c def c (c (? . 1) q part-collected-info)) q (63388 . 4)) ((c def c (c (? . 4) q struct:document-source)) c (? . 96)) ((c def c (c (? . 6) q var-id)) c (? . 64)) ((c def c (c (? . 13) q styled-itemization-style)) q (49037 . 3)) ((c def c (c (? . 1) q table-blockss)) c (? . 47)) ((c def c (c (? . 23) q command-extras)) c (? . 86)) ((c def c (c (? . 4) q script-property)) c (? . 97)) ((c def c (c (? . 98) q make-at-reader)) q (54794 . 5)) ((c def c (c (? . 7) q make-eval-factory)) q (41064 . 10)) ((c def c (c (? . 1) q resolve-info?)) c (? . 81)) ((c form c (c (? . 5) q history)) q (32951 . 8)) ((c def c (c (? . 13) q with-attributes?)) c (? . 72)) ((c def c (c (? . 4) q document-source-module-path)) c (? . 96)) ((c def c (c (? . 0) q section)) q (589 . 9)) ((c form c (c (? . 5) q defconstructor/make)) q (27336 . 2)) ((c def c (c (? . 32) q xref-index)) q (79375 . 3)) ((c def c (c (? . 15) q method-index-desc-class-tag)) c (? . 92)) ((c def c (c (? . 98) q read-inside)) q (53563 . 3)) ((c meth c (c (? . 107) q render)) q (74071 . 7)) ((c def c (c (? . 0) q .__)) q (6258 . 2)) ((c def c (c (? . 13) q make-styled-itemization)) q (48839 . 4)) ((c def c (c (? . 1) q toc-target-element?)) c (? . 100)) ((c def c (c (? . 1) q struct:paragraph)) c (? . 12)) ((c meth c (c (? . 35) q resolve)) q (70312 . 5)) ((c def c (c (? . 0) q superscript)) q (5113 . 3)) ((c def c (c (? . 23) q latex-defaults?)) c (? . 49)) ((c def c (c (? . 0) q author)) q (2418 . 3)) ((c def c (c (? . 1) q tag?)) q (61071 . 3)) ((c def c (c (? . 1) q block?)) q (60728 . 3)) ((c def c (c (? . 1) q index-element?)) c (? . 68)) ((c def c (c (? . 1) q delayed-element)) c (? . 17)) ((c def c (c (? . 7) q make-base-eval)) q (40204 . 10)) ((c def c (c (? . 1) q make-collected-info)) c (? . 69)) ((c def c (c (? . 1) q resolve-info)) c (? . 81)) ((c def c (c (? . 13) q element?)) q (51486 . 3)) ((c def c (c (? . 4) q body-id-value)) c (? . 50)) ((c def c (c (? . 1) q traverse-element-content)) q (63690 . 4)) ((c def c (c (? . 13) q make-omitable-paragraph)) q (48316 . 3)) ((c def c (c (? . 1) q struct:target-url)) c (? . 11)) ((c def c (c (? . 33) q nonterm)) q (45248 . 3)) ((c def c (c (? . 0) q ._)) q (6236 . 2)) ((c form c (c (? . 5) q codeblock)) q (11693 . 16)) ((c def c (c (? . 5) q racketvarfont)) q (14967 . 3)) ((c def c (c (? . 1) q image-element-suffixes)) c (? . 48)) ((c def c (c (? . 1) q struct:resolve-info)) c (? . 81)) ((c constructor c (? . 101)) q (71649 . 20)) ((c form c (c (? . 16) q include-abstract)) q (11285 . 2)) ((c def c (c (? . 4) q column-attributes?)) c (? . 62)) ((c def c (c (? . 98) q make-at-readtable)) q (53991 . 15)) ((c def c (c (? . 1) q struct:traverse-element)) c (? . 67)) ((c form c (c (? . 5) q definterface/title)) q (26963 . 2)) ((c form c (c (? . 5) q svar)) q (15810 . 2)) ((c form c (c (? . 5) q racketblock)) q (12600 . 5)) ((c def c (c (? . 4) q install-resource)) c (? . 108)) ((c form c (c (? . 5) q method)) q (28263 . 2)) ((c def c (c (? . 1) q make-toc-target2-element)) c (? . 59)) ((c def c (c (? . 8) q pre-part?)) q (74463 . 3)) ((c def c (c (? . 15) q class-index-desc?)) c (? . 85)) ((c form c (c (? . 5) q racketlink)) q (29548 . 6)) ((c def c (c (? . 5) q tech)) q (30667 . 12)) ((c def c (c (? . 4) q struct:css-addition)) c (? . 60)) ((c def c (c (? . 39) q affiliation-sep)) q (11159 . 2)) ((c def c (c (? . 1) q delayed-block)) c (? . 36)) ((c form c (c (? . 5) q defmodule*/no-declare)) q (18338 . 2)) ((c form c (c (? . 102) q CHUNK)) q (53250 . 2)) ((c def c (c (? . 6) q variable-color)) q (39013 . 2)) ((c form c (c (? . 2) q 10pt)) q (9376 . 2)) ((c def c (c (? . 5) q indexed-file)) q (31920 . 3)) ((c form c (c (? . 2) q include-abstract)) q (9541 . 2)) ((c def c (c (? . 5) q racketkeywordfont)) q (15058 . 3)) ((c def c (c (? . 1) q traverse-element-traverse)) c (? . 67)) ((c meth c (c (? . 35) q render)) q (70472 . 5)) ((c def c (c (? . 4) q alt-tag-name)) c (? . 43)) ((c def c (c (? . 1) q document-version-text)) c (? . 18)) ((c def c (c (? . 1) q make-resolve-info)) c (? . 81)) ((c def c (c (? . 6) q make-shaped-parens)) c (? . 26)) ((c def c (c (? . 1) q make-table-columns)) c (? . 53)) ((c def c (c (? . 4) q html-defaults?)) c (? . 58)) ((c def c (c (? . 5) q schemeparenfont)) q (16497 . 3)) ((c def c (c (? . 6) q value-link-color)) q (39136 . 2)) ((c def c (c (? . 8) q struct:part-start)) c (? . 24)) ((c def c (c (? . 4) q js-addition)) c (? . 87)) ((c def c (c (? . 22) q make-section-tag)) q (80033 . 7)) ((c form c (c (? . 5) q defform/none)) q (21954 . 4)) ((c def c (c (? . 5) q racketresultfont)) q (14698 . 5)) ((c def c (c (? . 8) q part-index-decl?)) c (? . 103)) ((c def c (c (? . 1) q make-nested-flow)) c (? . 14)) ((c def c (c (? . 4) q make-document-source)) c (? . 96)) ((c def c (c (? . 5) q bibliography)) q (32164 . 4)) ((c def c (c (? . 6) q long-boolean-val)) c (? . 95)) ((c def c (c (? . 5) q Flag)) q (29216 . 3)) ((c form c (c (? . 104) q provide-extracted)) q (45044 . 2)) ((c def c (c (? . 15) q make-exported-index-desc)) c (? . 66)) ((c def c (c (? . 5) q defterm)) q (28684 . 3)) ((c form c (c (? . 6) q define-code)) q (35802 . 5)) ((c def c (c (? . 4) q struct:html-defaults)) c (? . 58)) ((c def c (c (? . 1) q box-mode)) c (? . 3)) ((c form c (c (? . 5) q racketresultblock0)) q (12902 . 2)) ((c def c (c (? . 1) q make-toc-element)) c (? . 74)) ((c def c (c (? . 0) q image)) q (5518 . 11)) ((c def c (c (? . 5) q schemekeywordfont)) q (16402 . 3)) ((c def c (c (? . 0) q seclink)) q (7445 . 13)) ((c def c (c (? . 1) q part-tag-prefix)) c (? . 56)) ((c def c (c (? . 32) q xref-render)) q (78666 . 13)) ((c def c (c (? . 13) q make-blockquote)) q (49112 . 4)) ((c form c (c (? . 5) q defconstructor*/make)) q (27397 . 2)) ((c form c (c (? . 5) q racketmodlink)) q (14309 . 2)) ((c def c (c (? . 4) q document-source?)) c (? . 96)) ((c def c (c (? . 1) q multiarg-element-contents)) c (? . 21)) ((c def c (c (? . 15) q struct:constructor-index-desc)) c (? . 105)) ((c form c (c (? . 7) q def+int)) q (39937 . 2)) ((c def c (c (? . 6) q highlighted-color)) q (39264 . 2)) ((c def c (c (? . 15) q struct:module-path-index-desc)) c (? . 106)) ((c def c (c (? . 8) q make-title-decl)) c (? . 42)) ((c def c (c (? . 4) q make-css-addition)) c (? . 60)) ((c def c (c (? . 1) q collect-element)) c (? . 78)) ((c form c (c (? . 5) q defmixin)) q (27026 . 2)) ((c def c (c (? . 13) q make-aux-element)) q (51669 . 4)) ((q def ((lib "scribble/render.rkt") render)) q (67834 . 38)) ((c def c (c (? . 4) q struct:head-extra)) c (? . 54)) ((c def c (c (? . 13) q make-target-element)) q (49819 . 5)) ((c def c (c (? . 13) q styled-itemization?)) q (48972 . 3)) ((c def c (c (? . 5) q schemeerror)) q (16682 . 3)) ((c def c (c (? . 39) q affiliation)) q (11002 . 3)) ((c form c (c (? . 5) q defmodule)) q (16952 . 20)) ((c def c (c (? . 33) q BNF-alt)) q (45917 . 3)) ((c def c (c (? . 2) q abstract)) q (9457 . 3)) ((c def c (c (? . 1) q resolve-info-delays)) c (? . 81)) ((c def c (c (? . 98) q read-syntax)) q (53390 . 4)) ((c form c (c (? . 5) q defsubform)) q (22200 . 4)) ((c def c (c (? . 1) q struct:delayed-block)) c (? . 36)) ((c def c (c (? . 4) q struct:hover-property)) c (? . 55)) ((c def c (c (? . 7) q scribble-eval-handler)) q (41583 . 5)) ((c form c (c (? . 5) q SCHEMEBLOCK)) q (13742 . 2)) ((c def c (c (? . 1) q make-part-relative-element)) c (? . 29)) ((c def c (c (? . 1) q make-toc-target-element)) c (? . 100)) ((q def ((lib "scribble/latex-prefix.rkt") unicode-encoding-packages)) q (82569 . 2)) ((c form c (c (? . 104) q include-extracted)) q (45004 . 2)) ((c def c (? . 107)) q (73965 . 3)) ((c def c (c (? . 15) q struct:struct-index-desc)) c (? . 63)) ((c form c (c (? . 5) q var)) q (15790 . 2)) ((c def c (c (? . 22) q get-class/interface-and-method)) q (81288 . 3)) ((c def c (c (? . 4) q make-hover-property)) c (? . 55)) ((c def c (c (? . 6) q input-background-color)) q (38709 . 2)) ((c def c (c (? . 4) q install-resource-path)) c (? . 108)) ((c def c (c (? . 1) q struct:toc-element)) c (? . 74)) ((c def c (c (? . 5) q schememetafont)) q (16590 . 3)) ((c def c (c (? . 32) q xref?)) q (76523 . 3)) ((c def c (c (? . 1) q struct:redirect-target-element)) c (? . 46)) ((c def c (c (? . 1) q make-compound-paragraph)) c (? . 20)) ((c def c (c (? . 1) q color-property-color)) c (? . 44)) ((c def c (c (? . 1) q generated-tag)) c (? . 52)) ((c def c (c (? . 6) q shaped-parens)) c (? . 26)) ((c def c (c (? . 4) q link-resource-path)) c (? . 82)) ((c def c (c (? . 1) q box-mode-center-name)) c (? . 3)) ((c def c (c (? . 1) q struct:table)) c (? . 47)) ((c def c (c (? . 1) q document-date)) c (? . 90)) ((c def c (c (? . 7) q make-base-eval-factory)) q (40613 . 10)) ((c def c (c (? . 1) q struct:background-color-property)) c (? . 57)) ((c form c (c (? . 5) q defmodulelang*/no-declare)) q (18428 . 2)) ((c def c (c (? . 5) q deprecated)) q (33860 . 7)) ((c def c (c (? . 15) q interface-index-desc?)) c (? . 89)) ((c def c (c (? . 23) q latex-defaults-style)) c (? . 49)) ((c def c (c (? . 22) q constructor-tag?)) q (81580 . 3)) ((c def c (c (? . 13) q make-toc-target2-element)) q (50093 . 9)) ((c def c (c (? . 13) q make-redirect-target-element)) q (50551 . 12)) ((c def c (c (? . 1) q render-element?)) c (? . 109)) ((c def c (c (? . 15) q procedure-index-desc)) c (? . 79)) ((c def c (c (? . 0) q literal)) q (5453 . 3)) ((c def c (c (? . 0) q subsubsub*section)) q (1912 . 9)) ((c def c (c (? . 5) q etc)) q (33217 . 2)) ((c def c (c (? . 1) q itemization)) c (? . 73)) ((c def c (c (? . 0) q elemtag)) q (8223 . 4)) ((c def c (c (? . 15) q struct:form-index-desc)) c (? . 88)) ((c def c (c (? . 22) q class/interface-tag->constructor-tag)) q (81146 . 4)) ((c form c (c (? . 5) q defparam*)) q (23802 . 5)) ((c meth c (c (? . 35) q serialize-infos)) q (70703 . 5)) ((c def c (c (? . 13) q make-index-element)) q (51066 . 13)) ((c def c (c (? . 4) q struct:part-link-redirect)) c (? . 61)) ((c def c (c (? . 2) q copyrightdata)) q (10017 . 3)) ((c def c (c (? . 1) q table-columns?)) c (? . 53)) ((c def c (c (? . 4) q make-html-defaults)) c (? . 58)) ((c def c (c (? . 1) q index-element-desc)) c (? . 68)) ((c form c (c (? . 9) q provide/doc)) q (44972 . 2)) ((c form c (c (? . 5) q sigelem)) q (28569 . 2)) ((c def c (? . 110)) q (73584 . 3)) ((c def c (c (? . 13) q make-hover-element)) q (51770 . 5)) ((c def c (c (? . 8) q make-part-index-decl)) c (? . 103)) ((c def c (c (? . 5) q schememodfont)) q (16771 . 3)) ((c def c (c (? . 32) q entry-desc)) c (? . 94)) ((c def c (c (? . 22) q class/interface-tag?)) q (81457 . 3)) ((c def c (c (? . 8) q struct:part-tag-decl)) c (? . 65)) ((c def c (c (? . 1) q make-part)) c (? . 56)) ((c def c (c (? . 13) q with-attributes-assoc)) c (? . 72)) ((c form c (c (? . 5) q defthing)) q (24011 . 17)) ((c def c (c (? . 1) q document-version)) c (? . 18)) ((c def c (c (? . 1) q index-element)) c (? . 68)) ((c def c (c (? . 5) q filepath)) q (28964 . 3)) ((c def c (c (? . 0) q margin-note*)) q (3255 . 4)) ((c def c (c (? . 13) q image-file-scale)) c (? . 31)) ((c def c (c (? . 8) q part-index-decl-entry-seq)) c (? . 103)) ((c def c (c (? . 4) q make-js-addition)) c (? . 87)) ((c def c (c (? . 1) q toc-element?)) c (? . 74)) ((c def c (c (? . 1) q part?)) c (? . 56)) ((c def c (c (? . 1) q make-target-element)) c (? . 41)) ((c def c (c (? . 23) q struct:tex-addition)) c (? . 40)) ((c def c (c (? . 1) q collected-info-number)) c (? . 69)) ((c def c (c (? . 1) q make-traverse-block)) c (? . 80)) ((c def c (c (? . 4) q css-style-addition)) c (? . 30)) ((c def c (c (? . 8) q decode-compound-paragraph)) q (74864 . 3)) ((c def c (c (? . 4) q url-anchor-name)) c (? . 71)) ((c def c (c (? . 5) q current-display-width)) q (26468 . 4)) ((c def c (c (? . 1) q make-collect-info)) c (? . 10)) ((c def c (c (? . 1) q make-document-date)) c (? . 90)) ((c def c (c (? . 1) q tag-key)) q (63489 . 4)) ((c def c (c (? . 0) q nested)) q (2896 . 4)) ((c def c (c (? . 32) q make-data+root+doc-id)) q (79876 . 5)) ((c def c (c (? . 1) q collect-info-tags)) c (? . 10)) ((c def c (c (? . 13) q versioned-part?)) q (47248 . 3)) ((c meth c (c (? . 35) q get-undefined)) q (71487 . 3)) ((c def c (c (? . 1) q element-traverse-procedure/c)) q (63869 . 2)) ((c form c (c (? . 7) q racketblock0+eval)) q (39804 . 2)) ((c def c (c (? . 5) q racketoutput)) q (15613 . 3)) ((c def c (c (? . 7) q scribble-exn->string)) q (41789 . 4)) ((c def c (c (? . 33) q BNF-group)) q (45476 . 3)) ((c def c (c (? . 1) q struct:toc-target-element)) c (? . 100)) ((c form c (c (? . 5) q RACKETINPUT0)) q (13205 . 2)) ((c def c (c (? . 5) q bib-entry)) q (32294 . 15)) ((c def c (c (? . 13) q make-target-url)) c (? . 51)) ((c def c (c (? . 8) q part-index-decl-plain-seq)) c (? . 103)) ((c form c (c (? . 5) q RACKET)) q (13561 . 2)) ((c def c (c (? . 1) q make-background-color-property)) c (? . 57)) ((c def c (c (? . 1) q itemization?)) c (? . 73)) ((c def c (c (? . 1) q resolve-get-keys)) q (63242 . 5)) ((c def c (? . 70)) q (72942 . 3)) ((c def c (c (? . 5) q racketidfont)) q (14877 . 3)) ((c def c (c (? . 6) q syntax-link-color)) q (39101 . 2)) ((c def c (c (? . 0) q hspace)) q (6100 . 3)) ((c def c (c (? . 13) q make-styled-paragraph)) q (48074 . 4)) ((c def c (c (? . 6) q make-var-id)) c (? . 64)) ((c def c (c (? . 1) q box-mode-bottom-name)) c (? . 3)) ((c def c (c (? . 98) q read-syntax-inside)) q (53650 . 8)) ((c def c (c (? . 2) q exclusive-license)) q (10169 . 2)) ((c def c (c (? . 1) q link-element-tag)) c (? . 19)) ((c def c (c (? . 6) q output-color)) q (38650 . 2)) ((c def c (c (? . 1) q delayed-element-sizer)) c (? . 17)) ((c def c (c (? . 15) q exported-index-desc?)) c (? . 66)) ((c def c (c (? . 1) q part-relative-element-plain)) c (? . 29)) ((c form c (c (? . 7) q racketmod+eval)) q (39869 . 2)) ((c def c (c (? . 1) q page-target-element)) c (? . 111)) ((c def c (c (? . 32) q data+root?)) q (79645 . 3)) ((c def c (c (? . 5) q racketparenfont)) q (15153 . 3)) ((c form c (c (? . 5) q indexed-racket)) q (31675 . 2)) ((c def c (c (? . 1) q render-element-render)) c (? . 109)) ((c def c (c (? . 4) q install-resource?)) c (? . 108)) ((c def c (c (? . 0) q ~)) q (6173 . 2)) ((c def c (c (? . 8) q title-decl-tags)) c (? . 42)) ((c def c (c (? . 4) q make-css-style-addition)) c (? . 30)) ((c def c (c (? . 0) q smaller)) q (5202 . 3)) ((c form c (c (? . 5) q racketresultblock)) q (12849 . 2)) ((c form c (c (? . 2) q noqcourier)) q (9439 . 2)) ((c def c (c (? . 6) q just-context-val)) c (? . 112)) ((c def c (c (? . 5) q deftech)) q (30293 . 10)) ((c def c (c (? . 1) q image-element-scale)) c (? . 48)) ((c form c (c (? . 5) q schememodlink)) q (15895 . 2)) ((c def c (c (? . 15) q mixin-index-desc?)) c (? . 34)) ((c form c (c (? . 2) q preprint)) q (9360 . 2)) ((c def c (c (? . 1) q struct:table-cells)) c (? . 27)) ((q form ((lib "scribble/lp-include.rkt") lp-include)) q (53280 . 2)) ((c form c (c (? . 5) q RACKETRESULTBLOCK)) q (12956 . 2)) ((c def c (c (? . 1) q struct:part)) c (? . 56)) ((c def c (c (? . 0) q author+email)) q (2482 . 7)) ((c def c (c (? . 1) q make-style)) c (? . 25)) ((c def c (c (? . 6) q just-context)) c (? . 112)) ((c def c (c (? . 4) q js-style-addition?)) c (? . 84)) ((c def c (c (? . 15) q make-module-path-index-desc)) c (? . 106)) ((c def c (c (? . 23) q make-latex-defaults)) c (? . 49)) ((c def c (c (? . 4) q struct:js-style-addition)) c (? . 84)) ((c def c (c (? . 1) q struct:collect-element)) c (? . 78)) ((c def c (c (? . 5) q commandline)) q (33401 . 3)) ((c def c (c (? . 4) q attributes-assoc)) c (? . 75)) ((c def c (c (? . 1) q collect-info-gen-prefix)) c (? . 10)) ((c form c (c (? . 5) q defmodulereader)) q (18043 . 2)) ((c def c (c (? . 1) q style-properties)) c (? . 25)) ((c def c (c (? . 32) q xref-binding->definition-tag)) q (77223 . 17)) ((c def c (c (? . 15) q exported-index-desc-from-libs)) c (? . 66)) ((c def c (c (? . 0) q item?)) q (3638 . 3)) ((c def c (c (? . 4) q render-convertible-as-types)) c (? . 113)) ((c form c (c (? . 5) q declare-exporting)) q (17612 . 8)) ((c def c (c (? . 15) q struct:mixin-index-desc)) c (? . 34)) ((c def c (c (? . 1) q resolve-info-searches)) c (? . 81)) ((c form c (c (? . 9) q begin-for-doc)) q (44862 . 2)) ((c def c (c (? . 0) q larger)) q (5287 . 3)) ((c def c (c (? . 1) q nested-flow)) c (? . 14)) ((c def c (c (? . 4) q struct:install-resource)) c (? . 108)) ((c form c (c (? . 5) q this-obj)) q (28348 . 2)) ((c def c (c (? . 1) q nested-flow-blocks)) c (? . 14)) ((c def c (c (? . 1) q background-color-property-color)) c (? . 57)) ((c def c (c (? . 1) q collect-info-parts)) c (? . 10)) ((c form c (c (? . 7) q interaction-eval-show)) q (39676 . 2)) ((c form c (c (? . 5) q defboolparam)) q (23931 . 4)) ((c def c (c (? . 8) q part-start-title)) c (? . 24)) ((c def c (c (? . 22) q definition-tag?)) q (81396 . 3)) ((c def c (c (? . 4) q make-install-resource)) c (? . 108)) ((c def c (c (? . 6) q shaped-parens?)) c (? . 26)) ((c def c (c (? . 15) q constructor-index-desc)) c (? . 105)) ((c def c (c (? . 0) q nonbreaking)) q (6011 . 3)) ((c form c (c (? . 5) q defmodulelang*)) q (18190 . 2)) ((c def c (c (? . 4) q struct:script-property)) c (? . 97)) ((c def c (c (? . 4) q struct:url-anchor)) c (? . 71)) ((c def c (c (? . 4) q script-property?)) c (? . 97)) ((c def c (c (? . 15) q exported-index-desc)) c (? . 66)) ((c def c (c (? . 32) q entry?)) c (? . 94)) ((c def c (c (? . 4) q head-extra-xexpr)) c (? . 54)) ((c def c (c (? . 6) q comment-color)) q (38866 . 2)) ((c def c (c (? . 22) q intern-taglet)) q (80960 . 3)) ((c def c (c (? . 1) q struct:index-element)) c (? . 68)) ((c def c (c (? . 5) q manual-doc-style)) q (33266 . 2)) ((c def c (c (? . 1) q traverse-block)) c (? . 80)) ((c form c (c (? . 16) q institutes)) q (11536 . 4)) ((c meth c (c (? . 35) q get-defined)) q (71148 . 3)) ((c def c (c (? . 8) q title-decl-tag-prefix)) c (? . 42)) ((c def c (c (? . 1) q struct:traverse-block)) c (? . 80)) ((c def c (c (? . 0) q bold)) q (4864 . 3)) ((c def c (c (? . 4) q body-id)) c (? . 50)) ((c def c (c (? . 5) q image/plain)) q (34111 . 5)) ((c def c (c (? . 6) q struct:just-context)) c (? . 112)) ((c form c (c (? . 5) q scheme)) q (13983 . 2)) ((c def c (c (? . 1) q delayed-block-resolve)) c (? . 36)) ((c def c (c (? . 1) q part-parts)) c (? . 56)) ((c meth c (c (? . 35) q deserialize-info)) q (70852 . 7)) ((c def c (c (? . 1) q resolve-search)) q (62954 . 6)) ((c def c (c (? . 1) q document-date?)) c (? . 90)) ((c def c (c (? . 1) q struct:page-target-element)) c (? . 111)) ((c def c (c (? . 8) q decode-part)) q (74585 . 6)) ((c def c (c (? . 33) q BNF-seq)) q (45326 . 3)) ((c def c (c (? . 6) q result-color)) q (38805 . 2)) ((c def c (c (? . 13) q with-attributes)) c (? . 72)) ((c def c (c (? . 15) q method-index-desc-method-name)) c (? . 92)) ((c def c (c (? . 6) q module-color)) q (39170 . 2)) ((c def c (c (? . 13) q image-file-path)) c (? . 31)) ((c def c (c (? . 4) q render-convertible-as)) c (? . 113)) ((c def c (c (? . 1) q make-box-mode)) c (? . 3)) ((c def c (c (? . 4) q struct:attributes)) c (? . 75)) ((c def c (c (? . 4) q struct:js-addition)) c (? . 87)) ((c def c (c (? . 1) q info-key?)) q (62369 . 3)) ((c form c (c (? . 9) q form-doc)) q (44003 . 26)) ((c def c (c (? . 4) q script-property-type)) c (? . 97)) ((c def c (c (? . 15) q struct:thing-index-desc)) c (? . 83)) ((c def c (c (? . 15) q module-path-index-desc)) c (? . 106)) ((c def c (c (? . 8) q title-decl-content)) c (? . 42)) ((c def c (c (? . 32) q entry-tag)) c (? . 94)) ((c def c (c (? . 15) q make-class-index-desc)) c (? . 85)) ((c form c (c (? . 9) q struct*-doc)) q (43394 . 9)) ((c def c (c (? . 5) q racketcommentfont)) q (15338 . 3)) ((c def c (c (? . 6) q struct:literal-syntax)) c (? . 38)) ((c def c (c (? . 4) q url-anchor?)) c (? . 71)) ((c def c (c (? . 1) q collect-info-relatives)) c (? . 10)) ((c def c (c (? . 1) q part-relative-element?)) c (? . 29)) ((c def c (c (? . 4) q hover-property?)) c (? . 55)) ((c def c (c (? . 1) q struct:itemization)) c (? . 73)) ((c meth c (c (? . 35) q get-external)) q (71400 . 3)) ((q def ((lib "scribble/latex-render.rkt") render-mixin)) q (73404 . 3)) ((c def c (c (? . 1) q collected-info)) c (? . 69)) ((c def c (c (? . 1) q resolve-get/ext-id)) q (62798 . 5)) ((c def c (c (? . 23) q make-command-extras)) c (? . 86)) ((c meth c (c (? . 35) q collect)) q (70038 . 7)) ((c def c (c (? . 1) q make-redirect-target-element)) c (? . 46)) ((c form c (c (? . 5) q code)) q (12316 . 10)) ((c def c (c (? . 1) q index-element-entry-seq)) c (? . 68)) ((c def c (c (? . 32) q make-data+root)) q (79701 . 4)) ((c def c (c (? . 8) q part-start-tag-prefix)) c (? . 24)) ((c def c (c (? . 6) q no-color)) q (38749 . 2)) ((c def c (c (? . 1) q struct:target-element)) c (? . 41)) ((c def c (c (? . 0) q subsection)) q (1018 . 9)) ((c def c (c (? . 4) q column-attributes-assoc)) c (? . 62)) ((c def c (c (? . 5) q schemeresultfont)) q (16127 . 3)) ((c def c (c (? . 0) q itemlist)) q (3390 . 4)) ((c def c (c (? . 1) q collect-put!)) q (62424 . 5)) ((c def c (c (? . 0) q secref)) q (6727 . 9)) ((c form c (c (? . 5) q defmodulelang)) q (17848 . 4)) ((c def c (c (? . 6) q opt-color)) q (39045 . 2)) ((c def c (c (? . 4) q struct:column-attributes)) c (? . 62)) ((c def c (c (? . 5) q idefterm)) q (31747 . 3)) ((c def c (c (? . 5) q inset-flow)) q (33492 . 3)) ((c form c (c (? . 5) q defmethod*)) q (28073 . 5)) ((c def c (c (? . 15) q method-index-desc)) c (? . 92)) ((c def c (c (? . 2) q authorinfo)) q (9666 . 5)) ((c form c (c (? . 5) q SCHEME)) q (14025 . 2)) ((c def c (c (? . 1) q itemization-blockss)) c (? . 73)) ((c def c (c (? . 15) q struct:procedure-index-desc)) c (? . 79)) ((c def c (c (? . 2) q terms)) q (10523 . 3)) ((c form c (c (? . 5) q schemeblock0)) q (13789 . 2)) ((c def c (c (? . 4) q html-defaults-extra-files)) c (? . 58)) ((c def c (c (? . 23) q struct:command-extras)) c (? . 86)) ((c form c (c (? . 39) q include-abstract)) q (10760 . 2)) ((c def c (c (? . 5) q litchar)) q (14362 . 3)) ((c def c (c (? . 1) q make-render-element)) c (? . 109)) ((c def c (c (? . 8) q struct:part-index-decl)) c (? . 103)) ((c def c (c (? . 32) q entry-content)) c (? . 94)) ((c def c (c (? . 6) q keyword-color)) q (38835 . 2)) ((c def c (c (? . 1) q generated-tag?)) c (? . 52)) ((c def c (c (? . 1) q style?)) c (? . 25)) ((c def c (c (? . 15) q constructor-index-desc-class-tag)) c (? . 105)) ((c form c (c (? . 5) q defclass)) q (26609 . 8)) ((c form c (c (? . 5) q RACKETINPUT)) q (13110 . 2)) ((c def c (c (? . 98) q use-at-readtable)) q (54951 . 2)) ((c def c (c (? . 1) q image-element?)) c (? . 48)) ((c def c (c (? . 15) q struct-index-desc)) c (? . 63)) ((c form c (c (? . 5) q schememod)) q (13932 . 2)) ((c form c (c (? . 2) q onecolumn)) q (9407 . 2)) ((c def c (c (? . 13) q element-content)) q (51540 . 3)) ((c def c (c (? . 1) q part-tags)) c (? . 56)) ((c def c (c (? . 8) q part-tag-decl?)) c (? . 65)) ((c def c (c (? . 1) q content?)) q (60780 . 3)) ((c def c (c (? . 4) q alt-tag)) c (? . 43)) ((c def c (c (? . 8) q splice-run)) c (? . 93)) ((c meth c (c (? . 35) q traverse)) q (69893 . 4)) ((c def c (c (? . 8) q splice)) c (? . 93)) ((c def c (c (? . 15) q method-index-desc?)) c (? . 92)) ((c def c (c (? . 6) q just-context-context)) c (? . 112)) ((c def c (c (? . 32) q entry)) c (? . 94)) ((c def c (c (? . 5) q exec)) q (29050 . 3)) ((c def c (c (? . 8) q struct:part-collect-decl)) c (? . 45)) ((c def c (c (? . 6) q literal-syntax)) c (? . 38)) ((c def c (c (? . 4) q css-addition)) c (? . 60)) ((c def c (c (? . 22) q module-path-prefix->string)) q (80781 . 3)) ((c def c (c (? . 4) q part-link-redirect)) c (? . 61)) ((c def c (c (? . 8) q whitespace?)) q (75264 . 3)) ((c def c (c (? . 32) q xref-tag->path+anchor)) q (78080 . 12)) ((c def c (c (? . 8) q struct:title-decl)) c (? . 42)) ((c def c (c (? . 4) q css-style-addition-path)) c (? . 30)) ((c def c (c (? . 1) q struct:part-relative-element)) c (? . 29)) ((c def c (c (? . 0) q url)) q (6670 . 3)) ((c def c (c (? . 15) q constructor-index-desc?)) c (? . 105)) ((c def c (c (? . 8) q splice?)) c (? . 93)) ((c def c (c (? . 0) q italic)) q (4780 . 3)) ((c def c (c (? . 1) q color-property?)) c (? . 44)) ((c def c (c (? . 1) q struct:render-element)) c (? . 109)) ((c def c (c (? . 1) q struct:collected-info)) c (? . 69)) ((c def c (c (? . 7) q close-eval)) q (41500 . 3)) ((c def c (c (? . 32) q struct:entry)) c (? . 94)) ((c def c (c (? . 4) q script-property-script)) c (? . 97)) ((c form c (c (? . 5) q defform/subs)) q (22684 . 5)) ((c def c (c (? . 23) q tex-addition)) c (? . 40)) ((c def c (c (? . 1) q target-element?)) c (? . 41)) ((c def c (c (? . 1) q resolve-get)) q (62539 . 5)) ((c form c (c (? . 5) q schemegrammar*)) q (26397 . 2)) ((c def c (c (? . 5) q hash-lang)) q (33300 . 2)) ((c form c (c (? . 5) q specspecsubform/subs)) q (23202 . 5)) ((c def c (? . 114)) q (73198 . 3)) ((c def c (c (? . 4) q render-convertible-as?)) c (? . 113)) ((c def c (c (? . 6) q struct:shaped-parens)) c (? . 26)) ((c def c (c (? . 8) q decode)) q (74518 . 3)) ((c form c (c (? . 5) q racket)) q (13519 . 2)) ((c form c (c (? . 5) q racketmod0)) q (13455 . 2)) ((c def c (c (? . 6) q make-long-boolean)) c (? . 95)) ((c def c (c (? . 1) q part-style)) c (? . 56)) ((c form c (c (? . 7) q interaction0)) q (39493 . 2)) ((c def c (c (? . 1) q make-page-target-element)) c (? . 111)) ((c def c (c (? . 0) q -~-)) q (6193 . 2)) ((c def c (c (? . 4) q make-render-convertible-as)) c (? . 113)) ((c def c (c (? . 1) q struct:multiarg-element)) c (? . 21)) ((c def c (c (? . 6) q long-boolean)) c (? . 95)) ((c def c (c (? . 6) q make-just-context)) c (? . 112)) ((c def c (c (? . 8) q make-part-tag-decl)) c (? . 65)) ((c def c (c (? . 13) q make-table)) q (48464 . 4)) ((c def c (c (? . 15) q thing-index-desc)) c (? . 83)) ((c def c (c (? . 15) q make-interface-index-desc)) c (? . 89)) ((c def c (c (? . 0) q emph)) q (5371 . 3)) ((c def c (c (? . 0) q hyperlink)) q (6281 . 10)) ((c form c (c (? . 5) q specspecsubform)) q (22586 . 3))))
procedure
(title [#:tag tag                   
        #:tag-prefix tag-prefix     
        #:style style               
        #:version vers              
        #:date date]                
        pre-content ...+)       -> title-decl?
  tag : (or/c #f string? (listof string?)) = #f
  tag-prefix : (or/c #f string? module-path?) = #f
  style : (or/c style? #f string? symbol? (listof symbol?)) = #f
  vers : (or/c string? #f) = #f
  date : (or/c string? #f) = #f
  pre-content : pre-content?
procedure
(section [#:tag tag                   
          #:tag-prefix tag-prefix     
          #:style style]              
          pre-content ...+)       -> part-start?
  tag : (or/c #f string? (listof string?)) = #f
  tag-prefix : (or/c #f string? module-path?) = #f
  style : (or/c style? #f string? symbol? (listof symbol?)) = #f
  pre-content : pre-content?
procedure
(subsection [#:tag tag                   
             #:tag-prefix tag-prefix     
             #:style style]              
             pre-content ...+)       -> part-start?
  tag : (or/c #f string? (listof string?)) = #f
  tag-prefix : (or/c #f string? module-path?) = #f
  style : (or/c style? #f string? symbol? (listof symbol?)) = #f
  pre-content : pre-content?
procedure
(subsubsection [#:tag tag                   
                #:tag-prefix tag-prefix     
                #:style style]              
                pre-content ...+)       -> part-start?
  tag : (or/c #f string? (listof string?)) = #f
  tag-prefix : (or/c #f string? module-path?) = #f
  style : (or/c style? #f string? symbol? (listof symbol?)) = #f
  pre-content : pre-content?
procedure
(subsubsub*section [#:tag tag                   
                    #:tag-prefix tag-prefix     
                    #:style style]              
                    pre-content ...+)       -> paragraph?
  tag : (or/c #f string? (listof string?)) = #f
  tag-prefix : (or/c #f string? module-path?) = #f
  style : (or/c style? #f string? symbol? (listof symbol?)) = #f
  pre-content : pre-content?
syntax
(include-section module-path)
procedure
(author auth ...) -> block?
  auth : content?
procedure
(author+email  author-name                   
               email                         
              [#:obfuscate? obfuscate?]) -> element?
  author-name : content?
  email : string?
  obfuscate? : any/c = #f
procedure
(para [#:style style] pre-content ...) -> paragraph?
  style : (or/c style? string? symbol? #f) = #f
  pre-content : pre-content?
procedure
(nested [#:style style] pre-flow ...) -> nested-flow?
  style : (or/c style? string? symbol? #f) = #f
  pre-flow : pre-flow?
procedure
(centered pre-flow ...) -> nested-flow?
  pre-flow : pre-flow?
procedure
(margin-note pre-flow ... [#:left? left?]) -> block?
  pre-flow : pre-flow?
  left? : any/c = #f
procedure
(margin-note* pre-content ... [#:left? left?]) -> element?
  pre-content : pre-content?
  left? : any/c = #f
procedure
(itemlist itm ... [#:style style]) -> itemization?
  itm : items/c
  style : (or/c style? string? symbol? #f) = #f
value
items/c : flat-contract?
procedure
(item pre-flow ...) -> item?
  pre-flow : pre-flow?
procedure
(item? v) -> boolean?
  v : any/c
procedure
(tabular  cells                                     
         [#:style style                             
          #:sep sep                                 
          #:column-properties column-properties     
          #:row-properties row-properties           
          #:cell-properties cell-properties])   -> table?
  cells : (listof (listof (or/c block? content? 'cont)))
  style : (or/c style? string? symbol? #f) = #f
  sep : (or/c block? content? #f) = #f
  column-properties : (listof any/c) = '()
  row-properties : (listof any/c) = '()
  cell-properties : (listof (listof any/c)) = '()

recipe      vegetable
---------------------
caldo verde      kale
kinpira gobō  burdock
makizushi
procedure
(verbatim [#:indent indent] elem ...+) -> block?
  indent : exact-nonnegative-integer? = 0
  elem : content?
procedure
(elem pre-content ... [#:style style]) -> element?
  pre-content : pre-content?
  style : (or/c style? string? symbol? #f) = #f
procedure
(italic pre-content ...) -> element?
  pre-content : pre-content?
procedure
(bold pre-content ...) -> element?
  pre-content : pre-content?
procedure
(tt pre-content ...) -> element?
  pre-content : pre-content?
procedure
(subscript pre-content ...) -> element?
  pre-content : pre-content?
procedure
(superscript pre-content ...) -> element?
  pre-content : pre-content?
procedure
(smaller pre-content ...) -> element?
  pre-content : pre-content?
procedure
(larger pre-content ...) -> element?
  pre-content : pre-content?
procedure
(emph pre-content ...) -> element?
  pre-content : pre-content?
procedure
(literal str ...+) -> element?
  str : string?
procedure
(image  path                    
       [#:scale scale           
        #:suffixes suffixes     
        #:style style]          
        pre-content ...)    -> image-element?
  path : (or/c path-string? (cons/c 'collects (listof bytes?)))
  scale : real? = 1.0
  suffixes : (listof #rx"^[.]") = null
  style : (or/c style? string? symbol? #f) = #f
  pre-content : pre-content?
procedure
(linebreak) -> element?
procedure
(nonbreaking pre-content ...) -> element?
  pre-content : pre-content?
procedure
(hspace n) -> element?
  n : exact-nonnegative-integer?
value
~ : string?
value
-~- : string?
value
?- : string?
value
._ : element?
value
.__ : element?
procedure
(hyperlink  url                         
            pre-content ...             
           [#:underline? underline?     
            #:style style])         -> element?
  url : string?
  pre-content : pre-content?
  underline? : any/c = #t
  style : (or/c style? string? symbol? #f)
        = (if underline? #f "plainlink")
procedure
(url dest) -> element?
  dest : string?
procedure
(secref  tag                           
        [#:doc module-path             
         #:tag-prefixes prefixes       
         #:underline? underline?]) -> element?
  tag : string?
  module-path : (or/c module-path? #f) = #f
  prefixes : (or/c (listof string?) #f) = #f
  underline? : any/c = #t
procedure
(Secref  tag                           
        [#:doc module-path             
         #:tag-prefixes prefixes       
         #:underline? underline?]) -> element?
  tag : string?
  module-path : (or/c module-path? #f) = #f
  prefixes : (or/c (listof string?) #f) = #f
  underline? : any/c = #t
procedure
(seclink  tag                         
         [#:doc module-path           
          #:tag-prefixes prefixes     
          #:underline? underline?     
          #:indirect? indirect?]      
          pre-content ...)        -> element?
  tag : string?
  module-path : (or/c module-path? #f) = #f
  prefixes : (or/c (listof string?) #f) = #f
  underline? : any/c = #t
  indirect? : any/c = #f
  pre-content : pre-content?
procedure
(other-doc  module-path                 
           [#:underline? underline?     
            #:indirect indirect])   -> element?
  module-path : module-path?
  underline? : any/c = #t
  indirect : (or/c #f content?) = #f
procedure
(elemtag t pre-content ...) -> element?
  t : (or/c tag? string?)
  pre-content : pre-content?
procedure
(elemref  t                             
          pre-content ...               
         [#:underline? underline?]) -> element?
  t : (or/c tag? string?)
  pre-content : pre-content?
  underline? : any/c = #t
procedure
(index words pre-content ...) -> index-element?
  words : (or/c string? (listof string?))
  pre-content : pre-content?
procedure
(index* words word-contents pre-content ...) -> index-element?
  words : (listof string?)
  word-contents : (listof list?)
  pre-content : pre-content?
procedure
(as-index pre-content ...) -> index-element?
  pre-content : pre-content?
procedure
(section-index word ...) -> part-index-decl?
  word : string?
procedure
(index-section [#:tag tag]) -> part?
  tag : (or/c #f string?) = "doc-index"
procedure
(table-of-contents) -> delayed-block?
procedure
(local-table-of-contents [#:style style]) -> delayed-block?
  style : (or/c symbol? #f) = #f
syntax
preprint
syntax
10pt
syntax
nocopyright
syntax
onecolumn
syntax
notimes
syntax
noqcourier
procedure
(abstract pre-content ...) -> block?
  pre-content : pre-content?
syntax
(include-abstract module-path)
procedure
(subtitle pre-content ...) -> element?
  pre-content : pre-content?
procedure
(authorinfo name affiliation email) -> block?
  name : pre-content?
  affiliation : pre-content?
  email : pre-content?
procedure
(conferenceinfo conference location) -> block?
  conference : pre-content?
  location : pre-content?
procedure
(copyrightyear content ...) -> block?
  content : pre-content?
procedure
(copyrightdata content ...) -> block?
  content : pre-content?
procedure
(doi content ...) -> block?
  content : pre-content?
procedure
(exclusive-license) -> block?
procedure
(category  CR-number          
           subcategory        
           third-level        
          [fourth-level]) -> content?
  CR-number : pre-content?
  subcategory : pre-content?
  third-level : pre-content?
  fourth-level : (or/c #f pre-content?) = #f
procedure
(terms content ...) -> content?
  content : pre-content?
procedure
(keywords content ...) -> content?
  content : pre-content?
procedure
(abstract pre-content ...) -> block?
  pre-content : pre-content?
syntax
(include-abstract module-path)
procedure
(author name ...) -> block?
  name : pre-content?
procedure
((author/short short-name ...) long-name ...) -> block?
  short-name : pre-content?
  long-name : pre-content?
procedure
(affiliation place ...) -> element?
  place : pre-content?
procedure
(affiliation-mark mark ...) -> element?
  mark : pre-content?
procedure
(affiliation-sep) -> element?
procedure
(abstract pre-content ...) -> block?
  pre-content : pre-content?
syntax
(include-abstract module-path)
syntax
(authors auth ...)
 
auth = (author pre-content-expr ...)
     | (author #:inst str-expr pre-content-expr ...)
 
  pre-content-expr : pre-content?
  str-expr : string?
syntax
author
syntax
(institutes (institute pre-content-expr ...) ...)
 
  pre-content-expr : pre-content?
syntax
institute
syntax
(email pre-content-expr ...)
syntax
(codeblock option ... str-expr ...+)
 
option = #:keep-lang-line? keep-expr
       | #:indent indent-expr
       | #:expand expand-expr
       | #:context context-expr
       | #:line-numbers line-number-expr
       | #:line-number-sep line-number-sep-expr
 
  keep-expr : any/c
  indent-expr : exact-nonnegative-integer?
  expand-expr : (or/c #f (syntax? . -> . syntax?))
  context-expr : syntax?
  line-number-expr : (or/c #f exact-nonnegative-integer?)
  line-number-sep-expr : exact-nonnegative-integer?
syntax
(codeblock0 option ... str-expr ...+)
syntax
(code option ... str-expr ...+)
 
option = #:lang lang-line-expr
       | #:expand expand-expr
       | #:context context-expr
 
  lang-line-expr : (or/c #f string?)
  expand-expr : (or/c #f (syntax? . -> . syntax?))
  context-expr : syntax?
syntax
(racketblock maybe-escape datum ...)
 
maybe-escape = 
             | #:escape escape-id
syntax
(RACKETBLOCK maybe-escape datum ...)
syntax
(racketblock0 maybe-escape datum ...)
syntax
(RACKETBLOCK0 maybe-escape datum ...)
syntax
(racketresultblock maybe-escape datum ...)
syntax
(racketresultblock0 maybe-escape datum ...)
syntax
(RACKETRESULTBLOCK maybe-escape datum ...)
syntax
(RACKETRESULTBLOCK0 maybe-escape datum ...)
syntax
(racketinput maybe-escape datum ...)
syntax
(RACKETINPUT maybe-escape datum ...)
syntax
(racketinput0 maybe-escape datum ...)
syntax
(RACKETINPUT0 maybe-escape datum ...)
syntax
(racketmod maybe-file maybe-escape lang datum ...)
 
  maybe-file = 
             | #:file filename-expr
                
maybe-escape = 
             | #:escape escape-id
syntax
(racketmod0 maybe-file maybe-escape lang datum ...)
syntax
(racket maybe-escape datum ...)
syntax
(RACKET maybe-escape datum ...)
syntax
(racketresult maybe-escape datum ...)
syntax
(racketid maybe-escape datum ...)
syntax
(schemeblock maybe-escape datum ...)
syntax
(SCHEMEBLOCK maybe-escape datum ...)
syntax
(schemeblock0 maybe-escape datum ...)
syntax
(SCHEMEBLOCK0 maybe-escape datum ...)
syntax
(schemeinput maybe-escape datum ...)
syntax
(schememod lang maybe-escape datum ...)
syntax
(scheme maybe-escape datum ...)
syntax
(SCHEME maybe-escape datum ...)
syntax
(schemeresult maybe-escape datum ...)
syntax
(schemeid maybe-escape datum ...)
syntax
(racketmodname datum maybe-indirect)
(racketmodname (unsyntax expr) maybe-indirect)
 
maybe-indirect = 
               | #:indirect
syntax
(racketmodlink datum pre-content-expr ...)
procedure
(litchar str ...) -> element?
  str : string?
procedure
(racketfont pre-content ...) -> element?
  pre-content : pre-content?
procedure
(racketplainfont pre-content ...) -> element?
  pre-content : pre-content?
procedure
(racketvalfont pre-content ...) -> element?
  pre-content : pre-content?
procedure
(racketresultfont [#:decode? decode?]     
                   pre-content ...)   -> element?
  decode? : boolean? = #t
  pre-content : pre-content?
procedure
(racketidfont pre-content ...) -> element?
  pre-content : pre-content?
procedure
(racketvarfont pre-content ...) -> element?
  pre-content : pre-content?
procedure
(racketkeywordfont pre-content ...) -> element?
  pre-content : pre-content?
procedure
(racketparenfont pre-content ...) -> element?
  pre-content : pre-content?
procedure
(racketmetafont pre-content ...) -> element?
  pre-content : pre-content?
procedure
(racketcommentfont pre-content ...) -> element?
  pre-content : pre-content?
procedure
(racketerror pre-content ...) -> element?
  pre-content : pre-content?
procedure
(racketmodfont pre-content ...) -> element?
  pre-content : pre-content?
procedure
(racketoutput pre-content ...) -> element?
  pre-content : pre-content?
procedure
(procedure pre-content ...) -> element?
  pre-content : pre-content?
syntax
(var datum)
syntax
(svar datum)
syntax
(schememodname datum)
(schememodname (unsyntax expr))
syntax
(schememodlink datum pre-content-expr ...)
procedure
(schemefont pre-content ...) -> element?
  pre-content : pre-content?
procedure
(schemevalfont pre-content ...) -> element?
  pre-content : pre-content?
procedure
(schemeresultfont pre-content ...) -> element?
  pre-content : pre-content?
procedure
(schemeidfont pre-content ...) -> element?
  pre-content : pre-content?
procedure
(schemevarfont pre-content ...) -> element?
  pre-content : pre-content?
procedure
(schemekeywordfont pre-content ...) -> element?
  pre-content : pre-content?
procedure
(schemeparenfont pre-content ...) -> element?
  pre-content : pre-content?
procedure
(schememetafont pre-content ...) -> element?
  pre-content : pre-content?
procedure
(schemeerror pre-content ...) -> element?
  pre-content : pre-content?
procedure
(schememodfont pre-content ...) -> element?
  pre-content : pre-content?
procedure
(schemeoutput pre-content ...) -> element?
  pre-content : pre-content?
syntax
(defmodule maybe-req one-or-multi option ... pre-flow ...)
 
   maybe-req = 
             | #:require-form content-expr
                
one-or-multi = module-spec
             | #:multi (module-spec ...+)
                
 module-spec = module-path
             | content-expr
                
      option = #:module-paths (module-path ...)
             | #:no-declare
             | #:use-sources (src-module-path ...)
             | #:link-target? link-target?-expr
             | #:indirect
             | #:lang
             | #:reader
             | #:packages (pkg-expr ...)
syntax
(declare-exporting module-path ... maybe-pkgs maybe-sources)
 
   maybe-pkgs = 
              | #:packages (pkg-expr ...)
                 
maybe-sources = 
              | #:use-sources (module-path ...)
syntax
(defmodulelang one-or-multi maybe-sources option ... pre-flow ...)
(defmodulelang one-or-multi #:module-path module-path
               option ... pre-flow ...)
syntax
(defmodulereader one-or-multi option ... pre-flow ...)
syntax
(defmodule* maybe-req (module-spec ...+) option ... pre-flow ...)
syntax
(defmodulelang* (module-spec ...+) option ... pre-flow ...)
syntax
(defmodulereader* (module-spec ...+) option ... pre-flow ...)
syntax
(defmodule*/no-declare maybe-req (module-spec ...) option ... pre-flow ...)
syntax
(defmodulelang*/no-declare (module-spec ...) option ... pre-flow ...)
syntax
(defmodulereader*/no-declare (module-spec ...) option ... pre-flow ...)
syntax
(defproc options prototype
         result-contract-expr-datum
         maybe-value
         pre-flow ...)
 
  prototype = (id arg-spec ...)
            | (prototype arg-spec ...)
               
   arg-spec = (arg-id contract-expr-datum)
            | (arg-id contract-expr-datum default-expr)
            | (keyword arg-id contract-expr-datum)
            | (keyword arg-id contract-expr-datum default-expr)
            | ellipses
            | ellipses+
               
    options = maybe-kind maybe-link maybe-id
               
 maybe-kind = 
            | #:kind kind-string-expr
               
 maybe-link = 
            | #:link-target? link-target?-expr
               
   maybe-id = 
            | #:id [src-id dest-id-expr]
               
maybe-value = 
            | #:value value-expr-datum
               
   ellipses = ...
               
  ellipses+ = ...+
procedure
(make-sandwich ingredients) -> sandwich?
  ingredients : (listof ingredient?)
sandwich-maker
(make-reuben  ingredient              
              ...                     
             [#:veggie? veggie?]) -> sandwich?
  ingredient : sauerkraut?
  veggie? : any/c = #f

(arg-id contract-expr-datum)

(arg-id contract-expr-datum default-expr)

(keyword arg-id contract-expr-datum)

(keyword arg-id contract-expr-datum default-expr)

...

...+
syntax
(defproc* options
          ([prototype
            result-contract-expr-datum
            maybe-value] ...)
          pre-flow ...)
procedure
(make-pb&j) -> sandwich?
(make-pb&j jelly) -> sandwich?
  jelly : jelly?
syntax
(defform options form-datum
  maybe-grammar maybe-contracts
  pre-flow ...)
 
        options = maybe-kind maybe-link maybe-id maybe-literals
                   
     maybe-kind = 
                | #:kind kind-string-expr
                   
     maybe-link = 
                | #:link-target? link-target?-expr
                   
       maybe-id = 
                | #:id id
                | #:id [id id-expr]
                   
 maybe-literals = 
                | #:literals (literal-id ...)
                   
  maybe-grammar = 
                | #:grammar ([nonterm-id clause-datum ...+] ...)
                   
maybe-contracts = 
                | #:contracts ([subform-datum contract-expr-datum]
                               ...)
syntax
(sandwich-promise sandwich-expr)
 
  sandwich-expr : sandwich?
syntax
(sandwich-promise* [sandwich sandwich-expr]
                   [mixins ingredient-expr ...])
 
  sandwich-expr : sandwich?
  ingredient-expr : ingredient?
syntax
(sandwich-factory maybe-name factory-component ...)
 
       maybe-name = 
                  | name
                     
factory-component = #:protein protein-expr
                  | [vegetable vegetable-expr]
syntax
(defform* options [form-datum ...+]
  maybe-grammar maybe-contracts
  pre-flow ...)
syntax
(call-with-current-sandwich expr)
(call-with-current-sandwich expr sandwich-handler-expr)
syntax
(defform/none maybe-kind maybe-literal form-datum
  maybe-grammar maybe-contracts
  pre-flow ...)
syntax
(defidform maybe-kind maybe-link id pre-flow ...)
syntax
(defidform/inline id)
(defidform/inline (unsyntax id-expr))
syntax
(defsubform options form-datum
   maybe-grammar maybe-contracts
   pre-flow ...)
syntax
(defsubform* options [form-datum ...+]
  maybe-grammar maybe-contracts
  pre-flow ...)
syntax
(specform maybe-literals datum maybe-grammar maybe-contracts
  pre-flow ...)
syntax
(specsubform maybe-literals datum maybe-grammar maybe-contracts
  pre-flow ...)
syntax
(specspecsubform maybe-literals datum maybe-grammar maybe-contracts
  pre-flow ...)
syntax
(defform/subs options form-datum
  ([nonterm-id clause-datum ...+] ...)
  maybe-contracts
  pre-flow ...)
syntax
(defform*/subs options [form-datum ...+]
  ([nonterm-id clause-datum ...+] ...)
  maybe-contracts
  pre-flow ...)
syntax
(specform/subs maybe-literals datum
  ([nonterm-id clause-datum ...+] ...)
  maybe-contracts
  pre-flow ...)
syntax
(specsubform/subs maybe-literals datum
  ([nonterm-id clause-datum ...+] ...)
  maybe-contracts
  pre-flow ...)
syntax
(specspecsubform/subs maybe-literals datum
 ([nonterm-id clause-datum ...+] ...)
 maybe-contracts
 pre-flow ...)
syntax
(sandwich-factory maybe-name factory-component ...)
 
       maybe-name = 
                  | name
                     
factory-component = #:protein protein-expr
                  | [vegetable vegetable-expr]
syntax
(defparam maybe-link id arg-id
  contract-expr-datum
  maybe-value
  pre-flow ...)
parameter
(current-sandwich) -> sandwich?
(current-sandwich sandwich) -> void?
  sandwich : sandwich?
 = empty-sandwich
syntax
(defparam* maybe-link id arg-id
  in-contract-expr-datum out-contract-expr-datum
  maybe-value
  pre-flow ...)
syntax
(defboolparam maybe-link id arg-id
  maybe-value
  pre-flow ...)
syntax
(defthing options id contract-expr-datum maybe-value
  pre-flow ...)
 
    options = maybe-kind maybe-link maybe-id
               
 maybe-kind = 
            | #:kind kind-string-expr
               
 maybe-link = 
            | #:link-target? link-target?-expr
               
   maybe-id = 
            | #:id id-expr
               
maybe-value = 
            | #:value value-expr-datum
value
moldy-sandwich : sandwich?
value
empty-sandwich : sandwich? = (make-sandwich empty)
syntax
(defstruct* maybe-link struct-name ([field-name contract-expr-datum] ...)
  maybe-mutable maybe-non-opaque maybe-constructor
  pre-flow ...)
syntax
(defstruct maybe-link struct-name ([field-name contract-expr-datum] ...)
  maybe-mutable maybe-non-opaque maybe-constructor
  pre-flow ...)
 
       maybe-link = 
                  | #:link-target? link-target?-expr
                     
      struct-name = id
                  | (id super-id)
                     
    maybe-mutable = 
                  | #:mutable
                     
 maybe-non-opaque = 
                  | #:prefab
                  | #:transparent
                  | #:inspector #f
                     
maybe-constructor = 
                  | #:constructor-name constructor-id
                  | #:extra-constructor-name constructor-id
                  | #:omit-constructor
struct
(struct sandwich (protein sauce)
    #:extra-constructor-name make-sandwich)
  protein : ingredient?
  sauce : ingredient?
syntax
(deftogether [def-expr ...] pre-flow ...)
value
test-sandwich-1 : sandwich?
value
test-sandwich-2 : sandwich?
syntax
(racketgrammar maybe-literals id clause-datum ...+)
 
maybe-literals = 
               | #:literals (literal-id ...)
syntax
(racketgrammar* maybe-literals [id clause-datum ...+] ...)
procedure
(defidentifier  id                            
               [#:form? form?                 
                #:index? index?               
                #:show-libs? show-libs?]) -> element?
  id : identifier?
  form? : boolean? = #f
  index? : boolean? = #t
  show-libs? : boolean? = #t
syntax
(schemegrammar maybe-literals id clause-datum ...+)
syntax
(schemegrammar* maybe-literals [id clause-datum ...+] ...)
parameter
(current-display-width) -> exact-nonnegative-integer?
(current-display-width w) -> void?
  w : exact-nonnegative-integer?
syntax
(defclass maybe-link id super (intf-id ...) pre-flow ...)
 
maybe-link = 
           | #:link-target? link-target?-expr
              
     super = super-id
           | (mixin-id super)
syntax
(defclass/title maybe-link id super (intf-id ...) pre-flow ...)
syntax
(definterface id (intf-id ...) pre-flow ...)
syntax
(definterface/title id (intf-id ...) pre-flow ...)
syntax
(defmixin id (domain-id ...) (range-id ...) pre-flow ...)
syntax
(defmixin/title id (domain-id ...) (range-id ...) pre-flow ...)
syntax
(defconstructor (arg-spec ...) pre-flow ...)
 
arg-spec = (arg-id contract-expr-datum)
         | (arg-id contract-expr-datum default-expr)
syntax
(defconstructor/make (arg-spec ...) pre-flow ...)
syntax
(defconstructor*/make [(arg-spec ...) ...] pre-flow ...)
syntax
(defconstructor/auto-super [(arg-spec ...) ...] pre-flow ...)
syntax
(defmethod maybe-mode maybe-link (id arg-spec ...)
           result-contract-expr-datum
           pre-flow ...)
 
maybe-link = 
           | #:link-target? link-target?-expr
              
maybe-mode = 
           | #:mode override
           | #:mode override-final
           | #:mode public-final
           | #:mode augment
           | #:mode augment-final
           | #:mode pubment
           | #:mode extend
           | #:mode extend-final
syntax
(defmethod* maybe-mode maybe-link
            ([(id arg-spec ...)
              result-contract-expr-datum] ...)
            pre-flow ...)
syntax
(method class/intf-id method-id)
syntax
(xmethod class/intf-id method-id)
syntax
(this-obj)
syntax
(defsignature id (super-id ...) pre-flow ...)
syntax
(defsignature/splice id (super-id ...) pre-flow ...)
procedure
(signature-desc pre-flow ...) -> any/c
  pre-flow : pre-flow?
syntax
(sigelem sig-id id)
procedure
(aux-elem pre-content ...) -> element?
  pre-content : pre-content?
procedure
(defterm pre-content ...) -> element?
  pre-content : pre-content?
procedure
(onscreen pre-content ...) -> element?
  pre-content : pre-content?
procedure
(menuitem menu-name item-name) -> element?
  menu-name : string?
  item-name : string?
procedure
(filepath pre-content ...) -> element?
  pre-content : pre-content?
procedure
(exec pre-content ...) -> element?
  pre-content : pre-content?
procedure
(envvar pre-content ...) -> element?
  pre-content : pre-content?
procedure
(Flag pre-content ...) -> element?
  pre-content : pre-content?
procedure
(DFlag pre-content ...) -> element?
  pre-content : pre-content?
procedure
(PFlag pre-content ...) -> element?
  pre-content : pre-content?
procedure
(DPFlag pre-content ...) -> element?
  pre-content : pre-content?
syntax
(racketlink id #:style style-expr pre-content ...)
(racketlink id pre-content ...)
 
  id : identifier?
  pre-content : pre-content?
syntax
(schemelink id pre-content ...)
procedure
(link  url                         
       pre-content ...             
      [#:underline? underline?     
       #:style style])         -> element?
  url : string?
  pre-content : any/c
  underline? : any/c = #t
  style : (or/c style? string? symbol? #f)
        = (if underline? #f "plainlink")
procedure
(other-manual  module-path                   
              [#:underline? underline?]) -> element?
  module-path : module-path?
  underline? : any/c = #t
procedure
(deftech  pre-content                 
          ...                         
         [#:key key                   
          #:normalize? normalize?     
          #:style? style?])       -> element?
  pre-content : pre-content?
  key : (or/c string? #f) = #f
  normalize? : any/c = #t
  style? : any/c = #t
procedure
(tech  pre-content                   
       ...                           
      [#:key key                     
       #:normalize? normalize?       
       #:doc module-path             
       #:tag-prefixes prefixes]) -> element?
  pre-content : pre-content?
  key : (or/c string? #f) = #f
  normalize? : any/c = #t
  module-path : (or/c module-path? #f) = #f
  prefixes : (or/c (listof string?) #f) = #f
procedure
(techlink  pre-content                   
           ...                           
          [#:key key                     
           #:normalize? normalize?       
           #:doc module-path             
           #:tag-prefixes prefixes]) -> element?
  pre-content : pre-content?
  key : (or/c string? #f) = #f
  normalize? : any/c = #t
  module-path : (or/c module-path? #f) = #f
  prefixes : (or/c (listof string?) #f) = #f
syntax
(indexed-racket datum ...)
syntax
(indexed-scheme datum ...)
procedure
(idefterm pre-content ...) -> element?
  pre-content : pre-content?
procedure
(pidefterm pre-content ...) -> element?
  pre-content : pre-content?
procedure
(indexed-file pre-content ...) -> element?
  pre-content : pre-content?
procedure
(indexed-envvar pre-content ...) -> element?
  pre-content : pre-content?
procedure
(cite key ...+) -> element?
  key : string?
procedure
(bibliography [#:tag tag] entry ...) -> part?
  tag : string? = "doc-bibliography"
  entry : bib-entry?
procedure
(bib-entry  #:key key               
            #:title title           
           [#:is-book? is-book?     
            #:author author         
            #:location location     
            #:date date             
            #:url url])         -> bib-entry?
  key : string?
  title : (or/c #f pre-content?)
  is-book? : boolean? = #f
  author : (or/c #f pre-content?) = #f
  location : (or/c #f pre-content?) = #f
  date : (or/c #f pre-content?) = #f
  url : (or/c #f pre-content?) = #f
procedure
(bib-entry? v) -> boolean?
  v : any/c
syntax
(history clause ...)
 
clause = #:added version-expr
       | #:changed version-expr content-expr
 
  version-expr : valid-version?
  content-expr : content?
procedure
(t pre-content ...) -> paragraph?
  pre-content : pre-content?
value
etc : element?
value
PLaneT : element?
value
manual-doc-style : style?
procedure
(hash-lang) -> element?
value
void-const : element?
value
undefined-const : element?
procedure
(commandline pre-content ...) -> paragraph?
  pre-content : pre-content?
procedure
(inset-flow pre-flow ...) -> nested-flow?
  pre-flow : pre-flow?
procedure
(centerline pre-flow ...) -> nested-flow?
  pre-flow : pre-flow?
procedure
(math pre-content ...) -> element?
  pre-content : any/c
procedure
(filebox filename pre-flow ...) -> block?
  filename : (or/c string? element?)
  pre-flow : pre-flow?
procedure
(deprecated [#:what what]              
             replacement               
             additional-notes ...) -> block?
  what : content? = "library"
  replacement : content?
  additional-notes : content?
procedure
(image/plain filename-relative-to-source     
             pre-element ...)            -> element?
  filename-relative-to-source : string?
  pre-element : any/c
struct
(struct module-path-index-desc ()
    #:extra-constructor-name make-module-path-index-desc)
struct
(struct exported-index-desc (name from-libs)
    #:extra-constructor-name make-exported-index-desc)
  name : symbol?
  from-libs : (listof module-path?)
struct
(struct form-index-desc exported-index-desc ()
    #:extra-constructor-name make-form-index-desc)
struct
(struct procedure-index-desc exported-index-desc ()
    #:extra-constructor-name make-procedure-index-desc)
struct
(struct thing-index-desc exported-index-desc ()
    #:extra-constructor-name make-thing-index-desc)
struct
(struct struct-index-desc exported-index-desc ()
    #:extra-constructor-name make-struct-index-desc)
struct
(struct class-index-desc exported-index-desc ()
    #:extra-constructor-name make-class-index-desc)
struct
(struct interface-index-desc exported-index-desc ()
    #:extra-constructor-name make-interface-index-desc)
struct
(struct mixin-index-desc exported-index-desc ()
    #:extra-constructor-name make-mixin-index-desc)
struct
(struct method-index-desc exported-index-desc (method-name
                                               class-tag)
    #:extra-constructor-name make-method-index-desc)
  method-name : symbol?
  class-tag : tag?
struct
(struct constructor-index-desc exported-index-desc (class-tag)
    #:extra-constructor-name make-constructor-index-desc)
  class-tag : tag?
syntax
(define-code id typeset-expr)
(define-code id typeset-expr uncode-id)
(define-code id typeset-expr uncode-id d->s-expr)
(define-code id typeset-expr uncode-id d->s-expr stx-prop-expr)
procedure
(to-paragraph  v                           
              [#:expr? expr?               
               #:escapes? escapes?         
               #:color? color?             
               #:wrap-elem wrap-elem]) -> block?
  v : any/c
  expr? : any/c = #f
  escapes? : any/c = #t
  color? : any/c = #t
  wrap-elem : (element? . -> . element?) = (lambda (e) e)
procedure
((to-paragraph/prefix  prefix1                     
                       prefix                      
                       suffix)                     
                       v                           
                      [#:expr? expr?               
                       #:escapes? escapes?         
                       #:color? color?             
                       #:wrap-elem wrap-elem]) -> block?
  prefix1 : any/c
  prefix : any/c
  suffix : any/c
  v : any/c
  expr? : any/c = #f
  escapes? : any/c = #t
  color? : any/c = #f
  wrap-elem : (element? . -> . element?) = (lambda (e) e)
procedure
(to-element  v                       
            [#:expr? expr?           
             #:escapes? escapes?     
             #:defn? defn?])     -> element?
  v : any/c
  expr? : any/c = #f
  escapes? : any/c = #t
  defn? : any/c = #f
procedure
(to-element/no-color  v                         
                     [#:expr? expr?             
                      #:escapes? escapes?]) -> element?
  v : any/c
  expr? : any/c = #f
  escapes? : any/c = #t
struct
(struct var-id (sym)
    #:extra-constructor-name make-var-id)
  sym : (or/c symbol? identifier?)
struct
(struct shaped-parens (val shape)
    #:extra-constructor-name make-shaped-parens)
  val : any/c
  shape : char?
struct
(struct long-boolean (val)
    #:extra-constructor-name make-long-boolean)
  val : boolean?
struct
(struct just-context (val context)
    #:extra-constructor-name make-just-context)
  val : any/c
  context : syntax?
struct
(struct literal-syntax (stx)
    #:extra-constructor-name make-literal-syntax)
  stx : any/c
procedure
(element-id-transformer? v) -> boolean?
  v : any/c
procedure
(make-element-id-transformer proc) -> element-id-transformer?
  proc : (syntax? . -> . syntax?)
procedure
(variable-id? v) -> boolean?
  v : any/c
procedure
(make-variable-id sym) -> variable-id?
  sym : (or/c symbol? identifier?)
value
output-color : style?
value
input-color : style?
value
input-background-color : style?
value
no-color : style?
value
reader-color : style?
value
result-color : style?
value
keyword-color : style?
value
comment-color : style?
value
paren-color : style?
value
meta-color : style?
value
value-color : style?
value
symbol-color : style?
value
variable-color : style?
value
opt-color : style?
value
error-color : style?
value
syntax-link-color : style?
value
value-link-color : style?
value
module-color : style?
value
module-link-color : style?
value
block-color : style?
value
highlighted-color : style?
syntax
(interaction maybe-eval maybe-escape datum ...)
 
  maybe-eval = 
             | #:eval eval-expr
                
maybe-escape = 
             | #:escape escape-id
syntax
(interaction0 maybe-eval maybe-escape datum ...)
syntax
(interaction/no-prompt maybe-eval maybe-escape datum)
syntax
(interaction-eval maybe-eval maybe-escape datum)
syntax
(interaction-eval-show maybe-eval maybe-escape datum)
syntax
(racketblock+eval maybe-eval maybe-escape datum ...)
syntax
(racketblock0+eval maybe-eval maybe-escape datum ...)
syntax
(racketmod+eval maybe-eval maybe-escape name datum ...)
syntax
(def+int maybe-eval maybe-escape defn-datum expr-datum ...)
syntax
(defs+int maybe-eval maybe-escape (defn-datum ...) expr-datum ...)
syntax
(examples maybe-eval maybe-escape datum ...)
syntax
(defexamples maybe-eval maybe-escape datum ...)
procedure
(make-base-eval [#:pretty-print? pretty-print? 
                 #:lang lang]                  
                 input-program ...)            
 -> (any/c . -> . any)
  pretty-print? : any/c = #t
  lang : (or/c module-path?              = '(begin)
               (list/c 'special symbol?)
               (cons/c 'begin list?))
  input-program : any/c
procedure
(make-base-eval-factory  mod-paths                     
                        [#:pretty-print? pretty-print? 
                         #:lang lang])                 
 -> (-> (any/c . -> . any))
  mod-paths : (listof module-path?)
  pretty-print? : any/c = #t
  lang : (or/c module-path?              = '(begin)
               (list/c 'special symbol?)
               (cons/c 'begin list?))
procedure
(make-eval-factory  mod-paths                     
                   [#:pretty-print? pretty-print? 
                    #:lang lang])                 
 -> (-> (any/c . -> . any))
  mod-paths : (listof module-path?)
  pretty-print? : any/c = #t
  lang : (or/c module-path?              = '(begin)
               (list/c 'special symbol?)
               (cons/c 'begin list?))
procedure
(close-eval eval) -> (one-of/c "")
  eval : (any/c . -> . any)
parameter
(scribble-eval-handler)
 -> ((any/c . -> . any) any/c boolean? . -> . any)
(scribble-eval-handler handler) -> void?
  handler : ((any/c . -> . any) any/c boolean? . -> . any)
parameter
(scribble-exn->string) -> (-> (or/c exn? any/c) string?)
(scribble-exn->string handler) -> void?
  handler : (-> (or/c exn? any/c) string?)
syntax
(with-eval-preserve-source-locations expr ...)
syntax
(for-doc require-spec ...)
syntax
(proc-doc/names id contract arg-specs (desc-expr ...))
 
arg-specs = ((arg-id ...) ((arg-id default-expr) ...))
          | (arg-id ...)
             
 contract = (-> arg ... result)
          | (->* (mandatory ...) (optional ...) result)
          | (case-> (-> arg ... result) ...)
             
mandatory = contract-expr
          | keyword contract-expr
             
 optional = contract-expr
          | keyword contract-expr
syntax
(proc-doc id contract maybe-defs (desc-expr ...))
 
  contract = (-> result)
           | (->i (arg ...) (opt ...) maybe-pre [id res])
           | (->i (arg ...) (opt ...) maybe-pre (values [id res] ...))
           | (->i (arg ...) (opt ...) #:rest rest [id result-expr])
           | (->d (arg ...) () maybe-pre (values [id result] ...))
           | (->d (arg ...) () maybe-pre [id result])
           | (->d (arg ...) () #:rest id rest [id result])
              
 maybe-pre = 
           | #:pre (pre-id ...) condition
              
maybe-defs = 
           | (default-expr default-expr ...)
syntax
(thing-doc id contract-expr (desc-expr ...))
syntax
(parameter-doc id (parameter/c contract-expr) arg-id (desc-expr ...))
syntax
(struct*-doc struct-name
             ([field-name contract-expr-datum] ...)
             maybe-omit-constructor
             maybe-mutable maybe-non-opaque maybe-constructor
             (desc-expr ...))
 
maybe-omit-constructor = 
                       | #:omit-constructor
syntax
(struct-doc struct-name
            ([field-name contract-expr-datum] ...)
            maybe-omit-constructor
            maybe-mutable maybe-non-opaque maybe-constructor
            (desc-expr ...))
syntax
(form-doc options form-datum
  maybe-grammar maybe-contracts
  (desc-expr ...))
 
        options = maybe-kind maybe-link maybe-id maybe-literals
                   
     maybe-kind = 
                | #:kind kind-string-expr
                   
     maybe-link = 
                | #:link-target? link-target?-expr
                   
       maybe-id = 
                | #:id id
                | #:id [id id-expr]
                   
 maybe-literals = 
                | #:literals (literal-id ...)
                   
  maybe-grammar = 
                | #:grammar ([nonterm-id clause-datum ...+] ...)
                   
maybe-contracts = 
                | #:contracts ([subform-datum contract-expr-datum]
                               ...)
syntax
(begin-for-doc form ...)
syntax
(generate-delayed-documents)
syntax
(require/doc require-spec ...)
syntax
(provide/doc spec ...)
syntax
(include-extracted module-path)
syntax
(provide-extracted module-path)
syntax
(include-previously-extracted module-path regexp)
procedure
(BNF prod ...) -> table?
  prod : (cons element? (listof (or/c block? element?)))
procedure
(nonterm pre-content ...) -> element?
  pre-content : any/c
procedure
(BNF-seq elem ...) -> element?
  elem : element?
procedure
(BNF-seq-lines elems ...) -> block?
  elems : (listof element?)
procedure
(BNF-group pre-content ...) -> element?
  pre-content : any/c
procedure
(optional pre-content ...) -> element?
  pre-content : any/c
procedure
(kleenestar pre-content ...) -> element?
  pre-content : any/c
procedure
(kleeneplus pre-content ...) -> element?
  pre-content : any/c
procedure
(kleenerange n m pre-content ...) -> element?
  n : any/c
  m : any/c
  pre-content : any/c
procedure
(BNF-alt elem ...) -> element?
  elem : element?
value
BNF-etc : string?
procedure
(make-part tag-prefix        
           tags              
           title-content     
           style             
           to-collect        
           blocks            
           parts)        -> part?
  tag-prefix : (or/c false/c string?)
  tags : (listof tag?)
  title-content : (or/c false/c list?)
  style : any/c
  to-collect : list?
  blocks : (listof block?)
  parts : (listof part?)
procedure
(part-flow p) -> (listof block?)
  p : part?
procedure
(part-title-content p) -> list?
  p : part?
procedure
(make-versioned-part tag-prefix        
                     tags              
                     title-content     
                     style             
                     to-collect        
                     blocks            
                     parts             
                     version)      -> part?
  tag-prefix : (or/c false/c string?)
  tags : (listof tag?)
  title-content : (or/c false/c list?)
  style : any/c
  to-collect : list?
  blocks : (listof block?)
  parts : (listof part?)
  version : string?
procedure
(versioned-part? v) -> boolean?
  v : any/c
procedure
(make-unnumbered-part tag-prefix        
                      tags              
                      title-content     
                      style             
                      to-collect        
                      blocks            
                      parts)        -> part?
  tag-prefix : (or/c false/c string?)
  tags : (listof tag?)
  title-content : (or/c false/c list?)
  style : any/c
  to-collect : list?
  blocks : (listof block?)
  parts : (listof part?)
procedure
(unnumbered-part? v) -> boolean?
  v : any/c
procedure
(make-paragraph content) -> paragraph?
  content : list?
procedure
(paragraph-content p) -> list?
  p : paragraph?
procedure
(make-styled-paragraph content style) -> paragraph?
  content : list?
  style : any/c
procedure
(styled-paragraph? v) -> boolean?
  v : any/c
procedure
(styled-paragraph-style p) -> style?
  p : paragraph?
procedure
(make-omitable-paragraph content) -> paragraph?
  content : list?
procedure
(omitable-paragraph? v) -> boolean?
  v : any/c
procedure
(make-table style blocksss) -> table?
  style : any/c
  blocksss : (listof (listof (or/c (listof block?) (one-of/c 'cont))))
procedure
(table-flowss table)
 -> (listof (listof (or/c (listof block?) (one-of/c 'cont))))
  table : table?
procedure
(make-itemization blockss) -> itemization?
  blockss : (listof (listof block?))
procedure
(make-styled-itemization style blockss) -> itemization?
  style : any/c
  blockss : (listof (listof block?))
procedure
(styled-itemization? v) -> boolean?
  v : any/c
procedure
(styled-itemization-style i) -> style?
  i : itemization?
procedure
(make-blockquote style blocks) -> nested-flow?
  style : any/c
  blocks : (listof block?)
procedure
(make-auxiliary-table style blocksss) -> table?
  style : any/c
  blocksss : (listof (listof (or/c (listof block?) (one-of/c 'cont))))
procedure
(auxiliary-table? v) -> boolean?
  v : any/c
procedure
(make-compound-paragraph style blocks) -> compound-paragraph?
  style : any/c
  blocks : (listof block?)
procedure
(make-element style content) -> element?
  style : any/c
  content : list?
procedure
(make-toc-element style content toc-content) -> toc-element?
  style : any/c
  content : list?
  toc-content : list?
procedure
(make-target-element style content tag) -> target-element?
  style : any/c
  content : list?
  tag : tag?
procedure
(make-toc-target-element style content tag) -> toc-target-element?
  style : any/c
  content : list?
  tag : tag?
procedure
(make-toc-target2-element style            
                          content          
                          tag              
                          toc-content) -> toc-target2-element?
  style : any/c
  content : list?
  tag : tag?
  toc-content : content?
procedure
(make-page-target-element style content tag)
 -> page-target-element?
  style : any/c
  content : list?
  tag : tag?
procedure
(make-redirect-target-element style       
                              content     
                              tag         
                              alt-path    
                              alt-anchor) 
 -> redirect-target-element?
  style : any/c
  content : list?
  tag : tag?
  alt-path : path-string?
  alt-anchor : string?
procedure
(make-link-element style content tag) -> link-element?
  style : any/c
  content : list?
  tag : tag?
procedure
(make-index-element style         
                    content       
                    tag           
                    plain-seq     
                    entry-seq     
                    desc)     -> index-element?
  style : any/c
  content : list?
  tag : tag?
  plain-seq : (and/c pair? (listof string?))
  entry-seq : list?
  desc : any/c
procedure
(element? v) -> boolean?
  v : any/c
procedure
(element-content e) -> list?
  e : element?
procedure
(element-style e) -> element-style?
  e : element?
procedure
(make-aux-element style content) -> element?
  style : any/c
  content : list?
procedure
(make-hover-element style content text) -> element?
  style : any/c
  content : list?
  text : string?
procedure
(make-script-element style       
                     content     
                     type        
                     script) -> element?
  style : any/c
  content : list?
  type : string?
  script : (or/c path-string? (listof string?))
struct
(struct with-attributes (style assoc)
    #:extra-constructor-name make-with-attributes)
  style : any/c
  assoc : (listof (cons/c symbol? string?))
struct
(struct target-url (addr style)
    #:extra-constructor-name make-target-url)
  addr : path-string?
  style : any/c
struct
(struct image-file (path scale)
    #:extra-constructor-name make-image-file)
  path : (or/c path-string?
               (cons/c 'collects (listof bytes?)))
  scale : real?
procedure
(element->string element) -> string?
  element : content?
(element->string element renderer p info) -> string?
  element : content?
  renderer : any/c
  p : part?
  info : resolve-info?
procedure
(span-class style-name pre-content ...) -> element?
  style-name : string?
  pre-content : any/c
procedure
(itemize itm ... [#:style style]) -> itemization?
  itm : (or/c whitespace? an-item?)
  style : (or/c style? string? symbol? #f) = #f
syntax
(chunk id form ...)
syntax
(CHUNK id form ...)
syntax
(lp-include filename)
procedure
(read [in]) -> any
  in : input-port? = (current-input-port)
procedure
(read-syntax [source-name in]) -> (or/c syntax? eof-object?)
  source-name : any/c = (object-name in)
  in : input-port? = (current-input-port)
procedure
(read-inside [in]) -> any
  in : input-port? = (current-input-port)
procedure
(read-syntax-inside [source-name                   
                     in                            
                     #:command-char command-char]) 
 -> (or/c syntax? eof-object?)
  source-name : any/c = (object-name in)
  in : input-port? = (current-input-port)
  command-char : char? = #\@
procedure
(make-at-readtable [#:readtable readtable                      
                    #:command-char command-char                
                    #:command-readtable command-readtable      
                    #:datum-readtable datum-readtable          
                    #:syntax-post-processor syntax-post-proc]) 
 -> readtable?
  readtable : readtable? = (current-readtable)
  command-char : char? = #\@
  command-readtable : (or/c readtable? 'dynamic) = readtable
  datum-readtable : (or/c readtable?                     = #t
                          boolean?
                          (readtable? . -> . readtable?)
                          'dynamic)
  syntax-post-proc : (syntax? . -> . syntax?) = values
procedure
(make-at-reader #:syntax? syntax?          
                #:inside? inside? ...) -> procedure?
  syntax? : #t
  inside? : #f
procedure
(use-at-readtable ...) -> void?
struct
(struct part (tag-prefix
              tags
              title-content
              style
              to-collect
              blocks
              parts)
    #:extra-constructor-name make-part)
  tag-prefix : (or/c #f string?)
  tags : (listof tag?)
  title-content : (or/c #f list?)
  style : style?
  to-collect : list?
  blocks : (listof block?)
  parts : (listof part?)
struct
(struct paragraph (style content)
    #:extra-constructor-name make-paragraph)
  style : style?
  content : content?
struct
(struct table (style blockss)
    #:extra-constructor-name make-table)
  style : style?
  blockss : (listof (listof (or/c block? 'cont)))
struct
(struct itemization (style blockss)
    #:extra-constructor-name make-itemization)
  style : style?
  blockss : (listof (listof block?))
struct
(struct nested-flow (style blocks)
    #:extra-constructor-name make-nested-flow)
  style : any/c
  blocks : (listof block?)
struct
(struct compound-paragraph (style blocks)
    #:extra-constructor-name make-compound-paragraph)
  style : style?
  blocks : (listof block?)
struct
(struct traverse-block (traverse)
    #:extra-constructor-name make-traverse-block)
  traverse : block-traverse-procedure/c
struct
(struct delayed-block (resolve)
    #:extra-constructor-name make-delayed-block)
  resolve : (any/c part? resolve-info? . -> . block?)
struct
(struct element (style content)
    #:extra-constructor-name make-element)
  style : element-style?
  content : content?
struct
(struct image-element element (path suffixes scale)
    #:extra-constructor-name make-image-element)
  path : (or/c path-string?
               (cons/c 'collects (listof bytes?)))
  suffixes : (listof #rx"^[.]")
  scale : real?
struct
(struct target-element element (tag)
    #:extra-constructor-name make-target-element)
  tag : tag?
struct
(struct toc-target-element target-element ()
    #:extra-constructor-name make-toc-target-element)
struct
(struct toc-target2-element toc-target-element (toc-content)
    #:extra-constructor-name make-toc-target2-element)
  toc-content : content?
struct
(struct page-target-element target-element ()
    #:extra-constructor-name make-page-target-element)
struct
(struct redirect-target-element target-element (alt-path
                                                alt-anchor)
    #:extra-constructor-name make-redirect-target-element)
  alt-path : path-string?
  alt-anchor : string?
struct
(struct toc-element element (toc-content)
    #:extra-constructor-name make-toc-element)
  toc-content : content?
struct
(struct link-element element (tag)
    #:extra-constructor-name make-link-element)
  tag : tag?
struct
(struct index-element element (tag plain-seq entry-seq desc)
    #:extra-constructor-name make-index-element)
  tag : tag?
  plain-seq : (and/c pair? (listof string?))
  entry-seq : (listof content?)
  desc : any/c
struct
(struct multiarg-element (style contents)
    #:extra-constructor-name make-multiarg-element)
  style : element-style?
  contents : (listof content?)
struct
(struct traverse-element (traverse)
    #:extra-constructor-name make-traverse-element)
  traverse : element-traverse-procedure/c
struct
(struct delayed-element (resolve sizer plain)
    #:extra-constructor-name make-delayed-element)
  resolve : (any/c part? resolve-info? . -> . content?)
  sizer : (-> any/c)
  plain : (-> any/c)
struct
(struct part-relative-element (resolve sizer plain)
    #:extra-constructor-name make-part-relative-element)
  resolve : (collect-info? . -> . content?)
  sizer : (-> any/c)
  plain : (-> any/c)
struct
(struct collect-element element (collect)
    #:extra-constructor-name make-collect-element)
  collect : (collect-info . -> . any)
struct
(struct render-element element (render)
    #:extra-constructor-name make-render-element)
  render : (any/c part? resolve-info? . -> . any)
struct
(struct collected-info (number parent info)
    #:extra-constructor-name make-collected-info)
  number : (listof (or/c #f exact-nonnegative-integer? string?))
  parent : (or/c #f part?)
  info : any/c
struct
(struct target-url (addr)
    #:extra-constructor-name make-target-url)
  addr : path-string?
struct
(struct document-version (text)
    #:extra-constructor-name make-document-version)
  text : (or/c string? #f)
struct
(struct document-date (text)
    #:extra-constructor-name make-document-date)
  text : (or/c string? #f)
struct
(struct color-property (color)
    #:extra-constructor-name make-color-property)
  color : (or/c string? (list/c byte? byte? byte?))
struct
(struct background-color-property (color)
    #:extra-constructor-name make-background-color-property)
  color : (or/c string? (list/c byte? byte? byte?))
struct
(struct table-cells (styless)
    #:extra-constructor-name make-table-cells)
  styless : (listof (listof style?))
struct
(struct table-columns (styles)
    #:extra-constructor-name make-table-columns)
  styles : (listof style?)
struct
(struct box-mode (top-name center-name bottom-name)
    #:extra-constructor-name make-box-mode)
  top-name : string?
  center-name : string?
  bottom-name : string?
procedure
(box-mode* name) -> box-mode?
  name : string?
procedure
(block? v) -> boolean?
  v : any/c
procedure
(content? v) -> boolean?
  v : any/c
struct
(struct style (name properties)
    #:extra-constructor-name make-style)
  name : (or/c string? symbol? #f)
  properties : list?
value
plain : style?
procedure
(element-style? v) -> boolean?
  v : any/c
procedure
(tag? v) -> boolean?
  v : any/c
struct
(struct generated-tag ()
    #:extra-constructor-name make-generated-tag)
procedure
(content->string content) -> string?
  content : content?
(content->string content renderer p info) -> string?
  content : content?
  renderer : any/c
  p : part?
  info : resolve-info?
procedure
(content-width c) -> exact-nonnegative-integer?
  c : content?
procedure
(block-width e) -> exact-nonnegative-integer?
  e : block?
struct
(struct collect-info (fp
                      ht
                      ext-ht
                      ext-demand
                      parts
                      tags
                      gen-prefix
                      relatives
                      parents)
    #:extra-constructor-name make-collect-info)
  fp : any/c
  ht : any/c
  ext-ht : any/c
  ext-demand : (tag? collect-info? . -> . any/c)
  parts : any/c
  tags : any/c
  gen-prefix : any/c
  relatives : any/c
  parents : (listof part?)
struct
(struct resolve-info (ci delays undef searches)
    #:extra-constructor-name make-resolve-info)
  ci : any/c
  delays : any/c
  undef : any/c
  searches : any/c
procedure
(info-key? v) -> boolean?
  v : any/c
procedure
(collect-put! ci key val) -> void?
  ci : collect-info?
  key : info-key?
  val : any/c
procedure
(resolve-get p ri key) -> any/c
  p : (or/c part? #f)
  ri : resolve-info?
  key : info-key?
procedure
(resolve-get/ext? p ri key) -> any/c boolean?
  p : (or/c part? #f)
  ri : resolve-info?
  key : info-key?
procedure
(resolve-get/ext-id p ri key) -> any/c (or/c boolean? string?)
  p : (or/c part? #f)
  ri : resolve-info?
  key : info-key?
procedure
(resolve-search dep-key p ri key) -> void?
  dep-key : any/c
  p : (or/c part? #f)
  ri : resolve-info?
  key : info-key?
procedure
(resolve-get/tentative p ri key) -> any/c
  p : (or/c part? #f)
  ri : resolve-info?
  key : info-key?
procedure
(resolve-get-keys p ri pred) -> list?
  p : (or/c part? #f)
  ri : resolve-info?
  pred : (info-key? . -> . any/c)
procedure
(part-collected-info p ri) -> collected-info?
  p : part?
  ri : resolve-info?
procedure
(tag-key t ri) -> tag?
  t : tag?
  ri : resolve-info?
procedure
(traverse-block-block b i) -> block?
  b : traverse-block?
  i : (or/c resolve-info? collect-info?)
procedure
(traverse-element-content e i) -> content?
  e : traverse-element?
  i : (or/c resolve-info? collect-info?)
value
block-traverse-procedure/c : contract?
value
element-traverse-procedure/c : contract?
struct
(struct attributes (assoc)
    #:extra-constructor-name make-attributes)
  assoc : (listof (cons/c symbol? string?))
struct
(struct alt-tag (name)
    #:extra-constructor-name make-alt-tag)
  name : (and/c string? #rx"^[a-zA-Z0-9]+$")
struct
(struct column-attributes (assoc)
    #:extra-constructor-name make-column-attributes)
  assoc : (listof (cons/c symbol? string?))
struct
(struct url-anchor (name)
    #:extra-constructor-name make-url-anchor)
  name : string?
struct
(struct hover-property (text)
    #:extra-constructor-name make-hover-property)
  text : string?
struct
(struct script-property (type script)
    #:extra-constructor-name make-script-property)
  type : string?
  script : (or/c path-string? (listof string?))
struct
(struct css-addition (path)
    #:extra-constructor-name make-css-addition)
  path : (or/c path-string?
               (cons/c 'collects (listof bytes?))
               url?
               bytes?)
struct
(struct css-style-addition (path)
    #:extra-constructor-name make-css-style-addition)
  path : (or/c path-string?
               (cons/c 'collects (listof bytes?))
               url?
               bytes?)
struct
(struct js-addition (path)
    #:extra-constructor-name make-js-addition)
  path : (or/c path-string?
               (cons/c 'collects (listof bytes?))
               url?
               bytes?)
struct
(struct js-style-addition (path)
    #:extra-constructor-name make-js-style-addition)
  path : (or/c path-string?
               (cons/c 'collects (listof bytes?))
               url?
               bytes?)
struct
(struct body-id (value)
    #:extra-constructor-name make-body-id)
  value : string?
struct
(struct document-source (module-path)
    #:extra-constructor-name make-document-source)
  module-path : module-path?
struct
(struct html-defaults (prefix style extra-files)
    #:extra-constructor-name make-html-defaults)
  prefix : (or/c bytes? path-string?
                 (cons/c 'collects (listof bytes?)))
  style : (or/c bytes? path-string?
                (cons/c 'collects (listof bytes?)))
  extra-files : (listof (or/c path-string?
                              (cons/c 'collects (listof bytes?))))
struct
(struct head-extra (xexpr)
    #:extra-constructor-name make-head-extra)
  xexpr : xexpr/c
struct
(struct render-convertible-as (types)
    #:extra-constructor-name make-render-convertible-as)
  types : (listof (or/c 'png-bytes 'svg-bytes))
struct
(struct part-link-redirect (url)
    #:extra-constructor-name make-part-link-redirect)
  url : url?
struct
(struct link-resource (path)
    #:extra-constructor-name make-link-resource)
  path : path-string?
struct
(struct install-resource (path)
    #:extra-constructor-name make-install-resource)
  path : path-string?
struct
(struct tex-addition (path)
    #:extra-constructor-name make-tex-addition)
  path : (or/c path-string?
               (cons/c 'collects (listof bytes?))
               bytes?)
struct
(struct latex-defaults (prefix style extra-files)
    #:extra-constructor-name make-latex-defaults)
  prefix : (or/c bytes? path-string?
                 (cons/c 'collects (listof bytes?)))
  style : (or/c bytes? path-string?
                (cons/c 'collects (listof bytes?)))
  extra-files : (listof (or/c path-string?
                              (cons/c 'collects (listof bytes?))))
struct
(struct command-extras (arguments)
    #:extra-constructor-name make-command-extras)
  arguments : (listof string?)
procedure
(render  docs                                        
         names                                       
        [#:render-mixin render-mixin                 
         #:dest-dir dest-dir                         
         #:helper-file-prefix helper-file-prefix     
         #:prefix-file prefix-file                   
         #:style-file style-file                     
         #:style-extra-files style-extra-files       
         #:extra-files extra-files                   
         #:image-preferences image-preferences       
         #:xrefs xrefs                               
         #:info-in-files info-in-files               
         #:info-out-file info-out-file               
         #:redirect redirect                         
         #:redirect-main redirect-main               
         #:directory-depth directory-depth           
         #:quiet? quiet?                             
         #:warn-undefined? warn-undefined?])     -> void?
  docs : (listof part?)
  names : (listof path-string?)
  render-mixin : (class? . -> . class?) = render-mixin
  dest-dir : (or/c #f path-string?) = #f
  helper-file-prefix : (or/c #f string?) = #f
  prefix-file : (or/c #f path-string?) = #f
  style-file : (or/c #f path-string?) = #f
  style-extra-files : (listof path-string?) = #f
  extra-files : (listof path-string?) = #f
  image-preferences : (listof (or/c 'ps 'pdf 'png 'svg 'gif))
                    = null
  xrefs : (listof xref?) = null
  info-in-files : (listof path-string?) = null
  info-out-file : (or/c #f path-string?) = #f
  redirect : (or/c #f string?) = #f
  redirect-main : (or/c #f string?) = #f
  directory-depth : exact-nonnegative-integer? = 0
  quiet? : any/c = #t
  warn-undefined? : any/c = (not quiet?)
interface
render<%> : interface?
method
(send a-render traverse srcs dests) -> (and/c hash? immutable?)
  srcs : (listof part?)
  dests : (listof path-string?)
method
(send a-render collect srcs dests fp [demand]) -> collect-info?
  srcs : (listof part?)
  dests : (listof path-string?)
  fp : (and/c hash? immutable?)
  demand : (tag? collect-info? . -> . any/c)
         = (lambda (tag ci) #f)
method
(send a-render resolve srcs dests ci) -> resolve-info?
  srcs : (listof part?)
  dests : (listof path-string?)
  ci : collect-info?
method
(send a-render render srcs dests ri) -> void?
  srcs : (listof part?)
  dests : (listof path-string?)
  ri : resolve-info?
method
(send a-render serialize-info ri) -> any/c
  ri : resolve-info?
method
(send a-render serialize-infos ri count doc) -> list?
  ri : resolve-info?
  count : exact-positive-integer?
  doc : part?
method
(send a-render deserialize-info  v                      
                                 ci                     
                                [#:root root-path]) -> void?
  v : any/c
  ci : collect-info?
  root-path : (or/c path-string? false/c) = #f
method
(send a-render get-defined ci) -> (listof tag?)
  ci : collect-info?
method
(send a-render get-defineds ci count doc)
 -> (listof (listof tag?))
  ci : collect-info?
  count : exact-positive-integer?
  doc : part?
method
(send a-render get-external ri) -> (listof tag?)
  ri : resolve-info?
method
(send a-render get-undefined ri) -> (listof tag?)
  ri : resolve-info?
class
render% : class?
  superclass: object%
  extends: render<%>
constructor
(new render%                                                    
              [dest-dir dest-dir]                               
             [[refer-to-existing-files refer-to-existing-files] 
              [root-path root-path]                             
              [prefix-file prefix-file]                         
              [style-file style-file]                           
              [style-extra-files style-extra-files]             
              [extra-files extra-files]                         
              [image-preferences image-preferences]])           
 -> (is-a?/c render%)
  dest-dir : path-string?
  refer-to-existing-files : any/c = #f
  root-path : (or/c path-string? #f) = #f
  prefix-file : (or/c path-string? #f) = #f
  style-file : (or/c path-string? #f) = #f
  style-extra-files : (listof path-string?) = null
  extra-files : (listof path-string?) = null
  image-preferences : (listof (or/c 'ps 'pdf 'png 'svg 'gif))
                    = null
mixin
render-mixin : (class? . -> . class?)
  argument extends/implements: render<%>
mixin
render-mixin : (class? . -> . class?)
  argument extends/implements: render<%>
mixin
render-mixin : (class? . -> . class?)
  argument extends/implements: render<%>
method
(send a-render set-external-tag-path url) -> void?
  url : string?
method
(send a-render set-external-root-url url) -> void?
  url : string?
mixin
render-multi-mixin : (class? . -> . class?)
  argument extends/implements: render<%>
method
(send a-render-multi set-directory-depth depth) -> void?
  depth : exact-nonnegative-integer?
mixin
render-mixin : (class? . -> . class?)
  argument extends/implements: render<%>
mixin
render-mixin : (class? . -> . class?)
  argument extends/implements: render<%>
mixin
override-render-mixin-multi : (class? . -> . class?)
  argument extends/implements: render<%>
method
(send an-override-render-mixin-multi render srcs      
                                            dests     
                                            ri)   -> void?
  srcs : (listof part?)
  dests : (listof path?)
  ri : render-info?
mixin
override-render-mixin-single : (class? . -> . class?)
  argument extends/implements: render<%>
method
(send an-override-render-mixin-single render srcs      
                                             dests     
                                             ri)   -> void?
  srcs : (listof part?)
  dests : (listof path?)
  ri : render-info?
procedure
(pre-content? v) -> boolean?
  v : any/c
procedure
(pre-flow? v) -> boolean?
  v : any/c
procedure
(pre-part? v) -> boolean?
  v : any/c
procedure
(decode lst) -> part?
  lst : (listof pre-part?)
procedure
(decode-part lst tags title depth) -> part?
  lst : (listof pre-part?)
  tags : (listof string?)
  title : (or/c #f list?)
  depth : exact-nonnegative-integer?
procedure
(decode-flow lst) -> (listof block?)
  lst : (listof pre-flow?)
procedure
(decode-compound-paragraph lst) -> block?
  lst : (listof pre-flow?)
procedure
(decode-paragraph lst) -> paragraph?
  lst : (listof pre-content?)
procedure
(decode-content lst) -> list?
  lst : (listof pre-content?)
procedure
(decode-elements lst) -> list?
  lst : (listof pre-content?)
procedure
(decode-string s) -> (listof content?)
  s : string?
procedure
(whitespace? v) -> boolean?
  v : any/c
struct
(struct title-decl (tag-prefix tags version style content)
    #:extra-constructor-name make-title-decl)
  tag-prefix : (or/c #f string?)
  tags : (listof string?)
  version : (or/c string? #f)
  style : style?
  content : content?
struct
(struct part-start (depth tag-prefix tags style title)
    #:extra-constructor-name make-part-start)
  depth : integer?
  tag-prefix : (or/c #f string?)
  tags : (listof string?)
  style : style?
  title : content?
struct
(struct part-index-decl (plain-seq entry-seq)
    #:extra-constructor-name make-part-index-decl)
  plain-seq : (listof string?)
  entry-seq : list?
struct
(struct part-collect-decl (element)
    #:extra-constructor-name make-part-collect-decl)
  element : (or/c element? part-relative-element?)
struct
(struct part-tag-decl (tag)
    #:extra-constructor-name make-part-tag-decl)
  tag : tag?
struct
(struct splice (run)
    #:extra-constructor-name make-splice)
  run : list?
procedure
(spliceof ctc) -> flat-contract?
  ctc : flat-contract?
procedure
(clean-up-index-string str) -> string?
  str : string?
procedure
(xref? v) -> boolean?
  v : any/c
procedure
(load-xref  sources                           
           [#:demand-source demand-source     
            #:render% using-render%           
            #:root root-path                  
            #:doc-id doc-id-str])         -> xref?
  sources : (listof (-> (or/c any/c (-> list?))))
  demand-source : (tag? -> (or/c (-> any/c) #f))
                = (lambda (tag) #f)
  using-render% : (implementation?/c render<%>)
                = (render-mixin render%)
  root-path : (or/c path-string? false/c) = #f
  doc-id-str : (or/c path-string? false/c) = #f
procedure
(xref-binding->definition-tag xref        
                              binding     
                              mode)   -> (or/c tag? false/c)
  xref : xref?
  binding : (or/c identifier?
                  (list/c (or/c module-path?
                                module-path-index?)
                          symbol?)
                  (listof module-path-index?
                          symbol?
                          module-path-index?
                          symbol?
                          (one-of/c 0 1)
                          (or/c exact-integer? false/c)
                          (or/c exact-integer? false/c)))
  mode : (or/c exact-integer? false/c)
procedure
(xref-tag->path+anchor  xref                         
                        tag                          
                       [#:external-root-url root-url 
                        #:render% using-render%])    
 -> (or/c false/c path?)
    (or/c false/c string?)
  xref : xref?
  tag : tag?
  root-url : (or/c string? #f) = #f
  using-render% : (implementation?/c render<%>)
                = (render-mixin render%)
procedure
(xref-tag->index-entry xref tag) -> (or/c false/c entry?)
  xref : xref?
  tag : tag?
procedure
(xref-render  xref                                       
              doc                                        
              dest                                       
             [#:render% using-render%                    
              #:refer-to-existing-files? use-existing?]) 
 -> (or/c void? any/c)
  xref : xref?
  doc : part?
  dest : (or/c path-string? false/c)
  using-render% : (implemenation?/c render<%>)
                = (render-mixin render%)
  use-existing? : any/c = (not dest)
procedure
(xref-transfer-info renderer ci xref) -> void?
  renderer : (is-a?/c render<%>)
  ci : collect-info?
  xref : xref?
procedure
(xref-index xref) -> (listof entry?)
  xref : xref?
struct
(struct entry (words content tag desc)
    #:extra-constructor-name make-entry)
  words : (and/c (listof string?) cons?)
  content : list?
  tag : tag?
  desc : any/c
procedure
(data+root? v) -> boolean?
  v : any/c
procedure
(make-data+root data root) -> data+root?
  data : any/c
  root : (or/c #f path-string?)
procedure
(data+root+doc-id? v) -> boolean?
  v : any/c
procedure
(make-data+root+doc-id data root doc-id) -> data+root+doc-id?
  data : any/c
  root : (or/c #f path-string?)
  doc-id : string?
procedure
(make-section-tag  name                              
                  [#:doc doc-mod-path                
                   #:tag-prefixes tag-prefixes]) -> tag?
  name : string?
  doc-mod-path : (or/c module-path? #f) = #f
  tag-prefixes : (or/c #f (listof string?)) = #f
procedure
(make-module-language-tag lang) -> tag?
  lang : symbol?
procedure
(taglet? v) -> boolean?
  v : any/c
procedure
(doc-prefix mod-path taglet) -> taglet?
  mod-path : (or/c #f module-path?)
  taglet : taglet?
(doc-prefix mod-path extra-prefixes taglet) -> taglet?
  mod-path : (or/c #f module-path?)
  extra-prefixes : (or/c #f (listof taglet?))
  taglet : taglet?
procedure
(module-path-prefix->string mod-path) -> string?
  mod-path : module-path?
procedure
(module-path-index->taglet mpi) -> taglet?
  mpi : module-path-index?
procedure
(intern-taglet v) -> any/c
  v : any/c
procedure
(definition-tag->class/interface-tag definition-tag)
 -> class/interface-tag?
  definition-tag : definition-tag?
procedure
(class/interface-tag->constructor-tag class/interface-tag)
 -> constructor-tag?
  class/interface-tag : class/interface-tag?
procedure
(get-class/interface-and-method method-tag) -> symbol? symbol?
  method-tag : method-tag?
procedure
(definition-tag? v) -> boolean?
  v : any/c
procedure
(class/interface-tag? v) -> boolean?
  v : any/c
procedure
(method-tag? v) -> boolean?
  v : any/c
procedure
(constructor-tag? v) -> boolean?
  v : any/c
procedure
(fetch-blueboxes-strs  tag                                 
                      [#:blueboxes-cache blueboxes-cache]) 
 -> (or/c #f (non-empty-listof string?))
  tag : tag?
  blueboxes-cache : blueboxes-cache? = (make-blueboxes-cache #t)
procedure
(fetch-blueboxes-method-tags                                      
                              method-name                         
                             [#:blueboxes-cache blueboxes-cache]) 
 -> (listof method-tag?)
  method-name : symbol?
  blueboxes-cache : blueboxes-cache? = (make-blueboxes-cache #t)
procedure
(make-blueboxes-cache  populate?                         
                      [#:blueboxes-dirs blueboxes-dirs]) 
 -> blueboxes-cache?
  populate? : boolean?
  blueboxes-dirs : (listof path?) = (get-doc-search-dirs)
procedure
(blueboxes-cache? v) -> boolean?
  v : any/c
value
unicode-encoding-packages : string?
