typedef char CHAR;
