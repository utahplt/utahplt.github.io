#lang s-exp syntax/module-reader
deinprogramm/DMdA-assignments
