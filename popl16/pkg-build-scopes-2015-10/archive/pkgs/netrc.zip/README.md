netrc
=====
README text here.
