(display "hello world\n")
