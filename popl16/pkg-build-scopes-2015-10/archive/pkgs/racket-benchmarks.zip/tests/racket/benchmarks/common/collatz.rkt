(module collatz "wrap.rkt")
