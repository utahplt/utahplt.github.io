#lang racket/base

(provide not-sequence?
         sequence-map*
         endless-values in-common-difference
         in-evens in-odds
         in-squares in-cubes
         in-triangle in-double-triangle
         every-other interleave
         values->pair
         )

(define-syntax-rule (values->pair value-expression)
  (call-with-values (λ() value-expression) cons))

(define (not-sequence? a)
  (not (sequence? a)))

(define (endless-values v)
  (define (id x) x)
  (make-do-sequence
   (λ() (values id
                id
                v
                #f #f #f))))

(define (even/odd check? check-name from)
  (define (->next t)
    (+ t 2))
  (define (->current t)
    t)
  (define (next? t)
    #t)
  (if (or (not (exact-integer? from))
          (not (check? from)))
      (error 'evens "Non-~a starting value: ~a" check-name from)
      (make-do-sequence
       (λ()
         (values ->current
                 ->next
                 from
                 next?
                 #f #f)))))

(define (in-evens from)
  (even/odd even? 'in-evens from))

(define (in-odds from)
  (even/odd odd? 'in-odds from))

(module+ test
  (require rackunit)
  (define (pull seq terms)
    (for/list ((t seq)(i (in-range terms))) t))
  (check-equal? (pull (in-evens 0) 20)
                (build-list 20 (λ(x) (* 2 x)))
                "in-evens")
  (check-equal? (pull (in-odds 1) 20)
                (build-list 20 (λ(x) (add1 (* 2 x))))
                "in-odds"))

(define (in-common-difference start base-sequence #:strip-until (su #f))
  (define (->term d)
    (diff-term d))
  (define (->next d)
    (let ((add (diff-add d))
          (gen (diff-gen d))
          (term (diff-term d)))
      (if add
          (let-values (((add* gen*) (gen)))
            (diff (+ term (car add))
                  add* gen*))
          (diff #f #f #f))))
  (define (init d)
    (let ((g (diff-gen d)))
      (let-values (((add* gen*) (sequence-generate* g)))
        (diff (diff-term d) add* gen*))))
  (struct diff (term add gen)
    #:property prop:sequence
    (λ(d)
      (make-do-sequence
       (λ()
         (values ->term
                 ->next
                 (let loop ((d (init d)))
                   (if (not su)
                       d
                       (let ((t (->term d)))
                         (if (not t)
                             (diff #f #f #f)
                             (if (<= su t)
                                 d
                                 (loop (->next d)))))))
                 ->term
                 #f #f)))))
  (diff start #f base-sequence))

(define (in-squares from)
  (in-common-difference 0 (in-odds 1) #:strip-until from))
(module+ test
  (check-equal? (pull (in-squares 0) 20)
                (build-list 20 (λ(x) (* x x)))
                "in-squares"))

(define (in-cubes from)
  (in-common-difference 0
                        (in-common-difference 1
                                              (in-common-difference 6 (endless-values 6)))
                        #:strip-until from))
(module+ test
  (check-equal? (pull (in-cubes 0) 20)
                (build-list 20 (λ(x) (* x x x)))
                "in-cubes"))
(define (in-triangle from)
  (in-common-difference 0 (in-naturals 1) #:strip-until from))

(module+ test
  (define (triangle t) (/ (* t (add1 t)) 2))
  (check-equal? (pull (in-triangle 0) 20)
                (build-list 20 triangle)))

(define (in-double-triangle from)
  (in-common-difference 0 (in-evens 2) #:strip-until from))
(module+ test
  (define (double-triangle t) (* t (add1 t)))
  (check-equal? (pull (in-double-triangle 0) 20)
                (build-list 20 double-triangle)
                "in-triangle"))

(define (every-other seq)
  (struct unterleave (x gen)
    #:property prop:sequence
    (λ(u)
      (define (->term u)
        (unterleave-x u))
      (define (->next u)
        (let ((g (unterleave-gen u)))
          (let-values (((x! gen!)(g)))
            (if x!
                (let-values (((x* gen*)(gen!)))
                  (if x*
                      (unterleave (car x*) gen*)
                      (unterleave #f #f)))
                (unterleave #f #f)))))
      (define (init u)
        (let ((g (unterleave-gen u)))
          (let-values (((x* gen*)(sequence-generate* g)))
            (if x*
                (unterleave (car x*) gen*)
                (unterleave #f #f)))))
      (make-do-sequence
       (λ()
         (values ->term
                 ->next
                 (init u)
                 (λ(u) (unterleave-x u))
                 #f #f)))))
  (unterleave #f seq))

(struct interleaver (todo done) ;lists
  #:property prop:sequence
  (λ(position)
    (define (renew pair)
      (define-values (s? s)
        ((cdr pair)))
      (and s? (cons s? s)))
    (make-do-sequence
     (λ()
       (values (λ(strct) ; position -> value
                 (caaar (interleaver-todo strct)))
               (λ(strct) ; position -> next position
                 (let ((todo (interleaver-todo strct))
                       (done (interleaver-done strct)))
                   (let ((next (renew (car todo))))
                     (if (null? (cdr todo))
                         (if next
                             (interleaver (reverse (cons next done)) null)
                             (interleaver (reverse done) null))
                         (let ((t (interleaver-todo strct)))
                           (if next
                               (interleaver (cdr t) (cons next done))
                               (interleaver (cdr t) done)))))))
               (interleaver (map (λ(s) (call-with-values (λ() (sequence-generate* s)) cons)) (interleaver-todo position))
                            null)
               (λ(strct) (not (null? (interleaver-todo strct))))
               #f
               #f)))))

(define (interleave . seqs)
  (interleaver seqs null))

(define (sequence-map* f . seqs)
  (struct mapper (seqs)
    #:property prop:sequence
    (λ(m)
      (define (->term m)
        (apply f (map car (map car (mapper-seqs m)))))
      (define (->next m)
        (let ((gens (map cdr (mapper-seqs m))))
          (mapper (map (λ(g) (values->pair (g))) (map cdr (mapper-seqs m))))))
      (define (next? m)
        (andmap car (mapper-seqs m)))
      (make-do-sequence
       (λ()
         (values ->term
                 ->next
                 (mapper (map (λ(s) (values->pair (sequence-generate* s)))
                              (mapper-seqs m)))
                 next?
                 #f #f)))))
  (mapper seqs))

