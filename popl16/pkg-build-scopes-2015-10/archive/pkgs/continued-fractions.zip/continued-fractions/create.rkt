#lang racket/base
(require "private/sequence-utils.rkt"
         "private/general-continued-fractions.rkt"
         "private/consumer-emitters.rkt")

(module+ test
  (require rackunit racket/sequence math/number-theory
           "private/sequence-utils.rkt"))

(provide ;(all-from-out racket/sequence)
         sequence->simple-continued-fraction
         sequences->general-continued-fraction
         sequence-map*
         endless-values
         in-evens in-odds
         in-squares in-cubes
         in-triangle in-double-triangle
         in-common-difference
         every-other interleave)

(define (sequence->simple-continued-fraction seq #:force (force #f))
  (define seq* (if force
                   (make-general-cf seq (endless-values 1)
                                    #:force force)
                   seq))
    (cfce1 seq* '((1 0)(0 1))))

(define (sequences->general-continued-fraction denom-sequence num-sequence #:force (force #f))
  (cfce1 (make-general-cf denom-sequence num-sequence #:force force) '((1 0)(0 1))))

(module+ test
  (define (sqrt-cf x)
    (local-require math/number-theory)
    (let* ((a (integer-root x 2))
           (b (- x (* a a))))
      (sequences->general-continued-fraction
       (sequence-append (list a) (endless-values (* 2 a)))
       (endless-values b))))
  (check-equal? (for/list ((t (sequence->simple-continued-fraction
                               (sequence-append (list 1) (endless-values 2))))
                           (i (in-range 20)))
                  t)
                (for/list ((t (sqrt-cf 2))
                           (i (in-range 20)))
                  t)
                "sequence->simple test")
  (check-equal? (for/list ((t (sqrt-cf 3))
                           (i (in-range 20)))
                  t)
                '(1 1 2 1 2 1 2 1 2 1 2 1 2 1 2 1 2 1 2 1)
                "sequences->general test"))