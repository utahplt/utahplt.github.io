#lang info
(define version "0.8")
(define collection 'multi)
(define pkg-desc "Procedures for continued fraction arithmetic and base conversion.")
(define deps '("base"
               "math-lib"))
(define build-deps '("racket-doc"
                     "rackunit-lib"
                     "scribble-lib"))
