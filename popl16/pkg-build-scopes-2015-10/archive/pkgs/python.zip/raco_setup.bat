raco setup python
pause