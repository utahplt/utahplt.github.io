#lang setup/infotab

(define collection 'multi)
(define deps '("base" "scribble-lib" "typed-racket-lib"))
(define build-deps '("racket-doc" "typed-racket-lib"))

; vim:set ts=2 sw=2 et:
