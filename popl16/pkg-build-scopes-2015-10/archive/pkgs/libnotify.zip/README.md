libnotify for Racket
--------------------

This package provides support for desktop notifications through the
[libnotify](https://developer.gnome.org/libnotify/) library.

Installation
------------

`raco pkg install libnotify` (installs from the package catalog)

Documentation
-------------

Will be linked once the pkg-build service updates.

Limitations
-----------

Doesn't currently support features like querying the server capabilities
or supplying notification hints. If you need these features, let me know.

---

Copyright (c) 2015 Asumu Takikawa

This program is free software: you can redistribute it and/or modify it under
the terms of the GNU Lesser General Public License as published by the Free
Software Foundation, either version 3 of the License, or (at your option) any
later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE.  See the GNU Lesser General Public License for more
details.

You should have received a copy of the GNU Lesser General Public License along
with this program.  If not, see http://www.gnu.org/licenses.
