#lang setup/infotab

(define collection "tesseract")
