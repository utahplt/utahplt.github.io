#lang racket

#|
Tesseracket is a thin Racket wrapper for the Google Tesseract OCR:
( http://code.google.com/p/tesseract-ocr/ )
|#

(provide image->string)

; Generates new filename
; For now, just a random number with "tess_tmp_" in front
(define (generate-filename)
  (format "tess_tmp_~a" (random)))


; Removes all paths indicated
(define (cleanup . paths)
  (apply delete-directory/files paths))

; Runs tesseract on image, saves output to out-base.txt 
; Accepts configuration options as a list of separate strings
; String String List-of-Strings -> Bool
(define (tesser image out-base . config)
  (if (not (find-executable-path "tesseract")) (raise-user-error "Tesseracket can't find tesseract on your system.")
      (apply system* (find-executable-path "tesseract") image out-base "--quiet" config)))

; Runs tesseract on image, returns output as a string
; Accepts configuration options as a list of separate strings
; String List-of-Strings -> String
(define (return-tesser image . config)
  (let ([filename (generate-filename)])
    (dynamic-wind 
     (λ () (apply tesser image filename config))
     (λ () (file->string (string-append filename ".txt")))
     (λ () (cleanup (string-append filename ".txt"))))))


; Allows for input of config as a single string
; Example:
;          (image->string "foo.png" "../filebase" "-psm 8 -nobatch numbers") => #t
; Path-string Path-string String -> Bool or String
(define (image->string image #:out-base [out-base ""] #:config [config ""])
  (cond
    ([not (file-exists? image)] (raise-user-error "Couldn't open '~a', file does not exist" image))
    ([string=? out-base ""] (apply return-tesser image (string-split config)))
    (else (apply tesser image out-base (string-split config)))))
 
