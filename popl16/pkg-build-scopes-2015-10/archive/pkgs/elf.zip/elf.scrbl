#lang scribble/manual

@defmodule[elf]

@title{ELF Library}

@table-of-contents[]

@section{Introduction}
This library can read and write files in the exectuable and linking format common among unix like systems.

Due to the nature of overlapping binary data in ELF files, the library is strict in terms of write offsets and lengths.
It is therefor the users responsibility to ensure that the length and offset fields in the headers are adjusted properly should the length of binary data be changed.

See the ELF man page elf(5) for more general information on the executable and linking format.

@section{Reference}

@defstruct*[elf-header ([class integer?]
                        [data integer?]
                        [version integer?]
                        [abi integer?]
                        [abiver integer?]
                        [type integer?]
                        [machine integer?]
                        [entry integer?]
                        [prog-headers integer?]
                        [section-headers integer?]
                        [flags integer?]
                        [header-size integer?]
                        [prog-header-size integer?]
                        [prog-header-count integer?]
                        [sec-header-size integer?]
                        [sec-header-count integer?]
                        [sec-index integer?])]{
The ELF header.
}

@defstruct*[program-header ([type integer?]
                            [offset integer?]
                            [v-addr integer?]
                            [p-addr integer?]
                            [file-size integer?]
                            [mem-size integer?]
                            [flags integer?]
                            [align integer?]
                            [data bytes?])]
An ELF program header.

The data field is unused currently.
@defstruct*[section-header ([name integer?]
                            [type integer?]
                            [flags integer?]
                            [addr integer?]
                            [offset integer?]
                            [size integer?]
                            [link integer?]
                            [info integer?]
                            [addralign integer?]
                            [entsize integer?]
                            [data bytes?])]
An ELF section header.

The data field is unused currently.

@defproc[(read-elf [stream (file-stream-port?)]) list?]{
Reads an ELF from a file-stream, file stream must be seekable.

Returns a list consisting of an ELF header datastructure, a list of program-header, a list of section-header and 3 remaining elements of byte-string.
One for data following the ELF header, another for data after the program headers and finally one for everything after the section headers.
}

@defproc[(write-elf [elf (list?)] [stream (output-port?)]) void?]{
Write an object representing ELF data to a file stream as binary.

Endianess and data (32 or 64 bit) should be set in the respective header fields, if someone needs to change them explictly.
}

@defproc[(read-elf-header [stream (file-stream-port?)]) elf-header?]{
Read an ELF header from stream at current seek position.
}

@defproc[(write-elf-header [header (elf-header?)] [stream (output-port?)]) void?]{
Writes an ELF header to stream at current seek position.
}

@defproc[(elf-magic? [bstring (bytes?)]) boolean?]{
Checks if byte-string has valid elf header magic string, each ELF file must have this string at first 4 bytes from its start.
}

@defproc[(elf-info [header (elf-header?)]) string?]{
Returns a string with some general human readable information about an ELF header.
}

@defproc[(read-elf-program-header [stream (file-stream-port?)] [size (boolean?) false] [endianess (boolean?) false]) program-header?]{
Reads a program header from current seek position.
}

@defproc[(write-elf-program-header [prog-header (program-header?)] [stream (output-port?)] [data-size (boolean?) false] [endianess (boolean?) false]) void?]{
Writes a program header to stream at current seek position.
}

@defproc[(read-section [stream (file-stream-port?)] [size (boolean?) false] [endianess (boolean?) false]) section-header?]{
Reads a section header from current seek position.
}

@defproc[(write-section-header [section-header (section-header?)] [stream (output-port?)] [data-size (boolean?) false] [endianess (boolean?) false]) void?]{
Writes a section header to stream at current seek position. 
}

@defthing[elf-class-32 (integer?)]{
Define a 32bit ELF file in the class field of the ELF header.
}

@defthing[elf-class-64 (integer?)]{
Define a 64bit ELF file in the class field of the ELF header.
}

@defthing[elf-2cmpl-msb (integer?)]{
Define a most significant bit ELF file data field of the ELF header.
}

@defthing[elf-2cmpl-lsb (integer?)]{
Define a least significant bit ELF file data field of the ELF header.
}

@section{Copyright and contact}
Writen by "Code_Man".
Send feedback to Code_Man_AT_Cybnet.ch.
See code_man.cybnet.ch for more stuff of mine.

No implied warranties or liability of any kind, use at own risk.
