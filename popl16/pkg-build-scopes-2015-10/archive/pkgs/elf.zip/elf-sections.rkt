#lang racket/base

; elf-sections.rkt

; Elf section handling

(require elf/elf-header elf/elf-constants)
(require racket/base racket/contract racket/bool racket/list)

(provide (struct-out section-header)
         (contract-out [new-section (->* (integer? integer? integer? integer? integer? integer? integer? integer? integer? integer? string?)
                                         section-header?)]
                       [read-section (->* (file-stream-port?)
                                          (boolean? boolean?)
                                          section-header?)]
                       [write-section-header (->* (section-header? output-port?)
                                                  (boolean? boolean?)
                                                  void)]
                       [read-all-section-headers (->* (elf-header? file-stream-port?)
                                                      (boolean? boolean?)
                                                      list?)]
                       ;[resolve-secion-name (-> integer? section-header? list?)]
                       )
         ;get-section-by-name
         ;(struct-out symbol)
         ;read-symtable
         ;(struct-out reloc)
         ;read-reloc
         ;(struct-out reloca)
         ;read-reloca
         ;section-size
         ;write-section-data
         )

(struct section-header
  (name type flags addr offset size link info addralign entsize data) #:mutable)

; Easy section making
(define (new-section [name 0] [type 0] [flags 0] [addr 0] [offset 0] [size 0] [link 0] [info 0] [addralign 0] [entsize 0] [data 0])
  (section-header name type flags addr offset size link info addralign entsize data))

; 
(define (read-section stream [size false] [endianess false])
  (let ((input ""))
    (define header (new-section))
    (set! input
          (read-bytes 8 stream))
    (set-section-header-name! header
                              (elf-endianess-convert-and-read (subbytes input 0 4)
                                                              endianess))
    (set-section-header-type! header
                              (elf-endianess-convert-and-read (subbytes input 4 8)
                                                              endianess))
    (if (not size)
        (begin (set! input
                     (read-bytes 32 stream))
               (set-section-header-flags! header
                                          (elf-endianess-convert-and-read (subbytes input 0 4)
                                                                          endianess))
               (set-section-header-addr! header
                                         (elf-endianess-convert-and-read (subbytes input 4 8)
                                                                         endianess))
               (set-section-header-offset! header
                                           (elf-endianess-convert-and-read (subbytes input 8 12)
                                                                           endianess))
               (set-section-header-size! header
                                         (elf-endianess-convert-and-read (subbytes input 12 16)
                                                                         endianess))
               (set-section-header-link! header
                                         (elf-endianess-convert-and-read (subbytes input 16 20)
                                                                         endianess))
               (set-section-header-info! header
                                         (elf-endianess-convert-and-read (subbytes input 20 24)
                                                                         endianess))
               (set-section-header-addralign! header
                                              (elf-endianess-convert-and-read (subbytes input 24 28)
                                                                              endianess))
               (set-section-header-entsize! header
                                            (elf-endianess-convert-and-read (subbytes input 28 32)
                                                                            endianess)))
        (begin
          (set! input
                (read-bytes 56 stream))
          (set-section-header-flags! header
                                     (elf-endianess-convert-and-read (subbytes input 0 8)
                                                                     endianess))
          (set-section-header-addr! header
                                    (elf-endianess-convert-and-read (subbytes input 8 16)
                                                                    endianess))
          (set-section-header-offset! header
                                      (elf-endianess-convert-and-read (subbytes input 16 24)
                                                                      endianess))
          (set-section-header-size! header
                                    (elf-endianess-convert-and-read (subbytes input 24 32)
                                                                    endianess))
          (set-section-header-link! header
                                    (elf-endianess-convert-and-read (subbytes input 32 36)
                                                                    endianess))
          (set-section-header-info! header
                                    (elf-endianess-convert-and-read (subbytes input 36 40)
                                                                    endianess))
          (set-section-header-addralign! header
                                         (elf-endianess-convert-and-read (subbytes input 40 48)
                                                                         endianess))
          (set-section-header-entsize! header
                                       (elf-endianess-convert-and-read (subbytes input 48 56)
                                                                       endianess))))
;    (set-section-header-data! header
;                              (if (and (section-header-size header)
;                                       (not (or (= (section-header-type header)
;                                                   elf-section-type-null)
;                                                (= (section-header-type header)
;                                                   elf-section-header-type-nobits))))
;                                  (begin (set! old-position
;                                               (file-position stream))
;                                         (file-position stream
;                                                        (section-header-offset header))
;                                         (set! input
;                                               (read-bytes (section-header-size header)
;                                                           stream))
;                                         (file-position stream old-position)
;                                         input)
;                                  '()))
;    (set-section-header-data! header   
;                              (cond [(eq? (section-header-type header)
;                                          elf-section-type-null)
;                                     false]
;                                    [(eq? (section-header-type header)
;                                          elf-section-header-type-strtab)
;                                     (section-header-data header)]
;                                    [(eq? (section-header-type header)
;                                          elf-section-header-type-symtab)
;                                     (read-symtable header headerX)]
;                                    [(eq? (section-header-type header)
;                                          elf-section-header-type-reloc)
;                                     (read-reloc header headerX)]
;                                    [(eq? (section-header-type header)
;                                          elf-section-header-type-reloca) 
;                                     (read-reloca header headerX)]
;                                    [true (section-header-data header)]))
    header))

(define (read-all-section-headers header stream [size false] [endianess false])
  (when (elf-header-section-headers header)
    (let ([old-position (file-position stream)]
          [sections '()]
          [index '()])
      (file-position stream
                     (elf-header-section-headers header))
      (set! sections
            (for/list ([i (elf-header-sec-header-count header)])
              (read-section stream size endianess)))
      (set! index (list-ref sections
                            (elf-header-sec-index header)))
      ;(for-each (lambda (sec)
	;	  (resolve-secion-name (section-header-data index)
	;			       sec))
     ;           sections)
      ;(remq index sections)
      (file-position stream old-position)
      sections)))

(define (write-section-header section stream [data-size false] [endianess false])
  (set! endianess
        (not endianess))
  (write-bytes (bytes-append (integer->integer-bytes (section-header-name section)
                                                     4 endianess)
                             (integer->integer-bytes (section-header-type section)
                                                     4 endianess)
                             (if (not data-size)                          
                                 (bytes-append (integer->integer-bytes (section-header-flags section)
                                                                       4 false endianess)
                                               (integer->integer-bytes (section-header-addr section)
                                                                       4 false endianess)
                                               (integer->integer-bytes (section-header-offset section)
                                                                       4 false endianess)
                                               (integer->integer-bytes (section-header-size section)
                                                                       4 false endianess)
                                               (integer->integer-bytes (section-header-link section)
                                                                       4 false endianess)
                                               (integer->integer-bytes (section-header-info section)
                                                                       4 false endianess)
                                               (integer->integer-bytes (section-header-addralign section)
                                                                       4 false endianess)
                                               (integer->integer-bytes (section-header-entsize section)
                                                                       4 false endianess))
                                 (bytes-append (integer->integer-bytes (section-header-flags section)
                                                                       8 false endianess)
                                               (integer->integer-bytes (section-header-addr section)
                                                                       8 false endianess)
                                               (integer->integer-bytes (section-header-offset section)
                                                                       8 false endianess)
                                               (integer->integer-bytes (section-header-size section)
                                                                       8 false endianess)
                                               (integer->integer-bytes (section-header-link section)
                                                                       4 false endianess)
                                               (integer->integer-bytes (section-header-info section)
                                                                       4 false endianess)
                                               (integer->integer-bytes (section-header-addralign section)
                                                                       8 false endianess)
                                               (integer->integer-bytes (section-header-entsize section)
                                                                       8 false endianess))))
               stream))

(define (read-section-index index)
  (let ((str '())
        (setX '()))
    (set! index
          (bytes->list (section-header-data index)))
    (do ([i 0
            (+ 1 i)])
      ((>= i (length index)))
      (if (= (list-ref index i)
             0)
          (begin (set! setX
                       (append setX
                               (list (bytes->string/utf-8 (apply bytes str)))))
                 (set! str (list)))
          (set! str
                (append str
                        (list (list-ref index i))))))
    (set! index (cdr setX))
    setX))

(define (resolve-secion-name index section)
  (set-section-header-name! section
                            (if (or (>= (section-header-name section)
                                        (bytes-length index))
                                    (= (section-header-name section)
                                       0))
                                ""
                                (bytes->string/utf-8 (subbytes index
                                                               (section-header-name section)
                                                               (+ (for/or ([i (range (bytes-length (subbytes index
                                                                                                             (section-header-name section))))])
                                                                    (if (eq? (bytes-ref (subbytes index
                                                                                                  (section-header-name section)) i) 0) i false))
                                                                  (section-header-name section)))))))
(define (get-section-by-name elf name)
  (ormap (lambda (name)
	   (if (equal? (section-header-name name)
                       name)
               name false))
	 (list-ref elf 2)))

(define (read-string-table section)
  (let ((strings '()))
    (do ([i 0 
            (+ 1 i)])
      ((< i (bytes-length section)))
      (if 0 0 0))))

(struct symbolX
  (name info other index value size)
  #:mutable)

(define (read-symtable section elf)
  (let ((c '()))
    (do ([i 0
            (+ 1 i)]
         [sym (symbolX 0 0 0 0 0 0)
              (symbolX 0 0 0 0 0 0)])
      ((>= (* i
              (if false 16 24))
           (section-header-size section)))
      (if false
          (begin (set-symbolX-name! sym
                                   (subbytes (section-header-data section)
                                             (* i 16)
                                             (+ (* i 16)
                                                4)))
                 (set-symbolX-value! sym
                                    (subbytes (section-header-data section)
                                              (+ (* i 16)
                                                 4)
                                              (+ (* i 16)
                                                 8)))
                 (set-symbolX-size! sym
                                   (subbytes (section-header-data section)
                                             (+ (* i 16)
                                                8)
                                             (+ (* i 16)
                                                12)))
                 (set-symbolX-info! sym
                                   (subbytes (section-header-data section)
                                             (+ (* i 16)
                                                12)
                                             (+ (* i 16)
                                                13)))
                 (set-symbolX-other! sym
                                    (subbytes (section-header-data section)
                                              (+ (* i 16)
                                                 13)
                                              (+ (* i 16)
                                                 14)))
                 (set-symbolX-index! sym
                                    (subbytes (section-header-data section)
                                              (+ (* i 16)
                                                 15)
                                              (+ (* i 16)
                                                 16))))
          (begin (set-symbolX-name! sym
                                   (subbytes (section-header-data section)
                                             (* i 24)
                                             (+ (* i 24)
                                                4)))
                 (set-symbolX-info! sym
                                   (subbytes (section-header-data section)
                                             (+ (* i 24)
                                                4)
                                             (+ (* i 24)
                                                5)))
                 (set-symbolX-other! sym
                                    (subbytes (section-header-data section)
                                              (+ (* i 24)
                                                 5)
                                              (+ (* i 24)
                                                 6)))
                 (set-symbolX-index! sym
                                    (subbytes (section-header-data section)
                                              (+ (* i 24)
                                                 6)
                                              (+ (* i 24)
                                                 8)))
                 (set-symbolX-value! sym
                                    (subbytes (section-header-data section)
                                              (+ (* i 24)
                                                 8)
                                              (+ (* i 24)
                                                 16)))
                 (set-symbolX-size! sym
                                   (subbytes (section-header-data section)
                                             (+ (* i 24)
                                                16)
                                             (+ (* i 24)
                                                24)))))
      (set! c
            (append c
                    (list sym)))
      c)))

(define (get-symbol name symtable)
false)

(struct reloc
  (offset info) #:mutable)

(define (read-reloc section elf)
  (let ((c '()))
    (do ([i 0
            (+ 1 i)]
         [sym (reloc 0 0 )
              (reloc 0 0)])
      ((>= (* i
              (if false 8 16))
           (section-header-size section)))
      (if false
          (begin (set-reloc-offset! sym
                                    (subbytes (section-header-data section)
                                              (* i 8)
                                              (+ (* i 8)
                                                 4)))
                 (set-reloca-info! sym
                                   (subbytes (section-header-data section)
                                             (+ (* i 8)
                                                4)
                                             (+ (* i 8)
                                                8))))
          (begin (set-reloc-offset! sym
                                    (subbytes (section-header-data section)
                                              (* i 16)
                                              (+ (* i 16)
                                                 8)))
                 (set-reloc-info! sym
                                  (subbytes (section-header-data section)
                                            (+ (* i 16)
                                               8)
                                            (+ (* i 16)
                                               16)))))
      (set! c
            (append c
                    (list sym)))
      c)
    c))

(struct reloca
  (offset info addend) #:mutable)

(define (read-reloca section elf)
  (let ((c '()))
    (do ([i 0
            (+ 1 i)]
         [sym (reloca 0 0 0)
              (reloca 0 0 0)])
      ((>= (* i
              (if false 12 24))
           (section-header-size section)))
      (if false
          (begin (set-reloca-offset! sym
                                     (subbytes (section-header-data section)
                                               (* i 12)
                                               (+ (* i 12)
                                                  4)))
                 (set-reloca-info! sym
                                   (subbytes (section-header-data section)
                                             (+ (* i 12)
                                                4)
                                             (+ (* i 12)
                                                8)))
                 (set-reloca-addend! sym
                                     (subbytes (section-header-data section)
                                               (+ (* i 12)
                                                  8)
                                               (+ (* i 12)
                                                  12))))
          (begin (set-reloca-offset! sym
                                     (subbytes (section-header-data section)
                                               (* i 24)
                                               (+ (* i 24)
                                                  8)))
                 (set-reloca-info! sym
                                   (subbytes (section-header-data section)
                                             (+ (* i 24)
                                                8)
                                             (+ (* i 24)
                                                16)))
                 (set-reloca-addend! sym
                                     (subbytes (section-header-data section)
                                               (+ (* i 24)
                                                  16)
                                               (+ (* i 24)
                                                  24)))))
      (set! c
            (append c
                    (list sym)))
      c)
    c))

(define (section-size section data-size)
  (let ((elf (list '() '() (list section)))
        (i 0)
        (size 0))
    (cond [(eq? (section-header-type (list-ref (list-ref elf 2)
                                               i))
                elf-section-type-null)
           0]
          [(eq? (section-header-type (list-ref (list-ref elf 2)
                                               i))
                elf-section-header-type-nobits)
           0]
          [(eq? (section-header-type (list-ref (list-ref elf 2)
                                             i))
                elf-section-header-type-strtab)
           (bytes-length (section-header-data (list-ref (list-ref elf 2)
                                                           i)))]
          [(eq? (section-header-type (list-ref (list-ref elf 2)
                                               i))
                elf-section-header-type-symtab)
           (* (if data-size 16 24)
              (length (section-header-data (list-ref (list-ref elf 2)
                                                     i))))]
          [(eq? (section-header-type (list-ref (list-ref elf 2)
                                               i))
                elf-section-header-type-reloc)
           (* (if data-size 8 16)
              (length (section-header-data (list-ref (list-ref elf 2)
                                                   i))))]
        [(eq? (section-header-type (list-ref (list-ref elf 2)
                                             i))
              elf-section-header-type-reloca)
         (* (if data-size 12 24)
            (length (section-header-data (list-ref (list-ref elf 2)
                                                   i))))]
        ;[(eq? (section-header-type (list-ref (list-ref elf 2)
        ;                                      i))
        ;      elf-section-header-type-dynamic)
        ;  (when (> (* (if bit-size 8 16)
        ;              (length (section-header-data (list-ref (list-ref elf 2)
        ;                                                     i))))
        ;          size)
        ;   (set! size
        ;        (* (if bit-size 8 16)
        ;           (length (section-header-data (list-ref (list-ref elf 2)
        ;                                                   i))))))]
        [true (bytes-length (section-header-data (list-ref (list-ref elf 2)
                                                           i)))])))

(define (write-section-data section stream [data-size false] [endianess false])
  (cond
        [(eq? (section-header-type section)
              elf-section-type-null)
         ]
        [(eq? (section-header-type section)
              elf-section-header-type-nobits)
         ]
        [(eq? (section-header-type section)
              elf-section-header-type-strtab)
         (write-bytes (section-header-data section)
                      stream)]
        [(eq? (section-header-type section)
              elf-section-header-type-symtab)
         (for/list ([j (length (section-header-data section))])
           (write-bytes (bytes-append (list-ref (symbolX-name (section-header-data section))
                                                j)
                                      (list-ref (symbolX-value (section-header-data section))
                                                j)
                                      (list-ref (symbolX-size (section-header-data section))
                                                j)
                                      (list-ref (symbolX-info (section-header-data section))
                                                j)
                                      (list-ref (symbolX-other (section-header-data section))
                                                j)
                                      (list-ref (symbolX-index (section-header-data section))
                                                j))
                        stream))]
        [(eq? (section-header-type section)
              elf-section-header-type-reloc)
         (for-each (lambda (x)
                     (write-bytes (bytes-append (reloc-offset x)
                                                (reloc-info x))
                                  stream))
                   (section-header-data section))]
        [(eq? (section-header-type section)
              elf-section-header-type-reloca)
         (for-each (lambda (x)
                     (write-bytes (bytes-append (reloca-offset x)
                                                (reloca-info x)
                                                (reloca-addend x))
                                  stream))
                   (section-header-data section))]
        [true
         (write-bytes (section-header-data section)
                      stream)]))
