#lang racket/base

; elf-program-header.rkt

; Elf program handling

(module elf racket/base)

(require elf/elf-header elf/elf-constants)
(require racket/base racket/contract racket/bool)

(provide (struct-out program-header)
         (contract-out [read-elf-program-header (->* (file-stream-port?)
                                                     (boolean? boolean?)
                                                     program-header?)]
                       [write-elf-program-header (->* (program-header? output-port?)
                                                      (boolean? boolean?)
                                                      void)]))

(struct program-header
  (type
   offset
   v-addr
   p-addr
   file-size
   mem-size
   flags
   align
   data) #:mutable)

(define (read-elf-program-header stream [size false] [endianess false])
  (let ([input ""]
        [header (program-header 0 0 0 0 0 0 0 0 "")])
    (set! input
          (read-bytes 4 stream))
    (set-program-header-type! header
                              (integer-bytes->integer input false
                                                      (not endianess)))
    (if (not size)
        (begin (set! input
                     (read-bytes 28 stream))
               (set-program-header-offset! header
                                           (elf-endianess-convert-and-read (subbytes input 0 4)
                                                                           endianess))
               (set-program-header-v-addr! header
                                           (elf-endianess-convert-and-read (subbytes input 4 8)
                                                                           endianess))
               (set-program-header-p-addr! header
                                           (elf-endianess-convert-and-read (subbytes input 8 12)
                                                                           endianess))
               (set-program-header-file-size! header
                                              (elf-endianess-convert-and-read (subbytes input 12 16)
                                                                         endianess))
               (set-program-header-mem-size! header
                                        (elf-endianess-convert-and-read (subbytes input 16 20)
                                                                        endianess))
               (set-program-header-flags! header
                                          (elf-endianess-convert-and-read (subbytes input 20 24)
                                                                     endianess))
               (set-program-header-align! header
                                          (elf-endianess-convert-and-read (subbytes input 24 28)
                                                                          endianess)))
        (begin (set! input
                     (read-bytes 52 stream))
               (set-program-header-flags! header
                                          (elf-endianess-convert-and-read (subbytes input 0 4)
                                                                          endianess))
               (set-program-header-offset! header
                                           (elf-endianess-convert-and-read (subbytes input 4 12)
                                                                           endianess))
               (set-program-header-v-addr! header
                                           (elf-endianess-convert-and-read (subbytes input 12 20)
                                                                           endianess))
               (set-program-header-p-addr! header
                                           (elf-endianess-convert-and-read (subbytes input 20 28)
                                                                           endianess))
               (set-program-header-file-size! header
                                              (elf-endianess-convert-and-read (subbytes input 28 36)
                                                                              endianess))
               (set-program-header-mem-size! header
                                             (elf-endianess-convert-and-read (subbytes input 36 44)
                                                                             endianess))
               (set-program-header-align! header
                                          (elf-endianess-convert-and-read (subbytes input 44 52)
                                                                          endianess))))
    (set! size
          (program-header-file-size header))
    ;(set-program-header-data! header
    ;                          (if (and size)
    ;                              (begin (set! old-position
    ;                                           (file-position stream))
    ;                                     (file-position stream
    ;                                                    (program-header-offset header))
    ;                                     (set! input
    ;                                           (read-bytes size stream))
    ;                                     (file-position stream old-position)
    ;                                     input)
    ;                              '()))
    header))

(define (write-elf-program-header prog-header handle [data-size false] [endianess false])
  (set! endianess
        (not endianess))
  (write-bytes (bytes-append (integer->integer-bytes (program-header-type prog-header)
                                                     4 false endianess)
                             (if (not data-size)
                                 (bytes-append (integer->integer-bytes (program-header-offset prog-header)
                                                                       4 false endianess)
                                               (integer->integer-bytes (program-header-v-addr prog-header)
                                                                       4 false endianess)
                                               (integer->integer-bytes (program-header-p-addr prog-header)
                                                                       4 false endianess)
                                               (integer->integer-bytes (program-header-file-size prog-header)
                                                                       4 false endianess)
                                               (integer->integer-bytes (program-header-mem-size prog-header)
                                                                       4 false endianess)
                                               (integer->integer-bytes (program-header-flags prog-header)
                                                                       4 false endianess)
                                               (integer->integer-bytes (program-header-align prog-header)
                                                                       4 false endianess))
                                 (bytes-append (integer->integer-bytes (program-header-flags prog-header)
                                                                       4 false endianess)
                                               (integer->integer-bytes (program-header-offset prog-header)
                                                                       8 false endianess)
                                               (integer->integer-bytes (program-header-v-addr prog-header)
                                                                       8 false endianess)
                                               (integer->integer-bytes (program-header-p-addr prog-header)
                                                                       8 false endianess)
                                               (integer->integer-bytes (program-header-file-size prog-header)
                                                                       8 false endianess)
                                               (integer->integer-bytes (program-header-mem-size prog-header)
                                                                       8 false endianess)
                                               (integer->integer-bytes (program-header-align prog-header)
                                                                       8 false endianess))))
               handle))
  