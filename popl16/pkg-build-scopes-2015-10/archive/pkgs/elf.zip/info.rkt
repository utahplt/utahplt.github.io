#lang info

(define collection "elf")
(define version "0.1")
(define scribblings '(("elf.scrbl" ())))
