#lang racket/base

; elf.rkt

; Exectuable and linking format handling library
  
; This file is a disgusting mess but it works

(require racket/base racket/contract racket/port)
(require elf/elf-header elf/elf-program-header elf/elf-sections elf/elf-constants)

(provide (all-from-out elf/elf-header elf/elf-program-header elf/elf-sections elf/elf-constants)
         (contract-out [read-elf (-> file-stream-port? list?)]
                       ;[elf-get-code-section (-> list? list?)]
                       ;[elf-get-data-section (-> list? list?)]
                       ;[elf-get-bss-section (-> list? list?)]
                       [write-elf (-> list? output-port? void?)]))

;(define (elf-get-code-section elf)
;  (get-section-by-name elf ".text"))

;(define (elf-get-data-section elf)
;  (get-section-by-name elf ".data"))

;(define (elf-get-bss-section elf)
;  (get-section-by-name elf ".bss"))

;(define (elf-get-symtable-section elf)
;  (get-section-by-name elf ".symtab"))

(define (read-elf stream)
  (define header (read-elf-header stream))
  (when (= (elf-header-prog-headers header)
           66356)
    (error "Extended program headers not supported"))
  (when (not (= (elf-header-version header)
                1))
    (error "Unknonw elf version"))
  (file-position stream
                 (elf-header-prog-headers header))
  (list header
        (for/list ([i (elf-header-prog-header-count header)])
          (read-elf-program-header stream
                                   (= (elf-header-class header)
                                      elf-class-64)
                                   (= (elf-header-data header)
                                      elf-2cmpl-lsb)))
        (read-all-section-headers header stream
                                  (= (elf-header-class header)
                                     elf-class-64)
                                  (= (elf-header-data header)
                                     elf-2cmpl-lsb))
        (begin (file-position stream
                              (elf-header-prog-headers header))
               (read-bytes (- (elf-header-prog-headers header)
                              (elf-header-header-size header))
                           stream))
        (begin (file-position stream
                              (+ (elf-header-prog-headers header)
                                 (* (elf-header-prog-header-size header)
                                    (elf-header-prog-header-count header))))
               (read-bytes (- (elf-header-section-headers header)
                              (+ (elf-header-prog-headers header)
                                 (* (elf-header-prog-header-size header)
                                    (elf-header-prog-header-count header))))
                           stream))
        (begin (file-position stream
                              (+ (elf-header-section-headers header)
                                 (* (elf-header-sec-header-size header)
                                    (elf-header-sec-header-count header))))
               (port->bytes stream))))

(define (write-elf elf stream)
  (let ((offset 0)
        (prog-count (length (list-ref elf 1)))
        (name-offset 0)
        (name "")
        (name-list '())
        (j 0)
        [endianess (= (elf-header-data (list-ref elf 0))
                     elf-2cmpl-lsb)]
        [bit-size (= (elf-header-class (list-ref elf 0))
                     elf-class-64)])
    (set! offset
          (if bit-size 64 52))
    (set-elf-header-header-size! (list-ref elf 0)
                                 offset)
    (set-elf-header-prog-header-count! (list-ref elf 0)
                                       prog-count)
    ;(set-elf-header-sec-header-count! (list-ref elf 0)
    ;                                  (add1 (length (list-ref elf 2))))
    ;i))))))
    ;(set-elf-header-prog-headers! (list-ref elf 0)
    ;                              (if prog-count offset 0))
    ;(set! offset
    ;      (+ offset
    ;         (* prog-count
    ;         (if bit-size
    ;             44 56))))
    ;(set-elf-header-section-headers! (list-ref elf 0)
    ;                                 (if (elf-header-sec-header-count (list-ref elf 0))
    ;                                     offset 0))
    ;(set! offset
     ;    (+ offset
    ;        (* (elf-header-sec-header-count (list-ref elf 0))
     ;           (if bit-size
      ;              40 64))))
    ;(set-elf-header-sec-index! (list-ref elf 0)
    ;                           0)
    (write-elf-header (list-ref elf 0)
                      stream)
    '(when (= (program-header-type (list-ref (list-ref elf 1)
                                            0))
             6)
      (write-elf-program-header (program-header 6
                                                (if bit-size 52 64)
                                                (+ 4194304
                                                   (if bit-size 52 64))
                                                (+ 4194304
                                                   (if bit-size 52 64))
                                                (* prog-count
                                                   (if bit-size
                                                       44 56))
                                                (* prog-count
                                                   (if bit-size
                                                       44 56))
                                                (bitwise-ior 1 4)
                                                8
                                                (bytes))
                                stream 0 0 bit-size endianess)
      ;(set! elf (list (list-ref elf 0)
                     ; (cdr (list-ref elf 1))
                      ;(list-ref elf 2)
                     ; (list-ref elf 3)
                     ; (list-ref elf 4)
                      ;(list-ref elf 5)))
       )
    ;(for-each (lambda (prog) ; FIX ME
    ;             (set-program-header-offset! prog
     ;                                        (+ (program-header-offset prog)
    ;                                            ))))
    (file-position stream
                   (elf-header-prog-headers (list-ref elf 0)))
    (for-each (lambda (prog)
                ;(set-program-header-offset! prog offset)
                ;(set-program-header-file-size! prog
                ;                               (if (not (= (program-header-type prog)
                ;                                           0))
                ;                                   (bytes-length (program-header-data prog))
                ;                                   0))
                ;(set! offset
                ;      (+ offset
                ;         (program-header-file-size prog)))
                (write-elf-program-header prog stream bit-size endianess)
                ;(display (program-header-offset prog))(display " ")(display (program-header-file-size prog))(newline)
                )
              (list-ref elf 1))
    (file-position stream
                   (elf-header-section-headers (list-ref elf 0)))
    (for-each (lambda (section)
                ;(set-section-header-size! section
                ;                          (if (not (eq? (section-header-data section) '()))
                ;                              (bytes-length (section-header-data section))
                ;                              0))
                ;                          (section-size prog bit-size))
                ;(set-section-header-offset! section offset)
                ;(set! offset
                ;     (+ offset
                 ;        (if (not (eq? (section-header-data section) '()))
                 ;            (bytes-length (section-header-data section))
                  ;           0)))
                ;         (section-header-size prog)))
                ;(set! name
                ;      (section-header-name prog))
                ;(set-section-header-name! prog
                ;                          (if (string=? name "")
                ;                              0 name-offset))
                ;(unless (string=? name "")
                ;  (set! name-offset
                ;        (+ name-offset 1
                ;           (string-length name)))
                ;  (set! name-list (append name-list
                ;                          (list name))))
                (write-section-header section stream bit-size endianess))
              (list-ref elf 2))
            ;(for-each (lambda (prog)
    ;            (write-bytes (program-header-data prog)
    ;                         stream))
    ;          (list-ref elf 1))
    ;(for-each (lambda (sec)
    ;            (set! name
    ;                  (section-header-name sec))
    ;            (unless (string=? name "")
    ;              (set! name-offset
    ;                    (+ name-offset 1
    ;                       (string-length name)))))
    ;          (list-ref elf 2))
    ;(when (not (= name-offset 0))
    ;  (set! name-offset (+ 2
    ;                       (string-length ".shstrtab")))
    ;  (write-section-header (new-section 1 elf-section-header-type-strtab 0 0 offset name-offset 0 0 0 0 "")
    ;                        stream false endianess)
    ;  (set! offset
    ;        (+ offset name-offset))
    ;  (set! name-offset 1)) ; Null char is first char
;    (when (not (= name-offset
;                  (+ 2
;                     (string-length ".shstrtab"))))
;      (write-bytes (bytes-append (make-bytes 1 0)
;                                 (string->bytes/latin-1 ".shstrtab")
;                                 (make-bytes 1 0))
;                   stream)
;      (for-each (lambda (sec)
;                  (when (not (= (section-header-name sec)
;                                0))
;                    (write-bytes (bytes-append (string->bytes/latin-1 (list-ref name-list j))
;                                               (make-bytes 1 0))
;                                 stream)
;                    (set! j (add1 j))))
;                (list-ref elf 2)))
    ;(for-each (lambda (section)
    ;            (when (not (null? (section-header-data section)))
    ;              (write-bytes (section-header-data section)
    ;                           stream)))
    ;            (write-section-data sec stream bit-size true))
    ;          (list-ref elf 2))
    (file-position stream
                   (elf-header-header-size (list-ref elf 0)))
    (write-bytes (list-ref elf 3)
                 stream)
    (file-position stream
                   (+ (elf-header-prog-headers (list-ref elf 0))
                      (* (elf-header-prog-header-size (list-ref elf 0))
                         (elf-header-prog-header-count (list-ref elf 0)))))
    (write-bytes (list-ref elf 4)
                 stream)
    (file-position stream
                   (+ (elf-header-section-headers (list-ref elf 0))
                      (* (elf-header-sec-header-size (list-ref elf 0))
                         (elf-header-sec-header-count (list-ref elf 0)))))
    (write-bytes (list-ref elf 5)
                 stream))
  void)

; Usage example
;(define input-file "/usr/bin/emacs")
;(define elf
;  (read-elf (open-input-file input-file)))
;(call-with-output-file "/home/virtual/shit"
;  (lambda (out)
;    (write-elf elf out))
;  #:mode 'binary #:exists 'replace)
