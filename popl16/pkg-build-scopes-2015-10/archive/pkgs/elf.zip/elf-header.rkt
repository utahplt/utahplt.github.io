#lang racket/base

; elf-header.rkt

; Elf header support

(require racket/base racket/contract racket/bool elf/elf-constants)

(provide (struct-out elf-header)
         (contract-out [elf-magic? (-> bytes? boolean?)]
                       [read-elf-header (-> file-stream-port? elf-header?)]
                       [write-elf-header (-> elf-header? output-port? void?)]
                       [elf-info (-> elf-header? string?)])
         elf-endianess-convert-and-read)

(struct elf-header
  (class
    data
    version
    abi
    abiver
	 type
	 machine
	 entry
	 prog-headers
	 section-headers
	 flags
    header-size
	 prog-header-size
	 prog-header-count
	 sec-header-size
	 sec-header-count
	 sec-index)
  #:mutable)

; Wrapper for an easy elf-header
(define
  (new-elf-header)
  (elf-header elf-class-32 elf-2cmpl-lsb 1 elf-abi-gnu 0 elf-type-reloc elf-arch-386 0 0 0 0 0 0 0 0 0 0))

; Check if has valid elf magic
(define (elf-magic? input)
  (if (bytes=? input elf-magic)
      true false))

; To be removed
(define (elf-endianess-convert-and-read bstring endianess)
  (integer-bytes->integer bstring #false (not endianess)))

; Reads an elf header
(define (read-elf-header handle)
  (let ((input "")
        [header (new-elf-header)]
        [endianess false])
    (set! input
          (read-bytes 4 handle))
    (unless (elf-magic? input)
      (error "invalid elf magic" input))
    (set! input
          (read-bytes 12 handle))
    (set-elf-header-class! header
                           (bytes-ref input 0))
    (set-elf-header-data! header
                          (bytes-ref input 1))
    (set! endianess
          (if (= (elf-header-data header)
                 elf-2cmpl-lsb)
              false true))
    (set-elf-header-version! header
                             (bytes-ref input 2))
    (set-elf-header-abi! header
                         (bytes-ref input 3))
    (set-elf-header-abiver! header
                            (bytes-ref input 4))
    (set! input
          (read-bytes 8 handle))
    (set-elf-header-type! header
                          (integer-bytes->integer (subbytes input 0 2)
                                                  false
                                                  endianess))
    (set-elf-header-machine! header
                             (integer-bytes->integer (subbytes input 2 4)
                                                     false 
                                                     endianess)) ; We ignore the second version entry
    (if (= (elf-header-class header)
           elf-class-32)
        (begin (set! input
                     (read-bytes 12 handle))
               (set-elf-header-entry! header
                                      (integer-bytes->integer (subbytes input 0 4)
                                                              false
                                                              endianess))
               (set-elf-header-prog-headers! header
                                             (integer-bytes->integer (subbytes input 4 8)
                                                                     false
                                                                     endianess))
               (set-elf-header-section-headers! header
                                                (integer-bytes->integer (subbytes input 8 12)
                                                                        false
                                                                        endianess)))
        (begin
          (set! input
                (read-bytes 24 handle))
          (set-elf-header-entry! header
                                 (integer-bytes->integer (subbytes input 0 8)
                                                         false
                                                         endianess))
          (set-elf-header-prog-headers! header
                                        (integer-bytes->integer (subbytes input 8 16)
                                                                false
                                                                endianess))
          (set-elf-header-section-headers! header
                                           (integer-bytes->integer (subbytes input 16 24)
                                                                   false
                                                                   endianess))))
    (set! input
          (read-bytes 16 handle))
    (set-elf-header-flags! header
                           (integer-bytes->integer (subbytes input 0 4)
                                                   false
                                                   endianess))
    (set-elf-header-header-size! header
                                 (integer-bytes->integer (subbytes input 4 6)
                                                         false
                                                         endianess))
    (set-elf-header-prog-header-size! header
                                      (integer-bytes->integer (subbytes input 6 8)
                                                                      false
                                                                      endianess))
    (set-elf-header-prog-header-count! header
                                       (integer-bytes->integer (subbytes input 8 10)
                                                               false
                                                               endianess))
    (set-elf-header-sec-header-size! header
                                     (integer-bytes->integer (subbytes input 10 12)
                                                             false
                                                             endianess))
    (set-elf-header-sec-header-count! header
                                      (integer-bytes->integer (subbytes input 12 14)
                                                              false
                                                              endianess))
    (set-elf-header-sec-index! header
                               (integer-bytes->integer (subbytes input 14 16)
                                                       false
                                                       endianess))
    header))

; Writes an elf header
(define (write-elf-header header stream)
  (write-bytes (bytes-append elf-magic
                             (make-bytes 1
                                         (elf-header-class header))
                             (make-bytes 1
                                         (if (eq? (elf-header-data header)
                                                  elf-2cmpl-lsb)
                                             elf-2cmpl-lsb elf-2cmpl-msb))
                             (make-bytes 1
                                         (elf-header-version header))
                             (make-bytes 1
                                         (elf-header-abi header))
                             (make-bytes 1
                                         (elf-header-abiver header))
                             (make-bytes 7 0)
                             (integer->integer-bytes (elf-header-type header)
                                                     2
                                                     (not (eq? (elf-header-data header)
                                                               elf-2cmpl-lsb)))
                             (integer->integer-bytes (elf-header-machine header)
                                                     2
                                                     (not (eq? (elf-header-data header)
                                                               elf-2cmpl-lsb)))
                             (integer->integer-bytes (elf-header-version header)
                                                     4
                                                     (not (eq? (elf-header-data header)
                                                               elf-2cmpl-lsb)))
                             (if (= (elf-header-class header)
                                    elf-class-32)
                                 (bytes-append (integer->integer-bytes (elf-header-entry header)
                                                                         4
                                                                         (not (eq? (elf-header-data header)
                                                                                   elf-2cmpl-lsb)))
                                                 (integer->integer-bytes (elf-header-prog-headers header)
                                                                         4
                                                                         (not (eq? (elf-header-data header)
                                                                                 elf-2cmpl-lsb)))
                                                 (integer->integer-bytes (elf-header-section-headers header)
                                                                         4
                                                                         (not (eq? (elf-header-data header)
                                                                                 elf-2cmpl-lsb))))
                                 (bytes-append (integer->integer-bytes (elf-header-entry header)
                                                                       8
                                                                       (not (eq? (elf-header-data header)
                                                                                 elf-2cmpl-lsb)))
                                               (integer->integer-bytes (elf-header-prog-headers header)
                                                                       8
                                                                       (not (eq? (elf-header-data header)
                                                                                 elf-2cmpl-lsb)))
                                               (integer->integer-bytes (elf-header-section-headers header)
                                                                       8
                                                                       (not (eq? (elf-header-data header)
                                                                                 elf-2cmpl-lsb)))))
                             (integer->integer-bytes (elf-header-flags header)
                                                     4
                                                     (not (eq? (elf-header-data header)
                                                               elf-2cmpl-lsb)))
                             (integer->integer-bytes (if (= (elf-header-class header)
                                                            elf-class-32)
                                                         52 64)
                                                     2
                                                     (not (eq? (elf-header-data header)
                                                               elf-2cmpl-lsb)))
                             (integer->integer-bytes (if (= (elf-header-class header)
                                                            elf-class-32)
                                                         44 56)
                                                     2
                                                     (not (eq? (elf-header-data header)
                                                               elf-2cmpl-lsb)))
                             (integer->integer-bytes (elf-header-prog-header-count header)
                                                     2
                                                     (not (eq? (elf-header-data header)
                                                               elf-2cmpl-lsb)))
                             (integer->integer-bytes (if (= (elf-header-class header)
                                                            elf-class-32)
                                                         40 64)
                                                     2
                                                     (not (eq? (elf-header-data header)
                                                               elf-2cmpl-lsb)))
                             (integer->integer-bytes (elf-header-sec-header-count header)
                                                     2
                                                     (not (eq? (elf-header-data header)
                                                               elf-2cmpl-lsb)))
                             (integer->integer-bytes (elf-header-sec-index header)
                                                     2
                                                     (not (eq? (elf-header-data header)
                                                               elf-2cmpl-lsb)))) stream)
  (void))

; Returns a string with some general human readable information
(define (elf-info header)
   (let ((header (car header)))
     (string-append (cond ((= (elf-header-class header)
                              elf-class-32)
                           "elf-32")
                          (#true "elf-64"))
                    " "
                    (if (= (elf-header-data header)
                           elf-2cmpl-lsb)
                        "Least significant bit 2ers complement" "MSB")
                    " "
                    (if (= (elf-header-version header)
                           1)
                        "elf-version 1 (current)" "unknown version")
                    " "
                    (cond ((= (elf-header-abi header)
                              elf-abi-sysv)
                           "unix")
                          ((= (elf-header-abi header)
                              elf-abi-gnu)
                           "gnu")
                          (#true "unknown abi"))
                    " "
                    (if (= (elf-header-abiver header)
                           0)
                        "0" "unknown version")
                    " "
                    (cond ((= (elf-header-type header)
                              elf-type-reloc)
                           "relocateable")
                          ((= (elf-header-type header)
                              elf-type-exec)
                           "executable")
                          ((= (elf-header-type header)
                              elf-type-dyn)
                           "dynamic-library")
                          ((= (elf-header-type header)
                              elf-type-core)
                           "coredump")
                          (#true "unknown type"))
                    " "
                    (cond ((= (elf-header-machine header)
                              elf-arch-386)
                           "386")
                          ((= (elf-header-machine header)
                              elf-arch-x8664)
                           "AMD x86 64")
                          (#true "unknown architecture")))))
