Like `splitBy` from Mathematica
