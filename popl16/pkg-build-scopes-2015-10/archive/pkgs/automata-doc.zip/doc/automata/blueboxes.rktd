1820
((3) 0 () 4 ((q lib "automata/re.rkt") (q lib "automata/machine.rkt") (q lib "automata/re-ext.rkt") (q lib "automata/nfa-ep.rkt")) () (h ! (equal) ((c form c (c (? . 0) q star)) q (2274 . 2)) ((c form c (c (? . 0) q re)) q (1885 . 15)) ((c form c (c (? . 3) q nfa/ep)) q (1438 . 14)) ((c def c (c (? . 1) q machine-complement)) q (421 . 3)) ((c def c (c (? . 1) q machine-accepting?)) q (54 . 3)) ((c form c (c (? . 2) q rep)) q (2423 . 2)) ((c form c (c (? . 0) q rec)) q (2328 . 2)) ((c form c (c (? . 0) q epsilon)) q (2286 . 2)) ((c def c (c (? . 1) q machine-null)) q (320 . 2)) ((c form c (c (? . 0) q complement)) q (2232 . 2)) ((q form ((lib "automata/nfa.rkt") nfa)) q (1152 . 11)) ((c form c (c (? . 0) q dseq)) q (2316 . 2)) ((c form c (c (? . 2) q opt)) q (2380 . 2)) ((c form c (c (? . 0) q union)) q (2261 . 2)) ((c def c (c (? . 1) q machine-accepts?/prefix-closed)) q (212 . 4)) ((c form c (c (? . 3) q epsilon)) q (1423 . 2)) ((c form c (c (? . 0) q seq)) q (2250 . 2)) ((c def c (c (? . 1) q machine-seq*)) q (815 . 4)) ((c form c (c (? . 0) q define-re-transformer)) q (2339 . 2)) ((c def c (c (? . 1) q machine?)) q (0 . 3)) ((c form c (c (? . 2) q difference)) q (2449 . 2)) ((c def c (c (? . 1) q machine-accepts?)) q (118 . 4)) ((c form c (c (? . 2) q seq/close)) q (2531 . 2)) ((c def c (c (? . 1) q machine-union)) q (549 . 4)) ((q form ((lib "automata/dfa.rkt") dfa)) q (918 . 11)) ((c def c (c (? . 1) q machine-star)) q (488 . 3)) ((c form c (c (? . 0) q nullset)) q (2301 . 2)) ((c def c (c (? . 1) q machine-epsilon)) q (352 . 2)) ((c form c (c (? . 2) q plus)) q (2401 . 2)) ((c def c (c (? . 1) q machine-sigma*)) q (387 . 2)) ((c def c (c (? . 1) q machine-seq)) q (729 . 4)) ((c form c (c (? . 2) q intersection)) q (2489 . 2)) ((c def c (c (? . 1) q machine-intersect)) q (637 . 4))))
procedure
(machine? x) -> boolean?
  x : any/c
procedure
(machine-accepting? x) -> boolean?
  x : any/c
procedure
(machine-accepts? m i) -> boolean?
  m : machine?
  i : (listof any/c)
procedure
(machine-accepts?/prefix-closed m i) -> boolean?
  m : machine?
  i : (listof any/c)
value
machine-null : machine?
value
machine-epsilon : machine?
value
machine-sigma* : machine?
procedure
(machine-complement m) -> machine?
  m : machine?
procedure
(machine-star m) -> machine?
  m : machine?
procedure
(machine-union m0 m1) -> machine?
  m0 : machine?
  m1 : machine?
procedure
(machine-intersect m0 m1) -> machine?
  m0 : machine?
  m1 : machine?
procedure
(machine-seq m0 m1) -> machine?
  m0 : machine?
  m1 : machine?
procedure
(machine-seq* m0 make-m1) -> machine?
  m0 : machine?
  make-m1 : (-> machine?)
syntax
(dfa start
     (end ...)
     [state ([evt next-state]
             ...)]
     ...)
 
  start : identifier?
  end : identifier?
  state : identifier?
  next-state : identifier?
syntax
(nfa (start:id ...)
     (end:id ...)
     [state:id ([evt:expr (next-state:id ...)]
                ...)]
     ...)
 
  start : identifier?
  end : identifier?
  state : identifier?
  next-state : identifier?
syntax
epsilon
syntax
(nfa/ep (start:id ...)
        (end:id ...)
        [state:id ([epsilon (epsilon-state:id ...)]
                   ...
                   [evt:expr (next-state:id ...)]
                   ...)]
        ...)
 
  start : identifier?
  end : identifier?
  state : identifier?
  epsilon-state : identifier?
  next-state : identifier?
syntax
(re re-pat)
 
re-pat = (rec id re-pat)
       | ,expr
       | (complement re-pat)
       | (seq re-pat ...)
       | (union re-pat ...)
       | (star re-pat)
       | epsilon
       | nullset
       | re-transformer
       | (re-transformer . datum)
       | (dseq pat re-pat)
       | pat
syntax
complement
syntax
seq
syntax
union
syntax
star
syntax
epsilon
syntax
nullset
syntax
dseq
syntax
rec
syntax
(define-re-transformer id expr)
syntax
(opt re-pat)
syntax
(plus re-pat)
syntax
(rep re-pat num)
syntax
(difference re-pat_0 re-pat_1)
syntax
(intersection re-pat_0 re-pat_1)
syntax
(seq/close re-pat ...)
