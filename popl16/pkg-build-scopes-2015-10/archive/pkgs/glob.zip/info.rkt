#lang info
(define collection "glob")
(define deps '("base"))
(define build-deps '("cover" "cover-coveralls" "scribble-lib" "racket-doc" "rackunit-lib"))
(define pkg-desc "Unix-style globbing")
(define version "0.0")
(define pkg-authors '(ben))
(define scribblings '(("scribblings/glob.scrbl")))
