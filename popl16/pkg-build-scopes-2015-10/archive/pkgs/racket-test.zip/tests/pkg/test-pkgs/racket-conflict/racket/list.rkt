#lang racket
(error 'die!)
