730
((3) 0 () 2 ((q lib "remote-shell/ssh.rkt") (q lib "remote-shell/vbox.rkt")) () (h ! (equal) ((c def c (c (? . 1) q start-vbox-vm)) q (1784 . 11)) ((c def c (c (? . 0) q scp)) q (1277 . 6)) ((c def c (c (? . 0) q ssh)) q (720 . 14)) ((c def c (c (? . 0) q at-remote)) q (1494 . 4)) ((c def c (c (? . 1) q delete-vbox-snapshot)) q (2870 . 4)) ((c def c (c (? . 1) q take-vbox-snapshot)) q (2639 . 4)) ((c def c (c (? . 1) q stop-vbox-vm)) q (2265 . 9)) ((c def c (c (? . 1) q exists-vbox-snapshot?)) q (2986 . 4)) ((c def c (c (? . 0) q make-sure-remote-is-ready)) q (1592 . 5)) ((c def c (c (? . 0) q remote?)) q (0 . 3)) ((c def c (c (? . 0) q remote)) q (53 . 14)) ((c def c (c (? . 1) q restore-vbox-snapshot)) q (2753 . 4))))
procedure
(remote? v) -> boolean?
  v : any/c
procedure
(remote  #:host host                         
        [#:user user                         
         #:env env                           
         #:remote-tunnels remote-tunnels     
         #:key key                           
         #:timeout timeout-secs])        -> remote?
  host : string?
  user : string? = ""
  env : (listof (cons/c string? string?)) = '()
  remote-tunnels : (listof (cons/c (integer-in 1 65535)   = null
                                   (integer-in 1 65535)))
  key : (or/c #f path-string?) = #f
  timeout-secs : real? = 600
procedure
(ssh  remote                     
      command                    
     [#:mode mode                
      #:failure-log failure-dest 
      #:success-log success-dest 
      #:show-time? show-time?])  
 -> (or/c void? boolean? (cons/c boolean? bytes?))
  remote : remote?
  command : (or/c string? path-string?)
  mode : (or/c 'error 'result 'output) = 'error
  failure-dest : (or/c #f path-string?) = #f
  success-dest : (or/c #f path-string?) = #f
  show-time? : any/c = #f
procedure
(scp remote source dest [#:mode mode]) -> (or/c void? boolean?)
  remote : remote?
  source : path-string?
  dest : path-string?
  mode : (or/c 'error 'result 'output) = 'error
procedure
(at-remote remote path) -> string?
  remote : remote?
  path : path-string?
procedure
(make-sure-remote-is-ready  remote              
                           [#:tries tries]) -> void?
  remote : remote?
  tries : exact-nonnegative-integer? = 3
procedure
(start-vbox-vm  name                              
               [#:max-vms max-vms                 
                #:log-status log-status           
                #:pause-seconds pause-seconds     
                #:dry-run? dry-run?])         -> void?
  name : string?
  max-vms : real? = 1
  log-status : (string? #:rest any/c . -> . any) = printf
  pause-seconds : real? = 3
  dry-run? : any/c = #f
procedure
(stop-vbox-vm  name                          
              [#:save-state? save-state?     
               #:log-status log-status       
               #:dry-run? dry-run?])     -> void?
  name : string?
  save-state? : any/c = #t
  log-status : (string? #:rest any/c . -> . any) = printf
  dry-run? : any/c = #f
procedure
(take-vbox-snapshot name snapshot-name) -> void?
  name : string?
  snapshot-name : string?
procedure
(restore-vbox-snapshot name snapshot-name) -> void?
  name : string?
  snapshot-name : string?
procedure
(delete-vbox-snapshot name snapshot-name) -> void?
  name : string?
  snapshot-name : string?
procedure
(exists-vbox-snapshot? name snapshot-name) -> boolean?
  name : string?
  snapshot-name : string?
