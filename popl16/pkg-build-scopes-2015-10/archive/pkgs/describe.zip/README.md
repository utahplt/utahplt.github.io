describe
========

Mirror of describe
