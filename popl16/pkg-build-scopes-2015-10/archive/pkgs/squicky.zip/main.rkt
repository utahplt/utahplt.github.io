#lang racket/base
#|
exec @RACKET@ -l racket/base -u "$0" ${1+"$@"}
|#

(require "parser.rkt"
         "wiki2xml.rkt")

(provide (all-from-out "parser.rkt"))

(module+ main

  (require racket/cmdline)
  
  (define (Usage)
    (printf "~a~%Usage:~%    wiki2xml [--output filename] [--html] [--[no]structured] input-file?~%" (squicky-version))
    (exit 1))

  (define (define-option default)
    (let ((v default))
      (lambda args
        (if (null? args)
            v
            (set! v (car args))))))

  (let ((output-file (define-option #f))
        (structured-output (define-option #t))
        (output-html (define-option #f)))
    (let ((input-file
           (command-line
            #:program "wiki2xml"

            #:once-each
            ("--output"
             filename
             "File to receive XML output"
             (output-file filename))
            ("--structured"
             "Produce output with sections in <div>"
             (structured-output #t))
            ("--nostructured"
             "Produce output with sections in <h2>, <h3>, <h4>"
             (structured-output #f))
            ("--html"
             "Produce output as HTML"
             (output-html #t))
            ("--version"
             "Report version and exit"
             (Usage))

            #:args filenames

            filenames)))

      ;; Check, and bail out on bad input
      (when (> (length input-file) 1)
        (Usage))

      (let ((input-port (if (null? input-file)
                            (current-input-port)
                            (open-input-file (car input-file))))
            (output-port (cond ((output-file) => open-output-file)
                               (else (current-output-port)))))
        (if (output-html)
            (write-html-to-port (parse input-port)
                                output-port)
            (write-xml-to-port (parse input-port)
                               output-port
                               (structured-output)))))))
