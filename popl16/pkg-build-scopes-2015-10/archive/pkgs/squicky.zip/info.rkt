#lang info
(define collection "squicky")
(define scribblings '(("squicky.scrbl" ())))
(define version "1.1.2")
(define deps
  '("base"
    "parser-tools-lib"
    "scribble-lib"
    "srfi-lite-lib"))
(define build-deps
  '("at-exp-lib"
    "rackunit-lib"
    "racket-doc"))
