#lang scribble/manual

@(require scribble/srcdoc
          scribble/extract)
@(require (for-label "parser.rkt" racket/base))

@(declare-exporting "parser.rkt")

@title{Squicky: a quick wiki parser}
@author+email["Norman Gray"]{http://nxg.me.uk}

This is a parser for a wiki syntax based closely on
@hyperlink["http://www.wikicreole.org/"]{WikiCreole},
as described below. 
The source repository is available
@hyperlink["https://bitbucket.org/nxg/squicky"]{at bitbucket}.

Version 1.1.2, released 2015 September 22

@section{Usage}

The dialect parsed here is the consensus
WikiCreole syntax of @url{http://www.wikicreole.org/}.
It handles all of the WikiCreole
@hyperlink["http://www.wikicreole.org/wiki/Creole1.0TestCases"]{test cases},
except for one test of wiki-internal links (which is in any case somewhat underspecified).

In particular, the supported syntax is
@itemlist[
@item{@tt{//italics//}}
@item{@tt{**bold**} : A line which begins with @tt{**}, with possible whitespace either
side, is a (second-level) bulletted list if the line before it is a bulleted list,
but is a paragraph starting with bold text otherwise.}
@item{@tt{##monospaced text##} : A line which begins with @tt{##}, with possible whitespace either
side, is a (second-level) enumerated list if the line before it is an enumerated list,
but is a paragraph starting with monospace text otherwise. [This is
not specified in the WikiCreole definition, but is clearly compatible
with it].}
@item{@tt{ * bulleted list} : (including sublists, the asterisk may or
may not be indented)}
@item{@tt{ # numbered list} : (including sublists)}
@item{@tt{>quoted paragraph} : including multiple levels (this appears
to be an extension of WikiCreole).}
@item{@tt{[[link to wikipage]]}}
@item{@tt{[[URL|description]]}}
@item{@tt{{{image.png}}} or @tt{{{image.png|alt text}}} or @tt{{{image.png|att=value;att2=value; or more}}}.  In the last case, the @tt{att} indicates any attribute on the HTML @tt{<img>} element, such as @tt{class}; the @tt{att} must immediately follow the semicolon (so the last case (which is an extension to the Creole syntax) parses as @tt{att2='value; or more'}); and if the @tt{att} is omitted, it defaults to @tt{alt}.}
@item{@tt{== heading}}
@item{@tt{=== subheading}}
@item{@tt{==== subsubheading}}
@item{@tt{line\\break}}
@item{@verbatim|{----}| (four dashes in a row, on a line by themselves) horizontal list}
@item{@tt{~x} escaped character, and @tt{~http://url} which isn't linked}

@item{@verbatim|{{{{in-line literal text}}}}|}]

Blocks of verbatim text
(which will typically be rendered to @tt{<pre>} blocks),
can be specified with:
@verbatim{
{{{
preformatted text
}}}
}
The opening @tt|{{{{}|, and its closing partner, must be on
lines by themselves.  The newline after the opening marker, and the
newline before the closing one, are ignored.

Tables look like this:
@verbatim{
|=Heading Col 1 |=Heading Col 2         |
|Cell 1.1       |Two lines\\in Cell 1.2 |
|Cell 2.1       |Cell 2.2               |
}

To this I add syntax:
@itemlist[
@item{@tt{::key value...} :
adds ‘metadata’, which can be retrieved with the @racket[lookup] function;
For example after @tt{::title     Interesting things},
the value of the ‘title’ key will be @tt{Interesting things}.
This must be at the beginning of a line.}
@item{@tt{"quoted"} :
corresponds to @tt{<q>quoted</q>} (note that's a double-quote
character, not two single quotes).}
@item{@tt{<<element-name   content>>} :
adds @tt{<element-name>content</element-name>} to the output.}
@item{The @tt{att=value} syntax for @tt{{{image.png}}} is an extension.}
@item{@tt{!!target value ...} : processing instruction support –
adds a sexp equivalent to @tt{<?target value ...?>} to the output}]

For an example, the following parses some input text, and writes it
out as XML.

@racketblock[
(require xml
         squicky
         (prefix-in srfi19: srfi/19))

(define (write-html-to-port wiki-text port)
  (write-xml/content
   (xexpr->xml
    `(html ((xmlns "http://www.w3.org/1999/xhtml"))
           (head
            ,@(cond [(or (lookup-parsed wiki-text 'date)
                         (lookup-parsed wiki-text 'updated))
                     => (λ (date)
                           `((meta ((name "DC.date")
                                    (content ,(srfi19:date->string date "~4"))))))]
                    [else '()])
            (title ,(or (lookup wiki-text 'title) "Title")))
           (body
            ,@(body wiki-text))))
   port)
  (newline port))

(write-html-to-port (parse (current-input-port))
                    (current-output-port))
]

Suitable input text would be:
@verbatim{
::date 2010 December 12
== Here is a heading
Here is some text, with a list comprising:
  * one
  * two.

That's quite //astonishing!//.
}

The parsing is intended to be tolerant.  No matter how garbled the
WikiCreole syntax, the parser should not produce an error, or a body which
fails to satisfy the @racket[(listof xexpr?)] contract.

@section{Command line}

To convert input text to output, use
@verbatim{
% racket -l squicky -- --html input.wiki >input.html
}

Give the option @literal{--help} for other instructions.

@section{Reference}

@(include-extracted "parser.rkt")

@subsection{Parsing metadata lookups}

The default parsing function for @racket[lookup-parsed] treats
specially only the @racket['date] and @racket['updated] keys, which
are returned as SRFI-19 date objects.  The date parser is
reasonably lenient, and detects all of
@tt{2010-09-01},
@tt{2010-09-01T12:34:56},
@tt{2010 September 1},
@tt{1 Sep 2010},
@tt{Sep 1, 2010},
@tt{September 1, 2010},
@tt{1-09-2010},
@tt{1/9/2010} and
@tt{1 September 2010} as the same date
(that is, @tt{nn/nn/nnnn} dates are parsed as day-month-year, not
month-day-year; ISO-8601-style formats are probably the most reliable
in general).

You may override this parsing with a parameter:

@defparam[lookup-value-parser parser (-> symbol? string? any/c)]{
A parameter which evaluates to a parsing function for
@racket[lookup-parsed].  The function is given a key and a non-@tt["#f"]
string, and may return anything, including @tt{#f}.  If, for a given
key, @racket[lookup] would return the value @tt{#f}, then
@racket[lookup-parsed] returns @tt{#f}.  Otherwise,
@racket[lookup-parsed] returns the value of
@racket[((lookup-value-parser) key value)].
Thus, if the function does not recognise the key, it should return the value unchanged.}
