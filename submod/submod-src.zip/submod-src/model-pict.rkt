#lang racket/base
(require slideshow/pict
         redex/reduction-semantics
         redex/pict
         "model.rkt"
         "rewrites.rkt")

(provide (except-out (all-defined-out)
                     m:ast
                     t)
         (rename-out [m:ast ast]))


(define-language desc-L
  [mnam desc-mname]
  [dnam desc-dname]
  [ast desc-ast])
(define (desc-nam-pict)
  (language->pict desc-L #:nts '(mnam dnam)))
(define (desc-ast-pict)
  (language->pict desc-L #:nts '(ast)))

(define-language L-module
  [form (begin-for-syntax form ...)
        (define dnam expr)
        (define-syntax dnam expr)
        (require req)
        (module mnam mnam form ...)
        (module* mnam mnam form ...)
        (module* mnam () form ...)
        (dnam arb ...)]
  [req mnam
       (for-syntax req)
       (for-template req)]
  [expr desc-expr]
  [arb arb-expr])

(define (t s)
  (with-rewrites
   (text s 'roman (default-font-size))))

(define (nt s)
  (with-rewrites
   (text s (non-terminal-style) (default-font-size))))

(define (mf s)
  (with-rewrites
   (text s (metafunction-style) (metafunction-font-size))))

(define (m:ast s)
  (with-rewrites (ast s)))

(define-syntax-rule (tm e)
  (with-rewrites
   (term->pict L e)))

(define (mf/sym s)
  (mf (symbol->string s)))

(define-syntax signature
  (syntax-rules (: ->)
    [(_ nm : arg ... -> res)
     (hbl-append 4 (mf/sym 'nm) (t ":") (tm arg) ... (t "→") (tm res))]))

(define (s-exp-grammar-pict)
  (with-rewrites
   (language->pict L #:nts '(s-exp nam mnam dnam))))

(define (module-grammar-pict)
  (with-rewrites
   (vl-append
    10
    (language->pict L #:nts '(mod))
    (language->pict L #:nts '(dep defn))
    (language->pict L #:nts '(kind ph))
    (desc-nam-pict)
    (desc-ast-pict))))

(define (append-signature s m)
  (vc-append
   2
   (unscale s)
   m))

(define (cmodule-pict)
  (with-rewrites
   (append-signature
    (signature cmodule : s-exp M -> M)
    (parameterize ([linebreaks '(#t)])
      (metafunction->pict cmodule)))))

(define (run-pict)
  (with-rewrites
   (parameterize ()
     (vl-append
      10
      (append-signature
       (signature run : mnam ph M Σ -> Σ)
       (metafunction->pict run))
      (append-signature
       (signature run* : (Seq dep ...) ph M Σ -> Σ)
       (metafunction->pict run*))
      (append-signature
       (signature run-body : (Seq defn ...) nam ph Σ -> Σ)
       (parameterize ([linebreaks '(#f #t #t)])
         (metafunction->pict run-body)))))))

(define (bindings-pict)
  (with-rewrites
   (parameterize ()
     (vc-append
      10
      (language->pict L #:nts '(binding bindings))
      (append-signature
       (signature import : mnam ph M -> bindings)
       (metafunction->pict import))
      (language->pict L #:nts '(stx id))
      (append-signature
       (signature wrap : s-exp bindings -> stx)
       (metafunction->pict wrap))
      (language->pict L #:nts '(body))
      (append-signature
       (signature strip : stx -> s-exp)
       (metafunction->pict strip))))))

(define (resolve-pict)
  (with-rewrites
   (append-signature
    (signature resolve : id ph -> binding)
    (parameterize ([linebreaks '(#t)]
                   [metafunction-cases '(0)])
      (metafunction->pict resolve)))))

(define (module-language-pict)
  (with-rewrites
   (language->pict L-module)))

(define (cbody-signature-pict)
  (signature cbody : (Seq body ...) mnam (Seq dep ...) (Seq defn ...) M Σ -> M))

(define (cbody-done-pict)
  (with-rewrites
   (vc-append
    10
    (parameterize ([linebreaks '(#t)]
                   [metafunction-cases '(0)])
      (metafunction->pict cbody))
    (language->pict L #:nts '(deps defns)))))

(define (cbody-begin-syntax-pict)
  (with-rewrites
   (parameterize ([linebreaks '(#t)]
                  [metafunction-cases '(2)])
     (metafunction->pict cbody))))

(define (cbody-define-pict)
  (with-rewrites
   (parameterize ([linebreaks '(#t)]
                  [metafunction-cases '(3)])
     (metafunction->pict cbody))))

(define (cbody-define-syntax-pict)
  (with-rewrites
   (parameterize ([linebreaks '(#t)]
                  [metafunction-cases '(4)])
     (metafunction->pict cbody))))

(define (cbody-macro-pict)
  (with-rewrites
   (parameterize ([linebreaks '(#t)]
                  [metafunction-cases '(5)])
     (metafunction->pict cbody))))

(define (cbody-require-pict)
  (with-rewrites
   (vc-append
    10
    (parameterize ([linebreaks '(#t)]
                   [metafunction-cases '(6)])
      (metafunction->pict cbody))
    (append-signature
     (signature parse-req : stx ph -> [Tup nam ph])
     (metafunction->pict parse-req)))))

(define (cbody-module-pict)
  (with-rewrites
   (let ()
     (define (one n)
       (parameterize ([linebreaks '(#t)]
                      [metafunction-cases (list n)])
         (metafunction->pict cbody)))
     (vc-append 15 (one 7) (one 8) (one 9)))))

