This is the PLT Scheme v207 executable package folder for Windows.

The following are the executables:

  DrScheme.exe -- the Scheme development environment

  MzScheme.exe -- a text-only Scheme interpreter
  MrEd.exe -- a graphical Scheme interpreter
  mzc.exe -- a Scheme compiler
  Help Desk.exe --- for Help (also built into DrScheme)
  Setup PLT.exe --- command-line setup tool

In addition to the executables, system-wide libraries are used by
MzScheme executables (libmzchNNN_NNN.dll and libmzgcNNN_NNN.dll in the
Windows system folder), and MrEd executables (libmredNNN_NNN.dllfolder
in the samefolder).

PLT executables need to know where the PLT tree is installed, so if you
move an installed PLT tree, run Finish Install.exe immediately afterward
to update the executables.


License
-------

PLT Software
Copyright (c) 1995-2003 PLT
Copyright (c) 2004 PLT Inc.

PLT software is distributed under the GNU Lesser General Public License
(LGPL).  This means you can link PLT software (such as MzScheme or MrEd)
into proprietary applications, provided you follow the specific rules
stated in the LGPL.  You can also modify PLT software; if you distribute
a modified version, you must distribute it under the terms of the LGPL,
which in particular means that you must release the source code for the
modified software.  See notes/COPYING.LIB for more information.


More Information
----------------

For further information, select `Help Desk' from DrScheme's `Help' menu,
or run Help Desk.exe.  Also, visit http://www.plt-scheme.org/.
