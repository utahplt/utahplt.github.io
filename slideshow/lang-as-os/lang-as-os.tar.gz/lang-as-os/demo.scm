(define f (make-object frame% "Demo"))

(send f set-control-font
      (make-object font% 24
        'system 'normal 'normal))

(define b1
  (make-object button%
    "Loop Forever" f
    (lambda (b e)
      (let loop () (loop)))))

(define b2
  (make-object button%
    "Crash" f
    (lambda (b e)
      (+ 'not-a-num 1))))

(display "Frame is ready...")
